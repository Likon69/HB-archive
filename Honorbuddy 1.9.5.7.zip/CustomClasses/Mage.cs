﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using Styx;
using Styx.Combat.CombatRoutine;
using Styx.Helpers;
using Styx.Logic;
using Styx.Logic.Combat;
using Styx.Logic.Pathing;
using Styx.WoWInternals;
using Styx.WoWInternals.World;
using Styx.WoWInternals.WoWObjects;

namespace Mage
{
    internal class Mage : CombatRoutine
    {
        /*
         * Recommended Talent Spec
         * http://talent.mmo-champion.com/?mage#_CF9MYlsbiafpk,,9947
         */

        private bool _useFireCombat = false;
        private bool _useFrostCombat = true;
        private bool _useArcaneCombat = false;

        //eat And drink values
        private const int DrinkWhenManaPercentage = 50; //At which percentage you want it to drink.
        private const int EatWhenHealthPercentage = 60; //At which percentage you want it to eat.

        private static WoWUnit _lastPolymorphedUnit;

        private static uint _deathCount;

        private readonly Dictionary<int, int> _drinkSpells =
            new Dictionary<int, int> //Drink Dictionary, DONT EDIT!
                {
                    // Universal "all in one":	
                    {42956, 43523},
                    // 80
                    {42955, 43518},
                    // 75
                    // Water:	
                    {27090, 22018},
                    // 70
                    {37420, 30703},
                    // 65
                    {10140, 8079},
                    // 60
                    {10139, 8078},
                    // 50
                    {10138, 8077},
                    // 40
                    {6127, 3772},
                    // 30
                    {5506, 2136},
                    // 20
                    {5505, 2288},
                    // 10
                    {5504, 5350},
                    // 4
                };

        private readonly Dictionary<int, int> _foodSpells =
            new Dictionary<int, int> //Food Dictionary, DONT EDIT!
                {
                    // Universal "all in one":	
                    // {uint spellId, uint itemId},
                    {42956, 43523},
                    // 80
                    {42955, 43518},
                    // 75
                    // Food:		
                    {33717, 22019},
                    // 70
                    {28612, 22895},
                    // 60
                    {10145, 8076},
                    // 52
                    {10144, 8075},
                    // 42
                    {6129, 1487},
                    // 32
                    {990, 1114},
                    // 22
                    {597, 1113},
                    // 12
                    {587, 5349},
                    // 6
                };

        private readonly Dictionary<int, int> _gem = new Dictionary<int, int> //Mana gem dictionary, DONT EDIT!
                                                         {
                                                             //Mana Gem
                                                             //(uint spellId, uint itemId)
                                                             {42985, 33312},
                                                             //77
                                                             {27101, 22044},
                                                             //68
                                                             {10054, 8008},
                                                             //58
                                                             {10053, 8007},
                                                             //48
                                                             {3552, 5513},
                                                             //38
                                                             {759, 5514} //28
                                                         };

        private readonly List<uint> _gemIds = new List<uint> { 33312, 22044, 8008, 8007, 5513, 5514 };


        private int _drinkEntryId;
        private int _drinkSpellId;
        private int _foodEntryId;
        private int _foodSpellId;

        private int _gemId;
        private int _managemEntryId;


        private bool _updatedVictuals;

        public override WoWClass Class
        {
            get { return WoWClass.Mage; }
        }

        public override string Name
        {
            get { return "Hawker's Party Mage 2.3"; }
        }

        private static bool IsInGame
        {
            get { return ObjectManager.IsInGame; }
        }

        private static WoWUnit MyTarget
        {
            get { return ObjectManager.Me.CurrentTarget; }
        }

        private static bool GotTarget
        {
            get { return ObjectManager.Me.CurrentTarget != null; }
        }

        public uint GetFoodCount //Name speaks for itself, modify with caution
        {
            get
            {
                uint foodCount = 999;

                foreach (var spellFood in _foodSpells)
                {
                    if (SpellManagerEx.CanCast(spellFood.Key))
                    {
                        _foodEntryId = spellFood.Value;
                        _foodSpellId = spellFood.Key;
                        break;
                    }
                }

                if (_foodEntryId > 0)
                {
                    foodCount =
                        (uint)
                        Convert.ToInt32(
                            Lua.LuaGetReturnValue("return GetItemCount(\"" + _foodEntryId + "\")", "hawker.lua")[0]);
                }

                if (Equals(null, foodCount))
                {
                    return 9999;
                }

                return foodCount;
            }
        }

        private uint GetDrinkCount //Name speaks for itself, modify with caution.
        {
            get
            {
                uint drinkCount = 999;

                foreach (var spellDrink in _drinkSpells)
                {
                    if (SpellManagerEx.CanCast(spellDrink.Key))
                    {
                        _drinkEntryId = spellDrink.Value;
                        _drinkSpellId = spellDrink.Key;
                        break;
                    }
                }

                if (_drinkEntryId > 0)
                {
                    drinkCount =
                        (uint)
                        Convert.ToInt32(
                            Lua.LuaGetReturnValue("return GetItemCount(\"" + _drinkEntryId + "\")", "hawker.lua")[0]);
                }

                if (Equals(null, drinkCount))
                {
                    return 9999;
                }

                return drinkCount;
            }
        }

        private static void Player_OnMobKilled(BotEvents.Player.MobKilledEventArgs args)
        {
            StyxWoW.Me.ClearTarget();

            if (StyxWoW.Me.IsAutoAttacking)
            {
                StyxWoW.Me.ToggleAttack();
            }
        }

        private int GetGemCount()
        {
            int managemcount = 0;

            foreach (var spellgem in _gem)
            {
                if (SpellManagerEx.CanCast(spellgem.Key))
                {
                    _managemEntryId = spellgem.Value;
                    _gemId = spellgem.Key;
                    break;
                }
            }

            if (_managemEntryId > 0)
            {
                managemcount =
                    Convert.ToInt32(
                        Lua.LuaGetReturnValue("return GetItemCount(\"" + _managemEntryId + "\")", "hawker.lua")[0]);
            }

            if (managemcount == 0)
            {
                foreach (uint oldGemId in _gemIds)
                {
                    int a =
                        Convert.ToInt32(
                            Lua.LuaGetReturnValue("return GetItemCount(\"" + oldGemId + "\")", "hawker.lua")[0]);

                    if (a > 0)
                    {
                        Lua.DoString("/run PickupItem(\"" + oldGemId + "\")", "hawker.lua");
                        Lua.DoString("/run DeleteCursorItem()", "hawker.lua");
                    }
                }
            }

            return managemcount;
        }


        public void HandleFalling() { }

        private static void Slog(string format, params object[] args)
        {
            Logging.Write(format, args);
        }

        #region Global Variables

        public readonly LocalPlayer Me = ObjectManager.Me;
        private readonly TimeSpan _needBuffTimespan = new TimeSpan(0, 3, 0);

        #endregion

        #region Rest

        public override bool NeedRest
        {
            get
            {
                // SetCombatStyle();

                if (Me.Combat)
                {
                    return false;
                }

                if (ObjectManager.Me.Auras.ContainsKey("Resurrection Sickness"))
                {
                    return true;
                }

                if (Me.Auras.ContainsKey("Drink") || Me.Auras.ContainsKey("Food"))
                {
                    return true;
                }

                if (SpellManagerEx.HasSpell("Arcane Intellect"))
                {
                    if (!Me.Auras.ContainsKey("Arcane Intellect") &&
                        !Me.Auras.ContainsKey("Dalaran Intellect") &&
                        !Me.Auras.ContainsKey("Arcane Brilliance") &&
                        !Me.Auras.ContainsKey("Fel Intelligence") &&
                        !Me.Auras.ContainsKey("Dalaran Intellect"))
                    {
                        Slog("Need Arcane Intellect.");
                        return true;
                    }
                }

                if (SpellManagerEx.HasSpell("Arcane Intellect") && Me.Auras.ContainsKey("Arcane Intellect") &&
                    (Me.Auras["Arcane Intellect"].TimeLeft < _needBuffTimespan && Me.Auras["Arcane Intellect"].CreatorGuid == Me.Guid))
                {
                    Slog("Refresh Arcane Intellect.");
                    return true;
                }

                if (SpellManagerEx.HasSpell("Frost Armor") && Me.Auras.ContainsKey("Frost Armor") &&
                    Me.Auras["Frost Armor"].TimeLeft < _needBuffTimespan)
                {
                    Slog("Refresh Frost Armor.");
                    return true;
                }

                if (SpellManagerEx.HasSpell("Ice Armor") && Me.Auras.ContainsKey("Ice Armor") &&
                    Me.Auras["Ice Armor"].TimeLeft < _needBuffTimespan)
                {
                    Slog("Refresh Ice Armor.");
                    return true;
                }

                if (!Me.Auras.ContainsKey("Frost Armor") &&
                    SpellManagerEx.HasSpell("Frost Armor") &&
                    !SpellManagerEx.HasSpell("Ice Armor"))
                {
                    Slog("Need Frost Armor.");
                    return true;
                }
                else if (!Me.Auras.ContainsKey("Ice Armor") &&
                         SpellManagerEx.HasSpell("Ice Armor"))
                {
                    Slog("Need Ice Armor.");
                    return true;
                }

                if (Battlegrounds.IsInsideBattleground)
                {
                    return false;
                }

                if (!Me.Mounted && SpellManagerEx.HasSpell("Arcane Intellect"))
                {
                    foreach (WoWPlayer player in Me.PartyMembers)
                    {
                        if (player.HealthPercent > 5 && player.Class != WoWClass.DeathKnight &&
                            player.Class != WoWClass.Rogue &&
                            player.Class != WoWClass.Warrior &&
                            !player.Auras.ContainsKey("Arcane Intellect") &&
                            !player.Auras.ContainsKey("Dalaran Intellect") &&
                            !player.Auras.ContainsKey("Arcane Brilliance") &&
                            !player.Auras.ContainsKey("Fel Intelligence"))
                        {
                            return true;
                        }
                    }
                }

                double myHealthPercentage = ObjectManager.Me.GetPowerPercent(WoWPowerType.Health);
                double myManaPercentage = ObjectManager.Me.GetPowerPercent(WoWPowerType.Mana);

                if (Me.HealthPercent < EatWhenHealthPercentage &&
                    !Me.Auras.ContainsKey("Food")) //To prevent food spam.
                {
                    Slog("Need food.");
                    return true;
                }

                if (Me.ManaPercent < DrinkWhenManaPercentage &&
                    !Me.Auras.ContainsKey("Drink")) //To prevent drink spam.
                {
                    Slog("Need drink.");
                    return true;
                }

                if (!_updatedVictuals)
                {
                    if (GetDrinkCount < 4 &&
                        Me.Level > 3)
                    {
                        Slog("Make drinks.");
                        return true;
                    }

                    if (GetFoodCount < 4 &&
                        Me.Level > 5)
                    {
                        Slog("Make food.");
                        return true;
                    }

                    //if (GetGemCount() < 1 &&
                    //    Me.Level > 27)
                    //{
                    //    Slog("Make gems.");
                    //    return true;
                    //}

                    _updatedVictuals = true;
                }

                return false;
            }
        }

        public override void Rest()
        {
            while (Me.Auras.ContainsKey("Food") || Me.Auras.ContainsKey("Drink"))
            {
                Thread.Sleep(100);

                if (Me.HealthPercent == 100 && Me.ManaPercent == 100)
                {
                    break;
                }

                if (Me.Combat)
                {
                    break;
                }

                if (Me.HealthPercent == 100 && !Me.Auras.ContainsKey("Drink") ||
                    Me.ManaPercent == 100 && !Me.Auras.ContainsKey("Food"))
                {
                    break;
                }
            }

            if (!Me.Mounted)
            {
                MageBuffs();
            }

            if ((Me.Auras.ContainsKey("Drink") || Me.Auras.ContainsKey("Food")))
            {
                return;
            }

            if (!Me.Mounted && SpellManagerEx.HasSpell("Arcane Intellect"))
            {
                foreach (WoWPlayer player in Me.PartyMembers)
                {
                    if (player.HealthPercent > 5 && player.Class != WoWClass.DeathKnight &&
                        player.Class != WoWClass.Rogue && player.Class != WoWClass.Warrior &&
                        !player.Auras.ContainsKey("Arcane Intellect") &&
                        !player.Auras.ContainsKey("Dalaran Intellect") &&
                        !player.Auras.ContainsKey("Arcane Brilliance") &&
                        !player.Auras.ContainsKey("Fel Intelligence"))
                    {
                        player.Target();
                        Thread.Sleep(200);
                        if (SafeCast("Arcane Intellect"))
                        {
                            Slog("Arcane Intellect on " + player.Class);
                        }
                    }
                }
            }

            #region eat/drink

            double myHealthPercentage = ObjectManager.Me.GetPowerPercent(WoWPowerType.Health);
            double myManaPercentage = ObjectManager.Me.GetPowerPercent(WoWPowerType.Mana);

            WoWMovement.MoveStop();

            if (SpellManager.KnownSpells.ContainsKey("Evocation") &&
                Me.ManaPercent < 55 &&
                Me.HealthPercent > 30 &&
                Me.ManaPercent > 30)
            {
                WoWSpell evocationSpell = SpellManager.KnownSpells["Evocation"];
                bool evocationCooldown = evocationSpell.Cooldown;

                if (!evocationCooldown)
                {
                    Evocation();
                }
                else
                {
                    Slog("Evocation is on cooldown.");
                }
            }

            if (Me.HealthPercent < EatWhenHealthPercentage && GetFoodCount > 0 && !Me.Auras.ContainsKey("Food"))
            //To prevent food spam.
            {
                Lua.DoString("RunMacroText(\"/use item:" + _foodEntryId + "\");");
                //Lua inject to eat the highest level food
                Thread.Sleep(1000);
                if (Me.ManaPercent < 90)
                {
                    Lua.DoString("RunMacroText(\"/use item:" + _drinkEntryId + "\");");
                }
                Slog("Resting || Health: " + myHealthPercentage);
            }

            if (Me.ManaPercent < DrinkWhenManaPercentage && GetDrinkCount > 0 && !Me.Auras.ContainsKey("Drink"))
            //To prevent drink spam.
            {
                Lua.DoString("RunMacroText(\"/use item:" + _drinkEntryId + "\");");
                Thread.Sleep(1000);
                if (Me.HealthPercent < 90)
                {
                    Lua.DoString("RunMacroText(\"/use item:" + _foodEntryId + "\");");
                    //Lua inject to eat the highest level food
                }

                Slog("Resting || Mana: " + myManaPercentage);
                Thread.Sleep(2000);
            }

            if (!Me.Auras.ContainsKey("Drink"))
            //This line shouldnt be used because of the above code, but here to ensure that it actually is resting.
            {
                if (Me.ManaPercent < DrinkWhenManaPercentage)
                {
                    Lua.DoString("RunMacroText(\"/use item:" + _drinkEntryId + "\");");
                    Slog("Resting || Mana: " + myManaPercentage);
                    Thread.Sleep(1500);
                    if (Me.HealthPercent < 90)
                    {
                        Lua.DoString("RunMacroText(\"/use item:" + _foodEntryId + "\");");
                        //Lua inject to eat the highest level food
                    }
                    _updatedVictuals = true; //Prevent unnesesary lua injection.
                }
            }

            if (!Me.Auras.ContainsKey("Food"))
            //This line shouldnt be used because of the above code, but here to ensure that it actually is resting.
            {
                if (Me.HealthPercent < EatWhenHealthPercentage)
                {
                    Lua.DoString("RunMacroText(\"/use item:" + _foodEntryId + "\");");
                    Slog("Resting || Health: " + myHealthPercentage);

                    if (Me.ManaPercent < 90)
                    {
                        Lua.DoString("RunMacroText(\"/use item:" + _drinkEntryId + "\");");
                    }
                    Thread.Sleep(1500);
                    _updatedVictuals = true; //Prevent unesesary lua injection
                }
            }

            #endregion

            if (!Me.Auras.ContainsKey("Drink") && !Me.Auras.ContainsKey("Food"))
            {
                Slog("Check food and drinks.");

                _updatedVictuals = false;

                if (GetDrinkCount < 4)
                {
                    Slog("Make drinks.");
                    SafeCast(_drinkSpellId);
                    Thread.Sleep(4000);
                }

                //if (GetGemCount() < 1)
                //{
                //    Slog("Make Mana Gem.");
                //    SafeCast(_gemId);
                //    Thread.Sleep(4000);
                //}

                if (GetFoodCount < 4)
                {
                    Slog("Make food.");
                    SafeCast(_foodSpellId);
                    Thread.Sleep(4000);
                }

                MageBuffs();

                // this ought never get run over level 3
                if (Me.HealthPercent < EatWhenHealthPercentage)
                {
                    Styx.Logic.Common.Rest.Feed(); //these arent needed.
                }

                if (Me.ManaPercent < DrinkWhenManaPercentage)
                {
                    Styx.Logic.Common.Rest.Feed(); //these arent needed.
                }
            }
        }

        #endregion

        #region PreCombatBuffs

        public override bool NeedPreCombatBuffs
        {
            get { return false; }
        }

        public override void PreCombatBuff()
        {
            MageBuffs();
        }

        private void MageBuffs()
        {
            try
            {
                if (SpellManagerEx.HasSpell("Arcane Intellect") && Me.Auras.ContainsKey("Arcane Intellect") &&
                    Me.Auras["Arcane Intellect"].TimeLeft < _needBuffTimespan)
                {
                    if (Me.GotTarget && MyTarget.Guid != Me.Guid)
                    {
                        Me.ClearTarget();
                    }

                    SafeCast("Arcane Intellect");
                }
            }
            catch (Exception ex)
            {
                Logging.WriteException(ex);
            }

            if (SpellManagerEx.HasSpell("Frost Armor") && Me.Auras.ContainsKey("Frost Armor") &&
                Me.Auras["Frost Armor"].TimeLeft < _needBuffTimespan)
            {
                SafeCast("Frost Armor");
            }


            if (SpellManagerEx.HasSpell("Ice Armor") && Me.Auras.ContainsKey("Ice Armor") &&
                Me.Auras["Ice Armor"].TimeLeft < _needBuffTimespan)
            {
                SafeCast("Ice Armor");
            }

            if (!Me.Auras.ContainsKey("Arcane Intellect") &&
                !Me.Auras.ContainsKey("Arcane Brilliance"))
            {
                if (Me.GotTarget && MyTarget.Guid != Me.Guid)
                {
                    Me.ClearTarget();
                }

                SafeCast("Arcane Intellect");
            }

            if (!Me.Auras.ContainsKey("Frost Armor") &&
                SpellManagerEx.HasSpell("Frost Armor") &&
                !SpellManagerEx.HasSpell("Ice Armor"))
            {
                SafeCast("Frost Armor");
            }
            else if (!Me.Auras.ContainsKey("Ice Armor") &&
                     SpellManagerEx.HasSpell("Ice Armor"))
            {
                SafeCast("Ice Armor");
            }
        }

        #endregion

        #region CombatBuffs

        public override bool NeedCombatBuffs
        {
            get { return false; }
        }

        public override void CombatBuff() { }

        #endregion

        #region Heal

        public override bool NeedHeal
        {
            get { return false; }
        }

        public override void Heal()
        {
            //Nothing cool here yet
        }

        #endregion

        #region Pull

        public override bool NeedPullBuffs
        {
            get { return false; }
        }

        public override void PullBuff()
        {
            MageBuffs(); //Nice to be buffed before pull.
        }

        public override void Pull()
        {
            try
            {
                string targetName = string.Empty;

                // Try to avoid pulling adds...
                if (!GotTarget || MyTarget.Distance > Targeting.PullDistance)
                {
                    return;
                }
                else
                {
                    targetName = MyTarget.Name;
                }


                if (MyTarget.IsPlayer)
                {
                    targetName = "Level " + MyTarget.Level + " " + MyTarget.Race + " " + MyTarget.Class;
                }


                WoWPoint[] pathToTarget = Navigator.GeneratePath(ObjectManager.Me.Location, MyTarget.Location);

                if (pathToTarget.Length == 0 || !GameWorld.IsInLineOfSight(MyTarget.Location, pathToTarget[pathToTarget.Length - 1]))
                {
                    Blacklist.Add(MyTarget.Guid, new TimeSpan(0, 1, 0));
                    Logging.Write("(0} cannot be reached for now.", MyTarget.Name);
                }

                if (!Battlegrounds.IsInsideBattleground && Me.PartyMembers.Count > 0 &&
                    !Equals(null, Me.PartyMember1.CurrentTarget))
                {
                    Slog("Will on pull the party leader's target.");
                    return;
                }

                // SetCombatStyle();

                if (_useArcaneCombat)
                {
                    PullWithArcance(targetName);
                }
                else if (_useFrostCombat && SpellManagerEx.HasSpell("Frostbolt"))
                {
                    PullWithFrost(targetName);
                }
                else
                {
                    PullWithFire(targetName);
                }

            }
            catch (Exception ex)
            {
                Slog("Error in Pull(): {0}", ex.Message);
                Logging.WriteException(ex);
            }
            finally
            {
                // Slog("Pull Complete.");
            }
        }

        private void PullWithFire(string targetName)
        {
            if (SpellManagerEx.HasSpell("Pyroblast") && Me.CurrentMana > SpellManagerEx.Spells["Pyroblast"].PowerCost)
            {
                double spellDistance = SpellManagerEx.Spells["Pyroblast"].MaxRange - 2;

                if (MyTarget.Distance > spellDistance)
                {
                    _pointNow = WoWMovement.CalculatePointFrom(MyTarget.Location, (float)spellDistance - 2);
                    Navigator.MoveTo(_pointNow);
                    return;
                }

                Pyroblast();

                Slog("Cast Pyroblast on {0} at distance {1}", targetName, Math.Floor(MyTarget.Distance));
                int a = 0;

                while (a < 5 && !Me.Combat)
                {
                    while (Me.IsCasting)
                    {
                        Thread.Sleep(100);
                    }

                    if (!Me.IsCasting && !Me.Combat)
                    {
                        Fireball();
                        ++a;
                    }
                }
            }
            else
            {
                Slog("Pull with Fireball");

                double spellDistance = 33;

                if (MyTarget.Distance > spellDistance)
                {
                    _pointNow = WoWMovement.CalculatePointFrom(MyTarget.Location, (float)spellDistance - 2);
                    Navigator.MoveTo(_pointNow);
                    return;
                }
                Fireball();

                int a = 0;

                while (a < 5 && !Me.Combat)
                {
                    while (Me.IsCasting)
                    {
                        Thread.Sleep(100);
                    }

                    if (!Me.IsCasting && !Me.Combat)
                    {
                        Fireball();
                        ++a;
                    }
                }

                a = 0;
                while (Me.IsCasting)
                {
                    Thread.Sleep(250);
                    ++a;
                }

                Slog("Fireball pull of {0} at distance {1}", targetName, Math.Floor(MyTarget.Distance));
            }

        }

        private void PullWithFrost(string targetName)
        {
            double spellDistance = SpellManagerEx.Spells["Frostbolt"].MaxRange - 2;

            if (MyTarget.Distance > spellDistance)
            {
                _pointNow = WoWMovement.CalculatePointFrom(MyTarget.Location, (float)spellDistance - 2);
                Navigator.MoveTo(_pointNow);
                return;
            }

            int a = 0;

            while (a < 5 && !Me.Combat)
            {
                while (Me.IsCasting)
                {
                    Thread.Sleep(100);
                }

                if (!Me.IsCasting && !Me.Combat)
                {
                    Frostbolt();
                    ++a;
                }
            }

            Slog("Frostbolt pull of {0} at distance {1}", targetName, Math.Floor(MyTarget.Distance));

            a = 0;
            while (Me.IsCasting)
            {
                Thread.Sleep(250);
                ++a;
            }
        }

        private void PullWithArcance(string targetName)
        {
            if (SpellManagerEx.HasSpell("Slow") && !SpellManagerEx.Spells["Slow"].Cooldown)
            {
                double spellDistance = SpellManagerEx.Spells["Slow"].MaxRange - 2;

                if (MyTarget.Distance > spellDistance)
                {
                    _pointNow = WoWMovement.CalculatePointFrom(MyTarget.Location,
                                                               (float)spellDistance - 2);
                    Navigator.MoveTo(_pointNow);
                    return;
                }
                Slow();
                Slog("Cast slow on {0} at distance {1}", targetName, Math.Floor(MyTarget.Distance));
                int a = 0;

                while (a < 5 && !Me.Combat)
                {
                    while (Me.IsCasting)
                    {
                        Thread.Sleep(100);
                    }

                    if (!Me.IsCasting && !Me.Combat)
                    {
                        Frostbolt();
                        ++a;
                    }
                }
            }
        }

        #endregion

        #region Combat

        private bool CombatTest
        {
            get
            {
                if (Me.Dead)
                {
                    return false;
                }

                if (!Equals(null, RaFHelper.Leader) && !Equals(null, RaFHelper.Leader.CurrentTarget) &&
                    RaFHelper.Leader.Combat &&
                    !Equals(MyTarget, Me.PartyMember1.CurrentTarget))
                {
                    RaFHelper.Leader.CurrentTarget.Target();
                    MyTarget.Face();
                    Slog("Target the " + Me.PartyMember1.Class + "'s target.");
                    return true;
                }

                if (!Equals(null, RaFHelper.Leader) && !Equals(null, RaFHelper.Leader.CurrentTarget) &&
                    RaFHelper.Leader.Combat)
                {
                    return true;
                }

                if (Targeting.Instance.FirstUnit != null && Targeting.Instance.FirstUnit.CurrentTargetGuid == Me.Guid &&
                    (!GotTarget || (MyTarget.CurrentTarget != null && MyTarget.CurrentTargetGuid != Me.Guid)))
                {
                    Targeting.Instance.FirstUnit.Target();
                    Logging.Write("Switch to killing {0} with GUID {1}.", Targeting.Instance.FirstUnit.Name,
                                  Targeting.Instance.FirstUnit.Guid.ToString("X16"));
                    Thread.Sleep(200);
                }

                if (Me.Combat)
                {
                    return true;
                }

                return false;
            }
        }

        public override void Combat()
        {
            if (GotTarget && Me.CurrentTarget.Dead)
            {
                Me.ClearTarget();
                return;
            }
            if (Targeting.Instance.FirstUnit != null && Targeting.Instance.FirstUnit.CurrentTargetGuid == Me.Guid &&
                    (!GotTarget || !MyTarget.Combat))
            {
                Targeting.Instance.FirstUnit.Target();
                Thread.Sleep(200);
            }

            if (Me.IsCasting)
            {
                return;
            }

            // SetCombatStyle();

            if (_useFireCombat)
            {
                FireCombat();
            }
            else if (_useFrostCombat)
            {
                FrostCombat();
            }
            else if (_useArcaneCombat)
            {
                ArcaneCombat();
            }

        }

        private void ArcaneCombat()
        {
            try
            {
                if (AddsList.Count == 1 && !Me.GotTarget)
                {
                    List<WoWUnit> mobList = ObjectManager.GetObjectsOfType<WoWUnit>(false);

                    foreach (WoWUnit sheep in mobList)
                    {
                        if (sheep.Auras.ContainsKey("Polymorph"))
                        {
                            sheep.Target();
                            Thread.Sleep(200);
                        }
                    }
                }

                if (!Me.GotTarget ||
                    MyTarget.Distance > 50 ||
                    MyTarget.Dead)
                {
                    return;
                }
                else if (!SpellManagerEx.HasSpell("Arcane Missiles"))
                {
                    if (!Me.IsAutoAttacking)
                    {
                        Lua.DoString("StartAttack()");
                    }

                    if (Me.ManaPercent > 50)
                    {
                        Fireball();
                    }
                }
                else
                {
                    // have I died?
                    if (_deathCount < InfoPanel.Deaths)
                    {
                        FightTimer.Reset();
                        _deathCount = InfoPanel.Deaths;
                        Slog("I died in last fight.");
                    }

                    #region survival

                    // bugged mobs

                    if (!FightTimer.IsRunning || MyTarget.Guid != _lastGuid)
                    {
                        FightTimer.Reset();
                        FightTimer.Start();
                        _lastGuid = MyTarget.Guid;
                    }

                    if (!MyTarget.IsPlayer && FightTimer.ElapsedMilliseconds > 40 * 1000 &&
                        MyTarget.HealthPercent > 95)
                    {
                        Slog(" This " + MyTarget.Name + " is a bugged mob.  blacklisting for 1 hour.");

                        Blacklist.Add(MyTarget.Guid, TimeSpan.FromHours(1.00));

                        if (CanStrafeSafely(true, 10))
                        {
                            SafeMove(WoWMovement.MovementDirection.StrafeLeft, 1000);
                        }
                        else if (CanStrafeSafely(false, 10))
                        {
                            SafeMove(WoWMovement.MovementDirection.StrafeRight, 1000);
                        }
                        else
                        {
                            SafeMove(WoWMovement.MovementDirection.Backwards, 1000);
                        }

                        Me.ClearTarget();
                        _lastGuid = 0;
                    }

                    // things you need to check before casting any spells
                    if (Me.GotAlivePet && !Me.Pet.IsAutoAttacking)
                    {
                        Lua.DoString("PetAttack()");
                    }

                    if (Me.HealthPercent < 30 && MyTarget.HealthPercent > Me.HealthPercent)
                    {
                        Healing.UseHealthPotion();
                        GiftOfTheNaaru();
                        IceBarrier();

                        if (SpellManagerEx.Spells["Frost Nova"].Cooldown)
                        {
                            ColdSnap();
                        }

                        Slog("UseHealthPotion: " + MyTarget.ManaPercent + ":" + MyTarget.HealthPercent + ":" +
                             MyTarget.HealthPercent);
                    }

                    if (Me.ManaPercent < 30 &&
                        MyTarget.HealthPercent > MyTarget.HealthPercent)
                    {
                        Healing.UseManaPotion();
                        IceBarrier();

                        if (SpellManagerEx.Spells["Frost Nova"].Cooldown)
                        {
                            ColdSnap();
                        }

                        Slog("UseManaPotion: " + MyTarget.ManaPercent + ":" + MyTarget.HealthPercent + ":" +
                             MyTarget.HealthPercent);
                    }

                    if (Me.ManaPercent < 50 &&
                        MyTarget.HealthPercent > MyTarget.HealthPercent)
                    {
                        Lua.DoString("RunMacroText(\"/use item:" + _managemEntryId + "\");");
                    }

                    if (MyTarget.HealthPercent > 70 &&
                        Me.HealthPercent < 40)
                    {
                        Berserking();
                        Bloodrage();
                        WaterElemental();
                    }

                    if (Me.IsMoving)
                    {
                        WoWMovement.MoveStop();
                        Thread.Sleep(100);
                    }

                    WoWMovement.Face();
                }

                    #endregion

                #region defend

                // prevent casting
                if (Me.GotTarget && MyTarget.IsCasting)
                {
                    if (Me.Race == WoWRace.BloodElf && !SpellManagerEx.Spells["Arcane Torrent"].Cooldown && MyTarget.Distance < 6)
                    {
                        ArcaneTorrent();
                    }
                    else
                    {
                        Counterspell();
                    }
                }
                // get distance
                if (Me.GotTarget && MyTarget.Distance < 7 && SpellManagerEx.HasSpell("Frost Nova") &&
                    MyTarget.HealthPercent > 20)
                {
                    if (!SpellManagerEx.Spells["Frost Nova"].Cooldown &&
                        !MyTarget.Auras.ContainsKey("Frostbite") && !MyTarget.Auras.ContainsKey("Frost Nova"))
                    {
                        Lua.DoString("RunMacroText(\"/stopcasting\")");
                        Slog("Use Frost Nova to gain range.");
                        FrostNova();

                        if (CanStrafeSafely(true, 10))
                        {
                            SafeMove(WoWMovement.MovementDirection.StrafeLeft, 1000);
                        }
                        else if (CanStrafeSafely(false, 10))
                        {
                            SafeMove(WoWMovement.MovementDirection.StrafeRight, 1000);
                        }
                        else
                        {
                            SafeMove(WoWMovement.MovementDirection.Backwards, 1000);
                        }

                        WoWMovement.Face();

                        Frostbolt();
                        Fireblast();
                        Frostbolt();
                    }
                    else if (MyTarget.Auras.ContainsKey("Frostbite") || MyTarget.Auras.ContainsKey("Frost Nova"))
                    {
                        Slog("Move from frozen target.");
                        if (CanStrafeSafely(true, 10))
                        {
                            SafeMove(WoWMovement.MovementDirection.StrafeLeft, 1000);
                        }
                        else if (CanStrafeSafely(false, 10))
                        {
                            SafeMove(WoWMovement.MovementDirection.StrafeRight, 1000);
                        }
                        else
                        {
                            SafeMove(WoWMovement.MovementDirection.Backwards, 1000);
                        }


                        Frostbolt();


                        Fireblast();
                        Frostbolt();
                    }
                    else if (SpellManagerEx.Spells["Frost Nova"].Cooldown)
                    {
                        ColdSnap();
                        IceBarrier();
                    }
                }


                if (_lastPolymorphedUnit != null && !_lastPolymorphedUnit.Auras.ContainsKey("Polymorph") &&
                    AddsList.Count > 1 && SpellManagerEx.HasSpell("Polymorph") && !SpellManagerEx.Spells["Polymorph"].Cooldown)
                {
                    // polymorph time
                    foreach (WoWUnit mob in AddsList)
                    {
                        if (Me.GotTarget && MyTarget.Guid != mob.Guid && !SpellManagerEx.Spells["Polymorph"].Cooldown)
                        {
                            if (mob.CreatureType == WoWCreatureType.Beast || mob.CreatureType == WoWCreatureType.Humanoid)
                            {
                                WoWUnit myMob = MyTarget;
                                mob.Target();
                                SafeCast("Polymorph");
                                _lastPolymorphedUnit = mob;
                                myMob.Target();
                                break;
                            }
                        }
                    }

                    if (Me.HealthPercent < 75)
                    {
                        Healing.UseHealthPotion();
                        GiftOfTheNaaru();
                    }
                }

                #endregion

                #region attack

                if (!Me.GotTarget)
                {
                    return;
                }

                if (SpellManagerEx.HasSpell("Slow") && !MyTarget.Auras.ContainsKey("Slow") &&
                    !SpellManagerEx.Spells["Slow"].Cooldown)
                {
                    Slow();
                }
                else if (SpellManagerEx.HasSpell("Cone of Cold") && !SpellManagerEx.Spells["Cone of Cold"].Cooldown
                         && Me.HealthPercent < 30 && MyTarget.Distance < 6)
                {
                    if (!ConeOfCold())
                    {
                        Slog("Why no Cone of Cold?");
                    }
                }
                else if (SpellManagerEx.HasSpell("Fire Blast") && !SpellManagerEx.Spells["Fire Blast"].Cooldown
                         && (MyTarget.Auras.ContainsKey("Frostbite") || MyTarget.Auras.ContainsKey("Frost Nova")))
                {
                    ArcaneMissiles();
                    Fireblast();
                }
                else if (SpellManagerEx.HasSpell("Arcane Missiles"))
                {
                    ArcaneMissiles();
                }

                #endregion
            }
            finally
            {
                WoWMovement.MoveStop();
            }
        }

        private void FireCombat()
        {
            Slog("Fire combat");
            try
            {
                if (AddsList.Count == 1 && !Me.GotTarget)
                {
                    List<WoWUnit> mobList = ObjectManager.GetObjectsOfType<WoWUnit>(false);

                    foreach (WoWUnit sheep in mobList)
                    {
                        if (sheep.Auras.ContainsKey("Polymorph"))
                        {
                            sheep.Target();
                            Thread.Sleep(200);
                        }
                    }
                }

                if (!Me.GotTarget || MyTarget.Distance > 50 || MyTarget.Dead)
                {
                    return;
                }
                else
                {
                    // have I died?
                    if (_deathCount < InfoPanel.Deaths)
                    {
                        FightTimer.Reset();
                        _deathCount = InfoPanel.Deaths;
                        Slog("I died in last fight.");
                    }

                    #region survival

                    // bugged mobs
                    if (!Me.GotTarget)
                    {
                        return;
                    }

                    if (!FightTimer.IsRunning || MyTarget.Guid != _lastGuid)
                    {
                        FightTimer.Reset();
                        FightTimer.Start();
                        _lastGuid = MyTarget.Guid;
                    }

                    if (!MyTarget.IsPlayer && FightTimer.ElapsedMilliseconds > 40 * 1000 && MyTarget.HealthPercent > 95)
                    {
                        Slog(" This " + MyTarget.Name + " is a bugged mob.  blacklisting for 1 hour.");

                        Blacklist.Add(MyTarget.Guid, TimeSpan.FromHours(1.00));

                        if (CanStrafeSafely(true, 10))
                        {
                            SafeMove(WoWMovement.MovementDirection.StrafeLeft, 1000);
                        }
                        else if (CanStrafeSafely(false, 10))
                        {
                            SafeMove(WoWMovement.MovementDirection.StrafeRight, 1000);
                        }
                        else
                        {
                            SafeMove(WoWMovement.MovementDirection.Backwards, 1000);
                        }

                        Me.ClearTarget();
                        _lastGuid = 0;
                    }

                    // things you need to check before casting any spells
                    if (Me.GotAlivePet && !Me.Pet.IsAutoAttacking)
                    {
                        Lua.DoString("PetAttack()");
                    }

                    if (Me.HealthPercent < 50 && MyTarget.HealthPercent > MyTarget.HealthPercent)
                    {
                        Healing.UseHealthPotion();
                        GiftOfTheNaaru();
                        IceBarrier();


                        Slog("UseHealthPotion: " + MyTarget.ManaPercent + ":" + MyTarget.HealthPercent + ":" + MyTarget.HealthPercent);
                    }

                    if (Me.ManaPercent < 30 && MyTarget.HealthPercent > MyTarget.HealthPercent)
                    {
                        Healing.UseManaPotion();

                        Slog("UseManaPotion: " + MyTarget.ManaPercent + ":" + MyTarget.HealthPercent + ":" + MyTarget.HealthPercent);
                    }

                    if (Me.ManaPercent < 50 && MyTarget.HealthPercent > MyTarget.HealthPercent)
                    {
                        Lua.DoString("RunMacroText(\"/use item:" + _managemEntryId + "\");");
                    }

                    if (MyTarget.HealthPercent > 70 && Me.HealthPercent < 40)
                    {
                        Berserking();
                        Bloodrage();
                    }

                    if (Me.IsMoving)
                    {
                        WoWMovement.MoveStop();
                        Thread.Sleep(100);
                    }

                    WoWMovement.Face();
                }

                    #endregion

                #region defend

                if (!Me.IsAutoAttacking)
                {
                    Lua.DoString("StartAttack()");
                }

                // prevent casting
                if (MyTarget.IsCasting)
                {
                    if (Me.Race == WoWRace.BloodElf &&
                        !SpellManagerEx.Spells["Arcane Torrent"].Cooldown && MyTarget.Distance < 6)
                    {
                        ArcaneTorrent();
                    }
                    else
                    {
                        Counterspell();
                    }
                }
                // get distance if there is room to move
                if (Me.IsOutdoors && MyTarget.Distance < 7 && SpellManagerEx.HasSpell("Frost Nova") && MyTarget.HealthPercent > 20)
                {
                    if (!SpellManagerEx.Spells["Frost Nova"].Cooldown && !MyTarget.Auras.ContainsKey("Frostbite") && !MyTarget.Auras.ContainsKey("Frost Nova"))
                    {
                        Lua.DoString("RunMacroText(\"/stopcasting\")");
                        Slog("Use Frost Nova to gain range.");
                        FrostNova();

                        if (CanStrafeSafely(true, 10))
                        {
                            SafeMove(WoWMovement.MovementDirection.StrafeLeft, 1000);
                        }
                        else if (CanStrafeSafely(false, 10))
                        {
                            SafeMove(WoWMovement.MovementDirection.StrafeRight, 1000);
                        }
                        else
                        {
                            SafeMove(WoWMovement.MovementDirection.Backwards, 1000);
                        }

                        WoWMovement.Face();

                        if (SpellManagerEx.HasSpell("Pyroblast") && MyTarget.HealthPercent > 25 && Me.CurrentMana > SpellManagerEx.Spells["Pyroblast"].PowerCost)
                        {
                            Pyroblast();
                        }
                        else
                        {
                            Fireball();
                        }

                        Fireblast();
                        Fireball();
                    }
                    else if (MyTarget.Auras.ContainsKey("Frostbite") || MyTarget.Auras.ContainsKey("Frost Nova"))
                    {
                        Slog("Move from frozen target.");

                        if (CanStrafeSafely(true, 10))
                        {
                            SafeMove(WoWMovement.MovementDirection.StrafeLeft, 1000);
                        }
                        else if (CanStrafeSafely(false, 10))
                        {
                            SafeMove(WoWMovement.MovementDirection.StrafeRight, 1000);
                        }
                        else
                        {
                            SafeMove(WoWMovement.MovementDirection.Backwards, 1000);
                        }

                        WoWMovement.Face();

                        if (SpellManagerEx.HasSpell("Pyroblast") && MyTarget.HealthPercent > 25 && Me.CurrentMana > SpellManagerEx.Spells["Pyroblast"].PowerCost)
                        {
                            Pyroblast();
                        }
                        else
                        {
                            Fireball();
                        }

                        Fireblast();
                        Fireball();
                    }
                }

                if (_lastPolymorphedUnit != null && !_lastPolymorphedUnit.Auras.ContainsKey("Polymorph") &&
                    AddsList.Count > 1 && SpellManagerEx.HasSpell("Polymorph") && !SpellManagerEx.Spells["Polymorph"].Cooldown)
                {
                    // polymorph time
                    foreach (WoWUnit mob in AddsList)
                    {
                        if (MyTarget.Guid != mob.Guid && !SpellManagerEx.Spells["Polymorph"].Cooldown)
                        {
                            if (mob.CreatureType == WoWCreatureType.Beast ||
                                mob.CreatureType == WoWCreatureType.Humanoid)
                            {
                                WoWUnit myMob = MyTarget;
                                mob.Target();
                                SafeCast("Polymorph");
                                _lastPolymorphedUnit = mob;
                                myMob.Target();
                                break;
                            }
                        }
                    }

                    if (Me.HealthPercent < 75)
                    {
                        Healing.UseHealthPotion();
                        GiftOfTheNaaru();
                    }
                }

                #endregion

                #region attack

                if (MyTarget.Auras.ContainsKey("Frostbite") || MyTarget.Auras.ContainsKey("Frost Nova"))
                {
                    if (SpellManagerEx.HasSpell("Pyroblast"))
                    {
                        Pyroblast();
                        Fireblast();
                    }
                    else if (SpellManagerEx.HasSpell("Fire Blast") && !SpellManagerEx.Spells["Fire Blast"].Cooldown)
                    {
                        Fireball();
                        Fireblast();
                    }

                }
                Fireball();

                #endregion
            }
            finally
            {
                WoWMovement.MoveStop();
            }
        }
        private void FrostCombat()
        {
            try
            {
                if (AddsList.Count == 1 && !Me.GotTarget)
                {
                    List<WoWUnit> mobList = ObjectManager.GetObjectsOfType<WoWUnit>(false);

                    foreach (WoWUnit sheep in mobList)
                    {
                        if (sheep.Auras.ContainsKey("Polymorph"))
                        {
                            sheep.Target();
                            Thread.Sleep(200);
                        }
                    }
                }

                if (!Me.GotTarget || MyTarget.Distance > 50 || MyTarget.Dead)
                {
                    return;
                }
                else if (!SpellManagerEx.HasSpell("Frostbolt"))
                {
                    if (!Me.IsAutoAttacking)
                    {
                        Lua.DoString("StartAttack()");
                    }

                    if (Me.ManaPercent > 50)
                    {
                        Fireball();
                    }
                }
                else
                {
                    // have I died?
                    if (_deathCount < InfoPanel.Deaths)
                    {
                        FightTimer.Reset();
                        _deathCount = InfoPanel.Deaths;
                        Slog("I died in last fight.");
                    }

                    #region survival

                    // bugged mobs
                    if (!Me.GotTarget)
                    {
                        return;
                    }

                    if (!FightTimer.IsRunning || MyTarget.Guid != _lastGuid)
                    {
                        FightTimer.Reset();
                        FightTimer.Start();
                        _lastGuid = MyTarget.Guid;
                    }

                    if (!MyTarget.IsPlayer &&
                        FightTimer.ElapsedMilliseconds > 40 * 1000 &&
                        MyTarget.HealthPercent > 95)
                    {
                        Slog(" This " + MyTarget.Name + " is a bugged mob.  blacklisting for 1 hour.");

                        Blacklist.Add(MyTarget.Guid, TimeSpan.FromHours(1.00));

                        if (CanStrafeSafely(true, 10))
                        {
                            SafeMove(WoWMovement.MovementDirection.StrafeLeft, 1000);
                        }
                        else if (CanStrafeSafely(false, 10))
                        {
                            SafeMove(WoWMovement.MovementDirection.StrafeRight, 1000);
                        }
                        else
                        {
                            SafeMove(WoWMovement.MovementDirection.Backwards, 1000);
                        }

                        Me.ClearTarget();
                        _lastGuid = 0;
                    }

                    // things you need to check before casting any spells
                    if (Me.GotAlivePet && !Me.Pet.IsAutoAttacking)
                    {
                        Lua.DoString("PetAttack()");
                    }

                    if (Me.HealthPercent < 50 && MyTarget.HealthPercent > MyTarget.HealthPercent)
                    {
                        Healing.UseHealthPotion();
                        GiftOfTheNaaru();
                        IceBarrier();

                        if (SpellManagerEx.Spells["Frost Nova"].Cooldown)
                        {
                            ColdSnap();
                        }

                        Slog("UseHealthPotion: " + MyTarget.ManaPercent + ":" + MyTarget.HealthPercent + ":" +
                             MyTarget.HealthPercent);
                    }

                    if (Me.ManaPercent < 30 && MyTarget.HealthPercent > MyTarget.HealthPercent)
                    {
                        Healing.UseManaPotion();
                        IceBarrier();

                        if (SpellManagerEx.Spells["Frost Nova"].Cooldown)
                        {
                            ColdSnap();
                        }

                        Slog("UseManaPotion: " + MyTarget.ManaPercent + ":" + MyTarget.HealthPercent + ":" +
                             MyTarget.HealthPercent);
                    }

                    if (Me.ManaPercent < 50 && MyTarget.HealthPercent > MyTarget.HealthPercent)
                    {
                        Lua.DoString("RunMacroText(\"/use item:" + _managemEntryId + "\");");
                    }

                    if (MyTarget.HealthPercent > 70 &&
                        Me.HealthPercent < 40)
                    {
                        Berserking();
                        Bloodrage();
                        WaterElemental();
                    }

                    if (Me.IsMoving)
                    {
                        WoWMovement.MoveStop();
                        Thread.Sleep(100);
                    }

                    WoWMovement.Face();
                }

                    #endregion

                #region defend

                if (AddsList.Count > 1)
                {
                    IcyVeins();
                    WaterElemental();
                }

                // prevent casting
                if (MyTarget.IsCasting)
                {
                    if (Me.Race == WoWRace.BloodElf &&
                        !SpellManagerEx.Spells["Arcane Torrent"].Cooldown &&
                        MyTarget.Distance < 6)
                    {
                        ArcaneTorrent();
                    }
                    else
                    {
                        Counterspell();
                    }
                }
                // get distance
                if (MyTarget.Distance < 7 &&
                    SpellManagerEx.HasSpell("Frost Nova") &&
                    MyTarget.HealthPercent > 20)
                {
                    if (!SpellManagerEx.Spells["Frost Nova"].Cooldown &&
                        !MyTarget.Auras.ContainsKey("Frostbite") &&
                        !MyTarget.Auras.ContainsKey("Frost Nova"))
                    {
                        Lua.DoString("RunMacroText(\"/stopcasting\")");
                        Slog("Use Frost Nova to gain range.");
                        FrostNova();

                        if (CanStrafeSafely(true, 10))
                        {
                            SafeMove(WoWMovement.MovementDirection.StrafeLeft, 1000);
                        }
                        else if (CanStrafeSafely(false, 10))
                        {
                            SafeMove(WoWMovement.MovementDirection.StrafeRight, 1000);
                        }
                        else
                        {
                            SafeMove(WoWMovement.MovementDirection.Backwards, 1000);
                        }

                        WoWMovement.Face();

                        Frostbolt();


                        Fireblast();
                        Frostbolt();
                    }
                    else if (MyTarget.Auras.ContainsKey("Frostbite") ||                             MyTarget.Auras.ContainsKey("Frost Nova"))
                    {
                        Slog("Move from frozen target.");

                        if (CanStrafeSafely(true, 10))
                        {
                            SafeMove(WoWMovement.MovementDirection.StrafeLeft, 1000);
                        }
                        else if (CanStrafeSafely(false, 10))
                        {
                            SafeMove(WoWMovement.MovementDirection.StrafeRight, 1000);
                        }
                        else
                        {
                            SafeMove(WoWMovement.MovementDirection.Backwards, 1000);
                        }

                        WoWMovement.Face();

                        Frostbolt();
                        Fireblast();
                        Frostbolt();
                    }
                    else if (SpellManagerEx.Spells["Frost Nova"].Cooldown)
                    {
                        ColdSnap();
                        IceBarrier();
                    }
                }

                if (_lastPolymorphedUnit != null && !_lastPolymorphedUnit.Auras.ContainsKey("Polymorph") &&
                    AddsList.Count > 1 && SpellManagerEx.HasSpell("Polymorph") && !SpellManagerEx.Spells["Polymorph"].Cooldown)
                {
                    // polymorph time
                    foreach (WoWUnit mob in AddsList)
                    {
                        if (MyTarget.Guid != mob.Guid && !SpellManagerEx.Spells["Polymorph"].Cooldown)
                        {
                            if (mob.CreatureType == WoWCreatureType.Beast ||
                                mob.CreatureType == WoWCreatureType.Humanoid)
                            {
                                WoWUnit myMob = MyTarget;
                                mob.Target();
                                SafeCast("Polymorph");
                                _lastPolymorphedUnit = mob;
                                myMob.Target();
                                break;
                            }
                        }
                    }

                    if (Me.HealthPercent < 75)
                    {
                        Healing.UseHealthPotion();
                        GiftOfTheNaaru();
                    }

                    IcyVeins();
                    WaterElemental();
                }

                #endregion

                #region attack

                if (SpellManagerEx.HasSpell("Deep Freeze") &&
                    !SpellManagerEx.Spells["Deep Freeze"].Cooldown &&
                    (MyTarget.Auras.ContainsKey("Frostbite") ||
                     MyTarget.Auras.ContainsKey("Frost Nova")))
                {
                    if (SpellManagerEx.Spells["Deep Freeze"].Cooldown)
                    {
                        Slog("Deep FreezeCooldown? " + SpellManagerEx.Spells["Deep Freeze"].Cooldown);
                        Slog(deepFreezeTimer.ElapsedMilliseconds + " milliseconds since last try.");
                    }
                    IceLance();
                    DeepFreeze();
                }
                else if (SpellManagerEx.HasSpell("Cone of Cold") &&
                         !SpellManagerEx.Spells["Cone of Cold"].Cooldown &&
                         Me.HealthPercent < 30 &&
                         MyTarget.Distance < 6)
                {
                    if (!ConeOfCold())
                    {
                        Slog("Why no Cone of Cold?");
                    }
                }
                else if (SpellManagerEx.HasSpell("Fire Blast") &&
                         !SpellManagerEx.Spells["Fire Blast"].Cooldown &&
                         (MyTarget.Auras.ContainsKey("Frostbite") ||
                          MyTarget.Auras.ContainsKey("Frost Nova")))
                {
                    Frostbolt();
                    Fireblast();
                }

                else if (SpellManagerEx.HasSpell("Frostbolt"))
                {
                    Frostbolt();
                }

                #endregion
            }
            finally
            {
                WoWMovement.MoveStop();
            }
        }

        #region Spells

        /// <summary>
        /// Deep Freeze
        /// Stuns the target for 5 sec.  Only usable on Frozen targets.
        /// </summary>
        private static readonly Stopwatch deepFreezeTimer = new Stopwatch();

        private bool ArcaneMissiles()
        {
            if (Me.GotTarget)
            {
                WoWMovement.MoveStop();
                WoWMovement.Face();

                if (SafeCast("Presence of Mind"))
                {
                    Slog("Presence of Mind.");
                }

                if (SafeCast("Arcane Barrage"))
                {
                    Slog("Arcane Barrage.");
                }

                if (SafeCast("Arcane Missiles"))
                {
                    Slog("Arcane Missiles.");
                    return true;
                }
            }
            return false;
        }

        private bool Slow()
        {
            if (Me.GotTarget)
            {
                WoWMovement.MoveStop();
                WoWMovement.Face();

                if (SafeCast("Slow"))
                {
                    Slog("Slow.");
                    return true;
                }
            }
            return false;
        }

        private bool Pyroblast()
        {
            if (Me.GotTarget)
            {
                WoWMovement.MoveStop();
                WoWMovement.Face();

                Thread.Sleep(100);

                if (SafeCast("Pyroblast"))
                {
                    Thread.Sleep(1000);
                    while (Me.IsCasting)
                    {
                        Thread.Sleep(100);
                    }
                    Slog("Pyroblast.");
                    return true;
                }
            }
            return false;
        }


        /// <summary>
        /// Launches a bolt of frost at the enemy, causing Frost damage and slowing movement speed.
        /// </summary>
        private bool Frostbolt()
        {
            if (Me.IsCasting)
            {
                return false;
            }


            if (Me.GotTarget)
            {
                List<uint> FrostImmuneMobs = new List<uint>()
                {
                    20079, 2250, 2251,
                };
                if (FrostImmuneMobs.Contains(MyTarget.Entry))
                {
                    Fireball();
                    return true;
                }

                if (CombatChecks)
                {
                    if (MyTarget.Distance <= SpellManagerEx.Spells["Fireball"].MaxRange - 1 &&
                        HasBuffProcced("Fireball!", 0))
                    {
                        Fireball();
                    }

                    if (SafeCast("Frostbolt"))
                    {
                        Slog("Frostbolt.");
                        return true;
                    }
                }
            }
            return false;
        }

        /// <summary>
        /// Hurls a fiery ball that causes 14 to 22 Fire damage and an additional 2 Fire damage over 4 sec.
        /// </summary>
        private bool Fireball()
        {
            if (Me.IsCasting)
            {
                return false;
            }


            if (Me.GotTarget)
            {
                List<uint> FireImmuneMobs = new List<uint>()
                {
                    // none yet
                };

                if (FireImmuneMobs.Contains(MyTarget.Entry))
                {
                    // who cares
                }

                if (CombatChecks)
                {
                    if (SafeCast("Fireball"))
                    {
                        Slog("Fireball.");
                        return true;
                    }
                }
            }
            return false;
        }


        /// <summary>
        /// Hastens your spellcasting, increasing spell casting speed by 20% and reduces the pushback suffered from damaging attacks while casting by 100%.  Lasts 20 sec.
        /// </summary>
        private void IcyVeins()
        {
            if (Me.GotTarget && SafeCast("Icy Veins"))
            {
                Slog("Icy Veins.");
            }
        }

        /// <summary>
        /// Ice Lance
        /// Instantly deals 161 to 187 Frost damage to an enemy target.  Causes triple damage against Frozen targets.
        /// </summary>
        private void IceLance()
        {
            if (Me.GotTarget &&
                SafeCast("Ice Lance"))
            {
                Slog("Ice Lance.");
            }
        }

        private void DeepFreeze()
        {
            if (Me.GotTarget &&
                SafeCast("Deep Freeze"))
            {
                Slog("Deep Freeze");
                deepFreezeTimer.Reset();
                deepFreezeTimer.Start();
            }
        }

        /// <summary>
        /// Targets in a cone in front of the caster take Frost damage and are slowed by 50% for 8 sec.
        /// </summary>
        private bool ConeOfCold()
        {
            if (Me.GotTarget &&
                SpellManagerEx.HasSpell("Cone of Cold"))
            {
                WoWSpell coneOfCold = SpellManagerEx.Spells["Cone of Cold"];

                if (MyTarget.Distance <= 5 &&
                    !coneOfCold.Cooldown &&
                    SafeCast("Cone of Cold"))
                {
                    Slog("Cone of Cold.");
                    return true;
                }
                else
                {
                    return false;
                }
            }
            return false;
        }

        /// <summary>
        /// When activated, this spell finishes the cooldown on all Frost spells you recently cast.
        /// </summary>
        private void ColdSnap()
        {
            if (Me.GotTarget && SpellManagerEx.Spells.ContainsKey("Cold Snap") && !SpellManagerEx.Spells["Cold Snap"].Cooldown && SafeCast("Cold Snap"))
            {
                Slog("Cold Snap.");
            }
        }

        /// <summary>
        /// Counters the enemy's spellcast, preventing any spell from that school of magic from being cast for 8 sec.
        /// </summary>
        private void Counterspell()
        {
            if (Me.GotTarget && SpellManagerEx.Spells.ContainsKey("Counterspell") && !SpellManagerEx.Spells["Counterspell"].Cooldown && SafeCast("Counterspell"))
            {
                Slog("Counterspell.");
            }
        }

        /// <summary>
        /// Instantly shields you, absorbing damage.  Lasts 1 min.  While the shield holds, spellcasting will not be delayed by damage.
        /// </summary>
        private void IceBarrier()
        {
            if (SafeCast("Ice Barrier"))
            {
                Slog("Ice Barrier.");
            }
        }

        /// <summary>
        /// While channeling this spell, you gain 60% of your total mana over 8 sec.
        /// </summary>
        private void Evocation()
        {
            if (SafeCast("Evocation"))
            {
                Slog("Evocation.");
                Thread.Sleep(1000);

                int a = 0;

                while (a < 81 && !Me.Combat && Me.ManaPercent < 100 && Me.IsCasting)
                {
                    Thread.Sleep(100);
                    ++a;
                }
            }
        }

        /// <summary>
        /// Blasts enemies near the caster with Frost damage and freezes them in place for up to 8 sec.  Damage caused may interrupt the effect.
        /// </summary>        
        private bool FrostNova()
        {
            if (Me.GotTarget)
            {
                if (!MyTarget.Dead)
                {
                    if (SafeCast("Frost Nova"))
                    {
                        Slog("Frost Nova.");
                        return true;
                    }
                }
            }
            return false;
        }

        /// <summary>
        /// Instantly blasts the enemy for Fire damage.
        /// </summary>
        private void Fireblast()
        {
            if (SpellManagerEx.HasSpell("Fire Blast") && Me.GotTarget &&
                MyTarget.Distance <= SpellManagerEx.Spells["Fire Blast"].MaxRange)
            {
                while (Me.IsCasting || StyxWoW.GlobalCooldown)
                {
                    Thread.Sleep(100);
                }
            }

            Thread.Sleep(100);

            if (SpellManagerEx.HasSpell("Fire Blast") && Me.GotTarget &&
                MyTarget.Distance <= SpellManagerEx.Spells["Fire Blast"].MaxRange &&
                SafeCast("Fire Blast"))
            {
                Slog("Fire Blast.");
            }
            else
            {
                Slog("No Fire Blast: {0}", SpellManagerEx.Spells["Fire Blast"].MaxRange);
            }
        }

        private bool useManaGem() //your choice.
        {
            if ((Me.GotTarget &&
                 Me.Combat &&
                 Me.ManaPercent < 20 &&
                 MyTarget.HealthPercent > 20) ||
                (Me.Combat && Me.GotTarget && Me.ManaPercent <= 10))
            {
                Lua.DoString("luaDrinkCount = GetItemCount(" + _managemEntryId + ")");
                _updatedVictuals = false;
            }
            return false;
        }

        /// <summary>
        /// Summon a Water Elemental to fight for the caster for 45 sec.
        /// </summary>
        private void WaterElemental()
        {
            if (Me.GotTarget && SafeCast("Summon Water Elemental"))
            {
                Slog("Summon Water Elemental.");
            }
        }

        #endregion

        #endregion

        #region combat utilities

        private static ulong _lastGuid;
        private static readonly Stopwatch FightTimer = new Stopwatch();
        private static WoWPoint _pointNow;


        private static Stopwatch TalentTimer = new Stopwatch();
        /// <summary>
        /// This is not used as the Fire and Arcane combat logic are not ready for leveling
        /// </summary>
        private void SetCombatStyle()
        {
            if (!ObjectManager.IsInGame)
                return;

            if (TalentTimer.IsRunning && TalentTimer.ElapsedMilliseconds < 60 * 1000 * 5)
            {
                return;
            }
            else
            {
                TalentTimer.Reset();
                TalentTimer.Start();
            }

            if (Me.Level < 10)
            {
                _useFireCombat = true;
                return;
            }

            int nTab;

            int ArcaneTalents = 0;
            int FireTalents = 0;
            int FrostTalents = 0;



            for (nTab = 1; nTab <= 3; nTab++)
            {
                try
                {
                    List<string> tabInfo = Lua.LuaGetReturnValue("return GetTalentTabInfo(" + nTab + ",false,false," + 1 + ")", "hawker.lua");

                    if (!Equals(null, tabInfo))
                    {

                        switch (nTab)
                        {
                            case 1:
                                ArcaneTalents = Convert.ToInt32(tabInfo[2]);
                                if (ArcaneTalents > 0)
                                {
                                    Slog("Arcane Talents: {0}", ArcaneTalents);
                                }
                                break;
                            case 2:
                                FireTalents = Convert.ToInt32(tabInfo[2]);
                                if (FireTalents > 0)
                                {
                                    Slog("Fire Talents: {0}", FireTalents);
                                }
                                break;
                            case 3:
                                FrostTalents = Convert.ToInt32(tabInfo[2]);
                                if (FrostTalents > 0)
                                {
                                    Slog("Frost Talents: {0}", FrostTalents);
                                }
                                break;
                        }
                    }

                }
                catch (Exception ex)
                {
                    Logging.WriteException(ex);
                }

                if (ArcaneTalents > FrostTalents && ArcaneTalents > FireTalents)
                {
                    _useArcaneCombat = true;
                    _useFireCombat = false;
                    _useFrostCombat = false;

                    Slog("Arcane Combat is preferred style.");
                }
                else if (FireTalents > FrostTalents && FireTalents > ArcaneTalents)
                {
                    _useArcaneCombat = false;
                    _useFireCombat = true;
                    _useFrostCombat = false;
                    Slog("Fire is the preferred combat style");
                }
                else
                {
                    _useArcaneCombat = false;
                    _useFireCombat = false;
                    _useFrostCombat = true;

                    if (FrostTalents > 0)
                    {
                        Slog("Frost is the preferred combat style");
                    }
                }
            }
        }

        private bool CombatChecks
        {
            get
            {
                try
                {
                    if (!GotTarget)
                    {
                        return false;
                    }

                    if (Me.Dead)
                    {
                        Slog("I have died.");
                        return false;
                    }

                    if (MyTarget.Distance > 50 && MyTarget.Distance < 100)
                    {
                        Slog("Out of range: " + MyTarget.Name + " is " + Math.Round(MyTarget.Distance) + " yards away.");
                        if (ObjectManager.Me.IsMoving)
                        {
                            WoWMovement.MoveStop();
                        }
                        return false;
                    }

                    float spellRange = 30;

                    if (MyTarget.Distance > spellRange)
                    {
                        Slog(MyTarget.Name + " is at " + Math.Round(MyTarget.Distance) + " yards.");
                        int approachSeconds = 0;

                        // get within range
                        while (Me.IsAlive && MyTarget.IsAlive && approachSeconds < 10 && MyTarget.Distance > spellRange && MyTarget.Distance < 50)
                        {
                            _pointNow = WoWMovement.CalculatePointFrom(MyTarget.Location, spellRange - 2);
                            Navigator.MoveTo(_pointNow);

                            Thread.Sleep(250);

                            ++approachSeconds;
                        }

                        approachSeconds = 0;
                        while (approachSeconds < 10 && !MyTarget.InLineOfSight)
                        {
                            _pointNow = WoWMovement.CalculatePointFrom(MyTarget.Location, 4);
                            Navigator.MoveTo(_pointNow);

                            Thread.Sleep(250);

                            ++approachSeconds;
                        }

                        WoWMovement.MoveStop();
                    }

                    if (!MyTarget.InLineOfSight && Targeting.Instance.FirstUnit != null &&
                        Targeting.Instance.FirstUnit.CurrentTargetGuid == Me.Guid &&
                        (!GotTarget || !MyTarget.Combat))
                    {
                        Targeting.Instance.FirstUnit.Target();
                        Logging.Write("Switch to killing {0} with GUID {1}.", Targeting.Instance.FirstUnit.Name,
                                      Targeting.Instance.FirstUnit.Guid);
                        Thread.Sleep(200);
                    }

                    Thread.Sleep(10);

                    if (ObjectManager.Me.IsMoving)
                    {
                        WoWMovement.MoveStop();
                    }

                    WoWMovement.Face();

                    return true;
                }
                catch
                {
                    Slog("Error in Combat Checks");
                    return false;
                }

            }
        }

        private List<WoWUnit> AddsList
        {
            get
            {
                List<WoWUnit> mobList = ObjectManager.GetObjectsOfType<WoWUnit>(false);
                var enemyMobList = new List<WoWUnit>();

                foreach (WoWUnit thing in mobList)
                {
                    try
                    {
                        if ((thing.Guid != Me.Guid) && (thing.IsTargetingMeOrPet || thing.Fleeing))
                        {
                            enemyMobList.Add(thing);
                        }
                    }
                    catch (Exception ex)
                    {
                        Logging.WriteException(ex);
                        Slog("Add error.");
                    }
                }

                if (enemyMobList.Count > 1)
                {
                    Slog("Warning: there are " + enemyMobList.Count + " attackers.");
                }
                return enemyMobList;
            }
        }

        private bool SafeCast(int spellId)
        {
            if (SpellManagerEx.HasSpell(spellId) && !StyxWoW.Me.IsCasting)
            {
                while (StyxWoW.GlobalCooldown)
                {
                    Thread.Sleep(100);
                }

                SpellManagerEx.Cast(spellId);
                return true;
            }

            return false;
        }

        private bool SafeCast(string spellName)
        {
            if (Me.IsCasting || !SpellManagerEx.HasSpell(spellName))
            {
                return false;
            }

            if (SpellManagerEx.HasSpell(spellName) && !StyxWoW.Me.IsCasting)
            {
                if (SpellManagerEx.Spells[spellName].CastTime > 1)
                {
                    WoWMovement.MoveStop();
                    WoWMovement.Face();
                }

                try
                {
                    if (StyxWoW.Me.GotTarget && MyTarget.Attackable)
                    {
                        WoWMovement.Face();
                    }
                }
                catch
                {
                    Logging.WriteDebug("No need to face target.");
                }

                while (StyxWoW.GlobalCooldown)
                {
                    Thread.Sleep(100);
                }

                SpellManagerEx.Cast(spellName);

                return true;
            }

            Logging.WriteDebug("{0} can't cast {1}.", Name, spellName);

            return false;
        }

        private static void EvadeCheck()
        {
            for (int i = -1; i > -5; i--)
            {
                List<string> clog =
                    Lua.LuaGetReturnValue(
                        string.Format("CombatLogSetCurrentEntry({0}) return CombatLogGetCurrentEntry(\"true\")", i),
                        "_main.lua");
                if (clog == null || clog.Count < 12)
                {
                    return;
                }

                string sourceName = clog[3];
                string destName = clog[6];
                string missType = clog[11];
                if (missType.ToUpper() == "EVADE" && sourceName == ObjectManager.Me.Name &&
                    destName == MyTarget.Name)
                {
                    Slog(MyTarget.Name + " is evading.");
                    Blacklist.Add(MyTarget.Guid, TimeSpan.FromMinutes(5));
                    break;
                }
                // Logging.WriteDebug(clog[0]);
            }
        }

        /// <summary>
        /// Has this buff procced?
        /// </summary>
        /// <param name="cSearchBuffName"></param>
        /// <returns>True if the buff is present</returns>
        private static bool HasBuffProcced(string cSearchBuffName, int minStackCount)
        {
            int stackCount = 0;

            List<string> myBuffs = Lua.LuaGetReturnValue("return UnitBuff(\"player\",\"" + cSearchBuffName + "\")",
                                                         "hawker.lua");

            if (Equals(null, myBuffs))
            {
                return false;
            }

            string buffName = myBuffs[0];

            if (minStackCount > 0)
            {
                stackCount = Convert.ToInt32(myBuffs[3]);
            }

            if (buffName == cSearchBuffName || stackCount >= minStackCount)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// Move while alive and in game
        /// </summary>
        /// <param name="direction">The way to go</param>
        /// <param name="duration">Time to go in milliseconds</param>
        private static void SafeMove(WoWMovement.MovementDirection direction, int duration)
        {
            DateTime start = DateTime.Now;

            if (direction == WoWMovement.MovementDirection.StrafeMovement)
            {
                // Backwards means we want to strafe... check that first.
                // Left first
                if (CanStrafeSafely(true, 15f))
                {
                    direction = WoWMovement.MovementDirection.StrafeLeft;
                }
                else if (CanStrafeSafely(false, 15f))
                {
                    direction = WoWMovement.MovementDirection.StrafeRight;
                }
                else
                {
                    direction = WoWMovement.MovementDirection.Backwards;
                }
            }

            WoWMovement.Move(direction);

            while (IsInGame && ObjectManager.Me.HealthPercent > 1)
            {
                Thread.Sleep(335);

                if (DateTime.Now.Subtract(start).Milliseconds < 300 ||
                    DateTime.Now.Subtract(start).Milliseconds >= duration)
                {
                    break;
                }
            }

            WoWMovement.MoveStop(direction);
        }

        public static int AggroWithin(WoWPoint obj, float range, bool targetingMe)
        {
            if (targetingMe)
            {
                return (from o in ObjectManager.ObjectList
                        where o is WoWUnit && o.Location.Distance(obj) <= range
                        let u = o.ToUnit()
                        where u.Attackable && u.Aggro && !u.Dead && u.CurrentTarget == StyxWoW.Me
                        select o).Count();
            }
            return (from o in ObjectManager.ObjectList
                    where o is WoWUnit && o.Location.Distance(obj) <= range
                    let u = o.ToUnit()
                    where u.Attackable && u.Aggro && !u.Dead
                    select o).Count();
        }


        /// <summary>
        /// Finds the target, with the least amount of pullable adds.
        /// </summary>
        /// <returns></returns>
        public static WoWUnit FindBestTarget()
        {
            // Order by the amount of adds the unit has
            return (from o in Targeting.Instance.TargetList
                    orderby AggroWithin(o.Location, 10f, false),
                        Targeting.Instance.TargetList.IndexOf(o) ascending
                    select o).First().ToUnit();
        }

        public static bool CanStrafeSafely(bool left, float distance)
        {
            // Do this in degrees, since I'm lazy for right now.
            float myFacing = StyxWoW.Me.RotationDegrees;
            float direction = left ? myFacing - 90f : myFacing + 90f;

            if (direction < 0)
            {
                direction += 360f;
            }
            else if (direction > 360)
            {
                direction -= 360f;
            }

            direction = WoWMathHelper.DegreesToRadians(direction);
            WoWPoint myLoc = StyxWoW.Me.Location;
            WoWPoint endPoint = WoWPoint.RayCast(myLoc, direction, distance);

            // First, check for terrain collisions.
            if (GameWorld.IsInLineOfSight(endPoint, myLoc))
            {
                // We can strafe on the terrain, so now we check if we will run into aggro over there
                return AggroWithin(endPoint, distance, false) == 0;
            }

            // Can't safely strafe, so return false.
            return false;
        }

        #endregion

        #region horde racials

        // Berserking
        private void Berserking()
        {
            if (ObjectManager.Me.Race == WoWRace.Troll && SafeCast("Berserking"))
            {
                Logging.Write("Berserking.");
            }
        }

        // Bloodrage
        private void Bloodrage()
        {
            if (ObjectManager.Me.Race == WoWRace.Orc && SafeCast("Bloodrage"))
            {
                Logging.Write("Bloodrage.");
            }
        }

        // War Stomp
        private void WarStomp()
        {
            if (ObjectManager.Me.Race == WoWRace.Tauren && SafeCast("War Stomp"))
            {
                Logging.Write("War Stomp.");
            }
        }

        // Arcane Torrent
        private void ArcaneTorrent()
        {
            if (ObjectManager.Me.Race == WoWRace.BloodElf && SafeCast("Arcane Torrent"))
            {
                Logging.Write("Arcane Torrent.");
            }
        }

        // Will of the Forsaken 
        private void WillOfTheForsaken()
        {
            if (ObjectManager.Me.Race == WoWRace.Undead && SafeCast("Will of the Forsaken"))
            {
                Logging.Write("Will of the Forsaken.");
            }
        }

        #endregion

        #region alliance racials

        // Stoneform
        private void Stoneform()
        {
            if (ObjectManager.Me.Race == WoWRace.Dwarf && SafeCast("Stoneform"))
            {
                Logging.Write("Stoneform.");
            }
        }

        // Gift of the Naaru
        private void GiftOfTheNaaru()
        {
            if (ObjectManager.Me.Race == WoWRace.Draenei && SafeCast("Gift of the Naaru"))
            {
                Logging.Write("Gift of the Naaru.");
            }
        }

        // Every Man for Himself
        private void EveryManForHimself()
        {
            if (ObjectManager.Me.Race == WoWRace.Human && SafeCast("Every Man for Himself"))
            {
                Logging.Write("Every Man for Himself.");
            }
        }

        // Shadowmeld
        private void Shadowmeld()
        {
            if (ObjectManager.Me.Race == WoWRace.NightElf && SafeCast("Shadowmeld"))
            {
                Logging.Write("Shadowmeld.");
            }
        }

        // Escape Artist
        private void EscapeArtist()
        {
            if (ObjectManager.Me.Race == WoWRace.Gnome && SafeCast("Escape Artist"))
            {
                Logging.Write("Escape Artist.");
            }
        }

        #endregion

        #region Disenchanting

        private void GetGreens()
        {
            List<WoWItem> items = ObjectManager.GetObjectsOfType<WoWItem>(false);
            List<WoWItem> notSoulbound = items.Where(obj => !obj.IsSoulbound &&
                                                            obj.Quality == WoWItemQuality.Uncommon).ToList();

            foreach (WoWItem item in notSoulbound)
            {
                Logging.Write("{0} is not soulbound", item.Name);
            }
        }

        #endregion
    }
}