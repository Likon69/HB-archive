﻿
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Numerics;
using System.Threading.Tasks;
using Bots.DungeonBuddy.Behaviors;
using Buddy.Coroutines;
using CommonBehaviors.Actions;
using Styx;
using Styx.Common;
using Styx.Common.Helpers;
using Styx.CommonBot;
using Styx.CommonBot.Bars;
using Styx.CommonBot.Coroutines;
using Styx.CommonBot.Frames;
using Styx.Helpers;
using Styx.Patchables;
using Styx.Pathing;
using Styx.TreeSharp;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using Styx.WoWInternals.World;
using Action = Styx.TreeSharp.Action;
using Bots.DungeonBuddy.Profiles;
using Bots.DungeonBuddy.Attributes;
using Bots.DungeonBuddy.Enums;
using Bots.DungeonBuddy.Helpers;
using Styx.CommonBot.Routines;
using Styx.Pathing.Avoidance;


namespace Bots.DungeonBuddy.Dungeon_Scripts.Mists_of_Pandaria
{
    #region Normal Difficulty

    public class GateOfTheSettingSun : Dungeon
    {
        #region Overrides of Dungeon

        private const float ElevatorBottomZ = 388.1946f;
        private const float ElevatorTopZ = 430.2219f;
        private const float SouthOfGreatDoorX = 917;
        private const float NorthOfGreatDoorX = 1000;
        private const float LevelDividerZ = 350;
        private const uint RopeStalkerId = 58109;
        private const uint DoodadGreatWallDoor001Id = 212982;

        private readonly Vector3 _elevatorBottomBoardLoc = new Vector3(1195.308f, 2304.462f, 388.8313f);
        private readonly Vector3 _elevatorBottomWaitLoc = new Vector3(1193.303f, 2297.308f, 388.1255f);
        private readonly Vector3 _elevatorTopBoardLoc = new Vector3(1195.167f, 2304.742f, 430.8589f);
        private readonly Vector3 _elevatorTopWaitLoc = new Vector3(1203.566f, 2304.513f, 430.8623f);
        private readonly Vector3 _gadokRoomLoc = new Vector3(1195.002f, 2305.316f, 430.8587f);
        private readonly WaitTimer _ropeInteractTimer = new WaitTimer(TimeSpan.FromSeconds(2));

        private readonly CircularQueue<Vector3> _ropeLocations = new CircularQueue<Vector3>
                                                                  {
                                                                      new Vector3(842.0536f, 2315.725f, 381.3216f),
                                                                      new Vector3(842.3929f, 2299.741f, 381.3215f)
                                                                  };

        private WaitTimer _ropeTimer;
        private uint _ropeUseCounter;

        public override bool IsFlyingCorpseRun
        {
            get { return true; }
        }

        public override uint DungeonId
        {
            get { return 631; }
        }

        public override Vector3 Entrance
        {
            get { return new Vector3(699.101f, 2080.291f, 374.6979f); }
        }

        public override Vector3 ExitLocation
        {
            get
            {
                // use the top exit portal if dungeon is not complete or toon is not by last boss.
                return !IsComplete || Me.Z > LevelDividerZ
                    ? new Vector3(721.3207f, 2098.361f, 403.9803f)
                    : new Vector3(958.9496f, 2161.863f, 296.1056f);
            }
        }

        private readonly CircularQueue<Vector3> _corpseRunBreadCrumb = new CircularQueue<Vector3>()
                                                                    {
                                                                        new Vector3(639.6627f, 2082.097f, 384.1649f),
                                                                        new Vector3(699.101f, 2080.291f, 374.6979f)
                                                                    };
        public override CircularQueue<Vector3> CorpseRunBreadCrumb { get { return Me.IsGhost ? _corpseRunBreadCrumb : base.CorpseRunBreadCrumb; } }

        private bool GreatDoorBroken { get { return !ScriptHelpers.IsBossAlive("Commander Ri'mok"); } }

        private float _originalFarclip;

        public override void OnEnter()
        {
            _wallScalingPackTimer = null;
            // temp fix for a WoW bug that causes an invisible wall to spawn somewhere along the path between south entrance and last boss.
            _originalFarclip = Lua.GetReturnVal<float>("return GetCVar('farclip')", 0);
            Lua.DoString("SetCVar('farclip', {0})", 500);
        }

        public override void OnExit()
        {
            Lua.DoString("SetCVar('farclip', {0})", _originalFarclip);
        }

        public override void RemoveTargetsFilter(List<WoWObject> units)
        {
            var tank = ScriptHelpers.Tank;
            var tankTransport = tank != null ? tank.Transport : null;
            var isSolo = !Me.GroupInfo.IsInParty;
            var isRange = Me.IsRange();

            units.RemoveAll(
                ret =>
                {
                    var unit = ret.ToUnit();
                    if (unit != null)
                    {
                        // If solo farming then don't bother with trash unless in combat with them. 
                        if (isSolo && unit.Entry != WeakSpotId && unit.ThreatInfo.ThreatStatus == ThreatStatus.UnitNotInThreatTable
                            && ProfileManager.CurrentProfile.BossEncounters.All(b => b.Entry != unit.Entry))
                        {
                            return true;
                        }

                        // remove targets that being kited by group members.
                        if (unit.Combat && _kitedMobs.Contains(unit.Entry))
                        {
                            if (unit.IsTargetingMyPartyMember && (tank == null || !tank.IsMe))
                            {
                                if (tank == null)
                                    return true;
                                if (!tank.IsMe)
                                {
                                    var meleeRange = unit.MeleeRange;
                                    if (tank.Location.DistanceSquared((Vector3)unit.Location) > meleeRange * meleeRange)
                                        return true;

                                    if (tankTransport != null && tankTransport.Entry == ElevatorId)
                                        return true;
                                }
                            }
                            // sometimes these mobe will stay in combat with group while stuck on wall, just ignore them if that's the case.
                            if (unit.ZDiff > 15)
                                return true;
                        }
                        if (tank != StyxWoW.Me && _inCombatMobs.Contains(unit.Entry) && unit.ThreatInfo.ThreatStatus == ThreatStatus.UnitNotInThreatTable)
                            return true;
                        if (unit.Entry == KrikthikEngulferId && (Me.IsMelee() || unit.Distance > 35 || Me.InVehicle))
                            return true;
                        // ignore Striker Gadok if he's on a strafing run and toon isn't a solo ranged class
                        if (unit.Entry == StrikerGadokId && (!isRange || !isSolo) && unit.Z > StrikerGadokStrafeZ)
                            return true;
                        // force tank to get off elevator before calling CR pull behavior and getting stuck due to CR blacklisting because boss can't be navigated to from elevator.
                        if (unit.Entry == StrikerGadokId && Me.IsTank() && Me.TransportGuid.IsValid && !Me.Combat)
                            return true;

                        if (unit.Entry == KrikthikSwarmerId && (!Me.IsTank() || !_pickupSwarmers))
                            return true;

                        if (unit.Entry == RaigonnId && unit.Combat && unit.HasAura("Impervious Carapace") && Me.IsDps)
                            return true;
                    }
                    return false;
                });
        }

        public override void IncludeTargetsFilter(List<WoWObject> incomingunits, HashSet<WoWObject> outgoingunits)
        {
            foreach (var obj in incomingunits)
            {
                var unit = obj as WoWUnit;
                if (unit != null)
                {
                    // I have to add these units manually because they apear as non-hostile if using WoWUnit.IsHostile.
                    if (_inCombatMobs.Contains(unit.Entry) && !Me.Combat && unit.Distance <= 40)
                        outgoingunits.Add(unit);
                    if (unit.Entry == RaigonnId && !unit.Combat && Me.IsTank() && unit.Distance < 40)
                        outgoingunits.Add(unit);
                    if (unit.Entry == WeakSpotId && Me.HasAura(FactionOverrideId))
                        outgoingunits.Add(unit);

                    // ranged DPS should kill engulfers but ignore the ones that are > 20 Zdiff unless they're within casting 
                    // range since they probably can't be navigated to. Navigator.CanNavigateFully is too expensive to call here.
                    if (unit.Entry == KrikthikEngulferId && Me.IsRangeDps() && (unit.DistanceSqr < 35 * 35 || unit.ZDiff < 20))
                        outgoingunits.Add(unit);
                }
            }
        }

        public override void WeighTargetsFilter(List<Targeting.TargetPriority> units)
        {
            foreach (var priority in units)
            {
                var unit = priority.Object as WoWUnit;
                if (unit != null)
                {
                    // Only attack Striker Gadok when there's nothing else to attack if he's on a strafing run
                    if (unit.Entry == StrikerGadokId && unit.Z > StrikerGadokStrafeZ)
                        priority.Score -= 5000;

                    if (unit.Entry == WeakSpotId)
                        priority.Score += 5000;

                    // ignore the adds on commander Rimok if I'm dps.
                    if (unit.Entry == CommanderRimokId && Me.IsDps)
                        priority.Score += 5000;

                    if (unit.Entry == CommanderRimokId && Me.IsTank() && unit.CurrentTargetGuid != Me.Guid)
                        priority.Score += 5000;

                    if (unit.Entry == KrikthikEngulferId && Me.IsRange())
                        priority.Score += 3000;
                }
            }
        }

        public override void IncludeLootTargetsFilter(List<WoWObject> incomingObjects, HashSet<WoWObject> outgoingObjects)
        {
            foreach (var obj in incomingObjects)
            {
                var unit = obj as WoWUnit;
                if (unit != null)
                {
                    // Sometimes these bosses are not looted because toon is stuck in combat and default filters don't include targets while in combat.
                    if ((unit.Entry == StrikerGadokId || unit.Entry == MobId_Raigonn) && DungeonBuddySettings.Instance.LootMode != LootMode.Off)
                        outgoingObjects.Add(unit);
                }
            }
        }

        private Vector3 _destination;
        public override async Task<bool> HandleMovement(Vector3 location)
        {
            _destination = location;
            if (Me.IsGhost)
            {
                // sometime bot gets dismounted while flying to entrance and false down off wall where it can't get to entrance
                // so we need to port back to spirit healer.
                if (!Me.MovementInfo.CanFly)
                {
                    Lua.DoString("PortGraveyard()");
                    Logger.Write("Porting back to graveyard");
                    await Coroutine.Sleep(2000);
                    return true;
                }
                return false;
            }

            if (await ElevatorBehavior(location))
                return true;

            var myLoc = Me.Location;
            var iAmNorthOfGreatDoor = myLoc.X > NorthOfGreatDoorX;
            var iAmSouthOfGreatDoor = myLoc.X < SouthOfGreatDoorX;
            var destinationIsNorthOfGreatDoor = location.X > NorthOfGreatDoorX;
            var destinationIsSouthOfGreatDoor = location.X < SouthOfGreatDoorX;
            var iAmOnBottomLevel = myLoc.Z < LevelDividerZ;
            var destinationIsOnBottomLevel = location.Z < LevelDividerZ;

            var movingNorthAcrossGreatDoor = (iAmSouthOfGreatDoor || iAmOnBottomLevel) && destinationIsNorthOfGreatDoor && !destinationIsOnBottomLevel;
            var movingSouthAcrossGreatDoor = (iAmNorthOfGreatDoor || iAmOnBottomLevel) && destinationIsSouthOfGreatDoor && !destinationIsOnBottomLevel;
            var movingToBottomLevel = !iAmOnBottomLevel && destinationIsOnBottomLevel;
            var movingToTopLevel = iAmOnBottomLevel && !destinationIsOnBottomLevel;

            // are we moving to last boss or do we need to get to other side of broken door?
            if ((movingToBottomLevel || ((movingNorthAcrossGreatDoor || movingSouthAcrossGreatDoor) && !iAmOnBottomLevel && GreatDoorBroken)) && !Me.TransportGuid.IsValid)
            {
                // use the ropes to get down
                if (iAmSouthOfGreatDoor)
                {
                    var ropeLoc = _ropeLocations.Peek();

                    if (myLoc.Distance(ropeLoc) > 20 && _ropeUseCounter > 0)
                        _ropeUseCounter = 0;

                    if (myLoc.Distance(ropeLoc) > 4)
                        return (await CommonCoroutines.MoveTo(ropeLoc)).IsSuccessful();
                    if (myLoc.DistanceSquared((Vector3)ropeLoc) > 2)
                    {
                        Navigator.PlayerMover.MoveTowards(ropeLoc);
                    }
                    else
                    {
                        if (Me.Mounted)
                            Lua.DoString("if IsMounted() then Dismount() else CancelShapeshiftForm() end");
                        WoWUnit rope = ObjectManager.GetObjectsOfType<WoWUnit>()
                            .Where(u => u.Entry == RopeId)
                            .OrderBy(r => r.Location.DistanceSquared((Vector3)ropeLoc))
                            .FirstOrDefault();
                        if (rope != null && rope.IsValid)
                        {
                            if (_ropeTimer == null)
                            {
                                _ropeTimer = new WaitTimer(TimeSpan.FromMilliseconds(ScriptHelpers.Rnd.Next(10, 6000)));
                                _ropeTimer.Reset();
                            }
                            var otherGroupMemberIsUsingRope =
                                ScriptHelpers.GroupMembers.Any(
                                    g => g.Guid != Me.Guid && g.Player != null && g.Player.TransportGuid.IsValid && g.Player.Transport.Entry == RopeStalkerId);
                            var yieldToOther =
                                ScriptHelpers.GroupMembers.Any(g => g.Guid != Me.Guid && g.Location.Distance(rope.Location) < Me.Location.Distance(rope.Location)) &&
                                !_ropeTimer.IsFinished;
                            if (!otherGroupMemberIsUsingRope && !yieldToOther && _ropeInteractTimer.IsFinished)
                            {
                                if (_ropeUseCounter < 20)
                                {
                                    rope.Interact();
                                    _ropeInteractTimer.Reset();
                                    _ropeUseCounter++;
                                    _ropeTimer = null;
                                }
                                else
                                {
                                    Lua.DoString("LeaveParty()");
                                    Logger.WriteDebug("Ropes are bugged. Leaving group");
                                }
                                _ropeLocations.Dequeue();
                            }
                        }
                    }
                }
                // jump down a hole through floor to get down from north side
                else
                {
                    if (myLoc.Z > 375)
                    {
                        if (myLoc.Distance(_northTopToBottomStepOnePoint) > 15)
                            return (await CommonCoroutines.MoveTo(_northTopToBottomStepOnePoint)).IsSuccessful();
                        Navigator.PlayerMover.MoveTowards(_northTopToBottomStepTwoPoint);
                    }
                    else if (myLoc.Z > 350)
                    {
                        // Only jump doen the ledge if it's not suicide and we have a healer in group.
                        if ((Me.IsHealer || ScriptHelpers.GroupMembers.Any(g => g.IsHealer)) && Me.HealthPercent > 70)
                            Navigator.PlayerMover.MoveTowards(_northTopToBottomLedgePoint);
                        else
                            Navigator.PlayerMover.MoveTowards(_northTopToBottomInsideHallwayPoint);
                    }
                }
                return true;
            }
            // are we at last boss and we want to move to the walls?
            if (movingToTopLevel)
            {
                var artilleryLoc = movingNorthAcrossGreatDoor ? _artilleryNorthLoc : _artillerySouthLoc;
                if (myLoc.Distance(artilleryLoc) > 4)
                    return (await CommonCoroutines.MoveTo(artilleryLoc)).IsSuccessful();
                if (Me.Mounted)
                    Lua.DoString("if IsMounted() then Dismount() else CancelShapeshiftForm() end");
                var artillery = ObjectManager.GetObjectsOfType<WoWUnit>().OrderBy(u => u.DistanceSqr).FirstOrDefault(u => u.Entry == ArtilleryId);
                if (artillery != null)
                    artillery.Interact();
                return true;
            }
            return false;
        }

        #endregion

        private const uint KrikthikInfiltratorId = 56890;
        private const uint KrikthikInfiltrator2Id = 58108;
        private const uint KrikthikWindShaperId = 59801;
        private const uint KrikthikRagerId = 59800;
        private const uint KrikthikDemolisherId = 56875;
        private const uint VolatileMunitionsId = 56896;
        private const uint StableMunitionsId = 56917;
        private const uint LeverId = 211284;
        private const int NorthSouthStrafingRunId = 107342;
        private const int EastWeastStrafingRunId = 107284;
        private const uint StrikerGadokId = 56589;
        private const float StrikerGadokStrafeZ = 432;
        private const uint KrikthikBombardierId = 56706;
        private const int FrenziedAssaultId = 107120;
        private const uint CommanderRimokId = 56636;
        private const uint KrikthikSwarmerId = 59835;
        private const uint RopeId = 64710;
        private const uint ArtilleryId = 66904;
        private const int ImperviousCarapaceId = 107118;
        private const uint RaigonnId = 56877;
        private const uint WeakSpotId = 56895;
        private const int FactionOverrideId = 107132;
        private const uint KrikthikEngulferId = 56912;

        private uint[] _kitedMobs =
        {
            KrikthikInfiltratorId,
            KrikthikInfiltrator2Id,
            KrikthikWindShaperId,
            KrikthikRagerId,
            KrikthikDemolisherId
        };

        private const uint ElevatorId = 211013;
        private readonly Vector3 _artillerySouthLoc = new Vector3(866.2046f, 2225.777f, 311.2762f);

        private readonly uint[] _inCombatMobs = { KrikthikInfiltratorId, KrikthikInfiltrator2Id, KrikthikWindShaperId, KrikthikRagerId, KrikthikDemolisherId };

        private readonly uint[] _mantidMunitionsIds = new uint[] { 56911, 56918, 56919, 56920, 59205, 59206, 59207, 59208 };
        private readonly Vector3 _northTopToBottomStepOnePoint = new Vector3(1096.306f, 2309.375f, 381.5589f);
        private readonly Vector3 _northTopToBottomLedgePoint = new Vector3(1060.086f, 2297.707f, 344.1955f);
        private readonly Vector3 _northTopToBottomInsideHallwayPoint = new Vector3(1092.577f, 2313.916f, 331.0854f);
        private readonly Vector3 _northTopToBottomStepTwoPoint = new Vector3(1081.378f, 2299.337f, 364.1641f);

        private Vector3 _artilleryNorthLoc = new Vector3(1051.559f, 2224.952f, 311.2657f);
        private bool _pickupSwarmers;
        private WaitTimer _wallScalingPackTimer = new WaitTimer(TimeSpan.FromSeconds(10));

        private static LocalPlayer Me
        {
            get { return StyxWoW.Me; }
        }

        #region Root

        [EncounterHandler(64467, "Bowmistress Li", Mode = CallBehaviorMode.Proximity)]
        public Composite BowmistressLiEncounter()
        {
            return new PrioritySelector(
                new Decorator<WoWUnit>(u => u.HasQuestAvailable(), ScriptHelpers.CreatePickupQuest(64467)),
                new Decorator<WoWUnit>(u => u.HasQuestTurnin(), ScriptHelpers.CreateTurninQuest(64467)));
        }

        [EncounterHandler(0)]
        public Func<WoWUnit, Task<bool>> RootHandler()
        {
            AddAvoidObject(() => Me.GroupInfo.IsInParty, 5, VolatileMunitionsId);
            // AddAvoidObject(() => Me.TransportGuid == 0, 2f, LeverId);
            // run from the Munitations explosions.
            AddAvoidObject(
                () => Me.GroupInfo.IsInParty,
                3,
                u => _mantidMunitionsIds.Contains(u.Entry),
                u =>
                {
                    var start = u.Location;
                    return Me.Location.GetNearestPointOnSegment(start, start.RayCast(WoWMathHelper.NormalizeRadian(u.Rotation), 20));
                });

            return async npc =>
            {
                if (Me.IsFalling)
                    return true;

                if (await HandleSoloSpeedBuff())
                    return true;

                return await FollowerElevatorBehavior() || await ScriptHelpers.RunToTankIfAttacked() ||
                       await ScriptHelpers.CancelCinematicIfPlaying();
            };
        }

        [LocationHandler(830.1323f, 2312.181f, 381.2352f, 20, "Wait For wall scaling pack")]
        public Composite WaitForWallScalingPack()
        {
            return new PrioritySelector(
                new Decorator(
                    ctx => _wallScalingPackTimer == null,
                    new Action(
                        ctx =>
                        {
                            _wallScalingPackTimer = new WaitTimer(TimeSpan.FromSeconds(10));
                            _wallScalingPackTimer.Reset();
                        })),
                new Decorator(
                    ctx => Me.GroupInfo.IsInParty && !_wallScalingPackTimer.IsFinished && Me.IsTank() && Targeting.Instance.IsEmpty(),
                    new PrioritySelector(
                        new Decorator(ctx => Me.IsMoving, new Action(ctx => WoWMovement.MoveStop())),
                        new ActionAlwaysSucceed())));
        }

        [ObjectHandler(211129, "Signal Flame", ObjectRange = 250)]
        public async Task<bool> SignalFlameHandler(WoWGameObject flame)
        {
            if (flame.State != WoWGameObjectState.Active || !flame.CanUse())
                return false;
            // The following bosses are dead when the flame can be interacted with
            // so if the following bosses are listed as alive we should mark them as 'dead'.
            // Normally they are marked as dead after being killed but when coming back from 
            // a DC the bot forgets the list of killed bosses.
            if (ScriptHelpers.IsBossAlive("Saboteur Kip'tilak"))
                ScriptHelpers.MarkBossAsDead("Saboteur Kip'tilak");

            if (ScriptHelpers.IsBossAlive("Striker Ga'dok"))
                ScriptHelpers.MarkBossAsDead("Striker Ga'dok");

            // Tell the leader (tank if in a LFG, otherwise person with tank spec or highest HP in group if farming) to
            // go interact with the flame. 
            if (Me.IsLeader())
                ScriptHelpers.SetInteractPoi(flame);
            return false;
        }

        [LocationHandler(1087.696, 2311.945, 354.5028, 15)]
        public Func<Vector3, Task<bool>> HandleStuckAtBrokenWallSection()
        {
            return async loc =>
            {
                if (Me.IsFalling || Me.Z > 358 || Me.Z < 350)
                    return false;

                var moveTo = new Vector3(1090.066f, 2311.466f, 331.6075f);
                WoWMovement.ClickToMove(moveTo);
                return true;
            };
        }

        private async Task<bool> HandleSoloSpeedBuff()
        {
            if (Me.Mounted || !Me.IsMoving || Me.Location.DistanceSquared((Vector3)_destination) <= 50 * 50)
                return false;

            switch (Me.Class)
            {
                case WoWClass.Shaman:
                    if (Me.HasAura("Ghost Wolf"))
                        return false;
                    SpellManager.Cast("Ghost Wolf");
                    return true;
            }
            return false;
        }

        #endregion


        #region Saboteur Kip'tilak

        private Vector3 _kiptilakLeftDoorEdge = new Vector3(719.3694f, 2277.764f, 388.5826f);
        private Vector3 _kiptilakRightDoorEdge = new Vector3(724.2429f, 2277.849f, 388.3888f);

        private const uint MobId_SaboteurKiptilak = 56906;

        [EncounterHandler(56906, "Saboteur Kip'tilak", Mode = CallBehaviorMode.Proximity, BossRange = 100)]
        public Func<WoWUnit, Task<bool>> SaboteurKiptilakEncounter()
        {
            AddAvoidObject(
                () => Me.GroupInfo.IsInParty && Me.RaidMembers.Any(u => u.HasAura("Sabotage")),
                8,
                u =>
                    u.Entry == StableMunitionsId &&
                    Me.RaidMembers.Any(
                        p =>
                            p.HasAura("Sabotage") && (Math.Abs(u.X - p.X) < 4 || Math.Abs(u.Y - p.Y) < 4) &&
                            u.Location.Distance(p.Location) < 20));
            AddAvoidObject(() => true, 8, u => u is WoWPlayer && u != Me && u.ToPlayer().HasAura("Sabotage"));
            // run away from any stable munitions that are aligned north/south or east/west with a group member with Sabotage debuf.
            AddAvoidObject(() => Me.HasAura("Sabotage"), 8, u => u is WoWPlayer && u != Me);

            var randomPointInsideDoor = WoWMathHelper.GetRandomPointInCircle(new Vector3(721.9365f, 2282.52f, 387.9936f), 1.5f);

            return async boss => await ScriptHelpers.MoveInsideBossRoom(boss, _kiptilakLeftDoorEdge, _kiptilakRightDoorEdge, randomPointInsideDoor);
        }

        private bool InsideKiptilakRoom
        {
            get { return Me.Location.IsPointLeftOfLine(_kiptilakLeftDoorEdge, _kiptilakRightDoorEdge); }
        }

        #endregion

        #region Striker Ga'dok

        [EncounterHandler(56589, "Striker Ga'dok", BossRange = 300)]
        public Func<WoWUnit, Task<bool>> StrikerGadokEncounter()
        {
            var eastPoint = new Vector3(1195.388f, 2275.083f, 430.8744f);
            var southPoint = new Vector3(1166.775f, 2304.836f, 430.874f);
            var westPoint = new Vector3(1194.746f, 2333.279f, 430.874f);
            var northPoint = new Vector3(1223.854f, 2304.638f, 430.874f);

            const uint acidBombId = 59813;

            AddAvoidLocation(
                () => true,
                5,
                m => ((WoWMissile)m).ImpactPosition,
                () => WoWMissile.InFlightMissiles.Where(m => m.SpellId == acidBombId));
            AddAvoidObject(() => true, 5, acidBombId);


            Func<WoWUnit, Vector3> getNearestAvoidStrafePoint = boss =>
            {
                var leader = ScriptHelpers.Tank;
                var myLoc = leader != null && leader != Me
                    ? leader.Location
                    : Me.Location;
                var bossLoc = boss.Location;

                var bossToNorthSouthLineDistanceSqr =
                    bossLoc.GetNearestPointOnLine(northPoint, southPoint).DistanceSquared((Vector3)bossLoc);
                var bossToEastWestLineDistanceSqr =
                    bossLoc.GetNearestPointOnLine(eastPoint, westPoint).DistanceSquared((Vector3)bossLoc);

                if (bossToEastWestLineDistanceSqr <
                    bossToNorthSouthLineDistanceSqr)
                {
                    TreeRoot.StatusText = "Avoiding East/West Strafing run";
                    return myLoc.DistanceSquared((Vector3)northPoint) <
                        myLoc.DistanceSquared((Vector3)southPoint)
                        ? northPoint
                        : southPoint;
                }
                TreeRoot.StatusText = "Avoiding North/South Strafing run";
                return myLoc.DistanceSquared((Vector3)eastPoint) <
                    myLoc.DistanceSquared((Vector3)westPoint)
                    ? eastPoint
                    : westPoint;
            };

            var shouldHandleStrafe =
                new Func<WoWUnit, bool>(
                    unit => (Me.Level < 95 || Me.IsMelee())
                        && ScriptHelpers.IsViable(unit) && unit.Z > StrikerGadokStrafeZ &&
                        (Me.IsTank() && Targeting.Instance.TargetList.All(t => t.IsTargetingMeOrPet) || !Me.IsTank()));

            return async boss =>
            {
                // strafe run.
                if (shouldHandleStrafe(boss))
                {
                    return await ScriptHelpers.StayAtLocationWhile(
                            () => shouldHandleStrafe(boss),
                            getNearestAvoidStrafePoint(boss),
                            precision: 10);
                }

                if (Targeting.Instance.IsEmpty() && Me.IsTank())
                    return true;
                return false;
            };
        }


        [EncounterHandler(60415, "Flak Cannon", Mode = CallBehaviorMode.Proximity, BossRange = 100)]
        public Func<WoWUnit, Task<bool>> FlakCannonHandler()
        {
            const int lootSparkleId = 92406;
            return async cannon =>
            {
                return cannon.HasAura(lootSparkleId)
                       &&
                       ObjectManager.GetObjectsOfType<WoWUnit>().Any(u => u.Entry == KrikthikBombardierId && u.IsAlive)
                       && await ScriptHelpers.InteractWithObject(cannon, ignoreCombat: true);
            };
        }

        #endregion

        #region Commander Ri'mok

        [EncounterHandler(56636, "Commander Ri'mok")]
        public Composite CommanderRimokEncounter()
        {
            const uint viscosFluidStalkerId = 56883;
            const int frenziedAssaultId = 107120;
            var kiteCenterLoc = new Vector3(1297.094f, 2301.952f, 388.9373f);
            WoWUnit boss = null;
            Vector3 tankStepOutOfMeleeRangePoint = Vector3.Zero;

            AddAvoidObject(
                () => StyxWoW.Me.IsTank() && !_pickupSwarmers && boss != null && boss.IsValid && boss.CurrentTargetGuid == Me.Guid,
                () => kiteCenterLoc,
                46,
                17,
                u =>
                    u.Entry == viscosFluidStalkerId && boss != null && boss.IsValid && boss.Location.DistanceSquared((Vector3)u.Location) < 4 &&
                    boss.HasAura("Viscous Fluid") &&
                    boss.Auras["Viscous Fluid"].StackCount >= 3);

            AddAvoidObject(() => Me.IsRangeDps() && Me.Level < 95, 7, viscosFluidStalkerId);

            // ranged should stay away from the boss to avoid the frenzy attack.. 
            // note I'm making avoid radius higher while moving so range don't take tiny baby steps everytime boss moves a little whenever standing just outside the avoidance radius
            AddAvoidObject(() => Me.IsRange() && Me.Level < 95, o => Me.IsMoving ? 14 : 12, o => o.Entry == CommanderRimokId && o.ToUnit().IsAlive);


            return new PrioritySelector(
                ctx =>
                {
                    _pickupSwarmers =
                        ObjectManager.GetObjectsOfType<WoWUnit>().Count(u => u.Combat && u != boss && u.IsTargetingMyPartyMember) >= 5;
                    return boss = ctx as WoWUnit;
                },
                new Decorator(
                    ctx => Me.IsTank() && boss.CastingSpellId == frenziedAssaultId && Me.Level < 95,
                    new PrioritySelector(
                        // back away from boss so he kills the adds with his frontal attack.
                        new Decorator(
                            ctx => (tankStepOutOfMeleeRangePoint = GetPointInFrontOfUnitAndOusideMeleeRange(boss, 1)) != Vector3.Zero,
                            new PrioritySelector(
                                new Decorator(
                                    ctx => Navigator.AtLocation(tankStepOutOfMeleeRangePoint),
                                    new Action(ctx => Navigator.PlayerMover.MoveTowards(tankStepOutOfMeleeRangePoint))),
                                new Action(ctx => Navigator.GetRunStatusFromMoveResult(Navigator.MoveTo(tankStepOutOfMeleeRangePoint))))),
                        // bot can't move to the front we just sidestep.
                        ScriptHelpers.CreateAvoidUnitAnglesBehavior(
                            ctx => tankStepOutOfMeleeRangePoint == Vector3.Zero && boss.Distance < 12,
                            ctx => boss,
                            new ScriptHelpers.AngleSpan(0, 180)))),
                ScriptHelpers.CreateAvoidUnitAnglesBehavior(
                    ctx => Me.IsMeleeDps() && boss.Distance < 12 && boss.CurrentTargetGuid != Me.Guid,
                    ctx => boss,
                    new ScriptHelpers.AngleSpan(0, 180)));
        }

        private Vector3 GetPointInFrontOfUnitAndOusideMeleeRange(WoWUnit unit, float distancePastMeleeRange)
        {
            var facing = WoWMathHelper.NormalizeRadian(unit.Rotation);
            var point = unit.Location.RayCast(facing, 12 + distancePastMeleeRange);
            // set the Z coord to mesh level.
            return point;
#warning FIXME DB: GotSS: GetPointInFrontOfUnitAndOutsideMeleeRange
            // TODO: DB: GotSS: GetPointInFrontOfUnitAndOutsideMeleeRange
            // Use mesh sampling
            //            var zList = Navigator.FindHeights(point.X, point.Y);
            //            if (zList != null && zList.Count > 0)
            //            {
            //                point.Z = zList.OrderBy(z => Math.Abs(z - point.Z)).FirstOrDefault();
            //                if (Navigator.CanNavigateFully(Me.Location, point))
            //                    return point;
            //            }
            //            return Vector3.Zero;
        }

        #endregion

        #region Raigonn

        private const float RightSeatCorrectFacing = 0.8418016f;
        private const float LeftSeatCorrectFacing = 2.11022f;

        private const float WeakSpotFacingErrorAmount = 3f;
        private readonly Vector3 _rightSeatLoc = new Vector3(1.5f, -3f, 0.25f);
        private readonly Vector3 _leftSeatLoc = new Vector3(1.5f, 3f, 0.25f);
        private Vector3 _raigonnDropLocation = new Vector3(1098.698f, 2305.023f, 381.2352f);
        private const uint MobId_Raigonn = 56877;

        [EncounterHandler((int)MobId_Raigonn, "Raigonn", BossRange = 200)]
        public Func<WoWUnit, Task<bool>> RaigonnEncounter()
        {
            var capabilityHandle = CapabilityManager.Instance.CreateNewHandle();
            var isMovingTimer = new WaitTimer(TimeSpan.FromSeconds(1));
            const uint artilleryId = 59819;
            const uint engulfingWindsId = 56928;
            const int vulnerabilityId = 111682;

            var roomCenterLoc = new Vector3(956.2532f, 2275.753f, 296.1056f);
            var gateLoc = new Vector3(959.0933f, 2227.044f, 296.1056f);

            AddAvoidObject(() => Me.GroupInfo.IsInParty && Me.HasAura("Fixate"), () => roomCenterLoc, 80, 40, RaigonnId);
            AddAvoidObject(() => Me.GroupInfo.IsInParty && !Me.TransportGuid.IsValid,
                o =>
                {
                    if (Me.IsMoving)
                        isMovingTimer.Reset();
                    return Me.IsRange() && !isMovingTimer.IsFinished ? 10 : 5;
                }, engulfingWindsId);

            return async boss =>
            {
                CapabilityManager.Instance.Update(capabilityHandle, CapabilityFlags.Facing, () => Me.HasAura(FactionOverrideId));

                var shouldAttackWeakSpot = boss.HasAura("Impervious Carapace") && (Me.IsDps || !Me.GroupInfo.IsInParty)
                    && Me.TransportGuid != boss.Guid && Me.PartyMembers.Count(p => p.TransportGuid == boss.Guid) < 2
                    && (boss.Location.DistanceSquared((Vector3)gateLoc) <= 50 * 50 || Targeting.Instance.IsEmpty())
                    && ObjectManager.GetObjectsOfType<WoWUnit>().Any(u => u.Entry == WeakSpotId && u.HasAura(vulnerabilityId));

                if (shouldAttackWeakSpot)
                {
                    var artillery = ObjectManager.GetObjectsOfType<WoWUnit>()
                        .Where(u => u.Entry == artilleryId)
                        .OrderBy(u => u.DistanceSqr)
                        // skip artillery that have tornados nearby
                        .FirstOrDefault(u => !ObjectManager.GetObjectsOfType<WoWUnit>()
                            .Any(w => w.Entry == engulfingWindsId && u.Location.DistanceSquared((Vector3)w.Location) < 12 * 12));
                    if (artillery != null)
                    {
                        if (Me.Mounted && artillery.WithinInteractRange)
                            await CommonCoroutines.Dismount();

                        return await ScriptHelpers.InteractWithObject(artillery, 0, true);
                    }
                }

                // if stuck in an artillery then exit 
                if (Me.TransportGuid.IsValid && Me.Transport.Entry == artilleryId)
                {
                    Lua.DoString("VehicleExit()");
                    return true;
                }

                if (await ScriptHelpers.DispelGroup("Screeching Swarm", ScriptHelpers.PartyDispelType.Magic))
                    return true;

                // make sure we're facing the weak spot.
                var currentTarget = Me.CurrentTarget;
                // WoW does not face in the correct direction when the WoWUnit.Face() command is issued so 
                // the following is a hackish fix.
                if (currentTarget != null && currentTarget.Entry == WeakSpotId && !Me.IsSafelyFacing(currentTarget, 60))
                {
                    Logging.Write("Facing the WeakSpot");
                    await FaceWeakSpot(currentTarget);
                }

                return false;
            };
        }

        // hackish method of getting bot to face weakspot 
        private async Task FaceWeakSpot(WoWUnit weakSpot)
        {
            var rotationStep = Math.PI / 4;

            var targetLoc = weakSpot.Location;
            var myLoc = Me.Location;
            // rotation in radians clamped at (-PI, PI)
            var targetRotation = (float)Math.Atan2(targetLoc.Y - myLoc.Y, targetLoc.X - myLoc.X);
            WoWMovement.MovementDirection moveDir = WoWMovement.MovementDirection.None;
            try
            {
                while (weakSpot.IsValid && Me.HasAura(FactionOverrideId))
                {
                    // Me.Rotation returns (-PI, PI)
                    var myRotation = Me.Rotation;
                    var angleDiff = targetRotation - myRotation;

                    if (Math.Abs(angleDiff) <= WoWMathHelper.DegreesToRadians(30))
                        break;

                    if (moveDir != WoWMovement.MovementDirection.None)
                    {
                        WoWMovement.MoveStop(moveDir);
                        await Coroutine.Sleep(100);
                    }
                    moveDir = angleDiff > 0 ? WoWMovement.MovementDirection.TurnLeft : WoWMovement.MovementDirection.TurnRight;
                    var needToMove = moveDir == WoWMovement.MovementDirection.TurnLeft ? !Me.MovementInfo.MovingTurnLeft : !Me.MovementInfo.MovingTurnRight;
                    if (needToMove)
                    {
                        WoWMovement.Move(moveDir);
                        await Coroutine.Sleep(100);
                    }
                }
            }
            finally
            {
                if (moveDir != WoWMovement.MovementDirection.None)
                    WoWMovement.MoveStop(moveDir);
            }
        }

        #endregion

        #region Elevator

        private async Task<bool> FollowerElevatorBehavior()
        {
            if (Me.IsTank())
                return false;

            var tankI = StyxWoW.Me.GroupInfo.RaidMembers.FirstOrDefault(p => p.HasRole(WoWPartyMember.GroupRole.Tank));
            if (tankI != null)
            {
                var tank = tankI.ToPlayer();
                var myFloorLevel = FloorLevel(Me.Location);
                var tankLoc = tank != null ? tank.Location : tankI.Location3D;
                var tankLevel = FloorLevel(tankLoc);
                var elevatorRestingZ = myFloorLevel == 1 ? ElevatorBottomZ : ElevatorTopZ;
                var elevatorBoardLoc = myFloorLevel == 2 ? _elevatorTopBoardLoc : _elevatorBottomBoardLoc;
                var elevatorWaitLoc = myFloorLevel == 2 ? _elevatorTopWaitLoc : _elevatorBottomWaitLoc;

                // do we need to get on a lift?
                if (IsOnLift(tank) && (!IsOnLift(Me) || Me.Location.DistanceSquared((Vector3)elevatorBoardLoc) > 3 * 3) && tankLevel == myFloorLevel)
                {
                    var ele = ObjectManager.GetObjectsOfType<WoWGameObject>().FirstOrDefault(g => g.Entry == ElevatorId);
                    bool elevatorIsReadyToBoard = ele != null && Math.Abs(ele.Z - elevatorRestingZ) <= 0.5f;
                    if (elevatorIsReadyToBoard)
                    {
                        if (Me.Location.DistanceSquared((Vector3)elevatorBoardLoc) > 3 * 3)
                        {
                            Logger.Write("[Elevator Manager] Boarding Elevator");
                            Navigator.MoveTo(elevatorBoardLoc);
                        }
                        else
                        {
                            Logger.Write("[Elevator Manager] Jumping");
                            WoWMovement.Move(WoWMovement.MovementDirection.JumpAscend);
                            WoWMovement.MoveStop(WoWMovement.MovementDirection.JumpAscend);
                        }
                    }
                    return true;
                }

                // do we need to get off lift?
                if (IsOnLift(Me))
                {
                    var ele = ObjectManager.GetObjectsOfType<WoWGameObject>().FirstOrDefault(g => g.Entry == ElevatorId);
                    bool elevatorInUse = ele != null && Math.Abs(ele.Z - ElevatorBottomZ) > 0.5 && Math.Abs(ele.Z - ElevatorTopZ) > 0.5;
                    if (elevatorInUse)
                        return true;
                }
            }
            return false;
        }

        public async Task<bool> ElevatorBehavior(Vector3 destination)
        {
            if (AvoidanceManager.IsRunningOutOfAvoid)
                return false;
            var myloc = StyxWoW.Me.Location;

            var myFloorLevel = FloorLevel(myloc);
            var destinationFloorLevel = FloorLevel(destination);

            if (myFloorLevel != destinationFloorLevel)
            {
                var ele = ObjectManager.GetObjectsOfType<WoWGameObject>().FirstOrDefault(g => g.Entry == ElevatorId);

                var elevatorRestingZ = myFloorLevel == 1 ? ElevatorBottomZ : ElevatorTopZ;
                var elevatorBoardLoc = destinationFloorLevel == 1 ? _elevatorTopBoardLoc : _elevatorBottomBoardLoc;
                var elevatorWaitLoc = destinationFloorLevel == 1 ? _elevatorTopWaitLoc : _elevatorBottomWaitLoc;
                var lever = ObjectManager.GetObjectsOfType<WoWGameObject>().Where(o => o.Entry == 211284).OrderBy(o => o.DistanceSqr).FirstOrDefault();
                bool elevatorIsReadyToBoard = ele != null && Math.Abs(ele.Z - elevatorRestingZ) <= 0.5f;
                bool elevatorInUse = ele != null && Math.Abs(ele.Z - ElevatorBottomZ) > 0.5 && Math.Abs(ele.Z - ElevatorTopZ) > 0.5;

                // do nothing when taking elevator up/down.
                if (ele != null && Me.TransportGuid == ele.Guid && elevatorInUse)
                    return true;

                // move to the lever loc
                if ((ele == null || (myloc.DistanceSquared((Vector3)elevatorBoardLoc) > 20 * 20 || !elevatorIsReadyToBoard && myloc.DistanceSquared((Vector3)elevatorWaitLoc) > 4 * 4)) &&
                    !Me.TransportGuid.IsValid)
                {
                    Logger.Write("[Elevator Manager] Moving To Elevator");
                    var moveResult = Navigator.MoveTo(elevatorWaitLoc);
                    return moveResult != MoveResult.Failed && moveResult != MoveResult.PathGenerationFailed;
                }
                // use lever to bring elevator to our floor level.
                if (!elevatorIsReadyToBoard && !elevatorInUse && myloc.DistanceSquared((Vector3)elevatorWaitLoc) <= 20 * 20 && !Me.TransportGuid.IsValid && lever != null && lever.CanUse())
                {
                    if (myloc.DistanceSquared((Vector3)elevatorWaitLoc) > 3 * 3)
                    {
                        Navigator.MoveTo(elevatorWaitLoc);
                        return true;
                    }
                    Logger.Write("[Elevator Manager] Bringing Elevator to my level");
                    lever.Interact();
                }
                // get onboard of elevator.
                if (elevatorIsReadyToBoard && myloc.DistanceSquared((Vector3)elevatorBoardLoc) > 2 * 2 && !Me.TransportGuid.IsValid)
                {
                    Logger.Write("[Elevator Manager] Boarding Elevator");
                    // avoid getting stuck on lever
                    Navigator.MoveTo(elevatorBoardLoc);
                }
                else if (elevatorIsReadyToBoard && myloc.DistanceSquared((Vector3)elevatorBoardLoc) <= 2 * 2 && !Me.TransportGuid.IsValid)
                {
                    Logger.Write("[Elevator Manager] Jumping");
                    WoWMovement.Move(WoWMovement.MovementDirection.JumpAscend);
                    WoWMovement.MoveStop(WoWMovement.MovementDirection.JumpAscend);
                }

                if (elevatorIsReadyToBoard && Me.TransportGuid == ele.Guid
                    && Me.RaidMembers.Where(r => FloorLevel(r.Location) == myFloorLevel).All(r => r.TransportGuid == ele.Guid)
                    && lever != null && lever.CanUse())
                {
                    if (!lever.CanUseNow())
                        return (await CommonCoroutines.MoveTo(WoWMathHelper.CalculatePointFrom(Me.Location, lever.Location, lever.InteractRange - 1))).IsSuccessful();

                    if (Me.IsMoving && myloc.DistanceSquared((Vector3)elevatorBoardLoc) <= 3 * 3)
                        return await CommonCoroutines.StopMoving();

                    Logger.Write("[Elevator Manager] Using Lever");
                    lever.Interact();
                }
                return true;
            }

            // exit elevator
            var transport = Me.TransportGuid.IsValid ? Me.Transport : null;
            if (transport != null && transport.Entry == ElevatorId)
            {
                var elevatorExitZ = destinationFloorLevel == 1 ? ElevatorBottomZ : ElevatorTopZ;
                var elevatorExitLoc = destinationFloorLevel == 1 ? _elevatorBottomWaitLoc : _elevatorTopWaitLoc;
                bool elevatorIsReadyToExit = Math.Abs(transport.Z - elevatorExitZ) <= 0.5f;

                if (elevatorIsReadyToExit)
                {
#warning FIXME Dungeonbuddy - GotSS: CanNavigateFully when exiting elevator
                    // TODO: Dungeonbuddy - GotSS: CanNavigateFully when exiting elevator
                    // Clean solution would be to add this as a jump link in meshes
                    // and allow DB to override jump link handling for this.
                    //                    if (Navigator.CanNavigateFully(myloc, destination))
                    Navigator.MoveTo(destination);
                    //                    else
                    //                        Navigator.MoveTo(elevatorExitLoc);
                }
                return true;
            }

            return false;
        }


        private bool IsOnLift(WoWPlayer player)
        {
            return player != null && player.TransportGuid.IsValid && player.Transport.Entry == ElevatorId;
        }

        private int FloorLevel(Vector3 loc)
        {
            return loc.Z > 425 && loc.DistanceSquared(_gadokRoomLoc) <= 75 * 75 ? 2 : 1;
        }

        #endregion
    }

    #endregion

    #region Heroic Difficulty

    public class GateOfTheSettingSunHeroic : GateOfTheSettingSun
    {
        #region Overrides of Dungeon

        public override uint DungeonId
        {
            get { return 471; }
        }

        #endregion
    }

    #endregion
}