﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using CommonBehaviors.Actions;
using Styx;
using Styx.CommonBot;
using Styx.Pathing;
using Styx.WoWInternals.WoWObjects;
using Styx.TreeSharp;

using Bots.DungeonBuddy.Attributes;
using Bots.DungeonBuddy.Helpers;
using Styx.Common;
using Styx.Helpers;

namespace Bots.DungeonBuddy.Dungeon_Scripts.Classic
{
    public class DireMaulGordokCommons : Dungeon
    {
        #region Overrides of Dungeon

        public override uint DungeonId
        {
            get { return 38; }
        }

        public override Vector3 Entrance
        {
            get { return new Vector3(-3520.225f, 1094.745f, 161.0336f); }
        }

        public override Vector3 ExitLocation
        {
            get { return new Vector3(255.0915f, -12.56872f, -2.564304f); }
        }

        public override void WeighTargetsFilter(List<Targeting.TargetPriority> units)
        {
            foreach (var p in units)
            {
                var unit = p.Object.ToUnit();
                if ((unit.Entry == CaptainKromcrushId || unit.Entry == GordokMageLordId) && Me.IsDps)
                    p.Score += 1000;
            }
        }

        public override void RemoveTargetsFilter(List<WoWObject> units)
        {
            units.RemoveAll(
                o =>
                {
                    WoWUnit unit = o.ToUnit();
                    if (unit != null)
                    {
                        if (unit.Entry == CaptainKromcrushId && unit.HasAura("Retaliation") && Me.IsMelee())
                            return true;
                    }
                    return false;
                });
        }

        public override void IncludeTargetsFilter(List<WoWObject> incomingunits, HashSet<WoWObject> outgoingunits)
        {
            foreach (var unit in outgoingunits.Select(u => u.ToUnit()))
            {
                if (unit.Entry == WanderingEyeofKilroggId && (Me.IsTank() || unit.Combat))
                {
                    outgoingunits.Add(unit);
                }
            }
        }

        private List<DynamicBlackspot> _dynamicBlackspots;
        public override void OnEnter()
        {
            if (Me.IsFollower())
            {
                _dynamicBlackspots = GetEntranceTrashBlackspots().ToList();
                DynamicBlackspotManager.AddBlackspots(_dynamicBlackspots);
            }
        }

        public override void OnExit()
        {
            if (_dynamicBlackspots != null)
            {
                DynamicBlackspotManager.RemoveBlackspots(_dynamicBlackspots);
                _dynamicBlackspots = null;
            }
        }

        private static readonly Vector3 s_leftEntranceTrashLoc = new Vector3(298.3713f, 38.06606f, -3.957795f);
        private static readonly Vector3 s_rightEntranceTrashLoc = new Vector3(354.2512f, -108.8843f, -3.886184f);
        private static readonly Vector3 s_rightArchTrashLoc = new Vector3(445.1893f, 143.155f, -0.07393706f);
        private static readonly Vector3 s_centerArchTrashLoc = new Vector3(445.1893f, 143.155f, -0.07393706f);
        private static readonly Vector3 s_leftArchTrashLoc = new Vector3(445.1893f, 143.155f, -0.07393706f);
        private static readonly Vector3 s_moldarTrashLoc = new Vector3(358.8067f, 4.972275f, -24.7655f);

        private static readonly TimeCachedValue<bool> s_shouldAvoidRightEntranceSide = new TimeCachedValue<bool>(
            TimeSpan.FromSeconds(5),
            () => ScriptHelpers.GetUnfriendlyNpsAtLocation(
                s_rightEntranceTrashLoc,
                20,
                unit => unit.IsHostile && Math.Abs(unit.Z - s_rightEntranceTrashLoc.Z) < 8).Any());

        private static readonly TimeCachedValue<bool> s_shouldAvoidLeftEntranceSide = new TimeCachedValue<bool>(
            TimeSpan.FromSeconds(5),
            () => ScriptHelpers.GetUnfriendlyNpsAtLocation(
                s_leftEntranceTrashLoc,
                20,
                unit => unit.IsHostile && Math.Abs(unit.Z - s_rightEntranceTrashLoc.Z) < 8).Any());

        private static readonly TimeCachedValue<bool> s_shouldAvoidRightArch = new TimeCachedValue<bool>(
            TimeSpan.FromSeconds(5),
            () => ScriptHelpers.GetUnfriendlyNpsAtLocation(
                s_leftEntranceTrashLoc,
                10,
                unit => unit.IsHostile && Math.Abs(unit.Z - s_rightArchTrashLoc.Z) < 8).Any());

        private static readonly TimeCachedValue<bool> s_shouldAvoidCenterArch = new TimeCachedValue<bool>(
            TimeSpan.FromSeconds(5),
            () => ScriptHelpers.GetUnfriendlyNpsAtLocation(
                s_leftEntranceTrashLoc,
                10,
                unit => unit.IsHostile && Math.Abs(unit.Z - s_centerArchTrashLoc.Z) < 8).Any());

        private static readonly TimeCachedValue<bool> s_shouldAvoidLeftArch = new TimeCachedValue<bool>(
            TimeSpan.FromSeconds(5),
            () => ScriptHelpers.GetUnfriendlyNpsAtLocation(
                s_leftEntranceTrashLoc,
                10,
                unit => unit.IsHostile && Math.Abs(unit.Z - s_leftArchTrashLoc.Z) < 8).Any());

        private static readonly TimeCachedValue<bool> s_shouldAvoidMoldarTrash = new TimeCachedValue<bool>(
            TimeSpan.FromSeconds(5),
            () => ScriptHelpers.GetUnfriendlyNpsAtLocation(
                s_leftEntranceTrashLoc,
                10,
                unit => unit.IsHostile && Math.Abs(unit.Z - s_leftArchTrashLoc.Z) < 8).Any());

        private IEnumerable<DynamicBlackspot> GetEntranceTrashBlackspots()
        {
            yield return new DynamicBlackspot(
                () => s_shouldAvoidRightEntranceSide,
                () => s_rightEntranceTrashLoc,
                LfgDungeon.MapId,
                30,
                10,
                "Right Entrance Trash group");

            yield return new DynamicBlackspot(
                () => s_shouldAvoidLeftEntranceSide,
                () => s_leftEntranceTrashLoc,
                LfgDungeon.MapId,
                30,
                10,
                "Left Entrance Trash group");

            yield return new DynamicBlackspot(
                () => s_shouldAvoidRightArch,
                () => s_rightArchTrashLoc,
                LfgDungeon.MapId,
                15,
                10,
                "Right Arch Trash group");

            yield return new DynamicBlackspot(
                () => s_shouldAvoidCenterArch,
                () => s_centerArchTrashLoc,
                LfgDungeon.MapId,
                15,
                10,
                "Center Arch Trash group");

            yield return new DynamicBlackspot(
                () => s_shouldAvoidLeftArch,
                () => s_leftArchTrashLoc,
                LfgDungeon.MapId,
                15,
                10,
                "Left Arch Trash group");

            yield return new DynamicBlackspot(
                () => s_shouldAvoidMoldarTrash,
                () => s_moldarTrashLoc,
                LfgDungeon.MapId,
                30,
                20,
                "Moldar Trash group");
        }

        #endregion

        private LocalPlayer Me
        {
            get { return StyxWoW.Me; }
        }

        #region Root

        private const uint GordokMageLordId = 11444;
        private const uint GordokReaverId = 11450;
        private const uint WanderingEyeofKilroggId = 14386;
        [EncounterHandler(45052, "Stonemaul Ogre", Mode = CallBehaviorMode.Proximity, BossRange = 30)]
        public Composite QuestPickupHandler()
        {
            WoWUnit unit = null;
            return new PrioritySelector(
                ctx => unit = ctx as WoWUnit,
                new Decorator(
                    ctx => !Me.Combat && !ScriptHelpers.WillPullAggroAtLocation(unit.Location) && unit.QuestGiverStatus == QuestGiverStatus.Available,
                    ScriptHelpers.CreatePickupQuest(ctx => unit)),
                new Decorator(
                    ctx => !Me.Combat && !ScriptHelpers.WillPullAggroAtLocation(unit.Location) && unit.QuestGiverStatus == QuestGiverStatus.TurnIn,
                    ScriptHelpers.CreateTurninQuest(ctx => unit)));
        }

        #endregion

        [EncounterHandler(14325, "Stomper Kreeg")]
        public Composite StomperKreegFight()
        {
            WoWUnit boss = null;
            const uint stomperKreegId = 14325;

            AddAvoidObject(() => !Me.IsTank(), 8, o => o.Entry == stomperKreegId && o.ToUnit().HasAura("Whirlwind"));

            return new PrioritySelector(
                ctx => boss = ctx as WoWUnit,
                ScriptHelpers.CreateTankFaceAwayGroupUnit(ctx => boss, 15),
                ScriptHelpers.CreateAvoidUnitAnglesBehavior(ctx => !Me.IsTank() && boss.Distance < 15, ctx => boss, new ScriptHelpers.AngleSpan(0, 180)));
        }

        [EncounterHandler(14323, "Guard Slip'kik", Mode = CallBehaviorMode.Proximity, BossRange = 120)]
        public Composite GuardSlipkikEncounter()
        {
            WoWUnit boss = null;
            var pullToLoc = new Vector3(535.7172f, 542.0845f, -25.40273f);
            var trap = new Vector3(559.7982f, 547.8613f, -25.40069f);
            return new PrioritySelector(
                ctx => boss = ctx as WoWUnit,
                new Decorator(
                    ctx => Me.IsTank(),
                    ScriptHelpers.CreatePullNpcToLocation(ctx => !boss.Combat, ctx => boss.Location.Distance(trap) <= 15, ctx => boss, ctx => pullToLoc, ctx => pullToLoc, 4)),
                new Decorator(ctx => Targeting.Instance.TargetList.All(t => t.CurrentTargetGuid == Me.Guid), ScriptHelpers.CreateTankUnitAtLocation(ctx => pullToLoc, 5)));
        }

        #region Captain Kromcrush

        private const uint CaptainKromcrushId = 14325;

        [EncounterHandler(14325, "Captain Kromcrush")]
        public Composite CaptainKromcrushFight()
        {
            WoWUnit boss = null;
            const uint captainKromcrushId = 14325;
            // range need to stay away to avoid getting feared.
            AddAvoidObject(() => Me.IsRange() && !Me.IsCasting, 8, o => o.Entry == captainKromcrushId && o.ToUnit().CurrentTargetGuid != Me.Guid && o.ToUnit().IsAlive && !o.ToUnit().IsMoving);

            var tankLoc = new Vector3(584.6393f, 481.2674f, 29.4628f);
            return new PrioritySelector(
                ctx => boss = ctx as WoWUnit,
                // avoid gatting cleaved.
                ScriptHelpers.CreateAvoidUnitAnglesBehavior(ctx => !Me.IsTank() && boss.Distance < 8 && !Me.IsCasting && !boss.IsMoving && boss.CurrentTargetGuid != Me.Guid, ctx => boss, new ScriptHelpers.AngleSpan(0, 180)),
                new Decorator(
                    ctx => Me.IsTank() && Targeting.Instance.TargetList.All(t => t.CurrentTargetGuid == Me.Guid), ScriptHelpers.CreateTankUnitAtLocation(ctx => tankLoc, 7)),
                new Decorator(ctx => Me.IsTank() && Targeting.Instance.IsEmpty(), new ActionAlwaysSucceed()));
        }


        [EncounterHandler(11450, "Gordok Reaver")]
        public Composite GordokReaverFight()
        {
            WoWUnit unit = null;
            return new PrioritySelector(
                ctx => unit = ctx as WoWUnit,
                // avoid gatting cleaved.
                ScriptHelpers.CreateAvoidUnitAnglesBehavior(ctx => !Me.IsTank() && unit.Distance < 8 && !Me.IsCasting && !unit.IsMoving && unit.CurrentTargetGuid != Me.Guid, ctx => unit, new ScriptHelpers.AngleSpan(0, 180)));
        }

        #endregion

        #region KingGordok

        [EncounterHandler(11501, "King Gordok")]
        public Composite KingGordokFight()
        {
            const uint kingGordokId = 11501;

            WoWUnit boss = null;
            // range need to stay away to avoid getting stunned.
            AddAvoidObject(() => Me.IsRange(), 5, o => o.Entry == kingGordokId && o.ToUnit().CurrentTargetGuid != Me.Guid);
            return new PrioritySelector(ctx => boss = ctx as WoWUnit, ScriptHelpers.CreateDispelEnemy("Bloodlust", ScriptHelpers.EnemyDispelType.Magic, ctx => boss));
        }


        [EncounterHandler(14324, "ChorushTheObserver")]
        public Composite ChorushTheObserverFight()
        {
            WoWUnit unit = null;
            const int healingWaveId = 15982;
            const int healId = 38209;
            return new PrioritySelector(ctx => unit = ctx as WoWUnit, ScriptHelpers.CreateInterruptCast(ctx => unit, healingWaveId, healId));
        }

        #endregion
    }
}