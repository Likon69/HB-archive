﻿

using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;
using CommonBehaviors.Actions;
using Styx;
using Styx.CommonBot;
using Styx.Pathing;
using Styx.TreeSharp;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;

using Bots.DungeonBuddy.Attributes;
using Bots.DungeonBuddy.Helpers;
using Styx.Common;
using Action = Styx.TreeSharp.Action;

namespace Bots.DungeonBuddy.Dungeon_Scripts.Classic
{
    public class DireMaulWarpwoodQuarter : Dungeon
    {
        #region Overrides of Dungeon

        private readonly JumpLink[] _poolExitJumpLinks = new[]
        {
			// north-east side
			new JumpLink (new Vector3 (-3.108631f, -441.9224f, -59.9572f), new Vector3 (-2.984955f, -443.9251f, -58.62362f)),
			// south-east side
			new JumpLink (new Vector3 (-32.26128f, -442.0283f, -59.95f), new Vector3 (-32.61896f, -444.2151f, -58.61603f)),
			// south-west side
			new JumpLink (new Vector3 (-37.27712f, -411.3893f, -59.94997f), new Vector3 (-37.79222f, -408.4651f, -58.61409f)),
			// noeth-west side
			new JumpLink (new Vector3 (-8.181879f, -411.3037f, -59.94997f),new Vector3 (-7.396617f, -409.3429f, -58.61412f))
        };

        private readonly Vector3 _poolLoc = new Vector3(-14.4789f, -427.714f, -59.95045f);

        public override uint DungeonId
        {
            get { return 34; }
        }

        public override Vector3 Entrance
        {
            get { return new Vector3(-3764.563f, 935.0845f, 161.0271f); }
        }

        public override Vector3 ExitLocation
        {
            get { return new Vector3(41.75133f, -155.5493f, -2.714351f); }
        }


        public override async Task<bool> HandleMovement(Vector3 location)
        {
            // jump out of the pool.
            if (StyxWoW.Me.Location.DistanceSquared(_poolLoc) < 40 * 40)
            {
                if (StyxWoW.Me.Z < -59f && location.Z > -59 && !StyxWoW.Me.MovementInfo.IsAscending)
                {
                    var bestExit = _poolExitJumpLinks.OrderBy(jl => jl.From.DistanceSquared(location)).FirstOrDefault();

                    if (!Navigator.AtLocation(bestExit.From))
                        Navigator.MoveTo(bestExit.From);
                    else
                    {
                        Navigator.PlayerMover.MoveTowards(bestExit.To);
                        WoWMovement.Move(WoWMovement.MovementDirection.JumpAscend);
                        WoWMovement.MoveStop(WoWMovement.MovementDirection.JumpAscend);
                    }
                    return true;
                }
            }
            return false;
        }

        private struct JumpLink
        {
            public JumpLink(Vector3 from, Vector3 to)
            {
                From = from;
                To = to;
            }

            public readonly Vector3 From;
            public readonly Vector3 To;
        }
        #endregion

        private LocalPlayer Me
        {
            get { return StyxWoW.Me; }
        }

        [EncounterHandler(44971, "Ambassador Dagg'thol", Mode = CallBehaviorMode.Proximity)]
        [EncounterHandler(44969, "Furgus Warpwood", Mode = CallBehaviorMode.Proximity)]
        public Composite AmbassadorDaggtholEncounter()
        {
            WoWUnit unit = null;
            return new PrioritySelector(
                ctx => unit = ctx as WoWUnit,
                new Decorator(ctx => !Me.Combat && unit.QuestGiverStatus == QuestGiverStatus.Available, ScriptHelpers.CreatePickupQuest(ctx => unit)),
                new Decorator(ctx => !Me.Combat && unit.QuestGiverStatus == QuestGiverStatus.TurnIn, ScriptHelpers.CreateTurninQuest(ctx => unit)));
        }

        private const uint PimgibId = 14349;
        [EncounterHandler(14327, "Lethtendris")]
        public Composite LethtendrisEncounter()
        {
            const int shadowBoltVolleyId = 14887;
            WoWUnit boss = null;
            return new PrioritySelector(
                ctx => boss = ctx as WoWUnit,
                ScriptHelpers.CreateDispelGroup("Curse of Thorns", ScriptHelpers.PartyDispelType.Curse),
                ScriptHelpers.CreateDispelGroup("Curse of Tongues", ScriptHelpers.PartyDispelType.Curse),
                ScriptHelpers.CreateDispelGroup("Immolate", ScriptHelpers.PartyDispelType.Magic),
                ScriptHelpers.CreateInterruptCast(ctx => boss, shadowBoltVolleyId)
                );
        }

        [EncounterHandler(14349, "Pimgib")]
        public Composite PimgibEncounter()
        {
            WoWUnit boss = null;
            return new PrioritySelector(
                ctx => boss = ctx as WoWUnit,
                ScriptHelpers.CreateDispelEnemy("Enlarge", ScriptHelpers.EnemyDispelType.Magic, ctx => boss));
        }

        [EncounterHandler(14354, "Pusillin", Mode = CallBehaviorMode.Proximity)]
        public Composite PusillinEncounter()
        {
            WoWUnit boss = null;
            return new PrioritySelector(
                ctx => boss = ctx as WoWUnit, new Decorator(ctx => !boss.IsHostile && Me.IsTank() && Targeting.Instance.IsEmpty(), ScriptHelpers.CreateTalkToNpc(ctx => boss)));
        }

        [EncounterHandler(11490, "Zevrim Thornhoof")]
        public Composite ZevrimThornhoofEncounter()
        {
            WoWUnit boss = null;
            return new PrioritySelector(ctx => boss = ctx as WoWUnit);
        }

        [EncounterHandler(11492, "Alzzin the Wildshaper", Mode = CallBehaviorMode.CurrentBoss)]
        public Composite OpenPathTo_AlzzintheWildshaperBehavior()
        {
            // This tree's Entry is changed after you kill the boss before it. However the entry is somehow changed without a new tree spawning, so HB keeps the old cached entry for it.
            // Need to handle both IDs
            var ironbarkTheRedeemedIds = new HashSet<uint> { 11491, 14241 };
            const uint conservatoryDoorId = 176907;
            var ronbarkTheRedeemedLoc = new Vector3(-72.17187f, -283.2524f, -57.83297f);

            WoWGameObject door = null;
            WoWUnit ironbarkTheRedeemed = null;

            return new Decorator(
                ctx => Me.IsTank() && Targeting.Instance.IsEmpty(),
                new PrioritySelector(
                    ctx => door = ObjectManager.GetObjectsOfTypeFast<WoWGameObject>().FirstOrDefault(g => g.Entry == conservatoryDoorId),
                    // talk to Ironbark the Redeemed if door is not open
                    new Decorator(
                        ctx => door == null || door.State == WoWGameObjectState.Ready,
                        new PrioritySelector(
                            ctx =>
                                ironbarkTheRedeemed =
                                    ObjectManager.GetObjectsOfTypeFast<WoWUnit>().FirstOrDefault(u => ironbarkTheRedeemedIds.Contains(u.Entry)),
                            new Decorator(ctx => ironbarkTheRedeemed == null, new Action(ctx => Navigator.MoveTo(ronbarkTheRedeemedLoc))),
                            new Decorator(ctx => ironbarkTheRedeemed.CanGossip, ScriptHelpers.CreateTalkToNpc(ctx => ironbarkTheRedeemed)),
                            // wait at door for it to open
                            new Decorator(
                                ctx => door.DistanceSqr < 10 * 10,
                                new PrioritySelector(
                                    new Decorator(ctx => Me.IsMoving, new Action(ctx => WoWMovement.MoveStop())),
                                    new ActionAlwaysSucceed()))
                            ))
                    ));
        }

        [EncounterHandler(11492, "Alzzin the Wildshaper")]
        public Composite AlzzintheWildshaperEncounter()
        {
            WoWUnit boss = null;
            return new PrioritySelector(ctx => boss = ctx as WoWUnit,
                ScriptHelpers.CreateDispelEnemy("Wild Regneration", ScriptHelpers.EnemyDispelType.Magic, ctx => boss),
                ScriptHelpers.CreateDispelGroup("Enervate", ScriptHelpers.PartyDispelType.Poison),
                ScriptHelpers.CreateDispelGroup("Wither", ScriptHelpers.PartyDispelType.Disease),
                ScriptHelpers.CreateDispelEnemy("Thorns", ScriptHelpers.EnemyDispelType.Magic, ctx => boss));
        }
    }
}