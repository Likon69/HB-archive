﻿using Hera.Helpers;
using Hera.SpellsMan;
using TreeSharp;

namespace Hera
{
    public partial class Fpsware
    {
        // ******************************************************************************************
        // This is where the pull action takes place

        #region Pull
        // _pullBehavior is a class that will hold our logic. 
        private Composite _pullBehavior;
        public override Composite PullBehavior
        {
            get { if (_pullBehavior == null) { Utils.Log("Creating 'Pull' behavior"); _pullBehavior = CreatePullBehavior(); }  return _pullBehavior; }
        }

        private PrioritySelector CreatePullBehavior()
        {
            return new PrioritySelector(

                // All spells are checked in the order listed below, a prioritised order
                // Put the most important spells at the top of the list

                // If we can't reach the target blacklist it.
                new Decorator(ret => Me.GotTarget && !Target.CanGenerateNavPath, new Action(ret => Target.BlackList(1000))),

                // Check if the target is suitable for pulling, if not blacklist it
                new NeedToBlacklistPullTarget(new BlacklistPullTarget()),

                // Check pull timers and blacklist bad pulls where required
                new NeedToCheckPullTimer(new BlacklistPullTarget()),

                // Auto Attack
                new Decorator(ret => !Me.IsAutoAttacking, new Action(ret => Utils.AutoAttack(true))),


                // *******************************************************

                // Charge
                new NeedToCharge(new Charge()),

                // Intercept
                new NeedToIntercept(new Intercept()),

                // Face Target Pull
                new NeedToFaceTargetPull(new FaceTargetPull()),

                // Stance Dance
                new NeedToStanceDance(new StanceDance()),

                // Heroic Throw Pull
                new NeedToHeroicThrowPull(new HeroicThrowPull()),

                // Finally just move to target.
                new Action(ret => Movement.DistanceCheck(ClassHelper.MaximumDistance,1.5))
                );
        }
        #endregion

        #region Pull Timer / Timeout
        public class NeedToCheckPullTimer : Decorator
        {
            public NeedToCheckPullTimer(Composite child) : base(child) { }

            protected override bool CanRun(object context)
            {
                return Target.PullTimerExpired;
            }
        }

        public class CheckPullTimer : Action
        {
            protected override RunStatus Run(object context)
            {
                Utils.Log(string.Format("Unable to pull {0}, blacklisting and finding another target.", Me.CurrentTarget.Name), System.Drawing.Color.FromName("Red"));
                Target.BlackList(1200);
                Me.ClearTarget();

                return RunStatus.Success;
            }
        }
        #endregion

        #region Combat Timer / Timeout
        public class NeedToCheckCombatTimer : Decorator
        {
            public NeedToCheckCombatTimer(Composite child) : base(child) { }

            protected override bool CanRun(object context)
            {
                Debug.Log("NeedToCheckCombatTimer", 1);
                if (!Me.GotTarget || Me.CurrentTarget.Dead) return false;
                if (Target.IsElite) return false;
                

                return Target.CombatTimerExpired && Target.IsHealthAbove(95);
            }
        }

        public class CheckCombatTimer : Action
        {
            protected override RunStatus Run(object context)
            {
                Utils.Log(string.Format("Combat with {0} is bugged, blacklisting and finding another target.", Me.CurrentTarget.Name), System.Drawing.Color.FromName("Red"));
                Target.BlackList(1200);
                Utils.LagSleep();

                return RunStatus.Success;
            }
        }
        #endregion


        // ******************************************************************************************
        // Pull spells are here

        #region Charge
        public class NeedToCharge : Decorator
        {
            public NeedToCharge(Composite child) : base(child) { }

            protected override bool CanRun(object context)
            {
                string spellName = "Charge";
                if (!Me.GotTarget) return false;
                if (!Spell.IsKnown("Charge")) return false;
                if (Spell.IsOnCooldown("Charge")) return false;
                
                //if (!Utils.IsCommonChecksOk(spellName, false)) return false;
                if (!ClassHelper.Stance.IsBattleStance) return false;
                if (Target.IsDistanceLessThan(9)) return false;
                if (Target.IsDistanceMoreThan(30)) return false;

                return (Spell.CanCastLUA(spellName));
            }
        }

        public class Charge : Action
        {
            protected override RunStatus Run(object context)
            {
                Target.Face();
                Utils.LagSleep();

                string spellName = "Charge";
                bool result = Spell.Cast(spellName);
                return result ? RunStatus.Success : RunStatus.Failure;
            }
        }
        #endregion

        #region Intercept
        public class NeedToIntercept: Decorator
        {
            public NeedToIntercept(Composite child) : base(child) { }

            protected override bool CanRun(object context)
            {
                string spellName = "Intercept";
                if (!Utils.IsCommonChecksOk(spellName, false)) return false;
                if (!ClassHelper.Stance.IsBerserkerStance) return false;
                if (Target.IsDistanceLessThan(9)) return false;
                if (Target.IsDistanceMoreThan(24)) return false;

                return (Spell.CanCast(spellName));
            }
        }

        public class Intercept : Action
        {
            protected override RunStatus Run(object context)
            {
                Target.Face();
                Utils.LagSleep();

                string spellName = "Intercept";
                bool result = Spell.Cast(spellName);
                return result ? RunStatus.Success : RunStatus.Failure;
            }
        }
        #endregion

        #region Stance Dance
        public class NeedToStanceDance : Decorator
        {
            public NeedToStanceDance(Composite child) : base(child) { }

            protected override bool CanRun(object context)
            {
                if (!Utils.IsCommonChecksOk("", true)) return false;
                if (ClassHelper.Stance.IsBattleStance) return false;
                if (Spell.IsKnown("Intercept") && !Spell.IsOnCooldown("Intercept") && Self.IsRageAbove(12)) return false;

                return (Spell.CanCast("Battle Stance"));
            }
        }

        public class StanceDance : Action
        {
            protected override RunStatus Run(object context)
            {
                Spell.Cast("Battle Stance");
                Utils.LagSleep();

                bool result = Self.IsBuffOnMe("Battle Stance");
                return result ? RunStatus.Success : RunStatus.Failure;
            }
        }
        #endregion

        #region Face Target Pull

        public class NeedToFaceTargetPull : Decorator
        {
            public NeedToFaceTargetPull(Composite child)
                : base(child)
            {
            }

            protected override bool CanRun(object context)
            {
                if (!Utils.IsCommonChecksOk("", false)) return false;
                if (Me.IsMoving) return false;
                if (Target.IsFacing) return false;
                //if (Me.IsSafelyFacing(Me.CurrentTarget.Location)) return false;

                return true;
            }
        }

        public class FaceTargetPull : Action
        {
            protected override RunStatus Run(object context)
            {
                Target.Face();
                return RunStatus.Failure;
            }
        }

        #endregion

        #region Heroic Throw Pull

        public class NeedToHeroicThrowPull : Decorator
        {
            public NeedToHeroicThrowPull(Composite child) : base(child)
            {
            }

            protected override bool CanRun(object context)
            {
                string SpellName = "Heroic Throw";
                if (!Utils.IsCommonChecksOk(SpellName, false)) return false;
                if (ClassHelper.Stance.IsBattleStance && Spell.IsKnown("Charge") && !Spell.IsOnCooldown("Charge")) return false;
                if (ClassHelper.Stance.IsBerserkerStance && Spell.IsKnown("Intercept") && !Spell.IsOnCooldown("Intercept")) return false;

                return (Spell.CanCast(SpellName));
            }
        }

        public class HeroicThrowPull : Action
        {
            protected override RunStatus Run(object context)
            {
                string SpellName = "Heroic Throw";
                bool result = Spell.Cast(SpellName);
                return result ? RunStatus.Success : RunStatus.Failure;
            }
        }

        #endregion
    
    }
}