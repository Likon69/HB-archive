﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Styx.Combat.CombatRoutine;
using Styx;
using Styx.WoWInternals.WoWObjects;
using Styx.Helpers;
using Styx.Logic.Combat;
using Styx.WoWInternals;
using Tripper.Navigation;
using Styx.Logic;

namespace PrinceOfDarkness
{
    public class PrinceOfDarkness : CombatRoutine
    {
        public override WoWClass Class
        {
            get { return WoWClass.Warlock; }
        }

        public override string Name
        {
            get { return "Prince of Darkness"; }
        }

        /******************************************************************************/

        public static LocalPlayer Me { get { return StyxWoW.Me; } }

        public static void Debug(string msg, params object[] args)
        {
            Logging.WriteDebug(System.Drawing.Color.OrangeRed, msg, args);
        }



        public override bool NeedRest
        {
            get
            {
                if (Me.Mounted)
                    return false;
                if (Me.Dead || Me.IsGhost || Me.Combat)
                    return false;

                if (Me.HealthPercent < 50 || Me.ManaPercent < 60 || (Me.CurrentSoulShards <= 2 && SpellManager.CanCast("Soul Harvest")))
                {
                    Debug("NeedRest is true: life tap, drink or soul harvest");
                    return true;
                }

                // Let the harvest finish. Get our damned health back
                if ((Spells.Locked || Me.IsCasting) && Me.CastingSpellId == Spells.SoulHarvest.Id && Me.HealthPercent <= 95)
                {
                    Debug("NeedRest is true: casting soul harvest... wait.");
                    return true;
                }

                //Debug("NeedRest is false");
                return false;
            }
        }


        private DateTime SoulStoneTimer = DateTime.Now.AddMinutes(35);
        public static int maxAdds = 1; //see behavior.cs to edit this

        public override bool NeedPreCombatBuffs
        {
            get
            {
                //Debug("casting spell id " + Me.CastingSpellId);
                //if (Me.CurrentTarget != null) Debug("Target faction: " + Me.CurrentTarget.FactionId);
                //return true;

                if (Me.Mounted)
                    return false;

                if (CheckPet(true))
                    return false;

                if (Me.CastingSpellId == Spells.CreateHealthstone.Id || Me.CastingSpellId == Spells.CreateSoulStone.Id)
                {
                    Debug("Need buffs: creating hearthstone or soulstone");
                    return true;
                }
                if (Me.CastingSpellId == Spells.UseSoulStone.Id)
                {
                    Debug("Need buffs: binding soulstone...");
                    return true;
                }

                if (Spells.PlayerNeedsOneOfTheseBuffs(Spells.FelArmor, Spells.DemonArmor))
                {
                    Debug("Need buffs: no armor buff");
                    return true;
                }
                if (Spells.PlayerNeedsBuff(Spells.SoulLink))
                {
                    Debug("Need buffs: no soul link");
                    return true;
                }

                if (NeedsHealthstone || NeedsSoulstone)
                {
                    Debug("Need buffs: no healthstone or soulstone");
                    return true;
                }

                if (PlayerHasItem(SOULSTONE)
                    && !UnitHelper.HasBuff(Me, Spells.UseSoulStone)
                    && DateTime.Now.CompareTo(SoulStoneTimer) >= 0)
                {
                    Debug("Need buffs: soulstone is ready to use");
                    return true;
                }
                else
                {
                    //Debug("Soulstone timer: " + DateTime.Now.Subtract(SoulStoneTimer).TotalMinutes + " minutes");
                }

                //Debug("Need buffs: none :-)");
                return false;
            }
        }



        public override void Initialize()
        {
            Debug("Init: binding lua events");
            Lua.Events.AttachEvent("UNIT_SPELLCAST_SUCCEEDED", Spells.HandleSpellSucceeded);
            Lua.Events.AttachEvent("UNIT_SPELLCAST_STOP", Spells.HandleSpellFailure);
            Lua.Events.AttachEvent("UNIT_SPELLCAST_FAILED", Spells.HandleSpellFailure);
            Lua.Events.AttachEvent("UI_ERROR_MESSAGE", HandleErrorMessage);
            Lua.Events.AttachEvent("PLAYER_REGEN_ENABLED", HandleCombatDone);

            Debug("Getting lua vars");
            SPELL_FAILED_UNIT_NOT_INFRONT = Lua.GetReturnVal<string>("return SPELL_FAILED_UNIT_NOT_INFRONT", 0);

            Debug("Binding bot events...");
            BotEvents.OnBotStarted += delegate(EventArgs args)
            {
                Spells.ForceUnlock();
                Behavior.Reset();
            };
        }

        private string SPELL_FAILED_UNIT_NOT_INFRONT = null;
        private void HandleErrorMessage(object sender, LuaEventArgs args)
        {
            string msg = args.Args[0].ToString();

            if (msg == SPELL_FAILED_UNIT_NOT_INFRONT)
                FaceTarget();
        }

        private void HandleCombatDone(object sender, LuaEventArgs args)
        {
            Debug("--- Combat done! ---");
            Behavior.AddCombatStats();
        }

        public static void FaceTarget()
        {
            if (Me.CurrentTarget != null)
            {
                Debug("Correcting target facing.");
                Me.CurrentTarget.Face();
            }
        }


        public override void Rest()
        {
            //XXX does this actually work?
            if (Spells.Locked || Me.IsCasting || Me.ActiveAuras.Any(a => a.Value.Name == "Food" || a.Value.Name == "Drink"))
            {
                //Debug("Rest: do nothing, already busy");
                return;
            }

            if (Me.ManaPercent < 80 && Me.HealthPercent > 50 && SpellManager.CanCast(Spells.LifeTap))
            {
                Debug("Rest: life tap");
                Spells.Cast(Spells.LifeTap);
                return;
            }

            if ((Me.HealthPercent < 50 || Me.CurrentSoulShards < 3) && SpellManager.CanCast(Spells.SoulHarvest))
            {
                Debug("Rest: soul harvest");
                Spells.Cast(Spells.SoulHarvest);
                return;
            }

            if (Me.HealthPercent < 50 || Me.ManaPercent < 60)
                Debug("Resting lazily with drink/food...");

            if (Me.HealthPercent < 50)
                Styx.Logic.Common.Rest.FeedImmediate();
            if (Me.ManaPercent < 60)
                Styx.Logic.Common.Rest.DrinkImmediate();
        }



        public override void PreCombatBuff()
        {
            // Wait for us to stop casting please...
            if (Spells.Locked || Me.IsCasting)
            {
                //Debug("Precombat: do nothing as I'm casting...");
                return;
            }

            //pet
            if (CheckPet(true))
                return;

            if (Spells.PlayerNeedsBuff(Spells.FelArmor))
            {
                Debug("Precombat: need fel armor");
                Spells.Cast(Spells.FelArmor);
                return;
            }
            
            if (!SpellManager.HasSpell(Spells.FelArmor) && Spells.PlayerNeedsBuff(Spells.DemonArmor))
            {
                Debug("Precombat: need demon armor (no fel armor)");
                Spells.Cast(Spells.DemonArmor);
                return;
            }

            if (Spells.PlayerNeedsBuff(Spells.SoulLink))
            {
                Debug("Precombat: need soul link");
                Spells.Cast(Spells.SoulLink);
                return;
            }

            if (NeedsHealthstone)
            {
                Debug("Precombat: need a healthstone");
                Spells.Cast(Spells.CreateHealthstone);
                return;
            }

            if (NeedsSoulstone)
            {
                Debug("Precombat: need a soulstone");
                Spells.Cast(Spells.CreateSoulStone);
                return;
            }

            if (PlayerHasItem(SOULSTONE)
                && !UnitHelper.HasBuff(Me, Spells.UseSoulStone)
                && DateTime.Now.CompareTo(SoulStoneTimer) >= 0)
            {
                Debug("Precombat: get stoned (got it?)");
                SoulStoneTimer = DateTime.Now.AddMinutes(35);
                Spells.Cast(Spells.UseSoulStone);
                return;
            }
        }



        public override void Pull()
        {
            //Don't do anything while casting!!
            if (Spells.Locked || Me.IsCasting)
            {
                //Debug("Pull: Casting... do nothing");
                return;
            }

            PetAttack();

            Spells.Cast(Opener, Me.CurrentTarget);
        }



        public override void Combat()
        {
            if (Me.CurrentTarget == null)
            {
                if (Targeting.Instance.FirstUnit == null || Targeting.Instance.FirstUnit.Dead || !Targeting.Instance.FirstUnit.Combat)
                {
                    // Just try to pick up our pets target
                    if (Me.Pet != null && Me.Pet.Combat && Me.Pet.CurrentTarget != null)
                    {
                        Debug("Combat: picked up pet target");
                        Me.Pet.CurrentTarget.Target();
                        return;
                    }

                    //this seems to be ok... happens when combat done. still in combat but target died
                    //Debug("Combat: oops, no target!");
                    return;
                }
                Targeting.Instance.FirstUnit.Target();
                if (Me.CurrentTarget != null)
                    Debug("Picked up new target: " + Me.CurrentTarget.Name);
                return;
            }

            //Debug("Combat: targetting " + Me.CurrentTarget.Name);

            // Don't do anything while casting!!
            if (Me.IsCasting || Spells.Locked)
            {
                //Debug("Combat: do nothing, casting...");
                if (!Me.IsFacing(Me.CurrentTarget))
                {
                    FaceTarget();
                }
                return;
            }

            if (CheckPet(false))
                return;

            // Aggro management with more than one add
            var adds = ObjectManager.GetObjectsOfType<WoWUnit>(true, false).
                Where(u => u.CurrentTargetGuid == Me.Guid).OrderBy(u => u.Guid).ToList();
            if (adds.Count > 0)
            {
                Debug("Oops, I got {0} bad guys on me", adds.Count);

                //help me, stupid pet
                if (Me.Pet != null && !Me.Pet.Dead && Me.Pet.CurrentTarget != null && Me.Pet.CurrentTarget.CurrentTarget == Me.Pet)
                {
                    Debug("Sending pet on add");
                    var oldTarget = Me.CurrentTarget;
                    adds[0].Target();
                    PetAttack();
                    if (oldTarget != null)
                        oldTarget.Target();
                    return;
                }

                //too many bad guys?
                if (adds.Count > maxAdds)
                {
                    Debug("WARN: Too many adds on me!");
                    //try soulshatter if we got a pet
                    if (Me.HealthPercent < 60 && Me.Pet != null && !Me.Pet.Dead && Spells.Soulshatter.CanCast)
                    {
                        Spells.Cast(Spells.Soulshatter);
                        return;
                    }

                    //or pop an infernal and pray
                    /*if (Spells.SummonInfernal.CanCast)
                    {
                        Spells.Cast(Spells.SummonInfernal);
                        return;
                    }*/
                }
            }

            if (Me.HealthPercent >= 50 && Me.ManaPercent <= 70 && Spells.LifeTap.CanCast)
            {
                Spells.Cast(Spells.LifeTap);
                return;
            }

            if (Me.HealthPercent <= 40 && PlayerHasItem(HEALTHSTONE))
            {
                Debug("Use healthstone");
                Spells.Cast(Spells.UseHealthStone);
                return;
            }

            if (Me.HealthPercent >= 40 && Me.Pet != null && Me.Pet.HealthPercent < 60 && Spells.HealthFunnel.CanCast)
            {
                Spells.Cast(Spells.HealthFunnel);
                return;
            }

            /* affliction combat rotation
             * ***************************
             * that's why the bot should be doing:
             *  - should have pulled with best useful affliction spell, like haunt.
             *  - check that pet actually attacks target. else send pet to attack
             *  - Nuke loop:
             *          - if target hp < 25%, drain soul only!
             *          - else if soulburn ready, cast it with SF or drain life
             *          - refresh debuffs if necessary (corr, immolate/UA, bane of agony if no haunt)
             *          - haunt / drain life / shadowbolt
             */

            //pet attack
            if (Me.Pet != null && Me.Pet.CurrentTarget == null)
            {
                Debug("Send pet on target.");
                PetAttack();
            }

            //drain soul
            if (Me.CurrentTarget.HealthPercent < 25 && Spells.DrainSoul.CanCast)
            {
                Debug("Low HP target => drain soul!");
                Spells.Cast(Spells.DrainSoul, Me.CurrentTarget);
                return;
            }

            //instant SF
            if (Me.CurrentTarget.HealthPercent > 60 && SoulburnReady && Spells.SoulFire.CanCast)
            {
                Debug("Instant SF!§1");
                Spells.Cast(Spells.SoulFire, Me.CurrentTarget, true);
                return;
            }

            //corr
            if (Spells.Corruption.CanCast 
                && !UnitHelper.HasBuff(Me.CurrentTarget, Spells.Corruption))
            {
                Debug("Target needs corruption");
                Spells.Cast(Spells.Corruption, Me.CurrentTarget);
                return;
            }

            //immolate / UA
            var castDot = Immolate_OR_UnstableAffliction;
            if (castDot != null 
                && castDot.CanCast
                && UnitHelper.MustRefreshBuff(Me.CurrentTarget, castDot))
            {
                Debug("Target needs " + castDot.Name);
                Spells.Cast(castDot, Me.CurrentTarget);
                return;
            }

            //bane of agony
            castDot = null;
            if (!SpellManager.HasSpell(Spells.Haunt)
                && SpellManager.HasSpell(Spells.BaneOfAgony))
                castDot = Spells.BaneOfAgony;
            if (castDot != null
                && castDot.CanCast
                && !UnitHelper.HasBuff(Me.CurrentTarget, castDot))
            {
                Debug("Target needs " + castDot.Name);
                Spells.Cast(castDot, Me.CurrentTarget);
                return;
            }

            //super drain life
            if (SoulburnReady && Spells.DrainLife.CanCast)
            {
                Debug("Empowered drain life!");
                Spells.Cast(Spells.DrainLife, Me.CurrentTarget, true);
                return;
            }

            //can I pulls moar mobz? ********************************************

            if (SpellManager.HasSpell(Spells.Corruption) 
                && Me.HealthPercent > 70 
                && Me.ManaPercent > 70 
                && TotalAdds < maxAdds)
            {
                //anything around?
                var nearestTarget = ObjectManager.GetObjectsOfType<WoWUnit>(true, false).
                    FirstOrDefault(u =>  !u.IsPlayer 
                                && u.FactionId == Me.CurrentTarget.FactionId
                                && u.CurrentTarget == null 
                                && !u.TaggedByOther
                                && u.DistanceSqr < Math.Pow(Targeting.PullDistance, 2));

                if (nearestTarget != null)
                {
                    Debug("Found a near target to pull!");
                    nearestTarget.Target();
                    Spells.Cast(Spells.Corruption); //instant pull is better!
                }
            }

            //stupid nuke spells here. ******************************************

            if (SpellManager.HasSpell(Spells.Haunt) && !Spells.Haunt.Cooldown)
            {
                Debug("Haunt");
                Spells.Cast(Spells.Haunt, Me.CurrentTarget);
                return;
            }

            if ((Me.HealthPercent < 85 || Me.CurrentTarget.HealthPercent < 25 + 10)
                && SpellManager.HasSpell(Spells.DrainLife))
            {
                Debug("drain life");
                Spells.Cast(Spells.DrainLife, Me.CurrentTarget);
                return;
            }

            if (SpellManager.HasSpell(Spells.ShadowBolt))
            {
                Debug("shadow bolt");
                Spells.Cast(Spells.ShadowBolt, Me.CurrentTarget);
                return;
            }

            //nothing to do ?! desperate attack.
            Debug("Dont know what to cast... shooting");
            Spells.Cast(Spells.Shoot, Me.CurrentTarget);
        }

        /**************************************************************************/

        /* Lock helpers */

        public static uint HEALTHSTONE { get { return 5512; } }
        public static uint SOULSTONE { get { return 5232; } }

        public static WoWSpell Opener
        {
            get
            {
                var wish = new WoWSpell[] {
                    Spells.Haunt,
                    Spells.UnstableAffliction,
                    Spells.Corruption,
                    Spells.BaneOfAgony,
                    Spells.Immolate,
                    Spells.ShadowBolt
                };

                WoWSpell spell = wish.First(s => s.CanCast);
                Debug("Opener: " + spell.Name);
                return spell;
            }
        }

        public static WoWSpell Immolate_OR_UnstableAffliction
        {
            get
            {
                if (SpellManager.HasSpell(Spells.UnstableAffliction))
                    return Spells.UnstableAffliction;
                else if (SpellManager.HasSpell(Spells.Immolate))
                    return Spells.Immolate;
                else
                    return null;
            }
        }

        public static int TotalAdds
        {
            get
            {
                return ObjectManager.GetObjectsOfType<WoWUnit>(true, false).
                    Where(u => u.Attackable && (u.CurrentTargetGuid == Me.Guid || (Me.Pet != null && u.CurrentTargetGuid == Me.Pet.Guid))).
                    Count();
            }
        }

        public static bool NeedsHealthstone
        {
            get
            {
                return
                    !PlayerHasItem(HEALTHSTONE)
                    && SpellManager.HasSpell(Spells.CreateHealthstone);
            }
        }

        public static bool NeedsSoulstone
        {
            get
            {
                return 
                    !PlayerHasItem(SOULSTONE) 
                    && SpellManager.HasSpell(Spells.CreateSoulStone);
            }
        }

        public static bool SoulburnReady
        {
            get
            {
                return
                    Me.CurrentSoulShards > 0 &&
                    Spells.Soulburn.CanCast
                    && !Spells.Soulburn.Cooldown;
            }
        }

        public static bool PlayerHasItem(WoWItem item)
        {
            return PlayerHasItem(item.Entry);
        }
        public static bool PlayerHasItem(uint entry)
        {
            return
                ObjectManager.GetObjectsOfType<WoWItem>(false, false).
                    Exists(i => i.Entry == entry);
        }

        public static WoWItem FindItem(uint entry)
        {
            return
                ObjectManager.GetObjectsOfType<WoWItem>(false, false).
                    FirstOrDefault(i => i.Entry == entry);
        }

        public static void PetAttack()
        {
            if (Me.Pet != null && !Me.Pet.IsAutoAttacking)
                Lua.DoString("PetAttack()");
        }

        private static bool noPet = false; //skip pet actions or check?
        public static bool CheckPet(bool forceSummon)
        {
            //returns true if summoning a new pet
            if (!noPet && (Me.Pet == null || Me.Pet.Dead))
            {
                noPet = false;
                Debug("I need a new puppy.");

                //instant summon if needed
                //TODO: demon spec - check for buff 8844X, X=6,7,8...
                bool instant = (SoulburnReady && Me.Combat);

                //afflock: use the blue thingie, else imp
                if (SpellManager.HasSpell(Spells.SummonVoidwalker))
                    Spells.Cast(Spells.SummonVoidwalker, instant);
                else if (SpellManager.HasSpell(Spells.SummonImp))
                    Spells.Cast(Spells.SummonImp, instant);
                else
                {
                    Debug("Hey... no pet found?!");
                    noPet = true;
                }
                return true;
            }
            return false;
        }
    }
}
