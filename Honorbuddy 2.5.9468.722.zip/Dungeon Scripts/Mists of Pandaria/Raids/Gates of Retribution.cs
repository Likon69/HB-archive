﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;
using System.Windows.Forms;
using System.Windows.Media;
using Bots.DungeonBuddy.Avoidance;
using Bots.DungeonBuddy.Behaviors;
using Bots.DungeonBuddy.Profiles.Handlers;
using CommonBehaviors.Actions;
using Styx;
using Styx.Common;
using Styx.Common.Helpers;
using Styx.CommonBot;
using Styx.CommonBot.Coroutines;
using Styx.CommonBot.Frames;
using Styx.Helpers;
using Styx.Patchables;
using Styx.Pathing;
using Styx.TreeSharp;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using Styx.WoWInternals.World;
using Action = Styx.TreeSharp.Action;
using Bots.DungeonBuddy.Profiles;
using Bots.DungeonBuddy.Attributes;
using Bots.DungeonBuddy.Helpers;
using AvoidanceManager = Bots.DungeonBuddy.Avoidance.AvoidanceManager;

namespace Bots.DungeonBuddy.Dungeon_Scripts.Mists_of_Pandaria
{
	public class GatesOfRetribution : Dungeon
	{
		#region Overrides of Dungeon

		public override uint DungeonId
		{
			get { return 717; }
		}

		public override WoWPoint Entrance
		{
			get { return new WoWPoint(1242.479, 600.5036, 318.0787); }
		}

		#region Movement

		public override MoveResult MoveTo(WoWPoint location)
		{
			var myLoc = Me.Location;

			return MoveResult.Failed;
		}

		#endregion

		public override void RemoveTargetsFilter(List<WoWObject> units)
		{
			bool galakrasIsAlive = ScriptHelpers.IsBossAlive("Galakras");
			units.RemoveAll(
				ret =>
				{
					var unit = ret.ToUnit();
					if (unit != null)
					{
						if (unit.Entry != GeneralNazgrimId && ignoreNazgrimAdds)
							return true;

						// remove dps targets that are not by group while on pre-Galakras encounter (such as those on towers)
						if (galakrasIsAlive)
						{
							var rangedGroupCenter = GetRangedGroupCenter();
							if (unit.Location.DistanceSqr(rangedGroupCenter) > 50*50)
								return true;
						}

						switch (unit.Entry)
						{
								// only range should deal with these since they do aoe around them.
							case FoulSlimeId:
								return Me.IsMelee();
							case KorkronIronbladeId:
								return unit.CastingSpellId == IronstormSpellId && Me.IsMeleeDps();
							case GeneralNazgrimId:
								return unit.HasAura("Defensive Stance");
						}
					}
					return false;
				});
		}

		public override void IncludeTargetsFilter(List<WoWObject> incomingunits, HashSet<WoWObject> outgoingunits)
		{
			foreach (var obj in incomingunits)
			{
				var unit = obj as WoWUnit;
				if (unit != null)
				{
					if (unit.Entry == HealingTideTotemId || unit.Entry == HealingTideTotem2Id || unit.Entry == DragonmawWarBannerId)
						outgoingunits.Add(unit);
				}
			}
		}

		public override void RemoveHealTargetsFilter(List<WoWObject> units)
		{
			if (!ScriptHelpers.IsBossAlive("Galakras"))
				return;

			var rangedGroupCenter = GetRangedGroupCenter();
			units.RemoveAll(
				u =>
				{
					// remove healing targets that are not with group while on pre-Galakras encounter (such as those on towers)
					if (u.Location.DistanceSqr(rangedGroupCenter) > 50*50)
						return true;
					return false;
				});

		}

		public override void WeighTargetsFilter(List<Targeting.TargetPriority> units)
		{
			foreach (var priority in units)
			{
				var unit = priority.Object as WoWUnit;
				if (unit != null)
				{
					switch (unit.Entry)
					{
						case KorkronAssassinId:
							priority.Score += (Me.HasAura("Assassin's Mark") && Me.Auras["Assassin's Mark"].CreatorGuid == unit.Guid)
								? 10000
								: 3500;
							break;
						case KorkronBannerId:
							priority.Score += 4500;
							break;
							// These are casted by Dragonmaw Tidal Shaman and should be killed immediately
						case HealingTideTotemId:
						case HealingTideTotem2Id:
							// Foul Slime will spawn during the Kor'kron Dark Shaman encounter 
						case FoulSlimeId:
							priority.Score += 4000;
							break;
							// these are casted by Dragonmaw Flagbearer and should be killed immediately
						case DragonmawWarBannerId:
						case KorkronWarshamanId:
							priority.Score += 3500;
							break;
						case KorkronDemolisherId:
						case KorkronArcweaverId:
							priority.Score += 3000;
							break;
							// Summoned by Korgra the Snake. These will pop up behind random raid members and do a frontal attack.
						case DragonmawEbonStalkerId:
						case KorkronIronbladeId:
							priority.Score += 2500;
							break;
					}
				}
			}
		}

		public override void OnEnter()
		{
			if (Me.IsTank())
			{
				Alert.Show(
					"Tanking Not Supported",
					string.Format(
						"Tanking is not supported in the {0} script. If you wish to stay in raid and play manually then press 'Continue'. Otherwise you will automatically leave raid.",
						Name),
					30,
					true,
					true,
					null,
					() => Lua.DoString("LeaveParty()"),
					"Continue",
					"Leave");
			}
			else
			{
				Alert.Show(
					"Do Not AFK",
					"It is highly recommended you do not afk while in a raid and be prepared to intervene if needed in the event something goes wrong or you're asked to perform a certain task.",
					20,
					true,
					false,
					null,
					null,
					"Ok");
			}
			ignoreNazgrimAdds = false;
		}

		#endregion

		#region Root Behavior

		private LocalPlayer Me
		{
			get { return StyxWoW.Me; }
		}

		[EncounterHandler(0)]
		public Composite RootBehavior()
		{
			return new PrioritySelector();
		}

		#endregion

		#region Galakras

		private const uint HealingTideTotemId = 73086;
		private const uint DragonmawWarBannerId = 73088;
		private const uint FlameArrowsMissileId = 147552;
		private const uint FlameArrowsSpellId = 146764;
		private const uint KorkronDemolisherId = 72947;
		private const uint BombardMissileId = 148301;
		private const uint PoisonCloudSpellId = 147706;
		private const uint HighEnforcerThranokId = 72355;
		private const uint FlamesofGalakrondSpellIdSpellId = 146991;
		private const uint DragonmawEbonStalkerId = 72352;

		[EncounterHandler(72249, "Galakras")]
		public Composite CreateBehavior_Galakras()
		{
			// these are casted by Dragonmaw Flameslinger
			AddAvoidLocation(
				ctx => true,
				4,
				o => ((WoWMissile) o).ImpactPosition,
				() => WoWMissile.InFlightMissiles.Where(m => m.SpellId == FlameArrowsMissileId));
			AddAvoidObject(
				ctx => true,
				4,
				o =>
				{
					var areaTriger = o as WoWAreaTrigger;
					return areaTriger != null && areaTriger.SpellId == FlameArrowsSpellId;
				});

			// avoid the bombardment from demolishers.
			AddAvoidLocation(
				ctx => true,
				6,
				o => ((WoWMissile) o).ImpactPosition,
				() => WoWMissile.InFlightMissiles.Where(m => m.SpellId == BombardMissileId));

			// avoid the poisonous cloud lanched by Korgra the Snake
			AddAvoidLocation(
				ctx => true,
				4,
				o => ((WoWMissile) o).ImpactPosition,
				() => WoWMissile.InFlightMissiles.Where(m => m.SpellId == PoisonCloudSpellId));
			AddAvoidObject(
				ctx => true,
				4,
				o =>
				{
					var areaTriger = o as WoWAreaTrigger;
					return areaTriger != null && areaTriger.SpellId == PoisonCloudSpellId;
				});

			// avoid this guy while he's spinning around
			AddAvoidObject(ctx => true, 10, o => o.Entry == HighEnforcerThranokId && o.ToUnit().HasAura("Skull Cracker"));

			// a ball of fire casted by the boss. 
			AddAvoidObject(
				ctx => true,
				8,
				o =>
				{
					var areaTriger = o as WoWAreaTrigger;
					return areaTriger != null && areaTriger.SpellId == FlamesofGalakrondSpellIdSpellId;
				});

			WoWUnit boss = null;
			return new PrioritySelector(
				ctx => boss = ctx as WoWUnit,
				ScriptHelpers.CreateAvoidUnitAnglesBehavior(ctx => boss.Distance <= 20, o => boss, new ScriptHelpers.AngleSpan(0, 180)));
		}

		[EncounterHandler(72943, "Dragonmaw Proto-Drake")]
		public Composite CreateBehavior_DragonmawProtoDrake()
		{
			WoWUnit boss = null;
			return new PrioritySelector(
				
				
				// commented out because overlaping these can cause bot to spin! need to get better conal avodance.
				//	ctx => boss = ctx as WoWUnit,
				// these drakes have a flame breath so don't stand in front
				//ScriptHelpers.CreateAvoidUnitAnglesBehavior(ctx => boss.Distance <= 20, o => boss, new ScriptHelpers.AngleSpan(0, 180))
				);
		}

		[EncounterHandler(72352, "Dragonmaw Ebon Stalker")]
		public Composite CreateBehavior_DragonmawEbonStalker()
		{
			WoWUnit boss = null;
			return new PrioritySelector(
				ctx => boss = ctx as WoWUnit,
				// these drakes have a flame breath so don't stand in front
				ScriptHelpers.CreateAvoidUnitAnglesBehavior(ctx => boss.Distance <= 9, o => boss, new ScriptHelpers.AngleSpan(0, 100)));
		}

		[LocationHandler(1425.201, -4888.474, 11.2178, 200, "Galakras Area")]
		public Composite CreateBehavior_GalakrasArea()
		{
			return new PrioritySelector(
				// ranged classes should not wander too far from raid. (not a problem for melee)
				new Decorator(
					ctx => Me.IsRange(),
					new PrioritySelector(
						ctx => GetRangedGroupCenter(),
						new Decorator<WoWPoint>(
							raidPos => Me.Location.DistanceSqr(raidPos) > 25*25,
							new Helpers.Action<WoWPoint>(raidPos => Navigator.GetRunStatusFromMoveResult(Navigator.MoveTo(raidPos)))),
						new Decorator(
							ctx => ScriptHelpers.MovementEnabled,
							new Helpers.Action<WoWPoint>(
								raidPos =>
									ScriptHelpers.DisableMovement(
										() => Me.Location.DistanceSqr(raidPos) > 25*25 && !AvoidanceManager.IsRunningOutOfAvoid)))
						))
				);
		}

		#endregion

		#region Iron Juggernaut

		private const uint BorerDrillId = 71906;
		private const uint ExplosiveTarId = 71950;
		private const uint CrawlerMineId = 72050;
		private const uint CutterLaserId = 72026;
		private const uint CutterLaserSpellId = 144576;
		private const uint MortarBlastMissile1Id = 146027;
		private const uint MortarBlastMissile2Id = 144316;
		private const uint DemolisherCannonMissileId = 144153;
		private const uint IronJuggernautId = 71466;

		[EncounterHandler(71466, "Iron Juggernaute")]
		public Composite CreateBehavior_IronJuggernaut()
		{
			// Don't stand under Iron Juggernaute. With all the avoidance the bot tends to end up under the boss a lot. this prevents that.
			AddAvoidObject(ctx => true, 8, IronJuggernautId);

			// Borer Drill 
			AddAvoidObject(ctx => true, 8, BorerDrillId);

			// Borer Drill 
			AddAvoidObject(ctx => true, 8, BorerDrillId);

			// Explosive Tar
			AddAvoidObject(ctx => true, 10, ExplosiveTarId);

			// Mortar Blast
			AddAvoidLocation(
				ctx => true,
				8,
				o => ((WoWMissile) o).ImpactPosition,
				() => WoWMissile.InFlightMissiles.Where(m => m.SpellId == MortarBlastMissile1Id || m.SpellId == MortarBlastMissile2Id));

			// Cutter Laser
			AddAvoidObject(ctx => true, o => Me.IsMoving ? 12 : 7, CutterLaserId);
			AddAvoidObject(
				ctx => true,
				3,
				o =>
				{
					var areaTriger = o as WoWAreaTrigger;
					return areaTriger != null && areaTriger.SpellId == CutterLaserSpellId;
				});

			// Demolisher Cannon
			AddAvoidLocation(
				ctx => true,
				6,
				o => ((WoWMissile) o).ImpactPosition,
				() => WoWMissile.InFlightMissiles.Where(m => m.SpellId == DemolisherCannonMissileId));

			WoWUnit boss = null;
			return new PrioritySelector(
				ctx => boss = ctx as WoWUnit,
				// boss does some frontal cone damage so don't stand in front 
				ScriptHelpers.CreateAvoidUnitAnglesBehavior(ctx => boss.Distance <= 20, o => boss, new ScriptHelpers.AngleSpan(0, 180)),
				// ranged classes should no wander too far from raid. (not a problem for melee)
				new Decorator(
					ctx => Me.IsRange(),
					new PrioritySelector(
						ctx => GetRangedGroupCenter(),
						new Decorator<WoWPoint>(
							raidPos => Me.Location.DistanceSqr(raidPos) > 20*20,
							new Helpers.Action<WoWPoint>(raidPos => Navigator.GetRunStatusFromMoveResult(Navigator.MoveTo(raidPos))))))
				// ignore crawler mines
				);
		}

		#endregion

		#region Kor'kron Dark Shaman

		private const uint EarthbreakerHarommId = 71859;
		private const uint WavebinderKardrisId = 71858;
		private const uint ToxicStormId = 71801;
		private const uint ToxicTornadoId = 71817;
		private const uint FoulGeyserMissileId = 143992;
		private const uint FallingAshId = 71789;
		private const uint FoulStreamSpellId = 144090;
		private const uint FoulSlimeId = 71825;
		private const uint AshElementalId = 71827;

		private readonly WaitTimer _updateRangedGroupCenterPos = WaitTimer.FiveSeconds;
		private WoWPoint _rangedGroupCenter = WoWPoint.Zero;

		[EncounterHandler(71859, "Earthbreaker Haromm")]
		[EncounterHandler(71858, "Wavebinder Kardris")]
		public Composite CreateBehavior_KorkronDarkShaman()
		{
			// stay away from the foul slime
			AddAvoidObject(ctx => true, o => Me.IsRange() && Me.IsMoving ? 12 : 6, FoulSlimeId);
			// Avoid Toxic Storm
			AddAvoidObject(ctx => true, o => 9, ToxicStormId);
			// Avoid Toxic Tornado
			AddAvoidObject(ctx => true, o => Me.IsRange() && Me.IsMoving ? 10 : 6, ToxicTornadoId);
			// Foul Geyser
			AddAvoidLocation(
				ctx => true,
				3,
				o => ((WoWMissile) o).ImpactPosition,
				() => WoWMissile.InFlightMissiles.Where(m => m.SpellId == FoulGeyserMissileId));

			// Falling ash. Very important to avoid. This is instant death if caught in it.
			AddAvoidObject(ctx => true, 18, FallingAshId);

			// Avoid the Ash Elements. These are un-attackable stationary NPCs that will attack nearby players 
			AddAvoidObject(ctx => true, 4, AshElementalId);

			// Step out of the Foul Stream path when it's targeting another player.
			// ToDo: Foul Stream
			AddAvoidObject(
				ctx => true,
				7,
				o =>
				{
					if (o.Entry != WavebinderKardrisId)
						return false;
					var unit = (WoWUnit) o;
					return unit.CastingSpellId == FoulStreamSpellId && unit.GotTarget && unit.CurrentTargetGuid != Me.Guid;
				},
				o => Me.Location.GetNearestPointOnSegment(o.Location, o.ToUnit().CurrentTarget.Location));

			// these npcs spawn and cast a Aftershock presumably in a line in front of them.
			AddAvoidObject(
				ctx => true,
				7,
				o => o.Entry == AfterShockId,
				o =>
				{
					var unit = (WoWUnit) o;
					var endPoint = unit.Location.RayCast(unit.Rotation, 17);
					return Me.Location.GetNearestPointOnSegment(unit.Location, endPoint);
				});


			WoWUnit boss = null;
			WoWPoint? foulStreamMovetoPoint = null;

			return new PrioritySelector(
				ctx => boss = ctx as WoWUnit,
				new Decorator(
					ctx =>
						boss.Entry == WavebinderKardrisId && boss.CurrentTargetGuid == Me.Guid && boss.CastingSpellId == FoulStreamSpellId,
					new PrioritySelector(
						// run to an empty side of boss if targeted with foul stream
						new Decorator(
							ctx => foulStreamMovetoPoint == null,
							new Action(
								ctx =>
								{
									foulStreamMovetoPoint = GetBestFoulStreamMoveTo(boss);
									return RunStatus.Failure;
								})),
						new ActionSetActivity("Moving Foul stream out of raid"),
						new Action(ctx => Navigator.MoveTo(foulStreamMovetoPoint.Value)))),
				// reset the foul stream moveto location to it's default value since it's no-longer valid
				new Decorator(
					ctx => foulStreamMovetoPoint.HasValue,
					new Action(
						ctx =>
						{
							foulStreamMovetoPoint = null;
							return RunStatus.Failure;
						})),
				// ranged classes should no wander too far from raid. (not a problem for melee)
				new Decorator(
					ctx => Me.IsRange(),
					new PrioritySelector(
						ctx => GetRangedGroupCenter(),
						new Decorator<WoWPoint>(
							raidPos => Me.Location.DistanceSqr(raidPos) > 17*17,
							new Helpers.Action<WoWPoint>(raidPos => Navigator.GetRunStatusFromMoveResult(Navigator.MoveTo(raidPos))))))
				);
		}

		private WoWPoint GetRangedGroupCenter()
		{
			if (_rangedGroupCenter == WoWPoint.Zero || _updateRangedGroupCenterPos.IsFinished)
			{
				_rangedGroupCenter = ScriptHelpers.GetGroupCenterLocation(g => g.IsRange, 20);
				_updateRangedGroupCenterPos.Reset();
			}
			return _rangedGroupCenter;
		}

		private WoWPoint GetBestFoulStreamMoveTo(WoWUnit boss)
		{
			var groupLocs = Me.RaidMembers.Where(r => !r.IsMe).Select(r => r.Location);
			var bossLoc = boss.Location;
			var myLoc = Me.Location;
			// the idea is to find a nearby spot where the least amount of raid members would get hit by Foul Stream
			return
				GetCirclePointsAroundLocation(bossLoc, myLoc.Distance(bossLoc), 10)
					.OrderBy(l => groupLocs.Count(gl => gl.GetNearestPointOnSegment(bossLoc, l).Distance2DSqr(gl) < 3.5f*3.5f))
					.ThenBy(l => l.DistanceSqr(myLoc))
					.FirstOrDefault(l => l.DistanceSqr(myLoc) < 30*30 && Navigator.CanNavigateFully(myLoc, l));
		}

		private IEnumerable<WoWPoint> GetCirclePointsAroundLocation(WoWPoint center, float dist, float stepDegrees = 40)
		{
			for (float ang = 0; ang < 360; ang += stepDegrees)
			{
				var radians = WoWMathHelper.DegreesToRadians(ang);
				yield return center.RayCast(radians, dist);
			}
		}

		#endregion

		#region General Nazgrim

		private const uint GeneralNazgrimId = 71515;
		private const uint KorkronWarshamanId = 71773;
		private const uint HealingTideTotem2Id = 72563;
		private const uint KorkronArcweaverId = 71517;
		private const uint KorkronAssassinId = 71518;
		private const uint KorkronIronbladeId = 71516;
		private const uint KorkronBannerId = 71626;
		private const uint AfterShockId = 71697;
		private const uint RavagerId = 71762;
		private const uint IronstormSpellId = 145566;

		private bool ignoreNazgrimAdds;

		// todo Get data on AfterShock

		[EncounterHandler(71515, "General Nazgrim")]
		public Composite CreateBehavior_GeneralNazgrim()
		{
			// these npcs spawn and cast a Aftershock presumably in a line in front of them.
			AddAvoidObject(
				ctx => true,
				7,
				o => o.Entry == AfterShockId,
				o =>
				{
					var unit = (WoWUnit) o;
					var endPoint = unit.Location.RayCast(unit.Rotation, 17);
					return Me.Location.GetNearestPointOnSegment(unit.Location, endPoint);
				});

			AddAvoidObject(ctx => true, 10, RavagerId);
			AddAvoidObject(ctx => true, 6, o => o.Entry == KorkronIronbladeId && o.ToUnit().CastingSpellId == IronstormSpellId);

			WoWUnit boss = null;
			return new PrioritySelector(
				ctx => boss = ctx as WoWUnit,
				new Action(
					ctx =>
					{
						ignoreNazgrimAdds = boss.HasAura("Berserk");
						return RunStatus.Failure;
					}));
		}

		#endregion
	}
}