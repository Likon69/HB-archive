﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Numerics;
using System.Threading.Tasks;
using Bots.DungeonBuddy;
using Bots.DungeonBuddy.Attributes;
using Bots.DungeonBuddy.Helpers;
using Buddy.Coroutines;
using Styx;
using Styx.Common;
using Styx.CommonBot;
using Styx.CommonBot.POI;
using Styx.Helpers;
using Styx.Pathing;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;

namespace Bots.DungeonBuddy.Dungeon_Scripts.Wrath_of_the_Lich_King
{
    public class PitOfSaron : Dungeon
    {
        #region Overrides of Dungeon
        public override uint DungeonId => 253;

        private const uint MobIdWrathboneSiegesmith = 36907;

        public override void RemoveTargetsFilter(List<WoWObject> units)
        {
            // Don't run this if we are in combat with Forgetmaster Garfrost.
            if (ForgemasterGarfrost != null && ForgemasterGarfrost.Combat)
                return;

            units.RemoveAll(
                ret =>
                {
                    var unit = ret as WoWUnit;
                    // Remove Wrathbone Siegesmiths near Garfrost so the bot doesn't try to pull them over the boss.
                    if (unit != null && unit.Entry == MobIdWrathboneSiegesmith)
                        return true;

                    return false;
                });
        }

        #endregion
        private LocalPlayer Me => StyxWoW.Me;

        private const uint MobIdCollapsingIcicle = 36847;
        private const uint DynamicObjectIdCollapsingIcicleAreaEffect = 69424;

        [EncounterHandler(0)]
        public Func<WoWUnit, Task<bool>> RootHandler()
        {
            // Collapsing Icicle in the tunnel that leads to Scourgelord Tyrannus.
            AddAvoidObject<WoWUnit>(() => true, o => 5f, MobIdCollapsingIcicle);
            AddAvoidObject<WoWDynamicObject>(() => true, o => 5f, DynamicObjectIdCollapsingIcicleAreaEffect);

            return async npc =>
            {
                // In case we fall down in the center...
                if (Me.Z <= 500f)
                    return await ScriptHelpers.PortOutsideAndBackIn();

                return false;
            };
        }

        #region Stuck Handlers

        public override DungeonStuckHandler[] StuckHandlers { get; } = {
            new PitOfSaronStuckHandler(),
            new TunnelStuckHandlerEx()
        };

        private class PitOfSaronStuckHandler : DungeonStuckHandler
        {
            private readonly Vector3 _stuckLocation = new Vector3(584.6944f, 78.32003f, 515.0027f);

            protected override bool IsStuck
                => StyxWoW.Me.Location.DistanceSquared(_stuckLocation) < 6 * 6;

            protected override Vector3 UnstickMoveTo { get; } = new Vector3(602.7095f, 75.24823f, 508.1875f);
            protected override string StuckAreaName { get; } = "Up on a cliff, pushed by mob?";
        }

        private class TunnelStuckHandler : DungeonStuckHandler
        {
            private readonly Vector3[] _tunnelMoveToPath =
            {
                new Vector3(937.3242f, -79.22245f, 592.4915f),
                new Vector3(952.1797f, -104.01f, 594.8618f),
                new Vector3(973.1763f, -120.8311f, 599.3324f),
                new Vector3(1013.35f, -133.914f, 621.9852f),
                new Vector3(1040.463f, -113.8403f, 628.9459f),
                new Vector3(1070.528f, -27.02801f, 633.4422f),
                new Vector3(1073.094f, 44.04744f, 630.0524f),
                new Vector3(1066.255f, 64.238f, 632.042f),
                new Vector3(1060.088f, 109.039f, 629.0912f)
            };

            private readonly Vector2[] _tunnelPolygonArea =
            {
                new Vector2(1005.301f, -249.065f),
                new Vector2(859.0612f, -121.8739f),
                new Vector2(970.2415f, -39.84259f),
                new Vector2(1054.127f, 92.17946f),
                new Vector2(1106.988f, 115.247f),
                new Vector2(1113.528f, -210.2495f)
            };

            protected override bool IsStuck
            {
                get
                {
                    if (BossManager.CurrentBoss?.Name != "Scourgelord Tyrannus")
                        return false;

                    if (!WoWMathHelper.IsPointInPoly(StyxWoW.Me.Location, _tunnelPolygonArea))
                        return false;

                    return Math.Abs(GetNearestPointOnSafePath(StyxWoW.Me.Location).Z - StyxWoW.Me.Z) > 5f;
                }
            }

            protected override Vector3 UnstickMoveTo => _tunnelMoveToPath.Skip(1)
                .Select((v, i) => StyxWoW.Me.Location.GetNearestPointOnSegment(_tunnelMoveToPath[i - 1 < 0 ? 0 : i - 1], v))
                .OrderBy(v => StyxWoW.Me.Location.DistanceSquared(v)).First();

            private Vector3 GetNearestPointOnSafePath(Vector3 location)
            {
                return _tunnelMoveToPath.Skip(1)
                .Select((v, i) => location.GetNearestPointOnSegment(_tunnelMoveToPath[i - 1 < 0 ? 0 : i - 1], v))
                .OrderBy(v => location.DistanceSquared(v)).First();
            }

            protected override async Task Unstick()
            {
                Navigator.PlayerMover.MoveTowards(UnstickMoveTo);
                await Coroutine.Sleep(5000);
            }

            protected override string StuckAreaName { get; } = "Tunnel";
        }

        private class TunnelStuckHandlerEx : DungeonStuckHandler
        {
            // [key: stuck location, value: unstick location]
            private readonly Dictionary<Vector3, Vector3> _stuckLocations = new Dictionary<Vector3, Vector3>
            {
                {new Vector3(1003.801f, -149.3355f, 625.3524f), new Vector3(1003.521f, -133.2893f, 618.261f) },
                {new Vector3(962.1926f, -133.3263f, 607.4485f), new Vector3(975.1313f, -121.0139f, 600.168f) },
                {new Vector3(982.4399f, -104.122f, 601.86f), new Vector3(972.3375f, -121.8271f, 599.3838f) },
                {new Vector3(995.1872f, -118.5937f, 618.0151f), new Vector3(991.6483f, -131.5278f, 611.6983f) },
                {new Vector3(1006.37f, -121.6817f, 624.3532f), new Vector3(1005.693f, -132.8343f, 619.3018f)},
                {new Vector3(1016.512f, -119.0688f, 631.2458f), new Vector3(1023.408f, -129.3241f, 624.8242f)},
                {new Vector3(1027.36f, -111.1349f, 637.1456f), new Vector3(1036.729f, -119.288f, 627.9907f) },
                {new Vector3(1075.075f, -71.68582f, 645.7231f), new Vector3(1062.076f, -62.1981f, 633.9917f)},
                {new Vector3(1050.462f, -58.01925f, 645.6464f), new Vector3(1062.076f, -62.1981f, 633.9917f)},
                {new Vector3(1056.25f, -20.67162f, 640.7885f), new Vector3(1068.391f, -25.0033f, 633.5143f)},
                {new Vector3(1082.78f, -26.36183f, 638.6781f), new Vector3(1068.391f, -25.0033f, 633.5143f)},
                {new Vector3(1077.42f, -39.02176f, 641.0302f), new Vector3(1068.391f, -25.0033f, 633.5143f)},
                {new Vector3(1056.456f, -33.05704f, 641.6483f), new Vector3(1068.391f, -25.0033f, 633.5143f)},
                {new Vector3(1063.27f, 5.053152f, 646.0568f), new Vector3(1076.125f, 17.73912f, 633.3274f)},
                {new Vector3(1091.31f, 6.369847f, 643.1996f), new Vector3(1076.125f, 17.73912f, 633.3274f)},
                {new Vector3(1093.336f, 29.73297f, 632.1495f), new Vector3(1076.454f, 25.75124f, 631.2052f)},
                {new Vector3(1032.491f, -96.36558f, 629.7219f), new Vector3(1046.452f, -112.9803f, 629.4758f)},
                {new Vector3(1094.329f, 15.22204f, 637.4902f), new Vector3(1077.244f, 21.90826f, 632.2618f)},
                {new Vector3(978.5233f, -103.9061f, 598.889f), new Vector3(965.7046f, -117.6961f, 597.3411f)},
                {new Vector3(938.3095f, -105.8291f, 595.6331f), new Vector3(949.8914f, -101.9108f, 594.913f)}
            };

            private Vector3 _lastUnstickMoveTo;
            protected override bool IsStuck
            {
                get
                {
                    foreach (var kvp in _stuckLocations)
                    {
                        if (StyxWoW.Me.Location.DistanceSquared(kvp.Key) < 6 * 6)
                        {
                            _lastUnstickMoveTo = kvp.Value;
                            return true;
                        }
                    }
                    return false;
                }
            }

            protected override Vector3 UnstickMoveTo => _lastUnstickMoveTo;
            protected override string StuckAreaName { get; } = "Tunnel to Tyrannus";
        }

        #endregion

        #region Safe pulling / trash

        [LocationHandler(460.5078f, 209.7357f, 528.7083f, 50f, "Deathwhisper Necrolytes")]
        [LocationHandler(551.4285f, 150.3116f, 520.048f, 50f, "Mobs right after the slope close to the entrance")]
        [LocationHandler(875.6649f, 54.36069f, 524.5699f, 50f, "Mobs that spawn after killing Ick when goin up the slope.")]
        [LocationHandler(937.0725f, 22.39486f, 574.4124f, 50f, "Mobs up on the slope before Tyrannus")]
        public async Task<bool> NearEntranceTrashHandler1(Vector3 loc)
        {
            var trash = ScriptHelpers.GetUnfriendlyNpsAtLocation(loc, 60f).FirstOrDefault();
            if (trash == null || Me.Combat)
                return false;

            return await ScriptHelpers.PullNpcToLocation(() => true, trash, loc, 5000);
        }

        private const uint MobIdYmirjarSkycaller = 31260;

        [LocationHandler(627.3904f, 123.3117f, 508.6693f, 30f, "Ymirjar Skycaller")]
        [LocationHandler(619.7142f, 24.63049f, 513.1262f, 30f, "Ymirjar Skycaller")]
        public async Task<bool> YmirjarSkycallerHandler(Vector3 loc)
        {
            WoWUnit ymirjarSkycaller =
                ObjectManager.GetObjectsOfTypeFast<WoWUnit>()
                    .FirstOrDefault(u => u.Entry == MobIdYmirjarSkycaller && u.DistanceSqr < 80 * 80);

            var trash = ScriptHelpers.GetUnfriendlyNpsAtLocation(loc, 80f, u => u.ZDiff <= 3f).FirstOrDefault();
            if (trash == null || Me.Combat)
                return false;

            if (ymirjarSkycaller != null && BotPoi.Current.Type == PoiType.None)
            {
                Logger.Write("Waiting for Ymirjar Skycaller to move along");
                return true;
            }

            return await ScriptHelpers.PullNpcToLocation(() => true, trash, loc, 5000);
        }

        #endregion

        #region Quest Pickup/Turnin

        [EncounterHandler(37592, "Gorkun Ironskull", Mode = CallBehaviorMode.Proximity, BossRange = 40)]
        [EncounterHandler(38189, "Lady Sylvanas Windrunner", Mode = CallBehaviorMode.Proximity, BossRange = 40)]
        public async Task<bool> QuestPickupTurninLogic(WoWUnit unit)
        {
            // Turnin for this quest.
            // http://www.wowhead.com/quest=24507/the-path-to-the-citadel

            if (Me.IsActuallyInCombat || ScriptHelpers.WillPullAggroAtLocation(unit.Location))
                return false;
            if (unit.HasQuestAvailable(true))
                return await ScriptHelpers.PickupQuest(unit);
            if (unit.HasQuestTurnin())
                return await ScriptHelpers.TurninQuest(unit);
            return false;
        }

        #endregion

        private const int ObjectIdBallAndChain = 201969;

        [ObjectHandler(ObjectIdBallAndChain, "Ball and Chain", 75)]
        public async Task<bool> BallAndChainHandler(WoWGameObject obj)
        {
            // Objective of: http://www.wowhead.com/quest=24507/the-path-to-the-citadel
            if (!ScriptHelpers.HasQuest(24507) || ScriptHelpers.IsQuestInLogComplete(24507))
                return false;

            if (!Me.IsTank())
                return false;

            if (ScriptHelpers.WillPullAggroAtLocation(obj.Location))
                return false;

            if (BotPoi.Current.Type == PoiType.None && Targeting.Instance.IsEmpty())
                return await ScriptHelpers.InteractWithObject(obj);

            return false;
        }

        #region Forgemaster Garfrost

        private const int MobIdForgemasterGarfrost = 36494;
        private const int SpellIdThrowSaronite = 68788;
        private const int ObjectIdSaroniteRock = 196485;
        private const uint AuraIdPermafrost = 68786;

        private WoWUnit ForgemasterGarfrost
            => ObjectManager.GetObjectsOfTypeFast<WoWUnit>().FirstOrDefault(u => u.Entry == MobIdForgemasterGarfrost);
        private WoWGameObject NearestSaroniteRock
            => ObjectManager.GetObjectsOfTypeFast<WoWGameObject>()
                    .OrderBy(o => o.Distance).FirstOrDefault(obj => obj.Entry == ObjectIdSaroniteRock && obj.Location.DistanceSquared(ForgemasterGarfrost.Location) > 25 * 25);

        private static Vector3 s_garfrostCenterArea = new Vector3(696.5544f, -200.443f, 526.7174f);
        private static readonly Vector3[] s_garfrostForgePositions = new[] { new Vector3(639.1075f, -206.6277f, 528.9316f), new Vector3(723.6442f, -235.8857f, 527.6351f) };
        private static Vector3 s_garfrostTankloc = new Vector3(687.825f, -228.2301f, 526.7174f);

        [EncounterHandler(MobIdForgemasterGarfrost, "Forgemaster Garfrost", 100, CallBehaviorMode.Proximity)]
        public Func<WoWUnit, Task<bool>> ForgemasterGarfrostEncounter()
        {
            WoWUnit garfrost = null;

            // Avoid saronite rocks.
            AddAvoidObject<WoWGameObject>(() => true, 6, obj => obj.Entry == ObjectIdSaroniteRock);
            AddAvoidObject<WoWUnit>(() => Me.IsRangeDps(), 30, u => u.Entry == MobIdForgemasterGarfrost && u.Combat);

            return async boss =>
            {
                garfrost = boss;

                if (!boss.Combat)
                    return false;

                if (!boss.Combat && Me.Combat)
                    return false;

                WoWAura aura = StyxWoW.Me.GetAuraByName("Permafrost");
                if (aura != null && aura.StackCount >= 4 && NearestSaroniteRock != null)
                {
                    var trash = ScriptHelpers.GetUnfriendlyNpsAtLocation(boss.Location, 45f);
                    if (trash.Any(t => t.IsTargetingMeOrPet))
                        return false;

                    if (await ScriptHelpers.MoveOutOfLos(() =>
                    (Me.IsTank() && (s_garfrostForgePositions.Any(p => boss.Location.DistanceSquared(p) < 15 * 15) || !boss.IsTargetingMeOrPet) || (!Me.IsTank() && !Me.IsHealer)),
                    boss.Location, NearestSaroniteRock.Location, 4
                    ))
                        return true;
                }

                if (await ScriptHelpers.TankUnitAtLocation(s_garfrostTankloc, 10f))
                    return true;

                if (await ScriptHelpers.TankFaceUnitAwayFromGroup(5))
                    return true;

                return false;
            };
        }

        #endregion

        #region Ick & Krick

        private const int MobIdIck = 36476;
        private const int MobIdKrick = 36477;
        private const int UnitIdExplodingOrb = 36610;

        private const int SpellIdPoisonNova = 68989;
        private const uint DynamicObjectIdToxicAreaEffect = 69024;

        [EncounterHandler(MobIdIck, "Ick", 80, CallBehaviorMode.Proximity)]
        [EncounterHandler(MobIdKrick, "Krick", 80, CallBehaviorMode.Proximity)]
        public Func<WoWUnit, Task<bool>> IckKrickEncounter()
        {
            Vector3 pullPosition = new Vector3(819.2044f, 55.82256f, 509.905f);

            // Avoid poison nova.
            AddAvoidObject<WoWUnit>(() => true, 15, u => u.Entry == MobIdIck && u.ToUnit().CastingSpellId == SpellIdPoisonNova);
            // Stay at 15 yards if possible.
            AddAvoidObject<WoWUnit>(() => Me.IsRangeDps(), 15, u => u.Entry == MobIdIck && u.Combat);
            //Green shit.
            AddAvoidObject<WoWDynamicObject>(() => true, 6, o => o.Entry == DynamicObjectIdToxicAreaEffect);
            //Exploding Orb
            AddAvoidObject<WoWUnit>(() => !Me.IsTank(), 7, u => u.Entry == UnitIdExplodingOrb);

            return async boss =>
            {
                // Clear the area first.
                var trash = ScriptHelpers.GetUnfriendlyNpsAtLocation(boss.Location, 80f,
                    u => u != boss && u.Location.DistanceSquared(boss.Location) > 20 * 20).FirstOrDefault();

                if (await ScriptHelpers.PullNpcToLocation(() => trash != null, trash, pullPosition, 6000))
                    return true;

                return false;
            };
        }

        #endregion

        #region Scourgelord Tyrannus

        private const int ScourgelordTyrannusUnitId = 36658;
        private const int UnitIdIcyBlast = 36731;
        private const uint ObjectIdHallsOfReflectionPortcullis = 201848;
        private const uint DynamicObjectIdIceAreaEffect = 69238;

        [EncounterHandler(ScourgelordTyrannusUnitId, "Scourgelord Tyrannus", 100, CallBehaviorMode.Proximity)]
        public Func<WoWUnit, Task<bool>> ScourgelordTyrannusEncounter()
        {
            // Icy Blast ground effect, the portcullis appears where the patch of ice is about to appear.
            AddAvoidObject<WoWObject>(() => !Me.IsTank(), 10, u => u.Entry == UnitIdIcyBlast || u.Entry == ObjectIdHallsOfReflectionPortcullis);

            // Once a player has this debuff, Rimefang will do a breath attack causing nearby players to get stunned.
            AddAvoidObject<WoWPlayer>(() => Me.HasAura("Mark of Rimefang"), 15, o => !o.IsMe);

            //Ice patches.
            AddAvoidObject<WoWDynamicObject>(() => true, 7, o => o.Entry == DynamicObjectIdIceAreaEffect);

            Vector3 tyrasnnusTankSpot = new Vector3(1079.541f, 193.2534f, 628.1561f);

            return async boss =>
            {
                // He's flying around the map, sometimes before the encounter you get in range of him.
                if (ScriptHelpers.IsBossAlive("Forgemaster Garfrost") || ScriptHelpers.IsBossAlive("Ick"))
                    return false;

                if (Me.HasAura("Overlord's Brand"))
                {
                    // Stop casting if we are.
                    if (Me.IsCasting)
                        SpellManager.StopCasting();

                    // Don't do anything until it expires.
                    return true;
                }

                if (!Me.IsTank())
                    return false;

                return await ScriptHelpers.TankUnitAtLocation(tyrasnnusTankSpot, 15f);
            };
        }

        #endregion
    }

    public class PitOfSaronHeroic : PitOfSaron
    {
        public override uint DungeonId => 254;
    }

    public class PitOfSaronTimewalking : PitOfSaronHeroic
    {
        public override uint DungeonId => 1153;
    }
}
