using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Threading.Tasks;
using CommonBehaviors.Actions;
using Styx;
using Styx.Common;
using Styx.Common.Helpers;
using Styx.CommonBot;
using Styx.Helpers;
using Styx.Pathing;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using Styx.TreeSharp;
using Action = Styx.TreeSharp.Action;

using Bots.DungeonBuddy.Profiles;
using Bots.DungeonBuddy.Attributes;
using Bots.DungeonBuddy.Helpers;
using Styx.CommonBot.Coroutines;

namespace Bots.DungeonBuddy.Dungeon_Scripts.Wrath_of_the_Lich_King
{
    public class HallsOfLightning : Dungeon
    {
        #region Overrides of Dungeon

        public override uint DungeonId
        {
            get { return 207; }
        }

        public override Vector3 Entrance
        {
            get { return new Vector3(9185.314f, -1386.893f, 1110.216f); }
        }

        public override Vector3 ExitLocation
        {
            get { return new Vector3(1330.962f, 275.4182f, 52.81053f); }
        }

        public override bool IsFlyingCorpseRun
        {
            get { return true; }
        }

        public override void OnEnter()
        {
            _volkhanCleartrashPath.CycleTo(_volkhanCleartrashPath.First);
        }

        public override void RemoveTargetsFilter(List<WoWObject> units)
        {
            var tank = ScriptHelpers.Tank;
            var slagsAtackingTank = units.Count(u => u.Entry == SlagId && tank != null && u.ToUnit().CurrentTargetGuid == tank.Guid);
            var tankY = tank != null && tank.IsAlive ? tank.Y : Me.Y;
            units.RemoveAll(
                ret =>
                {
                    WoWUnit unit = ret.ToUnit();
                    if (unit != null)
                    {
                        if (ret.Entry == SlagId && (!unit.Combat || (Me.IsTank() && unit.CurrentTargetGuid == Me.Guid || Me.IsRange()) && slagsAtackingTank < 6 && tankY > -220))
                            return true;
                        if (ret.Entry == SparkofIonarId)
                            return true;
                        if (ret.Entry == GeneralBjarngrimId && ret.ToUnit().HasAura("Whirlwind") && Me.IsDps && Me.IsMelee())
                            return true;
                        if (ret.Entry == LokenId && _lightningNovaIds.Contains(ret.ToUnit().CastingSpellId) && Me.IsMelee())
                            return true;
                    }
                    return false;
                });
        }

        public override void IncludeTargetsFilter(List<WoWObject> incomingunits, HashSet<WoWObject> outgoingunits)
        {
            foreach (var obj in incomingunits)
            {
                var unit = obj as WoWUnit;
                if (unit != null) { }
            }
        }

        public override void WeighTargetsFilter(List<Targeting.TargetPriority> units)
        {
            foreach (var priority in units)
            {
                var unit = priority.Object as WoWUnit;
                if (unit != null)
                {
                    if (unit.Entry == StormforgedLieutenantId && StyxWoW.Me.IsDps)
                        priority.Score += 500;
                    else if (unit.Entry == StormforgedMenderId && StyxWoW.Me.IsDps)
                        priority.Score += 600;
                }
            }
        }

        public override DungeonPathForkInfo[] PathForks { get; } =
            {
                new DungeonPathForkInfo(
                    rightSideDivider: new Vector3(1259.816f, 72.22592f, 33.50554f),
                    rightSideFromEntranceMoveTo:  new Vector3(1264.937f, 51.62081f, 33.50554f),
                    rightSideTowardsEntranceMoveTo: new Vector3(1287.328f, 101.89f, 34.6474f),

                    leftSideDivider: new Vector3(1412.935f, 35.15359f, 50.03821f),
                    leftSideFromEntranceMoveTo: new Vector3(1375.218f, 14.61286f, 49.80734f),
                    leftSideTowardsEntranceMoveTo: new Vector3(1375.553f, 55.91578f, 50.0383f),

                    shouldTakeRightSide: () => ScriptHelpers.WillPullAggroAtLocation(new Vector3(1395.28f, 47.64f, 50.04f))
                    )
            };

        #endregion


        [EncounterHandler(56027, "Stormherald Eljrrin", Mode = CallBehaviorMode.Proximity, BossRange = 35)]
        public Composite QuestPickupHandler()
        {
            WoWUnit unit = null;
            return new PrioritySelector(
                ctx => unit = ctx as WoWUnit,
                new Decorator(
                    ctx => !Me.Combat && !ScriptHelpers.WillPullAggroAtLocation(unit.Location) && unit.QuestGiverStatus == QuestGiverStatus.Available,
                    ScriptHelpers.CreatePickupQuest(ctx => unit)),
                new Decorator(
                    ctx => !Me.Combat && !ScriptHelpers.WillPullAggroAtLocation(unit.Location) && unit.QuestGiverStatus == QuestGiverStatus.TurnIn,
                    ScriptHelpers.CreateTurninQuest(ctx => unit)));
        }

        private LocalPlayer Me
        {
            get { return StyxWoW.Me; }
        }

        private readonly CircularQueue<Vector3> _volkhanCleartrashPath = new CircularQueue<Vector3>
        {
            new Vector3(1361.804f, -188.0309f, 52.02539f),
            new Vector3(1366.668f, -145.0833f, 52.0296f),
            new Vector3(1362.529f, -184.9581f, 52.02528f),
            new Vector3(1303.465f, -190.1832f, 52.02384f),
            new Vector3(1299.959f, -140.8916f, 52.00739f)
        };

        private WoWUnit _sparks;

        private const uint SlagId = 28585;
        private const uint StormforgedLieutenantId = 29240;
        private const uint GeneralBjarngrimId = 28586;
        private const uint StormforgedMenderId = 28582;
        private const uint SparkofIonarId = 28926;

        [EncounterHandler(28586, "General Bjarngrim", Mode = CallBehaviorMode.Proximity, BossRange = 300)]
        public Composite GeneralBjarngrimEncounter()
        {
            WoWUnit boss = null;
            var runToPoint = new Vector3(1331.974f, 101.1538f, 40.18048f);
            AddAvoidObject(() => Me.IsFollower() && !Me.IsCasting, 8, o => o.Entry == GeneralBjarngrimId && (o.ToUnit().HasAura("Whirlwind") || Me.IsRange() && !o.ToUnit().IsMoving));
            AddAvoidUnitCone(() => !Me.IsTank(), 0, 8, 180, u => u.Entry == GeneralBjarngrimId && !u.IsMoving && u.CurrentTarget != Me && u.Combat);

            return new PrioritySelector(
                ctx => boss = ctx as WoWUnit,
                // run from boss if tank and I'm fighting stuff or he's near adds that would aggro if boss is pulled.
                new Decorator(
                    ctx =>
                    StyxWoW.Me.IsLeader() && !boss.Combat && boss.DistanceSqr <= 75 * 75 &&
                    (StyxWoW.Me.IsActuallyInCombat || ScriptHelpers.GetUnfriendlyNpsAtLocation(boss.Location, 35, u => u.Entry != StormforgedLieutenantId && u != boss).Any()),
                    new Sequence(ScriptHelpers.CreateMoveToContinue(ctx => boss.DistanceSqr <= 90 * 90 && !boss.Combat, ctx => runToPoint, true))),
                new Decorator(
                    ctx => boss.Combat,
                    new PrioritySelector(
                        ScriptHelpers.CreateTankFaceAwayGroupUnit(8))));
        }

        [EncounterHandler(28587, "Volkhan", Mode = CallBehaviorMode.Proximity, BossRange = 110)]
        public Func<WoWUnit, Task<bool>> VolkhanEncounter()
        {
            WoWUnit volkhan = null;
            var roomCenterLoc = new Vector3(1331.7f, -165.3561f, 52.02283f);
            var shatteringStompIds = new[] { 52237, 59529 };
            const uint brittleGolemId = 28681;
            AddAvoidObject(() => volkhan != null && volkhan.IsValid && shatteringStompIds.Contains(volkhan.CastingSpellId), 10, brittleGolemId);

            return async boss =>
            {
                volkhan = boss;
                if (ScriptHelpers.IsBossAlive("General Bjarngrim"))
                    return false;

                if (StyxWoW.Me.IsTank() &&
                    ScriptHelpers.GetUnfriendlyNpsAtLocation(roomCenterLoc, 51, u => u.Z >= 50 && u != boss).Any() &&
                    (Targeting.Instance.FirstUnit == null || Targeting.Instance.FirstUnit.DistanceSqr > 25 * 25))
                {
                    if (StyxWoW.Me.Location.Distance2DSquared(_volkhanCleartrashPath.Peek()) < 5 * 5)
                        _volkhanCleartrashPath.Dequeue();
                    return (await CommonCoroutines.MoveTo(_volkhanCleartrashPath.Peek())).IsSuccessful();
                }
                return false;
            };
        }

        [EncounterHandler(28546, "Ionar", Mode = CallBehaviorMode.CurrentBoss)]
        public Composite StatueEncounter()
        {
            WoWUnit boss = null;
            return new PrioritySelector(
                ctx => boss = ctx as WoWUnit,
                // for the statues that come alive..
                new Decorator(
                    ctx => StyxWoW.Me.IsTank() && (boss == null || !boss.Combat) && StyxWoW.Me.Combat && Targeting.Instance.FirstUnit == null && StyxWoW.Me.IsMoving,
                    new Action(ctx => WoWMovement.MoveStop())));
        }

        [EncounterHandler(28926, "Spark of Ionar")]
        [EncounterHandler(28546, "Ionar")]
        public Composite IonarEncounter()
        {
            WoWUnit boss = null;


            AddAvoidObject(
                () => Me.IsFollower(),
                8,
                u => u is WoWPlayer && u != StyxWoW.Me && (u.ToPlayer().HasAura("Static Overload") || Me.HasAura("Static Overload")));

            var tankLoc = new Vector3(1081.995f, -261.8092f, 61.20797f);
            var runtoLoc = new Vector3(1177.047f, -231.855f, 52.36805f);
            var disperseTimer = new WaitTimer(TimeSpan.FromSeconds(5));

            return new PrioritySelector(
                ctx =>
                {
                    _sparks = ObjectManager.GetObjectsOfType<WoWUnit>().Where(u => u.Entry == 28926).OrderBy(u => u.DistanceSqr).FirstOrDefault();
                    return boss = ctx as WoWUnit;
                },
                new Action(
                    ctx =>
                    {
                        if (boss != null && boss.CastingSpellId == 52770)
                            disperseTimer.Reset();
                        return RunStatus.Failure;
                    }),
                new Decorator(
                    ctx => !disperseTimer.IsFinished || (_sparks != null && _sparks.DistanceSqr <= 20 * 20),
                    new Action(ctx => Navigator.GetRunStatusFromMoveResult(Navigator.MoveTo(runtoLoc)))),
                new Decorator(ctx => _sparks != null && Me.IsTank(), new ActionAlwaysSucceed()),

                new Decorator(ctx => Me.IsLeader() && boss.CurrentTargetGuid == StyxWoW.Me.Guid, ScriptHelpers.CreateTankUnitAtLocation(ctx => tankLoc, 7)));
        }

        private const uint LokenId = 28923;
        private readonly int[] _lightningNovaIds = new int[] { 59835, 52960 };

        [EncounterHandler(28923, "Loken")]
        public Composite LokenEncounter()
        {
            WoWUnit boss = null;

            AddAvoidObject(() => true, 20, o => o.Entry == LokenId && _lightningNovaIds.Contains(o.ToUnit().CastingSpellId));

            return new PrioritySelector(
                ctx => boss = ctx as WoWUnit,
                new Decorator(
                    ctx => StyxWoW.Me.IsRange() && boss.DistanceSqr > 13 * 13,
                    new Action(ctx => Navigator.GetRunStatusFromMoveResult(Navigator.MoveTo(WoWMathHelper.CalculatePointFrom(StyxWoW.Me.Location, boss.Location, 10))))));
        }
    }

    public class HallsOfLightningTimewalking : HallsOfLightning
    {
        public override uint DungeonId => 1018;
    }
}