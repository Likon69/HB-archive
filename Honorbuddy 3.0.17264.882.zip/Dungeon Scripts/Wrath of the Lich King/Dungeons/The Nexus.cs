
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Numerics;
using System.Threading.Tasks;
using CommonBehaviors.Actions;
using Styx;
using Styx.Common.Helpers;
using Styx.CommonBot;
using Styx.Helpers;

using Styx.Pathing;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using Styx.TreeSharp;
using Action = Styx.TreeSharp.Action;

using Bots.DungeonBuddy.Profiles;
using Bots.DungeonBuddy.Attributes;
using Bots.DungeonBuddy.Helpers;
using Buddy.Coroutines;
using Styx.Common;
using Styx.CommonBot.Coroutines;

namespace Bots.DungeonBuddy.Dungeon_Scripts.Wrath_of_the_Lich_King
{
    public class TheNexus : Dungeon
    {
        #region Overrides of Dungeon

        public override uint DungeonId { get { return 225; } }

        public override Vector3 Entrance
        {
            get { return new Vector3(3900.531f, 6985.386f, 69.4887f); }
        }

        public override Vector3 ExitLocation
        {
            get { return new Vector3(145.4159f, -15.77039f, -16.63676f); }
        }

        private readonly WaitTimer _kiteCrystallineFrayerTimer = WaitTimer.FiveSeconds;

        public override void RemoveTargetsFilter(List<WoWObject> units)
        {
            units.RemoveAll(
                obj =>
                {
                    if (obj.Entry == AnomalusId && ((WoWUnit)obj).HasAura("Rift Shield"))
                        return true;
                    // forces tank to move
                    if (obj.Entry == CrystallineFrayerId && Me.IsTank() && Me.Combat)
                    {
                        _kiteCrystallineFrayerTimer.Reset();
                        return true;
                    }
                    return false;
                });
        }

        public override void IncludeTargetsFilter(List<WoWObject> incomingunits, HashSet<WoWObject> outgoingunits)
        {
            foreach (var obj in incomingunits)
            {
                var unit = obj as WoWUnit;
                if (unit != null)
                {
                }
            }
        }

        public override void WeighTargetsFilter(List<Targeting.TargetPriority> units)
        {
            foreach (var priority in units)
            {
                var unit = priority.Object as WoWUnit;
                if (unit != null)
                {
                    if (Me.IsDps && unit.Entry == ChaoticRiftId)
                        priority.Score += 500;
                    else if (unit.Entry == CrystallineFrayerId)
                        priority.Score -= 10000;
                }
            }
        }

        public override void IncludeLootTargetsFilter(List<WoWObject> incomingunits, HashSet<WoWObject> outgoingObjects)
        {
            foreach (var obj in incomingunits)
            {
                var gObj = obj as WoWGameObject;
                if (gObj != null)
                {
                    if (ScriptHelpers.SupportsQuesting && BerinandsResearchId == obj.Entry
                        && gObj.DistanceSqr < 35 * 35 && gObj.ZDiff < 10
                        && !ScriptHelpers.WillPullAggroAtLocation(gObj.Location) && gObj.CanUse())
                    {
                        outgoingObjects.Add(obj);
                    }
                }
            }
        }

        public override DungeonPathForkInfo[] PathForks { get; } =
        {
                new DungeonPathForkInfo(
                    rightSideDivider: new Vector3(405.3071f, -24.15804f, -16.63672f),
                    rightSideFromEntranceMoveTo: new Vector3(2424.725f, 1086.823f, 35.35196f),
                    rightSideTowardsEntranceMoveTo: new Vector3(2539.162f, 1042.772f, 46.69485f),
                    leftSideDivider: new Vector3(407.5223f, 17.63889f, -16.63672f),
                    leftSideFromEntranceMoveTo: new Vector3(417.8698f, 184.2527f, -35.01971f),
                    leftSideTowardsEntranceMoveTo: new Vector3(392.3523f, 156.3838f, -35.01959f),
                    shouldTakeRightSide: () => false,
                    
                    // Take this fork whenever Keristrasza is alive.
                    shouldHandleForkAdditionalCondition: moveto => ScriptHelpers.IsBossAlive("Keristrasza") && BossManager.CurrentBoss != null && BossManager.CurrentBoss.Name != "Ormorok the Tree-Shaper"
                    )
            };

        #endregion

        private const uint AnomalusId = 26763;
        private const uint ChaoticRiftId = 26918;

        private const uint CrystallineFrayerId = 26793;
        private const uint OrmorokId = 26794;


        private LocalPlayer Me
        {
            get { return StyxWoW.Me; }
        }

        #region Quest

        [EncounterHandler(55531, "Warmage Kaitlyn", Mode = CallBehaviorMode.Proximity, BossRange = 35)]
        [EncounterHandler(55536, "Image of Warmage Kaitlyn", Mode = CallBehaviorMode.Proximity, BossRange = 35)]
        [EncounterHandler(55537, "Image of Warmage Kaitlyn", Mode = CallBehaviorMode.Proximity, BossRange = 35)]
        [EncounterHandler(55535, "Image of Warmage Kaitlyn", Mode = CallBehaviorMode.Proximity, BossRange = 35)]
        public async Task<bool> QuestPickupTurninHandler(WoWUnit npc)
        {
            if (Me.Combat || ScriptHelpers.WillPullAggroAtLocation(npc.Location))
                return false;
            // pickup or turnin quests if any are available.
            return npc.HasQuestAvailable(true)
                ? await ScriptHelpers.PickupQuest(npc)
                : npc.HasQuestTurnin() && await ScriptHelpers.TurninQuest(npc);
        }

        private const uint QuestId_PostponingTheInevitiable = 11905;
        private const uint ItemId_InterdimentionalRefabricator = 35479;
        private const uint BerinandsResearchId = 192788;

        [LocationHandler(637.8363, -313.2727, -9.455564, 50, "Postponing the inevitable")]
        public Func<Vector3, Task<bool>> TheRiftLocationHandler()
        {
            return async loc =>
            {
                if (!ScriptHelpers.SupportsQuesting || Me.Combat || !ScriptHelpers.HasQuest(QuestId_PostponingTheInevitiable) ||
                    ScriptHelpers.IsQuestInLogComplete(QuestId_PostponingTheInevitiable))
                {
                    return false;
                }

                var questItem = Me.BagItems.FirstOrDefault(i => i.Entry == ItemId_InterdimentionalRefabricator);

                // Abandon quest so it's picked up again if item is missing
                if (questItem == null)
                {
                    StyxWoW.Me.QuestLog.AbandonQuestById(QuestId_PostponingTheInevitiable);
                    await CommonCoroutines.SleepForRandomUiInteractionTime();
                    return true;
                }

                if (!ScriptHelpers.AtLocation(Me.Location, loc, 4))
                    return (await CommonCoroutines.MoveTo(loc)).IsSuccessful();

                await CommonCoroutines.StopMoving();
                questItem.Use();
                await Coroutine.Sleep(3000);
                await CommonCoroutines.SleepForRandomUiInteractionTime();
                return true;
            };
        }

        #endregion

        private const int AuraIdIntenseCold = 48095;

        [EncounterHandler(0, "Root Handler")]
        public Func<WoWUnit, Task<bool>> RootHandler()
        {
            return async boss =>
            {
                WoWAura aura = Me.GetAuraById(AuraIdIntenseCold);
                // Don't bother trying to jump when we have Crystallize, you can't move.
                if (!Me.HasAura("Crystallize") && aura != null && !Me.IsCasting && (aura.StackCount >= 3 || !Me.Combat))
                {
                    try
                    {
                        WoWMovement.Move(WoWMovement.MovementDirection.JumpAscend);
                        await Coroutine.Sleep(200);
                    }
                    finally
                    {
                        WoWMovement.MoveStop(WoWMovement.MovementDirection.JumpAscend);
                    }
                    return true;
                }
                return false;
            };
        }

        [EncounterHandler(26731, "Grand Magus Telestra", Mode = CallBehaviorMode.Proximity, BossRange = 65)]
        public Composite GrandMagusTelestraEncounter()
        {
            var trashTankLoc = new Vector3(545.6187f, 108.4139f, -16.63844f);
            var trashLoc = new Vector3(518.0992f, 90.58775f, -16.12559f);

            WoWUnit boss = null, trash = null;
            return new PrioritySelector(
                ctx => boss = ctx as WoWUnit,
                new Decorator(
                    ctx => !boss.Combat && !Me.Combat,
                    new PrioritySelector(
                        ctx => trash = ScriptHelpers.GetUnfriendlyNpsAtLocation(trashLoc, 10, u => true).FirstOrDefault(),
                        ScriptHelpers.CreatePullNpcToLocation(ctx => trash != null, ctx => trash, ctx => trashTankLoc, 10)))
                );
        }


        [EncounterHandler(26794, "Ormorok the Tree-Shaper", Mode = CallBehaviorMode.CurrentBoss, BossRange = 100)]
        public Composite OrmorokTheTreeShaperGauntletBehavior()
        {
            return new PrioritySelector(
                new Decorator(ctx => Me.IsTank() && Me.Combat && Targeting.Instance.IsEmpty() && !_kiteCrystallineFrayerTimer.IsFinished,
                    new Action(ctx => Navigator.MoveTo(_ormorokRoomCenterLoc)))
                );
        }

        private readonly Vector3 _ormorokRoomCenterLoc = new Vector3(264.9587f, -225.4145f, -9.100944f);


        [EncounterHandler(26794, "Ormorok the Tree-Shaper", BossRange = 100)]
        public Composite OrmorokTheTreeShaperEncounter()
        {
            WoWUnit boss = null;
            const uint crystalSpikeTriggerId = 27079;
            AddAvoidObject(() => true, 4, crystalSpikeTriggerId);

            return new PrioritySelector(ctx => boss = ctx as WoWUnit);
        }

        private const uint MobId_Keristrasza = 26723;

        [EncounterHandler(MobId_Keristrasza, "Keristrasza", Mode = CallBehaviorMode.Proximity)]
        public Func<WoWUnit, Task<bool>> KeristraszaEncounter()
        {
            // avoid front and rear portions of Keristrasza if not a tank
            AddAvoidUnitCone(() => !Me.IsTank(), 0, 15, 100, u => u.Entry == MobId_Keristrasza && !u.IsMoving && u.CurrentTarget != Me && u.Combat);
            AddAvoidUnitCone(() => !Me.IsTank(), 180, 15, 100, u => u.Entry == MobId_Keristrasza && !u.IsMoving && u.CurrentTarget != Me && u.Combat);
            // Stay at around 15 yards if we are ranged.
            AddAvoidObject<WoWUnit>(() => Me.IsRange(), 15f, u => u.Entry == MobId_Keristrasza);

            return async boss =>
            {
                if (!boss.Combat)
                {
                    WoWGameObject sphere = ObjectManager.GetObjectsOfType<WoWGameObject>().Where(
                        o => (o.Entry == 188526 || o.Entry == 188527 || o.Entry == 188528) && o.CanUse()).MinByOrDefault(
                        o => o.DistanceSqr);

                    if (ScriptHelpers.GetUnfriendlyNpsAtLocation(boss.Location, 50f, u => u != boss).Any())
                    {
                        // clear the room,
                        await ScriptHelpers.ClearArea(boss.Location, 40, u => u != boss);
                        return false;
                    }

                    if (Me.IsLeader() && sphere != null && Targeting.Instance.IsEmpty() && boss.DistanceSqr < 40 * 40)
                        return await ScriptHelpers.InteractWithObject(sphere);
                }

                GroupMember groupMember = ScriptHelpers.GroupMembers.FirstOrDefault(
                    gm => gm.Player != null && gm.Player.GetAuraById(AuraIdIntenseCold)?.StackCount >= 3 && gm.Player.HasAura("Crystallize"));

                WoWPlayer crystallizeDispelTarget = groupMember?.Player;

                // Dispel Crystallize off of players with high Intense Cold stacks, so they can reset their stacks
                if (crystallizeDispelTarget != null)
                {
                    if (await ScriptHelpers.DispelFriendlyUnit("Crystallize", ScriptHelpers.PartyDispelType.Magic, crystallizeDispelTarget))
                        return true;
                }

                // Keep Keristrasza facing away from ranged DPS/healer to prevent spreading Crystalfire Breath damage
                return await ScriptHelpers.TankFaceUnitAwayFromGroup(15);
            };
        }
    }

    public class TheNexusTimewalking : TheNexus
    {
        public override uint DungeonId => 1019;
    }
}