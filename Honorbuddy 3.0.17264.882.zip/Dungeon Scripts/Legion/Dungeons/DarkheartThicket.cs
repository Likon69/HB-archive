﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Numerics;
using System.Reflection;
using System.Threading.Tasks;
using System.Windows.Markup;
using Bots.DungeonBuddy.Attributes;
using Bots.DungeonBuddy.Enums;
using Bots.DungeonBuddy.Helpers;
using Buddy.Coroutines;
using Styx;
using Styx.Common;
using Styx.Common.Helpers;
using Styx.CommonBot;
using Styx.CommonBot.Coroutines;
using Styx.CommonBot.POI;
using Styx.CommonBot.Routines;
using Styx.Helpers;
using Styx.Pathing;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using Styx.WoWInternals.WoWObjects.AreaTriggerShapes;

// ReSharper disable CheckNamespace


namespace Bots.DungeonBuddy.DungeonScripts.Legion
// ReSharper restore CheckNamespace
{
    #region Normal Difficulty

    public class DarkheartThicket : Dungeon
    {
        #region Overrides of Dungeon

        public override uint DungeonId => 1201;

        public override Vector3 Entrance => new Vector3(3824.023f, 6355.737f, 185.547f);

        public override Vector3 ExitLocation => new Vector3(3265.236f, 1831.2f, 239.9943f);

        public override void RemoveTargetsFilter(List<WoWObject> units)
        {
            var stranglingRootGuid =
                (Me.GetAuraByName("Strangling Roots") ??
                 Me.PartyMembers.Select(p => p.GetAuraByName("Strangling Roots")).FirstOrDefault())?.CreatorGuid;

            units.RemoveAll(
                ret =>
                {
                    var unit = ret as WoWUnit;
                    if (unit == null)
                        return false;

                    if (unit.Entry == MobId_StranglingRoots && (!stranglingRootGuid.HasValue || stranglingRootGuid.Value != unit.Guid))
                        return true;

                    return false;
                });
        }

        public override void IncludeTargetsFilter(List<WoWObject> incomingunits, HashSet<WoWObject> outgoingunits)
        {
            foreach (var obj in incomingunits)
            {
                var unit = obj as WoWUnit;
                if (unit != null)
                {
                }
            }
        }

        public override void WeighTargetsFilter(List<Targeting.TargetPriority> units)
        {
            var isTank = Me.IsTank;

            foreach (var priority in units)
            {
                var unit = priority.Object as WoWUnit;
                if (unit != null)
                {
                    switch (unit.Entry)
                    {
                        case MobId_StranglingRoots:
                            priority.Score  += isTank ? -5000 : 5000;
                            break;

                        case MobId_HatespawnWhelpling:
                            // fight other mobs if whelps have my aggro
                            if (isTank && unit.Aggro)
                                priority.Score -= 5000;
                            break;
                    }
                }
            }
        }

        public override void OnEnter()
        {
            var displayPugGroupWarning = DungeonBuddySettings.Instance.PartyMode == PartyMode.Off ||
                (DungeonBuddySettings.Instance.PartyMode == PartyMode.Leader &&
                DungeonBuddySettings.Instance.PartyMembers.Count(s => !string.IsNullOrWhiteSpace(s)) < 4);

            if (displayPugGroupWarning)
            {
                Alert.Show(
                    "Dungeon not tested in PUGs",
                    $"{Name} dungeon has not been tested in PUGs so it's very important to not leave toon unattended",
                    15);
            }
        }


        public override async Task<bool> HandleMovement(MoveToParameters moveToParameters)
        {
            if (await HandleLastBossAreaNavigation(moveToParameters.Location))
                return true;

            return false;
        }


        public override DungeonStuckHandler[] StuckHandlers { get; } = {
            new RockStuckHandler(new Vector3(3088.177f, 1578.699f, 143.1691f), 5, 2,
                new Vector3(3092.326f, 1569.236f, 137.4397f), "Rock 1"),
            new RockStuckHandler(new Vector3(3091.131f, 1600.27f, 147.9177f), 5, 2,
                new Vector3(3106.983f, 1601.196f, 138.2564f), "Rock 2"),
            new RockStuckHandler(new Vector3(3079.271f, 1574.706f, 142.1789f), 5, 2,
                new Vector3(3087.62f, 1569.958f, 138.2564f), "Rock 3"),
            new RockStuckHandler(new Vector3(3050.261f, 1556.622f, 143.8157f), 5, 2,
                new Vector3(3058.784f, 1552.789f, 138.2564f), "Rock 4"),
            new RockStuckHandler(new Vector3(3070.835f, 1643.248f, 144.9376f), 5, 2,
                new Vector3(3085.721f, 1639.212f, 137.7676f), "Rock 5"),
            new RockStuckHandler(new Vector3(3128.248f, 1592.397f, 143.2345f), 7, 2,
                new Vector3(3126.135f, 1599.842f, 137.1728f), "Rock 6"),
            new RockStuckHandler(new Vector3(3072.669f, 1577.249f, 141.4829f), 7, 2,
                new Vector3(3073.524f, 1571.65f, 138.471f), "Rock 7"),
            new RockStuckHandler(new Vector3(3183.13f, 1916.453f, 221.776f), 7, 3,
                new Vector3(3176.761f, 1905.104f, 217.8304f), "Slope by entrance"),
            new RockStuckHandler(new Vector3(2984.491f, 1808.932f, 143.3518f), 7, 3,
                new Vector3(2980.173f, 1800.935f, 141.5858f), "Rock 8"),
            new RockStuckHandler(new Vector3(3089.738f, 1969.919f, 207.763f), 4, 2,
                new Vector3(3091.843f, 1962.533f, 204.1932f), "Pods 1"),                
        };


        private class RockStuckHandler : DungeonStuckHandler
        {
            private Vector3 _stuckLocation;
            private readonly float _stuckRadius;
            private readonly float _stuckAreaZDiff;

            public RockStuckHandler(Vector3 stuckLocation, float stuckRadius, float stuckAreaZDiff, Vector3 ctmLocation,
                string name)
            {
                _stuckLocation = stuckLocation;
                _stuckRadius = stuckRadius;
                _stuckAreaZDiff = stuckAreaZDiff;
                UnstickMoveTo = ctmLocation;
                StuckAreaName = name;
            }

            protected override bool IsStuck
                =>
                    StyxWoW.Me.Location.DistanceSquared(_stuckLocation) < _stuckRadius * _stuckRadius &&
                    Math.Abs(Me.Z - _stuckLocation.Z) < _stuckAreaZDiff;

            protected override Vector3 UnstickMoveTo { get; }
            protected override string StuckAreaName { get; }
        }

        #endregion

        #region Root

        protected static LocalPlayer Me => StyxWoW.Me;


        [EncounterHandler(0, "Root Handler")]
        public Func<WoWUnit, Task<bool>> RootBehavior()
        {
            return async npc =>
            {
                return false;
            };
        }



        #endregion


        #region Archdruid Glaidalis

        #region Trash

        private const int SpellId_StarShower = 200658;
        private const int SpellId_Despair = 200642;
        private const int MissileSpellId_StarShower1 = 204407;
        private const int MissileSpellId_StarShower2 = 204383;

        private const uint MobId_DreadsoulRuiner = 95771;

        [EncounterHandler(MobId_DreadsoulRuiner, "Dreadsoul Ruiner")]
        public Func<WoWUnit, Task<bool>> DreadsoulRuinerHandler()
        {
            AddAvoidLocation(() => true, 3, missile => missile.ImpactPosition,
                () =>
                    WoWMissile.InFlightMissiles.Where(
                        m => m.SpellId == MissileSpellId_StarShower1 || m.SpellId == MissileSpellId_StarShower2));


            return async boss =>
            {
                return await ScriptHelpers.InterruptCast(boss, SpellId_StarShower, SpellId_Despair);
            };
        }

        private const uint MobId_MindshatteredScreecher = 95769;
        private const int SpellId_UnnervingScreech = 200630;


        [EncounterHandler(MobId_MindshatteredScreecher, "Mindshattered Screecher")]
        public Func<WoWUnit, Task<bool>> MindshatteredScreecherHandler()
        {
            return async boss =>
            {
                return await ScriptHelpers.InterruptCast(boss, SpellId_UnnervingScreech);
            };
        }

        private const uint MobId_FesterhideGrizzly = 95779;

        [EncounterHandler(MobId_FesterhideGrizzly, "Festerhide Grizzly")]
        public Func<WoWUnit, Task<bool>> FesterhideGrizzlyHandler()
        {
            AddAvoidUnitCone(() => !Me.IsTank, 0, 15, 90, unit => unit.Entry == MobId_FesterhideGrizzly && unit.CurrentTargetGuid != Me.Guid);

            return async boss => { return false; };
        }

        private const uint MobId_FrenziedNightclaw = 95772;
        [LocationHandler(3146.373f, 1972.733f, 214.4704f, 30, "1st Dangerous Trash Pull Before Archdruid Glaidalis")]
        public Func<Vector3, Task<bool>> FirstBigTrashPullBeforeArchdruidGlaidalis()
        {
            var trashLoc1 = new Vector3(3121.975f, 1975.475f, 207.5191f);
            var trashLoc2 = new Vector3(3101.638f, 1993.348f, 205.4648f);
            var trashLoc3 = new Vector3(3142.649f, 2028.644f, 204.5187f);
            var trash3TankLoc = new Vector3(3142.649f, 2028.644f, 204.5187f);
            var safeLoc = new Vector3(3128.622f, 2021.303f, 205.4724f);
            return async loc =>
            {
                var trash = ScriptHelpers.GetUnfriendlyNpsAtLocation(trashLoc1, 10).FirstOrDefault()
                    ?? ScriptHelpers.GetUnfriendlyNpsAtLocation(trashLoc2, 10).FirstOrDefault();

                if (trash != null)
                    return await ScriptHelpers.PullNpcToLocation(() => trash != null, trash, loc, 5000);

                trash = ScriptHelpers.GetUnfriendlyNpsAtLocation(trashLoc3, 35, u => u.Entry == MobId_FrenziedNightclaw).FirstOrDefault();
                return await ScriptHelpers.PullNpcToLocation(() => trash != null, () => trash.Location.DistanceSquared(safeLoc) < 15 * 15, trash, trash3TankLoc, trash3TankLoc, 6000);
            };
        }

        [LocationHandler(3131.92f, 1984.413f, 205.4949f, 25, "Second Dangerous Trash Pull Before Archdruid Glaidalis")]
        public Func<Vector3, Task<bool>> SecondBigTrashPullBeforeArchdruidGlaidalis()
        {
            var trashLoc = new Vector3(3103.678f, 1950.905f, 204.8633f);

            return async loc =>
            {
                var trash = ScriptHelpers.GetUnfriendlyNpsAtLocation(trashLoc, 35).FirstOrDefault();
                return await ScriptHelpers.PullNpcToLocation(() => trash != null, trash, loc, 6000);
            };
        }


        #endregion

        private const uint AreaTriggerId_Nightfall = 10154;
        private const int MissileSpellId_Nightfall = 198401;
        private const uint MobId_ArchdruidGlaidalis = 96512;

        [EncounterHandler(MobId_ArchdruidGlaidalis, "Archdruid Glaidalis")]
        public Func<WoWUnit, Task<bool>> ArchdruidGlaidalisHandler()
        {
            AddAvoidObject<WoWAreaTrigger>(4, AreaTriggerId_Nightfall);
            AddAvoidLocation(() => true, 4, missile => missile.ImpactPosition, () => WoWMissile.InFlightMissiles.Where(m => m.SpellId == MissileSpellId_Nightfall));
            AddAvoidUnitCone(() => !Me.IsTank, 0, 8, 60, u => u.Entry == MobId_ArchdruidGlaidalis && u.Combat && u.CurrentTargetGuid != Me.Guid);

            return async boss =>
            {
                return false;
            };
        }

        #endregion

        #region Oakheart

        #region Trash
        private const uint MobId_VilethornBlossom = 99360;
        private const uint MobId_RootBurstInvisibleStalker = 101958;

        [EncounterHandler(MobId_VilethornBlossom, "Vilethorn Blossom")]
        public Func<WoWUnit, Task<bool>> VilethornBlossomHandler()
        {
            AddAvoidObject<WoWUnit>(7, MobId_RootBurstInvisibleStalker);

            return async boss => false;
        }

        private const uint AreaTriggerId_VileMushroom = 10193;
        private const uint MobId_RotheartKeeper = 99359;
        private const int MissileSpellId_VileMushroom = 220369;

        [EncounterHandler(MobId_RotheartKeeper, "Rotheart Keeper")]
        public Func<WoWUnit, Task<bool>> RotheartKeeperHandler()
        {
            AddAvoidObject<WoWUnit>(6, AreaTriggerId_VileMushroom);
            AddAvoidLocation(() => true, 6, missile => missile.ImpactPosition, () => WoWMissile.InFlightMissiles.Where(m => m.SpellId == MissileSpellId_VileMushroom));

            return async boss => false;
        }

        #endregion

        private const uint MobId_Oakheart = 103344;

        private const int SpellId_NightmareBreath = 204667;
        private const uint MobId_StranglingRoots = 100991;
        private const uint MobId_NightmareDweller = 101991;

        [EncounterHandler(MobId_Oakheart, "Oakheart", Mode = CallBehaviorMode.Proximity)]
        public Func<WoWUnit, Task<bool>> OakheartHandler()
        {
            AddAvoidUnitCone(() => true, 0, 25, 60, 
                u => u.Entry == MobId_Oakheart && u.Combat 
                    && ((!Me.IsTank && u.CurrentTargetGuid != Me.Guid) || u.CastingSpellId == SpellId_NightmareBreath));

            AddAvoidObject<WoWUnit>(() => !Me.HasAura("Strangling Roots"), 2.5f, u => u.Entry == MobId_StranglingRoots);


            return async boss =>
            {
                if (!boss.Combat)
                {
                    if (await ScriptHelpers.ClearArea(boss.Location, 100, u => u.Entry == MobId_NightmareDweller))
                        return true;

                    return false;
                }

                if (await ScriptHelpers.CastActiveMitigationSpell(boss))
                    return true;

                return false;
            };
        }

        #endregion

        #region Dresaron

        #region Trash

        private const int SpellId_BloodAssault = 201226;
        private const int MissileSpellId_BloodBomb = 201272;

        private const uint MobId_BloodtaintedFury = 100531;

        [EncounterHandler(MobId_BloodtaintedFury, "BloodtaintedFury")]
        public Func<WoWUnit, Task<bool>> BloodtaintedFuryHandler()
        {
            WoWUnit bloodtaintedFury = null;

            AddAvoidLine<WoWUnit>(() => true, u => u.Location, u => u.Rotation, u => 20, u => 6, u => u.Entry == MobId_BloodtaintedFury && u.CastingSpellId == SpellId_BloodAssault);

            AddAvoidLocation(() => true, 8, missile => missile.ImpactPosition, () => WoWMissile.InFlightMissiles.Where(m => m.SpellId == MissileSpellId_BloodBomb));

            return async boss =>
            {
                bloodtaintedFury = boss;
                return false;
            };
        }

        #endregion


        private const int SpellId_DownDraft = 199345;


        private const uint MobId_CorruptedDragonEgg = 101072;
        private const uint MobId_CorruptedEgg = 100533;
        private const uint MobId_Dresaron = 99200;
        private const uint MobId_AcidBreathInvisibleStalker = 101078;
        private const uint MobId_HatespawnWhelpling = 101074;

        private const uint AreaTriggerId_FallingRocks = 10253;

        [EncounterHandler(MobId_Dresaron, "Dresaron", 80, CallBehaviorMode.Proximity)]
        public Func<WoWUnit, Task<bool>> DresaronHandler()
        {
            WoWUnit dresaron = null;

            var rightDoorEdge = new Vector3(3057.92f, 1530.719f, 138.4122f);
            var leftDoorEdge = new Vector3(3062.269f, 1524.423f, 138.0279f);

            var randomPointInsideRoom = WoWMathHelper.GetRandomPointInCircle(new Vector3(3054.385f, 1523.222f, 138.0141f), 2);

            // Eggs encountered while moving to boss that spawn whelps when player moves near
            AddAvoidObject<WoWUnit>(5, u => u.Entry == MobId_CorruptedDragonEgg || u.Entry == MobId_CorruptedEgg, ignoreIfBlocking: true);

            AddAvoidUnitCone(
                () =>
                    !Me.IsTank ||
                    ObjectManager.GetObjectsOfType<WoWUnit>().Any(u => u.Entry == MobId_AcidBreathInvisibleStalker), 0,
                15, 80, 
                u => u.Entry == MobId_Dresaron && (Me.IsTank || u.CurrentTargetGuid != Me.Guid), 
                unit =>
                {
                    // Boss is flying so we need to bring the location to avoid down further...
                    var loc = unit.Location;

                    loc.Z = 138.4122f;
                    return loc;
                });


            var tankLoc = new Vector3(3032.412f, 1505.61f, 138.0186f);
            var capabilityHandle = CapabilityManager.Instance.CreateNewHandle();

            Func<WoWUnit, bool> castingDownDraft = unit => unit.HasAura(SpellId_DownDraft) || unit.CastingSpellId == SpellId_DownDraft;

            AddAvoidObject<WoWAreaTrigger>(() => true, a => ScriptHelpers.IsViable(dresaron) && castingDownDraft(dresaron) ? 10 : 8, AreaTriggerId_FallingRocks);

            return async boss =>
            {
                dresaron = boss;

                // deal with any trash attacking us
                if (!Targeting.Instance.IsEmpty() && !boss.Combat && Targeting.Instance.FirstUnit != boss)
                    return false;

                if (await ScriptHelpers.MoveInsideBossRoom(boss, leftDoorEdge, rightDoorEdge, randomPointInsideRoom))
                    return true;

                if (!boss.Combat)
                    return false;

                if (await ScriptHelpers.CastActiveMitigationSpell(boss))
                    return true;

                if (castingDownDraft(boss) && boss.Distance2D > 3 * 3)
                {
                    CapabilityManager.Instance.Update(capabilityHandle, CapabilityFlags.Movement, () => boss.IsValid && castingDownDraft(boss));
                    Navigator.PlayerMover.MoveTowards(boss.Location);
                    return false;
                }

                if (boss.HealthPercent > 10 && await ScriptHelpers.CastHeroism())
                    return true;

                // Stay near boss to avoid spawning 
                if (await ScriptHelpers.StayAtLocationWhile(() => !Me.IsTank && boss.IsValid && boss.Combat, boss.Location, boss.SafeName, 10))
                    return true;

                return false;
            };
        }

        #endregion

        #region Shade of Xavius

        #region Navigation

        private readonly Vector2[] _lastBossOutsideTunnel =
        {
            new Vector2(2980.651f, 1556.529f),
            new Vector2(2987.317f, 1615.694f),
            new Vector2(2875.983f, 1624.552f),
            new Vector2(2907.947f, 1561.863f),
        };

        private readonly Vector2[] _lastBossInsideTunnel =
        {
            new Vector2(2906.459f, 1567.843f),
            new Vector2(2891.656f, 1618.383f),
            new Vector2(2638.623f, 1346.049f),
            new Vector2(2708.18f, 1248.965f),
            new Vector2(2769.863f, 1292.604f),
        };

        private bool IsPointInLastBossArea(Vector3 point)
        {
            if (point.Z < 113 && WoWMathHelper.IsPointInPoly(point, _lastBossOutsideTunnel))
                return true;

            if (point.Z < 150 && WoWMathHelper.IsPointInPoly(point, _lastBossInsideTunnel))
                return true;

            return false;
        }

        private const uint MobId_MalfurionStormrage = 100652;
        private readonly Vector3 _malfurionStormrageLoc = new Vector3(2713.03f, 1330.03f, 128.3684f);
        private async Task<bool> HandleLastBossAreaNavigation(Vector3 destination)
        {
            if (!IsPointInLastBossArea(Me.Location) || IsPointInLastBossArea(destination))
                return false;

            if (Me.GroupInfo.LfgDungeonId != 0)
            {
                // port out if current lfg ID matches this dungeon, otherwise teleport into the other dungeon.
                Lua.DoString(Me.GroupInfo.LfgDungeonId == DungeonId ? "LFGTeleport(true)" : "LFGTeleport(false)");
            }

            var stormrage =
                ObjectManager.GetObjectsOfType<WoWUnit>().FirstOrDefault(u => u.Entry == MobId_MalfurionStormrage);

            if (stormrage == null)
                return (await CommonCoroutines.MoveTo(_malfurionStormrageLoc, "Malfurion Stormrage")).IsSuccessful();

            return await ScriptHelpers.TalkToNpc(stormrage, 1);
        }

        #endregion

        #region Trash

        private const int SpellId_DreadInferno = 201399;
        private const uint MobId_DreadfireImp = 100527;

        [EncounterHandler(MobId_DreadfireImp, "Dreadfire Imp")]
        public Func<WoWUnit, Task<bool>> DreadfireImpHandler()
        {
            return async boss => await ScriptHelpers.InterruptCast(boss, SpellId_DreadInferno);
        }

        private const uint MobId_TaintheartSummoner = 99366;
        [EncounterHandler(MobId_TaintheartSummoner, "Taintheart Summoner")]
        public Func<WoWUnit, Task<bool>> TaintheartSummonerHandler()
        {
            // Stay away from other players if has Curse of Isolation
            AddAvoidObject<WoWPlayer>(() => true, 6, p => !p.IsMe && p.IsAlive && (p.HasAura("Curse of Isolation") || Me.HasAura("Curse of Isolation")));

            return async boss =>
            {
                return await ScriptHelpers.DispelGroup("Curse of Isolation", ScriptHelpers.PartyDispelType.Curse);
            };
        }

        #endregion

        protected const uint MobId_ShadeofXavius = 99192;
        private const uint AreaTriggerId_GrowingParanoia = 10343;
        private const uint MobId_NightmareFire = 200067;
        private const int MissileSpellId_ApocalypticNightmare = 200067;

        [EncounterHandler(MobId_ShadeofXavius, "Shade of Xavius")]
        public Func<WoWUnit, Task<bool>> ShadeofXaviusHandler()
        {
            // Stay away from players with Growing Paranoia
            AddAvoidObject<WoWPlayer>(() => true, 5, p => !p.IsMe && p.IsAlive && (p.HasAura("Growing Paranoia") || Me.HasAura("Growing Paranoia")));
            AddAvoidLocation(() => true, 8, missile => missile.ImpactPosition, () => WoWMissile.InFlightMissiles.Where(m => m.SpellId == MissileSpellId_ApocalypticNightmare));
            AddAvoidObject<WoWUnit>(8, MobId_NightmareFire);

            return async boss =>
            {
                var fasteringRip = Me.RaidMembers.FirstOrDefault(p => p.HasAura("Festering Rip"));
                if (fasteringRip != null && await ScriptHelpers.DispelFriendlyUnit("Festering Rip", ScriptHelpers.PartyDispelType.Magic, fasteringRip))
                    return true;
                // ToDO Added Apocalyptic Fire
                return false;
            };
        }

        #endregion
    }

    #endregion

    #region Heroic Difficulty

    public class DarkheartThicketHeroic : DarkheartThicket
    {
        #region Overrides of Dungeon

        public override uint DungeonId => 1202;

        #endregion

        #region Shade of Xavius

        [EncounterHandler(MobId_ShadeofXavius, "Shade of Xavius")]
        public Func<WoWUnit, Task<bool>> ShadeofXaviusHeroicHandler()
        {
            return async boss =>
            {
                if (Me.IsDps)
                {
                    var cowardice = Me.PartyMembers.FirstOrDefault(p => !p.IsMe && p.HasAura("Cowardice"));
                    // Toons with the Cowardice debuf are silenced until someone moves close to them
                    if (cowardice != null)
                        return (await CommonCoroutines.MoveTo(cowardice.Location)).IsSuccessful();
                }
                return false;
            };
        }

        #endregion
    }

    #endregion
}
