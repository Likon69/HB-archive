﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Reflection;
using System.Threading.Tasks;
using Bots.DungeonBuddy.Attributes;
using Bots.DungeonBuddy.Enums;
using Bots.DungeonBuddy.Helpers;
using Bots.DungeonBuddy.Profiles;
using Buddy.Coroutines;
using CommonBehaviors.Actions;
using Styx;
using Styx.Common;
using Styx.Common.Helpers;
using Styx.CommonBot;
using Styx.CommonBot.Bars;
using Styx.CommonBot.Coroutines;
using Styx.CommonBot.Routines;
using Styx.Helpers;
using Styx.Patchables;
using Styx.Pathing;
using Styx.Pathing.Avoidance;
using Styx.TreeSharp;
using Styx.WoWInternals;
using Styx.WoWInternals.World;
using Styx.WoWInternals.WoWObjects;
using Styx.WoWInternals.WoWObjects.AreaTriggerShapes;
using Styx.CommonBot.POI;

// ReSharper disable CheckNamespace

namespace Bots.DungeonBuddy.DungeonScripts.Legion
// ReSharper restore CheckNamespace
{
    #region Normal Difficulty
    public class MawOfSouls : Dungeon
    {
        #region Overrides of Dungeon

        public override uint DungeonId => 1191;

        public override Vector3 Entrance { get; } = new Vector3(3430.797f, 1988.546f, 17.9667f);

        public override Vector3 ExitLocation { get; } = new Vector3(7161.093f, 7321.446f, 17.31403f);

        public override void RemoveTargetsFilter(List<WoWObject> units)
        {
            var isMelee = Me.IsMelee;
            units.RemoveAll(
                ret =>
                {
                    var unit = ret as WoWUnit;
                    if (unit == null)
                        return false;

                    if (unit.Entry == MobId_Helya && unit.HasAura("Submerged"))
                        return true;

                    if (isMelee && unit.Entry == MobId_YmironTheFallenKing && unit.CastingSpellId == SpellId_ScreamsoftheDead)
                        return true;

                    return false;
                });
        }

        public override void IncludeTargetsFilter(List<WoWObject> incomingunits, HashSet<WoWObject> outgoingunits)
        {
            var isTank = Me.IsTank;

            foreach (var obj in incomingunits)
            {
                var unit = obj as WoWUnit;
                if (unit != null)
                {
                    if (unit.Entry == MobId_SoulFragment && !isTank)
                        outgoingunits.Add(unit);
                }
            }
        }

        public override void WeighTargetsFilter(List<Targeting.TargetPriority> units)
        {
            var isDps = Me.IsDps;
            foreach (var priority in units)
            {
                var unit = priority.Object as WoWUnit;
                if (unit != null)
                {
                    switch (unit.Entry)
                    {
                        case MobId_ShackledServitor:
                        case MobId_EnslavedShieldmaiden:
                            if (isDps)
                                priority.Score += 4500;
                            break;

                        case MobId_SoulFragment:
                            priority.Score += isDps ? 5000 : -5000;
                            break;

                        case MobId_DestructorTentacle:
                            priority.Score += 5000;
                            break;

                        case MobId_YmironTheFallenKing:
                            // Attacks boss lass if aggroed while killing trash.
                            if (isDps)
                                priority.Score -= 5000;
                            break;
                    }
                }
            }
        }

        public override void IncludeLootTargetsFilter(List<WoWObject> incomingunits, HashSet<WoWObject> outgoingunits)
        {
            foreach (var lootTarget in incomingunits)
            {
                var gObj = lootTarget as WoWGameObject;
                if (gObj != null && gObj.Entry == GameObjectId_WaterloggedCacheOfAncientRelics && gObj.CanLoot &&
                    DungeonBuddySettings.Instance.LootMode != LootMode.Off)
                {
                    outgoingunits.Add(gObj);
                }
            }
        }

        public override void OnEnter()
        {
            _exitCageAttempt = 0;
            var displayPugGroupWarning = DungeonBuddySettings.Instance.PartyMode == PartyMode.Off ||
                                         (DungeonBuddySettings.Instance.PartyMode == PartyMode.Leader &&
                                          DungeonBuddySettings.Instance.PartyMembers.Count(
                                              s => !string.IsNullOrWhiteSpace(s)) < 4);

            if (displayPugGroupWarning)
            {
                Alert.Show(
                    "Dungeon not tested in PUGs",
                    $"{Name} dungeon has not been tested in PUGs so it's very important to not leave toon unattended",
                    15);
            }

            GameWorld.UnitSpellLineOfSightTest += GameWorld_UnitSpellLineOfSightTest;
        }

        public override void OnExit()
        {
            GameWorld.UnitSpellLineOfSightTest -= GameWorld_UnitSpellLineOfSightTest;
        }

        private void GameWorld_UnitSpellLineOfSightTest(object sender, UnitSpellLineOfSightTestEventArgs e)
        {
            if (e.Unit.Entry == MobId_Helya || e.Unit.Entry == MobId_DestructorTentacle || _mobIds_GraspingTentacle.Contains(e.Unit.Entry))
            {
                e.InSpellLineOfSight = e.Unit.DistanceSqr < 60 * 60;
                e.Handled = true;
            }
        }

        private readonly Vector3 _hornMoveTo = new Vector3(7408.271f, 7260.215f, 51.09502f);
        private const uint GameObjectId_EchoingHornoftheDamned = 247041;

        private int _exitCageAttempt;
        public override async Task<bool> HandleMovement(MoveToParameters moveToParameters)
        {
            var transport = Me.Transport;
            if (transport != null && transport.Entry == MobId_Helheim)
            {
                // Sometimes toon gets stuck in a cage and only way out is teleporting out of instance
                if (_exitCageAttempt > 10)
                {
                    Lua.DoString("LeaveParty()");
                    await CommonCoroutines.SleepForRandomUiInteractionTime();
                    _exitCageAttempt = 0;
                    return true;
                }
                var cage =
                    ObjectManager.GetObjectsOfType<WoWGameObject>()
                        .Where(g => _gameObjectIds_BarnacledCage.Contains(g.Entry))
                        .MinByOrDefault(g => g.DistanceSqr);

                if (cage != null)
                {
                    cage.Interact();
                    await CommonCoroutines.SleepForRandomUiInteractionTime();
                    _exitCageAttempt++;
                    return true;
                }
            }

            var meIsAtStartArea = IsAtStartArea(Me.Location);
            var destIsAtStartLoc = IsAtStartArea(moveToParameters.Location);

            if (meIsAtStartArea != destIsAtStartLoc)
            {
                if (meIsAtStartArea)
                {
                    var horn =
                        ObjectManager
                            .GetObjectsOfType<WoWGameObject>()
                            .FirstOrDefault(g => g.Entry == GameObjectId_EchoingHornoftheDamned);
                    if (horn == null || !horn.WithinInteractRange)
                        return (await CommonCoroutines.MoveTo(_hornMoveTo)).IsSuccessful();

                    await CommonCoroutines.StopMoving();
                    horn.Interact();
                    return true;
                }
            }

            var currentTarget = Me.CurrentTarget;
            if (currentTarget != null
                && (currentTarget.Entry == MobId_DestructorTentacle || _mobIds_GraspingTentacle.Contains(currentTarget.Entry)))
            {
                moveToParameters.DistanceTolerance = 10;
            }

            if (IsByHelyaArea(Me.Location) && !IsByHelyaArea(moveToParameters.Location))
            {
                if (Me.GroupInfo.LfgDungeonId != 0)
                {
                    Lua.DoString("LFGTeleport(true)");
                    return true;
                }

                var portal =
                    ObjectManager.GetObjectsOfType<WoWGameObject>()
                        .FirstOrDefault(g => g.Entry == Gameobjectid_PortalToStormheim);

                if (portal != null)
                    return await ScriptHelpers.InteractWithObject(portal, 0, true);
            }

            return false;
        }

        private bool IsAtStartArea(Vector3 location)
        {
            return location.X > 6414 && location.Y > 6436;
        }


        public override DungeonPathForkInfo[] PathForks { get; } = { new Boss2PathFork() };

        private class Boss2PathFork : DungeonPathForkInfo
        {
            private const uint GameObjectId_RightHeavyBarnacledDoor = 246890;

            private static bool TakeRightSide => ObjectManager.GetObjectsOfType<WoWGameObject>()
                            .Any(g => g.Entry == GameObjectId_RightHeavyBarnacledDoor && !((WoWDoor)g.SubObj).IsClosed);
            public Boss2PathFork()
                : base(
                    new Vector3(2901.656f, 738.1776f, 516.7661f), new Vector3(2905.365f, 723.5131f, 523.3771f), new Vector3(2904.754f, 744.9089f, 515.1533f),
                    new Vector3(2965.141f, 738.0034f, 515.0736f), new Vector3(2961.423f, 729.562f, 519.7495f), new Vector3(2959.256f, 746.9906f, 515.16f),
                    () => TakeRightSide,
                    name: "2nd Boss Fork")
            {
            }

            public override bool IsLocationOnEntranceSide(Vector3 location)
            {
                return location.Y > 738.68 && location.Y < 882.3129f && location.Z < 520f;
            }
        }

        public override DungeonStuckHandler[] StuckHandlers { get; } = new DungeonStuckHandler[]
        {
            new BoundingBox3StuckHandler(
                new BoundingBox3(new Vector3(2914.751f, 919.4913f, 510), new Vector3(2921.692f, 924.4551f, 513f)),
                ctmLocation: new Vector3(2918.827f, 927.7844f, 512.2638f), 
                name: "Pothole 1"),

            new BoundingBox3StuckHandler(
                new BoundingBox3(new Vector3(2930.028f, 917.2403f, 510), new Vector3(2936.792f, 923.2021f, 513f)),
                ctmLocation: new Vector3(2933.671f, 930.0299f, 512.2637f),
                name: "Pothole 2"),

            new BoundingBox3StuckHandler(
                new BoundingBox3(new Vector3(2944.85f, 919.2272f, 510), new Vector3(2951.401f, 924.6038f,  513f)),
                ctmLocation: new Vector3(2948.01f, 930.1998f, 512.2638f),
                name: "Pothole 3"),
        };

        private class BoundingBox3StuckHandler : DungeonStuckHandler
        {
            private BoundingBox3 _bounds;
            public BoundingBox3StuckHandler(BoundingBox3 bounds, Vector3 ctmLocation, string name)
            {
                _bounds = bounds;
                UnstickMoveTo = ctmLocation;
                StuckAreaName = name;
            }

            protected override bool IsStuck => _bounds.Contains(Me.Location);
            protected override Vector3 UnstickMoveTo { get; }
            protected override string StuckAreaName { get; }
        }

        #endregion

        #region Root

        private const uint MobId_Helheim = 103115;
        private readonly HashSet<uint> _gameObjectIds_BarnacledCage = new HashSet<uint>(new uint[] { 246985, 246988, 246986, 246989, 246987 });

        private static LocalPlayer Me => StyxWoW.Me;

        [EncounterHandler(0, "Root Handler")]
        public Func<WoWUnit, Task<bool>> RootBehavior()
        {
            return async npc =>
            {
                return await ScriptHelpers.CancelCinematicIfPlaying();
            };
        }


        #endregion

        #region Ymiron, the Fallen King

        #region Trash

        #region Seacursed Slaver

        private const uint MobId_SeacursedSlaver = 97043;
        private const int SpellId_Fracture = 198752;
        private const int SpellId_BarbedSpear = 194674;
        private const uint AreaTriggerId_SwirlingMuck = 10460;

        [EncounterHandler(MobId_SeacursedSlaver, "SeacursedSlaver")]
        public Func<WoWUnit, Task<bool>> SeacursedSlaverHandler()
        {
            AddAvoidLine<WoWUnit>(() => true, u => u.Location, u => u.Rotation, u => 50, u => 8,
                u => u.Entry == MobId_SeacursedSlaver && u.CastingSpellId == SpellId_Fracture);

            AddAvoidObject<WoWUnit>(() => true, 8,
                u => u.Entry == MobId_SeacursedSlaver && u.CastingSpellId == SpellId_BarbedSpear);
            AddAvoidObject<WoWAreaTrigger>(2, AreaTriggerId_SwirlingMuck);

            return async boss =>
            {
                return false;
            };
        }

        #endregion



        #region Enslaved Shieldmaiden

        private const int SpellId_HewSoul = 199061;
        private const uint MobId_EnslavedShieldmaiden = 102896;

        [EncounterHandler(MobId_EnslavedShieldmaiden, "Enslaved Shieldmaiden")]
        public Func<WoWUnit, Task<bool>> EnslavedShieldmaidenHandler()
        {
            AddAvoidUnitCone(() => true, 0, 8, 45, u => u.Entry == MobId_EnslavedShieldmaiden && u.CastingSpellId == SpellId_HewSoul);

            return async boss => { return false; };
        }

        #endregion

        #region Seacursed Soulkeeper

        private const uint MobId_SeacursedSoulkeeper = 97200;
        private const int SpellId_DefiantStrike = 195031;

        [EncounterHandler(MobId_SeacursedSoulkeeper, "Seacursed Soulkeeper")]
        public Func<WoWUnit, Task<bool>> SeacursedSoulkeeperHandler()
        {
            AddAvoidLine<WoWUnit>(() => true, u => WoWMathHelper.CalculatePointBehind(u.Location, u.Rotation, 3),
                u => u.Rotation, u => 20, u => 8,
                u =>
                    u.Entry == MobId_SeacursedSoulkeeper &&
                    (u.CastingSpellId == SpellId_DefiantStrike || u.HasAura("Defiant Strike")));

            AddAvoidObject<WoWPlayer>(() => true, 8,
                p => !p.IsMe && (p.HasAura("Brackwater Blast") || Me.HasAura("Brackwater Blast")));

            return async boss => { return false; };
        }

        #endregion

        private const uint MobId_CursedFalke = 97163;

        [LocationHandler(7362.18f, 7295.142f, 43.61924f, radius: 60, locationDisplayName: "Boss 1 trash handler")]
        public Func<Vector3, Task<bool>> Boss1TrashPullHandler()
        {
            return async loc =>
            {
                if (Me.Combat || ScriptHelpers.Tank == null)
                    return false;

                var trash = ScriptHelpers.GetUnfriendlyNpsAtLocation(ScriptHelpers.Tank.Location, 40, u => u.Entry != MobId_CursedFalke).FirstOrDefault();

                if (trash == null)
                    return false;

                return await ScriptHelpers.PullNpcToLocation(() => ScriptHelpers.IsViable(trash), trash, null, 6000);
            };
        }
        #endregion


        private const uint MobId_YmironTheFallenKing = 96756;
        private const uint AreaTriggerId_Bane = 10407;
        private const int MissileSpellId_Bane = 193463;
        private const int SpellId_ScreamsoftheDead = 193364;

        [EncounterHandler(MobId_YmironTheFallenKing, "Ymiron, the Fallen King")]
        public Func<WoWUnit, Task<bool>> YmironTheFallenKingHandler()
        {
            // On heroic/mythic diffculty the Bane will spawn skeletons if not absorbed so we don't bother avoided unless health is low
            AddAvoidObject<WoWAreaTrigger>(
                () => LfgDungeon.Difficulty == Styx.WoWInternals.DBC.LfgDifficulty.Normal || Me.HealthPercent < 50,
                6, a => a.Entry == AreaTriggerId_Bane);

            AddAvoidLocation(
                () => LfgDungeon.Difficulty == Styx.WoWInternals.DBC.LfgDifficulty.Normal || Me.HealthPercent < 50,
                3, m => m.ImpactPosition, () => WoWMissile.InFlightMissiles.Where(m => m.SpellId == MissileSpellId_Bane));

            AddAvoidObject<WoWUnit>(() => true, 12,
                u => u.Entry == MobId_YmironTheFallenKing && u.CastingSpellId == SpellId_ScreamsoftheDead);

            return async boss => await ScriptHelpers.DispelGroup("Screams of the Dead", ScriptHelpers.PartyDispelType.Magic);
        }


        #endregion

        #region Harbaron

        #region Trash

        #region Waterlogged Soul Guard

        private const int SpellId_SixPoundBarrel = 194442;

        private const uint MobId_WaterloggedSoulGuard = 99188;
        private const uint AreaTriggerId_SixPoundBarrel = 9817;
        private const int SpellId_SoulSiphon = 194657;

        [EncounterHandler(MobId_WaterloggedSoulGuard, "Waterlogged Soul Guard")]
        public Func<WoWUnit, Task<bool>> WaterloggedSoulGuardHandler()
        {
            AddAvoidLine<WoWUnit>(() => true, u => u.Location, u => u.Rotation, u => 10, u => 2,
                u => u.Entry == MobId_WaterloggedSoulGuard && u.CastingSpellId == SpellId_SixPoundBarrel);

            AddAvoidLine<WoWAreaTrigger>(() => true, u => u.Location, u => u.Rotation, u => 10, u => 2,
                u => u.Entry == AreaTriggerId_SixPoundBarrel);

            return async boss => await ScriptHelpers.InterruptCast(boss, SpellId_SoulSiphon)
                || await ScriptHelpers.DispelGroup("Curse of Hope", ScriptHelpers.PartyDispelType.Curse);
        }

        #endregion

        #region Seacursed Swiftblade

        private const uint MobId_SeacursedSwiftblade = 98919;
        private const uint AreaTriggerId_DeceptiveStrike = 6197;

        [EncounterHandler(MobId_SeacursedSwiftblade, "Seacursed Swiftblade")]
        public Func<WoWUnit, Task<bool>> SeacursedSwiftbladeHandler()
        {
            AddAvoidObject<WoWAreaTrigger>(1, AreaTriggerId_DeceptiveStrike);
            // ToDO get the ID of the ghostly copy of this NPC
            return async boss =>
            {
                if (await ScriptHelpers.DispelEnemy("Sea Legs", ScriptHelpers.EnemyDispelType.Magic, boss))
                    return true;

                return false;
            };
        }

        #endregion

        #region The Grimewalker

        private const uint MobId_TheGrimewalker = 97185;
        private const int SpellId_BileBreath = 194099;
        private const uint AreaTriggerId_PoisonousSludge = 9790;

        [EncounterHandler(MobId_TheGrimewalker, "The Grimewalker")]
        public Func<WoWUnit, Task<bool>> TheGrimewalkerHandler()
        {
            AddAvoidUnitCone(() => !Me.IsTank, 0, 30, 45, u => u.Entry == MobId_TheGrimewalker && u.CastingSpellId == SpellId_BileBreath);
            AddAvoidObject<WoWAreaTrigger>(1, AreaTriggerId_PoisonousSludge);

            return async boss => false;
        }

        #endregion

        #region Helarjar Champion

        private const uint MobId_HelarjarChampion = 97097;
        private const int SpellId_BoneChillingScream = 198405;

        [EncounterHandler(MobId_HelarjarChampion, "Helarjar Champion")]
        public Func<WoWUnit, Task<bool>> HelarjarChampionHandler()
        {
            return async boss =>
            {
                if (boss.HasAura("Ghostly Rage,") && await ScriptHelpers.CastActiveMitigationSpell(boss))
                    return true;

                return await ScriptHelpers.InterruptCast(boss, SpellId_BoneChillingScream)
                    || await ScriptHelpers.DispelGroup("Bone Chilling Scream", ScriptHelpers.PartyDispelType.Magic);
            };
        }

        #endregion

        #region Seacursed Mistmender

        private const uint MobId_SeacursedMistmender = 97365;
        private const int SpellId_TorrentofSouls = 199514;

        [EncounterHandler(MobId_SeacursedMistmender, "Seacursed Mistmender")]
        public Func<WoWUnit, Task<bool>> SeacursedMistmenderHandler()
        {
            // Move away from Mistmender/Mistcaller's target to prevent chaining the Shroud Bolt ability.
            AddAvoidObject<WoWUnit>(() => Me.IsRanged, 15,
                u => (u.Entry == MobId_SeacursedMistmender || u.Entry == MobId_HelarjarMistcaller)
                && u.Combat && u.GotTarget && u.CurrentTargetGuid != Me.Guid,
                u => u.CurrentTarget.Location);

            return async boss => await ScriptHelpers.InterruptCast(boss, SpellId_TorrentofSouls);
        }

        #endregion

        [LocationHandler(2950.746, 805.6597, 515.0328, radius: 50, locationDisplayName: "Boss 2 trash handler")]
        public Func<Vector3, Task<bool>> Boss2TrashPullHandler()
        {
            return async loc =>
            {
                if (Me.Z > 520 || !ScriptHelpers.IsBossAlive("Harbaron") || Me.Combat || ScriptHelpers.Tank == null)
                    return false;

                var trash =
                    ScriptHelpers.GetUnfriendlyNpsAtLocation(ScriptHelpers.Tank.Location, 40,
                        u => u.Entry != MobId_CursedFalke).FirstOrDefault();

                if (trash == null)
                    return false;

                return await ScriptHelpers.PullNpcToLocation(() => ScriptHelpers.IsViable(trash), trash, null, 6000);
            };
        }

        #region Plaguemaw

        private const uint MobId_Plaguemaw = 103045;
        [EncounterHandler(MobId_Plaguemaw, "Plaguemaw", Mode =CallBehaviorMode.Proximity, BossRange = 60)]
        public Func<WoWUnit, Task<bool>> PlaguemawHandler()
        {
            return async boss =>
            {
                if (!Targeting.Instance.IsEmpty() || BotPoi.Current.Type != PoiType.None)
                    return false;

                ScriptHelpers.SetLeaderMoveToPoi(boss.Location, boss.SafeName);
                return false;
            };
        }

        #endregion

        #endregion



        private const uint MobId_Harbaron = 96754;
        private const uint MobId_SoulFragment = 98761;
        private const int SpellId_CosmicScythe = 194216;

        [EncounterHandler(MobId_Harbaron, "Harbaron")]
        public Func<WoWUnit, Task<bool>> HarbaronHandler()
        {
            AddAvoidLine<WoWUnit>(() => true, u => u.Location, u => u.Rotation, u => 60, u => 8, u => u.Entry == MobId_Harbaron && u.CastingSpellId == SpellId_CosmicScythe);

            return async boss => false;
        }

        private const uint MobId_ShackledServitor = 98693;
        private const int SpellId_VoidSnap = 194266;

        [EncounterHandler(MobId_ShackledServitor, "Shackled Servitor")]
        public Func<WoWUnit, Task<bool>> ShackledServitorHandler()
        {
            return async boss => await ScriptHelpers.InterruptCast(boss, SpellId_VoidSnap);
        }

        #endregion

        #region Helya

        #region Trash

        #region Helarjar Mistcaller

        private const uint MobId_HelarjarMistcaller = 99033;
        private const int SpellId_WhirlpoolOfSouls = 199589;

        [EncounterHandler(MobId_HelarjarMistcaller, "Helarjar Mistcaller")]
        public Func<WoWUnit, Task<bool>> HelarjarMistcallerHandler()
        {
            return async boss => await ScriptHelpers.InterruptCast(boss, SpellId_WhirlpoolOfSouls);
        }

        #endregion

        #region Skjal

        private const uint MobId_Skjal = 99307;
        private const int SpellId_DebilitatingShout = 195293;
        private const int SpellId_GiveNoQuarter = 196885;

        [EncounterHandler(MobId_Skjal, "Skjal")]
        public Func<WoWUnit, Task<bool>> SkjalHandler()
        {
            var giveNoQuarterTimer = WaitTimer.FiveSeconds;
            Vector3 giveNoQuarterLoc = Vector3.Zero;

            AddAvoidObject<WoWUnit>(
                () => true, 8,
                u => u.Entry == MobId_Skjal && u.CastingSpellId == SpellId_GiveNoQuarter,
                u =>
                {
                    if (giveNoQuarterTimer.IsFinished && u.GotTarget)
                    {
                        giveNoQuarterLoc = u.CurrentTarget.Location;
                        giveNoQuarterTimer.Reset();
                    }
                    return giveNoQuarterLoc;
                });

            return async boss =>
            {
                if (await ScriptHelpers.InterruptCast(boss, SpellId_DebilitatingShout))
                    return true;
                return false;
            };
        }

        #endregion

        [LocationHandler(2928.849f, 783.1022f, 538.468f, radius: 100, locationDisplayName: "Boss 3 trash handler")]
        public Func<Vector3, Task<bool>> Boss3TrashPullHandler()
        {
            return async loc =>
            {
                if (Me.Z < 535 || ScriptHelpers.IsBossAlive("Harbaron") || Me.Combat || ScriptHelpers.Tank == null)
                    return false;

                var trash = ScriptHelpers.GetUnfriendlyNpsAtLocation(ScriptHelpers.Tank.Location, 40, u => u.Z > 532).FirstOrDefault();

                if (trash == null)
                    return false;

                return await ScriptHelpers.PullNpcToLocation(() => ScriptHelpers.IsViable(trash), trash, null, 6000);
            };
        }

        #endregion

        private bool IsByHelyaArea(Vector3 loc)
        {
            return loc.Distance2DSquared(_helyaAreaLoc) < 90 * 90 && loc.Z < 530 && loc.Y > 913;
        }

        private readonly HashSet<uint> _mobIds_GraspingTentacle = new HashSet<uint>(new uint[] { 98363, 100359, 100360, 100361, 100362 });
        private const uint MobId_DestructorTentacle = 99801;
        private const uint MobId_Helya = 96759;
        private const int MissileSpellId_TurbulentWaters = 197752;
        private const int SpellId_CorruptedBellow = 227233;
        private const int SpellId_Torrent = 197805;
        private const uint GameObjectId_WaterloggedCacheOfAncientRelics = 246036;
        private const uint Gameobjectid_PortalToStormheim = 267034;
        private readonly Vector3 _helyaAreaLoc = new Vector3(2932.641f, 927.9313f, 512.3921f);

        [EncounterHandler(MobId_Helya, "Helya", Mode = CallBehaviorMode.Proximity)]
        public Func<WoWUnit, Task<bool>> HelyaHandler()
        {
            AddAvoidLocation(() => true, 3f, m => m.ImpactPosition,
                () => WoWMissile.InFlightMissiles.Where(m => m.SpellId == MissileSpellId_TurbulentWaters));

            AddAvoidUnitCone(() => true, 0, 90, 60, u => u.Entry == MobId_Helya && u.CastingSpellId == SpellId_CorruptedBellow);

            AddAvoidObject<WoWUnit>(() => Me.IsRanged, u => u.MeleeRange + 1, MobId_DestructorTentacle);

            return async boss =>
            {
                if (Me.RaidMembers.All(r => r.HealthPercent > 40)
                    && await ScriptHelpers.DispelGroup("Taint of the Sea", ScriptHelpers.PartyDispelType.Magic))
                {
                    return true;
                }

                if (await ScriptHelpers.InterruptCast(boss, SpellId_Torrent))
                    return true;

                return false;
            };
        }

        #endregion
    }

    #endregion

    #region Heroic Difficulty

    public class MawOfSoulsHeroic : MawOfSouls
    {
        public override uint DungeonId => 1192;

        #region Harbaron

        private const uint AreaTriggerId_NetherRip = 9799;

        private const uint MobId_Harbaron = 96754;

        private const int MissileSpellId_NetherRip1 = 199457;
        private const int MissileSpellId_NetherRip2 = 200304;
        private const int SpellId_BrackwaterBarrage = 202088;
        [EncounterHandler(MobId_Harbaron, "Harbaron")]
        public Func<WoWUnit, Task<bool>> HarbaronHeroicHandler()
        {
            AddAvoidObject<WoWAreaTrigger>(
                () => true, 
                a => ((AreaTriggerSphere)a.Shape).CurrentRadius + (AvoidanceManager.IsRunningOutOfAvoid ? 3: 0),
                AreaTriggerId_NetherRip);

            AddAvoidLocation(() => true, 5, m => m.ImpactPosition, 
                () => WoWMissile.InFlightMissiles.Where(m => m.SpellId == MissileSpellId_NetherRip1 || m.SpellId == MissileSpellId_NetherRip2));

            // ToDo- handle the Brackwater Barrage ability.
            return async boss => false;
        }

        #endregion


        #region Helya

        private const uint MobId_Helya = 96759;
        private const int MissileSpellId_TaintedEssence = 202470;

        [EncounterHandler(MobId_Helya, "Helya", Mode = CallBehaviorMode.Proximity)]
        public Func<WoWUnit, Task<bool>> HelyaHeroicHandler()
        {
            AddAvoidLocation(() => true, 5f, m => m.ImpactPosition,
                () => WoWMissile.InFlightMissiles.Where(m => m.SpellId == MissileSpellId_TaintedEssence));

            return async boss =>
            {
                return false;
            };
        }

        #endregion

    }

    #endregion
}