﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Numerics;
using System.Text;
using CommonBehaviors.Actions;
using Styx;
using Styx.Common.Helpers;
using Styx.Pathing;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using Styx.TreeSharp;
using Action = Styx.TreeSharp.Action;
using Bots.DungeonBuddy.Profiles;
using Bots.DungeonBuddy.Attributes;
using Bots.DungeonBuddy.Helpers;
using Styx.Common;
using System.Threading.Tasks;
using Styx.CommonBot;

namespace Bots.DungeonBuddy.Dungeon_Scripts.Classic
{
    public class MaraudonFoulsporeCavern : Dungeon
    {
        #region Overrides of Dungeon

        private WaitTimer _deathTimer;

        public override uint DungeonId
        {
            get { return 26; }
        }

        public override Vector3 Entrance
        {
            get
            {
                if (_deathTimer == null)
                {
                    _deathTimer = new WaitTimer(TimeSpan.FromMinutes(2));
                    _deathTimer.Reset();
                }
                return new Vector3(-1381.243f, 2918.000f, 73.42503f);
            }
        }

        public override Vector3 ExitLocation
        {
            get { return new Vector3(1008.538f, -461.3261f, -43.5484f); }
        }

        public override void RemoveTargetsFilter(List<WoWObject> units)
        {
            const uint larvaSpewerId = 178559;
            const uint spewedLarvaUnitId = 13533;

            WoWGameObject larvaSpewer =
                ObjectManager.GetObjectsOfType<WoWGameObject>().FirstOrDefault(g => g.Entry == larvaSpewerId);

            Vector3 spewerLocation = Vector3.Zero;
            if (larvaSpewer != null)
                spewerLocation = larvaSpewer.Location;

            units.RemoveAll(
                o =>
                {
                    WoWUnit unit = o.ToUnit();
                    if (unit != null && spewerLocation != Vector3.Zero && unit.Location.DistanceSquared(spewerLocation) < 30 * 30)
                    {
                        if (unit.Entry == spewedLarvaUnitId)
                            return true;
                    }
                    return false;
                });
        }

        #endregion

        private const int ServantsOfTheradrasQuestId = 27698;

        private LocalPlayer Me
        {
            get { return StyxWoW.Me; }
        }

        [EncounterHandler(0, "Root")]
        public Composite RootHandler()
        {
            PlayerQuest quest = null;
            return new PrioritySelector(
                new Decorator(ctx => (quest = Me.QuestLog.GetQuestById(ServantsOfTheradrasQuestId)) != null && quest.IsCompleted,
                    ScriptHelpers.CreateCompletePopupQuest(ServantsOfTheradrasQuestId)),

                // make sure we're at the right entrance when porting in after dieing.
                // fixed by zoning out and back in.
                new Decorator(
                    ctx => _deathTimer != null,
                    new Sequence(
                        new DecoratorContinue(
                            ctx => !_deathTimer.IsFinished && Me.Location.Distance(ExitLocation) > 50,
                            new Sequence(
                                new Action(ctx => Logger.Write("Porting outside because I'm not at right entrance.")),
                                new Action(ctx => ScriptHelpers.TelportOutsideLfgInstance()),
                                new WaitContinue(2, ctx => !StyxWoW.IsInWorld, new ActionAlwaysSucceed()),
                                new WaitContinue(40, ctx => StyxWoW.IsInWorld, new ActionAlwaysSucceed()),
                                new Action(ctx => Lua.DoString("LFGTeleport(false)")))),
                        new Action(ctx => _deathTimer = null))));
        }

        private const int GameObjectId_LarvaSpewer = 178559;


        [ObjectHandler(GameObjectId_LarvaSpewer, ObjectRange = 30f)]
        public Func<WoWGameObject, Task<bool>> LarvaSpewerHandler()
        {
            WoWGuid interactGuid = WoWGuid.Empty;
            Stopwatch interactTimer = null;

            AddAvoidObject<WoWGameObject>(() => true, 20, obj => obj.Entry == GameObjectId_LarvaSpewer && Blacklist.Contains(obj, BlacklistFlags.Interact));

            return async obj =>
            {
                if (Blacklist.Contains(obj, BlacklistFlags.Interact))
                    return false;

                if (obj.Guid != interactGuid)
                {
                    interactGuid = obj.Guid;
                    interactTimer = Stopwatch.StartNew();
                }

                if (interactTimer.ElapsedMilliseconds > 30000)
                {
                    Blacklist.Add(obj, BlacklistFlags.Interact, TimeSpan.FromMinutes(15));
                    return true;
                }

                return await ScriptHelpers.InteractWithObject(obj, 2000, false);
            };
        }

        private const uint MobId_Razorlash = 12258;

        [EncounterHandler(12258, "Razorlash")]
        public Composite RazorlashFight()
        {
            WoWUnit boss = null;
            // Boss has a cleave
            AddAvoidUnitCone(() => !Me.IsTank(), 0, 10, 180, u => u.Entry == MobId_Razorlash && u.CurrentTarget != Me && u.Combat);

            return new PrioritySelector(
                ScriptHelpers.CreateTankFaceAwayGroupUnit(10));
        }
    }
}