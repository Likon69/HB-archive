﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;
using CommonBehaviors.Actions;
using Styx;
using Styx.Common.Helpers;
using Styx.Pathing;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using Styx.TreeSharp;
using Action = Styx.TreeSharp.Action;

using Bots.DungeonBuddy.Profiles;
using Bots.DungeonBuddy.Attributes;
using Bots.DungeonBuddy.Helpers;
using Styx.Common;
using Styx.CommonBot;

namespace Bots.DungeonBuddy.Dungeon_Scripts.Classic
{
    public class MaraudonTheWickedGrotto : Dungeon
    {
        #region Overrides of Dungeon
        public override uint DungeonId => 272;

        public override Vector3 Entrance
        {
            get
            {
                if (_deathTimer == null)
                {
                    _deathTimer = new WaitTimer(TimeSpan.FromMinutes(2));
                    _deathTimer.Reset();
                }
                return new Vector3(-1381.243f, 2918.000f, 73.42503f);
            }
        }

        public override Vector3 ExitLocation { get; } = new Vector3(756.0845f, -628.2405f, -32.81234f);

        private WaitTimer _deathTimer;

        public override void WeighTargetsFilter(List<Targeting.TargetPriority> objPriorities)
        {
            foreach (var targetPriority in objPriorities)
            {
                var unit = targetPriority.Object as WoWUnit;
                if (unit == null)
                    continue;

                if (unit.Entry == MobId_CorruptForceOfNature)
                    targetPriority.Score += 5000;
            }
        }

        #endregion

        private LocalPlayer Me => StyxWoW.Me;

        private const int CorruptionInMaraudonQuestId = 27697;

        [EncounterHandler(0, "Root")]
        public Composite RootHandler()
        {
            PlayerQuest quest = null;
            return new PrioritySelector(
                 new Decorator(ctx => (quest = Me.QuestLog.GetQuestById(CorruptionInMaraudonQuestId)) != null && quest.IsCompleted,
                     ScriptHelpers.CreateCompletePopupQuest(CorruptionInMaraudonQuestId)),

                // make sure we're at the right entrance when porting in after dieing.
                // fixed by zoning out and back in.
                new Decorator(
                    ctx => _deathTimer != null,
                    new Sequence(
                        new DecoratorContinue(
                            ctx => !_deathTimer.IsFinished && Me.Location.Distance(ExitLocation) > 50,
                            new Sequence(
                                new Action(ctx => Logger.Write("Porting outside because I'm not at right entrance.")),
                                new Action(ctx => ScriptHelpers.TelportOutsideLfgInstance()),
                                new WaitContinue(2, ctx => !StyxWoW.IsInWorld, new ActionAlwaysSucceed()),
                                new WaitContinue(40, ctx => StyxWoW.IsInWorld, new ActionAlwaysSucceed()),
                                new Action(ctx => Lua.DoString("LFGTeleport(false)")))),
                        new Action(ctx => _deathTimer = null))));
        }

        private const uint MobId_TinkererGizlock = 13601;

        [EncounterHandler(13601, "Tinkerer Gizlock")]
        public Func<WoWUnit, Task<bool>> TinkererGizlockFight()
        {
            WoWUnit tinkerGizlock = null;

            AddAvoidUnitCone(() => !Me.IsTank(), 0, 10, 180, u => u.Entry == MobId_TinkererGizlock && u.Combat);

            AddAvoidObject<WoWPlayer>(
                () => Me.IsRanged && ScriptHelpers.IsViable(tinkerGizlock) && tinkerGizlock.Combat, 6,
                p => !p.IsMe && p.IsAlive);

            return async boss =>
            {
                tinkerGizlock = boss;

                // Boss has a cleave
                return await ScriptHelpers.TankFaceUnitAwayFromGroup(boss, 10);
            };
        }

        [EncounterHandler(12236, "Lord Vyletongue")]
        public Func<WoWUnit, Task<bool>> LordVyletongueFight()
        {
            WoWUnit lordVyletongue = null;

            AddAvoidObject<WoWPlayer>(
                () => Me.IsRanged && ScriptHelpers.IsViable(lordVyletongue) && lordVyletongue.Combat, 6,
                p => !p.IsMe && p.IsAlive);

            return async boss =>
            {
                lordVyletongue = boss;
                return false;
            };
        }

        private const int SpellId_EntanglingRoots = 12747;
        private const uint MobId_CorruptForceOfNature = 13743;

        [EncounterHandler(12225, "Celebras the Cursed")]
        public Func<WoWUnit, Task<bool>> CelebrasTheCursedFight()
        {
            return async boss => await ScriptHelpers.InterruptCast(boss, SpellId_EntanglingRoots)
                                 || await ScriptHelpers.DispelGroup("Entangling Roots", ScriptHelpers.PartyDispelType.Magic);
        }
    }
}
