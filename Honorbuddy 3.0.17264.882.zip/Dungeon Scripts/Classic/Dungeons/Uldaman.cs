﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using Bots.DungeonBuddy.Enums;
using CommonBehaviors.Actions;
using Styx;
using Styx.Common;
using Styx.CommonBot;
using Styx.CommonBot.Coroutines;
using Styx.Pathing;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using Styx.TreeSharp;
using System.Threading.Tasks;

using Action = Styx.TreeSharp.Action;

using Bots.DungeonBuddy.Profiles;
using Bots.DungeonBuddy.Attributes;
using Bots.DungeonBuddy.Helpers;
using Buddy.Coroutines;

namespace Bots.DungeonBuddy.Dungeon_Scripts.Classic
{
    public class Uldaman : Dungeon
    {
        #region Overrides of Dungeon

        public override uint DungeonId
        {
            get { return 22; }
        }

        public override Vector3 Entrance
        {
            get { return new Vector3(-6061.87f, -2956.325f, 209.7706f); }
        }

        public override Vector3 ExitLocation
        {
            get { return new Vector3(-228.2558f, 40.31088f, -46.0186f); }
        }

        public override void IncludeTargetsFilter(List<WoWObject> incomingunits, HashSet<WoWObject> outgoingunits)
        {
            foreach (var unit in incomingunits.Select(obj => obj.ToUnit()))
            {
                switch (unit.Entry)
                {
                    case 3560: // healing totem
                    case 6017: // Lava sprout totem
                        outgoingunits.Add(unit);
                        break;
                }
            }
        }

        public override void WeighTargetsFilter(List<Targeting.TargetPriority> units)
        {
            foreach (var p in units)
            {
                WoWUnit unit = p.Object.ToUnit();
                switch (unit.Entry)
                {
                    case 3560: // healing totem
                    case 6017: // Lava sprout totem
                        p.Score += 500;
                        break;
                }
            }
        }

        public override void RemoveTargetsFilter(List<WoWObject> units)
        {
            units.RemoveAll(
                o =>
                {
                    var unit = o as WoWUnit;
                    if (unit != null)
                    {
                        if (unit.Entry == JadespineBasiliskId && unit.HasAura("Reflection") && Me.IsRange() && Me.IsDps)
                            return true;
                        if (unit.Entry == EarthenGuardianId && unit.HasAura("Whirlwind") && Me.IsMelee() && Me.IsDps)
                            return true;
                    }
                    return false;
                });
        }

        public override void IncludeLootTargetsFilter(List<WoWObject> incomingObjects, HashSet<WoWObject> outgoingunits)
        {
            foreach (var obj in incomingObjects)
            {
                var gObj = obj as WoWGameObject;
                if (gObj != null && gObj.Entry == AncientTreasureId && gObj.CanUse()
                    && DungeonBuddySettings.Instance.LootMode != LootMode.Off)
                {
                    outgoingunits.Add(gObj);
                }
            }
        }

        #endregion


        private LocalPlayer Me
        {
            get { return StyxWoW.Me; }
        }

        private WoWGameObject HallOfCraftersDoor
        {
            get { return ObjectManager.GetObjectsOfType<WoWGameObject>().FirstOrDefault(o => o.Entry == 124367); }
        }

        private WoWGameObject AncientTreasure
        {
            get { return ObjectManager.GetObjectsOfType<WoWGameObject>().FirstOrDefault(o => o.Entry == 141979); }
        }

        #region Root

        private const int TheChamberOfKhazmulQuestId = 27679;
        private const int ArchaedasTheAncientStoneWatcherQuestId = 27680;

        [EncounterHandler(46241, "Aoren Sunglow", Mode = CallBehaviorMode.Proximity, BossRange = 40)]
        [EncounterHandler(46235, "Lidia Sunglow", Mode = CallBehaviorMode.Proximity, BossRange = 40)]
        [EncounterHandler(46236, "High Examiner Tae'thelan Bloodwatcher", Mode = CallBehaviorMode.Proximity, BossRange = 40)]
        public Composite QuestGiversBehavior()
        {
            WoWUnit unit = null;
            return new PrioritySelector(
                ctx => unit = ctx as WoWUnit,
                new Decorator(ctx => !Me.Combat && unit.QuestGiverStatus == QuestGiverStatus.Available, ScriptHelpers.CreatePickupQuest(ctx => unit)),
                new Decorator(ctx => !Me.Combat && unit.QuestGiverStatus == QuestGiverStatus.TurnIn, ScriptHelpers.CreateTurninQuest(ctx => unit)));
        }

        [EncounterHandler(0)]
        public Composite RootHandler()
        {
            PlayerQuest quest = null;
            return new PrioritySelector(
                new Decorator(ctx => (quest = Me.QuestLog.GetQuestById(TheChamberOfKhazmulQuestId)) != null && quest.IsCompleted,
                    ScriptHelpers.CreateCompletePopupQuest(TheChamberOfKhazmulQuestId)),

                new Decorator(ctx => (quest = Me.QuestLog.GetQuestById(ArchaedasTheAncientStoneWatcherQuestId)) != null && quest.IsCompleted,
                    ScriptHelpers.CreateCompletePopupQuest(ArchaedasTheAncientStoneWatcherQuestId))
                );
        }
        #endregion

        [LocationHandler(-347.3496, 125.7285, -49.82032, 4)]
        public Composite StuckAtThreeDwarvesHandler()
        {
            var movetoLoc = new Vector3(-349.752f, 130.5805f, -47.7855f);
            return new PrioritySelector(
                new Decorator(ctx => !Me.Combat,
                    new Sequence(
                        new Action(ctx => Navigator.PlayerMover.MoveTowards(movetoLoc)),
                        new Action(ctx => WoWMovement.Move(WoWMovement.MovementDirection.JumpAscend)),
                        new Action(ctx => WoWMovement.MoveStop(WoWMovement.MovementDirection.JumpAscend))
                        ))
                );
        }


        [ObjectHandler(130511, "Altar of The Keepers")]
        public async Task<bool> AltarofTheKeepers(WoWGameObject altar)
        {
            var door = HallOfCraftersDoor; // cache the door object.

            if (door == null || door.State == WoWGameObjectState.Active)
                return false;
            if (Targeting.Instance.TargetList.Any(u => u.ZDiff < 10 && u.Location.DistanceSquared(altar.Location) < 25 * 25))
                return false;

            if (altar.DistanceSqr > 5 * 5)
                return (await CommonCoroutines.MoveTo(altar.Location, altar.SafeName)).IsSuccessful();

            if (await ScriptHelpers.InteractWithObject(altar))
                await Coroutine.Sleep(6000);

            return true;
        }


        private const uint AncientTreasureId = 141979;

        [EncounterHandler(7206, "Ancient Stone Keeper")]
        public Composite AncientStoneKeeperHandler()
        {
            const uint sandStormId = 7226;
            var tankLoc = new Vector3(-42.94647f, 220.7556f, -48.32799f);
            // avoid the sand storms
            AddAvoidObject(() => !Me.IsTank(), 8, sandStormId);
            WoWUnit boss = null;
            return new PrioritySelector(ctx => boss = ctx as WoWUnit,
                new Decorator(ctx => Me.IsTank() && boss.CurrentTargetGuid == Me.Guid,
                    ScriptHelpers.CreateTankUnitAtLocation(ctx => tankLoc, 5)));
        }

        #region Galgann Firehammer

        private const uint GalgannFirehammerId = 7291;

        [EncounterHandler(7291, "Galgann Firehammer")]
        public Composite GalgannFirehammerHandler()
        {
            // range shouldn't get caught in the fire nova aoe.
            WoWUnit boss = null;
            AddAvoidObject(() => Me.IsRange() && !Me.IsCasting, 10, o => o.Entry == GalgannFirehammerId && o.ToUnit().CurrentTargetGuid != Me.Guid && o.ToUnit().IsAlive);
            return new PrioritySelector(ctx => boss = ctx as WoWUnit);
        }

        [EncounterHandler(7030, "Shadowforge Geologist")]
        public Composite ShadowforgeGeologistHandler()
        {
            const int flameSpikeId = 8814;
            const int flameLashId = 3356;
            // stay out of the flame spike.
            AddAvoidObject(() => true, 5, flameSpikeId);
            WoWUnit boss = null;
            return new PrioritySelector(ctx => boss = ctx as WoWUnit, ScriptHelpers.CreateInterruptCast(ctx => boss, flameLashId, flameSpikeId));
        }

        #endregion

        #region Grimlok

        private const uint JadespineBasiliskId = 4863;

        [EncounterHandler(4854, "Grimlok")]
        public Composite GrimlokHandler()
        {
            const int chainBoltId = 8292;
            const int shrinkId = 11892;
            WoWUnit boss = null;
            return new PrioritySelector(ctx => boss = ctx as WoWUnit, ScriptHelpers.CreateInterruptCast(ctx => boss, chainBoltId, shrinkId));
        }

        [EncounterHandler(4863, "Jadespine Basilisk")]
        public Composite JadespineBasiliskHandler()
        {
            const int crystallineSlumberId = 3636;
            WoWUnit unit = null;
            return new PrioritySelector(
                ctx => unit = ctx as WoWUnit,
                ScriptHelpers.CreateDispelGroup("Crystalline Slumber", ScriptHelpers.PartyDispelType.Magic),
                ScriptHelpers.CreateDispelEnemy("Bloodlust", ScriptHelpers.EnemyDispelType.Magic, ctx => unit),
                ScriptHelpers.CreateDispelEnemy("Reflection", ScriptHelpers.EnemyDispelType.Magic, ctx => unit),
                ScriptHelpers.CreateInterruptCast(ctx => unit, crystallineSlumberId));
        }

        #endregion

        #region Ironaya

        private const uint IronayaId = 7228;

        [ObjectHandler(124371, "Keystone")]
        public Composite KeystoneObject()
        {
            WoWGameObject keystone = null;
            return new PrioritySelector(
                ctx => keystone = ctx as WoWGameObject,
                new Decorator(ctx => !Me.Combat && keystone.Locked == false && Me.IsTank(), ScriptHelpers.CreateInteractWithObject(ctx => keystone)));
        }

        private const uint MobId_Ironaya = 7228;

        [EncounterHandler(7228, "Ironaya")]
        public Composite IronayaHandler()
        {
            WoWUnit boss = null;
            // range should stay away to avoid geting stunned. 
            AddAvoidObject(() => Me.IsRange(), 5, o => o.Entry == IronayaId && o.ToUnit().CurrentTargetGuid != Me.Guid && o.ToUnit().IsAlive);
            // avoid getting cleaved 
            AddAvoidUnitCone(() => !Me.IsTank(), 0, 10, 180, u => u.Entry == MobId_Ironaya && u.CurrentTarget != Me && u.Combat);

            return new PrioritySelector();
        }

        #endregion

        #region Archaedas

        private const uint EarthenGuardianId = 7076;


        [EncounterHandler(2748, "Archaedas", Mode = CallBehaviorMode.Proximity)]
        public Func<WoWUnit, Task<bool>> ArchaedasHandler()
        {
            const uint altarofTheArchaedas = 133234;

            AddAvoidObject(() => !Me.IsTank(), 11, o => o.Entry == EarthenGuardianId && o.ToUnit().HasAura("Whirlwind"));

            return async boss =>
            {
                if (!Targeting.Instance.IsEmpty())
                    return false;

                if (boss.HasAura("Freeze Anim") && boss.DistanceSqr <= 30 * 30 && boss.ZDiff < 8)
                {
                    var altar = ObjectManager.ObjectList.FirstOrDefault(o => o.Entry == altarofTheArchaedas);
                    if (altar != null)
                    {
                        if (altar.DistanceSqr > 4 * 4)
                            return (await CommonCoroutines.MoveTo(altar.Location, altar.SafeName)).IsSuccessful();
                        await ScriptHelpers.StopMovingIfMoving();
                        altar.Interact();
                        await CommonCoroutines.SleepForLagDuration();
                        await Coroutine.Wait(12000, () => !Me.IsCasting || !Targeting.Instance.IsEmpty());
                        return true;
                    }
                }
                return false;
            };
        }

        #endregion
    }
}