﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Bots.DungeonBuddy.Enums;
using CommonBehaviors.Actions;
using Styx;
using Styx.Common;
using Styx.Common.Helpers;
using Styx.CommonBot;
using Styx.CommonBot.Coroutines;
using Styx.CommonBot.Frames;
using Styx.CommonBot.POI;
using Styx.Helpers;
using Styx.Pathing;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using Styx.TreeSharp;
using Action = Styx.TreeSharp.Action;
using Bots.DungeonBuddy.Attributes;
using Bots.DungeonBuddy.Helpers;

namespace Bots.DungeonBuddy.Dungeon_Scripts.Classic
{
    public class BlackrockDepthsDetentionBlock : Dungeon
    {
        #region Overrides of Dungeon

        public override uint DungeonId => 30;

        public override Vector3 Entrance => new Vector3(-7178.417f, -926.6841f, 167.1217f);

        public override Vector3 ExitLocation => new Vector3(457.0491f, 38.14f, -68.74f);

        public override void WeighTargetsFilter(List<Targeting.TargetPriority> units)
        {
            foreach (var entry in units)
            {
                var unit = entry.Object;
                switch (unit.Entry)
                {
                    case 8894: // Anvilrage Medic
                        entry.Score += 250;
                        break;
                    case PrincessMoiraBronzeBeardId:
                        entry.Score -= 10000;
                        break;
                }
            }
        }

        public override void RemoveTargetsFilter(List<WoWObject> units)
        {
            units.RemoveAll(
                u =>
                {
                    WoWUnit unit = u.ToUnit();
                    // Princess should not killed because of a quest requiring her to be alive in the end.
                    if (unit.Entry == PrincessMoiraBronzebeardId)
                        return true;
                    if (unit.Entry == AnvilrageReservistId && !unit.Combat) // Anvilrage Reservist
                        return true;
                    if (unit.Entry == ShadowforgeFlameKeeperId && !HuntFlameKeepers && !unit.Combat)
                        return true;
                    return false;
                });
        }

        public override void IncludeTargetsFilter(List<WoWObject> incomingunits, HashSet<WoWObject> outgoingunits)
        {
            foreach (var unit in incomingunits.OfType<WoWUnit>())
            {
                // Add Shadowforge Flame Keeper if we need to farm tourches.
                if (unit.Entry == ShadowforgeFlameKeeperId && HuntFlameKeepers && LootTargeting.Instance.IsEmpty())
                    outgoingunits.Add(unit);
            }
        }

        public override void IncludeLootTargetsFilter(List<WoWObject> incomingunits, HashSet<WoWObject> outgoingunits)
        {
            foreach (var lootTarget in incomingunits)
            {
                var unit = lootTarget as WoWUnit;
                if (unit != null)
                {
                    if (unit.Entry == ShadowforgeFlameKeeperId && HuntFlameKeepers)
                        outgoingunits.Add(unit);
                }

                var gObj = lootTarget as WoWGameObject;
                if (gObj != null && gObj.Entry == ChestOfTheSevenId && gObj.CanUse() &&
                    DungeonBuddySettings.Instance.LootMode != LootMode.Off)
                {
                    outgoingunits.Add(gObj);
                }
            }
        }

        public override void OnEnter()
        {
            Lua.Events.AttachEvent("CHAT_MSG_LOOT", ChatMsgLoot);
        }

        public override void OnExit()
        {
            Lua.Events.DetachEvent("CHAT_MSG_LOOT", ChatMsgLoot);
            _northBrazierLighted = _lootedChestOfTheSeven = _talkedToDoomrelt = _southBrazierLighted = false;
        }

        #region Mole Machine

        private const uint Entrance_AbandonedMoleMachineId = 207401;
        private const uint ShadowForgeCity_AbandonedMoleMachineId = 207402;
        private readonly Vector3 _entranceMoleMachineLoc = new Vector3(448.2525f, 21.00523f, -70.67912f);
        private readonly Vector3 _grimGuzzlerMoleMachineLoc = new Vector3(929.9165f, -292.2379f, -49.94017f);
        private readonly Vector3 _shadowForgeCityrMoleMachineLoc = new Vector3(931.931f, -286.9268f, -49.93598f);

        public override async Task<bool> HandleMovement(MoveToParameters moveToParameters)
        {
            var location = moveToParameters.Location;
            var myLoc = Me.Location;

            if (!Me.Combat && !ScriptHelpers.IsBossAlive("Lord Incendius")
                && myLoc.DistanceSquared(_entranceMoleMachineLoc) < 60 * 60
                && _grimGuzzlerMoleMachineLoc.Distance(location) < myLoc.Distance(location))
            {
                var moleMachine = ObjectManager.GetObjectsOfType<WoWGameObject>().FirstOrDefault(o => o.Entry == Entrance_AbandonedMoleMachineId);
                if (moleMachine != null)
                {
                    if (moleMachine.Distance > 5)
                        return (await CommonCoroutines.MoveTo(moleMachine.Location)).IsSuccessful();

                    if (GossipFrame.Instance.IsVisible)
                        GossipFrame.Instance.SelectGossipOption(0);
                    else
                        moleMachine.Interact();
                    return true;
                }
            }

            if (!Me.Combat && myLoc.DistanceSquared((Vector3)_shadowForgeCityrMoleMachineLoc) < 60 * 60 && _entranceMoleMachineLoc.Distance(location) < myLoc.Distance(location))
            {
                var moleMachine = ObjectManager.GetObjectsOfType<WoWGameObject>().FirstOrDefault(o => o.Entry == ShadowForgeCity_AbandonedMoleMachineId);
                if (moleMachine != null)
                {
                    if (moleMachine.Distance > 5)
                        return (await CommonCoroutines.MoveTo(moleMachine.Location)).IsSuccessful();

                    if (GossipFrame.Instance.IsVisible)
                        GossipFrame.Instance.SelectGossipOption(0);
                    else
                        moleMachine.Interact();
                    return true;
                }
            }
            return false;
        }

        #endregion

        #endregion

        private const uint PrincessMoiraBronzebeardId = 8929;
        private const uint ShadowforgeFlameKeeperId = 9956;
        private const uint ShadowforgeTorchId = 11885;
        private const uint AnvilrageReservistId = 8901;
        private static readonly Regex s_itemIdRegex = new Regex(@"Hitem:(?<id>\d+)", RegexOptions.CultureInvariant);
        private static readonly WaitTimer s_shadowForgeTorchLooted = new WaitTimer(TimeSpan.FromMinutes(5));
        private readonly Vector3 _baelGarLocation = new Vector3(701.8241f, 185.5464f, -72.06669f);
        private readonly Vector3 _lordIncendiusTankSpot = new Vector3(861.7827f, -241.1472f, -71.76051f);
        private readonly Vector3 _northBrazierLocation = new Vector3(1431.913f, -523.971f, -92.03755f);
        private readonly Vector3 _openBarDoorSafeMoveTo = new Vector3(881.53f, -226.6577f, -46.51212f);
        private readonly Vector3 _openBarDoorWaitAtPoint = new Vector3(869.8575f, -227.0011f, -43.75132f);
        private readonly Vector3 _ribblyScrewspigotDpsSpot = new Vector3(893.4753f, -157.8955f, -49.76056f);
        private readonly Vector3 _ribblyScrewspigotTankSpot = new Vector3(896.8156f, -163.6791f, -49.76056f);

        private readonly Vector3 _ringOfLawCenterLocation = new Vector3(595.9567f, -188.4252f, -54.14674f);
        private readonly Vector3 _southBrazierLocation = new Vector3(1332.868f, -508.6617f, -88.86429f);
        private bool _lootedChestOfTheSeven;
        private bool _northBrazierLighted;
        private bool _southBrazierLighted;
        private bool _talkedToDoomrelt;

        private LocalPlayer Me
        {
            get { return StyxWoW.Me; }
        }

        private WoWGameObject BarDoor
        {
            get { return ObjectManager.GetObjectsOfType<WoWGameObject>().FirstOrDefault(o => o.IsValid && o.Entry == 170571); }
        }

        private bool HasTorch
        {
            get { return Me.BagItems.Any(i => i.Entry == ShadowforgeTorchId); }
        }

        private PerFrameCachedValue<bool> _huntFlameKeepers;
        private bool HuntFlameKeepers
        {
            get
            {
                return _huntFlameKeepers ?? (_huntFlameKeepers = new PerFrameCachedValue<bool>(
                    () => s_shadowForgeTorchLooted.IsFinished
                    && !ScriptHelpers.IsBossAlive("Doom'rel")
                    && ScriptHelpers.IsBossAlive("Magmus")
                    && (!_northBrazierLighted || !_southBrazierLighted)
                    && !HasTorch && Me.IsTank()));
            }
        }

        private static void ChatMsgLoot(object sender, LuaEventArgs args)
        {
            var match = s_itemIdRegex.Match(args.Args[0].ToString());
            if (match.Success && match.Groups["id"].Success)
            {
                var itemId = int.Parse(match.Groups["id"].Value);
                if (itemId == ShadowforgeTorchId) // Shadowforge Torch
                {
                    Logger.Write("A party member looted Shadowforge torch");
                    s_shadowForgeTorchLooted.Reset();
                }
            }
        }

        [EncounterHandler(45849, "Tinkee Steamboil", Mode = CallBehaviorMode.Proximity, BossRange = 45)]
        [EncounterHandler(45821, "Thal'trak Proudtusk", Mode = CallBehaviorMode.Proximity, BossRange = 45)]
        [EncounterHandler(45818, "Lexlort", Mode = CallBehaviorMode.Proximity, BossRange = 45)]
        public Composite QuestPickupTurninHandler()
        {
            WoWUnit unit = null;
            return new PrioritySelector(
                ctx => unit = ctx as WoWUnit,
                new Decorator(
                    ctx => !Me.Combat && !ScriptHelpers.WillPullAggroAtLocation(unit.Location) && unit.QuestGiverStatus == QuestGiverStatus.Available,
                    ScriptHelpers.CreatePickupQuest(ctx => unit)),
                new Decorator(
                    ctx => !Me.Combat && !ScriptHelpers.WillPullAggroAtLocation(unit.Location) && unit.QuestGiverStatus == QuestGiverStatus.TurnIn,
                    ScriptHelpers.CreateTurninQuest(ctx => unit)));
        }

        [EncounterHandler(9018, "High Interrogator Gerstahn")]
        public Composite HighInterrogatorGerstahnEncounter()
        {
            return ScriptHelpers.CreateTankUnitAtLocation(ctx => new Vector3(310.2939f, -147.5773f, -70.38612f), 7);
        }

        // skipped in LFG
        //[ObjectHandler(161524, "Ring of the Law", 1000)]
        //public Composite RingOfTheLawEncounter()
        //{
        //    WoWGameObject eastGarrisonDoor = null;
        //    WoWGameObject wave1Door = null;
        //    WoWGameObject wave2Door = null;
        //    bool wave1Inc = false;
        //    bool wave2Inc = false;
        //    // WoWDoor.IsClosed doesn't seem to work for these doors so using WowGameObject.State. Active state means it's open, Ready state means it's closed.
        //    return new PrioritySelector(
        //        ctx =>
        //        {
        //            wave1Door = ObjectManager.GetObjectsOfType<WoWGameObject>().FirstOrDefault(o => o.Entry == 161525);
        //            wave2Door = ObjectManager.GetObjectsOfType<WoWGameObject>().FirstOrDefault(o => o.Entry == 161522);
        //            eastGarrisonDoor = ObjectManager.GetObjectsOfType<WoWGameObject>().FirstOrDefault(o => o.Entry == 161524);
        //            wave1Inc = wave1Door != null && wave1Door.State == WoWGameObjectState.Active && eastGarrisonDoor != null &&
        //                       eastGarrisonDoor.State == WoWGameObjectState.Ready;
        //            wave2Inc = wave2Door != null && wave2Door.State == WoWGameObjectState.Active && eastGarrisonDoor != null &&
        //                       eastGarrisonDoor.State == WoWGameObjectState.Ready;
        //            return ctx;
        //        },
        //        new Decorator(
        //            ctx =>
        //            eastGarrisonDoor != null && eastGarrisonDoor.State == WoWGameObjectState.Ready &&
        //            (!ScriptHelpers.IsBossAlive("Houndmaster Grebmar") || !ScriptHelpers.ShouldKillBoss("Houndmaster Grebmar")) && StyxWoW.Me.IsTank(),
        //            new PrioritySelector(
        //                new Decorator(
        //                    ctx => !wave1Inc && !wave2Inc,
        //                    new PrioritySelector(
        //                        new ActionSetActivity("Moving to Ring of Law"),
        //                        new Decorator(
        //                            ctx => StyxWoW.Me.Location.DistanceSqr(_ringOfLawCenterLocation) > 5 * 5 && BotPoi.Current.Type == PoiType.None,
        //                            new Action(ctx => ScriptHelpers.SetLeaderMoveToPoi(_ringOfLawCenterLocation))),
        //                        new Decorator(
        //                            ctx => StyxWoW.Me.Location.DistanceSqr(_ringOfLawCenterLocation) <= 5 * 5 && Targeting.Instance.FirstUnit == null, new ActionAlwaysSucceed()))),
        //        // dont move anywhere
        //                new Decorator(
        //                    ctx => wave2Inc && Targeting.Instance.FirstUnit == null,
        //                    new PrioritySelector(
        //                        new ActionSetActivity("Picking up boss."),
        //                        new Decorator(
        //                            ctx => StyxWoW.Me.Location.DistanceSqr(wave2Door.Location) > 5 * 5 && BotPoi.Current.Type == PoiType.None, new Action(ctx => ScriptHelpers.SetLeaderMoveToPoi(wave2Door.Location))),
        //                        new Decorator(
        //                            ctx => StyxWoW.Me.Location.DistanceSqr(wave2Door.Location) <= 5 * 5 && Targeting.Instance.FirstUnit == null, new ActionAlwaysSucceed()))),
        //        // dont move anywhere
        //                new Decorator(
        //                    ctx => wave1Inc && !wave2Inc && Targeting.Instance.FirstUnit == null,
        //                    new PrioritySelector(
        //                        new ActionSetActivity("Picking up the waves of NPCs."),
        //                        new Decorator(
        //                            ctx => StyxWoW.Me.Location.DistanceSqr(wave1Door.Location) > 5 * 5 && BotPoi.Current.Type == PoiType.None, new Action(ctx => ScriptHelpers.SetLeaderMoveToPoi(wave1Door.Location))),
        //                        new Decorator(
        //                            ctx => StyxWoW.Me.Location.DistanceSqr(wave1Door.Location) <= 5 * 5 && Targeting.Instance.FirstUnit == null, new ActionAlwaysSucceed())))
        //        // dont move anywhere
        //                )));
        //}


        [EncounterHandler(9016, "Bael'Gar", BossRange = 100, Mode = CallBehaviorMode.Proximity)]
        public Composite BaelGarEncounter()
        {
            // clear room of argo.
            WoWUnit boss = null;
            return new PrioritySelector(ctx => boss = ctx as WoWUnit, ScriptHelpers.CreateClearArea(() => _baelGarLocation, 100, u => u.Entry != boss.Entry));
        }

        [EncounterHandler(9017, "Lord Incendius")]
        public Composite LordIncendiusEncounter()
        {
            return new PrioritySelector(
                new Decorator(ctx => StyxWoW.Me.IsTank(), ScriptHelpers.CreateTankUnitAtLocation(ctx => _lordIncendiusTankSpot, 7)),
                new Decorator(
                    ctx => StyxWoW.Me.IsDps,
                    // wait until boss is over in tanking spot before opening up on him.
                    new PrioritySelector(new Decorator(ctx => ((WoWUnit)ctx).Location.DistanceSquared((Vector3)_lordIncendiusTankSpot) > 12 * 12, new ActionAlwaysSucceed()))));
        }


        [ObjectHandler(161460, "The Shadowforge Lock", ObjectRange = 60)]
        public Composite TheShadowforgeLockHandler()
        {
            WoWGameObject shadowForgeLock = null;
            return new PrioritySelector(
                ctx => shadowForgeLock = ctx as WoWGameObject,
                new Decorator(
                    ctx =>
                        {
                            if (shadowForgeLock.State != WoWGameObjectState.Ready || !Me.IsTank() || !Targeting.Instance.IsEmpty())
                                return false;

                            PathInformation path = Navigator.LookupPathInfo(shadowForgeLock, shadowForgeLock.InteractRange);
                            return path.Navigability == PathNavigability.Navigable &&
                                   path.Distance < 60f;
                        },
                    ScriptHelpers.CreateInteractWithObject(ctx => (WoWGameObject)ctx)));
        }

        [ObjectHandler(164911, "Thunderbrew Lager Keg", 75)]
        public Composite HurleyBlackbreathEncounter()
        {
            WoWGameObject keg = null;
            return new PrioritySelector(
                ctx => keg = ctx as WoWGameObject,
                new Decorator(
                    ctx => keg != null && ScriptHelpers.ShouldKillBoss("Hurley Blackbreath") && ScriptHelpers.IsBossAlive("Hurley Blackbreath"),
                    ScriptHelpers.CreateInteractWithObject(164911)));
        }

        // Should never do this encounter on LFG because its a waste of time.
        /*
		[EncounterHandler(9543, "Ribbly Screwspigot", Mode = CallBehaviorMode.Proximity, BossRange = 40)]
		public Composite RibblyScrewspigotEncounter()
		{
			return new PrioritySelector(
				new Decorator(
					ctx => !ScriptHelpers.IsBossAlive("Hurley Blackbreath") && // loot up before we start event
						   !ObjectManager.GetObjectsOfType<WoWUnit>().Any(
							   u => u.IsValid && u.IsDead && u.Lootable && u.DistanceSqr < CharacterSettings.Instance.LootRadius * CharacterSettings.Instance.LootRadius),
					new PrioritySelector(
				// I am tank
						new Decorator(
							ctx => StyxWoW.Me.IsTank(),
							new PrioritySelector(
								new Decorator(
									ctx => !StyxWoW.Me.IsActuallyInCombat,
									new Sequence(
										ScriptHelpers.CreateTalkToNpcContinue(9543),
										ScriptHelpers.CreateMoveToContinue(ctx => _ribblyScrewspigotTankSpot),
										new WaitContinue(15, ctx => StyxWoW.Me.IsActuallyInCombat, new ActionAlwaysSucceed()))),
								ScriptHelpers.CreateTankUnitAtLocation(ctx => _ribblyScrewspigotTankSpot, 4))),
				// I am dps/healer.
						new Decorator(
							ctx => StyxWoW.Me.IsFollower(),
							new PrioritySelector(
								new Decorator(
									ctx => StyxWoW.Me.Location.DistanceSqr(_ribblyScrewspigotDpsSpot) > 4 * 4,
									new Action(ctx => Navigator.GetRunStatusFromMoveResult(Navigator.MoveTo(_ribblyScrewspigotDpsSpot)))),
								new Decorator(
									ctx => ScriptHelpers.MovementEnabled && StyxWoW.Me.Location.DistanceSqr(_ribblyScrewspigotDpsSpot) <= 4 * 4,
									new Action(ctx => ScriptHelpers.DisableMovement(() => ScriptHelpers.IsBossAlive("Ribbly Screwspigot") && StyxWoW.Me.IsAlive))))))));
		}
		*/
        /*
		[EncounterHandler(9499, "Plugger Spazzring", Mode = CallBehaviorMode.Proximity, BossRange = 100)]
		public Composite OpenBarDoorEncounter()
		{
			const uint bartenderId = 9499;
			const uint rockNotId = 9503;
			var rockNotIdleLoc = new Vector3(891.1985, -197.924, -43.7037);
			const uint beverageId = 11325;
			WoWGameObject barDoor = null;
			WoWUnit rockNot = null;
			WoWUnit pluggerSpazzring = null;
			int mugsInBag = 0;
			return new PrioritySelector(
				ctx =>
				{
					barDoor = BarDoor;
					rockNot = ObjectManager.GetObjectsOfType<WoWUnit>().FirstOrDefault(u => u.Entry == rockNotId);
					pluggerSpazzring = ctx as WoWUnit;
					return ctx;
				},
				new Decorator(
					ctx => barDoor != null && barDoor.State == WoWGameObjectState.Ready && !ScriptHelpers.IsBossAlive("Ribbly Screwspigot"),
					new PrioritySelector(
						ctx => mugsInBag = (int)StyxWoW.Me.CarriedItems.Sum(i => i != null && i.IsValid && i.Entry == beverageId ? i.StackCount : 0),
				// buy
						new Decorator(
							ctx => Me.IsTank() && rockNot.Location.Distance(rockNotIdleLoc) < 3,
							new PrioritySelector(
								new Decorator(
									ctx => mugsInBag < 6,
									new PrioritySelector(
										new Decorator(
											ctx => pluggerSpazzring.WithinInteractRange,
											new Sequence(
												new Action(ctx => pluggerSpazzring.Interact()),
												new WaitContinue(2, ctx => MerchantFrame.Instance.IsVisible, new ActionAlwaysSucceed()),
												new Action(ctx => ScriptHelpers.BuyItem(beverageId, 6 - mugsInBag)),
												new WaitContinue(3, ctx => false, new ActionAlwaysSucceed()))),
										new Decorator(ctx => !pluggerSpazzring.WithinInteractRange, new Action(ctx => Navigator.MoveTo(pluggerSpazzring.Location))))),
								new Decorator(
									ctx => StyxWoW.Me.IsTank() && mugsInBag >= 6,
									new Sequence(
										ScriptHelpers.CreateTurninQuest(rockNotId),
										new Action(ctx => QuestFrame.Instance.Close()),
										new WaitContinue(1, ctx => false, new ActionAlwaysSucceed()),
										ScriptHelpers.CreateTurninQuest(rockNotId),
										new Action(ctx => QuestFrame.Instance.Close()),
										new WaitContinue(1, ctx => false, new ActionAlwaysSucceed()),
										ScriptHelpers.CreateTurninQuest(rockNotId),
										new WaitContinue(1, ctx => false, new ActionAlwaysSucceed()))))),
						new Decorator(
							ctx => rockNot.Location.Distance(rockNotIdleLoc) >= 3 && !Me.Combat,
							new PrioritySelector(
								new Decorator(ctx => Me.Location.Distance(_openBarDoorWaitAtPoint) > 4, new Action(ctx => Navigator.MoveTo(_openBarDoorWaitAtPoint))),
								new Decorator(
									ctx => Me.Location.Distance(_openBarDoorWaitAtPoint) <= 4,
									new Sequence(
										new WaitContinue(
											TimeSpan.FromMinutes(2),
											ctx => BarDoor.State == WoWGameObjectState.ActiveAlternative || StyxWoW.Me.Combat,
											new ActionAlwaysSucceed()),
										new DecoratorContinue(
											ctx => BarDoor.State == WoWGameObjectState.ActiveAlternative, ScriptHelpers.CreateMoveToContinue(ctx => _openBarDoorSafeMoveTo)))))))));
		}
		*/

        private const uint ChestOfTheSevenId = 169243;

        [EncounterHandler(9938, "Magmus")]
        public Composite MagmusEncounter()
        {
            WoWUnit boss = null;
            // tank n spank
            return new PrioritySelector(ctx => boss = ctx as WoWUnit);
        }

        private const uint PrincessMoiraBronzeBeardId = 8929;

        [EncounterHandler(8929, "Princess Moira BronzeBeard")]
        public Composite PrincesMoiraBronzeBeardEncounter()
        {
            WoWUnit boss = null;
            const int healId = 15586;
            const int renewId = 8362;

            return new PrioritySelector(ctx => boss = ctx as WoWUnit, ScriptHelpers.CreateInterruptCast(ctx => boss, healId, renewId));
        }

        private readonly Vector3 _emperorTankLoc = new Vector3(1380.191f, -807.5756f, -92.72278f);

        [EncounterHandler(9019, "Emperor Dagran Thaurissan")]
        public async Task<bool> EmperorDagranThaurissanEncounter(WoWUnit boss)
        {
            return await ScriptHelpers.DispelEnemy("Renew", ScriptHelpers.EnemyDispelType.Magic, boss)
                || await ScriptHelpers.TankUnitAtLocation(_emperorTankLoc, 5);
        }

        #region Shortcut
        private readonly WaitTimer _trashBeforeTheSevenTimer = WaitTimer.FiveSeconds;

        private bool _shouldAvoidTrashBeforeTheSeven;

        private readonly Vector3 _trashShortcutLoc = new Vector3(1158.5f, -137.6574f, -74.3636f);

        #endregion


        #region Golem Room South

        [ObjectHandler(170574, "Golem Room South", ObjectRange = 250)] // door that opens if the braziers are lit
        public Func<WoWGameObject, Task<bool>> LightTheBraziersHandler()
        {
            var flameKeeperPath = new CircularQueue<Vector3>
                                {
                                    new Vector3(1381.926f, -332.2724f, -92.0544f),
                                    new Vector3(1389.05f, -458.6602f, -93.66544f)
                                };
            // ensure we're on correct floor level before running this behavior.
            return async door =>
            {
                // if door is open or we're not on the correct floorlevel then encounter is not in progress.
                if (((WoWDoor)door.SubObj).IsOpen || Me.Z <= -100 || Me.Z >= -85)
                    return false;

                if (ScriptHelpers.IsBossAlive("Doom'rel") || !ScriptHelpers.IsBossAlive("Magmus"))
                    return false;

                // we only want to deal with the braziers if there's nothing to kill.
                if (!Targeting.Instance.IsEmpty())
                    return false;

                var southBrazier = ObjectManager.GetObjectsOfType<WoWGameObject>().FirstOrDefault(o => o.Entry == 174744);
                var northBrazier = ObjectManager.GetObjectsOfType<WoWGameObject>().FirstOrDefault(o => o.Entry == 174745);

                if (southBrazier != null && southBrazier.State == WoWGameObjectState.Active && !_southBrazierLighted)
                {
                    s_shadowForgeTorchLooted.Stop();
                    _southBrazierLighted = true;
                }

                if (northBrazier != null && northBrazier.State == WoWGameObjectState.Active && !_northBrazierLighted)
                {
                    s_shadowForgeTorchLooted.Stop();
                    _northBrazierLighted = true;
                }

                var brazer = !_northBrazierLighted ? northBrazier : southBrazier;
                var brazerLoc = !_northBrazierLighted ? _northBrazierLocation : _southBrazierLocation;

                // Go light a brazier
                if ((!_northBrazierLighted || !_southBrazierLighted) && (!s_shadowForgeTorchLooted.IsFinished || HasTorch))
                {
                    if (HasTorch && (Me.IsLeader() || Me.Location.DistanceSquared((Vector3)brazerLoc) < 30 * 30) && brazer != null)
                    {
                        ScriptHelpers.SetInteractPoi(brazer);
                        return false;
                    }
                    if (Me.Location.DistanceSquared((Vector3)brazerLoc) > 5 * 5)
                    {
                        ScriptHelpers.SetLeaderMoveToPoi(brazerLoc, brazer != null ? brazer.SafeName : "brazier");
                        return false;
                    }
                    // do nothing if leader and waiting at brazier for someone to light it.
                    return Me.IsLeader();
                }

                if (Me.IsLeader() && BotPoi.Current.Type == PoiType.None)
                {
                    if (Me.Location.DistanceSquared((Vector3)flameKeeperPath.Peek()) < 5 * 5)
                        flameKeeperPath.Dequeue();
                    ScriptHelpers.SetLeaderMoveToPoi(flameKeeperPath.Peek());
                }

                return false;
            };
        }

        #endregion

        #region The Seven

        [EncounterHandler(9039, "Doom'relt", Mode = CallBehaviorMode.Proximity, BossRange = 100)]
        public Func<WoWUnit, Task<bool>> TheSevenEncounter()
        {
            var shouldAvoid =
                new TimeCachedValue<bool>(TimeSpan.FromSeconds(2),
                    () => !Me.Combat && Me.Location.Distance(_trashShortcutLoc) < 100 * 100 &&
                          ScriptHelpers.GetUnfriendlyNpsAtLocation(_trashShortcutLoc, 20).Any());

            // Trash before 'The Seven' encounter
            AddAvoidLocation(() => Me.IsFollower() && shouldAvoid, 30, () => _trashShortcutLoc);
            var waitAtLoc = new Vector3(1263.587f, -257.3126f, -78.21929f);

            return async boss =>
            {
                if (Me.IsLeader() && !Me.Combat)
                {
                    if (boss.CanGossip)
                        return await ScriptHelpers.TalkToNpc(boss);

                    // don't do anything while waiting for combat... such as running off to look for next boss.
                    if (Targeting.Instance.IsEmpty())
                    {
                        if (Me.Location.Distance(waitAtLoc) > 4 * 4)
                            return (await CommonCoroutines.MoveTo(waitAtLoc)).IsSuccessful();
                        return true;
                    }
                }
                return false;
            };
        }

        #endregion
    }
}