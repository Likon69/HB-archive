﻿using System;
using System.Linq;
using System.Numerics;
using System.Threading.Tasks;

using Styx;
using Styx.CommonBot;
using Styx.CommonBot.Coroutines;
using Styx.CommonBot.POI;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using Bots.DungeonBuddy;
using Bots.DungeonBuddy.Attributes;
using Bots.DungeonBuddy.Helpers;

namespace DungeonBuddyScripts.Burning_Crusade.Dungeons
{
    public class OpeningOfTheDarkPortal : Dungeon
    {
        public override uint DungeonId => 171;

        private LocalPlayer Me => StyxWoW.Me;

        [EncounterHandler(20201, "Sa'at", Mode = CallBehaviorMode.Proximity, BossRange = 40)]
        public async Task<bool> QuestPickupTurninLogic(WoWUnit unit)
        {
            if (Me.IsActuallyInCombat || ScriptHelpers.WillPullAggroAtLocation(unit.Location))
                return false;
            if (unit.HasQuestAvailable(true))
                return await ScriptHelpers.PickupQuest(unit);
            if (unit.HasQuestTurnin())
                return await ScriptHelpers.TurninQuest(unit);
            return false;
        }

        [EncounterHandler(17838, "Time Rift", Mode = CallBehaviorMode.Proximity, BossRange = 200)]
        public async Task<bool> TimeRiftHandler(WoWUnit unit)
        {
            const uint mobIdAeonus = 17881;
            WoWUnit aeonusUnit = ObjectManager.GetObjectsOfType<WoWUnit>().FirstOrDefault(u => u.Entry == mobIdAeonus);
            if (aeonusUnit != null)
                return false;

            // Just make sure we go near any rifts that opens.
            if (Me.IsTank() && Targeting.Instance.IsEmpty())
            {
                await CommonCoroutines.MoveTo(unit.Location);
                return true;
            }

            return false;
        }

        private bool _eventStarted;
        [EncounterHandler(15608, "Medivh", Mode = CallBehaviorMode.Proximity, BossRange = 100)]
        public async Task<bool> DefendMedivhHandler(WoWUnit unit)
        {
            // Ignore Medivh after we killed the final boss.
            if (!ScriptHelpers.IsBossAlive("Aeonus"))
                return false;

            // Go help Medivh in case he's attacked, shouldn't happen if we move from rift to rift killing mobs tho.
            if (Me.IsTank() && Targeting.Instance.IsEmpty() && BotPoi.Current.Type == PoiType.None)
            {
                Vector3 medivhPosition = new Vector3(-2025.30f, 7119.58f, 22.66f);
                var attackingMedivh = ScriptHelpers.GetUnfriendlyNpsAtLocation(medivhPosition, 15f, u => u.IsHostile);
                if (attackingMedivh.Count != 0)
                {
                    ScriptHelpers.SetLeaderMoveToPoi(medivhPosition, "Medivh");
                }
            }

            return false;
        }

        [EncounterHandler(17879, "Chrono Lord Deja", Mode = CallBehaviorMode.Proximity, BossRange = 80)]
        public Func<WoWUnit, Task<bool>> ChronoLordDejaEncounter()
        {
            return async npc =>
            {
                return false;
            };
        }

        [EncounterHandler(17880, "Temporus", Mode = CallBehaviorMode.Proximity, BossRange = 80)]
        public Func<WoWUnit, Task<bool>> TemporusEncounter()
        {
            return async boss =>
            {
                if (boss.HasAura("Spell Reflection"))
                {
                    // Stop attacking if boss has Spell Reflection.
                    if (StyxWoW.Me.IsRange() && StyxWoW.Me.IsDps && StyxWoW.Me.PowerType == WoWPowerType.Mana)
                    {
                        if (Me.IsCasting)
                        {
                            SpellManager.StopCasting();
                            return true;
                        }
                    }

                    // Face the boss away from the party to avoid the breath attack.
                    var isTank = Me.IsTank();
                    var isTargetingMe = boss.CurrentTargetGuid == Me.Guid;
                    return isTank && isTargetingMe && await ScriptHelpers.TankFaceUnitAwayFromGroup(15);
                }

                return false;
            };
        }

        [EncounterHandler(17881, "Aeonus", Mode = CallBehaviorMode.Proximity, BossRange = 80)]
        public Func<WoWUnit, Task<bool>> AeonusEncounter()
        {
            return async boss =>
            {
                // Face the boss away from the party to avoid the breath attack.
                var isTank = Me.IsTank();
                var isTargetingMe = boss.CurrentTargetGuid == Me.Guid;
                return isTank && isTargetingMe && await ScriptHelpers.TankFaceUnitAwayFromGroup(15);
            };
        }
    }

    public class OpeningOfTheDarkPortalHeroic : OpeningOfTheDarkPortal
    {
        public override uint DungeonId => 182;
    }

    public class OpeningOfTheDarkPortalTimewalking : OpeningOfTheDarkPortal
    {
        public override uint DungeonId => 1012;
    }
}
