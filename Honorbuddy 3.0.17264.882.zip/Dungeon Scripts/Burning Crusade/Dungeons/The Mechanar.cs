using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Threading.Tasks;
using Bots.DungeonBuddy.Enums;
using CommonBehaviors.Actions;
using Styx;
using Styx.CommonBot;
using Styx.CommonBot.Frames;
using Styx.Pathing;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using Styx.TreeSharp;
using Action = Styx.TreeSharp.Action;
using Bots.DungeonBuddy.Attributes;
using Bots.DungeonBuddy.Helpers;
using Styx.Common;

namespace Bots.DungeonBuddy.Dungeon_Scripts.Burning_Crusade
{
    public class TheMechanar : Dungeon
    {
        #region Overrides of Dungeon

        public override uint DungeonId
        {
            get { return 172; }
        }

        public override Vector3 Entrance
        {
            get { return new Vector3(2860.672f, 1544.55f, 252.1591f); }
        }

        public override Vector3 ExitLocation
        {
            get { return new Vector3(-39.46347f, 0.2592911f, -1.812383f); }
        }

        public override bool IsFlyingCorpseRun
        {
            get { return true; }
        }

        public override void RemoveTargetsFilter(List<WoWObject> units)
        {
            units.RemoveAll(
                u =>
                {
                    var unit = u as WoWUnit;
                    if (unit != null)
                    {
                        if (unit is WoWPlayer)
                            return true;
                        if (unit.Entry == RagingFlamesId)
                            return true;
                    }
                    return false;
                });
        }

        public override void WeighTargetsFilter(List<Targeting.TargetPriority> units)
        {
            foreach (var priority in units)
            {
                var unit = priority.Object as WoWUnit;
                if (unit != null)
                {
                    if (StyxWoW.Me.IsDps)
                    {
                        if (unit.Entry == NetherWraithId)
                            priority.Score += 500;

                        if (StyxWoW.Me.IsRange() && unit.Entry == MechanarTinkererId)
                            priority.Score += 500;
                    }
                }
            }
        }

        public override void IncludeLootTargetsFilter(List<WoWObject> incomingObjects, HashSet<WoWObject> outgoingunits)
        {
            foreach (var obj in incomingObjects)
            {
                var gObj = obj as WoWGameObject;
                if (gObj != null && gObj.Entry == CacheoftheLegionId && gObj.CanUse() &&
                    DungeonBuddySettings.Instance.LootMode != LootMode.Off)
                {
                    outgoingunits.Add(gObj);
                }
            }
        }
        #endregion

        #region Root

        private const uint RagingFlamesId = 20481;
        private const uint NetherWraithId = 21062;
        private const uint MechanarTinkererId = 19716;
        private const uint BloodwarderSlayerId = 19167;
        private const uint LostTreasureQuestId = 29659;
        private const uint WithGreatPowerComesGreatResponsibilityQuestId = 29657;
        private const uint TheCalculatorQuestId = 29658;

        private LocalPlayer Me
        {
            get { return StyxWoW.Me; }
        }

        [EncounterHandler(0, "Root behavior")]
        public Composite RootBehavior()
        {
            PlayerQuest quest = null;
            return
                new PrioritySelector(
                    new Decorator(
                        ctx => (quest = Me.QuestLog.GetQuestById(WithGreatPowerComesGreatResponsibilityQuestId)) != null && quest.IsCompleted,
                        ScriptHelpers.CreateCompletePopupQuest(WithGreatPowerComesGreatResponsibilityQuestId)),
                    new Decorator(
                        ctx => (quest = Me.QuestLog.GetQuestById(LostTreasureQuestId)) != null && quest.IsCompleted,
                        ScriptHelpers.CreateCompletePopupQuest(LostTreasureQuestId)),
                    new Decorator(
                        ctx => (quest = Me.QuestLog.GetQuestById(TheCalculatorQuestId)) != null && quest.IsCompleted,
                        ScriptHelpers.CreateCompletePopupQuest(TheCalculatorQuestId)),
                    CreateFollowerElevatorBehavior());
        }

        [ObjectHandler(184228, "Instance_Portal_Difficulty_1", ObjectRange = 100)]
        public Composite EntranceTrashHandler()
        {
            var patroller1Loc = new Vector3(30.21965f, 2.915361f, -0.0006945329f);
            var trash1Loc = new Vector3(22.4355f, -20.95673f, 5.289912f);
            var trash2Loc = new Vector3(22.14023f, 20.44575f, -0.0001794659f);

            var tankLoc1 = new Vector3(-14.75135f, 0.7233489f, -1.8124f);
            var tankLoc2 = new Vector3(-27.63513f, 0.1582904f, -1.812397f);
            WoWUnit patroller1 = null, trash1 = null, trash2 = null;
            AddAvoidObject(() => Me.IsFollower(), 8, o => o.Entry == BloodwarderSlayerId && o.ToUnit().HasAura("Whirlwind"));

            return new PrioritySelector(
                ctx =>
                {
                    patroller1 = ScriptHelpers.GetUnfriendlyNpsAtLocation(patroller1Loc, 2, u => u.Entry == 19166).FirstOrDefault();
                    trash1 = ScriptHelpers.GetUnfriendlyNpsAtLocation(trash1Loc, 10, u => u.Entry != 19166).FirstOrDefault();
                    trash2 = ScriptHelpers.GetUnfriendlyNpsAtLocation(trash2Loc, 10, u => u.Entry != 19166).FirstOrDefault();
                    return ctx;
                },
                // pull the 1st patroller when he's alone.
                ScriptHelpers.CreatePullNpcToLocation(
                    ctx => patroller1 != null,
                    ctx => ScriptHelpers.GetUnfriendlyNpsAtLocation(patroller1Loc, 25, u => u.Entry == 19166).Count() == 1,
                    ctx => patroller1,
                    ctx => tankLoc2,
                    ctx => tankLoc1,
                    10),
                // pull trash group1 if no pats are close.
                ScriptHelpers.CreatePullNpcToLocation(
                    ctx => trash1 != null && !ScriptHelpers.GetUnfriendlyNpsAtLocation(trash1Loc, 20, u => u.Entry == 19166).Any(),
                    ctx => !ScriptHelpers.GetUnfriendlyNpsAtLocation(trash1Loc, 20, u => u.Entry == 19166).Any(),
                    ctx => trash1,
                    ctx => tankLoc1,
                    4),
                // pull trash group2 if no pats are close.
                ScriptHelpers.CreatePullNpcToLocation(
                    ctx => trash2 != null, ctx => !ScriptHelpers.GetUnfriendlyNpsAtLocation(trash2Loc, 20, u => u.Entry == 19166).Any(), ctx => trash2, ctx => tankLoc1, 4));
        }

        #endregion

        #region Mechano-Lord Capacitus

        private const uint NetherChargeId = 20405;

        [EncounterHandler(19219, "Mechano-Lord Capacitus")]
        public Composite MechanoLordCapacitusEncounter()
        {
            WoWUnit boss = null;
            AddAvoidObject(() => Me.IsFollower() && !Me.IsCasting, 8, NetherChargeId);
            AddAvoidObject<WoWUnit>(
                () => Me.IsFollower(),
                () => ScriptHelpers.Tank.Location,
                35,
                12,
                o =>
                o is WoWPlayer &&
                (o.ToPlayer().HasAura("Positive Charge") && Me.HasAura("Negative Charge") || o.ToPlayer().HasAura("Negative Charge") && Me.HasAura("Positive Charge")));

            return new PrioritySelector(ctx => boss = ctx as WoWUnit);
        }

        #endregion

        private HashSet<uint> _mobIds_GateWatchers = new HashSet<uint> { 19218, 19710 };

        [EncounterHandler(19218, "Gatewatcher Gyro-Kill")]
        [EncounterHandler(19710, "Gatewatcher Iron-Hand")]
        public Composite GatewatcherIronHandEncounter()
        {
            AddAvoidUnitCone(() => !Me.IsCasting, 0, 10, 180, u => _mobIds_GateWatchers.Contains(u.Entry) && !u.IsMoving && u.CurrentTarget != Me && u.Combat);

            return new PrioritySelector(
                ScriptHelpers.CreateTankFaceAwayGroupUnit(10));
        }

        private const uint CacheoftheLegionId = 184465;

        [EncounterHandler(19221, "Nethermancer Sepethrea", Mode = CallBehaviorMode.Proximity, BossRange = 60)]
        public Composite NethermancerSepethreaCapacitusEncounter()
        {
            WoWUnit boss = null;
            const uint RagingFlamesId = 20481;
            const uint RagingFlameSpellId = 35278;
            var InfernoIds = new[] { 35268, 39346 };

            AddAvoidObject<WoWUnit>(() => !Me.IsCasting, o => InfernoIds.Contains(o.ToUnit().CastingSpellId) || Me.IsRange() && Me.IsMoving ? 10 : 6, o => o.Entry == RagingFlamesId && o.ToUnit().IsAlive);
            AddAvoidObject<WoWDynamicObject>(2, RagingFlameSpellId);

            WoWUnit destroyer1 = null, destroyer2 = null, trash1 = null, trash2 = null;
            var destroyer1Loc = new Vector3(291.155f, 34.63794f, 25.38616f);
            var destroyer2Loc = new Vector3(296.6584f, -17.13713f, 25.3822f);
            var trash1Loc = new Vector3(309.3312f, 15.13393f, 25.38623f);
            var trash2Loc = new Vector3(272.1549f, -24.6583f, 26.3284f);

            var tankloc1 = new Vector3(276.8195f, 49.4281f, 25.38621f);
            var tankloc2 = new Vector3(275.7698f, 26.60911f, 25.38618f);

            return new PrioritySelector(
                ctx => boss = ctx as WoWUnit,
                new Decorator(
                    ctx => !boss.Combat,
                    new PrioritySelector(
                        ctx =>
                        {
                            destroyer1 = ScriptHelpers.GetUnfriendlyNpsAtLocation(destroyer1Loc, 20, u => u.Entry == 19735).FirstOrDefault();
                            destroyer2 = ScriptHelpers.GetUnfriendlyNpsAtLocation(destroyer2Loc, 20, u => u.Entry == 19735).FirstOrDefault();
                            trash1 = ScriptHelpers.GetUnfriendlyNpsAtLocation(trash1Loc, 8, u => true).FirstOrDefault();
                            trash2 = ScriptHelpers.GetUnfriendlyNpsAtLocation(trash2Loc, 8, u => true).FirstOrDefault();
                            return ctx;
                        },
                        ScriptHelpers.CreatePullNpcToLocation(ctx => destroyer1 != null, ctx => destroyer1, ctx => tankloc1, 10),
                        ScriptHelpers.CreatePullNpcToLocation(ctx => trash1 != null, ctx => trash1, ctx => tankloc1, 3),
                        ScriptHelpers.CreatePullNpcToLocation(ctx => destroyer2 != null, ctx => destroyer2, ctx => tankloc2, 10),
                        ScriptHelpers.CreatePullNpcToLocation(ctx => trash2 != null, ctx => trash2, ctx => tankloc2, 3))),
                new Decorator(
                    ctx => boss.Combat,
                    new PrioritySelector()));
        }

        [EncounterHandler(19220, "Pathaleon the Calculator")]
        public Composite PathaleonTheCalculatorEncounter()
        {
            const uint pathaleonTheCalculatorId = 19220;
            WoWUnit boss = null;
            AddAvoidObject(
                () => Me.IsRange() && !Me.IsCasting,
                25,
                o => o.Entry == pathaleonTheCalculatorId && o.ToUnit().IsAlive && o.ToUnit().CurrentTargetGuid != Me.Guid && !o.ToUnit().IsMoving);
            return new PrioritySelector(ctx => boss = ctx as WoWUnit);
        }

        #region Elevator

        private const float ElevatorBottomZ = 0;
        private const float ElevatorTopZ = 25.43577f;
        private const uint ElevatorId = 183788;
        private readonly Vector3 _elevatorBottomBoardLoc = new Vector3(257.019f, 52.3995f, 0.2461777f);
        private readonly Vector3 _elevatorBottomExitLoc = new Vector3(248.6114f, 52.36416f, 0.2290135f);

        private readonly Vector3 _elevatorTopBoardLoc = new Vector3(257.019f, 52.39949f, 25.67912f);
        private readonly Vector3 _elevatorTopExitLoc = new Vector3(265.7578f, 52.01247f, 25.64683f);

        private Composite CreateFollowerElevatorBehavior()
        {
            return new Decorator(
                ctx => !StyxWoW.Me.IsTank(),
                new Action(
                    ctx =>
                    {
                        var tank = ScriptHelpers.GroupMembers.FirstOrDefault(g => g.IsLeader());

                        if (tank != null && tank.Player != null)
                        {
                            var myFloorLevel = FloorLevel(Me.Location);
                            var tankLoc = tank.Location;
                            var tankLevel = FloorLevel(tankLoc);
                            var elevatorRestingZ = myFloorLevel == 1 ? ElevatorBottomZ : ElevatorTopZ;
                            var elevatorBoardLoc = myFloorLevel == 2 ? _elevatorTopBoardLoc : _elevatorBottomBoardLoc;
                            var elevatorWaitLoc = myFloorLevel == 2 ? _elevatorTopExitLoc : _elevatorBottomExitLoc;

                            // do we need to get on a lift?
                            if ((IsOnLift(tank.Player) || _elevatorBottomBoardLoc.Distance(tankLoc) < 8) && !IsOnLift(Me) && tankLevel == myFloorLevel)
                            {
                                var ele = ObjectManager.GetObjectsOfType<WoWGameObject>().FirstOrDefault(g => g.Entry == ElevatorId);
                                bool elevatorIsReadyToBoard = ele != null && Math.Abs(ele.Z - elevatorRestingZ) <= 0.5f;
                                if (elevatorIsReadyToBoard)
                                {
                                    if (Me.Location.DistanceSquared(elevatorBoardLoc) > 3 * 3)
                                    {
                                        Logger.Write("[Elevator Manager] Boarding Elevator");
                                        Navigator.PlayerMover.MoveTowards(elevatorBoardLoc);
                                    }
                                    else
                                    {
                                        Logger.Write("[Elevator Manager] Jumping");
                                        WoWMovement.Move(WoWMovement.MovementDirection.JumpAscend);
                                        WoWMovement.MoveStop(WoWMovement.MovementDirection.JumpAscend);
                                    }
                                }
                                return RunStatus.Success;
                            }
                            if (IsOnLift(Me))
                            {
                                var ele = ObjectManager.GetObjectsOfType<WoWGameObject>().FirstOrDefault(g => g.Entry == ElevatorId);
                                bool elevatorIsReadyToBoard = ele != null && Math.Abs(ele.Z - elevatorRestingZ) <= 0.5f;
                                // do we need to get off lift?
                                if (elevatorIsReadyToBoard && !IsOnLift(tank.Player) && tankLevel == myFloorLevel)
                                {
                                    Logger.Write("[Elevator Manager] Exiting Elevator");
                                    Navigator.PlayerMover.MoveTowards(elevatorWaitLoc);
                                }
                                else if (Me.Location.DistanceSquared(elevatorBoardLoc) > 3 * 3)
                                    Navigator.PlayerMover.MoveTowards(elevatorBoardLoc);
                                return RunStatus.Success;
                            }
                        }
                        return RunStatus.Failure;
                    }));
        }

        public bool ElevatorBehavior(Vector3 destination)
        {
            var myloc = StyxWoW.Me.Location;

            var myFloorLevel = FloorLevel(myloc);
            var destinationFloorLevel = FloorLevel(destination);

            if (myFloorLevel != destinationFloorLevel)
            {
                var ele = ObjectManager.GetObjectsOfType<WoWGameObject>().FirstOrDefault(g => g.Entry == ElevatorId);

                var elevatorRestingZ = myFloorLevel == 1 ? ElevatorBottomZ : ElevatorTopZ;
                var elevatorBoardLoc = destinationFloorLevel == 1 ? _elevatorTopBoardLoc : _elevatorBottomBoardLoc;
                var elevatorWaitLoc = destinationFloorLevel == 1 ? _elevatorTopExitLoc : _elevatorBottomExitLoc;
                bool elevatorIsReadyToBoard = ele != null && Math.Abs(ele.Z - elevatorRestingZ) <= 0.5f;

                // move to the
                if ((ele == null || myloc.DistanceSquared(elevatorBoardLoc) > 20 * 20 ||
                    !elevatorIsReadyToBoard && myloc.DistanceSquared(elevatorWaitLoc) > 4 * 4) &&
                    !Me.TransportGuid.IsValid)
                {
                    //  If we fall off elevator we can't navagate back to the 'elevatorWaitLoc' because of a too high of a step so we just wait
                    if (Me.Location.Distance(elevatorBoardLoc) < 8 && Me.Z < -1)
                        return true;
                    Logger.Write("[Elevator Manager] Moving To Elevator");
                    var moveResult = Navigator.MoveTo(elevatorWaitLoc);
                    return moveResult != MoveResult.Failed && moveResult != MoveResult.PathGenerationFailed;
                }
                // get onboard of elevator.
                if (elevatorIsReadyToBoard && myloc.DistanceSquared(elevatorBoardLoc) > 3 * 3)
                {
                    Logger.Write("[Elevator Manager] Boarding Elevator");
                    // avoid getting stuck on lever
                    Navigator.PlayerMover.MoveTowards(elevatorBoardLoc);
                }
                else if (elevatorIsReadyToBoard && myloc.DistanceSquared(elevatorBoardLoc) <= 3 * 3 && !Me.TransportGuid.IsValid)
                {
                    Logger.Write("[Elevator Manager] Jumping");
                    WoWMovement.Move(WoWMovement.MovementDirection.JumpAscend);
                    WoWMovement.MoveStop(WoWMovement.MovementDirection.JumpAscend);
                }
                return true;
            }

            // exit elevator
            var transport = Me.Transport;
            if (transport != null && transport.Entry == ElevatorId)
            {
                Logger.Write("[Elevator Manager] Exiting Elevator");
                var elevatorExitZ = destinationFloorLevel == 1 ? ElevatorBottomZ : ElevatorTopZ;
                var elevatorExitLoc = destinationFloorLevel == 1 ? _elevatorBottomExitLoc : _elevatorTopExitLoc;
                bool elevatorIsReadyToExit = Math.Abs(transport.Z - elevatorExitZ) <= 0.5f;
                if (elevatorIsReadyToExit && myFloorLevel == destinationFloorLevel)
                    Navigator.PlayerMover.MoveTowards(elevatorExitLoc);
                return true;
            }
            return false;
        }

        private bool IsOnLift(WoWPlayer player)
        {
            return player != null && player.TransportGuid.IsValid && player.Transport.Entry == ElevatorId;
        }

        private int FloorLevel(Vector3 loc)
        {
            return loc.Z < 20 ? 1 : 2;
        }

        public override async Task<bool> HandleMovement(MoveToParameters moveToParameters)
        {
            return ElevatorBehavior(moveToParameters.Location);
        }

        #endregion
    }

    public class TheMechanarHeroic : TheMechanar
    {
        public override uint DungeonId => 192;
    }
}