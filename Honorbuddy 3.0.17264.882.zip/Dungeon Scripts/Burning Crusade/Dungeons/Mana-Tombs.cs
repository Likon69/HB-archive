using System;
using System.Linq;
using System.Numerics;
using System.Threading.Tasks;
using CommonBehaviors.Actions;
using Styx;
using Styx.CommonBot;
using Styx.Pathing;
using Styx.WoWInternals.WoWObjects;
using Styx.TreeSharp;

using Bots.DungeonBuddy.Attributes;
using Bots.DungeonBuddy.Helpers;
using Styx.Common;
using Action = Styx.TreeSharp.Action;

namespace Bots.DungeonBuddy.Dungeon_Scripts.Burning_Crusade
{
    public class ManaTombs : Dungeon
    {
        #region Overrides of Dungeon

        public override uint DungeonId { get { return 148; } }

        public override Vector3 Entrance { get { return new Vector3(-3074.542f, 4943.176f, -101.0476f); } }

        public override Vector3 ExitLocation
        {
            get { return new Vector3(6.456772f, 0.9883103f, -0.9543309f); }
        }

        #endregion

        private LocalPlayer Me
        {
            get { return StyxWoW.Me; }
        }

        private readonly uint[] _entranceQuestIds = { 29574, 29573, 29575 };
        private readonly Vector3 _lastBossLocation = new Vector3(-184.3657f, 9.333467f, 16.73412f);

        [EncounterHandler(0)]
        public async Task<bool> RootBehavior()
        {
            // port outside and back in to hand in quests once dungeon is complete.
            // QuestPickupTurninHandler will handle the turnin
            return IsComplete && !Me.Combat
                    && _entranceQuestIds.Any(ScriptHelpers.IsQuestInLogComplete)
                    && LootTargeting.Instance.IsEmpty()
                    && Me.Location.DistanceSquared(_lastBossLocation) < 50 * 50
                    && await ScriptHelpers.PortOutsideAndBackIn();
        }

        [EncounterHandler(54694, "Mamdy the Ologist", Mode = CallBehaviorMode.Proximity, BossRange = 30)]
        [EncounterHandler(54692, "Artificer Morphalius", Mode = CallBehaviorMode.Proximity, BossRange = 30)]
        public async Task<bool> QuestPickupTurninHandler(WoWUnit npc)
        {
            if (Me.Combat || ScriptHelpers.WillPullAggroAtLocation(npc.Location))
                return false;
            return npc.HasQuestAvailable()
                ? await ScriptHelpers.PickupQuest(npc)
                : npc.HasQuestTurnin() && await ScriptHelpers.TurninQuest(npc);
        }

        [LocationHandler(-67.70435f, -56.33237f, -0.8602805f, 30, "Pandemonnis boss room.")]
        public Func<Vector3, Task<bool>> PandemonnisTrashHandler()
        {
            return async loc =>
            {
                Vector3 lineStart = new Vector3(-73.1573f, -43.83451f, -0.9541273f);
                Vector3 lineEnd = new Vector3(-62.23001f, -44.3026f, -0.9542542f);
                Vector3 pullPosition = new Vector3(-68.02682f, -15.71178f, -0.9440291f);

                if (!Me.Location.IsPointLeftOfLine(lineStart, lineEnd))
                    return false;

                WoWUnit trash = ScriptHelpers.GetUnfriendlyNpsAtLocation(loc, 50, u => u.Entry != MobId_Pandemonius && !u.Location.IsPointLeftOfLine(lineStart, lineEnd)).FirstOrDefault();
                if (trash == null)
                    return false;

                return await ScriptHelpers.PullNpcToLocation(() => true, trash, pullPosition, 5000);
            };
        }

        private const uint MobId_Pandemonius = 18341;

        [EncounterHandler(MobId_Pandemonius, "Pandemonius", Mode = CallBehaviorMode.Proximity, BossRange = 80)]
        public Composite PandemoniusEncounter()
        {
            WoWUnit boss = null;
            var pandemoniusRoomAddsloc1 = new Vector3(-44.84757f, -80.27489f, -2.326236f);
            var pandemoniusRoomAddsloc2 = new Vector3(-94.44795f, -85.13178f, -2.020432f);
            var pandemoniusTankSpot = new Vector3(-61.92603f, -95.23901f, -0.4504707f);

            return new PrioritySelector(
                ctx => boss = ctx as WoWUnit,
                new Decorator(
                    ctx => ScriptHelpers.GetUnfriendlyNpsAtLocation(pandemoniusRoomAddsloc1, 25, u => u != boss).Any(),
                    ScriptHelpers.CreateClearArea(() => pandemoniusRoomAddsloc1, 25, u => u != boss)),
                new Decorator(
                    ctx => !ScriptHelpers.GetUnfriendlyNpsAtLocation(pandemoniusRoomAddsloc1, 25, u => u != boss).Any(),
                    ScriptHelpers.CreateClearArea(() => pandemoniusRoomAddsloc2, 25, u => u != boss)),
                // stop attacking if boss has Dark Shell
                new Decorator(
                    ctx => boss.HasAura("Dark Shell") && StyxWoW.Me.IsRange() && StyxWoW.Me.IsDps && StyxWoW.Me.PowerType == WoWPowerType.Mana,
                    new PrioritySelector(
                        new Decorator(
                            ctx => StyxWoW.Me.IsCasting,
                            new Action(ctx => SpellManager.StopCasting())),
                        new ActionAlwaysSucceed())),
                new Decorator(
                    ctx => Targeting.Instance.FirstUnit == boss && boss.CurrentTargetGuid == Me.Guid,
                    ScriptHelpers.CreateTankUnitAtLocation(ctx => pandemoniusTankSpot, 3))
                );
        }

        private const uint MobId_Tavarok = 18343;

        [EncounterHandler(18343, "Tavarok")]
        public Composite TavarokEncounter()
        {
            AddAvoidUnitCone(() => !Me.IsTank(), 0, 15, 180, u => u.Entry == MobId_Tavarok && !u.IsMoving && u.CurrentTarget != Me && u.Combat);

            WoWUnit boss = null;
            return new PrioritySelector(ctx => boss = ctx as WoWUnit,
                ScriptHelpers.CreateTankFaceAwayGroupUnit(15)
                );
        }

        [EncounterHandler(18344, "Nexus-Prince Shaffar", Mode = CallBehaviorMode.Proximity)]
        public Composite NexusPrinceShaffarEncounter()
        {
            WoWUnit boss = null;
            return new PrioritySelector(
                ctx => boss = ctx as WoWUnit,
                ScriptHelpers.CreateClearArea(() => boss.Location, 70, u => u != boss)
                );
        }
    }

    public class ManaTombsHeroic : ManaTombs
    {
        public override uint DungeonId => 179;
    }

    public class ManaTombsTimewalking : ManaTombs
    {
        public override uint DungeonId => 1013;
    }
}