﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.WebSockets;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;
using Bots.DungeonBuddy;
using Bots.DungeonBuddy.Attributes;
using Bots.DungeonBuddy.Helpers;
using Styx;
using Styx.Common;
using Styx.CommonBot;
using Styx.CommonBot.Coroutines;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;

namespace DungeonBuddyScripts.Burning_Crusade.Dungeons
{
    public class TheArcatraz : Dungeon
    {
        #region Overrides of Dungeon

        public override uint DungeonId => 174;

        public override void RemoveTargetsFilter(List<WoWObject> units)
        {
            units.RemoveAll(
                ret =>
                {
                    var unit = ret as WoWUnit;
                    // Make sure we remove the Protean Horrors where they spawn idefinently to avoid getting stuck.
                    if (unit != null && unit.Entry == MobId_ProteanHorror && unit.Location.DistanceSquared(new Vector3(169.5233f, 2.316799f, -10.09738f)) < 45 * 45)
                        return true;

                    return false;
                });
        }

        public override void RemoveLootTargetsFilter(List<WoWObject> objects)
        {
            objects.RemoveAll(
                ret =>
                {
                    var unit = ret as WoWUnit;
                    // Make sure we remove the Protean Horrors where they spawn idefinently to avoid getting stuck.
                    if (unit != null && unit.Entry == MobId_ProteanHorror && unit.Location.DistanceSquared(new Vector3(169.5233f, 2.316799f, -10.09738f)) < 45 * 45)
                        return true;

                    return false;
                });
        }

        public override void WeighTargetsFilter(List<Targeting.TargetPriority> units)
        {
            HashSet<uint> skyrissClones = new HashSet<uint>
            {
                21466,
                21467
            };

            foreach (var priority in units)
            {
                var unit = priority.Object as WoWUnit;
                if (unit != null)
                {
                    // Give a higher weight to the one one with the lowest health.
                    if (skyrissClones.Contains(unit.Entry))
                    {
                        priority.Score = 5000 - unit.HealthPercent;
                    }
                }
            }
        }

        #endregion

        private LocalPlayer Me => StyxWoW.Me;

        #region Stuck Handlers

        public override DungeonStuckHandler[] StuckHandlers { get; } = {
            new SoccothratesStuckHandler(),
        };

        private class SoccothratesStuckHandler : DungeonStuckHandler
        {
            private readonly Vector3 _stuckLocation = new Vector3(154.1443f, 176.5023f, 22.39046f);

            protected override bool IsStuck
                => StyxWoW.Me.Location.DistanceSquared(_stuckLocation) < 4 * 4;

            protected override Vector3 UnstickMoveTo { get; } = new Vector3(149.1499f, 177.2623f, 22.44115f);
            protected override string StuckAreaName { get; } = "Behind Crates, pushed by Soccothrates?";
        }

        #endregion

        #region Safe pulling/Trash


        [LocationHandler(384.5475f, 22.2709f, 48.21268f, 50, "Room before last one")]
        public Func<Vector3, Task<bool>> LastRoomTrashHandler1()
        {
            return async loc =>
            {
                Vector3 lineStart = new Vector3(436.537f, -32.46439f, 48.21453f);
                Vector3 lineEnd = new Vector3(455.0504f, -32.83309f, 48.248f);

                if (!Me.Location.IsPointLeftOfLine(lineStart, lineEnd))
                    return false;

                // If there's less than 3 trash mobs left just move towards the boss like normal.
                WoWUnit trash = ScriptHelpers.GetUnfriendlyNpsAtLocation(loc, 50, u => u.Location.IsPointLeftOfLine(lineStart, lineEnd)).FirstOrDefault();
                if (trash == null)
                    return false;

                // We need to make sure the roaming pack doesn't get pulled at the same time, it's a 100% wipe if we do.
                var movingPack = ScriptHelpers.GetUnfriendlyNpsAtLocation(loc, 80f, u => u.IsMoving).FirstOrDefault();
                if (movingPack == null)
                    return false;

                return await ScriptHelpers.PullNpcToLocation(() => movingPack.Location.DistanceSquared(trash.Location) > 30f, trash, loc, 5000);
            };
        }


        [LocationHandler(445.7253f, -44.50898f, 48.21691f, 110, "Last Room (Skyriss) Trash Handler")]
        public Func<Vector3, Task<bool>> LastRoomTrashHandler2()
        {
            HashSet<uint> unwantedPulls = new HashSet<uint> {
                MobId_WardenMellichar
            };

            Vector3 trashPackCenter = new Vector3(444.31f, -110.02f, 43.10f);

            Vector3 lineStart = new Vector3(436.537f, -32.46439f, 48.21453f);
            Vector3 lineEnd = new Vector3(455.0504f, -32.83309f, 48.248f);


            return async loc =>
            {
                // Ignore this when we are to the left of this line to avoid running into angry mobs
                if (Me.Location.IsPointLeftOfLine(lineStart, lineEnd))
                    return false;

                List<WoWUnit> trashMobs = ScriptHelpers.GetUnfriendlyNpsAtLocation(trashPackCenter, 120, u => !unwantedPulls.Contains(u.Entry));
                if (trashMobs.Count <= 3)
                    return false;

                var trash = trashMobs.FirstOrDefault();
                if (trash == null)
                    return false;

                return await ScriptHelpers.PullNpcToLocation(() => ScriptHelpers.IsViable(trash), trash, loc, 6000);
            };
        }

        [LocationHandler(218.8245f, 146.3857f, 22.35582f, 40, "Room before Dalliah and Soccothrates Trash Handler")]
        [LocationHandler(267.5732f, -40.0289f, 22.43036f, 60, "Warp-Master Trash Handler")]
        [LocationHandler(301.631f, 93.34056f, 22.29092f, 60, "Eredar Death/Soul eater Trash Handler")]
        public Func<Vector3, Task<bool>> TrashHandlers()
        {
            HashSet<uint> unwantedPulls = new HashSet<uint> {
                MobId_ProteanHorror,
                MobId_ProteanSpawn,
                MobId_DalliahTheDoomsayer,
                MobId_WrathScryerSoccothrates
            };

            return async loc =>
            {
                //if (ScriptHelpers.IsBossAlive(MobId_ZerekethTheUnbound))
                //    return false;

                var trash = ScriptHelpers.GetUnfriendlyNpsAtLocation(loc, 110, u => u.ZDiff <= 5 && !unwantedPulls.Contains(u.Entry)).FirstOrDefault();
                if (trash == null)
                    return false;

                return await ScriptHelpers.PullNpcToLocation(() => ScriptHelpers.IsViable(trash), trash, loc, 5000);
            };
        }

        #endregion

        #region Zereketh the Unbound

        private const uint MobId_ZerekethTheUnbound = 20870;
        private const uint MobId_UnboundVoidZone = 21101;
        private const uint MobId_ProteanHorror = 20865;
        private const uint MobId_ProteanSpawn = 21395;
        private const uint SpellId_ShadowNova = 39005;

        [EncounterHandler(MobId_ZerekethTheUnbound, "Zereketh the Unbound", Mode = CallBehaviorMode.Proximity, BossRange = 100)]
        public Func<WoWUnit, Task<bool>> ZerekethEncounter()
        {
            // Avoid Unbound Void Zone spawned by http://www.wowhead.com/spell=36119/void-zone
            AddAvoidObject(() => true, 8, o => o.Entry == MobId_UnboundVoidZone);

            // Ranged should stay away from boss to not get hit by the Shadow Nova. http://www.wowhead.com/spell=39005
            AddAvoidObject(
                () => Me.IsRange() && !Me.IsCasting && ScriptHelpers.Tank != null && ScriptHelpers.Tank.IsAlive,
                50,
                o => o.Entry == MobId_ZerekethTheUnbound && o.ToUnit().Combat && o.ToUnit().CurrentTargetGuid != Me.Guid && o.ToUnit().CastingSpellId == SpellId_ShadowNova);

            // Seed of Corruption is a dot that deals shadow damage to all enemies within 10 yards of the corrupted target
            // Ignore if we are the tank.
            AddAvoidObject(() => !Me.IsTank(), 13, o => o is WoWPlayer && !o.IsMe && (o.ToPlayer().GetAllAuras().Any(a => a.Name == "Seed of Corruption")));

            return async boss =>
            {
                // Clear the room before pulling the boss.
                var packLoc = new Vector3(237.6797f, -152.7494f, -10.10709f);
                var pullLoc = new Vector3(202.0857f, -111.1541f, -10.12302f);

                // Skip protean horrors.
                var trash = ScriptHelpers.GetUnfriendlyNpsAtLocation(packLoc, 60, u => u != boss && !new[] { MobId_ProteanHorror, MobId_ProteanSpawn }.Contains(u.Entry)).FirstOrDefault();

                if (await ScriptHelpers.PullNpcToLocation(() => trash != null, trash, pullLoc, 7000, 2))
                    return true;

                return false;
            };
        }

        #endregion

        #region Dalliah the Doomsayer

        private const uint MobId_DalliahTheDoomsayer = 20885;

        [EncounterHandler(MobId_DalliahTheDoomsayer, "Dalliah the Doomsayer", Mode = CallBehaviorMode.Proximity, BossRange = 80)]
        public Func<WoWUnit, Task<bool>> DalliahEncounter()
        {
            AddAvoidObject(() => !Me.IsTank(), 15, o => o.Entry == MobId_DalliahTheDoomsayer && o.ToUnit().HasAura("Whirlwind"));

            return async boss =>
            {
                return false;
            };
        }

        #endregion

        #region Wrath-Scryer Soccothrates

        private const uint MobId_WrathScryerSoccothrates = 20886;

        [EncounterHandler(MobId_WrathScryerSoccothrates, "Wrath-Scryer Soccothrates", Mode = CallBehaviorMode.Proximity, BossRange = 80)]
        public Func<WoWUnit, Task<bool>> WrathScryerSoccothratesEncounter()
        {
            return async boss =>
            {
                return false;
            };
        }

        #endregion

        #region Harbinger Skyriss

        private const uint MobId_WardenMellichar = 20904;

        [EncounterHandler(MobId_WardenMellichar, "Warden Mellichar", Mode = CallBehaviorMode.Proximity, BossRange = 80)]
        public Func<WoWUnit, Task<bool>> WardenMellicharHandler()
        {
            return async npc =>
            {
                return false;
            };
        }

        private const uint MobId_HarbingerSkyriss = 20904;

        [EncounterHandler(MobId_HarbingerSkyriss, "Harbinger Skyriss", Mode = CallBehaviorMode.Proximity, BossRange = 80)]
        public Func<WoWUnit, Task<bool>> HarbingerSkyrissEncounter()
        {
            return async boss =>
            {
                WoWPlayer dominatedPlayer =
                    ObjectManager.GetObjectsOfType<WoWPlayer>().FirstOrDefault(p => p.HasAura("Complete Domination"));

                // taunt whatever player that gets the complete domination debuff.
                if (dominatedPlayer != null && dominatedPlayer != StyxWoW.Me && StyxWoW.Me.Class == WoWClass.Warrior &&
                    SpellManager.CanCast("Taunt"))
                {
                    SpellManager.Cast("Taunt", dominatedPlayer);
                    return true;
                }

                return false;
            };
        }

        #endregion
    }

    public class TheArcatrazHeroic : TheArcatraz
    {
        public override uint DungeonId => 190;
    }

    public class TheArcatrazTimewalking : TheArcatraz
    {
        public override uint DungeonId => 1011;
    }
}