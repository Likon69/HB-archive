﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Threading.Tasks;
using Bots.DungeonBuddy.Attributes;
using Bots.DungeonBuddy.DungeonScripts.WarlordsOfDraenor;
using Bots.DungeonBuddy.Enums;
using Bots.DungeonBuddy.Helpers;
using Buddy.Coroutines;
using Styx;
using Styx.Common;
using Styx.Common.Helpers;
using Styx.CommonBot;
using Styx.CommonBot.Coroutines;
using Styx.CommonBot.Frames;
using Styx.CommonBot.POI;
using Styx.CommonBot.Routines;
using Styx.Helpers;
using Styx.Pathing;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;

// ReSharper disable CheckNamespace

namespace Bots.DungeonBuddy.DungeonScripts.WarlordsOfDraenor
// ReSharper restore CheckNamespace
{
    #region Normal Difficulty

    public class Skyreach : WoDDungeon
    {
        #region Overrides of Dungeon

        public override uint DungeonId => 779;

        public override Vector3 Entrance => new Vector3(22.00776f, 2522.445f, 104.4983f);

        // Must talk to Shadow-Sage Iskar (Id: 82376) and click the confirmation popup to exit. 
        // Call lua func SelectGossipOption(1) to confirm
        public override Vector3 ExitLocation => new Vector3(1121.187f, 1811.161f, 262.1724f);

        public override void RemoveTargetsFilter(List<WoWObject> units)
        {
            var isTank = Me.IsTank();
            var isHealer = Me.IsHealer;
            List<WoWUnit> ashes = null;
            units.RemoveAll(
            obj =>
            {
                var unit = obj as WoWUnit;
                if (unit == null)
                    return false;

                //// We want to ignore Ranjit while we're LOSing his quills ability.
                //// Some CRs (such as Singular) only do healing from Combat behavior and Combat only gets called when we have a kill target
                //// so inorder to keep the healer healing we make sure he/she has a kill target by not removing the boss from targeting if a healer.
                //if (unit.Entry == MobId_Ranjit && !isHealer && IsCastingQuills(unit))
                //	return true; 

                if (unit.Entry == MobId_SolarFlare)
                {
                    if (isTank)
                        return true;

                    if (ashes == null)
                    {
                        ashes = ObjectManager.GetObjectsOfType<WoWUnit>()
                            .Where(u => u.Entry == MobId_PileofAsh && u.HasAura("Dormant")).ToList();
                    }
                    // Killing a Solar Flare by an ash will cause another solar flare to spawn
                    if (ashes.Any(u => u.Location.DistanceSquared((Vector3)unit.Location) <= 5 * 5))
                        return true;
                }
                return false;
            });
        }

        public override void IncludeTargetsFilter(List<WoWObject> incomingunits, HashSet<WoWObject> outgoingunits)
        {
            var isDps = Me.IsDps;
            foreach (var obj in incomingunits)
            {
                var unit = obj as WoWUnit;
                if (unit != null)
                {
                    if ((unit.Entry == MobId_SolarFlare || unit.Entry == MobId_SolarZealot) && isDps)
                        outgoingunits.Add(unit);
                }
            }
        }

        public override void WeighTargetsFilter(List<Targeting.TargetPriority> units)
        {
            var isDps = Me.IsDps;
            foreach (var priority in units)
            {
                var unit = priority.Object as WoWUnit;
                if (unit != null)
                {
                    switch (unit.Entry)
                    {
                        case MobId_PileofAsh:
                            if (isDps && !unit.HasAura("Dormant"))
                                priority.Score += 4500;
                            break;
                        case MobId_SolarMagnifier:
                        case MobId_SolarFamiliar:
                        case MobId_SunTrinket:
                        case MobId_DefenseConstruct:
                            if (isDps)
                                priority.Score += 4500;
                            break;
                        // These shield High Sage Viryx
                        case MobId_SkyreachShieldConstruct:
                            priority.Score += 4500;
                            break;
                        // Will carry a palyer off the platform during High Sage Viryx encounter unlessed killed first.
                        case MobId_SolarZealot:
                            priority.Score += 5000;
                            break;
                    }
                }
            }
        }

        public override void OnEnter()
        {
            _showedDungeonLeaveAlert = false;
        }

        public override async Task<bool> HandleMovement(MoveToParameters moveToParameters)
        {
            if (Me.MapId != LfgDungeon.MapId)
                return false;

            var rukhran = ObjectManager.GetObjectsOfType<WoWUnit>().FirstOrDefault(u => u.Entry == MobId_Rukhran);
            if (rukhran != null && rukhran.Location.DistanceSquared(moveToParameters.Location) < 3 * 3 )
            {
                if (rukhran.Location.DistanceSquared(_rukkranFightLoc) > 3*3)
                    return (await CommonCoroutines.MoveTo(_rukkranEncounterMoveToLoc, rukhran.SafeName)).IsSuccessful();

                moveToParameters.DistanceTolerance = rukhran.MeleeRange;
            }

            var destination = moveToParameters.Location;
            return await HandleTrashPackAtSecondBoss(destination) || await HandleTrashPackAtLastBoss(destination);
        }



        #region Trash pack at second boss.


        private readonly Vector3 _secondBossAreaRightDividerLoc = new Vector3(1125.492f, 1805.031f, 203.0741f);
        private readonly Vector3 _secondBossAreaRightFromLoc = new Vector3(1118.058f, 1775.238f, 203.1127f);
        private readonly Vector3 _secondBossAreaRightToLoc = new Vector3(1103.169f, 1796.79f, 206.5254f);
        private readonly Vector3 _secondBossAreaRightTrashLoc = new Vector3(1115.879f, 1780.179f, 202.9964f);

        private readonly Vector3 _secondBossAreaLeftDividerLoc = new Vector3(1082.289f, 1737.848f, 203.6725f);
        private readonly Vector3 _secondBossAreaLeftFromLoc = new Vector3(1103.845f, 1755.614f, 203.0968f);
        private readonly Vector3 _secondBossAreaLeftToLoc = new Vector3(1078.729f, 1763.467f, 206.8463f);
        private bool LocationIsAtFirstBossArea(Vector3 location)
        {
            return location.Z < 210 &&
                   location.IsPointLeftOfLine(_secondBossAreaRightDividerLoc, _secondBossAreaLeftDividerLoc);
        }

        private async Task<bool> HandleTrashPackAtSecondBoss(Vector3 location)
        {
            var myLoc = Me.Location;

            // skip pack when moving to last boss
            if (LocationIsAtFirstBossArea(myLoc) && !LocationIsAtFirstBossArea(location))
            {
                var moveTo = ScriptHelpers.GetUnfriendlyNpsAtLocation(_secondBossAreaRightTrashLoc, 25).Any()
                    ? _secondBossAreaLeftToLoc
                    : _secondBossAreaRightToLoc;

                return (await CommonCoroutines.MoveTo(moveTo)).IsSuccessful();
            }

            // skip pack when moving from last boss
            if (!LocationIsAtFirstBossArea(myLoc) && LocationIsAtFirstBossArea(location))
            {
                var moveTo = ScriptHelpers.GetUnfriendlyNpsAtLocation(_secondBossAreaRightTrashLoc, 25).Any()
                    ? _secondBossAreaLeftFromLoc
                    : _secondBossAreaRightFromLoc;

                return (await CommonCoroutines.MoveTo(moveTo)).IsSuccessful();
            }
            return false;
        }

        #endregion

        #region Tash pack at last boss.

        private readonly Vector3 _lastBossRoomRightDividerLoc = new Vector3(1002.321f, 1794.205f, 250.2783f);
        private readonly Vector3 _lastBossRoomRightFromLastBossLoc = new Vector3(995.3442f, 1804.726f, 251.2998f);
        private readonly Vector3 _lastBossRoomRightToLastBossLoc = new Vector3(1005.608f, 1782.034f, 251.3277f);
        private readonly Vector3 _lastBossRoomRightTrashLoc = new Vector3(1025.469f, 1777.403f, 250.2384f);

        private readonly Vector3 _lastBossRoomLeftDividerLoc = new Vector3(1048.394f, 1859.494f, 250.2784f);
        private readonly Vector3 _lastBossRoomLeftFromLastBossLoc = new Vector3(1035.113f, 1861.594f, 251.2999f);
        private readonly Vector3 _lastBossRoomLeftToLastBossLoc = new Vector3(1064.887f, 1858.256f, 251.3279f);
        private bool LocationIsAtLastBoss(Vector3 location)
        {
            return location.Z > 245 &&
                   location.IsPointLeftOfLine(_lastBossRoomLeftDividerLoc, _lastBossRoomRightDividerLoc);
        }

        private async Task<bool> HandleTrashPackAtLastBoss(Vector3 location)
        {
            var myLoc = Me.Location;

            // skip pack when moving to last boss
            if (!LocationIsAtLastBoss(myLoc) && LocationIsAtLastBoss(location))
            {
                var moveTo = ScriptHelpers.GetUnfriendlyNpsAtLocation(_lastBossRoomRightTrashLoc, 25).Any()
                    ? _lastBossRoomLeftToLastBossLoc
                    : _lastBossRoomRightToLastBossLoc;

                return (await CommonCoroutines.MoveTo(moveTo)).IsSuccessful();
            }

            // skip pack when moving from last boss
            if (LocationIsAtLastBoss(myLoc) && !LocationIsAtLastBoss(location))
            {
                var moveTo = ScriptHelpers.GetUnfriendlyNpsAtLocation(_lastBossRoomRightTrashLoc, 25).Any()
                    ? _lastBossRoomLeftFromLastBossLoc
                    : _lastBossRoomRightFromLastBossLoc;

                return (await CommonCoroutines.MoveTo(moveTo)).IsSuccessful();
            }
            return false;
        }

        #endregion


        #endregion

        #region Root

        private static LocalPlayer Me { get { return StyxWoW.Me; } }

        private static readonly Vector3[] s_windPath =
        {
            new Vector3(958.7506f, 1899.613f, 215.1132f),
            new Vector3(991.1855f, 1915.5f, 227.9198f),
            new Vector3(989.8868f, 1928.845f, 227.8823f),
            new Vector3(993.5295f, 1935.617f, 227.8823f),
            new Vector3(1000.47f, 1941.263f, 227.8823f),
            new Vector3(1013.008f, 1944.458f, 227.8823f),
            new Vector3(1021.958f, 1941.863f, 227.8823f),
            new Vector3(1027.734f, 1935.086f, 227.9031f),
            new Vector3(1031.265f, 1923.598f, 227.8823f),
            new Vector3(1028.775f, 1919.856f, 227.7367f),
            new Vector3(1023.285f, 1923.882f, 227.6823f),
            new Vector3(1020.629f, 1932.105f, 227.6823f),
            new Vector3(1014.836f, 1936.723f, 227.6823f),
            new Vector3(1007.047f, 1937.06f, 227.6823f),
            new Vector3(1000.579f, 1933.303f, 227.6823f),
            new Vector3(997.6884f, 1927.151f, 227.6823f),
            new Vector3(998.5137f, 1919.573f, 227.6823f),
            new Vector3(1001.279f, 1903.705f, 228.0616f),
            new Vector3(1000.151f, 1889.907f, 231.0617f),
            new Vector3(998.2874f, 1882.888f, 235.5307f),
            new Vector3(995.3996f, 1870.825f, 240.8472f),
        };

        [EncounterHandler(0, "Root")]
        public Func<WoWUnit, Task<bool>> RootHandler()
        {
            return async npc =>
            {
                if (Me.HasAura("Cloak"))
                {
                    TreeRoot.StatusText = "Taking Dread Raven ride to instance entrace";
                    return true;
                }
                if (Me.HasAura("Wind"))
                    await FollowWindPath();
                return false;
            };
        }

        private bool _showedDungeonLeaveAlert;

        private async Task FollowWindPath()
        {
            var index = 1;
            var shortestDist = float.MaxValue;
            var myLoc = Me.Location;
            var path = s_windPath;
            // cycle to the nearest path segment
            for (int i = 1; i < path.Length; i++)
            {
                var dist = WoWMathHelper.GetNearestPointOnLineSegment(myLoc, path[i - 1], path[i]).Distance(myLoc);
                if (dist < shortestDist)
                {
                    index = i;
                    shortestDist = dist;
                }
            }

            var timer = WaitTimer.TenSeconds;
            timer.Reset();
            while (!Navigator.AtLocation(path.Last()) && index < path.Length)
            {
                if (!Me.IsAlive)
                {
                    Logger.Write("Died. Canceling wind path follow");
                    return;
                }

                if (timer.IsFinished)
                {
                    if (Me.GroupInfo.IsInParty)
                    {
                        if (!_showedDungeonLeaveAlert)
                        {
                            Logger.Write("Got stuck while following wind path. Leaving group unless user intervenes.");
                            Alert.Show(
                                "Dungeonbuddy, Skyreach: Stuck at Wind Path",
                                "It appears your toon got stuck while following the 'Wind Path' in Skyreach and will automatically leave group unless you intervene and cancel leave",
                                15,
                                cancelAction: () => Lua.DoString("LeaveParty()"),
                                cancelButtonText: "Leave group");
                            _showedDungeonLeaveAlert = true;
                        }
                        return;
                    }
                    Logger.Write("Got stuck while following wind path. Stopping HB.");
                    TreeRoot.Stop();
                    return;
                }

                if (Navigator.AtLocation(path[index]))
                {
                    timer.Reset();
                    index++;
                }

                var moveTo = path[index];
                WoWMovement.ClickToMove(moveTo);
                await Coroutine.Yield();
            }
        }

        [EncounterHandler(84782, "Reshad", Mode = CallBehaviorMode.Proximity)]
        public async Task<bool> ReshadEncounter(WoWUnit npc)
        {
            if (!npc.CanGossip || DungeonBuddySettings.Instance.DungeonType != DungeonType.Farm)
                return false;

            await ScriptHelpers.TalkToNpc(npc);
            Lua.DoString("SelectGossipOption(1, 1, 1)");
            return true;
        }

        #endregion

        #region Garrison Inn Quests

        [ObjectHandler(237467, "Pristine Plumage", ObjectRange = 30)]
        public async Task<bool> PristinePlumageHandler(WoWGameObject gObj)
        {
            return await SafeInteractWithGameObject(gObj, 40);
        }

        [ObjectHandler(237466, "Sun Crystal", ObjectRange = 35)]
        public async Task<bool> SunCrystalHandler(WoWGameObject gObj)
        {
            return await SafeInteractWithGameObject(gObj, 45);
        }

        [ObjectHandler(237480, "Bottled Windstorm", ObjectRange = 35)]
        public async Task<bool> BottledWindstormHandler(WoWGameObject gObj)
        {
            return await SafeInteractWithGameObject(gObj, 45);
        }

        #endregion

        #region Ranjit

        #region Trash

        private const int SpellId_ThrowChakram = 169689;
        private const int SpellId_SolarHeal = 152893;
        private const int SpellId_FlashHeal = 152894;
        private const int SpellId_SolarWrath = 157020;
        private const int SpellId_FlashBang = 152953;

        private const uint AreaTriggerId_Storm = 6420;
        private const uint MobId_SolarMagnifier = 77559;
        private const uint MobId_DivingChakramSpinner = 76116;
        private const uint MobId_WhirlingDervish = 77605;
        private const uint MobId_HeraldofSunrise = 78933;
        private const uint MobId_BloodedBladefeather = 76205;
        private const uint MobId_SoaringChrakramMaster = 76132;
        private const uint MobId_BlindingSolarFlare = 79462;
        private const uint MobId_SolarFamiliar = 76097;

        private const uint AreaTriggerId_SpinningBlade = 6038;
        private const uint AreaTriggerId_SolarZone = 6743;

        [LocationHandler(1269.863, 1763.272, 177.196, 20, "Ranjit Trash Handler 1")]
        public Func<Vector3, Task<bool>> RanjitTrashHandler1()
        {
            var packLoc = new Vector3(1290.827f, 1732.28f, 177.1701f);
            return async loc =>
            {
                if (Me.Combat || !Me.IsTank())
                    return false;
                var trash = ScriptHelpers.GetUnfriendlyNpsAtLocation(packLoc, 14).FirstOrDefault();

                if (await ScriptHelpers.PullNpcToLocation(() => trash != null, trash, loc, 5000, 2))
                    return true;
                return false;
            };
        }

        [LocationHandler(1290.912, 1747.058, 177.1656, 30, "Ranjit Trash Handler 2")]
        public Func<Vector3, Task<bool>> RanjitTrashHandler2()
        {
            var packLoc = new Vector3(1291.937f, 1702.007f, 177.2466f);
            return async loc =>
            {
                if (Me.Combat || !Me.IsTank())
                    return false;
                var trash = ScriptHelpers.GetUnfriendlyNpsAtLocation(packLoc, 20).ToList();
                // pull the 2nd group when pat isn't around.
                if (trash.Any() && await ScriptHelpers.PullNpcToLocation(trash.Any, () => trash.Count <= 3, trash.First(), loc, loc, 5000, 2))
                    return true;
                return false;
            };
        }

        [EncounterHandler((int)MobId_DivingChakramSpinner, "Diving Chakram Spinner")]
        public Func<WoWUnit, Task<bool>> DivingChakramSpinnerHandler()
        {
            AddAvoidObject(() => true, 2, AreaTriggerId_SpinningBlade);
            return async npc => await ScriptHelpers.InterruptCast(npc, SpellId_ThrowChakram);
        }

        [EncounterHandler((int)MobId_BloodedBladefeather, "Blooded Bladefeather")]
        public Func<WoWUnit, Task<bool>> BloodedBladefeatherHandler()
        {
            // windup attack that causes mob to charge forward, doing damage to anyone in path
            AddAvoidObject(() => true, 5,
                o => o.Entry == MobId_BloodedBladefeather && o.ToUnit().HasAura("Piercing Rush"),
                o => Me.Location.GetNearestPointOnSegment(o.Location, o.Location.RayCast(o.Rotation, 25)));

            return async npc => false;
        }

        [EncounterHandler((int)MobId_WhirlingDervish, "Whirling Dervish")]
        public Func<WoWUnit, Task<bool>> WhirlingDervishSunHandler()
        {
            AddAvoidObject(() => true, 3, AreaTriggerId_Storm);

            return async npc => false;
        }

        [EncounterHandler((int)MobId_HeraldofSunrise, "Herald of Sunrise")]
        public Func<WoWUnit, Task<bool>> HeraldofSunriseHandler()
        {
            // Pull mobs out of the effect since it heals them.
            AddAvoidObject(
                () => Me.IsTank() && Targeting.Instance.TargetList.All(t => t.Aggro)
                    && Targeting.Instance.TargetList.Any(t => t.HasAura("Solar Zone")),
                15,
                AreaTriggerId_SolarZone);

            return async npc => await ScriptHelpers.InterruptCast(npc, SpellId_SolarHeal, SpellId_FlashHeal);
        }

        [EncounterHandler((int)MobId_SoaringChrakramMaster, "Soaring Chrakram Master")]
        public Func<WoWUnit, Task<bool>> SoaringChrakramMasterHandler()
        {
            return async npc => false;
        }

        [EncounterHandler((int)MobId_BlindingSolarFlare, "Blinding Solar Flare")]
        public Func<WoWUnit, Task<bool>> BlindingSolarFlareHandler()
        {
            // player does aoe damage to party members when Solar Detonation expires
            AddAvoidObject(
                () => true,
                2,
                o => o is WoWPlayer && !o.IsMe && (o.ToPlayer().HasAura("Solar Detonation") || Me.HasAura("Solar Detonation")));

            return async npc => await ScriptHelpers.InterruptCast(npc, SpellId_SolarWrath);
        }

        [EncounterHandler((int)MobId_SolarFamiliar, "Solar Familiar")]
        public Func<WoWUnit, Task<bool>> SolarFamiliarHandler()
        {
            return async npc => await ScriptHelpers.InterruptCast(npc, SpellId_FlashBang);
        }


        #endregion

        private const int MissileSpellId_PiercingRush = 165732;
        private readonly int[] _missileSpellIds_Windwall = { 153593, 156793 };
        private const int MissileSpellId_FourWinds = 156793;

        private const uint MobId_Ranjit = 75964;
        private const uint AreaTriggerId_FourWinds = 6385;
        private const uint AreaTriggerId_Windwall = 6062;
        private const int AreaTriggerSpellId_WindWall_ClockwiseRotation = 156634;
        private const int AreaTriggerSpellId_WindWall_CounterClockwiseRotation = 156636;

        private readonly Vector3[] _windWallRelativeAvoidPoints =
        {
            new Vector3(-11, 0, 0),
            new Vector3(-9, 0, 0),
            new Vector3(-7, 0, 0),
            new Vector3(-5, 0, 0),
            new Vector3(-3, 0, 0),
            new Vector3(-1, 0, 0),
            new Vector3(1, 0, 0),
            new Vector3(3, 0, 0),
            new Vector3(5, 0, 0),
            new Vector3(7, 0, 0),
            new Vector3(9, 0, 0),
            new Vector3(11, 0, 0),
        };

        private readonly Vector3[] _fourWindsRelativeAvoidPoints =
        {
            new Vector3(5.2072f, 34.84442f, 0),
            new Vector3(6.40078f, 32.64315f, 0),
            new Vector3(7.41073f, 29.98329f, 0),
            new Vector3(7.96161f, 27.32342f, 0),
            new Vector3(8.51249f, 24.11323f, 0),
            new Vector3(8.51249f, 20.71961f, 0),
            new Vector3(8.23705f, 17.60114f, 0),
            new Vector3(7.77798f, 14.75783f, 0),
            new Vector3(7.04348f, 12.37312f, 0),
            new Vector3(6.03353f, 9.4381f, 0),
            new Vector3(5.11539f, 6.96167f, 0),
            new Vector3(3.73819f, 5.219f, 0),
            new Vector3(1.90192f, 3.75148f, 0),
            new Vector3(0.34109f, 2.10053f, 0),
            new Vector3(-0.24478f, -0.87428f, 0),
            new Vector3(2.17459f, -0.43484f, 0),
            new Vector3(4.0441f, -2.4123f, 0),
            new Vector3(6.02358f, -4.38975f, 0),
            new Vector3(8.4394f, -5.81845f, 0),
            new Vector3(11.15196f, -7.07786f, 0),
            new Vector3(13.72155f, -7.79537f, 0),
            new Vector3(16.91072f, -8.56438f, 0),
            new Vector3(20.20985f, -8.56438f, 0),
            new Vector3(22.95913f, -8.45452f, 0),
            new Vector3(26.14829f, -8.12494f, 0),
            new Vector3(29.5574f, -7.24608f, 0),
            new Vector3(32.30667f, -6.36721f, 0),
            new Vector3(34.94598f, -5.15876f, 0),
            new Vector3(-0.24478f, -0.87428f, 0),
            new Vector3(-1.6744f, -2.74187f, 0),
            new Vector3(-3.214f, -4.60947f, 0),
            new Vector3(-4.86357f, -6.36721f, 0),
            new Vector3(-5.96328f, -8.45452f, 0),
            new Vector3(-7.28293f, -10.98127f, 0),
            new Vector3(-8.05273f, -13.94745f, 0),
            new Vector3(-8.71256f, -17.35306f, 0),
            new Vector3(-9.15244f, -20.20939f, 0),
            new Vector3(-8.82253f, -23.06571f, 0),
            new Vector3(-8.27267f, -25.92203f, 0),
            new Vector3(-7.61284f, -28.99807f, 0),
            new Vector3(-6.40316f, -31.85439f, 0),
            new Vector3(-5.19348f, -34.60086f, 0),
            new Vector3(-1.31156f, 0.72474f, 0),
            new Vector3(-3.54391f, 1.98204f, 0),
            new Vector3(-5.41342f, 3.9595f, 0),
            new Vector3(-8.27267f, 5.49752f, 0),
            new Vector3(-11.13192f, 7.1454f, 0),
            new Vector3(-14.32108f, 7.91441f, 0),
            new Vector3(-17.2903f, 8.57356f, 0),
            new Vector3(-20.69941f, 9.01299f, 0),
            new Vector3(-24.21848f, 8.68342f, 0),
            new Vector3(-27.40765f, 8.02427f, 0),
            new Vector3(-29.93698f, 7.36511f, 0),
            new Vector3(-32.35635f, 6.48625f, 0),
            new Vector3(-34.99565f, 5.2778f, 0),
        };

        // Strategy Guide http://www.wowhead.com/guide=2669/skyreach-dungeon-strategy-guide#ranjit
        [EncounterHandler(75964, "Ranjit", Mode = CallBehaviorMode.Proximity)]
        public Func<WoWUnit, Task<bool>> RanjitEncounter()
        {
            var roomCenter = new Vector3(1165.827f, 1727.5f, 189.4511f);
            var rightDoorEdge = new Vector3(1066.295f, 1778.992f, 263.4299f);
            var leftDoorEdge = new Vector3(1082.896f, 1803.643f, 263.1978f);

            var randomPointInsideRoom = WoWMathHelper.GetRandomPointInCircle(new Vector3(1191.229f, 1720.492f, 189.9772f), 2);

            AddAvoidLocation(
                () => true,
                () => roomCenter,
                30f,
                12,
                m => m.ImpactPosition,
                () => WoWMissile.InFlightMissiles.Where(m => _missileSpellIds_Windwall.Contains(m.SpellId)));

            AddAvoidObject(() => true, 12, AreaTriggerId_Windwall);

            AddAvoidLocation(
                () => true,
                () => roomCenter,
                30f,
                4,
                m => m.ImpactPosition,
                () => WoWMissile.InFlightMissiles.Where(m => m.SpellId == MissileSpellId_FourWinds));

            AddAvoidLocation(
                () => true,
                () => roomCenter,
                30f,
                8,
                m => m.ImpactPosition,
                () => WoWMissile.InFlightMissiles.Where(m => m.SpellId == MissileSpellId_PiercingRush));


            // windup attack that causes mob to charge forward, doing damage to anyone in path
            AddAvoidObject(() => true, 4,
                o => o.Entry == MobId_Ranjit && o.ToUnit().HasAura("Piercing Rush"),
                o => Me.Location.GetNearestPointOnSegment(o.Location, o.Location.RayCast(o.Rotation, 25)));

            // Commented out for now.. Causes too much movement and doesn't work its spinning counter clockwise
            //AddAvoidLocation(
            //    ctx => true,
            //    () => roomCenter,
            //    30f,
            //    o => Me.IsMoving ? 8 : 4,
            //    o => (Vector3)o,
            //    GetFourWindsAvoidPoints);

            return async boss =>
            {
                if (await ScriptHelpers.MoveInsideBossRoom(boss, leftDoorEdge, rightDoorEdge, randomPointInsideRoom))
                    return true;

                if (boss.HealthPercent <= 97 && boss.HealthPercent >= 25 && await ScriptHelpers.CastHeroism())
                    return true;

                if (await ScriptHelpers.TankUnitAtLocation(roomCenter, 14))
                    return true;

                return false;
            };
        }

        private IEnumerable<object> GetFourWindsAvoidPoints()
        {
            var fourWinds = ObjectManager.GetObjectsOfType<WoWAreaTrigger>()
                .FirstOrDefault(a => a.Entry == AreaTriggerId_FourWinds);

            if (fourWinds == null)
                yield break;

            var matrix = fourWinds.GetWorldMatrix();
            foreach (var relativePoint in _fourWindsRelativeAvoidPoints)
                yield return (Vector3)Vector3.Transform(relativePoint, matrix);
        }

        #endregion

        #region Araknath

        #region Trash

        private const int SpellId_SolarShower = 160274;
        private const int SpellId_CraftSunTrinket = 153521;
        private const uint MobId_SunTrinket = 76094;
        private const int SpellId_SolarStorm = 159215;

        private const uint MobId_InitiateoftheRisingSun = 79466;
        private const uint MobId_AdeptoftheDawn = 79467;
        private const uint MobId_DrivingGaleCaller = 78932;
        private const uint MobId_AdornedBladetalon = 79303;
        private const uint MobId_SkyreachArcanologist = 76376;

        private const uint AreaTriggerId_Dervish = 6117;
        private const uint AreaTriggerId_SolarStorm = 6697;

        //[LocationHandler(1131.825, 1751.89, 194.271, 20, "Araknath Trash Handler")]
        //public Func<Vector3, Task<bool>> AraknathTrashHandler()
        //{
        //    var packLoc = new Vector3(1115.23, 1781.71, 202.9953);
        //    return async loc =>
        //    {
        //        var trash = ScriptHelpers.GetUnfriendlyNpsAtLocation(packLoc, 14).FirstOrDefault();

        //        if (await ScriptHelpers.PullNpcToLocation(() => trash != null, trash, loc, 5000, 2))
        //            return true;
        //        return false;
        //    };
        //}

        [EncounterHandler((int)MobId_InitiateoftheRisingSun, "Initiate of the Rising Sun")]
        public Func<WoWUnit, Task<bool>> InitiateoftheRisingSunHandler()
        {
            return async npc => await ScriptHelpers.InterruptCast(npc, SpellId_SolarShower, SpellId_SolarHeal, SpellId_FlashHeal);
        }

        [EncounterHandler((int)MobId_AdeptoftheDawn, "Adept of the Dawn")]
        public Func<WoWUnit, Task<bool>> AdeptoftheDawnHandler()
        {
            return async npc => await ScriptHelpers.InterruptCast(npc, SpellId_SolarHeal, SpellId_FlashHeal, SpellId_CraftSunTrinket);
        }


        [EncounterHandler((int)MobId_DrivingGaleCaller, "Driving Gale-Caller")]
        public Func<WoWUnit, Task<bool>> DrivingGaleCallerHandler()
        {
            AddAvoidObject(() => true, 1.2f, AreaTriggerId_Dervish);

            return async npc => false;
        }

        [EncounterHandler((int)MobId_SkyreachArcanologist, "Skyreach Arcanologist")]
        public Func<WoWUnit, Task<bool>> SkyreachArcanologistHandler()
        {
            AddAvoidObject(() => true, 5, AreaTriggerId_SolarStorm);

            return async npc => await ScriptHelpers.InterruptCast(npc, SpellId_SolarStorm);
        }

        #endregion


        private const uint MobId_SkyreachSunConstructPrototype = 76142;
        private const uint MobId_Araknath = 76141;
        private readonly int[] _spellIds_Smash = { 154113, 154110 };

        [EncounterHandler((int)MobId_Araknath, "Araknath", Mode = CallBehaviorMode.Proximity)]
        public Func<WoWUnit, Task<bool>> AraknathEncounter()
        {
            var roomCenter = new Vector3(1042.375f, 1814.569f, 200.1174f);
            const float roomRadius = 32;

            var randomPointsInsideRoom = new[]
            {
                WoWMathHelper.GetRandomPointInCircle(new Vector3(1057.8f, 1790.674f, 199.5619f), 3),
                WoWMathHelper.GetRandomPointInCircle(new Vector3(1070.234f, 1808.342f, 199.5619f), 3),
            };

            AddAvoidObject(
                () => true,
                9f,
                o => o.Entry == MobId_Araknath && _spellIds_Smash.Contains(o.ToUnit().CastingSpellId),
                o => o.Location.RayCast(o.Rotation, 7));

            return async boss =>
            {
                var randomPoint = randomPointsInsideRoom.OrderBy(l => l.DistanceSquared((Vector3)Me.Location)).First();
                if (await ScriptHelpers.GetInsideCircularBossRoom(boss, roomCenter, roomRadius, randomPoint))
                    return true;

                if (!boss.Combat)
                    return false;

                if (boss.HasAura("Energize") && Me.IsTank())
                {
                    var construct =
                        ObjectManager.GetObjectsOfType<WoWUnit>()
                            .FirstOrDefault(u => u.Entry == MobId_SkyreachSunConstructPrototype && u.HasAura("Energize"));

                    if (construct != null)
                    {
                        var beamMoveTo = WoWMathHelper.GetNearestPointOnLineSegment(
                            Me.Location,
                            WoWMathHelper.CalculatePointFrom(construct.Location, boss.Location, 3),
                            construct.Location);

                        return await ScriptHelpers.StayAtLocationWhile(
                            () => ScriptHelpers.IsViable(boss) && boss.HasAura("Energize"),
                            beamMoveTo,
                            null,
                            1);
                    }
                }

                return false;
            };
        }

        #endregion

        #region Rukhran

        #region Trash

        private const uint MobId_SkyreachSunTalon = 79093;

        [LocationHandler(978.3587, 1858.442, 218.511, 30, "Rukhkran Trash Handler")]
        public Func<Vector3, Task<bool>> RukhkranTrashHandler()
        {
            var leftPackLoc = new Vector3(930.3639f, 1873.723f, 213.8664f);
            var rightPackLoc = new Vector3(952.46f, 1896.429f, 213.8671f);
            return async loc =>
            {
                var rightPack = ScriptHelpers.GetUnfriendlyNpsAtLocation(
                    rightPackLoc,
                    12,
                    o => o.Entry == MobId_SkyreachSunTalon && o.IsAlive).FirstOrDefault();

                if (await ScriptHelpers.PullNpcToLocation(() => rightPack != null, rightPack, loc, 5000, 2))
                    return true;

                var leftPack = ScriptHelpers.GetUnfriendlyNpsAtLocation(
                    leftPackLoc,
                    12,
                    o => o.Entry == MobId_SkyreachSunTalon && o.IsAlive).FirstOrDefault();

                if (await ScriptHelpers.PullNpcToLocation(() => leftPack != null, leftPack, loc, 5000, 2))
                    return true;
                return false;
            };
        }

        #endregion

        private const uint MobId_PileofAsh = 79505;
        private const uint MobId_SolarFlare = 79505;
        private const int SpellId_Quills = 159382;
        private const uint GameObjectId_CacheofArakkoanTreasures = 234164;
        private const uint GameObjectId_CacheofArakkoanTreasures_Heroic = 234165;
        private const int MissileSpellId_SummonSolarFlare = 153810;
        private const uint MobId_Rukhran = 76143;

        private readonly Vector3 _rukkranEncounterMoveToLoc = new Vector3(922.9847f, 1897.908f, 213.8669f);
        private readonly Vector3 _rukkranFightLoc = new Vector3(908.1511f, 1908.491f, 215.8947f);

        [EncounterHandler((int)MobId_Rukhran, "Rukhran", Mode = CallBehaviorMode.Proximity)]
        public Func<WoWUnit, Task<bool>> RukhranEncounter()
        {
            WoWUnit rukhran = null;

            AddAvoidLocation(
                () => true,
                5,
                m => ((WoWMissile)m).ImpactPosition,
                () => WoWMissile.InFlightMissiles.Where(m => m.SpellId == MissileSpellId_SummonSolarFlare));

            AddAvoidObject(() => Me.HasAura("Fixate"), o => Me.IsMoving ? 15 : 8, o => o.Entry == MobId_SolarFlare && !o.ToUnit().HasAura("Dormant"));

            var hasSolarDetonation = new PerFrameCachedValue<bool>(() => StyxWoW.Me.HasAura("Solar Detonation"));

            AddAvoidObject(2, o => o is WoWPlayer && !o.IsMe && (o.ToUnit().HasAura("Solar Detonation") || hasSolarDetonation));

            var gabcloserCapabilityHandler = CapabilityManager.Instance.CreateNewHandle();
            var pillarLosLoc = WoWMathHelper.GetRandomPointInCircle(new Vector3(946.8605f, 1881.408f, 213.8669f), 2);
            var castingQuills = new PerFrameCachedValue<bool>(() => ScriptHelpers.IsViable(rukhran) && IsCastingQuills(rukhran));

            return async boss =>
            {
                rukhran = boss;
                CapabilityManager.Instance.Update(
                    gabcloserCapabilityHandler,
                    CapabilityFlags.GapCloser,
                    () => ScriptHelpers.IsViable(boss) && Targeting.Instance.FirstUnit == boss);

                if (castingQuills)
                    return await ScriptHelpers.StayAtLocationWhile(() => castingQuills, pillarLosLoc, "LOS location", 3);
                return false;
            };
        }

        [ObjectHandler((int)GameObjectId_CacheofArakkoanTreasures, "Cache of Arakkoan Treasures")]
        [ObjectHandler((int)GameObjectId_CacheofArakkoanTreasures_Heroic, "Cache of Arakkoan Treasures Heroic ")]
        public async Task<bool> CacheofArakkoanTreasuresHandler(WoWGameObject chest)
        {
            // respect loot settings.
            // We can't loot this chest using normal loot targeting since it's always flagged as 'InUse'
            var lootMode = DungeonBuddySettings.Instance.LootMode;
            if (lootMode == LootMode.Off || lootMode == LootMode.BossesOnly)
                return false;

            if (StyxWoW.Me.Combat || chest.InUse || !chest.CanUse())
                return false;

            if (Blacklist.Contains(chest, BlacklistFlags.Loot))
                return false;

            if (!chest.WithinInteractRange)
                return (await CommonCoroutines.MoveTo(chest.Location, chest.SafeName)).IsSuccessful();

            await ScriptHelpers.StopMovingIfMoving("looting chest");

            for (int attempt = 0; attempt < 4 && !LootFrame.Instance.IsVisible && ScriptHelpers.IsViable(chest); attempt++)
            {
                chest.Interact();
                // some chests trigger a cast bar when opening.. waits a max of 2 seconds if there is no cast bar.
                await Coroutine.Wait(2000, () => StyxWoW.Me.IsCasting);
                await Coroutine.Wait(10000, () => !StyxWoW.Me.IsCasting);
            }
            if (LootFrame.Instance.IsVisible)
                LootFrame.Instance.LootAll();

            Blacklist.Add(chest, BlacklistFlags.Loot, TimeSpan.FromMinutes(3), "Chest looted");
            return true;
        }

        private bool IsCastingQuills(WoWUnit unit)
        {
            return unit.CastingSpellId == SpellId_Quills || unit.HasAura(SpellId_Quills);
        }

        #endregion

        #region High Sage Viryx

        #region Trash

        private const int SpellId_ProtectiveBarrier = 152973;
        private const int SpellId_Empower = 152917;
        private const uint MobId_RadiantSupernova = 79463;
        private const uint MobId_DefenseConstruct = 76087;

        private static readonly Vector3 s_rightHighSageViryxTrashLoc = new Vector3(1025.469f, 1777.403f, 250.2384f);
        private static readonly Vector3 s_leftHighSageViryxTrashLoc = new Vector3(1077.552f, 1849.872f, 250.3618f);

        // We need followers to take the ramp that trash has been cleared if running back from a wipe.
        // ToDO Fix ME: Followers need to go either right or left at ramp to SageViryx depending on which is cleared.

        private readonly TimeCachedValue<bool> _shouldAvoidLeftSide = new TimeCachedValue<bool>(
            TimeSpan.FromSeconds(5),
            () => ScriptHelpers.GetUnfriendlyNpsAtLocation(s_leftHighSageViryxTrashLoc, 20, unit => unit.IsHostile).Any());

        private readonly TimeCachedValue<bool> _shouldAvoidRightSide = new TimeCachedValue<bool>(
            TimeSpan.FromSeconds(5),
            () => ScriptHelpers.GetUnfriendlyNpsAtLocation(s_rightHighSageViryxTrashLoc, 20, unit => unit.IsHostile).Any());

        [EncounterHandler((int)MobId_DefenseConstruct, "Defense Construct")]
        public Func<WoWUnit, Task<bool>> DefenseConstructHandler()
        {
            return async npc => await ScriptHelpers.InterruptCast(npc, SpellId_ProtectiveBarrier);
        }

        [EncounterHandler((int)MobId_RadiantSupernova, "Radiant Supernova")]
        public Func<WoWUnit, Task<bool>> RadiantSupernovaHandler()
        {
            return async npc => await ScriptHelpers.InterruptCast(npc, SpellId_SolarWrath);
        }

        [EncounterHandler((int)MobId_SolarMagnifier, "Solar Magnifier")]
        public Func<WoWUnit, Task<bool>> SolarMagnifierHandler()
        {
            return async npc => false;
        }

        #endregion

        private const int SpellId_SolarBurst = 154396;
        private const int SpellId_Shielding = 158641;
        private const int MissileSpellId_CastDown = 156789;

        private const uint MobId_SolarZealot = 76267;
        private const uint MobId_SkyreachShieldConstruct = 76292;
        private const uint MobId_ArakkoaMagnifyingGlassFocus = 76083;
        private const uint MobId_ArakkoaMagnifyingGlass = 76285;

        private const uint AreaTriggerId_LensFlare = 6127;

        // Strategy Guide http://www.wowhead.com/guide=2669/skyreach-dungeon-strategy-guide#high-sage-viryx
        [EncounterHandler(76266, "High Sage Viryx", Mode = CallBehaviorMode.Proximity)]
        public Func<WoWUnit, Task<bool>> HighSageViryxEncounter()
        {
            var platformCenter = new Vector3(1086.119f, 1783.944f, 262.1719f);
            var rightDoorEdge = new Vector3(1066.295f, 1778.992f, 263.4299f);
            var leftDoorEdge = new Vector3(1082.896f, 1803.643f, 263.1978f);

            var randomPointInsideRoom = WoWMathHelper.GetRandomPointInCircle(platformCenter, 3);

            // increased avoidance on lens flare for tank to ensure boss is not tanked in them.
            AddAvoidObject(() => true, o => !Me.IsMoving ? 6 : 15, AreaTriggerId_LensFlare);
            AddAvoidObject(() => true, 2, MobId_ArakkoaMagnifyingGlassFocus);

            var leftFlareRunToStart = new Vector3(1101.015f, 1819.824f, 262.1719f);
            var leftFlareRunToend = new Vector3(1127.635f, 1807.427f, 262.1719f);
            var rightFlareRunToStart = new Vector3(1063.045f, 1764.506f, 262.1719f);
            var rightFlareRunToend = new Vector3(1088.384f, 1737.376f, 262.1719f);

            return async boss =>
            {
                if (await ScriptHelpers.MoveInsideBossRoom(boss, leftDoorEdge, rightDoorEdge, randomPointInsideRoom, p => p.Z > 230))
                    return true;

                if (!boss.Combat)
                    return false;

                // Move to platform center if targeted by 'CastDown'
                if (WoWMissile.InFlightMissiles.Any(m => m.SpellId == MissileSpellId_CastDown && m.TargetGuid == Me.Guid))
                    return (await CommonCoroutines.MoveTo(platformCenter)).IsSuccessful();

                // kite the flare away from center of platform.
                var magnifyingGlass = ObjectManager.GetObjectsOfType<WoWUnit>()
                    .FirstOrDefault(u => u.Entry == MobId_ArakkoaMagnifyingGlass);

                // Unable to figure out
                if (magnifyingGlass != null && magnifyingGlass.CurrentTargetGuid == Me.Guid)
                {
                    TreeRoot.StatusText = "Running Lens Focus away from group";
                    var nearestLeftPoint = Me.Location.GetNearestPointOnSegment(leftFlareRunToStart, leftFlareRunToend);
                    var nearestRightPoint = Me.Location.GetNearestPointOnSegment(rightFlareRunToStart, rightFlareRunToend);
                    // either go left or right, which ever is closer.
                    var moveTo = Me.Location.DistanceSquared((Vector3)nearestLeftPoint) < Me.Location.DistanceSquared((Vector3)nearestRightPoint)
                        ? nearestLeftPoint
                        : nearestRightPoint;

                    if (!Navigator.AtLocation(moveTo))
                    {
                        return (await CommonCoroutines.MoveTo(moveTo)).IsSuccessful();
                    }
                }

                if (await ScriptHelpers.TankUnitAtLocation(platformCenter, 15))
                    return true;

                if (await ScriptHelpers.InterruptCast(boss, SpellId_SolarBurst))
                    return true;

                return false;
            };
        }

        // Mob that spawns during encounter. Need to interrupt the 'Shielding' spell since it places a 
        // shield on boss that reduces damage by 50%.
        [EncounterHandler((int)MobId_SkyreachShieldConstruct, "Skyreach Shield Construct")]
        public Func<WoWUnit, Task<bool>> SkyreachShieldConstructEncounter()
        {
            return async npc => await ScriptHelpers.InterruptCast(npc, SpellId_Shielding);
        }

        #endregion

    }

    #endregion

    #region Heroic Difficulty

    public class SkyreachHeroic : Skyreach
    {
        #region Overrides of Dungeon

        public override uint DungeonId
        {
            get { return 780; }
        }

        #endregion
    }

    #endregion
}