﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Numerics;
using System.Threading.Tasks;
using CommonBehaviors.Actions;
using Styx;
using Styx.Common.Helpers;
using Styx.CommonBot;
using Styx.Helpers;
using Styx.Pathing;
using Styx.TreeSharp;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using Action = Styx.TreeSharp.Action;
using Bots.DungeonBuddy.Attributes;
using Bots.DungeonBuddy.Helpers;
using Bots.DungeonBuddy.Profiles.Handlers;
using Styx.CommonBot.Routines;

namespace Bots.DungeonBuddy.Dungeon_Scripts.Classic
{
    public class RagefireChasm : Dungeon
    {
        #region Overrides of Dungeon

        public override uint DungeonId => 4;

        public override Vector3 Entrance => new Vector3(1820.646f, -4427.459f, -20.67462f);

        public override Vector3 ExitLocation => new Vector3(2.109175f, -3.876605f, -14.15257f);

        public override void WeighTargetsFilter(List<Targeting.TargetPriority> units)
        {
            foreach (Targeting.TargetPriority t in units)
            {
                WoWObject prioObject = t.Object;
            }
        }

        public override void RemoveTargetsFilter(List<WoWObject> units)
        {
            units.RemoveAll(
                o =>
                {
                    var unit = o as WoWUnit;
                    if (unit != null)
                    {
                        if (unit.Entry == SlagmawId && unit.HasAura("Magnaw Submerge") && !Me.IsHealer)
                            return true;
                    }
                    return false;
                });
        }

        #endregion

        private const uint SlagmawId = 61463;

        private LocalPlayer Me => StyxWoW.Me;

        #region Root

        private const uint LavaId1 = 61560;
        private const uint LavaId2 = 61601;
        private const int NoOrcLeftBehindQuestId = 30984;

        private readonly int[] _blacklistedSpells =
            {
                109132, // monk's roll.
			};

        private readonly Vector3 _lavaLocation1 = new Vector3(-100.9294f, -33.67703f, -29.74805f);
        private readonly Vector3 _lavaLocation2 = new Vector3(-260.9831f, 7.593772f, -49.85098f);

        [EncounterHandler(0)]
        public Composite RootBehavior()
        {
            //AddAvoidObject(() => true, 10, o => o.Entry == LavaId1 && o.Z > -33.6, o => _lavaLocation1);
            // second lava location does so little damage I'm not sure its worth avoiding.
            // AddAvoidObject(() => true, 17, o => o.Entry == LavaId2 && o.Z > -49, o => _lavaLocation2);
            return new PrioritySelector();
        }

        [EncounterHandler(61716, "Invoker Xorenth", Mode = CallBehaviorMode.Proximity, BossRange = 40)]
        [EncounterHandler(61724, "Commander Bagran", Mode = CallBehaviorMode.Proximity, BossRange = 40)]
        [EncounterHandler(61823, "High Sorceress Aryna", Mode = CallBehaviorMode.Proximity, BossRange = 40)]
        [EncounterHandler(61822, "SI:7 Field Commander Dirken", Mode = CallBehaviorMode.Proximity, BossRange = 40)]

        public Composite QuestGiversBehavior()
        {
            WoWUnit unit = null;
            return new PrioritySelector(
                ctx => unit = ctx as WoWUnit,
                new Decorator(ctx => !Me.Combat && unit.QuestGiverStatus == QuestGiverStatus.Available, ScriptHelpers.CreatePickupQuest(ctx => unit)),
                new Decorator(ctx => !Me.Combat && unit.QuestGiverStatus == QuestGiverStatus.TurnIn, ScriptHelpers.CreateTurninQuest(ctx => unit)));
        }

        [EncounterHandler(61780, "Suspicious Rock", Mode = CallBehaviorMode.Proximity, BossRange = 15)]
        public Composite SuspiciousRockEncounter()
        {
            PlayerQuest quest = null;
            WoWUnit rock = null;
            return new PrioritySelector(
                ctx => rock = ctx as WoWUnit,
                new Decorator(
                    ctx => (quest = Me.QuestLog.GetQuestById(NoOrcLeftBehindQuestId)) != null && !quest.IsCompleted && !Me.Combat, ScriptHelpers.CreateTalkToNpc(ctx => rock)));
        }

        /* Navigation issues getting to these. these can be skipped and still be able to complete quest but might take 2 runs. 
		[EncounterHandler(61680, "Kor'kron Scout", Mode = CallBehaviorMode.Proximity, BossRange = 20)]
		public Composite KorkronScoutEncounter()
		{
			PlayerQuest quest = null;
			WoWUnit scout = null;
			var hangingLocs = new[] { new Vector3(-288.154, 137.8819, -25.4445), new Vector3(-173.5599, 6.632007, -30.54592) };

			return new PrioritySelector(
				ctx => scout = ctx as WoWUnit,
				new Decorator(
					ctx =>
					(quest = Me.QuestLog.GetQuestById(NoOrcLeftBehindQuestId)) != null && !quest.IsCompleted && !Me.Combat &&
					hangingLocs.Any(l => scout.Location.Distance(l) < 10),
					new PrioritySelector(
						new Decorator(ctx => scout.WithinInteractRange, new Action(ctx => scout.Interact())),
						new Decorator(
							ctx => !scout.WithinInteractRange,
							new Action(ctx => Navigator.MoveTo(WoWMathHelper.CalculatePointFrom(Me.Location, scout.Location, Navigator.PathPrecision + 2)))))));
		}
		*/
        #endregion


        private const uint MobId_Adarogg = 61408;

        [EncounterHandler(61408, "Adarogg")]
        public Composite AdaroggEncounter()
        {
            const uint demonicLeapId = 61409;
            AddAvoidObject(() => true, 6, u => u.Entry == demonicLeapId && u.ToUnit().HasAura("Inferno Charge"));
            // avoid the flame breath
            AddAvoidUnitCone(0, 10, 90, u => u.Entry == MobId_Adarogg && u.Combat && u.CurrentTarget != Me);

            WoWUnit boss = null;
            return new PrioritySelector();
        }

        [EncounterHandler(61412, "Dark Shaman Koranthal")]
        public Composite KoranthalEncounter()
        {
            WoWUnit boss = null;
            const int twistedElementsId = 119300;
            var shadowStormMissileIds = new[] { 119965, 119984 };
            // avoid the shadow storm
            AddAvoidLocation(() => true, 2, o => ((WoWMissile)o).ImpactPosition, () => WoWMissile.InFlightMissiles.Where(m => shadowStormMissileIds.Contains(m.SpellId)));

            return new PrioritySelector(ctx => boss = ctx as WoWUnit, ScriptHelpers.CreateInterruptCast(ctx => boss, twistedElementsId));
        }


        [EncounterHandler(61463, "Slagmaw", Mode = CallBehaviorMode.Proximity)]
        public Func<WoWUnit, Task<bool>> SlagmawEncounter()
        {
            //var spitTimer = new WaitTimer(TimeSpan.FromSeconds(4));
            //const int lavaSpitId = 119434;
            var roomCenterLoc = new Vector3(-244.7897f, 155.2252f, -18.72345f);
            //WoWUnit boss = null;
            var capabilityHandle = CapabilityManager.Instance.CreateNewHandle();

            return async boss =>
            {
                CapabilityManager.Instance.Update(capabilityHandle, CapabilityFlags.GapCloser, 
                    () => boss != null && boss.IsValid && (boss.Combat || Me.GotTarget || Me.CurrentTarget == boss));

                if (!boss.Combat)
                    return false;

                if (boss.WithinInteractRange && Me.IsMeleeDps && Me.CurrentTargetGuid == boss.Guid && ScriptHelpers.MovementEnabled)
                    ScriptHelpers.DisableMovement(() => boss != null && boss.IsValid && boss.Combat && boss.IsWithinMeleeRange && Me.CurrentTargetGuid == boss.Guid);

                if (await ScriptHelpers.SpreadOut(roomCenterLoc, 3, 15))
                    return true;

                if (Targeting.Instance.IsEmpty() && Me.IsTank())
                    return true;

                return false;
            };

        }

        [EncounterHandler(61528, "Lava Guard Gordoth")]
        public Composite GordothEncounter()
        {
            return new PrioritySelector();
        }

    }
}