﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Threading.Tasks;
using Styx;
using Styx.CommonBot;
using Styx.CommonBot.POI;
using Styx.Pathing;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using Styx.TreeSharp;
using Bots.DungeonBuddy.Profiles;
using Bots.DungeonBuddy.Attributes;
using Bots.DungeonBuddy.Helpers;
using Buddy.Coroutines;
using Styx.Common;
using Action = Styx.TreeSharp.Action;

namespace Bots.DungeonBuddy.Dungeon_Scripts.Classic
{
    public class SunkenTemple : Dungeon
    {
        #region Overrides of Dungeon

        public override uint DungeonId
        {
            get { return 28; }
        }

        public override Vector3 Entrance
        {
            get { return new Vector3(-10292.47f, -3990.68f, -70.85f); }
        }

        public override Vector3 ExitLocation
        {
            get { return new Vector3(-318.16f, 94.90f, -91.31f); }
        }

        public override void RemoveTargetsFilter(List<WoWObject> units)
        {
            // don't kill MCed party members.
            units.RemoveAll(
                o =>
                {
                    if (o is WoWPlayer)
                        return true;

                    if (o.Entry == AtalaiDeathwalkersSpiritId)
                        return true;

                    return false;
                });
        }

        public override void IncludeTargetsFilter(List<WoWObject> incomingunits, HashSet<WoWObject> outgoingunits)
        {
            foreach (var unit in incomingunits.Select(obj => obj.ToUnit()))
            {
                switch (unit.Entry)
                {
                    case 6066: // Earthgrab Totem
                        outgoingunits.Add(unit);
                        break;
                }
            }
        }

        public override void WeighTargetsFilter(List<Targeting.TargetPriority> units)
        {
            var isDps = Me.IsDps;
            foreach (var p in units)
            {
                WoWUnit unit = p.Object.ToUnit();
                if (unit != null)
                {
                    if (unit.Entry == EarthgrabTotemId)
                        p.Score += 5000;
                    if (unit.Entry == JammalanTheProphetid && isDps)
                        p.Score += 4000;
                }
            }
        }

        #endregion

        #region Root

        private const uint EarthgrabTotemId = 6066;
        private const uint AtalaiDeathwalkersSpiritId = 8317;

        private LocalPlayer Me => StyxWoW.Me;

        [EncounterHandler(0, "Root")]
        public Func<WoWUnit,Task<bool>> RootBehavior()
        {
            AddAvoidObject(() => !Me.IsCasting, obj => Me.IsRange() && Me.IsMoving ? 8 : 5f, AtalaiDeathwalkersSpiritId);

            var roomsWithLedges = new[]
            {
                // covers the room that Morphaz flies around in
                new WallLedgeRoomInfo("Morphaz's Room", new BoundingBox3(new Vector3(-688f, 17.55229f, -88f), new Vector3(-630.5f, 152.2532f, -80f)),
                    new Vector3(-664.7697f, 145.7598f, -90.82809f), new Vector3(-660.5892f, 15.91421f, -90.83525f)),

                // covers the two rooms between Morphaz's room and the main center area
                new WallLedgeRoomInfo("Room between Morphaz and main center area", new BoundingBox3(new Vector3(-630.5898f, 75.20183f, -88.5f), new Vector3(-539.777f, 115.3643f, -80f)),
                    new Vector3(-630.9948f, 95.02701f, -90.85859f), new Vector3(-540.9977f, 97.39682f, -90.86944f)),

                // Room beside Morphaz's room
                new WallLedgeRoomInfo("Room beside Morphaz's room", new BoundingBox3(new Vector3(-703.5f, -63f, -88.5f), new Vector3(-617f, 18f, -80f)),
                    new Vector3(-664.0042f, -50.62711f, -90.83517f), new Vector3(-662.4044f, 11.91034f, -90.83513f)),
            };

            return async boss =>
            {
                var stuckOnLedgeRoom = roomsWithLedges.FirstOrDefault(r => r.StuckBounds.Contains(Me.Location));
                if (stuckOnLedgeRoom != null)
                {
                    Logger.WriteDebug($"Stuck on ledge at {stuckOnLedgeRoom.Name}. Freeing");
                    var moveTo = Me.Location.GetNearestPointOnSegment(stuckOnLedgeRoom.UnstuckMoveLineStart, stuckOnLedgeRoom.UnstuckMoveLineEnd);
                    Navigator.PlayerMover.MoveTowards(moveTo);
                    await Coroutine.Wait(3000, () => !stuckOnLedgeRoom.StuckBounds.Contains(Me.Location));
                    return true;
                }

                return false;
            };
        }


        [EncounterHandler(46077, "Lord Itharius", Mode = CallBehaviorMode.Proximity, BossRange = 30)]
        public Composite QuestPickupHandler()
        {
            WoWUnit unit = null;
            return new PrioritySelector(
                ctx => unit = ctx as WoWUnit,
                new Decorator(
                    ctx => !Me.Combat && !ScriptHelpers.WillPullAggroAtLocation(unit.Location) && unit.QuestGiverStatus == QuestGiverStatus.Available,
                    ScriptHelpers.CreatePickupQuest(ctx => unit)),
                new Decorator(
                    ctx => !Me.Combat && !ScriptHelpers.WillPullAggroAtLocation(unit.Location) && unit.QuestGiverStatus == QuestGiverStatus.TurnIn,
                    ScriptHelpers.CreateTurninQuest(ctx => unit)));
        }

        private class WallLedgeRoomInfo
        {
            public WallLedgeRoomInfo(string name, BoundingBox3 stuckBounds, Vector3 unstuckMoveLineStart, Vector3 unstuckMoveLineEnd)
            {
                Name = name;
                StuckBounds = stuckBounds;
                UnstuckMoveLineStart = unstuckMoveLineStart;
                UnstuckMoveLineEnd = unstuckMoveLineEnd;
            }

            public string Name { get; }

            public BoundingBox3 StuckBounds { get; }
            public Vector3 UnstuckMoveLineStart { get; }
            public Vector3 UnstuckMoveLineEnd { get; }

        }

        #endregion

        private const uint JammalanTheProphetid = 5710;

        [EncounterHandler(5710, "Jammal'an the Prophet", BossRange = 100, Mode = CallBehaviorMode.Proximity)]
        public Composite OgomTheWretchedEncounter()
        {
            const uint flamestrikeId = 12468;
            AddAvoidObject(() => !Me.IsCasting, 5, flamestrikeId);
            AddAvoidObject(() => !Me.IsTank(), obj => Me.IsRange() && Me.IsMoving ? 10 : 6, o => o is WoWPlayer && o.ToPlayer().HasAura("Hex of Jammal'an") && !o.IsMe);

            // clear room of argo.
            List<WoWUnit> targets = null;
            return
                new PrioritySelector(
                    ctx => targets = ObjectManager.GetObjectsOfType<WoWUnit>().Where(u => u.IsValid && u.IsAlive && u.Entry == 5271).OrderBy(u => u.DistanceSqr).ToList(),
                    new Decorator(
                        ctx =>
                        targets != null && targets.Count > 0 && Targeting.Instance.FirstUnit == null && Navigator.LookupPathInfo(targets[0]).Navigability == PathNavigability.Navigable &&
                        BotPoi.Current.Type == PoiType.None,
                        new Action(ctx => ScriptHelpers.SetLeaderMoveToPoiPS(targets[0].Location))));
        }

        private const uint AvatarOfHakkarId = 8443;

        [ObjectHandler(208321, "Shrine of the Soulflayer")]
        public async Task<bool> ShrineoftheSoulflayerHandler(WoWGameObject shrine)
        {
            if (!Me.IsTank() || !Targeting.Instance.IsEmpty() || !ScriptHelpers.IsBossAlive("Avatar of Hakkar"))
                return false;
            // sometimes this shrine does not despawn after boss is summoned so we need to ignore it if this happens.
            var hakker = ObjectManager.GetObjectsOfType<WoWUnit>().FirstOrDefault(u => u.Entry == AvatarOfHakkarId);
            if (hakker != null && hakker.IsDead)
                return false;
            return await ScriptHelpers.InteractWithObject(shrine);
        }
        public Composite CreateBehavior_ShrineoftheSoulflayer()
        {
            return new PrioritySelector(
                new Decorator<WoWGameObject>(obj => Me.IsTank() && Targeting.Instance.IsEmpty(),
                    ScriptHelpers.CreateInteractWithObject(ctx => (WoWGameObject)ctx))
                );
        }

        private readonly HashSet<uint> MobIds_Dragons = new HashSet<uint> { 5722 , 5721, 5720, 5719, 5709};

        [EncounterHandler(5722, "Hazzas")]                                              
        [EncounterHandler(5721, "Dreamscythe")]                                         
        [EncounterHandler(5720, "Weaver")]
        [EncounterHandler(5719, "Morphaz")]
        [EncounterHandler(5709, "Shade of Eranikus")]
        public Composite HazzasEncounter()
        {
            WoWUnit boss = null;

            AddAvoidUnitCone(() => !Me.IsTank(), 0, 15, 180, u => MobIds_Dragons.Contains(u.Entry) && !u.IsMoving && u.Combat);

            return new PrioritySelector(ctx => boss = ctx as WoWUnit,
                ScriptHelpers.CreateDispelEnemy("Deep Slumber", ScriptHelpers.EnemyDispelType.Magic, ctx => boss),
                ScriptHelpers.CreateTankFaceAwayGroupUnit(ctx => boss, 10));
        }
    }
}