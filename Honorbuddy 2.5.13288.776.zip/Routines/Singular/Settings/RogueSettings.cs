﻿
using System.ComponentModel;
using System.IO;
using Singular.ClassSpecific.Rogue;
using Styx.Helpers;

using DefaultValue = Styx.Helpers.DefaultValueAttribute;

namespace Singular.Settings
{
    public enum StealthMode
    {
        Never   = 0,
        Auto    = 1,
        PVP     = 2,
        Always  = 4
    }

    internal class RogueSettings : Styx.Helpers.Settings
    {
        public RogueSettings()
            : base(Path.Combine(SingularSettings.SingularSettingsPath, "Rogue.xml"))
        {
        }

        [Setting]
        [DefaultValue(false)]
        [Category("常规")]
        [DisplayName("使用疾跑")]
        [Description("拉怪或者战斗时使用疾跑接近目标")]
        public bool UseSprint { get; set; }

        [Setting]
        [DefaultValue(70)]
        [Category("常规")]
        [DisplayName("恢复血量百分比")]
        [Description("血量低于该百分比时使用恢复,设置为 0 则不使用该技能")]
        public int RecuperateHealth { get; set; }

        [Setting]
        [DefaultValue(LethalPoisonType.Auto)]
        [Category("常规")]
        [DisplayName("致命药膏")]
        [Description("致命药膏")]
        public LethalPoisonType LethalPoison { get; set; }

        [Setting]
        [DefaultValue(NonLethalPoisonType.Auto)]
        [Category("常规")]
        [DisplayName("非致命药膏")]
        [Description("非致命药膏")]
        public NonLethalPoisonType NonLethalPoison { get; set; }

        [Setting]
        [DefaultValue(StealthMode.Auto)]
        [Category("常规")]
        [DisplayName("总是潜行")]
        [Description("脱离战斗后总是潜行.不要禁用坐骑.(如果需要你可以在HB的设置里进行设置)")]
        public StealthMode Stealth { get; set; }

        [Setting]
        [DefaultValue(true)]
        [Category("常规")]
        [DisplayName("吃喝时潜行")]
        [Description("吃喝时潜行")]
        public bool StealthIfEating { get; set; }

        [Setting]
        [DefaultValue(4)]
        [Category("常规")]
        [DisplayName("刀扇敌人数量")]
        [Description("当敌人数量超过该值时,使用刀扇来积累连击点数")]
        public int FanOfKnivesCount { get; set; }

        [Setting]
        [DefaultValue(4)]
        [Category("常规")]
        [DisplayName("AOE技能优先敌人数量")]
        [Description("当敌人数量超过该数值时优先使用AOE技能")]
        public int AoeSpellPriorityCount { get; set; }

        [Setting]
        [DefaultValue(true)]
        [Category("常规")]
        [DisplayName("打断施法")]
        [Description("打断施法")]
        public bool InterruptSpells { get; set; }

        [Setting]
        [DefaultValue(true)]
        [Category("常规")]
        [DisplayName("使用嫁祸诀窍")]
        [Description("使用嫁祸诀窍")]
        public bool UseTricksOfTheTrade { get; set; }

        [Setting]
        [DefaultValue(true)]
        [Category("常规")]
        [DisplayName("使用开锁")]
        [Description("需要开启游戏内自动拾取功能; 休息时自动开启上锁的箱子")]
        public bool UsePickLock { get; set; }

        [Setting]
        [DefaultValue(25)]
        [Category("常规")]
        [DisplayName("闷棍可能ADD怪的距离")]
        [Description("对在该范围内可能引致ADD的怪物使用闷棍;设置为0禁用")]
        public int SapAddDistance { get; set; }

        [Setting]
        [DefaultValue(true)]
        [Category("常规")]
        [DisplayName("闷棍移动的目标")]
        [Description("潜行时对目标使用闷棍来避免跟随移动的目标移动")]
        public bool SapMovingTargetsOnPull { get; set; }


        [Setting]
        [DefaultValue(true)]
        [Category("战斗专精")]
        [DisplayName("使用割裂作为终结技")]
        [Description("使用割裂作为终结技")]
        public bool CombatUseRuptureFinisher { get; set; }

        [Setting]
        [DefaultValue(false)]
        [Category("常规")]
        [DisplayName("移动到目标背后")]
        [Description("开怪或者目标被晕眩或者目标的目标不是你时移动到目标背后")]
        public bool MoveBehindTargets { get; set; }

        [Setting]
        [DefaultValue(true)]
        [Category("战斗专精")]
        [DisplayName("使用破甲")]
        [Description("使用破甲")]
        public bool UseExposeArmor { get; set; }

        [Setting]
        [DefaultValue(true)]
        [Category("常规")]
        [DisplayName("使用加速技能")]
        [Description("当脱离战斗过程中使用速度爆发")]
        public bool UseSpeedBuff { get; set; }

        [Setting]
        [DefaultValue(false)]
        [Category("偷窃")]
        [DisplayName("仅限偷窃禁用拉怪")]
        [Description("尝试在偷窃，但不进入战斗")]
        public bool PickPocketOnlyPull { get; set; }

        [Setting]
        [DefaultValue(true)]
        [Category("搜索")]
        [DisplayName("使用搜索")]
        [Description("需要开启游戏内自动拾取功能; 开怪先使用搜索偷取怪物身上物品")]
        public bool UsePickPocket { get; set; }

        [Setting]
        [DefaultValue(3)]
        [Category("偷窃")]
        [DisplayName("偷窃当前目标间隔分钟")]
        [Description("搜索成功多少分钟后，把目标啦到偷窃黑名单。并不妨碍战斗与目标")]
        public int SuccessfulPostPickPocketBlacklistMinutes { get; set; }

        [Setting]
        [DefaultValue(200)]
        [Category("搜索")]
        [DisplayName("搜索之后暂停时间")]
        [Description("使用搜索技能之后暂停的毫秒数(由于搜索无公共冷却,导致系统自动拾取反应缓慢)")]
        public int PostPickPocketPause { get; set; }

        [Setting]
        [DefaultValue(100)]
        [Category("搜索")]
        [DisplayName("搜索之前暂停时间")]
        [Description("使用搜索技能之前暂停的毫秒数(因为系统有延迟)")]
        public int PrePickPocketPause { get; set; }

        [Setting]
        [DefaultValue(false)]
        [Category("搜索")]
        [DisplayName("允许战斗中使用搜索")]
        [Description("当技能可用且目标可偷时允许战斗中使用搜索")]
        public bool AllowPickPocketInCombat { get; set; }

        [Setting]
        [DefaultValue(false)]
        [Category("常规")]
        [DisplayName("使用拆卸")]
        [Description("True:冷却结束马上使用拆卸; False:不使用该技能")]
        public bool UseDimantle { get; set; }
    }
}
