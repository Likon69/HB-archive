﻿
using System.ComponentModel;
using System.IO;
using Styx.Helpers;
using Styx.WoWInternals.WoWObjects;

using DefaultValue = Styx.Helpers.DefaultValueAttribute;
using System.Windows.Forms;

namespace Singular.Settings
{
    internal class HotkeySettings : Styx.Helpers.Settings
    {
        public HotkeySettings()
            : base(Path.Combine(SingularSettings.CharacterSettingsPath, "SingularSettings.Hotkeys.xml"))
        { 
            // bit of a hack -- SavedToFile setting tracks if we have ever saved
            // .. these settings.  this is needed because we can't use the DefaultValue
            // .. attribute for a multi values setting
            if (!SavedToFile)
            {
                // force to true so when loaded next time we skip the following
                SavedToFile = true;

                // set default values for array
                SuspendMovementKeys = new Keys[] 
                {
                    // default WOW bindings for movement keys
                    Keys.MButton,
                    Keys.RButton,
                    Keys.W,
                    Keys.S,
                    Keys.A,
                    Keys.D,
                    Keys.Q,
                    Keys.E,
                    Keys.Up,
                    Keys.Down,
                    Keys.Left,
                    Keys.Right
                };
            }
        }


        // hidden setting to track if we have ever saved this settings file before
        [Setting]
        [Browsable(false)]
        [DefaultValue(false)]
        public bool SavedToFile { get; set; }

        [Setting]
        [DefaultValue(true)]
        [Category("控制")]
        [DisplayName("聊天框信息")]
        [Description("按下快捷键按下时在聊天框输出信息")]
        public bool ChatFrameMessage { get; set; }

        [Setting]
        [DefaultValue(true)]
        [Category("控制")]
        [DisplayName("快捷键开关行为")]
        [Description("True: 按下禁用，再按启用; False:按住禁用，松开启用")]
        public bool KeysToggleBehavior { get; set; }

        [Setting]
        [DefaultValue(Keys.None)]
        [Category("快捷键")]
        [DisplayName("AOE技能快捷键")]
        [Description("启用/禁用AOE战斗技能")]
        public Keys AoeToggle { get; set; }

        [Setting]
        [DefaultValue(Keys.None)]
        [Category("快捷键")]
        [DisplayName("战斗快捷键")]
        [Description("启用/禁用所有战斗技能")]
        public Keys CombatToggle { get; set; }

        [Setting]
        [DefaultValue(Keys.None)]
        [Category("快捷键")]
        [DisplayName("移动快捷键")]
        [Description("启用/禁用Singular战斗模块控制移动")]
        public Keys MovementToggle { get; set; }

        [Setting]
        [DefaultValue(Keys.None)]
        [Category("Hotkeys")]
        [DisplayName("Key - Pull More")]
        [Description("Enables/Disables Pull More Ability")]
        public Keys PullMoreToggle { get; set; }

        [Setting]
        [DefaultValue(false)]
        [Category("辅助始终过程中允许手动移动")]
        [DisplayName("允许用户移动")]
        [Description("True: 快捷键按下后暂停辅助控制角色移动 # 秒")]
        public bool SuspendMovement { get; set; }

        [Setting]
        [DefaultValue(3)]
        [Category("辅助始终过程中允许手动移动")]
        [DisplayName("暂停时间")]
        [Description("按下暂停快捷键后开始计算的暂停移动控制的秒数")]
        public int SuspendDuration { get; set; }

        [Setting]
        [Category("辅助始终过程中允许手动移动")]
        [DisplayName("暂停快捷键")]
        [Description("快捷键按下后暂停所有移动控制 # 秒")]
        public Keys[] SuspendMovementKeys { get; set; }

    }
}
