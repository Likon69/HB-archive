﻿
using System;
using System.ComponentModel;
using System.IO;
using Styx.Helpers;
using Styx.WoWInternals.WoWObjects;

using DefaultValue = Styx.Helpers.DefaultValueAttribute;

namespace Singular.Settings
{
    public enum DeathKnightPresence
    {
        None = 0,
        Auto,
        Blood,
        Frost,
        Unholy
    }

    public enum DarkSimulacrumTarget
    {
        None = 0,
        All,
        HealersOnly
    }

    internal class DeathKnightSettings : Styx.Helpers.Settings
    {
        public DeathKnightSettings()
            : base(Path.Combine(SingularSettings.SingularSettingsPath, "DeathKnight.xml"))
        {
        }

        #region Common

        [Setting]
        [DefaultValue(DeathKnightPresence.Auto)]
        [Category("常规")]
        [DisplayName("灵气")]
        [Description("Auto: 自动根据专精/角色/环境选择最适用的灵气, None: 玩家控制")]
        public DeathKnightPresence Presence { get; set; }

        [Setting]
        [DefaultValue(false)]
        [Category("常规")]
        [DisplayName("亡者大军")]
        public bool UseArmyOfTheDead { get; set; }

        [Setting]
        [DefaultValue(false)]
        [Category("常规")]
        [DisplayName("冰霜之路")]
        public bool UsePathOfFrost { get; set; }

        [Setting]
        [DefaultValue(60)]
        [Category("常规")]
        [DisplayName("符能转换血量百分比")]
        [Description("当血量低于该百分比时使用符能转换进行治疗.")]
        public int ConversionPercent { get; set; }

        [Setting]
        [DefaultValue(80)]
        [Category("常规")]
        [DisplayName("符能转换符文能量百分比")]
        [Description("当符文能量等于或者高于该百分比时才使用符文转换.")]
        public int MinimumConversionRunicPowerPrecent { get; set; }

        [Setting]
        [DefaultValue(2)]
        [Category("常规")]
        [DisplayName("枯萎凋零怪物数量")]
        [Description("当怪物数量等于或大于该值时使用枯萎凋零. 该设置决定AOE循环")]
        public int DeathAndDecayCount { get; set; }

        [Setting]
        [DefaultValue(60)]
        [Category("常规")]
        [DisplayName("天灾契约血量百分比")]
        [Description("当血量低于该百分比时使用天灾契约进行治疗.")]
        public int DeathPactPercent { get; set; }

        [Setting]
        [DefaultValue(85)]
        [Category("常规")]
        [DisplayName("死亡虹吸血量百分比")]
        [Description("当血量低于该百分比时使用死亡虹吸进行治疗.")]
        public int DeathSiphonPercent { get; set; }

        [Setting]
        [DefaultValue(30)]
        [Category("常规")]
        [DisplayName("灵界打击血量百分比 [DPS天赋]")]
        public int DeathStrikeEmergencyPercent { get; set; }

        [Setting]
        [DefaultValue(DarkSimulacrumTarget.All)]
        [Category("常规")]
        [DisplayName("黑暗拟像目标")]
        [Description("None: 关闭, All: 所有的目标, HealersOnly: 目标只有在PVP/一切都在PVE治疗师")]
        public DarkSimulacrumTarget TargetWithDarkSimulacrum { get; set; }

        [Setting]
        [DefaultValue(false)]
        [Category("常规")]
        [DisplayName("黑暗拟像自动清除灵气")]
        [Description("True: 保护，寒冰屏障等清晰手后即可使用（用于快速清洗）; False:不使用r")]
        public bool AutoClearAuraWithDarkSimulacrum { get; set; }

        [Setting]
        [DefaultValue(30)]
        [Category("常规")]
        [DisplayName("冰封之韧血量百分比")]
        public int IceboundFortitudePercent { get; set; }

        [Setting]
        [DefaultValue(60)]
        [Category("常规")]
        [DisplayName("巫妖之躯血量百分比")]
        [Description("当血量低于该百分比时使用巫妖之躯+调零缠绕进行治疗.")]
        public int LichbornePercent { get; set; }

        [Setting]
        [DefaultValue(60)]
        [Category("鲜血")]
        [DisplayName("符文武器增效血量百分比")]
        [Description("当血量低于该百分比时使用符文武器增效")]
        public int EmpowerRuneWeaponPercent { get; set; }

        #endregion

        #region Category: Blood

        [Setting]
        [DefaultValue(60)]
        [Category("鲜血")]
        [DisplayName("亡者大军血量百分比")]
        [Description("当血量低于该百分比时使用亡者大军")]
        public int ArmyOfTheDeadPercent { get; set; }

        [Setting]
        [DefaultValue(4)]
        [Category("鲜血")]
        [DisplayName("血液沸腾怪物数量")]
        [Description("当附近敌人的数量大于等于该数值时使用血液沸腾.")]
        public int BloodBoilCount { get; set; }

        [Setting]
        [DefaultValue(false)]
        [Category("鲜血")]
        [DisplayName("优先使用白骨之盾")]
        [Description("False: 一冷却就用, True: 仅在身上无白骨之盾,吸血鬼之血,符文刃舞,巫妖之躯,冰封之韧等Buff时使用")]
        public bool BoneShieldExclusive { get; set; }

        [Setting]
        [DefaultValue(false)]
        [Category("鲜血")]
        [DisplayName("优先使用天灾契约")]
        [Description("False: 需要时施放召唤食尸鬼来使用天灾契约, True: 只在身上无白骨之盾,吸血鬼之血,符文刃舞,巫妖之躯,冰封之韧等Buff时施放召唤食尸鬼来使用天灾契约")]
        public bool DeathPactExclusive { get; set; }

        [Setting]
        [DefaultValue(false)]
        [Category("鲜血")]
        [DisplayName("优先使用冰封之韧")]
        [Description("False:需要时使用, True:需要时且身上无白骨之盾,吸血鬼之血,符文刃舞,巫妖之躯,冰封之韧等Buff时使用")]
        public bool IceboundFortitudeExclusive { get; set; }

        [Setting]
        [DefaultValue(false)]
        [Category("鲜血")]
        [DisplayName("优先使用巫妖之躯")]
        [Description("False:需要时使用, True:需要时且身上无白骨之盾,吸血鬼之血,符文刃舞,巫妖之躯,冰封之韧等Buff时使用")]
        public bool LichborneExclusive { get; set; }

        [Setting]
        [DefaultValue(60)]
        [Category("鲜血")]
        [DisplayName("符文分流血量百分比")]
        [Description("当血量低于该百分比时使用符文分流")]
        public int RuneTapPercent { get; set; }

        [Setting]
        [DefaultValue(false)]
        [Category("鲜血")]
        [DisplayName("召唤食尸鬼作为输出技能冷却即用")]
        [Description("鲜血专精:召唤食尸鬼作为输出技能而不保留到天灾契约时使用")]
        public bool UseGhoulAsDpsCdBlood { get; set; }

        [Setting]
        [DefaultValue(60)]
        [Category("鲜血")]
        [DisplayName("吸血鬼之血血量百分比")]
        [Description("当血量低于该百分比时使用吸血鬼之血")]
        public int VampiricBloodPercent { get; set; }

        [Setting]
        [DefaultValue(false)]
        [Category("鲜血")]
        [DisplayName("优先使用吸血鬼之血")]
        [Description("False: 在需要时使用, True: 需要时且身上无白骨之盾,吸血鬼之血,符文刃舞,巫妖之躯,冰封之韧等Buff时使用")]
        public bool VampiricBloodExclusive { get; set; } 
        #endregion

        #region Category: Frost
        [Setting]
        [DefaultValue(false)]
        [Category("冰霜")]
        [DisplayName("召唤食尸鬼作为输出技能冷却即用")]
        [Description("冰霜专精:召唤食尸鬼作为输出技能而不保留到天灾契约时使用")]
        public bool UseGhoulAsDpsCdFrost { get; set; }

        #endregion

        #region Category: Unholy

        [Setting]
        [DefaultValue(true)]
        [Category("邪恶")]
        [DisplayName("召唤石像鬼")]
        [Description("False: 不使用该技能, True: 当需要长时间战斗时使用 (Boss, PVP, 有压力的单人战斗)")]
        public bool UseSummonGargoyle { get; set; }

        #endregion

    }
}
