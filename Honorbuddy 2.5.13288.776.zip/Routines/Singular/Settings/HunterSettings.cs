﻿
using System;
using System.ComponentModel;
using System.IO;
using Styx.Helpers;
using Styx.WoWInternals.WoWObjects;

using DefaultValue = Styx.Helpers.DefaultValueAttribute;

namespace Singular.Settings
{
    internal class HunterSettings : Styx.Helpers.Settings
    {
        public HunterSettings()
            : base(Path.Combine(SingularSettings.SingularSettingsPath, "Hunter.xml"))
        {
        }

        #region Category: Pet

        [Setting]
        [DefaultValue(1)]
        [Category("宠物")]
        [DisplayName("(单人战斗) 召唤宠物序号(1到5)")]
        public int PetNumberSolo { get; set; }

        [Setting]
        [DefaultValue(1)]
        [Category("宠物")]
        [DisplayName("(PvP) 召唤宠物序号(1到5)")]
        public int PetNumberPvp { get; set; }

        [Setting]
        [DefaultValue(1)]
        [Category("宠物")]
        [DisplayName("(副本) 召唤宠物序号(1到5)")]
        public int PetNumberInstance { get; set; }

        [Setting]
        [DefaultValue(70)]
        [Category("宠物")]
        [DisplayName("治疗宠物血量百分比")]
        public int MendPetPct { get; set; }

        [Setting]
        [DefaultValue(false)]
        [Category("Pet")]
        [DisplayName("Use Pet Buffs")]
        public bool PetBuffs { get; set; }

        #endregion

        #region Category: Common

        [Setting]
        [DefaultValue(true)]
        [Category("常规")]
        [DisplayName("使用逃脱")]
        [Description("无论这里怎么设置,战场中始终使用逃脱.")]
        public bool UseDisengage { get; set; }

        [Setting]
        [DefaultValue(true)]
        [Category("常规")]
        [DisplayName("使用拾回")]
        [Description("使用拾回来捡取离你10码以外的物品")]
        public bool UseFetch { get; set; }

        [Setting]
        [DefaultValue(true)]
        [Category("常规")]
        [DisplayName("副本中使用误导")]
        [Description("在副本中开怪后对MT使用误导, 当所有MT阵亡且猎人获得当前仇恨时对宠物使用误导")]
        public bool UseMisdirectionInInstances { get; set; }

        [Setting]
        [DefaultValue(false)]
        [Category("常规")]
        [DisplayName("蜘蛛毒刺")]
        [Description("True: 在敌对玩家身上保持此减益效果; False: 不使用该技能.")]
        public bool UseWidowVenom { get; set; }

        [Setting]
        [DefaultValue(false)]
        [Category("控制技能")]
        [DisplayName("对焦点目标使用控制技能")]
        [Description("True: 仅对焦点目标使用控制技能; False: 在ADD时使用.")]
        public bool CrowdControlFocus { get; set; }

        [Setting]
        [DefaultValue(50)]
        [Category("常规")]
        [DisplayName("威慑血量百分比")]
        [Description("战斗中血量低于该百分比时使用威慑")]
        public int DeterrenceHealth { get; set; }

        [Setting]
        [DefaultValue(3)]
        [Category("常规")]
        [DisplayName("威慑敌人数量")]
        [Description("正在攻击猎人的敌人数量(宠物不计算在内)")]
        public int DeterrenceCount { get; set; }

        [Setting]
        [DefaultValue(10)]
        [Category("常规")]
        [DisplayName("假死血量百分比")]
        [Description("血量低于该百分比时使用假死")]
        public int FeignDeathHealth { get; set; }

        [Setting]
        [DefaultValue(true)]
        [Category("常规")]
        [DisplayName("受到敌对玩家宠物攻击时假死")]
        [Description("受到敌对玩家宠物攻击时假死一冷却就用")]
        public bool FeignDeathPvpEnemyPets { get; set; }

        [Setting]
        [DefaultValue(true)]
        [Category("常规")]
        [DisplayName("在副本中使用假死")]
        [Description("战斗中OT时使用假死; 不尝试其他方法保命")]
        public bool FeignDeathInInstances { get; set; }

        [Setting]
        [DefaultValue(5)]
        [Category("Common")]
        [DisplayName("Camouflage: Health %")]
        [Description("Cast if health below this % and have Enhanced Camouflage (Level 92+); 0: disable")]
        public int ImprovedCamouflageHealth { get; set; }

       
        #endregion
    }
}
