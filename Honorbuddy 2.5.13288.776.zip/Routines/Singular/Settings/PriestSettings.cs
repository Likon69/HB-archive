﻿
using System;
using System.ComponentModel;
using System.IO;
using Styx.Helpers;

using DefaultValue = Styx.Helpers.DefaultValueAttribute;
using Styx;
using System.Drawing;

namespace Singular.Settings
{
    internal class PriestSettings : Styx.Helpers.Settings
    {
        public PriestSettings()
            : base(Path.Combine(SingularSettings.SingularSettingsPath, "Priest.xml"))
        {
        }

        #region Holy Healing Context Late Loading Wrappers

        private HolyPriestHealSettings _holybattleground;
        private HolyPriestHealSettings _holyinstance;
        private HolyPriestHealSettings _holyraid;

        [Browsable(false)]
        public HolyPriestHealSettings HolyBattleground { get { return _holybattleground ?? (_holybattleground = new HolyPriestHealSettings(HealingContext.Battlegrounds)); } }

        [Browsable(false)]
        public HolyPriestHealSettings HolyInstance { get { return _holyinstance ?? (_holyinstance = new HolyPriestHealSettings(HealingContext.Instances)); } }

        [Browsable(false)]
        public HolyPriestHealSettings HolyRaid { get { return _holyraid ?? (_holyraid = new HolyPriestHealSettings(HealingContext.Raids)); } }

        [Browsable(false)]
        public HolyPriestHealSettings HolyHeal { get { return HolyHealLookup(Singular.SingularRoutine.CurrentWoWContext); } }

        public HolyPriestHealSettings HolyHealLookup(WoWContext ctx)
        {
            if (ctx == WoWContext.Instances)
                return StyxWoW.Me.CurrentMap.IsRaid ? HolyRaid : HolyInstance;
            return HolyBattleground;
        }

        #endregion


        #region Disc Healing Context Late Loading Wrappers

        private DiscPriestHealSettings _discbattleground;
        private DiscPriestHealSettings _discinstance;
        private DiscPriestHealSettings _discraid;

        [Browsable(false)]
        public DiscPriestHealSettings DiscBattleground { get { return _discbattleground ?? (_discbattleground = new DiscPriestHealSettings(HealingContext.Battlegrounds)); } }

        [Browsable(false)]
        public DiscPriestHealSettings DiscInstance { get { return _discinstance ?? (_discinstance = new DiscPriestHealSettings(HealingContext.Instances)); } }

        [Browsable(false)]
        public DiscPriestHealSettings DiscRaid { get { return _discraid ?? (_discraid = new DiscPriestHealSettings(HealingContext.Raids)); } }

        [Browsable(false)]
        public DiscPriestHealSettings DiscHeal { get { return DiscHealLookup(Singular.SingularRoutine.CurrentWoWContext); } }

        public DiscPriestHealSettings DiscHealLookup(WoWContext ctx)
        {
            if (ctx == WoWContext.Instances)
                return StyxWoW.Me.CurrentMap.IsRaid ? DiscRaid : DiscInstance;
            return DiscBattleground;
        }

        #endregion

        #region Shadow

        [Setting]
        [DefaultValue(30)]
        [Category("暗影")]
        [DisplayName("快速治疗血量百分比")]
        [Description("血量低于该百分比时使用快速治疗（暗影天赋）")]
        public int ShadowFlashHeal { get; set; }

        [Setting]
        [DefaultValue(0)]
        [Category("治疗")]
        [DisplayName("% 愈合祷言")]
        [Description("血量百分比低于该数值时使用该技能.设置为0禁用.")]
        public int PrayerOfMending { get; set; }

        [Setting]
        [DefaultValue(25)]
        [Category("Shadow")]
        [DisplayName("Mind Flay Mana")]
        [Description("Will only use Mind Flay while manapercent is above this value")]
        public int MindFlayManaPct { get; set; }

        [Setting]
        [DefaultValue(60)]
        [Category("Shadow")]
        [DisplayName("Vampiric Embrace Health")]
        [Description("Health % for Vampiric Embrace")]
        public int VampiricEmbracePct { get; set; }

        [Setting]
        [DefaultValue(3)]
        [Category("Shadow")]
        [DisplayName("Vampiric Embrace Mob Count")]
        [Description("Count of players for Vampiric Embrace in Instances (Solo and Dungeon checks only characters health")]
        public int VampiricEmbraceCount { get; set; }


/*
        [Setting]
        [DefaultValue(15)]
        [Category("Shadow")]
        [DisplayName("Mind Blast Timer")]
        [Description("Casts mind blast anyway after this many seconds if we haven"t got 3 shadow orbs")]
        public int MindBlastTimer { get; set; }
*/
/*
        [Setting]
        [DefaultValue(false)]
        [Category("Shadow")]
        [DisplayName("Devouring Plague First")]
        [Description("Casts devouring plague before anything else, useful for farming low hp mobs")]
        public bool DevouringPlagueFirst { get; set; }
/*
        [Setting]
        [DefaultValue(false)]
        [Category("Shadow")]
        [DisplayName("Archangel on 5")]
        [Description("Always archangel on 5 dark evangelism, ignoring mana %")]
        public bool AlwaysArchangel5 { get; set; }
*/

        [Setting]
        [DefaultValue(20)]
        [Category("暗影")]
        [DisplayName("消散法力百分比")]
        [Description("法力百分比低于该百分比时使用消散")]
        public int DispersionMana { get; set; }

        [Setting]
        [DefaultValue(40)]
        [Category("暗影")]
        [DisplayName("治疗法术血量百分比")]
        [Description("血量低于该百分比时使用治疗法术治疗")]
        public int DontHealPercent { get; set; }

        [Setting]
        [DefaultValue(3)]
        [Category("Shadow")]
        [DisplayName("Talent T6: Mob Count")]
        [Description("0 = disable, 1 = on cooldown, otherwise minimum number of mobs to hit.  Will not cast if it will break CC or aggro non-trivial mobs not in combat")]
        public int TalentTier6Count { get; set; }

        #endregion

        #region Common

        [Setting]
        [DefaultValue(true)]
        [Category("常规")]
        [DisplayName("开怪前上盾")]
        [Description("开怪前使用真言术：盾.在心灵尖刺的循环中不使用该设置")]
        public bool UseShieldPrePull { get; set; }

        [Setting]
        [DefaultValue(60)]
        [Category("治疗")]
        [DisplayName("% 真言术：盾")]
        [Description("血量百分比低于该数值时使用该技能.设置为0禁用.")]
        public int PowerWordShield { get; set; }

        [Setting]
        [DefaultValue(00)]
        [Category("治疗")]
        [DisplayName("群体驱散玩家")]
        [Description("使用群体驱散的最少玩家数量 (0: 禁用群体驱散)")]
        public int CountMassDispel { get; set; }

        [Setting]
        [DefaultValue(true)]
        [Category("常规")]
        [DisplayName("使用渐隐术")]
        [Description("True: 获得仇恨时使用渐隐术,或者点了幻隐天赋时用来解除移动限制效果")]
        public bool UseFade { get; set; }

        /*
                        [Setting]
                        [DefaultValue(true)]
                        [Category("常规")]
                        [DisplayName("Use Shadow Protection")]
                        [Description("Use Shadow Protection buff")]
                        public bool UseShadowProtection { get; set; }
                */
        [Setting]
        [DefaultValue(50)]
        [Category("Common")]
        [DisplayName("Crowd Control: Health %")]
        [Description("If health falls below this, use Shackle Undead / Psychic Horror")]
        public int CrowdControlHealth { get; set; }

        [Setting]
        [DefaultValue(true)]
        [Category("常规")]
        [DisplayName("使用心灵尖啸")]
        [Description("使用心灵尖啸")]
        public bool PsychicScreamAllow { get; set; }

        [Setting]
        [DefaultValue(4)]
        [Category("常规")]
        [DisplayName("使用心灵尖啸的敌人数量")]
        [Description("当ADD的敌人数量大于等于该数值时使用心灵尖啸(不包含当前目标)")]
        public int PsychicScreamAddCount { get; set; }

        [Setting]
        [DefaultValue(25)]
        [Category("Common")]
        [DisplayName("Psychic Scream: Health %")]
        [Description("Use Psychic Scream as a hail mary to get some heals if health falls below")]
        public int PsychicScreamHealth { get; set; }

        [Setting]
        [DefaultValue(true)]
        [Category("常规")]
        [DisplayName("使用防护恐惧结界")]
        [Description("使用防护恐惧结界")]
        public bool UseFearWard { get; set; }

        [Setting]
        [DefaultValue(true)]
        [Category("常规")]
        [DisplayName("允许风筝怪物")]
        [Description("允许风筝怪物来减少受到的伤害")]
        public bool AllowKiting { get; set; }

/*
                [Setting]
                [DefaultValue(75)]
                [Category("常规")]
                [DisplayName("Archangel Mana")]
                [Description("Archangel will be used at this value")]
                public int ArchangelMana { get; set; }
        */

        [Setting]
        [DefaultValue(75)]
        [Category("常规")]
        [DisplayName("暗影魔/摧心魔法力百分比")]
        [Description("法力低于该百分比时使用暗影魔或者摧心魔")]
        public int ShadowfiendMana { get; set; }
/*
        [Setting]
        [DefaultValue(50)]
        [Category("常规")]
        [DisplayName("Mindbender Mana")]
        [Description("Mindbender will be used at this value")] 
        public int MindbenderMana { get; set; }
*/
        [Setting]
        [DefaultValue(30)]
        [Category("常规")]
        [DisplayName("绝望祷言血量百分比")]
        [Description("血量低于该百分比时使用绝望祷言")]
        public int DesperatePrayerHealth { get; set; }
                       

        //[Setting]
        //[DefaultValue(false)]
        //[Category("Common")]
        //[DisplayName("Use Wand")]
        //[Description("Uses wand if we're oom")]
        //public bool UseWand { get; set; }

        [Setting]
        [DefaultValue(true)]
        [Category("常规")]
        [DisplayName("使用移动加速技能")]
        [Description("跑步或者非战斗时使用第二层天赋的技能加速移动")]
        public bool UseSpeedBuff { get; set; }

        [Setting]
        [DefaultValue(true)]
        [Category("常规")]
        [DisplayName("对坦克使用移动加速技能")]
        [Description("非战斗中的移动状态下对坦克使用第二层天赋的技能加速移动")]
        public bool UseSpeedBuffOnTank { get; set; }

        [Setting]
        [DefaultValue(true)]
        [Category("常规")]
        [DisplayName("使用信仰飞跃")]
        [Description("当队友快被不良环境伤害或者近战敌人杀死时对其使用信仰飞跃")]
        public bool UseLeapOfFaith { get; set; }

        #endregion

        #region Discipline
/*
        [Setting]
        [DefaultValue(80)]
        [Category("血量百分比")]
        [DisplayName("% 灵魂护壳")]
        [Description("血量百分比低于该数值时使用该技能.设置为0禁用.")]
        public int SpiritShell { get; set; }

        [Setting]
        [DefaultValue(30)]
        [Category("治疗")]
        [DisplayName("% 苦修")]
        [Description("血量百分比低于该数值时使用该技能.设置为0禁用.")]
        public int Penance { get; set; }

        [Setting]
        [DefaultValue(40)]
        [Category("治疗")]
        [DisplayName("% 快速治疗")]
        [Description("血量百分比低于该数值时使用该技能.设置为0禁用.")]
        public int FlashHeal { get; set; }

        [Setting]
        [DefaultValue(50)]
        [Category("治疗")]
        [DisplayName("% 治疗术")]
        [Description("血量百分比低于该数值时使用该技能.设置为0禁用.")]
        public int Heal { get; set; }

        [Setting]
        [DefaultValue(30)]
        [Category("治疗")]
        [DisplayName("% 痛苦压制")]
        [Description("血量百分比低于该数值时使用该技能.设置为0禁用.")]
        public int PainSuppression { get; set; }

        [Setting]
        [DefaultValue(50)]
        [Category("治疗")]
        [DisplayName("% 治疗祷言")]
        [Description("血量百分比低于该数值时使用该技能.设置为0禁用.")]
        public int PrayerOfHealing { get; set; }

        [Setting]
        [DefaultValue(40)]
        [Category("治疗")]
        [DisplayName("% 真言术：盾")]
        [Description("血量百分比低于该数值时使用该技能.设置为0禁用.")]
        public int PowerWordShield { get; set; }

        [Setting]
        [DefaultValue(3)]
        [Category("戒律")]
        [DisplayName("治疗祷言队友数量")]
        [Description("超过设置数量的队友血量低于治疗祷言血量百分比时使用治疗祷言")]
        public int PrayerOfHealingCount { get; set; }

        [Setting]
        [DefaultValue(70)]
        [Category("戒律")]
        [DisplayName("输出法力百分比")]
        [Description("法力高于该百分比时进行多输出(在小队中使用)")]
        public int DpsMana { get; set; }
*/
        #endregion

        #region Holy
/*
        [Setting]
        [DefaultValue(95)]
        [Category("神圣")]
        [DisplayName("治疗术血量百分比")]
        [Description("血量低于该百分比时使用治疗术")]
        public int HolyHealPercent { get; set; }

        [Setting]
        [DefaultValue(50)]
        [Category("神圣")]
        [DisplayName("强效治疗术血量百分比")]
        [Description("血量低于该百分比时使用强效治疗术")]
        public int HolyHeal { get; set; }

        [Setting]
        [DefaultValue(25)]
        [Category("神圣")]
        [DisplayName("快速治疗血量百分比")]
        [Description("血量低于该百分比时使用快速治疗")]
        public int HolyFlashHeal { get; set; }

        [Setting]
        [DefaultValue(40)]
        [Category("神圣")]
        [DisplayName("神圣赞美诗血量百分比")]
        [Description("血量低于该百分比时使用神圣赞美诗")]
        public int DivineHymnHealth { get; set; }

        [Setting]
        [DefaultValue(6)]
        [Category("神圣")]
        [DisplayName("神圣赞美诗队友数量")]
        [Description("超过设置数量的队友血量低于神圣赞美诗血量百分比时使用神圣赞美诗")]
        public int DivineHymnCount { get; set; }

        [Setting]
        [DefaultValue(80)]
        [Category("神圣")]
        [DisplayName("治疗祷言(带妙手回春效果)血量百分比")]
        [Description("血量低于该百分比时使用治疗祷言(带妙手回春效果)")]
        public int PrayerOfHealingSerendipityHealth { get; set; }

        [Setting]
        [DefaultValue(4)]
        [Category("神圣")]
        [DisplayName("治疗祷言(带妙手回春效果)队友数量")]
        [Description("超过设置数量的队友血量低于治疗祷言(带妙手回春效果)血量百分比时使用治疗祷言(带妙手回春效果)")]
        public int PrayerOfHealingSerendipityCount { get; set; }

        [Setting]
        [DefaultValue(95)]
        [Category("神圣")]
        [DisplayName("治疗之环血量百分比")]
        [Description("血量低于该百分比时使用治疗之环")]
        public int CircleOfHealingHealth { get; set; }

        [Setting]
        [DefaultValue(5)]
        [Category("神圣")]
        [DisplayName("治疗之环队友数量")]
        [Description("超过设置数量的队友血量低于治疗之环血量百分比时使用治疗之环")]
        public int CircleOfHealingCount { get; set; }

*/


        #endregion
    }

    internal class HolyPriestHealSettings : Singular.Settings.HealerSettings
    {
        private HolyPriestHealSettings()
            : base("", HealingContext.None)
        {
        }

        public HolyPriestHealSettings(HealingContext ctx)
            : base("Priest-Holy", ctx)
        {

            // we haven't created a settings file yet,
            //  ..  so initialize values for various heal contexts

            if (!SavedToFile)
            {
                if (ctx == Singular.HealingContext.Battlegrounds)
                {
                    Renew = 95;
                    PrayerOfMending = 94;
                    Heal = 0;
                    FlashHeal = 80;
                    BindingHeal = 55;
                    HolyLevel90Talent = 85;
                    HolyWordSanctuary = 95;
                    HolyWordSerenity = 85;
                    CircleOfHealing = 90;
                    PrayerOfHealing = 85;
                    DivineHymn = 75;
                    GuardianSpirit = 35;
                    CountHolyWordSanctuary = 3;
                    CountLevel90Talent = 3;
                    CountCircleOfHealing = 3;
                    CountPrayerOfHealing = 3;
                    CountDivineHymn = 4;
                }
                else if (ctx == Singular.HealingContext.Instances)
                {
                    Renew = 95;
                    PrayerOfMending = 85;
                    Heal = 65;
                    FlashHeal = 65;
                    BindingHeal = 35;
                    HolyLevel90Talent = 80;
                    HolyWordSanctuary = 0;
                    HolyWordSerenity = 85;
                    CircleOfHealing = 93;
                    PrayerOfHealing = 85;
                    DivineHymn = 75;
                    GuardianSpirit = 20;
                    CountHolyWordSanctuary = 3;
                    CountLevel90Talent = 3;
                    CountCircleOfHealing = 3;
                    CountPrayerOfHealing = 3;
                    CountDivineHymn = 4;
                }
                else if (ctx == Singular.HealingContext.Raids)
                {
                    PowerWordShield = 100;
                    Renew = 95;
                    PrayerOfMending = 94;
                    Heal = 40;
                    FlashHeal = 20;
                    BindingHeal = 30;
                    HolyLevel90Talent = 80;
                    HolyWordSanctuary = 92;
                    HolyWordSerenity = 0;
                    CircleOfHealing = 93;
                    PrayerOfHealing = 85;
                    DivineHymn = 75;
                    GuardianSpirit = 20;
                    CountHolyWordSanctuary = 3;
                    CountLevel90Talent = 4;
                    CountCircleOfHealing = 4;
                    CountPrayerOfHealing = 3;
                    CountDivineHymn = 5;
                }
                // omit case for WoWContext.Normal and let it use DefaultValue() values
            }

            // adjust Flash Heal if we have not previously 
            if (!FlashHealAdjusted && StyxWoW.Me.Level >= 34 && (ctx == HealingContext.Instances || ctx == HealingContext.Raids))
            {
                if (SavedToFile)
                    Logger.Write( LogColor.Hilite, "Flash Heal % changed from {0} to {1} for {2}.  Visit Class Config and Save to make permanent.", FlashHeal, GuardianSpirit + 1, ctx.ToString());

                FlashHeal = GuardianSpirit + 1;
                FlashHealAdjusted = true;
            }

            SavedToFile = true;
        }

        #region Saved Conversion State

        [Setting]
        [Browsable(false)]
        [DefaultValue(false)]
        public bool SavedToFile { get; set; }

        [Setting]
        [Browsable(false)]
        [DefaultValue(false)]
        public bool FlashHealAdjusted { get; set; }

        #endregion

        [Setting]
        [DefaultValue(100)]
        [Category("治疗")]
        [DisplayName("% 真言术：盾")]
        [Description("血量百分比低于该数值时使用该技能.设置为0禁用.")]
        public int PowerWordShield { get; set; }

        [Setting]
        [DefaultValue(95)]
        [Category("治疗")]
        [DisplayName("% 恢复")]
        [Description("血量百分比低于该数值时使用该技能.设置为0禁用.")]
        public int Renew { get; set; }

        [Setting]
        [DefaultValue(94)]
        [Category("治疗")]
        [DisplayName("% 愈合祷言")]
        [Description("血量百分比低于该数值时使用该技能.设置为0禁用.")]
        public int PrayerOfMending { get; set; }

        [Setting]
        [DefaultValue(40)]
        [Category("治疗")]
        [DisplayName("% 治疗术")]
        [Description("血量百分比低于该数值时使用该技能.设置为0禁用.")]
        public int Heal { get; set; }

        [Setting]
        [DefaultValue(20)]
        [Category("治疗")]
        [DisplayName("% 快速治疗")]
        [Description("血量百分比低于该数值时使用该技能.设置为0禁用.")]
        public int FlashHeal { get; set; }

        [Setting]
        [DefaultValue(80)]
        [Category("治疗")]
        [DisplayName("% 联结治疗")]
        [Description("血量百分比低于该数值时使用该技能.设置为0禁用.")]
        public int BindingHeal { get; set; }

        [Setting]
        [DefaultValue(75)]
        [Category("血量百分比")]
        [DisplayName("% 90级天赋")]
        [Description("血量百分比低于该数值时使用该技能.设置为0禁用.")]
        public int HolyLevel90Talent { get; set; }

        [Setting]
        [DefaultValue(92)]
        [Category("血量百分比")]
        [DisplayName("% 圣言术：佑")]
        [Description("血量百分比低于该数值时使用该技能.设置为0禁用.")]
        public int HolyWordSanctuary { get; set; }

        [Setting]
        [DefaultValue(00)]
        [Category("血量百分比")]
        [DisplayName("% 圣言术：静")]
        [Description("血量百分比低于该数值时使用该技能.设置为0禁用.")]
        public int HolyWordSerenity { get; set; }

        [Setting]
        [DefaultValue(93)]
        [Category("血量百分比")]
        [DisplayName("% 治疗之环")]
        [Description("血量百分比低于该数值时使用该技能.设置为0禁用.")]
        public int CircleOfHealing { get; set; }

        [Setting]
        [DefaultValue(80)]
        [Category("治疗")]
        [DisplayName("% 治疗祷言")]
        [Description("血量百分比低于该数值时使用该技能.设置为0禁用.")]
        public int PrayerOfHealing { get; set; }

        [Setting]
        [DefaultValue(70)]
        [Category("血量百分比")]
        [DisplayName("% 神圣赞美诗")]
        [Description("血量百分比低于该数值时使用该技能.设置为0禁用.")]
        public int DivineHymn { get; set; }

        [Setting]
        [DefaultValue(50)]
        [Category("血量百分比")]
        [DisplayName("% 守护之魂")]
        [Description("血量百分比低于该数值时使用该技能.设置为0禁用.")]
        public int GuardianSpirit { get; set; }

        #region Counts

        [Setting]
        [DefaultValue(3)]
        [Category("最少目标数量")]
        [DisplayName("圣言术：佑数量")]
        [Description("设置区域内需要使用圣言术：佑的最少目标数量")]
        public int CountHolyWordSanctuary { get; set; }

        [Setting]
        [DefaultValue(3)]
        [Category("最少目标数量")]
        [DisplayName("90级天数量")]
        [Description("需要治疗的最少目标数量")]
        public int CountLevel90Talent { get; set; }

        [Setting]
        [DefaultValue(3)]
        [Category("最少目标数量")]
        [DisplayName("治疗之环数量")]
        [Description("需要治疗的最少目标数量")]
        public int CountCircleOfHealing { get; set; }

        [Setting]
        [DefaultValue(3)]
        [Category("最少目标数量")]
        [DisplayName("治疗祷言数量")]
        [Description("需要治疗的最少目标数量")]
        public int CountPrayerOfHealing { get; set; }

        [Setting]
        [DefaultValue(4)]
        [Category("最少目标数量")]
        [DisplayName("神圣赞美诗数量")]
        [Description("需要治疗的最少目标数量")]
        public int CountDivineHymn { get; set; }

        [Setting]
        [DefaultValue(3)]
        [Category("最少目标数量")]
        [DisplayName("愈合祷言数量")]
        [Description("需要治疗的最少目标数量")]
        public int CountPrayerOfMending { get; set; }

        #endregion
    }

    internal class DiscPriestHealSettings : Singular.Settings.HealerSettings
    {
        private DiscPriestHealSettings()
            : base("", HealingContext.None)
        {
        }

        public DiscPriestHealSettings(HealingContext ctx)
            : base("Priest-Discipline", ctx)
        {

            // we haven't created a settings file yet,
            //  ..  so initialize values for various heal contexts

            if (!SavedToFile)
            {
                if (ctx == Singular.HealingContext.Battlegrounds)
                {
                    Penance = 80;
                    PrayerOfMending = 80;
                    Heal = 0;
                    FlashHeal = 80;
                    PrayerOfHealing = 90;
                    PainSuppression = 0;
                    DiscLevel90Talent = 85;
                    PowerWordBarrier = 40;
                    CountLevel90Talent = 3;
                    CountPrayerOfHealing = 3;
                    CountPrayerOfMending = 3;
                    CountPowerWordBarrier = 3;
                    AtonementAbovePercent = 90;
                    AtonementAboveCount = 1;
                    AtonementWhenIdle = true;
                }
                else if (ctx == Singular.HealingContext.Instances)
                {
                    Penance = 80;
                    PrayerOfMending = 80;
                    Heal = 60;
                    FlashHeal = 30;
                    PrayerOfHealing = 90;
                    PainSuppression = 0;
                    DiscLevel90Talent = 85;
                    PowerWordBarrier = 0;
                    CountLevel90Talent = 3;
                    CountPrayerOfHealing = 3;
                    CountPrayerOfMending = 3;
                    CountPowerWordBarrier = 3;
                    AtonementAbovePercent = 90;
                    AtonementAboveCount = 1;
                    AtonementWhenIdle = true;
                }
                else if (ctx == Singular.HealingContext.Raids)
                {
                    Penance = 80;
                    PrayerOfMending = 90;
                    Heal = 50;
                    FlashHeal = 30;
                    PrayerOfHealing = 89;
                    PainSuppression = 49;
                    DiscLevel90Talent = 89;
                    PowerWordBarrier = 80;
                    CountLevel90Talent = 3;
                    CountPrayerOfHealing = 3;
                    CountPrayerOfMending = 3;
                    CountPowerWordBarrier = 3;
                    AtonementAbovePercent = 90;
                    AtonementAboveCount = 1;
                    AtonementWhenIdle = true;
                }
                // omit case for WoWContext.Normal and let it use DefaultValue() values
            }

            SavedToFile = true;
        }

        [Setting]
        [Browsable(false)]
        [DefaultValue(false)]
        public bool SavedToFile { get; set; }

        [Setting]
        [DefaultValue(100)]
        [Category("治疗")]
        [DisplayName("% 真言术：盾")]
        [Description("血量百分比低于该数值时使用该技能.设置为0禁用.")]
        public int PowerWordShield { get; set; }

        [Setting]
        [DefaultValue(0)]
        [Category("治疗")]
        [DisplayName("% 苦修")]
        [Description("血量百分比低于该数值时使用该技能.设置为0禁用.")]
        public int Penance { get; set; }

        [Setting]
        [DefaultValue(90)]
        [Category("治疗")]
        [DisplayName("% 愈合祷言")]
        [Description("血量百分比低于该数值时使用该技能.设置为0禁用.")]
        public int PrayerOfMending { get; set; }

        [Setting]
        [DefaultValue(60)]
        [Category("治疗")]
        [DisplayName("% 治疗术")]
        [Description("血量百分比低于该数值时使用该技能.设置为0禁用.")]
        public int Heal { get; set; }

        [Setting]
        [DefaultValue(30)]
        [Category("治疗")]
        [DisplayName("% 快速治疗")]
        [Description("血量百分比低于该数值时使用该技能.设置为0禁用.")]
        public int FlashHeal { get; set; }

        [Setting]
        [DefaultValue(89)]
        [Category("治疗")]
        [DisplayName("% 治疗祷言")]
        [Description("血量百分比低于该数值时使用该技能.设置为0禁用.")]
        public int PrayerOfHealing { get; set; }

        [Setting]
        [DefaultValue(0)]
        [Category("治疗")]
        [DisplayName("% 痛苦压制")]
        [Description("血量百分比低于该数值时使用该技能.设置为0禁用.")]
        public int PainSuppression { get; set; }

        [Setting]
        [DefaultValue(89)]
        [Category("血量百分比")]
        [DisplayName("% 90级天赋")]
        [Description("血量百分比低于该数值时使用该技能.设置为0禁用.")]
        public int DiscLevel90Talent { get; set; }

        [Setting]
        [DefaultValue(80)]
        [Category("血量百分比")]
        [DisplayName("% 真言术：障")]
        [Description("血量百分比低于该数值时使用该技能.设置为0禁用.")]
        public int PowerWordBarrier { get; set; }

        [Setting]
        [DefaultValue(75)]
        [Category("血量百分比")]
        [DisplayName("% 灵魂护壳")]
        [Description("血量百分比低于该数值时使用该技能.设置为0禁用.")]
        public int SpiritShell { get; set; }

        [Setting]
        [DefaultValue(3)]
        [Category("最少目标数量")]
        [DisplayName("90级天数量")]
        [Description("需要治疗的最少目标数量")]
        public int CountLevel90Talent { get; set; }

        [Setting]
        [DefaultValue(3)]
        [Category("最少目标数量")]
        [DisplayName("治疗祷言数量")]
        [Description("需要治疗的最少目标数量")]
        public int CountPrayerOfHealing { get; set; }

        [Setting]
        [DefaultValue(3)]
        [Category("最少目标数量")]
        [DisplayName("愈合祷言数量")]
        [Description("需要治疗的最少目标数量")]
        public int CountPrayerOfMending { get; set; }

        [Setting]
        [DefaultValue(3)]
        [Category("最少目标数量")]
        [DisplayName("真言术：障数量")]
        [Description("需要治疗的最少目标数量")]
        public int CountPowerWordBarrier { get; set; }

        [Setting]
        [DefaultValue(3)]
        [Category("最少目标数量")]
        [DisplayName("灵魂护壳数量")]
        [Description("血量百分比低于该数值的最少目标数量")]
        public int CountSpiritShell { get; set; }

        [Setting]
        [DefaultValue(90)]
        [Category("戒律")]
        [DisplayName("使用救赎仅在血量百分比高于")]
        [Description("仅在血量百分比高于该数值时使用救赎")]
        public int AtonementAbovePercent { get; set; }

        [Setting]
        [DefaultValue(1)]
        [Category("治疗")]
        [DisplayName("使用救赎仅在数量少于")]
        [Description("需要治疗目标数低于该数值且使用救赎仅在血量百分比高于设置值的时候使用救赎,否则使用其他治疗技能")]
        public int AtonementAboveCount { get; set; }

        [Setting]
        [DefaultValue(true)]
        [Category("治疗")]
        [DisplayName("闲时使用救赎")]
        [Description("True: 没有治疗需求时使用救赎进行输出")]
        public bool AtonementWhenIdle { get; set; }


    }
}
