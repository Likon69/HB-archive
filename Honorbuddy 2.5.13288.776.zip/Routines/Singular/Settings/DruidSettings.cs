﻿
using System;
using System.ComponentModel;
using System.IO;
using Styx.Helpers;

using DefaultValue = Styx.Helpers.DefaultValueAttribute;
using System.Drawing;

namespace Singular.Settings
{
    public enum FeralForm
    {
        None,
        Bear,
        Cat
    }

    internal class DruidSettings : Styx.Helpers.Settings
    {
        public DruidSettings()
            : base(Path.Combine(SingularSettings.SingularSettingsPath, "Druid.xml"))
        {
        }

        #region Context Late Loading Wrappers

        private DruidHealSettings _battleground;
        private DruidHealSettings _instance;
        private DruidHealSettings _raid;
        private DruidHealSettings _normal;

        [Browsable(false)]
        public DruidHealSettings Battleground { get { return _battleground ?? (_battleground = new DruidHealSettings(HealingContext.Battlegrounds)); } }

        [Browsable(false)]
        public DruidHealSettings Instance { get { return _instance ?? (_instance = new DruidHealSettings(HealingContext.Instances)); } }

        [Browsable(false)]
        public DruidHealSettings Raid { get { return _raid ?? (_raid = new DruidHealSettings(HealingContext.Raids)); } }

        [Browsable(false)]
        public DruidHealSettings Normal { get { return _normal ?? (_normal = new DruidHealSettings(HealingContext.Normal)); } }

        [Browsable(false)]
        public DruidHealSettings Heal { get { return HealLookup(Singular.SingularRoutine.CurrentWoWContext); } }

        public DruidHealSettings HealLookup(WoWContext ctx)
        {
            if (ctx == WoWContext.Battlegrounds)
                return Battleground;
            if (ctx == WoWContext.Instances)
                return Styx.StyxWoW.Me.CurrentMap.IsRaid ? Raid : Instance;
            return Normal;
        }

        #endregion


        #region pvp
        /*
        [Setting]
        [DefaultValue(3)]
        [Category("野性 PVP")]
        [DisplayName("PvP Add Switch")]
        [Description("Switch to bear when the amount of attackers is equal or greater than this value")]
        public int PvPAddSwitch { get; set; }

        [Setting]
        [DefaultValue(40)]
        [Category("野性 PVP")]
        [DisplayName("PvP Health Switch")]
        [Description("Switch to bear when health drops below this value")]
        public int PvPHealthSwitch { get; set; }

        [Setting]
        [DefaultValue(false)]
        [Category("野性 PVP")]
        [DisplayName("Berserk Save")]
        [Description("Only use Berserk when there are 2 or more attackers")]
        public bool PvPBerserksafe { get; set; }

        [Setting]
        [DefaultValue(false)]
        [Category("野性 PVP")]
        [DisplayName("Shift out of snares")]
        [Description("Cancels Catform to remove snares")]
        public bool PvPSnared { get; set; }

        [Setting]
        [DefaultValue(true)]
        [Category("野性 PVP")]
        [DisplayName("Remove root")]
        [Description("Uses Dash/Stampeding Roar to remove root")]
        public bool PvPRooted { get; set; }

        [Setting]
        [DefaultValue(false)]
        [Category("野性 PVP")]
        [DisplayName("Cyclone adds")]
        [Description("Use Cyclone on adds")]
        public bool PvPccAdd { get; set; }

        [Setting]
        [DefaultValue(40)]
        [Category("野性 PVP")]
        [DisplayName("Rejuv Health")]
        [Description("Rejuv will be used when your health drops below this value")]
        public int PvPReju { get; set; }

        [Setting]
        [DefaultValue(20)]
        [Category("野性 PVP")]
        [DisplayName("HealingTouch Health")]
        [Description("Healing Touch will be used when your health drops below this value")]
        public int PvPHealingTouch { get; set; }

        [Setting]
        [DefaultValue(60)]
        [Category("野性 PVP")]
        [DisplayName("Predator"s Swiftness heal")]
        [Description("Predator"s Swiftness will be used when your health drops below this value")]
        public int PvPProcc { get; set; }

        [Setting]
        [DefaultValue(false)]
        [Category("野性 PVP")]
        [DisplayName("In combat healing")]
        public bool PvPpHealBool { get; set; }

        [Setting]
        [DefaultValue(false)]
        [Category("野性 PVP")]
        [DisplayName("Use Nature"s Grasp")]
        [Description("Use Nature"s Grasp when there are 2+ attackers")]
        public bool PvPGrasp { get; set; }

        [Setting]
        [DefaultValue(false)]
        [Category("野性 PVP")]
        [DisplayName("Use CC on fleeing target")]
        public bool PvPRoot { get; set; }
        */

        /* Logic for this needs work
        [Setting]
        [DefaultValue(true)]
        [Category("野性 PVP")]
        [DisplayName("Use Stealth when roaming")]
        //[Description("")]
        public bool PvPStealth { get; set; }
        */

        #endregion
  
        #region Common

        [Setting]
        [DefaultValue(false)]
        [Category("常规")]
        [DisplayName("使用水栖形态")]
        [Description("投水栖形态更快的运动，而游泳")]
        public bool UseAquaticForm { get; set; }

        [Setting]
        [DefaultValue(true)]
        [Category("常规")]
        [DisplayName("使用旅行形态")]
        [Description("Cast Travel Form (or Cat Form) for faster movement while running on foot")]
        public bool UseTravelForm { get; set; }

        [Setting]
        [DefaultValue(true)]
        [Category("常规")]
        [DisplayName("使用野性冲锋")]
        [Description("使用各天赋下对应的野性冲锋")]
        public bool UseWildCharge { get; set; }

        [Setting]
        [DefaultValue(false)]
        [Category("常规")]
        [DisplayName("移动到目标背后")]
        [Description("猫形态下在开怪前/目标昏迷/目标的目标不是你时移动到目标背后")]
        public bool MoveBehindTargets { get; set; }

        [Setting]
        [DefaultValue(1)]
        [Category("Common")]
        [DisplayName("Disorienting Roar Count")]
        [Description("Number of Mobs required before casting Disorienting Roar when Solo/PVP")]
        public int DisorientingRoarCount { get; set; }

        [Setting]
        [DefaultValue(25)]
        [Category("Common")]
        [DisplayName("Disorienting Roar Health %")]
        [Description("Health % to cast Disorienting Roar to peel off mobs prior to healing when Solo/PVP")]
        public int DisorientingRoarHealth { get; set; } 



/*
                        [Setting]
                        [DefaultValue(false)]
                        [Category("常规")]
                        [DisplayName("平衡和野性专精时不进行治疗")]
                        public bool NoHealBalanceAndFeral { get; set; }

                        [Setting]
                        [DefaultValue(20)]
                        [Category("常规")]
                        [DisplayName("治疗之触血量百分比(平衡和野性专精)")]
                        [Description("当血量低于或等于该百分比时使用治疗之触.")]
                        public int NonRestoHealingTouch { get; set; }

                */

        [Setting]
        [DefaultValue(60)]
        [Category("治疗自己")]
        [DisplayName("回春术")]
        [Description("单人战斗时当血量低于该百分比时使用回春术进行自我治疗")]
        public int SelfRejuvenationHealth { get; set; }

        [Setting]
        [DefaultValue(40)]
        [Category("治疗自己")]
        [DisplayName("治疗之触")]
        [Description("单人战斗时当血量低于该百分比时使用治疗之触进行自我治疗")]
        public int SelfHealingTouchHealth { get; set; }

        [Setting]
        [DefaultValue(35)]
        [Category("治疗自己")]
        [DisplayName("新生")]
        [Description("单人战斗时当血量低于该百分比时使用新生进行自我治疗")]
        public int SelfRenewalHealth { get; set; }

        [Setting]
        [DefaultValue(20)]
        [Category("治疗自己")]
        [DisplayName("自然迅捷")]
        [Description("单人战斗时当血量低于该百分比时使用自然迅捷进行自我治疗")]
        public int SelfNaturesSwiftnessHealth { get; set; } 

        [Setting]
        [DefaultValue(80)]
        [Category("治疗自己")]
        [DisplayName("塞纳里奥结界")]
        [Description("单人战斗时当血量低于该百分比时使用塞纳里奥结界进行自我治疗")]
        public int SelfCenarionWardHealth { get; set; }

        #endregion

        #region Balance

        [Setting]
        [DefaultValue(80)]
        [Category("平衡")]
        [DisplayName("回春术(枭兽形态下)")]
        [Description("单人战斗时当血量低于该百分比时使用回春术(枭兽形态下)进行自我治疗")]
        public int MoonBeastRejuvenationHealth { get; set; }

        [Setting]
        [DefaultValue(40)]
        [Category("平衡")]
        [DisplayName("治疗之触(枭兽形态下)")]
        [Description("单人战斗时当血量低于该百分比时使用治疗之触(枭兽形态下)自我治疗")]
        public int MoonBeastHealingTouch { get; set; }


        #endregion

        #region Resto

        [Setting]
        [DefaultValue(1)]
        [Category("Restoration")]
        [DisplayName("Wild Charge Count")]
        [Description("Count of Melee Attacks which cause this spell to be used, 0: disable")]
        public int RestoWildChargeCount { get; set; }

        [Setting]
        [DefaultValue(60)]
        [Category("恢复")]
        [DisplayName("宁静血量百分比")]
        [Description("当血量低于该百分比时使用宁静")]
        public int TranquilityHealth { get; set; }

        [Setting]
        [DefaultValue(3)]
        [Category("恢复")]
        [DisplayName("宁静(血量过低的队友数量)")]
        [Description("当队友血量低于宁静血量百分比的人数达到该值时使用宁静")]
        public int TranquilityCount { get; set; }

        [Setting]
        [DefaultValue(65)]
        [Category("恢复")]
        [DisplayName("迅捷治愈血量百分比")]
        [Description("当血量低于该百分比时使用迅捷治愈")]
        public int Swiftmend { get; set; }

        [Setting]
        [DefaultValue(80)]
        [Category("恢复")]
        [DisplayName("野性成长血量百分比")]
        [Description("当血量低于该百分比时使用野性成长")]
        public int WildGrowthHealth { get; set; }

        [Setting]
        [DefaultValue(2)]
        [Category("恢复")]
        [DisplayName("野性成长(血量过低的队友数量)")]
        [Description("当队友血量低于宁静血量百分比的人数达到该值时使用野性成长")]
        public int WildGrowthCount { get; set; }

        [Setting]
        [DefaultValue(70)]
        [Category("恢复")]
        [DisplayName("% 愈合")]
        [Description("当血量低于该百分比时使用该技能.设置为0禁用.")]
        public int Regrowth { get; set; }

        [Setting]
        [DefaultValue(60)]
        [Category("恢复")]
        [DisplayName("% 治疗之触")]
        [Description("当血量低于该百分比时使用该技能.设置为0禁用.")]
        public int HealingTouch { get; set; }

        [Setting]
        [DefaultValue(90)]
        [Category("恢复")]
        [DisplayName("% 回春术")]
        [Description("当血量低于该百分比时使用该技能.设置为0禁用.")]
        public int Rejuvenation { get; set; }

        [Setting]
        [DefaultValue(70)]
        [Category("恢复")]
        [DisplayName("树皮术血量百分比")]
        [Description("当血量低于该百分比时使用树皮术")]
        public int Barkskin { get; set; }

        #endregion


        #region Guardian
        [Setting]
        [DefaultValue(70)]
        [Category("守护")]
        [DisplayName("狂暴回复血量百分比")]
        [Description("当血量低于该百分比时使用狂暴回复.设置为100则技能一冷却就用.(推荐设置:装备了雕文设置为30,没装备雕文设置为15)")]
        public int TankFrenziedRegenerationHealth { get; set; }

        [Setting]
        [DefaultValue(100)]
        [Category("守护")]
        [DisplayName("野蛮防御血量百分比")]
        [Description("当血量低于该百分比时使用野蛮防御.设置为100则技能一冷却就用.")]
        public int TankSavageDefense { get; set; }

        [Setting]
        [DefaultValue(55)]
        [Category("守护")]
        [DisplayName("生存本能血量百分比")]
        [Description("当血量低于该百分比时使用生存本能.设置为100则技能一冷却就用. (推荐设置:55)")]
        public int TankSurvivalInstinctsHealth { get; set; }

        [Setting]
        [DefaultValue(80)]
        [Category("Guardian")]
        [DisplayName("Barkskin Health")]
        [Description("Barkskin will be used at this value. Set this to 100 to enable on cooldown usage.")]
        public int TankFeralBarkskin { get; set; }

        [Setting]
        [DefaultValue(80)]
        [Category("Guardian")]
        [DisplayName("Dream of Cenarius Healing Touch")]
        [Description("Health Percent to cast Healing Touch if Dream of Cenarius has procced")]
        public int DreamOfCenariusHealingTouchHealth { get; set; }


        #endregion

        #region Feral

        public enum SpellPriority
        {
            Noxxic = 1,
            ElitistJerks = 3
        }


        [Setting]
        [DefaultValue(SpellPriority.ElitistJerks )]
        [Category("野性")]
        [DisplayName("形态法术优先")]
        public SpellPriority FeralSpellPriority { get; set; }


        [Setting]
        [DefaultValue(80)]
        [Category("野性")]
        [DisplayName("治疗之触(掠食者的迅捷)")]
        [Description("单人战斗时当血量低于该百分比时使用治疗之触(掠食者的迅捷)进行自我治疗")]
        public int PredSwiftnessHealingTouchHealth { get; set; }

        [Setting]
        [DefaultValue(35)]
        [Category("野性")]
        [DisplayName("在PVP时使用掠食者的迅捷进行辅助治疗的血量百分比")]
        [Description("队友血量低于该百分比时使用掠食者的迅捷进行辅助治疗")]
        public int PredSwiftnessPvpHeal { get; set; }


/*
        [Setting]
        [DefaultValue(50)]
        [Category("野性")]
        [DisplayName("树皮术治疗")]
        [Description("Barkskin will be used at this value. Set this to 100 to enable on cooldown usage.")]
        public int FeralBarkskin { get; set; }
*/

        [Setting]
        [DefaultValue(55)]
        [Category("野性")]
        [DisplayName("生存本能血量百分比")]
        [Description("当血量低于该百分比时使用生存本能.设置为100则技能一冷却就用.(推荐设置:55)")]
        public int SurvivalInstinctsHealth { get; set; }

        [Setting]
        [DefaultValue(false)]
        [Category("野性")]
        [DisplayName("总是潜行")]
        [Description("脱离战斗后总是潜行.不要禁用坐骑.(如果需要你可以在HB的设置里进行设置)")]
        public bool ProwlAlways { get; set; }

/*
                [Setting]
                [DefaultValue(30)]
                [Category("野性 PVP")]
                [DisplayName("Frenzied Regeneration Health")]
                [Description("FR will be used at this value. Set this to 100 to enable on cooldown usage. (Recommended: 30 if glyphed. 15 if not.)")]
                public int FrenziedRegenerationHealth { get; set; }

                [Setting]
                [DefaultValue(0)]
                [Category("Form Selection")]
                [DisplayName("Form Selection")]
                [Description("Form Selection!")]
                public int Shapeform { get; set; }

                [Setting]
                [DefaultValue(60)]
                [Category("野性")]
                [DisplayName("Predator"s Swiftness heal")]
                [Description("Healing with Predator"s Swiftness will be used at this value")]
                public int NonRestoprocc { get; set; }

                [Setting]
                [DefaultValue(true)]
                [Category("野性 团队/副本")]
                [DisplayName("Cat - Disable Healing for Balance and Feral")]
                public bool RaidCatProwl { get; set; }

                [Setting]
                [DefaultValue(15)]
                [Category("野性 团队/副本")]
                [DisplayName("Cat - Predator"s Swiftness (Balance and Feral)")]
                public int RaidCatProccHeal { get; set; }


                [Setting]
                [DefaultValue(true)]
                [Category("野性 团队/副本")]
                [DisplayName("Interrupt")]
                [Description("Automatically interrupt spells while in an instance if this value is set to true.")]
                public bool Interrupt { get; set; }

                [Setting]
                [DefaultValue(true)]
                [Category("野性 团队/副本")]
                [DisplayName("猫 - 不在BOSS身后报警")]
                public bool CatRaidWarning { get; set; }

                [Setting]
                [DefaultValue(true)]
                [Category("野性 团队/副本")]
                [DisplayName("猫 - 使用冲刺作为差距接近")]
                public bool CatRaidDash { get; set; }

                [Setting]
                [DefaultValue(true)]
                [Category("野性 团队/副本")]
                [DisplayName("猫 - 使用团队副本按钮")]
                //[Description("")]
                public bool CatRaidButtons { get; set; }

                [Setting]
                [DefaultValue(true)]
                [Category("野性 团队/副本")]
                [DisplayName("猫 - 使用狂奔怒吼")]
                [Description("If set to true, it will cast Stampeding Roar to close gap to target.")]
                public bool CatRaidStampeding { get; set; }
        


                [Setting]
                [DefaultValue(true)]
                [Category("野性 PVP")]
                [DisplayName("猫 - 隐身拉怪")]
                [Description("Always try to pull while in stealth. If disabled it pulls with FFF instead.")]
                public bool CatNormalPullStealth { get; set; }


                [Setting]
                [DefaultValue(4)]
                [Category("野性 团队/副本")]
                [DisplayName("猫 - AOE数")]
                [Description("Number of adds needed to start Aoe rotation.")]
                public int CatRaidAoe { get; set; }

                [Setting]
                [DefaultValue(true)]
                [Category("野性 团队/副本")]
                [DisplayName("猫 - 自动狂暴")]
                [Description("If set to true, it will cast Berserk automatically to do max dps.")]
                public bool CatRaidBerserk { get; set; }

                [Setting]
                [DefaultValue(true)]
                [Category("野性 团队/副本")]
                [DisplayName("猫 - 自动猛虎之怒")]
                [Description("If set to true, it will cast Tiger"s Fury automatically to do max dps.")]
                public bool CatRaidTigers { get; set; }

                [Setting]
                [DefaultValue(false)]
                [Category("野性 团队/副本")]
                [DisplayName("猫 - 战斗中补buff")]
                [Description("If set to true, it will rebuff Mark of the Wild infight.")]
                public bool CatRaidRebuff { get; set; }

                [Setting]
                [DefaultValue(true)]
                [Category("野性 团队/副本")]
                [DisplayName("猫 - 野性冲锋")]
                [Description("                [Description("Use Feral Charge to close gaps. It should handle bosses where charge is not" +
                             "possible || best solution automatically.")]
                public bool CatRaidUseFeralCharge { get; set; }

                [Setting]
                [DefaultValue(true)]
                [Category("野性 团队/副本")]
                [DisplayName("熊 - 野性冲锋")]
                [Description("                [Description("Use Feral Charge to close gaps. It should handle bosses where charge is not" +
                             "possible || best solution automatically.")]
                public bool BearRaidUseFeralCharge { get; set; }

                [Setting]
                [DefaultValue(2)]
                [Category("野性 团队/副本")]
                [DisplayName("熊 - AOE数")]
                [Description("开启AOE所需的数量")]
                public int BearRaidAoe { get; set; }

                [Setting]
                [DefaultValue(true)]
                [Category("野性 团队/副本")]
                [DisplayName("熊 - 自动狂暴")]
                [Description("如果设置成True，则自动施放狂暴")]
                public bool BearRaidBerserk { get; set; }

                [Setting]
                [DefaultValue(false)]
                [Category("野性 团队/副本")]
                [DisplayName("熊 - 狂暴爆发")]
                [Description("If set to true, it will SPAM MANGLE FOR GODS SAKE while Berserk is active.")]
                public bool BearRaidBerserkFun { get; set; }

                [Setting]
                [DefaultValue(true)]
                [Category("Feral Raid / Instance")]
                [DisplayName("Bear - Auto defensive cooldowns")]
                [Description("If set to true, it will cast defensive cooldowns automatically.")]
                public bool BearRaidCooldown { get; set; }
        */
        // End of IloveDruids

        #endregion
    }


    internal class DruidHealSettings : Singular.Settings.HealerSettings
    {
        private DruidHealSettings()
            : base("", HealingContext.None)
        {
        }

        public DruidHealSettings(HealingContext ctx)
            : base("Druid", ctx)
        {

            // we haven't created a settings file yet,
            //  ..  so initialize values for various heal contexts

            if (!SavedToFile)
            {
                if (ctx == Singular.HealingContext.Battlegrounds)
                {
                    Rejuvenation = 95;
                    Nourish = 0;
                    HealingTouch = 0;
                    Regrowth = 75;
                    WildGrowth = 90;
                    CountWildGrowth = 3;
                    Swiftmend = 74;
                    WildMushroomBloom = 60;
                    CountMushroomBloom = 1;
                    Tranquility = 0;
                    CountTranquility = 0;
                    TreeOfLife = 60;
                    CountTreeOfLife = 1;
                    Ironbark = 59;
                    NaturesSwiftness = 35;
                    CenarionWard = 80;
                    NaturesVigil = 60;
                }
                else if (ctx == Singular.HealingContext.Instances)
                {
                    Rejuvenation = 95;
                    Nourish = 85;
                    HealingTouch = 70;
                    Regrowth = 40;
                    WildGrowth = 85;
                    CountWildGrowth = 3;
                    Swiftmend = 70;
                    WildMushroomBloom = 85;
                    CountMushroomBloom = 2;
                    Tranquility = 60;
                    CountTranquility = 3;
                    TreeOfLife = 70;
                    CountTreeOfLife = 3;
                    Ironbark = 60;
                    NaturesSwiftness = 25;
                    CenarionWard = 80;
                    NaturesVigil = 70;
                }
                else if (ctx == Singular.HealingContext.Raids)
                {
                    Rejuvenation = 94;
                    Nourish = 95;
                    HealingTouch = 60;
                    Regrowth = 40;
                    WildGrowth = 90;
                    CountWildGrowth = 4;
                    Swiftmend = 85;
                    WildMushroomBloom = 95;
                    CountMushroomBloom = 3;
                    Tranquility = 70;
                    CountTranquility = 5;
                    TreeOfLife = 75;
                    CountTreeOfLife = 4;
                    Ironbark = 65;
                    NaturesSwiftness = 25;
                    CenarionWard = 85;
                    NaturesVigil = 80;
                }
                // omit case for WoWContext.Normal and let it use DefaultValue() values
            }

            SavedToFile = true;
        }

        [Setting]
        [Browsable(false)]
        [DefaultValue(false)]
        public bool SavedToFile { get; set; }

        [Setting]
        [DefaultValue(70)]
        [Category("恢复")]
        [DisplayName("% 回春术")]
        [Description("当血量低于该百分比时使用该技能.设置为0禁用.")]
        public int Rejuvenation { get; set; }

        [Setting]
        [DefaultValue(70)]
        [Category("恢复")]
        [DisplayName("% 滋养")]
        [Description("当血量低于该百分比时使用该技能.设置为0禁用.")]
        public int Nourish { get; set; }

        [Setting]
        [DefaultValue(70)]
        [Category("恢复")]
        [DisplayName("% 治疗之触")]
        [Description("当血量低于该百分比时使用该技能.设置为0禁用.")]
        public int HealingTouch { get; set; }

        [Setting]
        [DefaultValue(70)]
        [Category("恢复")]
        [DisplayName("% 愈合")]
        [Description("当血量低于该百分比时使用该技能.设置为0禁用.")]
        public int Regrowth { get; set; }

        [Setting]
        [DefaultValue(92)]
        [Category("恢复")]
        [DisplayName("% 野性成长")]
        [Description("当血量低于该百分比时使用该技能.设置为0禁用.")]
        public int WildGrowth { get; set; }

        [Setting]
        [DefaultValue(4)]
        [Category("恢复")]
        [DisplayName("野性成长最少队友数量")]
        [Description("最少血量百分比低于野性成长设置值的范围内队友数")]
        public int CountWildGrowth { get; set; }

        [Setting]
        [DefaultValue(70)]
        [Category("恢复")]
        [DisplayName("迅捷治愈血量百分比")]
        [Description("当血量低于该百分比时使用迅捷治愈")]
        public int Swiftmend { get; set; }

        [Setting]
        [DefaultValue(70)]
        [Category("恢复")]
        [DisplayName("% 野性蘑菇：绽放")]
        [Description("当血量低于该百分比时使用该技能.设置为0禁用.")]
        public int WildMushroomBloom { get; set; }

        [Setting]
        [DefaultValue(3)]
        [Category("恢复")]
        [DisplayName("野性蘑菇：绽放最少队友数量")]
        [Description("最少血量百分比低于野性蘑菇：绽放设置值的范围内队友数")]
        public int CountMushroomBloom { get; set; }

        [Setting]
        [DefaultValue(91)]
        [Category("恢复")]
        [DisplayName("% 宁静")]
        [Description("当血量低于该百分比时使用该技能.小队时最少设置数量3,团队时最少设置数量4.设置为0禁用.")]
        public int Tranquility { get; set; }

        [Setting]
        [DefaultValue(4)]
        [Category("恢复")]
        [DisplayName("宁静最少队友数量")]
        [Description("当队友血量低于宁静血量百分比的人数达到该值时使用宁静")]
        public int CountTranquility { get; set; }

        [Setting]
        [DefaultValue(60)]
        [Category("恢复")]
        [DisplayName("% 生命之树形态")]
        [Description("当血量低于该百分比时使用该技能.设置为0禁用.")]
        public int TreeOfLife { get; set; }

        [Setting]
        [DefaultValue(3)]
        [Category("恢复")]
        [DisplayName("生命之树最少队友数量")]
        [Description("最少血量百分比低于生命之树设置值的范围内队友数")]
        public int CountTreeOfLife { get; set; }

        [Setting]
        [DefaultValue(60)]
        [Category("恢复")]
        [DisplayName("% 源生")]
        [Description("当血量低于该百分比时使用该技能.设置为0禁用.")]
        public int Genesis { get; set; }

        [Setting]
        [DefaultValue(3)]
        [Category("恢复")]
        [DisplayName("源生最少队友数量")]
        [Description("最少血量百分比低于源生设置值的范围内具有回春BUFF的队友数")]
        public int CountGenesis { get; set; }

        [Setting]
        [DefaultValue(60)]
        [Category("恢复")]
        [DisplayName("% 铁木树皮")]
        [Description("当血量低于该百分比时使用该技能.设置为0禁用.")]
        public int Ironbark { get; set; }

        [Setting]
        [DefaultValue(60)]
        [Category("恢复")]
        [DisplayName("% 自然迅捷")]
        [Description("当血量低于该百分比时使用该技能.设置为0禁用.")]
        public int NaturesSwiftness { get; set; }

        [Setting]
        [DefaultValue(60)]
        [Category("恢复")]
        [DisplayName("% 塞纳里奥结界")]
        [Description("当血量低于该百分比时使用该技能.设置为0禁用.")]
        public int CenarionWard { get; set; }

        [Setting]
        [DefaultValue(60)]
        [Category("恢复")]
        [DisplayName("% 自然的守护")]
        [Description("当血量低于该百分比时使用该技能.设置为0禁用.")]
        public int NaturesVigil { get; set; }

        [Setting]
        [DefaultValue(60)]
        [Category("恢复")]
        [DisplayName("% 野性之心")]
        [Description("当血量低于该百分比时使用该技能.设置为0禁用.")]
        public int HeartOfTheWild { get; set; }

        [Setting]
        [DefaultValue(5)]
        [Category("恢复")]
        [DisplayName("野性之心最少队友数量")]
        [Description("最少血量百分比低于野性之心设置值的队友数.")]
        public int CountHeartOfTheWild { get; set; }

        [Setting]
        [DefaultValue(0)]
        [Category("恢复")]
        [DisplayName("塞纳留斯的梦境血量百分比")]
        [Description("仅在血量高于该百分比时使用塞纳留斯的梦境进行治疗")]
        public int DreamOfCenariusAbovePercent { get; set; }

        [Setting]
        [DefaultValue(1)]
        [Category("恢复")]
        [DisplayName("塞纳留斯的梦境治疗目标数量")]
        [Description("仅在治疗目标数量低于该值时使用塞纳留斯的梦境,否则使用其他治疗技能")]
        public int DreamOfCenariusAboveCount { get; set; }

        [Setting]
        [DefaultValue(true)]
        [Category("恢复")]
        [DisplayName("塞纳留斯的梦境闲时")]
        [Description("True:在没有治疗需求时使用塞纳留斯的梦境输出")]
        public bool DreamOfCenariusWhenIdle { get; set; }

    }

}
