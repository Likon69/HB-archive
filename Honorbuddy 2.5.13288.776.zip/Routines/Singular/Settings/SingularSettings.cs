﻿
using System.ComponentModel;
using System.IO;
using System.Linq;
using Styx;
using Styx.Helpers;

using DefaultValue = Styx.Helpers.DefaultValueAttribute;
using Singular.Managers;
using System.Reflection;
using System;
using System.Collections.Generic;
using Singular.Helpers;
using Styx.CommonBot;
using Styx.WoWInternals;
using System.Drawing;
using Styx.CommonBot.CharacterManagement;

namespace Singular.Settings
{
    enum AllowMovementType
    {
        None,
        ClassSpecificOnly,
        All,
        Auto       
    }

    enum CheckTargets
    {
        None = 0,
        Current,
        All
    }

    enum PurgeAuraFilter
    {
        None = 0,
        Whitelist,
        All
    }

    enum RelativePriority
    {
        None = 0,
        LowPriority,
        HighPriority
    }

    enum TargetingStyle
    {
        None = 0,
        Enable,
        Auto
    }

    enum SelfRessurectStyle
    {
        None = 0,
        Enable,
        Auto
    }

    enum CombatRezTarget
    {
        None = 0,
        All = Tank | Healer | DPS,
        Tank = 1,
        Healer = 2,
        TankOrHealer = Tank | Healer,
        DPS = 4
    }

    enum DpsOffHealWhen
    {
        Never = 0,
        NoHealer,
        NoHealerInRange,
        Always
    }

    enum DebugOutputDest
    {
        None = 0,
        FileOnly = 1,
        WindowAndFile = 3
    }

    enum PullMoreUsageType
    {
        None = 0,
        Always = 1,
        Auto = 2
    }
    enum PullMoreTargetType
    {
        None = 0,
        LikeCurrent,
        Hostile,
        All
    }


    internal class SingularSettings : Styx.Helpers.Settings
    {
        private static int entrycount = 0;
        private static SingularSettings _instance;

        public SingularSettings()
            : base(Path.Combine(CharacterSettingsPath, "SingularSettings.xml"))
        {
            // changing how we are initialize the _instance pointer
            entrycount++;
            if (entrycount != 1)
            {
                Logger.WriteFile("Settings: unexpected reentrant call in Settings: {0}", entrycount );
            }

            if (_instance != null)
            {
                if (_instance != this)
                {
                    Logger.WriteFile("Settings: unexpected singleton error");
                }
            }
            else
            {
                _instance = this;

                bool fileExists = ConfigVersion != null;
                bool weSetPullMoreValues = false;
                Version verSourceCode = SingularRoutine.GetSingularVersion();
                Version verConfigFile = null;

                // if version is null, set to current value
                if (ConfigVersion == null)
                {
                    verConfigFile = verSourceCode;
                    ConfigVersion = verConfigFile.ToString();
                }

                try
                {
                    verConfigFile = new Version(ConfigVersion);
                }
                catch
                {
                    verConfigFile = verSourceCode;
                }

                if (verConfigFile < verSourceCode)
                {
                    Logger.WriteDiagnostic(LogColor.Init, "Settings: config file from verion {0}", verConfigFile.ToString());
                    if (verConfigFile < new Version("3.0.0.3080"))
                    {
                        Logger.Write(LogColor.Init, "Settings: applying {0} related changes", new Version("3.0.0.3080").ToString());
                        UseFrameLock = true;
                        DisableInQuestVehicle = false;
                    }

                    if (verConfigFile < new Version("3.0.0.3173"))
                    {
                        Logger.WriteDiagnostic(LogColor.Init, "Settings: applying {0} related changes", new Version("3.0.0.3173").ToString());
                        if ( MinHealth == 65)
                            MinHealth = 60;
                        if (MinMana == 65)
                            MinMana = 50;
                    }

                    if (verConfigFile < new Version("4.0.0.4000"))
                    {
                        weSetPullMoreValues = true;
                        SetDefaultPullMoreSettingValues();
                    }

                    ConfigVersion = verSourceCode.ToString();
                    Logger.WriteDiagnostic(LogColor.Init, "Settings: config settings upgrade to {0} complete", ConfigVersion.ToString());
                }

                // Pull More settings should be overwritten if !fileExist or last config saved was before selecting Specialization 
                if (!weSetPullMoreValues)
                    SetDefaultPullMoreSettingValues();

                // set calculated default values if file did not exist
                if (!fileExists)
                {
                    if (StyxWoW.Me.Class == WoWClass.DeathKnight)
                    {
                        this.MinHealth = 50;
                        Logger.Write(LogColor.Init, "Settings: default Min Health to {0}% since Death Knight", this.MinHealth);
                    }

                }
            }

            // Validate settings
            //===================================================================================
            StayNearTankRangeCombat = Validate.IntValue("StayNearTankRangeCombat", 5, 100, StayNearTankRangeCombat );
            StayNearTankRangeRest = Validate.IntValue("StayNearTankRangeRest", 5, 100, StayNearTankRangeRest);

            entrycount--;
        }

        /// <summary>
        /// sets values for Pull More based upon current WoWSpec of character.  will set temporary defaults   
        /// </summary>
        private void SetDefaultPullMoreSettingValues()
        {
            if (PullMoreSpecDefaultsSaved)
                return;

            WoWSpec spec = StyxWoW.Me.Specialization;
            if (spec == WoWSpec.None && CharacterManager.CurrentClassProfile != null)
                spec =  CharacterManager.CurrentClassProfile.GetSpec();

            int mobCount, distMelee, distRanged, minHealth;

            SingularRoutine.BestPullMoreSettingsForToon(spec, out mobCount, out distMelee, out distRanged, out minHealth);

            if (StyxWoW.Me.Specialization != WoWSpec.None)
            {
                if (this.PullMoreMobCount != mobCount)
                    Logger.Write(LogColor.Init, "Settings: default Pull More Count to {0} mobs for{1}", mobCount, SingularRoutine.SpecAndClassName());
                if (PullMoreMinHealth != minHealth)
                    Logger.Write(LogColor.Init, "Settings: default Pull More Health to {0}% for{1}", minHealth, SingularRoutine.SpecAndClassName());

                PullMoreSpecDefaultsSaved = true;
            }

            this.PullMoreDistMelee = distMelee;
            this.PullMoreDistRanged = distRanged;
            this.PullMoreMinHealth = minHealth;
            this.PullMoreMobCount = mobCount;
        }

        public static string GlobalSettingsPath
        {
            get
            {
                return Path.Combine(Styx.Common.Utilities.AssemblyDirectory, "Settings");
            }
        }


        public static string CharacterSettingsPath
        {
            get
            {
                string settingsDirectory = Path.Combine(Styx.Common.Utilities.AssemblyDirectory, "Settings");
                return Path.Combine(Path.Combine(settingsDirectory, StyxWoW.Me.RealmName), StyxWoW.Me.Name);
            }
        }


        public static string SingularSettingsPath
        {
            get
            {
                string settingsDirectory = Path.Combine(Styx.Common.Utilities.AssemblyDirectory, "Settings");
                return Path.Combine(Path.Combine(Path.Combine(settingsDirectory, StyxWoW.Me.RealmName), StyxWoW.Me.Name), "Singular");
            }
        }

        public static void Initialize()
        {
            if (_instance == null)
                _instance = new SingularSettings();
        }

        public static SingularSettings Instance 
        { 
            get { return _instance ?? (_instance = new SingularSettings()); }
            set { _instance = value; }
        }

        public static bool IsTrinketUsageWanted(TrinketUsage usage)
        {
            return usage == SingularSettings.Instance.Trinket1Usage
                || usage == SingularSettings.Instance.Trinket2Usage;
        }

        /// <summary>
        /// Write all Singular Settings in effect to the Log file
        /// </summary>
        public void LogSettings()
        {
            Logger.WriteFile("");

            // reference the internal references so we can display only for our class
            LogSettings("Singular", SingularSettings.Instance);
            LogSettings("HotkeySettings", Hotkeys());
            if (StyxWoW.Me.Class == WoWClass.DeathKnight )  LogSettings("DeathKnightSettings", DeathKnight());
            if (StyxWoW.Me.Class == WoWClass.Druid )        LogSettings("DruidSettings", Druid());
            if (StyxWoW.Me.Class == WoWClass.Hunter )       LogSettings("HunterSettings", Hunter());
            if (StyxWoW.Me.Class == WoWClass.Mage )         LogSettings("MageSettings", Mage());
            if (StyxWoW.Me.Class == WoWClass.Monk )         LogSettings("MonkSettings", Monk());
            if (StyxWoW.Me.Class == WoWClass.Paladin )      LogSettings("PaladinSettings", Paladin());
            if (StyxWoW.Me.Class == WoWClass.Priest )       LogSettings("PriestSettings", Priest());
            if (StyxWoW.Me.Class == WoWClass.Rogue )        LogSettings("RogueSettings", Rogue());
            if (StyxWoW.Me.Class == WoWClass.Shaman)        LogSettings("ShamanSettings", Shaman());
            if (StyxWoW.Me.Class == WoWClass.Warlock)       LogSettings("WarlockSettings", Warlock());
            if (StyxWoW.Me.Class == WoWClass.Warrior)       LogSettings("WarriorSettings", Warrior());

            if (TalentManager.CurrentSpec == WoWSpec.ShamanRestoration)
            {
                LogSettings("Shaman.Heal.Battleground", Shaman().RestoBattleground);
                LogSettings("Shaman.Heal.Instance", Shaman().RestoInstance);
                LogSettings("Shaman.Heal.Raid", Shaman().RestoRaid);
            }

            if (TalentManager.CurrentSpec == WoWSpec.PriestHoly)
            {
                LogSettings("Priest.Holy.Heal.Battleground", Priest().HolyBattleground);
                LogSettings("Priest.Holy.Heal.Instance", Priest().HolyInstance);
                LogSettings("Priest.Holy.Heal.Raid", Priest().HolyRaid);
            }

            if (TalentManager.CurrentSpec == WoWSpec.PriestDiscipline)
            {
                LogSettings("Priest.Disc.Heal.Battleground", Priest().DiscBattleground);
                LogSettings("Priest.Disc.Heal.Instance", Priest().DiscInstance);
                LogSettings("Priest.Disc.Heal.Raid", Priest().DiscRaid);
            }

            if (TalentManager.CurrentSpec == WoWSpec.DruidRestoration)
            {
                LogSettings("Druid.Heal.Battleground", Druid().Battleground);
                LogSettings("Druid.Heal.Instance", Druid().Instance);
                LogSettings("Druid.Heal.Raid", Druid().Raid);
            }

            Logger.WriteFile("====== Evaluated/Dynamic Settings ======");
            Logger.WriteFile("  {0}: {1}", "Debug", SingularSettings.Debug.ToYN());
            Logger.WriteFile("  {0}: {1}", "DisableAllMovement", SingularSettings.Instance.DisableAllMovement.ToYN());
            Logger.WriteFile("  {0}: {1}", "DisableAllTargeting", SingularSettings.DisableAllTargeting.ToYN());
            Logger.WriteFile("");

            if (DisableSpellsWithCooldown == 0)
                Logger.WriteFile("No spells blocked by DisableSpellsWithCooldown");
            else if (!Debug)
                Logger.WriteFile("Spells with cooldown more than {0} secs Blocked by DisableSpellsWithCooldown", DisableSpellsWithCooldown);
            else
            {
                int maxcd = DisableSpellsWithCooldown * 1000;
                Logger.WriteFile("====== Spells Blocked by DisableSpellsWithCooldown  ======");

                using (StyxWoW.Memory.AcquireFrame())
                {
                    foreach (WoWSpell spell in SpellManager.Spells.OrderBy(s => s.Key).Select(s => s.Value))
                    {
                        int cd = Spell.GetBaseCooldown(spell);
                        if (cd >= maxcd)
                        {
                            Logger.WriteFile("  {0} {1}", (cd / 1000).ToString().AlignRight(4), spell.Name);
                        }
                    }
                }
                Logger.WriteFile(" ");
            }
        }

        public void LogSettings(string desc, Styx.Helpers.Settings set)
        {
            if (set == null)
                return;

            Logger.WriteFile("====== {0} Settings ======", desc);
            foreach (var kvp in set.GetSettings())
            {
                Logger.WriteFile("  {0}: {1}", kvp.Key, kvp.Value.ToString());
            }

            Logger.WriteFile("");
        }

        public void SetPropertyReadOnly(string propName, bool isReadOnly)
        {
            PropertyDescriptor descriptor = TypeDescriptor.GetProperties(this.GetType())[propName];
            ReadOnlyAttribute attribute = (ReadOnlyAttribute)descriptor.Attributes[typeof(ReadOnlyAttribute)];
            if (attribute != null)
            {
                FieldInfo fieldToChange = attribute.GetType().GetField("isReadOnly",
                                                 System.Reflection.BindingFlags.NonPublic |
                                                 System.Reflection.BindingFlags.Instance);
                if (fieldToChange != null)
                {
                    bool currentlyReadOnly = (bool) fieldToChange.GetValue(attribute);
                    if (currentlyReadOnly != isReadOnly)
                        fieldToChange.SetValue(attribute, isReadOnly);
                }
            }
        }

        /// <summary>
        /// Obsolete:  Almost all code should reference MovementManager.IsMovementDisabled
        /// .. which will handle Hotkey processing and any context sensitive bot behavior.
        /// .. This setting only retrieves the user setting which typically is insufficient.
        /// </summary>
        [Browsable(false)]
        public bool DisableAllMovement
        {
            get
            {
                if (AllowMovement != AllowMovementType.Auto)
                    return AllowMovement == AllowMovementType.None;

                return SingularRoutine.IsManualMovementBotActive;
            }
        }

        [Browsable(false)]
        public static bool Debug
        {
            get
            {
                return Instance.DebugOutput != DebugOutputDest.None;
            }
        }

        [Browsable(false)]
        public static bool DebugSpellCasting
        {
            get
            {
                return Debug && Instance.EnableDebugSpellCasting;
            }
        }

        [Browsable(false)]
        public static bool DebugStopMoving
        {
            get
            {
                return false;
            }
        }

        [Browsable(false)]
        public static bool Trace
        {
            get
            {
                return Debug && SingularSettings.Instance.EnableDebugTrace;
            }
        }

        [Browsable(false)]
        public static bool DisableAllTargeting
        {
            get
            {
                if (SingularSettings.Instance.TypeOfTargeting != TargetingStyle.Auto)
                    return SingularSettings.Instance.TypeOfTargeting == TargetingStyle.None;

                return SingularRoutine.IsManualMovementBotActive || SingularRoutine.IsDungeonBuddyActive;
            }
        }

        #region Category: Hidden

        [Browsable(false)]
        [Setting,ReadOnly(false)]
        public string ConfigVersion { get; set; }

        [Browsable(false)]
        [Setting,ReadOnly(false)]
        [DefaultValue(450)]
        [Category("增强")]
        [DisplayName("Spell Throttle")]
        [Description("Time between same instance of spell cast can be repeated")]
        public int SameSpellThrottle { get; set; }
            
        #endregion 

        #region Category: Debug

        // code should reference SingularSettings.DebugSpellCasting
        //
        [Browsable(false)]
        [Setting,ReadOnly(false)]
        [DefaultValue(false)]
        [Category("调试")]
        [DisplayName("调试法术输出检测")]
        [Description("Enables logging of GCD/Cast/Channeling in Singular. Debug Logging setting must also be true")]
        public bool EnableDebugSpellCasting { get; set; }

        // code should reference SingularSettings.Trace
        //
        [Browsable(false)]
        [Setting,ReadOnly(false)]
        [DefaultValue(false)]
        [Category("调试")]
        [DisplayName("调试跟踪")]
        [Description("极其详细的记录!启用进入/退出的每个行为记录.仅在收到指示时使用,除非你你喜欢较慢的响应时间!")]
        public bool EnableDebugTrace { get; set; }

        // code should reference SingularSettings.Debug
        //
        [Browsable(false)]
        [Setting,ReadOnly(false)]
        [DefaultValue(DebugOutputDest.FileOnly)]
        [Category("调试")]
        [DisplayName("调试输出")]
        [Description("None: disable debug logic, FileOnly: debug output to file, WindowAndFile: debug output to log window and file")]
        public DebugOutputDest DebugOutput { get; set; }

        // code should reference SingularSettings.DebugBuffAuraPresence
        //
        [Browsable(false)]
        [Setting, ReadOnly(false)]
        [DefaultValue(false)]
        [Category("Debug")]
        [DisplayName("Debug Spell Casting Detection")]
        [Description("Enables logging of GCD/Cast/Channeling in Singular. Debug Logging setting must also be true")]
        public bool EnableDebugTraceBuffPresence { get; set; }

        #endregion

        #region Window Layout

        [Browsable(false)]
        [Setting,ReadOnly(false)]
        [DefaultValue(337)]
        public int FormHeight { get; set; }

        [Browsable(false)]
        [Setting,ReadOnly(false)]
        [DefaultValue(378)]
        public int FormWidth { get; set; }

        [Browsable(false)]
        [Setting,ReadOnly(false)]
        [DefaultValue(0)]
        public int FormTabIndex { get; set; }


        #endregion

        #region Category: Movement

        [Setting,ReadOnly(false)]
        [DefaultValue(AllowMovementType.Auto)]
        [Category("移动")]
        [DisplayName("允许移动")]
        [Description("允许战斗模块控制角色移动. None: 禁止所有移动; ClassSpecificOnly: 仅使用冲锋/英勇飞跃/闪现/逃脱/等; All: 允许所有移动; Auto: 当<LazyRaider模式>启用时和<None>一样,其他情况下同<All>。")]
        public AllowMovementType AllowMovement { get; set; }

        [Setting, ReadOnly(false)]
        [DefaultValue(true)]
        [Category("移动")]
        [DisplayName("横向移动以聚集怪物")]
        [Description("Allow movement to move attacking NPCs in front")]
        public bool MoveSidewaysToGatherMobs { get; set; }

        [Setting, ReadOnly(false)]
        [DefaultValue(12)]
        [Category("移动")]
        [DisplayName("近战取消坐骑距离")]
        [Description("当近战与目标的距离小于设置的距离时取消坐骑")]
        public int MeleeDismountRange { get; set; }

        [Setting, ReadOnly(false)]
        [DefaultValue(true)]
        [Category("移动")]
        [DisplayName("允许群怪在后面")]
        [Description("Allow Singular to move melee classes to behind bosses, etc.")]
        public bool MeleeMoveBehind { get; set; }

        [Setting,ReadOnly(false)]
        [DefaultValue(true)]
        [Category("移动")]
        [DisplayName("保持群怪在前面")]
        [Description("Allow Singular to move melee classes to keep melee attackers in front.  Works only in Normal (Solo) context")]
        public bool MeleeKeepMobsInFront { get; set; }

        [Setting,ReadOnly(false)]
        [DefaultValue(true)]
        [Category("移动")]
        [DisplayName("使用可移动施法的技能")]
        [Description("True: 在移动中使用非瞬发法术前先尝试使用灵魂行者之赐,浮冰,基尔加丹的狡诈,等技能.")]
        public bool UseCastWhileMovingBuffs { get; set; }

        #endregion 

        #region Category: Consumables

        [Setting,ReadOnly(false)]
        [DefaultValue(60)]
        [Category("消耗品")]
        [DisplayName("使用食物血量百分比")]
        [Description("使用食物的最低血量百分比")]
        public int MinHealth { get; set; }

        [Setting,ReadOnly(false)]
        [DefaultValue(50)]
        [Category("消耗品")]
        [DisplayName("使用饮料法力百分比")]
        [Description("使用饮料的最低法力百分比")]
        public int MinMana { get; set; }

        [Setting,ReadOnly(false)]
        [DefaultValue(30)]
        [Category("消耗品")]
        [DisplayName("使用药水血量百分比")]
        [Description("使用治疗药水/饰品/治疗石的最低血量百分比")]
        public int PotionHealth { get; set; }

        [Setting,ReadOnly(false)]
        [DefaultValue(30)]
        [Category("消耗品")]
        [DisplayName("使用药水法力百分比")]
        [Description("使用魔法药水/饰品的最低法力百分比(所有法力回复物品均有效)")]
        public int PotionMana { get; set; }

        [Setting,ReadOnly(false)]
        [DefaultValue(false)]
        [Category("消耗品")]
        [DisplayName("使用绷带")]
        [Description("使用背包中的绷带进行治疗")]
        public bool UseBandages { get; set; }

        #endregion

        #region Category: Avoidance

        [Setting,ReadOnly(false)]
        [DefaultValue(true)]
        [Category("躲避")]
        [DisplayName("允许逃脱")]
        [Description("允许使用逃脱, 闪现, 平衡-野性冲锋, 或者相当于快速位移的法术")]
        public bool DisengageAllowed { get; set; }

        [Setting,ReadOnly(false)]
        [DefaultValue(101)]
        [Category("躲避")]
        [DisplayName("逃脱血量百分比")]
        [Description("Disengage (or equiv) if health below this % and mob in melee range")]
        public int DisengageHealth { get; set; }

        [Setting,ReadOnly(false)]
        [DefaultValue(1)]
        [Category("躲避")]
        [DisplayName("逃脱怪物数量")]
        [Description("如果超过该数量的怪物进入近战范围时使用逃脱(或同样效果的技能)")]
        public int DisengageMobCount { get; set; }

        [Setting,ReadOnly(false)]
        [DefaultValue(false)]
        [Category("躲避")]
        [DisplayName("允许风筝")]
        [Description("允许风筝怪物")]
        public bool KiteAllow { get; set; }

        [Setting,ReadOnly(false)]
        [DefaultValue(70)]
        [Category("躲避")]
        [DisplayName("风筝血量百分比")]
        [Description("血量低于该百分且怪物进入近战范围时进行风筝")]
        public int KiteHealth { get; set; }

        [Setting,ReadOnly(false)]
        [DefaultValue(1)]
        [Category("躲避")]
        [DisplayName("风筝怪物数量")]
        [Description("风筝如果超过设置的敌人的数量进入近战范围")]
        public int KiteMobCount { get; set; }

        [Setting,ReadOnly(false)]
        [DefaultValue(8)]
        [Category("躲避")]
        [DisplayName("躲避距离")]
        [Description("仅在这个距离内攻击你的怪物数量达到逃脱/风筝怪物数量时使用")]
        public int AvoidDistance { get; set; }

        [Browsable(false)]
        [Setting,ReadOnly(false)]
        [DefaultValue(false)]
        [Category("躲避")]
        [DisplayName("风筝时跳跃转身")]
        [Description("风筝怪物时跳跃后转身进行攻击(目前仅支持猎人)")]
        public bool JumpTurnAllow { get; set; }

        #endregion

        #region Category: General

        [Setting,ReadOnly(false)]
        [DefaultValue(true)]
        [Category("常规")]
        [DisplayName("使用帧数锁定")]
        [Description("强制使用帧数锁定.主要用于某些不支持帧数锁定的辅助模式")]
        public bool UseFrameLock { get; set; }

        [Setting, ReadOnly(false)]
        [DefaultValue(true)]
        [Category("常规")]
        [DisplayName("等待复活虚弱")]
        [Description("等待复活虚弱状态结束.")]
        public bool ResSicknessWait { get; set; }

        [Setting, ReadOnly(false)]
        [DefaultValue(false)]
        [Category("General")]
        [DisplayName("Res Sickness: Stealth")]
        [Description("Stealth while waiting for resurrection sickness to wear off.")]
        public bool ResSicknessStealthDuring { get; set; }

        [Setting, ReadOnly(false)]
        [DefaultValue(false)]
        [Category("常规")]
        [DisplayName("禁用非战斗行为")]
        [Description("启用后会禁用非战斗行为.例如(吃喝恢复,战斗前加BUFF等)")]
        public bool DisableNonCombatBehaviors { get; set; }

        [Setting,ReadOnly(false)]
        [DefaultValue(false)]
        [Category("常规")]
        [DisplayName("乘坐任务运输工具时禁用")]
        [Description("True: 乘坐任务运输工具时禁用Singular忽略调用; False: 当任务模式需要是尝试让Singular进行战斗/治疗.")]
        public bool DisableInQuestVehicle { get; set; }

        [Setting,ReadOnly(false)]
        [DefaultValue(0)]
        [Category("常规")]
        [DisplayName("禁用冷却大于等于该时间的技能(秒)")]
        [Description("阻止Singular施放技能冷却时间等于或者大于该秒数的技能; 设置为0则允许施放所有技能")]
        public int DisableSpellsWithCooldown { get; set; }

        [Setting, ReadOnly(false)]
        [DefaultValue(SelfRessurectStyle.Auto)]
        [Category("常规")]
        [DisplayName("自我复活")]
        [Description("Auto: 除禁用了移动功能的情况外进行自我复活(重生/灵魂石), Enable: 自我复活可用时总是使用, None: 不使用自我复活")]
        public SelfRessurectStyle SelfRessurect { get; set; }

        [Setting, ReadOnly(false)]
        [DefaultValue(50)]
        [Category("General")]
        [DisplayName("Garrison Ability: at Health %")]
        [Description("Use Garrison Ability if Health below this and target(s) likely to out live you")]
        public int GarrisonAbilityHealth { get; set; }

        [Setting, ReadOnly(false)]
        [DefaultValue(3)]
        [Category("General")]
        [DisplayName("Garrison Ability: at mob count")]
        [Description("Use Garrison Ability if in combat with this many mobs or more")]
        public int GarrisonAbilityMobCount { get; set; }

        #endregion

        #region Category: Pets

        [Setting,ReadOnly(false)]
        [DefaultValue(false)]
        [Category("宠物")]
        [DisplayName("禁用宠物")]
        [Description("允许该项将会禁用宠物")]
        public bool DisablePetUsage { get; set; }

        [Setting,ReadOnly(false)]
        [DefaultValue(true)]
        [Category("宠物")]
        [DisplayName("单人战斗: 宠物当MT,T住ADD的怪")]
        [Description("True: 单人战斗下,宠物会主动嘲讽正在攻击玩家的怪物")]
        public bool PetTankAdds { get; set; }

        #endregion 

        #region Category: Group Healing / Support

        [Setting,ReadOnly(false)]
        [DefaultValue(35)]
        [Category("队伍治疗/支援")]
        [DisplayName("DPS紧急治疗开始 %")]
        [Description("DPS Off-Heal starts if companion below % (never in raids)")]
        public int DpsOffHealBeginPct { get; set; }

        [Setting,ReadOnly(false)]
        [DefaultValue(65)]
        [Category("队伍治疗/支援")]
        [DisplayName("DPS紧急治疗结束 %")]
        [Description("DPS heals ends if group above % and healer in range (never in raids)")]
        public int DpsOffHealEndPct { get; set; }

        [Setting,ReadOnly(false)]
        [DefaultValue(true)]
        [Category("队伍治疗/支援")]
        [DisplayName("允许DPS紧急治疗")]
        [Description("DPS will off-heal if health below Begin %.  Will leave off-heal mode if healer in range and group above End % health (never in raids)")]
        public bool DpsOffHealAllowed { get; set; }

        [Setting,ReadOnly(false)]
        [DefaultValue(95)]
        [Category("队伍治疗/支援")]
        [DisplayName("忽略的治疗目标血量百分比")]
        [Description("治疗目标血量百分比高于该值时忽略治疗,即使正在施法也会打断读条停止治疗.")]
        public int IgnoreHealTargetsAboveHealth { get; set; }

        [Setting,ReadOnly(false)]
        [DefaultValue(75)]
        [Category("队伍治疗/支援")]
        [DisplayName("治疗目标最大距离")]
        [Description("进行治疗目标的最大距离(最大值: 100)")]
        public int MaxHealTargetRange { get; set; }

        [Setting,ReadOnly(false)]
        [DefaultValue(25)]
        [Category("队伍治疗/支援")]
        [DisplayName("靠近坦克 - 战斗范围")]
        [Description("Max combat distance from Tank before we move towards it (max value: 100)")]
        public int StayNearTankRangeCombat { get; set; }

        [Setting,ReadOnly(false)]
        [DefaultValue(15)]
        [Category("队伍治疗/支援")]
        [DisplayName("靠近坦克 - 非战斗")]
        [Description("Max combat distance from Tank before we move towards it (max value: 100)")]
        public int StayNearTankRangeRest { get; set; }

        [Setting,ReadOnly(false)]
        [DefaultValue(true)]
        [Category("队伍治疗/支援")]
        [DisplayName("保持在坦克附近")]
        [Description("如果没人需要治疗则始终保持在能治疗到坦克的范围内移动")]
        public bool StayNearTank { get; set; }

        [Setting,ReadOnly(false)]
        [DefaultValue(true)]
        [Category("队伍治疗/支援")]
        [DisplayName("治疗他人宠物")]
        [Description("True: 对他人宠物进行治疗(禁用该项不会影响治疗自己的宠物)")]
        public bool IncludePetsAsHealTargets { get; set; }

        [Setting,ReadOnly(false)]
        [DefaultValue(true)]
        [Category("队伍治疗/支援")]
        [DisplayName("包含召唤的NPC作为治疗对象")]
        [Description("True: Include Escorts and Summoned Companions as Healing targets")]
        public bool IncludeCompanionssAsHealTargets { get; set; }

        [Setting,ReadOnly(false)]
        [DefaultValue(RelativePriority.LowPriority)]
        [Category("队伍治疗/支援")]
        [DisplayName("驱散")]
        [Description("驱散有害状态.None:不驱散,LowPriority:低优先级,HighPriority:高优先级")]
        public RelativePriority DispelDebuffs { get; set; }

        [Setting, ReadOnly(false)]
        [DefaultValue(CombatRezTarget.Healer)]
        [Category("队伍治疗/支援")]
        [DisplayName("战复小队同伴")]
        [Description("None: disable Combat Rez; other setting limits rez to target with that role set")]
        public CombatRezTarget CombatRezTargetParty { get; set; }

        [Setting, ReadOnly(false)]
        [DefaultValue(CombatRezTarget.Tank)]
        [Category("队伍治疗/支援")]
        [DisplayName("战复团队同伴")]
        [Description("None: disable Combat Rez; other setting limits rez to target with that role set")]
        public CombatRezTarget CombatRezTargetRaid { get; set; }

        [Setting, ReadOnly(false)]
        [DefaultValue(2)]
        [Category("队伍治疗/支援")]
        [DisplayName("战复延迟")]
        [Description("等待(秒)再对队友进行战复")]
        public int CombatRezDelay { get; set; }

        [Setting,ReadOnly(false)]
        [DefaultValue(true)]
        [Category("队伍治疗/支援")]
        [DisplayName("允许治疗DPS输出")]
        [Description("Allow Healer to DPS. Does not affect Atonement/Telluric Currents/Dream of Cenarius/etc casts.  Forced to false in Raids")]
        public bool HealerCombatAllow { get; set; }

        [Setting,ReadOnly(false)]
        [DefaultValue(75)]
        [Category("队伍治疗/支援")]
        [DisplayName("治疗DPS输出最小法力 %")]
        [Description("Healer will DPS if Healer Mana % is above this")]
        public int HealerCombatMinMana { get; set; }

        [Setting,ReadOnly(false)]
        [DefaultValue(85)]
        [Category("队伍治疗/支援")]
        [DisplayName("治疗DPS输出最小血量 %")]
        [Description("Healer will DPS if Lowest Health % in group is above this")]
        public int HealerCombatMinHealth { get; set; }


        #endregion

        #region Category: Group - Use Items

        [Setting, ReadOnly(false)]
        [DefaultValue(true)]
        [Category("队伍：使用物品")]
        [DisplayName("治疗珠：使用")]
        [Description("True: allow moving to spheres for Health/Chi")]
        public bool MoveToSpheres { get; set; }

        [Setting, ReadOnly(false)]
        [DefaultValue(15)]
        [Category("队伍：使用物品")]
        [DisplayName("治疗珠: 休息时最大范围")]
        [Description("Max distance willing to move when resting")]
        public int SphereDistanceAtRest { get; set; }

        [Setting, ReadOnly(false)]
        [DefaultValue(7)]
        [Category("队伍：使用物品")]
        [DisplayName("治疗珠: 战斗时最大范围")]
        [Description("Max distance willing to move during combat")]
        public int SphereDistanceInCombat { get; set; }

        [Setting, ReadOnly(false)]
        [DefaultValue(85)]
        [Category("队伍：使用物品")]
        [DisplayName("治疗珠: 休息时血量 %")]
        [Description("Health % to cause move to healing spheres at rest")]
        public int SphereHealthPercentAtRest { get; set; }

        [Setting, ReadOnly(false)]
        [DefaultValue(60)]
        [Category("队伍：使用物品")]
        [DisplayName("治疗珠: 战斗时血量 %")]
        [Description("Health % to cause move to healing spheres during combat")]
        public int SphereHealthPercentInCombat { get; set; }

        [Setting, ReadOnly(false)]
        [DefaultValue(true)]
        [Category("队伍：使用物品")]
        [DisplayName("灵魂井: 使用")]
        [Description("Use any nearby Soulwell from your group when out of Healthstones")]
        public bool UseSoulwell { get; set; }

        [Setting, ReadOnly(false)]
        [DefaultValue(40)]
        [Category("队伍：使用物品")]
        [DisplayName("灵魂井: 最大范围")]
        [Description("Max distance willing to move when resting")]
        public int SoulwellDistance { get; set; }

        [Setting, ReadOnly(false)]
        [DefaultValue(true)]
        [Category("队伍：使用物品")]
        [DisplayName("餐桌: 使用")]
        [Description("Use any nearby Refreshment Table from your group when out of Healthstones")]
        public bool UseTable { get; set; }

        [Setting, ReadOnly(false)]
        [DefaultValue(40)]
        [Category("队伍：使用物品")]
        [DisplayName("餐桌: 最大范围")]
        [Description("Max distance willing to move when to Refreshment Table")]
        public int TableDistance { get; set; }

        #endregion

        #region Category: Healing

        #endregion

        #region Category: Items

        [Setting,ReadOnly(true)]
        [DefaultValue(true)]
        [Category("物品")]
        [DisplayName("使用炼金合剂")]
        [Description("使用炼金合剂")]
        public bool UseAlchemyFlasks { get; set; }

        [Setting,ReadOnly(false)]
        [DefaultValue(false)]
        [Category("物品")]
        [DisplayName("Use Scrolls of ...")]
        [Description("Uses Scrolls present in bags that temporarily buff a useful stat. Uses those buffing primary stat first, then Scrolls of Stamina")]
        public bool UseScrolls { get; set; }

        [Setting,ReadOnly(false)]
        [DefaultValue(TrinketUsage.Never)]
        [Category("物品")]
        [DisplayName("使用饰品 1")]
        public TrinketUsage Trinket1Usage { get; set; }

        [Setting, ReadOnly(false)]
        [DefaultValue(TrinketUsage.Never)]
        [Category("物品")]
        [DisplayName("使用饰品 2")]
        public TrinketUsage Trinket2Usage { get; set; }

        [Setting, ReadOnly(false)]
        [DefaultValue(true)]
        [Category("Items")]
        [DisplayName("Toys: Allow Use")]
        [Description("Uses Thunderlord Grapple")]
        public bool ToysAllowUse { get; set; }

        #endregion

        #region Category: Racials

        [Setting,ReadOnly(false)]
        [DefaultValue(true)]
        [Category("种族技能")]
        [DisplayName("使用种族技能")]
        public bool UseRacials { get; set; }

        [Setting,ReadOnly(false)]
        [DefaultValue(30)]
        [Category("种族技能")]
        [DisplayName("使用纳鲁的祝福血量百分比")]
        [Description("血量低于该百分比时使用纳鲁的祝福。")]
        public int GiftNaaruHP { get; set; }

        [Setting, ReadOnly(false)]
        [DefaultValue(0)]
        [Category("Racials")]
        [DisplayName("Shadowmeld: Solo Health %")]
        [Description("Solo Only: 0 = disable Shadowmeld, else cast if health % falls below this value")]
        public int ShadowmeldSoloHealthPct { get; set; }

        [Setting, ReadOnly(false)]
        [DefaultValue(true)]
        [Category("种族技能")]
        [DisplayName("隐遁清仇恨")]
        [Description("当在队伍中且不是坦克时使用隐遁清仇恨")]
        public bool ShadowmeldThreatDrop { get; set; }

        #endregion

        #region Category: Tanking

        [Setting,ReadOnly(false)]
        [DefaultValue(false)]
        [Category("坦克")]
        [DisplayName("禁用目标切换")]
        [Description("True:坦克时保持当前目标.  False: 切换目时标保持仇恨在队友是最高的")]
        public bool DisableTankTargetSwitching { get; set; }

        [Setting,ReadOnly(false)]
        [DefaultValue(true)]
        [Category("坦克")]
        [DisplayName("允许嘲讽技能")]
        public bool EnableTaunting { get; set; }

        #endregion

        #region Category: Targeting

        [Setting,ReadOnly(false)]
        [DefaultValue(TargetingStyle.Auto)]
        [Category("选怪")]
        [DisplayName("使用Singular选怪")]
        [Description("None: 禁用, Enable: 智能切换; Auto: 地下城模式/其他手动辅助模式下禁用,否则智能切换")]
        public TargetingStyle TypeOfTargeting { get; set; }

        [Setting,ReadOnly(false)]
        [DefaultValue(true)]
        [Category("Targeting")]
        [DisplayName("PVP时忽略目标")]
        [Description("Solo Only.  True: when attacked by player, ignore everything else and fight back;  False: attack based upon Targeting priority list.")]
        public bool TargetWorldPvpRegardless { get; set; }

        #endregion

        #region Category: Enemy Control

        private PullMoreUsageType _PullMoreAllowed = PullMoreUsageType.Auto;

        [DefaultValue(8)]
        [Category("Enemy Control")]
        [DisplayName("Evade Attacks Allowed")]
        [Description("# of Evaded attacks allowed before mob is blacklisted as Evade Bugged")]
        public int EvadedAttacksAllowed { get; set; }

        [Setting, ReadOnly(false)]
        [DefaultValue(PullMoreUsageType.Auto)]
        [Category("敌对控制 - 拉更多怪")]
        [DisplayName("允许拉更多怪")]
        [Description("Auto: enable the feature only with Questing and Grind Bot; Enable: pull adds based upon settings; None: disable pull more feature")]
        public PullMoreUsageType UsePullMore
        {
            get
            {
                return _PullMoreAllowed;
            }

            set
            {
                _PullMoreAllowed = value;
                SetPropertyReadOnly("PullMoreTargetType", _PullMoreAllowed == PullMoreUsageType.None);
                SetPropertyReadOnly("PullMoreMobCount", _PullMoreAllowed == PullMoreUsageType.None);
                SetPropertyReadOnly("PullMoreDistMelee", _PullMoreAllowed == PullMoreUsageType.None);
                SetPropertyReadOnly("PullMoreDistRanged", _PullMoreAllowed == PullMoreUsageType.None);
                SetPropertyReadOnly("PullMoreMinHealth", _PullMoreAllowed == PullMoreUsageType.None);
                SetPropertyReadOnly("PullMoreTimeOut", _PullMoreAllowed == PullMoreUsageType.None);
                SetPropertyReadOnly("PullMoreMaxTime", _PullMoreAllowed == PullMoreUsageType.None);
            }
        }

        [Setting,ReadOnly(false)]
        
        [DefaultValue(PullMoreTargetType.LikeCurrent)]
        [Category("敌对控制 - 拉更多怪")]
        [DisplayName("拉怪的类型")]
        [Description("None: disabled, Current: like CurrentTarget; Hostile: any hostile target; Any: any nearby valid target")]
        public PullMoreTargetType PullMoreTargetType { get; set; }

        [Setting,ReadOnly(false)]
        
        [DefaultValue(3)]
        [Category("敌对控制 - 拉更多怪")]
        [DisplayName("拉怪的数量")]
        [Description("Pull more until in combat with this many, then finish them off before acquiring more")]
        public int PullMoreMobCount { get; set; }

        [Setting,ReadOnly(false)]
        
        [DefaultValue(35)]
        [Category("敌对控制 - 拉更多怪")]
        [DisplayName("拉群怪的距离")]
        [Description("For Melee Characters: Maximum distance of adds which will be pulled")]
        public int PullMoreDistMelee { get; set; }

        [Setting,ReadOnly(false)]
        
        [DefaultValue(55)]
        [Category("敌对控制 - 拉更多怪")]
        [DisplayName("拉远程怪的距离")]
        [Description("For Ranged Characters: Maximum distance of adds which will be pulled")]
        public int PullMoreDistRanged { get; set; }

        [Setting,ReadOnly(false)]
        
        [DefaultValue(60)]
        [Category("敌对控制 - 拉更多怪")]
        [DisplayName("拉怪的血量 %")]
        [Description("Pull more unless Health % below this")]
        public int PullMoreMinHealth { get; set; }

        [Setting,ReadOnly(false)]
        
        [DefaultValue(12)]
        [Category("敌对控制 - 拉更多怪")]
        [DisplayName("拉怪超时标记（秒）")]
        [Description("Pull more will timeout an individual pull if not tagged by this many seconds")]
        public int PullMoreTimeOut { get; set; }

        [Setting, ReadOnly(false)]

        [DefaultValue(45)]
        [Category("敌对控制 - 拉更多怪")]
        [DisplayName("拉怪最长时间（秒）")]
        [Description("Pull more for this duration, then suppress Pull More behavior until no longer in combat")]
        public int PullMoreMaxTime { get; set; }

        [Setting, ReadOnly(false), Browsable(false)]
        [DefaultValue(false)]
        public bool PullMoreSpecDefaultsSaved { get; set; }

        #endregion

        #region Category: Enemy Control

        [Setting, ReadOnly(false)]
        [DefaultValue(true)]
        [Category("Enemy Control")]
        [DisplayName("Rest: Fight if Attacked")]
        [Description("True: fight if attacked even if BotBase does not, False: leave decision to fight to BotBase")]
        public bool RestCombatAllowed { get; set; }

        [Setting, ReadOnly(false)]
        [DefaultValue(CheckTargets.Current)]
        [Category("敌对控制")]
        [DisplayName("净化目标")]
        [Description("None: 禁用, Current: 仅作用于目标, All: 范围内面向的所有敌人")]
        public CheckTargets PurgeTargets { get; set; }

        [Setting,ReadOnly(false)]
        [DefaultValue(PurgeAuraFilter.Whitelist)]
        [Category("敌对控制")]
        [DisplayName("净化增益状态")]
        [Description("None: 禁用, Current: 仅作用于目标, All: 范围内面向的所有敌人")]
        public PurgeAuraFilter PurgeBuffs { get; set; }

        [Setting,ReadOnly(false)]
        [DefaultValue(CheckTargets.All)]
        [Category("敌对控制")]
        [DisplayName("打断目标")]
        [Description("None: 禁用, Current: 仅作用于目标, All: 范围内面向的所有敌人")]
        public CheckTargets InterruptTarget { get; set; }

        [Setting, ReadOnly(false)]
        [DefaultValue(50)]
        [Category("敌对控制")]
        [DisplayName("忽略怪物最大血量比你血量少的百分比")]
        [Description("怪物的血量百分比比你血量少于这个百分比时忽略怪物")]
        public int TrivialMaxHealthPcnt { get; set; }

#if SERIOUS_SUPPORT_IMPLEMENTED
        [Setting, ReadOnly(false)]
        [DefaultValue(200)]
        [Category("Enemy Control")]
        [DisplayName("Serious: Mob Min Health %")]
        [Description("Mob with Max Health more than % of your Max Health considered Serious")]
        public int SeriousMinHealthPct { get; set; }

        [Setting, ReadOnly(false)]
        [DefaultValue(3)]
        [Category("Enemy Control")]
        [DisplayName("Serious: Mob Levels Above")]
        [Description("Mob this many levels above treated as an Elite")]
        public int SeriousMobLevelsAboveAsElite { get; set; }

        [Setting, ReadOnly(false)]
        [DefaultValue(50)]
        [Category("Enemy Control")]
        [DisplayName("Serious: Mob Count")]
        [Description("Fight with this many mobs (or more) non-trivial mobs will enable use of cooldowns saved for Serious Fights")]
        public int SeriousMobCount { get; set; }

        [Setting, ReadOnly(false)]
        [DefaultValue(60)]
        [Category("General")]
        [DisplayName("Serious: Save Cooldowns (secs)")]
        [Description("Prevent Singular from casting any spell with a this cooldown or greater unless in a Serious fight; set to 0 to allow Singular to cast all spells")]
        public int SeriousSaveCooldowns { get; set; }
#endif

        [Setting, ReadOnly(false)]
        [DefaultValue(true)]
        [Category("敌对控制")]
        [DisplayName("使用AOE技能")]
        [Description("True: 需要时使用群攻伤害技能; False: 仅对当前目标使用单体技能")]
        public bool AllowAOE { get; set; }

        #endregion

        #region Class Late-Loading Wrappers

        // Do not change anything within this region.
        // It's written so we ONLY load the settings we're going to use.
        // There's no reason to load the settings for every class, if we're only executing code for a Druid.

        private DeathKnightSettings _dkSettings;

        private DruidSettings _druidSettings;

        private HunterSettings _hunterSettings;

        private MageSettings _mageSettings;
		
		private MonkSettings _monkSettings;
		
        private PaladinSettings _pallySettings;

        private PriestSettings _priestSettings;

        private RogueSettings _rogueSettings;

        private ShamanSettings _shamanSettings;

        private WarlockSettings _warlockSettings;

        private WarriorSettings _warriorSettings;

        private HotkeySettings _hotkeySettings;

        // late-binding interfaces 
        // -- changed from readonly properties to methods as GetProperties() in SaveToXML() was causing all classes configs to load
        // -- this was causing Save to write a DeathKnight.xml file for all non-DKs for example
        internal DeathKnightSettings DeathKnight() { return _dkSettings ?? (_dkSettings = new DeathKnightSettings()); } 
        internal DruidSettings Druid() { return _druidSettings ?? (_druidSettings = new DruidSettings()); }
        internal HunterSettings Hunter() { return _hunterSettings ?? (_hunterSettings = new HunterSettings()); }
        internal MageSettings Mage() { return _mageSettings ?? (_mageSettings = new MageSettings()); }
        internal MonkSettings Monk() { return _monkSettings ?? (_monkSettings = new MonkSettings()); }
        internal PaladinSettings Paladin() { return _pallySettings ?? (_pallySettings = new PaladinSettings()); }
        internal PriestSettings Priest() { return _priestSettings ?? (_priestSettings = new PriestSettings()); }
        internal RogueSettings Rogue() { return _rogueSettings ?? (_rogueSettings = new RogueSettings()); }
        internal ShamanSettings Shaman() { return _shamanSettings ?? (_shamanSettings = new ShamanSettings()); }
        internal WarlockSettings Warlock() { return _warlockSettings ?? (_warlockSettings = new WarlockSettings()); }
        internal WarriorSettings Warrior() { return _warriorSettings ?? (_warriorSettings = new WarriorSettings()); }
        internal HotkeySettings Hotkeys() { return _hotkeySettings ?? (_hotkeySettings = new HotkeySettings()); }

        #endregion

        class Validate 
        {
            public static int IntValue( string name, int minValue, int maxValue, int setting)
            {
                if (!setting.Between( minValue, maxValue))
                {
                    int newValue = setting;
                    newValue = Math.Max( minValue, newValue);
                    newValue = Math.Min( maxValue, newValue);
                    Logger.Write(Color.Yellow, "warning: Singular setting '{0}' value of {1} out of range, changing to {2}", name, setting, newValue);
                    setting = newValue;
                }

                return setting;
            }
        }
    }

}
