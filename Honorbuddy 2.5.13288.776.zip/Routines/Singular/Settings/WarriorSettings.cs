﻿
using System.ComponentModel;
using System.IO;
using Styx.Helpers;

using DefaultValue = Styx.Helpers.DefaultValueAttribute;

namespace Singular.Settings
{
    public enum WarriorStance
    {
        Auto,
        BattleStance        = Styx.ShapeshiftForm.BattleStance ,
        DefensiveStance     = Styx.ShapeshiftForm.DefensiveStance,
        GladiatorStance     = 33
    }

    public enum WarriorShout
    {
        CommandingShout,
        BattleShout
    }

    internal class WarriorSettings : Styx.Helpers.Settings
    {
        public WarriorSettings()
            : base(Path.Combine(SingularSettings.SingularSettingsPath, "Warrior.xml"))
        {
        }

        public enum SpellPriority
        {
            Noxxic = 1,
            IcyVeins = 2,
            ElitistJerks = 3
        }
#if MULTIPLE_SUPPORTED
        [Setting]
        [DefaultValue(SpellPriority.Noxxic)]
        [Category("武器")]
        [DisplayName("法术优先选择")]
        public SpellPriority ArmsSpellPriority { get; set; }
#endif
        #region Protection

        [Setting]
        [DefaultValue(30)]
        [Category("防护")]
        [DisplayName("盾墙血量百分比")]
        [Description("血量低于该百分比时使用盾墙")]
        public int WarriorShieldWallHealth { get; set; }


        [Setting]
        [DefaultValue(20)]
        [Category("防护")]
        [DisplayName("破釜沉舟血量百分比")]
        [Description("血量低于该百分比时使用破釜沉舟")]
        public int WarriorLastStandHealth  { get; set; }

        [Setting]
        [DefaultValue(50)]
        [Category("防护")]
        [DisplayName("盾牌格挡血量百分比")]
        [Description("血量低于该百分比时使用盾牌格挡")]
        public int WarriorShieldBlockHealth { get; set; }

        [Setting]
        [DefaultValue(80)]
        [Category("防护")]
        [DisplayName("盾牌屏障血量百分比")]
        [Description("血量低于该百分比时使用盾牌屏障")]
        public int WarriorShieldBarrierHealth { get; set; }

        #endregion

        #region DPS

        [Setting]
        [DefaultValue(50)]
        [Category("防护")]
        [DisplayName("狂怒回复血量百分比")]
        [Description("血量低于该百分比时使用狂怒回复")]
        public int WarriorEnragedRegenerationHealth { get; set; }

        [Setting]
        [DefaultValue(true)]
        [Category("输出")]
        [DisplayName("使用打断")]
        [Description("True / False：设置是否让战斗模块进行施法打断")]
        public bool UseWarriorInterrupts { get; set; }

        [Setting]
        [DefaultValue(true)]
        [Category("输出")]
        [DisplayName("减速")]
        [Description("True / False：设置是否让战斗模块施放减速技能.如:断筋,刺耳怒吼")]
        public bool UseWarriorSlows { get; set; }
        
        [Setting]
        [DefaultValue(WarriorStance.Auto)]
        [Category("DPS")]
        [DisplayName("Warrior DPS Stance")]
        [Description("The stance to use while DPSing. Battle stance if there is little incoming damage. Protection will always use Defensive stance.")]
        public WarriorStance StanceSelected { get; set; }

        #endregion

        [Setting]
        [DefaultValue(true)]
        [Category("输出")]
        [DisplayName("使用冲锋/英勇飞跃?")]
        [Description("True / False：设置是否让战斗模块使用这些快速接近目标的技能")]
        public bool UseWarriorCloser { get; set; }

        [Setting]
        [DefaultValue(WarriorShout.BattleShout)]
        [Category("常规")]
        [DisplayName("战士怒吼")]
        [Description("怒吼用于保持身上的增益状态,或者在低怒气的情况下使用.CommandingShout:命令怒吼;BattleShout:战斗怒吼")]
        public WarriorShout Shout { get; set; }

        [Setting]
        [DefaultValue(false)]
        [Category("常规")]
        [DisplayName("乘胜追击")]
        [Description("True: 无视血量百分比,只要乘胜追击/胜利在望冷却一到就用")]
        public bool VictoryRushOnCooldown { get; set; }

        [Setting]
        [DefaultValue(50)]
        [Category("Defensive")]
        [DisplayName("Die by the Sword %")]
        [Description("Health % to cast this ability")]
        public int DieByTheSwordHealth { get; set; }

        [Setting]
        [DefaultValue(50)]
        [Category("Defensive")]
        [DisplayName("Vigilance %")]
        [Description("Health % to cast this ability")]
        public int VigilanceHealth { get; set; }

    }
}
