﻿
using System.ComponentModel;
using System.IO;
using Styx.Helpers;
using Styx.WoWInternals.WoWObjects;

using DefaultValue = Styx.Helpers.DefaultValueAttribute;
using Styx;
using System.Drawing;
using System;

namespace Singular.Settings
{
    internal class ShamanSettings : Styx.Helpers.Settings
    {
        public ShamanSettings()
            : base(Path.Combine(SingularSettings.SingularSettingsPath, "Shaman.xml"))
        {
        }

        #region Context Late Loading Wrappers

        private ShamanRestoHealSettings _restobattleground;
        private ShamanRestoHealSettings _restoinstance;
        private ShamanRestoHealSettings _restoraid;
        private ShamanOffHealSettings _offhealbattleground;
        private ShamanOffHealSettings _offhealpve;

        [Browsable(false)]
        public ShamanRestoHealSettings RestoBattleground { get { return _restobattleground ?? (_restobattleground = new ShamanRestoHealSettings(HealingContext.Battlegrounds)); } }

        [Browsable(false)]
        public ShamanRestoHealSettings RestoInstance { get { return _restoinstance ?? (_restoinstance = new ShamanRestoHealSettings(HealingContext.Instances)); } }

        [Browsable(false)]
        public ShamanRestoHealSettings RestoRaid { get { return _restoraid ?? (_restoraid = new ShamanRestoHealSettings(HealingContext.Raids)); } }

        [Browsable(false)]
        public ShamanOffHealSettings OffhealBattleground { get { return _offhealbattleground ?? (_offhealbattleground = new ShamanOffHealSettings(HealingContext.Battlegrounds)); } }

        [Browsable(false)]
        public ShamanOffHealSettings OffhealPVE { get { return _offhealpve ?? (_offhealpve = new ShamanOffHealSettings(HealingContext.Instances)); } }

        [Browsable(false)]
        public ShamanRestoHealSettings RestoHealSettings { get { return RestoHealSettingsLookup(Singular.SingularRoutine.CurrentWoWContext); } }

        public ShamanRestoHealSettings RestoHealSettingsLookup(WoWContext ctx)
        {
            if (ctx == WoWContext.Instances)
                return StyxWoW.Me.GroupInfo.IsInRaid ? RestoRaid : RestoInstance;

            if (ctx == WoWContext.Battlegrounds)
                return RestoBattleground;

            return RestoInstance;
        }

        [Browsable(false)]
        public ShamanOffHealSettings OffHealSettings { get { return OffHealSettingsLookup(Singular.SingularRoutine.CurrentWoWContext); } }

        public ShamanOffHealSettings OffHealSettingsLookup(WoWContext ctx)
        {
            if (ctx == WoWContext.Battlegrounds)
                return OffhealBattleground;

            return OffhealPVE;
        }

        #endregion


        #region Category: Common

        [Setting]
        [DefaultValue(true)]
        [Category("常规")]
        [DisplayName("使用幽魂之狼")]
        [Description("跑步或者室内时使用幽魂之狼移动")]
        public bool UseGhostWolf { get; set; }

        [Setting]
        [DefaultValue(false)]
        [Category("常规")]
        [DisplayName("使用嗜血/英勇")]
        [Description("适当的时间使用(禁用移动控制后会自动禁用该功能)")]
        public bool UseBloodlust { get; set; }

        [Setting]
        [DefaultValue(true)]
        [Category("常规")]
        [DisplayName("使用武器附魔")]
        [Description("True:自动选择并施放附魔, False:防止自动施放武器附魔")]
        public bool UseAscendance { get; set; }

        [Setting]
        [DefaultValue(15)]
        [Category("常规")]
        [DisplayName("使用水之护盾法力百分比")]
        [Description("当法力低于该百分比时切换水盾")]
        public int TwistWaterShield { get; set; }


        private int _TwistDamageShield;

        [Setting]
        [DefaultValue(25)]
        [Category("常规")]
        [DisplayName("切换闪电/大地盾法力百分比")]
        [Description("当法力高于该百分比时切换闪电之盾(DPS)或者大地之盾(恢复).提示:至少比切换水之护盾百分比高10%。")]
        public int TwistDamageShield 
        { 
            get { return Math.Max( _TwistDamageShield, TwistWaterShield + 10); }
            set { _TwistDamageShield = value; }
        }

        #endregion

        #region Category: Enhancement
        [Setting]
        [DefaultValue(CastOn.All)]
        [Category("增强")]
        [DisplayName("野性狼魂")]
        [Description("选择在何种类型战斗下使用野性狼魂")]
        public CastOn FeralSpiritCastOn  { get; set; }

        [Setting]
        [DefaultValue(75)]
        [Category("增强")]
        [DisplayName("治疗之涌(触发漩涡瞬发)")]
        [Description("血量低于该百分比时使用该技能.设置为100一冷却就用,设置为0禁用.")]
        public int MaelHealingSurge { get; set; }

        [Setting]
        [DefaultValue(false)]
        [Category("增强")]
        [DisplayName("禁用漩涡输出")]
        [Description("禁用闪电箭,闪电链以及妖术")]
        public bool AvoidMaelstromDamage { get; set; }

        [Setting]
        [DefaultValue(35)]
        [Category("增强")]
        [DisplayName("PVP时使用漩涡辅助治疗")]
        [Description("血量低于该百分比时使用该技能.设置为100一冷却就用,设置为0禁用.")]
        public int MaelPvpOffHeal { get; set; }

        #endregion

        #region Category: Self-Healing

        [Setting]
        [DefaultValue(85)]
        [Category("治疗自己")]
        [DisplayName("治疗之泉图腾血量百分比")]
        [Description("血量低于该百分比时使用该技能.设置为100一冷却就用,设置为0禁用.")]
        public int SelfHealingStreamTotem { get; set; }

        [Setting]
        [DefaultValue(40)]
        [Category("治疗自己")]
        [DisplayName("治疗之涌血量百分比")]
        [Description("血量低于该百分比时使用该技能.设置为100一冷却就用,设置为0禁用.")]
        public int SelfHealingSurge { get; set; }

        [Setting]
        [DefaultValue(65)]
        [Category("治疗自己")]
        [DisplayName("先祖指引血量百分比")]
        [Description("血量低于该百分比时使用该技能.设置为100一冷却就用,设置为0禁用.")]
        public int SelfAncestralGuidance { get; set; }

        [Setting]
        [DefaultValue(25)]
        [Category("治疗自己")]
        [DisplayName("先祖迅捷血量百分比")]
        [Description("血量低于该百分比时使用该技能.设置为100一冷却就用,设置为0禁用.")]
        public int SelfAncestralSwiftnessHeal { get; set; }

        #endregion

        #region Category: Totems

        [Setting]
        [DefaultValue(80)]
        [Category("图腾")]
        [DisplayName("法力之潮图腾法力百分比")]
        [Description("法力低于该百分比时使用法力之潮图腾.设置为 0 禁用.")]
        public int ManaTideTotemPercent { get; set; }

        #endregion

        #region Talents

        [Setting]
        [DefaultValue(47)]
        [Category("天赋")]
        [DisplayName("星界转移血量百分比")]
        [Description("血量低于该百分比时使用星界转移。设置为 0 禁用。")]
        public int AstralShiftPercent { get; set; }

        [Setting]
        [DefaultValue(47)]
        [Category("天赋")]
        [DisplayName("治疗之潮图腾血量百分比")]
        [Description("血量低于该百分比时使用治疗之潮图腾。设置为 0 禁用。")]
        public int HealingTideTotemPercent { get; set; }

        [Setting]
        [DefaultValue(47)]
        [Category("天赋")]
        [DisplayName("石壁图腾血量百分比")]
        [Description("血量低于该百分比时使用石壁图腾。设置为 0 禁用.")]
        public int StoneBulwarkTotemPercent { get; set; }

        #endregion
    }

    internal class ShamanRestoHealSettings : Singular.Settings.HealerSettings
    {
        private ShamanRestoHealSettings()
            : base("", HealingContext.None)
        {
        }

        public ShamanRestoHealSettings(HealingContext ctx)
            : base("ShamanResto", ctx)
        {

            // we haven't created a settings file yet,
            //  ..  so initialize values for various heal contexts

            if (!SavedToFile)
            {
                if (ctx == Singular.HealingContext.Battlegrounds)
                {
                    ChainHeal = 90;
                    HealingRain = 93;
                    HealingWave = 0;
                    Ascendance = 49;
                    SpiritLinkTotem = 50;
                    HealingSurge = 85;
                    AncestralSwiftness = 35;
                    HealingStreamTotem = 90;
                    HealingTideTotem = 55;

                    RollRiptideCount = 0;
                    MinHealingRainCount = 4;
                    MinChainHealCount = 3;
                    MinHealingTideCount = 2;
                }
                else if (ctx == Singular.HealingContext.Instances)
                {
                    ChainHeal = 92;
                    HealingRain = 91;
                    HealingWave = 90;
                    Ascendance = 50;
                    SpiritLinkTotem = 49;
                    HealingSurge = 70;
                    AncestralSwiftness = 30;
                    HealingStreamTotem = 90;
                    HealingTideTotem = 65;

                    RollRiptideCount = 1;
                    MinHealingRainCount = 2;
                    MinChainHealCount = 3;
                    MinHealingTideCount = 2;
                }
                else if (ctx == Singular.HealingContext.Raids)
                {
                    ChainHeal = 90;
                    HealingRain = 95;
                    HealingWave = 50;
                    Ascendance = 50;
                    SpiritLinkTotem = 48;
                    HealingSurge = 21;
                    AncestralSwiftness = 20;
                    HealingStreamTotem = 85;
                    HealingTideTotem = 70;

                    RollRiptideCount = 5;
                    MinHealingRainCount = 3;
                    MinChainHealCount = 2;
                    MinHealingTideCount = 4;
                }
                // omit case for WoWContext.Normal and let it use DefaultValue() values
            }

            // adjust Healing Surge if we have not previously 
            if (!HealingSurgeAdjusted && StyxWoW.Me.Level >= 60 && (ctx == HealingContext.Instances || ctx == HealingContext.Raids))
            {
                if (SavedToFile)
                    Logger.Write( LogColor.Hilite, "Healing Surge % changed from {0} to {1} for {2}.  Visit Class Config and Save to make permanent.", HealingSurge, AncestralSwiftness + 1, ctx.ToString());

                HealingSurge = AncestralSwiftness + 1;
                HealingSurgeAdjusted = true;
            }

            SavedToFile = true;
        }

        [Setting]
        [Browsable(false)]
        [DefaultValue(false)]
        public bool SavedToFile { get; set; }

        [Setting]
        [Browsable(false)]
        [DefaultValue(false)]
        public bool HealingSurgeAdjusted { get; set; }

        [Setting]
        [DefaultValue(92)]
        [Category("恢复")]
        [DisplayName("% 治疗链")]
        [Description("血量低于该百分比时使用该技能.小队时最少2人,团队时最少3人需要治疗.设置为0禁用.")]
        public int ChainHeal { get; set; }

        [Setting]
        [DefaultValue(91)]
        [Category("恢复")]
        [DisplayName("% 治疗之雨")]
        [Description("血量低于该百分比时使用该技能.小队时最少3人,团队时最少4人需要治疗.设置为0禁用.")]
        public int HealingRain { get; set; }

        [Setting]
        [DefaultValue(60)]
        [Category("恢复")]
        [DisplayName("% 治疗波")]
        [Description("血量低于该百分比时使用该技能.设置为0禁用.")]
        public int HealingWave { get; set; }

        [Setting]
        [DefaultValue(45)]
        [Category("恢复")]
        [DisplayName("% 升腾")]
        [Description("血量低于该百分比时使用该技能.设置为0禁用.")]
        public int Ascendance { get; set; }

        [Setting]
        [DefaultValue(16)]
        [Category("恢复")]
        [DisplayName("% 治疗之涌")]
        [Description("血量低于该百分比时使用该技能.设置为0禁用.")]
        public int HealingSurge { get; set; }

        [Setting]
        [DefaultValue(15)]
        [Category("恢复")]
        [DisplayName("% 迅捷治疗+强效治疗波")]
        [Description("血量低于该百分比使用迅捷治疗!(自然迅捷+强效治疗波). 如果设置为0,冷却中,没选择该天赋时不使用.")]
        public int AncestralSwiftness { get; set; }

        [Setting]
        [DefaultValue(48)]
        [Category("恢复")]
        [DisplayName("% 灵魂连接图腾")]
        [Description("血量低于该百分比使用该技能. 仅在队伍中有效.设置为0禁用.")]
        public int SpiritLinkTotem { get; set; }

        [Setting]
        [DefaultValue(95)]
        [Category("恢复")]
        [DisplayName("% 治疗之泉图腾")]
        [Description("血量低于该百分比时使用该技能.设置为0禁用.")]
        public int HealingStreamTotem { get; set; }

        [Setting]
        [DefaultValue(70)]
        [Category("天赋")]
        [DisplayName("治疗之潮图腾 %")]
        [Description("血量低于该百分比时使用该技能.设置为0禁用.")]
        public int HealingTideTotem { get; set; }

        [Setting]
        [DefaultValue(4)]
        [Category("恢复")]
        [DisplayName("维持激流最大目标数")]
        [Description("维持激流的最大目标数(始终保持坦克身上的激流效果且坦克计算在该数量当中)")]
        public int RollRiptideCount { get; set; }

        [Setting]
        [DefaultValue(4)]
        [Category("恢复")]
        [DisplayName("治疗之雨队友数量")]
        [Description("范围内最少需要治疗的队友血量低于治疗之雨血量百分比的队友数目")]
        public int MinHealingRainCount { get; set; }

        [Setting]
        [DefaultValue(3)]
        [Category("恢复")]
        [DisplayName("治疗链队友数量")]
        [Description("最少需要治疗的队友数量")]
        public int MinChainHealCount { get; set; }

        [Setting]
        [DefaultValue(4)]
        [Category("恢复")]
        [DisplayName("治疗之潮图腾队友数量")]
        [Description("最少需要治疗的队友数量")]
        public int MinHealingTideCount { get; set; }

        [Setting]
        [DefaultValue(1)]
        [Category("恢复")]
        [DisplayName("灵魂链接图腾队友数量")]
        [Description("最少需要治疗的队友数量")]
        public int MinSpiritLinkCount { get; set; }

        [Setting]
        [DefaultValue(3)]
        [Category("恢复")]
        [DisplayName("升腾队友数量")]
        [Description("最少需要治疗的队友数量")]
        public int MinAscendanceCount { get; set; }

        [Setting]
        [DefaultValue(90)]
        [Category("恢复")]
        [DisplayName("施放魔流(闪电箭雕文)回蓝血量百分比")]
        [Description("当队伍血量高于该百分比时施放闪电箭来回蓝")]
        public int TelluricHealthCast { get; set; }

        [Setting]
        [DefaultValue(80)]
        [Category("恢复")]
        [DisplayName("取消施放魔流(闪电箭雕文)回蓝血量百分比")]
        [Description("当队伍血量低于该百分比时取消施放闪电箭来回蓝")]
        public int TelluricHealthCancel { get; set; }

    }

    internal class ShamanOffHealSettings : Singular.Settings.HealerSettings
    {
        private ShamanOffHealSettings()
            : base("", HealingContext.None)
        {
        }

        public ShamanOffHealSettings(HealingContext ctx)
            : base("ShamanOffheal", ctx)
        {

            // we haven't created a settings file yet,
            //  ..  so initialize values for various heal contexts

            if (!SavedToFile)
            {
                if (ctx == Singular.HealingContext.Battlegrounds)
                {
                    HealingRain = 93;
                    HealingSurge = 85;
                    AncestralSwiftness = 40;
                    HealingStreamTotem = 90;

                    MinHealingRainCount = 3;
                    MinHealingTideCount = 2;
                }
                else // use group/companion healing
                {
                    HealingRain = 93;
                    HealingSurge = 80;
                    AncestralSwiftness = 35;
                    HealingStreamTotem = 90;

                    MinHealingRainCount = 4;
                    MinHealingTideCount = 2;
                }
            }

            SavedToFile = true;
        }

        [Setting]
        [Browsable(false)]
        [DefaultValue(false)]
        public bool SavedToFile { get; set; }

        [Setting]
        [DefaultValue(91)]
        [Category("恢复")]
        [DisplayName("% 治疗之雨")]
        [Description("血量低于该百分比时使用该技能.小队时最少3人,团队时最少4人需要治疗.设置为0禁用.")]
        public int HealingRain { get; set; }

        [Setting]
        [DefaultValue(16)]
        [Category("恢复")]
        [DisplayName("% 治疗之涌")]
        [Description("血量低于该百分比时使用该技能.设置为0禁用.")]
        public int HealingSurge { get; set; }

        [Setting]
        [DefaultValue(15)]
        [Category("恢复")]
        [DisplayName("% 迅捷治疗+强效治疗波")]
        [Description("血量低于该百分比使用迅捷治疗!(自然迅捷+强效治疗波). 如果设置为0,冷却中,没选择该天赋时不使用.")]
        public int AncestralSwiftness { get; set; }

        [Setting]
        [DefaultValue(95)]
        [Category("恢复")]
        [DisplayName("% 治疗之泉图腾")]
        [Description("血量低于该百分比时使用该技能.设置为0禁用.")]
        public int HealingStreamTotem { get; set; }

        [Setting]
        [DefaultValue(4)]
        [Category("恢复")]
        [DisplayName("治疗之雨队友数量")]
        [Description("范围内最少需要治疗的队友血量低于治疗之雨血量百分比的队友数目")]
        public int MinHealingRainCount { get; set; }

        [Setting]
        [DefaultValue(4)]
        [Category("恢复")]
        [DisplayName("治疗之潮图腾队友数量")]
        [Description("最少需要治疗的队友数量")]
        public int MinHealingTideCount { get; set; }

    }

}
