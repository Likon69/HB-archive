﻿
using System;
using System.ComponentModel;
using System.IO;
using Singular.ClassSpecific.Paladin;

using Styx.Helpers;

using DefaultValue = Styx.Helpers.DefaultValueAttribute;
using Styx.CommonBot;
using Styx;

namespace Singular.Settings
{

    public enum PaladinBlessings
    {
        Auto,
        Kings,
        Might
    }

    public enum PaladinSeal
    {
        None = 0,
        Auto = 1,
        Command,
        Truth,
        Insight,
        Righteousness,
        Justice
    }

    internal class PaladinSettings : Styx.Helpers.Settings
    {
        public PaladinSettings()
            : base(Path.Combine(SingularSettings.SingularSettingsPath, "Paladin.xml"))
        {
        }


        #region Common
        /*
        [Setting]
        [DefaultValue(PaladinAura.Auto)]
        [Category("常规")]
        [DisplayName("光环")]
        [Description("The aura to be used while not mounted. Set this to Auto to allow the CC to automatically pick the aura depending on spec.")]
        public PaladinAura Aura { get; set; }
        */

        [Setting]
        [DefaultValue(90)]
        [Category("常规")]
        [DisplayName("圣光术血量百分比")]
        [Description("血量低于该百分比时使用圣光术")]
        public int HolyLightHealth { get; set; }

        [Setting]
        [DefaultValue(PaladinBlessings.Auto)]
        [Category("常规")]
        [DisplayName("祝福")]
        [Description("使用何种祝福(Auto: 最佳选项)")]
        public PaladinBlessings Blessings { get; set; }

        [Setting]
        [DefaultValue(PaladinSeal.Auto)]
        [Category("常规")]
        [DisplayName("圣印")]
        [Description("使用何种圣印(None: 玩家控制, Auto: 最佳选项)")]
        public PaladinSeal Seal { get; set; }

        [Setting]
        [DefaultValue(true)]
        [Category("常规")]
        [DisplayName("普通环境中使用制裁之锤")]
        [Description("在单人战斗中冷却一到立即使用制裁之锤晕怪以减少受到的伤害")]
        public bool StunMobsWhileSolo { get; set; }

        #endregion

        #region Self-Heal

        [Setting]
        [DefaultValue(25)]
        [Category("治疗自己")]
        [DisplayName("圣疗血量百分比")]
        [Description("血量低于该百分比时使用圣疗")]
        public int SelfLayOnHandsHealth { get; set; }

        [Setting]
        [DefaultValue(40)]
        [Category("治疗自己")]
        [DisplayName("圣光闪现血量百分比")]
        [Description("血量低于该百分比时使用圣光闪现")]
        public int SelfFlashOfLightHealth { get; set; }

        [Setting]
        [DefaultValue(0)]
        [Category("治疗自己")]
        [DisplayName("荣耀圣令血量百分比(1+圣能)")]
        [Description("仅有1格圣能时血量低于该百分比时使用荣耀圣令")]
        public int SelfWordOfGloryHealth1 { get; set; }

        [Setting]
        [DefaultValue(0)]
        [Category("治疗自己")]
        [DisplayName("荣耀圣令血量百分比(2+圣能)")]
        [Description("2+格圣能时血量低于该百分比时使用荣耀圣令")]
        public int SelfWordOfGloryHealth2 { get; set; }

        [Setting]
        [DefaultValue(65)]
        [Category("治疗自己")]
        [DisplayName("荣耀圣令血量百分比(3+圣能)")]
        [Description("3+格圣能时血量低于该百分比时使用荣耀圣令")]
        public int SelfWordOfGloryHealth3 { get; set; }

        [Setting]
        [DefaultValue(65)]
        [Category("治疗自己")]
        [DisplayName("永恒之火血量百分比")]
        [Description("血量低于该百分比时使用永恒之火当有3+格圣能时")]
        public int SelfEternalFlameHealth { get; set; }

        #endregion  

        #region Holy

        [Setting]
        [DefaultValue(25)]
        [Category("神圣")]
        [DisplayName("圣疗血量百分比")]
        [Description("血量低于该百分比时使用圣疗")]
        public int LayOnHandsHealth { get; set; }

        [Setting]
        [DefaultValue(50)]
        [Category("神圣")]
        [DisplayName("圣光闪现血量百分比")]
        [Description("血量低于该百分比时使用圣光闪现")]
        public int FlashOfLightHealth { get; set; }

        [Setting]
        [DefaultValue(true)]
        [Category("神圣")]
        [DisplayName("保持坦克的永恒之火")]
        [Description("维持坦克身上的永恒之火状态")]
        public bool KeepEternalFlameUp { get; set; } 

        [Setting]
        [DefaultValue(80)]
        [Category("神圣")]
        [DisplayName("黎明圣光血量百分比")]
        [Description("血量低于该百分比时使用黎明圣光")]
        public int LightOfDawnHealth { get; set; }

        [Setting]
        [DefaultValue(2)]
        [Category("神圣")]
        [DisplayName("黎明圣光队友数量")]
        [Description("超过设置数量的队友血量低于黎明圣光血量百分比时使用黎明圣光")]
        public int LightOfDawnCount { get; set; }

        [Setting]
        [DefaultValue(90)]
        [Category("神圣")]
        [DisplayName("神圣震击血量百分比")]
        [Description("血量低于该百分比时使用神圣震击")]
        public int HolyShockHealth { get; set; }

        [Setting]
        [DefaultValue(65)]
        [Category("神圣")]
        [DisplayName("神圣之光血量百分比")]
        [Description("血量低于该百分比时使用神圣之光")]
        public int DivineLightHealth { get; set; }

        [Setting]
        [DefaultValue(50)]
        [Category("神圣")]
        [DisplayName("神圣恳求法力百分比")]
        [Description("法力低于该百分比时使用神圣恳求")]
        public int DivinePleaManaPct { get; set; }

         #endregion

        #region Protection
        [Setting]
        [DefaultValue(40)]
        [Category("防护")]
        [DisplayName("远古列王守卫血量百分比")]
        [Description("血量低于该百分比时使用远古列王守卫")]
        public int GoAKHealth { get; set; }

        [Setting]
        [DefaultValue(40)]
        [Category("防护")]
        [DisplayName("炽热防御者血量百分比")]
        [Description("血量低于该百分比时使用炽热防御者")]
        public int ArdentDefenderHealth { get; set; }

        [Setting]
        [DefaultValue(80)]
        [Category("防护")]
        [DisplayName("圣佑术血量百分比")]
        [Description("血量低于该百分比时使用圣佑术")]
        public int DivineProtectionHealthProt { get; set; }

        [Setting]
        [DefaultValue(false)]
        [Category("防护")]
        [DisplayName("仅在引怪时使用复仇者之盾")]
        [Description("仅使用复仇者之盾来引怪")]
        public bool AvengersPullOnly { get; set; }

        [Setting]
        [DefaultValue(3)]
        [Category("防护")]
        [DisplayName("奉献怪物数量")]
        [Description("超过该数量的怪物攻击你时使用奉献")]
        public int ProtConsecrationCount { get; set; }
        #endregion

        #region Retribution
        [Setting]
        [DefaultValue(70)]
        [Category("惩戒")]
        [DisplayName("圣佑术血量百分比")]
        [Description("血量低于该百分比时使用圣佑术")]
        public int DivineProtectionHealthRet { get; set; }

        [Setting]
        [DefaultValue(true)]
        [Category("惩戒")]
        [DisplayName("使用复仇之怒/神圣复仇者/远古列王守卫")]
        [Description("True:自动使用复仇之怒,神圣复仇者,远古列王守卫.False: 手动施放使用")]
        public bool RetAvengAndGoatK { get; set; }

       #endregion
    }
}
