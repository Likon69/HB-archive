﻿
using System.ComponentModel;
using System.IO;
using Styx.Helpers;
using Styx.WoWInternals.WoWObjects;

using DefaultValue = Styx.Helpers.DefaultValueAttribute;

namespace Singular.Settings
{
    public class HealerSettings : Styx.Helpers.Settings
    {
        [Browsable(false)]
        public HealingContext Context { get; set; }

        // reqd ctor
        public HealerSettings(string className, HealingContext ctx)
            : base(Path.Combine(SingularSettings.SingularSettingsPath, className + "-Heal-" + ctx.ToString() + ".xml"))
        {
            Context = ctx;
        }

        // hide default ctor
        private HealerSettings()
            : base(null)
        {
        }


#if false

        [Setting]
        [DefaultValue(47)]
        [Category("天赋")]
        [DisplayName("石壁图腾血量百分比")]
        [Description("血量低于该百分比时使用石壁图腾.设置为0禁用.")]
        public int StoneBulwarkTotemPercent { get; set; }

#endif
    }
}
