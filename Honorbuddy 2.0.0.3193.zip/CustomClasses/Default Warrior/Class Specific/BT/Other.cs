﻿using System.Linq;
using System.Threading;
using Hera.Helpers;
using Hera.SpellsMan;
using Styx.Logic;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using TreeSharp;
using Settings = Hera.Config.Settings;

namespace Hera
{
    public partial class Fpsware
    {

        // ******************************************************************************************
        //
        // This is where the Composites start
        //


        // Healing logic, everyone needs to heal (almost everyone) and this will be our first BT example
        #region Heal Behaviour

        // _healBehavior is a class that will hold our logic. This code is created a bit further down
        private Composite _healBehavior;

        // We override the HB HealBehavior and return our own, in this case we return _healBehavior
        public override Composite HealBehavior
        {
            get
            {
                // First check if _healBehavior has anything in it. If its null then its not going to do anything
                if (_healBehavior == null)
                {
                    // We're here because _healBehavior is null so we need to assign our logic to it. 
                    Utils.Log("Creating 'Heal' behavior");

                    // CreateHealBehavior is a class we create that holds all our logic and we assign that to _healBehaviour
                    // But we only do it once and this happens during the CC initialisation
                    _healBehavior = CreateHealBehavior();
                }

                return _healBehavior;
            }
        }

        // This is the place we create our healing logic
        // Instead of getting overly complicated (and messy) and using Decorators, Selectors and Actions I use seperate classes 
        // Basically CreateHealBehavior is a single line of code, we just add some white space to make it readable
        //
        private static Composite CreateHealBehavior()
        {
            return new PrioritySelector(

                // Use a health potion if we need it
                //new NeedToUseHealthPot(new UseHealthPot())

                );
        }

        #endregion



        // Rest Behaviour
        //   * Healing
        //   * Eat and Drink
        //   * Buffs
        #region Rest Behaviour
        private Composite _restBehavior;
        public override Composite RestBehavior
        {
            get { if (_restBehavior == null) { Utils.Log("Creating 'Rest' behavior"); _restBehavior = CreateRestBehavior(); } return _restBehavior; }
        }

        private Composite CreateRestBehavior()
        {
            return new PrioritySelector(

                // We're full. Stop eating/drinking
                // No point sitting there doing nothing wating for the Eat/Drink buff to disapear
                new NeedToCancelFoodDrink(new CancelFoodDrink()),

                // Eat and Drink
                new NeedToEatDrink(new EatDrink()),

                // Battle Shout
                new NeedToShout(new Shout())

                );
        }

        #endregion




        // ******************************************************************************************
        //
        // This is where the common priority selectors start
        // These can be used with ANY class, they are all non-class specific
        //


        // Check your distance to the target and move appropriately
        //      * If you're too close and moving then stop moving
        //      * If you're too far away then move closer
        #region DistanceCheck
        public class NeedToCheckDistance : Decorator
        {
            public NeedToCheckDistance(Composite child) : base(child) { }

            protected override bool CanRun(object context)
            {
                Debug.Log("NeedToCheckDistance", 1);
                if (!Me.GotTarget || Me.CurrentTarget.Dead) return false;
                if (!Utils.IsCommonChecksOk("", false)) return false;
                return Movement.NeedToCheck;
            }
        }

        public class CheckDistance : Action
        {
            protected override RunStatus Run(object context)
            {
                Movement.DistanceCheck();
                return RunStatus.Success;
            }
        }
        #endregion

        // Cancel the food / drink buff if we're above 98%
        #region Cancel Food Drink Buff
        public class NeedToCancelFoodDrink : Decorator
        {
            public NeedToCancelFoodDrink(Composite child) : base(child) { }

            protected override bool CanRun(object context)
            {
                Debug.Log("NeedToCancelFoodDrink", 1);
                return Self.IsHealthAbove(98) && Self.IsBuffOnMe("Food");
            }
        }

        public class CancelFoodDrink : Action
        {
            protected override RunStatus Run(object context)
            {
                Lua.DoString("CancelUnitBuff('player', 'Food') CancelUnitBuff('player', 'Drink')");
                return RunStatus.Success;
            }
        }
        #endregion

        #region Eat and Drink
        public class NeedToEatDrink : Decorator
        {
            public NeedToEatDrink(Composite child) : base(child) { }

            protected override bool CanRun(object context)
            {
                Debug.Log("NeedToEatDrink", 1);
                if (Me.IsSwimming) return false;

                return !Self.IsBuffOnMe("Food") &&  Me.HealthPercent < Settings.RestHealth;
            }
        }

        public class EatDrink : Action
        {
            protected override RunStatus Run(object context)
            {
                bool result = false;

                //Inventory.Drink(false);
                Inventory.Eat(false);
                Utils.LagSleep();

                if (Self.IsBuffOnMe("Food")) result = true;

                return result ? RunStatus.Success : RunStatus.Failure;
            }
        }
        #endregion

        #region Use Health Potion
        public class NeedToUseHealthPot : Decorator
        {
            public NeedToUseHealthPot(Composite child) : base(child) { }

            protected override bool CanRun(object context)
            {
                if (!Me.Combat) return false;
                if (Self.IsHealthAbove(Settings.HealthPotion)) return false;

                if (Inventory.HealthPotions.IsUseable) return true;

                return false;
            }
        }

        public class UseHealthPot : Action
        {
            protected override RunStatus Run(object context)
            {
                Inventory.HealthPotions.Use();
                return RunStatus.Success;
            }
        }
        #endregion

        #region We got aggro during pull
        public class NeedToCheckAggroOnPull : Decorator
        {
            public NeedToCheckAggroOnPull(Composite child) : base(child) { }

            protected override bool CanRun(object context)
            {
                Debug.Log("NeedToCheckAggroOnPull",1);
                if (Me.Combat && !Me.Mounted)
                {

                    if (Targeting.Instance.TargetList.Count <= 0) return false;
                    if (!Me.Combat) return false;

                    // Check if something has aggro during our pull
                    if (Me.GotTarget && Target.IsDistanceMoreThan(15) && !CT.Combat)
                    {
                        foreach (WoWUnit t in Targeting.Instance.TargetList)
                        {
                            if (t.Guid == CT.Guid) continue;
                            return true;
                        }
                        //return Targeting.Instance.TargetList.Where(mob => mob.CurrentTargetGuid == Me.Guid && Me.CurrentTargetGuid != mob.CurrentTargetGuid).Any();
                    }

                    /*
                    if (!Me.GotTarget && Me.Combat)
                    {
                        return true;
                    }
                     */
                }


                return false;
            }
        }

        public class CheckAggroOnPull : Action
        {
            protected override RunStatus Run(object context)
            {
                foreach (WoWUnit mob in Targeting.Instance.TargetList.Where(mob => mob.CurrentTargetGuid == Me.Guid && Me.CurrentTargetGuid != mob.CurrentTargetGuid))
                {
                    //Utils.Log(string.Format("Looks like we got aggro from {0}", mob.Name), Utils.Colour("Red"));
                    if (Me.IsMoving) Movement.StopMoving();
                    mob.Target();
                    Thread.Sleep(500);
                    //Target.Face();
                    break;
                }

                bool result = Me.GotTarget;
                return result ? RunStatus.Success : RunStatus.Failure;
            }
        }
        #endregion

        #region Face Target
        public class NeedToFaceTarget: Decorator
        {
            public NeedToFaceTarget(Composite child) : base(child) { }

            protected override bool CanRun(object context)
            {
                Debug.Log("NeedToFaceTarget", 1);
                if (!Me.GotTarget) return false;
                if (Me.CurrentTarget.Dead) return false;
                //return (!Me.IsSafelyFacing(CT));
                return !Target.IsFacing;
            }
        }

        public class FaceTarget : Action
        {
            protected override RunStatus Run(object context)
            {
                Target.Face();
                bool result = true;
                Utils.Log("-Face the target",Utils.Colour("Blue"));

                return result ? RunStatus.Success : RunStatus.Failure;
            }
        }
        #endregion

        #region Blacklist Pull Target
        public class NeedToBlacklistPullTarget: Decorator
        {
            public NeedToBlacklistPullTarget(Composite child) : base(child) { }

            protected override bool CanRun(object context)
            {
                Debug.Log("NeedToBlacklistPullTarget", 1);
                return !Target.IsValidPullTarget;
            }
        }

        public class BlacklistPullTarget : Action
        {
            protected override RunStatus Run(object context)
            {
                Utils.Log(string.Format("Bad pull target blacklisting and finding another target."), Utils.Colour("Red"));
                Target.BlackList(100);
                Me.ClearTarget();

                return RunStatus.Success;
            }
        }
        #endregion

        #region Select RAF Target
        public class NeedToSelectRAFTarget : Decorator
        {
            public NeedToSelectRAFTarget(Composite child) : base(child) { }

            protected override bool CanRun(object context)
            {
                CLC.RawSetting = Settings.RAFTarget;
                if (!CLC.IsOkToRun) return false;

                bool result = Me.IsInParty
                              && RaFHelper.Leader != null
                              && RaFHelper.Leader.GotTarget
                              && Me.GotTarget
                              && Me.CurrentTargetGuid != RaFHelper.Leader.CurrentTargetGuid;

                return result;
            }
        }

        public class SelectRAFTarget : Action
        {
            protected override RunStatus Run(object context)
            {
                RaFHelper.Leader.CurrentTarget.Target();
                Thread.Sleep(250);
                bool result = (Me.GotTarget && Me.CurrentTargetGuid == RaFHelper.Leader.CurrentTargetGuid);

                return result ? RunStatus.Success : RunStatus.Failure;

            }
        }
        #endregion

        #region Battle Shout / Commanding Shout
        public class NeedToShout: Decorator
        {
            public NeedToShout(Composite child) : base(child) { }

            protected override bool CanRun(object context)
            {
                Debug.Log("NeedToShout", 1);
                if (!Utils.IsCommonChecksOk(Settings.Shout, false)) return false;
                if (!Self.CanBuffMe(Settings.Shout)) return false;

                bool result = Spell.CanCast(Settings.Shout);
                return result;
            }
        }

        public class Shout : Action
        {
            protected override RunStatus Run(object context)
            {
                bool result = Spell.Cast(Settings.Shout, Me);
                return result ? RunStatus.Success : RunStatus.Failure;
            }
        }
        #endregion

       
    }
}
