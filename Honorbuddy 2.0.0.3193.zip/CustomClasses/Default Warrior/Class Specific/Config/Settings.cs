﻿using System;
using System.Diagnostics;
using System.IO;
using System.Xml;
using Hera.Helpers;
using Styx.Helpers;

namespace Hera.Config
{
    public static class Settings
    {
        private const string FileName = @"CustomClasses\Default Warrior\Class Specific\Config\Settings.xml";
        private static string _fullFileNameAndPath = "";

        // Common settings template
        public static bool DirtyData { get; set; }
        public static int RestHealth { get; set; }
        public static string Debug { get; set; }
        public static string RAFTarget { get; set; }
        public static string ShowUI { get; set; }
        public static string SmartEatDrink { get; set; }
        public static int CombatTimeout { get; set; }
        public static int HealthPotion { get; set; }

        // class specific
        public static string Rend { get; set; }
        public static string ThunderClap { get; set; }
        public static string Shout { get; set; }
        public static string DeathWish { get; set; }
        public static string BerserkerRage { get; set; }
        public static int AttackRage { get; set; }
        public static string Execute { get; set; }
        public static string DeadlyCalm { get; set; }
        public static string Cleave { get; set; }
        public static string Whirlwind { get; set; }




        public static void Save()
        {
            try
            {
                XmlDocument xmlDoc = new XmlDocument();
                xmlDoc.Load(_fullFileNameAndPath);


                // Common settings template
                xmlDoc.SelectSingleNode("//Warrior/ShowUI").InnerText = ShowUI;
                xmlDoc.SelectSingleNode("//Warrior/SmartEatDrink").InnerText = SmartEatDrink;
                xmlDoc.SelectSingleNode("//Warrior/RAFTarget").InnerText = RAFTarget;
                xmlDoc.SelectSingleNode("//Warrior/Debug").InnerText = Debug;
                xmlDoc.SelectSingleNode("//Warrior/RestHealth").InnerText = RestHealth.ToString();
                xmlDoc.SelectSingleNode("//Warrior/CombatTimeout").InnerText = CombatTimeout.ToString();
                xmlDoc.SelectSingleNode("//Warrior/HealthPotion").InnerText = HealthPotion.ToString();
                
                // Class specific
                xmlDoc.SelectSingleNode("//Warrior/Rend").InnerText = Rend;
                xmlDoc.SelectSingleNode("//Warrior/ThunderClap").InnerText = ThunderClap;
                xmlDoc.SelectSingleNode("//Warrior/Shout").InnerText = Shout;
                xmlDoc.SelectSingleNode("//Warrior/DeathWish").InnerText = DeathWish;
                xmlDoc.SelectSingleNode("//Warrior/BerserkerRage").InnerText = BerserkerRage;
                xmlDoc.SelectSingleNode("//Warrior/AttackRage").InnerText = AttackRage.ToString();
                xmlDoc.SelectSingleNode("//Warrior/Execute").InnerText = Execute;
                xmlDoc.SelectSingleNode("//Warrior/DeadlyCalm").InnerText = DeadlyCalm;
                xmlDoc.SelectSingleNode("//Warrior/Cleave").InnerText = Cleave;
                xmlDoc.SelectSingleNode("//Warrior/Whirlwind").InnerText = Whirlwind;


                xmlDoc.Save(_fullFileNameAndPath);
                Utils.Log("Settings have been updated");
            }
            catch (Exception e)
            {
                Logging.WriteDebug("**********************************************************************");
                Logging.WriteDebug("**********************************************************************");
                Logging.WriteDebug(" ");
                Logging.WriteDebug(" ");
                Logging.WriteDebug(String.Format("Exception in XML Save {0}", e.Message));
                Logging.WriteDebug(" ");
                Logging.WriteDebug(" ");
                Logging.WriteDebug("**********************************************************************");
                Logging.WriteDebug("**********************************************************************");
            }
        }

        public static void Load()
        {

            string currentXMLKey = "NO KEY READ YET";

            try
            {
                
                XmlTextReader reader;
                XmlNode xvar;

                string sPath = Process.GetCurrentProcess().MainModule.FileName;
                sPath = Path.GetDirectoryName(sPath);
                sPath = Path.Combine(sPath, FileName);
                _fullFileNameAndPath = sPath;

                Utils.Log("Loading settings from the config file...");

                try { reader = new XmlTextReader(sPath); }
                catch (Exception e) { Logging.WriteDebug(String.Format("Error loading configuration file: {0}", e.Message)); return; }

                XmlDocument xml = new XmlDocument();


                xml.Load(reader);

                // Common settings template
                currentXMLKey = "//Warrior/RAFTarget"; xvar = xml.SelectSingleNode(currentXMLKey); if (xvar != null) { RAFTarget = Convert.ToString(xvar.InnerText); }
                currentXMLKey = "//Warrior/Debug"; xvar = xml.SelectSingleNode(currentXMLKey); if (xvar != null) { Debug = Convert.ToString(xvar.InnerText); }
                currentXMLKey = "//Warrior/RestHealth"; xvar = xml.SelectSingleNode(currentXMLKey); if (xvar != null) { RestHealth = Convert.ToInt16(xvar.InnerText); }
                currentXMLKey = "//Warrior/ShowUI"; xvar = xml.SelectSingleNode(currentXMLKey); if (xvar != null) { ShowUI = Convert.ToString(xvar.InnerText); }
                currentXMLKey = "//Warrior/SmartEatDrink"; xvar = xml.SelectSingleNode(currentXMLKey); if (xvar != null) { SmartEatDrink = Convert.ToString(xvar.InnerText); }
                currentXMLKey = "//Warrior/CombatTimeout"; xvar = xml.SelectSingleNode(currentXMLKey); if (xvar != null) { CombatTimeout = Convert.ToInt16(xvar.InnerText); }
                currentXMLKey = "//Warrior/HealthPotion"; xvar = xml.SelectSingleNode(currentXMLKey); if (xvar != null) { HealthPotion = Convert.ToInt16(xvar.InnerText); }

                // Class specific
                currentXMLKey = "//Warrior/Rend"; xvar = xml.SelectSingleNode(currentXMLKey); if (xvar != null) { Rend = Convert.ToString(xvar.InnerText); }
                currentXMLKey = "//Warrior/ThunderClap"; xvar = xml.SelectSingleNode(currentXMLKey); if (xvar != null) { ThunderClap = Convert.ToString(xvar.InnerText); }
                currentXMLKey = "//Warrior/Shout"; xvar = xml.SelectSingleNode(currentXMLKey); if (xvar != null) { Shout = Convert.ToString(xvar.InnerText); }
                currentXMLKey = "//Warrior/DeathWish"; xvar = xml.SelectSingleNode(currentXMLKey); if (xvar != null) { DeathWish = Convert.ToString(xvar.InnerText); }
                currentXMLKey = "//Warrior/BerserkerRage"; xvar = xml.SelectSingleNode(currentXMLKey); if (xvar != null) { BerserkerRage = Convert.ToString(xvar.InnerText); }
                currentXMLKey = "//Warrior/AttackRage"; xvar = xml.SelectSingleNode(currentXMLKey); if (xvar != null) { AttackRage = Convert.ToInt16(xvar.InnerText); }
                currentXMLKey = "//Warrior/Execute"; xvar = xml.SelectSingleNode(currentXMLKey); if (xvar != null) { Execute = Convert.ToString(xvar.InnerText); }
                currentXMLKey = "//Warrior/DeadlyCalm"; xvar = xml.SelectSingleNode(currentXMLKey); if (xvar != null) { DeadlyCalm = Convert.ToString(xvar.InnerText); }
                currentXMLKey = "//Warrior/Cleave"; xvar = xml.SelectSingleNode(currentXMLKey); if (xvar != null) { Cleave = Convert.ToString(xvar.InnerText); }
                currentXMLKey = "//Warrior/Whirlwind"; xvar = xml.SelectSingleNode(currentXMLKey); if (xvar != null) { Whirlwind = Convert.ToString(xvar.InnerText); }

                
                reader.Close();
                Utils.Log("Finished loading settings");
            }
            catch (Exception e)
            {
                Logging.WriteDebug("**********************************************************************");
                Logging.WriteDebug("**********************************************************************");
                Logging.WriteDebug(" ");
                Logging.WriteDebug(" ");
                Logging.WriteDebug(String.Format("Exception in XML Load: {0}", e.Message)); Logging.WriteDebug("-- Attempted to read: " + currentXMLKey);
                Logging.WriteDebug(" ");
                Logging.WriteDebug(" ");
                Logging.WriteDebug("**********************************************************************");
                Logging.WriteDebug("**********************************************************************");
            }
        }
    }
}