﻿using System;
using System.Diagnostics;
using System.IO;
using System.Xml;
using Hera.Helpers;
using Styx.Helpers;

namespace Hera.Config
{
    public static class Settings
    {
        private const string FileName = @"CustomClasses\Default Druid\Class Specific\Config\Settings.xml";
        private static string _fullFileNameAndPath = "";

        // Common settings template
        public static string Cleanse { get; set; }
        public static bool DirtyData { get; set; }
        public static int RestMana { get; set; }
        public static int RestHealth { get; set; }
        public static int PotionMana { get; set; }
        public static string Debug { get; set; }
        public static string RAFTarget { get; set; }
        public static string HealPartyMembers { get; set; }
        public static string ShowUI { get; set; }
        public static string SmartEatDrink { get; set; }
        public static int CombatTimeout { get; set; }

        // class specific
        public static string Regrowth { get; set; }
        public static int RegrowthHealth { get; set; }
        public static string HealingTouch { get; set; }
        public static int HealingTouchHealth { get; set; }
        public static int InnervateMana { get; set; }

        // Balance
        public static string PullBalance { get; set; }
        public static string FaerieFireBalance { get; set; }
        public static string InsectSwarm { get; set; }
        public static string Moonfire { get; set; }
        public static string Starsurge { get; set; }
        public static string ForceOfNature { get; set; }
        public static string PrimaryDPSSpell { get; set; }

        // Feral
        public static string PullFeral { get; set; }
        public static int AttackEnergy { get; set; }
        public static string FaerieFireFeral { get; set; }
        public static string Rake { get; set; }
        public static string SkullBash { get; set; }
        public static string TigersFury { get; set; }
        public static string SavageRoar { get; set; }
        public static string Swipe { get; set; }
        public static string Thrash { get; set; }
        public static string Rip { get; set; }
        public static string Maim { get; set; }
        public static string FerociousBite { get; set; }
        public static string BearForm { get; set; }
        
        // Travel Form
        public static string TravelForm { get; set; }
        public static int TravelFormMinDistance { get; set; }
        public static int TravelFormHostileRange { get; set; }




        public static void Save()
        {


            try
            {

                XmlDocument xmlDoc = new XmlDocument();
                xmlDoc.Load(_fullFileNameAndPath);

                // Common settings template
                xmlDoc.SelectSingleNode("//Karis/ShowUI").InnerText = ShowUI;
                xmlDoc.SelectSingleNode("//Karis/SmartEatDrink").InnerText = SmartEatDrink;
                xmlDoc.SelectSingleNode("//Karis/HealPartyMembers").InnerText = HealPartyMembers;
                xmlDoc.SelectSingleNode("//Karis/RAFTarget").InnerText = RAFTarget;
                xmlDoc.SelectSingleNode("//Karis/Debug").InnerText = Debug;
                xmlDoc.SelectSingleNode("//Karis/PotionMana").InnerText = PotionMana.ToString();
                xmlDoc.SelectSingleNode("//Karis/RestMana").InnerText = RestMana.ToString();
                xmlDoc.SelectSingleNode("//Karis/RestHealth").InnerText = RestHealth.ToString();
                xmlDoc.SelectSingleNode("//Karis/Cleanse").InnerText = Cleanse;
                xmlDoc.SelectSingleNode("//Karis/CombatTimeout").InnerText = CombatTimeout.ToString();

                // Class specific
                // Healing
                xmlDoc.SelectSingleNode("//Karis/Regrowth").InnerText = Regrowth;
                xmlDoc.SelectSingleNode("//Karis/RegrowthHealth").InnerText = RegrowthHealth.ToString();
                xmlDoc.SelectSingleNode("//Karis/HealingTouch").InnerText = HealingTouch;
                xmlDoc.SelectSingleNode("//Karis/HealingTouchHealth").InnerText = HealingTouchHealth.ToString();
                xmlDoc.SelectSingleNode("//Karis/InnervateMana").InnerText = InnervateMana.ToString();

                // Balance
                xmlDoc.SelectSingleNode("//Karis/PullBalance").InnerText = PullBalance;
                xmlDoc.SelectSingleNode("//Karis/FaerieFireBalance").InnerText = FaerieFireBalance;
                xmlDoc.SelectSingleNode("//Karis/InsectSwarm").InnerText = InsectSwarm;
                xmlDoc.SelectSingleNode("//Karis/Moonfire").InnerText = Moonfire;
                xmlDoc.SelectSingleNode("//Karis/Starsurge").InnerText = Starsurge;
                xmlDoc.SelectSingleNode("//Karis/PrimaryDPSSpell").InnerText = PrimaryDPSSpell;
                xmlDoc.SelectSingleNode("//Karis/ForceOfNature").InnerText = ForceOfNature;

                // Feral
                xmlDoc.SelectSingleNode("//Karis/PullFeral").InnerText = PullFeral;
                xmlDoc.SelectSingleNode("//Karis/AttackEnergy").InnerText = AttackEnergy.ToString();
                xmlDoc.SelectSingleNode("//Karis/FaerieFireFeral").InnerText = FaerieFireFeral;
                xmlDoc.SelectSingleNode("//Karis/Rake").InnerText = Rake;
                xmlDoc.SelectSingleNode("//Karis/SkullBash").InnerText = SkullBash;
                xmlDoc.SelectSingleNode("//Karis/TigersFury").InnerText = TigersFury;
                xmlDoc.SelectSingleNode("//Karis/Swipe").InnerText = Swipe;
                xmlDoc.SelectSingleNode("//Karis/SavageRoar").InnerText = SavageRoar;
                xmlDoc.SelectSingleNode("//Karis/Thrash").InnerText = Thrash;
                xmlDoc.SelectSingleNode("//Karis/Rip").InnerText = Rip;
                xmlDoc.SelectSingleNode("//Karis/Maim").InnerText = Maim;
                xmlDoc.SelectSingleNode("//Karis/FerociousBite").InnerText = FerociousBite;
                xmlDoc.SelectSingleNode("//Karis/BearForm").InnerText = BearForm;

                // Travel Form
                xmlDoc.SelectSingleNode("//Karis/TravelForm").InnerText = TravelForm;
                xmlDoc.SelectSingleNode("//Karis/TravelFormMinDistance").InnerText = TravelFormMinDistance.ToString();
                xmlDoc.SelectSingleNode("//Karis/TravelFormHostileRange").InnerText = TravelFormHostileRange.ToString();




                xmlDoc.Save(_fullFileNameAndPath);
                Utils.Log("Settings have been updated");
            }
            catch (Exception e)
            {
                Logging.WriteDebug("**********************************************************************");
                Logging.WriteDebug("**********************************************************************");
                Logging.WriteDebug(" ");
                Logging.WriteDebug(" ");
                Logging.WriteDebug(String.Format("Exception in XML Save {0}", e.Message));
                Logging.WriteDebug(" ");
                Logging.WriteDebug(" ");
                Logging.WriteDebug("**********************************************************************");
                Logging.WriteDebug("**********************************************************************");
            }
        }

        public static void Load()
        {

            string currentXMLKey = "NO KEY READ YET";

            try
            {
                
                XmlTextReader reader;
                XmlNode xvar;

                string sPath = Process.GetCurrentProcess().MainModule.FileName;
                sPath = Path.GetDirectoryName(sPath);
                sPath = Path.Combine(sPath, FileName);
                _fullFileNameAndPath = sPath;

                Utils.Log("Loading settings from the config file...");

                try { reader = new XmlTextReader(sPath); }
                catch (Exception e) { Logging.WriteDebug(String.Format("Error loading configuration file: {0}", e.Message)); return; }

                XmlDocument xml = new XmlDocument();


                xml.Load(reader);

                // Common settings template
                currentXMLKey = "//Karis/HealPartyMembers"; xvar = xml.SelectSingleNode(currentXMLKey); if (xvar != null) { HealPartyMembers = Convert.ToString(xvar.InnerText); }
                currentXMLKey = "//Karis/RAFTarget"; xvar = xml.SelectSingleNode(currentXMLKey); if (xvar != null) { RAFTarget = Convert.ToString(xvar.InnerText); }
                currentXMLKey = "//Karis/Debug"; xvar = xml.SelectSingleNode(currentXMLKey); if (xvar != null) { Debug = Convert.ToString(xvar.InnerText); }
                currentXMLKey = "//Karis/PotionMana"; xvar = xml.SelectSingleNode(currentXMLKey); if (xvar != null) { PotionMana = Convert.ToInt16(xvar.InnerText); }
                currentXMLKey = "//Karis/RestMana"; xvar = xml.SelectSingleNode(currentXMLKey); if (xvar != null) { RestMana = Convert.ToInt16(xvar.InnerText); }
                currentXMLKey = "//Karis/RestHealth"; xvar = xml.SelectSingleNode(currentXMLKey); if (xvar != null) { RestHealth = Convert.ToInt16(xvar.InnerText); }
                currentXMLKey = "//Karis/Cleanse"; xvar = xml.SelectSingleNode(currentXMLKey); if (xvar != null) { Cleanse = Convert.ToString(xvar.InnerText); }
                currentXMLKey = "//Karis/ShowUI"; xvar = xml.SelectSingleNode(currentXMLKey); if (xvar != null) { ShowUI = Convert.ToString(xvar.InnerText); }
                currentXMLKey = "//Karis/SmartEatDrink"; xvar = xml.SelectSingleNode(currentXMLKey); if (xvar != null) { SmartEatDrink = Convert.ToString(xvar.InnerText); }
                currentXMLKey = "//Karis/CombatTimeout"; xvar = xml.SelectSingleNode(currentXMLKey); if (xvar != null) { CombatTimeout = Convert.ToInt16(xvar.InnerText); }

                // Class specific

                // Healing and Mana Regen
                currentXMLKey = "//Karis/Regrowth"; xvar = xml.SelectSingleNode(currentXMLKey); if (xvar != null) { Regrowth = Convert.ToString(xvar.InnerText); }
                currentXMLKey = "//Karis/RegrowthHealth"; xvar = xml.SelectSingleNode(currentXMLKey); if (xvar != null) { RegrowthHealth = Convert.ToInt16(xvar.InnerText); }
                currentXMLKey = "//Karis/HealingTouch"; xvar = xml.SelectSingleNode(currentXMLKey); if (xvar != null) { HealingTouch = Convert.ToString(xvar.InnerText); }
                currentXMLKey = "//Karis/HealingTouchHealth"; xvar = xml.SelectSingleNode(currentXMLKey); if (xvar != null) { HealingTouchHealth = Convert.ToInt16(xvar.InnerText); }
                currentXMLKey = "//Karis/InnervateMana"; xvar = xml.SelectSingleNode(currentXMLKey); if (xvar != null) { InnervateMana = Convert.ToInt16(xvar.InnerText); }

                // Balance
                currentXMLKey = "//Karis/PullBalance"; xvar = xml.SelectSingleNode(currentXMLKey); if (xvar != null) { PullBalance = Convert.ToString(xvar.InnerText); }
                currentXMLKey = "//Karis/FaerieFireBalance"; xvar = xml.SelectSingleNode(currentXMLKey); if (xvar != null) { FaerieFireBalance = Convert.ToString(xvar.InnerText); }
                currentXMLKey = "//Karis/InsectSwarm"; xvar = xml.SelectSingleNode(currentXMLKey); if (xvar != null) { InsectSwarm = Convert.ToString(xvar.InnerText); }
                currentXMLKey = "//Karis/Moonfire"; xvar = xml.SelectSingleNode(currentXMLKey); if (xvar != null) { Moonfire = Convert.ToString(xvar.InnerText); }
                currentXMLKey = "//Karis/Starsurge"; xvar = xml.SelectSingleNode(currentXMLKey); if (xvar != null) { Starsurge = Convert.ToString(xvar.InnerText); }
                currentXMLKey = "//Karis/ForceOfNature"; xvar = xml.SelectSingleNode(currentXMLKey); if (xvar != null) { ForceOfNature = Convert.ToString(xvar.InnerText); }
                currentXMLKey = "//Karis/PrimaryDPSSpell"; xvar = xml.SelectSingleNode(currentXMLKey); if (xvar != null) { PrimaryDPSSpell = Convert.ToString(xvar.InnerText); }

                // Feral
                currentXMLKey = "//Karis/PullFeral"; xvar = xml.SelectSingleNode(currentXMLKey); if (xvar != null) { PullFeral = Convert.ToString(xvar.InnerText); }
                currentXMLKey = "//Karis/AttackEnergy"; xvar = xml.SelectSingleNode(currentXMLKey); if (xvar != null) { AttackEnergy = Convert.ToInt16(xvar.InnerText); }
                currentXMLKey = "//Karis/FaerieFireFeral"; xvar = xml.SelectSingleNode(currentXMLKey); if (xvar != null) { FaerieFireFeral = Convert.ToString(xvar.InnerText); }
                currentXMLKey = "//Karis/Rake"; xvar = xml.SelectSingleNode(currentXMLKey); if (xvar != null) { Rake = Convert.ToString(xvar.InnerText); }
                currentXMLKey = "//Karis/SkullBash"; xvar = xml.SelectSingleNode(currentXMLKey); if (xvar != null) { SkullBash = Convert.ToString(xvar.InnerText); }
                currentXMLKey = "//Karis/TigersFury"; xvar = xml.SelectSingleNode(currentXMLKey); if (xvar != null) { TigersFury = Convert.ToString(xvar.InnerText); }
                currentXMLKey = "//Karis/SavageRoar"; xvar = xml.SelectSingleNode(currentXMLKey); if (xvar != null) { SavageRoar = Convert.ToString(xvar.InnerText); }
                currentXMLKey = "//Karis/Swipe"; xvar = xml.SelectSingleNode(currentXMLKey); if (xvar != null) { Swipe = Convert.ToString(xvar.InnerText); }
                currentXMLKey = "//Karis/Thrash"; xvar = xml.SelectSingleNode(currentXMLKey); if (xvar != null) { Thrash = Convert.ToString(xvar.InnerText); }
                currentXMLKey = "//Karis/Rip"; xvar = xml.SelectSingleNode(currentXMLKey); if (xvar != null) { Rip = Convert.ToString(xvar.InnerText); }
                currentXMLKey = "//Karis/Maim"; xvar = xml.SelectSingleNode(currentXMLKey); if (xvar != null) { Maim = Convert.ToString(xvar.InnerText); }
                currentXMLKey = "//Karis/FerociousBite"; xvar = xml.SelectSingleNode(currentXMLKey); if (xvar != null) { FerociousBite = Convert.ToString(xvar.InnerText); }
                currentXMLKey = "//Karis/BearForm"; xvar = xml.SelectSingleNode(currentXMLKey); if (xvar != null) { BearForm = Convert.ToString(xvar.InnerText); }
                
                // Travel Form
                currentXMLKey = "//Karis/TravelForm"; xvar = xml.SelectSingleNode(currentXMLKey); if (xvar != null) { TravelForm = Convert.ToString(xvar.InnerText); }
                currentXMLKey = "//Karis/TravelFormMinDistance"; xvar = xml.SelectSingleNode(currentXMLKey); if (xvar != null) { TravelFormMinDistance = Convert.ToInt16(xvar.InnerText); }
                currentXMLKey = "//Karis/TravelFormHostileRange"; xvar = xml.SelectSingleNode(currentXMLKey); if (xvar != null) { TravelFormHostileRange = Convert.ToInt16(xvar.InnerText); }

                
                reader.Close();
                Utils.Log("Finished loading settings");
            }
            catch (Exception e)
            {
                Logging.WriteDebug("**********************************************************************");
                Logging.WriteDebug("**********************************************************************");
                Logging.WriteDebug(" ");
                Logging.WriteDebug(" ");
                Logging.WriteDebug(String.Format("Exception in XML Load: {0}", e.Message)); Logging.WriteDebug("-- Attempted to read: " + currentXMLKey);
                Logging.WriteDebug(" ");
                Logging.WriteDebug(" ");
                Logging.WriteDebug("**********************************************************************");
                Logging.WriteDebug("**********************************************************************");
            }
        }
    }
}