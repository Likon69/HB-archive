﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Styx.Plugins.PluginClass;
using Styx.Combat.CombatRoutine;
using Styx.Logic.Combat;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using System.Threading;
using Styx;
using Styx.Helpers;
using System.Diagnostics;

namespace ePriest4
{
    public class ePriest : CombatRoutine
    {
        #region BasicInfo
        List<WoWUnit> mobsTargetingMe 
        {
            get
            {
                return ObjectManager.GetObjectsOfType<WoWUnit>(true).Where(u => u.CurrentTarget == StyxWoW.Me).ToList();
            }
        }
        LocalPlayer me = ObjectManager.Me;

        public override string Name
        {
            get 
            { 
                return "ePriest"; 
            }
        }

        public override WoWClass Class
        {
            get
            {
                return WoWClass.Priest;
            }
        }

        #endregion

        #region Pull

        public override void Pull()
        {
            if (me.CurrentTarget.Distance > 40 && me.CurrentTarget.InLineOfSight)
            {
                WoWMovement.ClickToMove(me.CurrentTarget.Location);
            }
            else
            {
                WoWMovement.MoveStop();
                WoWMovement.StopFace();
            }
            if (SpellManager.HasSpell("Vampiric Touch"))
            {
                SpellManager.Cast("Vampiric Touch");
                return;
            }
            else if (SpellManager.HasSpell("Mind Blast"))
            {
                SpellManager.Cast("Mind Blast");
                return;
            }
            else
            {
                SpellManager.Cast("Smite");
            }

        }

            #region PullBuffs

        public override void PullBuff()
        {
            if (SpellManager.CanCast("Shadowform") && !me.Auras.ContainsKey("Shadowform"))
            {
                SpellManager.Cast("Shadowform");
            }
        }

        public override bool NeedPullBuffs
        {
            get
            {
                if (SpellManager.CanCast("Shadowform") && !me.Auras.ContainsKey("Shadowform"))
                {
                    return true;
                }
                return false;
            }
        }
            #endregion

        #endregion

        #region Combat

            public override void Combat()
            {
                if (me.CurrentTarget.Distance > 40 && me.CurrentTarget.InLineOfSight)
                {
                    WoWMovement.ClickToMove(me.CurrentTarget.Location);
                }
                else
                {
                    WoWMovement.MoveStop();
                    WoWMovement.StopFace();
                }
                if (SpellManager.CanCast("Smite"))
                {
                    var s = ChooseSpell();
                    if (s != null)
                    {
                        s.TargetCast();
                    }
                }
            }

            #region CombatHelpers
            Stopwatch vampTouchTimer = new Stopwatch();
            public WoWSpellTarget ChooseSpell()
            {
                if (StyxWoW.GlobalCooldown || StyxWoW.Me.IsCasting)
                {
                    return null;
                }
                WoWUnit secondUnit = GetSecondMobToPull();
                List<WoWUnit> mobs = mobsTargetingMe;
                if (!mobs.Contains(me.CurrentTarget))
                {
                    mobs.Add(me.CurrentTarget);
                }
                if (secondUnit != null)
                {
                    if (!mobs.Contains(secondUnit))
                    {
                        mobs.Add(secondUnit);
                    }
                }
                if (mobs.Contains(me))
                {
                    mobs.Remove(me);
                }
                if (mobs.Contains(null))
                {
                    mobs.Remove(null);
                }
                #region Power Word: Death
                if (SpellManager.CanCast("Shadow Word: Death") && me.HealthPercent > 75)
                {
                    foreach (WoWUnit unit in mobs)
                    {
                        if (unit.HealthPercent < 20)
                        {
                            return new WoWSpellTarget(GetSpell("Shadow Word: Death"), unit);
                        }
                    }
                }
                #endregion
                #region Vampiric Touch
                if (SpellManager.CanCast("Vampiric Touch") && (!vampTouchTimer.IsRunning || vampTouchTimer.Elapsed.TotalSeconds >= 1))
                {
                    foreach (WoWUnit unit in mobs)
                    {
                        if ((unit.HealthPercent > 30 || mobs.Count >= 2) && !unit.Auras.ContainsKey("Vampiric Touch"))//No dots unless health is high unless have more than 1 mob so dont kill high hp mob before low
                        {
                            vampTouchTimer.Reset();
                            vampTouchTimer.Start();
                            return new WoWSpellTarget(GetSpell("Vampiric Touch"), unit);
                        }
                    }
                }
                #endregion
                #region Devouring Plague
                bool devo = true;
                if (SpellManager.CanCast("Devouring Plague"))
                {
                    foreach (WoWUnit unit in mobs)
                    {
                        if (unit.Auras.ContainsKey("Vampiric Touch"))
                        {
                            devo = false;
                        }
                    }
                    if (devo)
                    {
                        foreach (WoWUnit unit in mobs)
                        {
                            if ((unit.HealthPercent > 30 || mobs.Count >= 2) && !unit.Auras.ContainsKey("Devouring Plague"))//No dots unless health is high unless have more than 1 mob so dont kill high hp mob before low
                            {
                                return new WoWSpellTarget(GetSpell("Devouring Plague"), unit);
                            }
                        }
                    }
                }
                #endregion
                #region Shadow Word: Pain
                if (SpellManager.CanCast("Shadow Word: Pain"))
                {
                    foreach (WoWUnit unit in mobs)
                    {
                        if ((unit.HealthPercent > 30 || mobs.Count >= 2) && !unit.Auras.ContainsKey("Shadow Word: Pain"))//No dots unless health is high unless have more than 1 mob so dont kill high hp mob before low
                        {
                            return new WoWSpellTarget(GetSpell("Shadow Word: Pain"), unit);
                        }
                    }
                }
                #endregion
                #region Shadowfiend
                if (SpellManager.CanCast("Shadowfiend"))
                {
                    foreach (WoWUnit unit in mobs)
                    {
                        if (unit.HealthPercent > 60 || mobs.Count >= 2)
                        {
                            return new WoWSpellTarget(GetSpell("Shadowfiend"), unit);
                        }
                    }
                    
                }
                #endregion
                #region Mind Blast
                if (SpellManager.CanCast("Mind Blast"))
                {
                    WoWUnit wu = null;
                    double lastHPPercent = 101;
                    foreach (WoWUnit unit in mobs)
                    {
                        if (unit.HealthPercent < lastHPPercent)
                        {
                            wu = unit;
                            lastHPPercent = unit.HealthPercent;
                        }
                    }
                    return new WoWSpellTarget(GetSpell("Mind Blast"), wu);
                }
                #endregion
                #region Mind Blast
                if (SpellManager.CanCast("Mind Flay"))
                {
                    WoWUnit wu = null;
                    TimeSpan shortestTimeSpan = new TimeSpan(long.MaxValue);
                    foreach (WoWUnit unit in mobs)
                    {
                        if (unit.Auras.ContainsKey("Shadow Word: Pain"))
                        {
                            if (unit.Auras["Shadow Word: Pain"].TimeLeft < shortestTimeSpan)
                            {
                                wu = unit;
                                shortestTimeSpan = unit.Auras["Shadow Word: Pain"].TimeLeft;
                            }
                        }
                        else if (wu==null)
                        {
                            wu = unit;
                        }
                    }
                    return new WoWSpellTarget(GetSpell("Mind Flay"), wu);
                }
                #endregion

                return new WoWSpellTarget(GetSpell("Smite"), mobs[0]);
            }

            public WoWSpell GetSpell(string spell)
            {
                foreach (WoWSpell wowSpell in SpellManager.Spells.Values)
                {
                    if (wowSpell.Name == spell)
                    {
                        return wowSpell;
                    }
                }
                return null;
            }

            public WoWUnit GetSecondMobToPull()
            {
                foreach (WoWUnit u in mobsTargetingMe)
                {
                    if (u.IsPlayer)
                    {
                        return null;
                    }
                }
                if (me.CurrentTarget.HealthPercent < 30 && mobsTargetingMe.Count <2 && me.HealthPercent > 60 && me.ManaPercent > 60)
                {
                    List<WoWUnit> units = ObjectManager.GetObjectsOfType<WoWUnit>(true).Where(u => u.Distance < 35 && !u.IsFriendly && u.Level +2 <= me.Level).ToList();
                    if (units.Count > 0)
                    {
                        WoWUnit theUnit = null;
                        double distance = double.MaxValue;
                        foreach (WoWUnit unit in units)
                        {
                            if (unit.Distance > distance)
                            {
                                distance = unit.Distance;
                                theUnit = unit;
                            }
                        }
                        return theUnit;
                    }
                    else
                    {
                        return null;
                    }
                } 
                return null;
            }
            
            #endregion

            #region Heal

        public override bool NeedHeal
        {
            get
            {
                if (me.HealthPercent < 60 && !me.Auras.ContainsKey("Renew") && SpellManager.CanCast("Renew"))
                {
                    return true;
                }
                else if (me.HealthPercent < 35)
                {
                    return true;
                }
                return false;
            }
        }

        public override void Heal()
        {
            if (SpellManager.CanCast("Psychic Horror") && mobsTargetingMe.Count > 0)
            {
                mobsTargetingMe[0].Target();
                Thread.Sleep(250);
                SpellManager.Cast("Psychic Horror");
            }
            if (me.HealthPercent < 35)
            {
                if (SpellManager.CanCast("Flash Heal"))
                {
                    new WoWSpellTarget(GetSpell("Flash Heal"), me).TargetCast();
                }
                else if (SpellManager.CanCast("Greater Heal"))
                {
                    new WoWSpellTarget(GetSpell("Greater Heal"), me).TargetCast();
                }
                else if (SpellManager.CanCast("Heal"))
                {
                    new WoWSpellTarget(GetSpell("Heal"), me).TargetCast();
                }
            }
            else if (!me.Auras.ContainsKey("Renew") && SpellManager.CanCast("Renew"))
            {
                new WoWSpellTarget(GetSpell("Renew"), me).TargetCast();
            }
        }

        #endregion

            #region Buffs

        public override bool NeedCombatBuffs
        {
            get
            {
                if (SpellManager.CanCast("Shadowform") && !me.Auras.ContainsKey("Shadowform") && (me.HealthPercent > 60 || (me.HealthPercent > 35 && me.Auras.ContainsKey("Renew"))))
                {
                    return true;
                }
                return false;
            }
        }


        public override void CombatBuff()
        {
            if (SpellManager.CanCast("Shadowform"))
            {
                SpellManager.Cast("Shadowform");
            }
        }
        #endregion


        #endregion

        #region PreCombatbuffs

        public override void PreCombatBuff()
        {
            if (!me.Auras.ContainsKey("Power Word: Fortitude") && SpellManager.CanCast("Power Word: Fortitude"))
            {
                new WoWSpellTarget(GetSpell("Power Word: Fortitude"), me).TargetCast();
            }
            if (!me.Auras.ContainsKey("Inner Fire") && SpellManager.CanCast("Inner Fire"))
            {
                SpellManager.Cast("Inner Fire");
            }
            if (SpellManager.CanCast("Shadowform") && !me.Auras.ContainsKey("Shadowform"))
            {
                SpellManager.Cast("Shadowform");
            }
        }

        public override bool NeedPreCombatBuffs
        {
            get
            {
                if (!me.Auras.ContainsKey("Power Word: Fortitude") && SpellManager.CanCast("Power Word: Fortitude"))
                {
                    return true;
                }
                if (!me.Auras.ContainsKey("Inner Fire") && SpellManager.CanCast("Inner Fire"))
                {
                    return true;
                }
                if (SpellManager.CanCast("Shadowform") && !me.Auras.ContainsKey("Shadowform"))
                {
                    return true;
                }
                return false;
            }
        }

        #endregion

        #region Resting

        public override void Rest()
        {
            if (me.HealthPercent < me.ManaPercent - 25)
            {
                Heal();
            }
            Styx.Logic.Common.Rest.Feed();
        }

        public override bool NeedRest
        {
            get
            {
                if (me.HealthPercent < 60 || me.ManaPercent < 60)
                {
                    return true;
                }
                return false;
            }
        }
        #endregion
    }

    public class WoWSpellTarget
    {
        private WoWSpell wowSpell;
        private WoWUnit wowUnit;

        public WoWSpellTarget(WoWSpell spell, WoWUnit unit)
        {
            wowSpell = spell;
            wowUnit = unit;
        }

        public void TargetCast()
        {
            if (ObjectManager.Me.CurrentTarget != wowUnit)
            {
                wowUnit.Target();
                wowUnit.Face();
                Thread.Sleep(250);
            }
            if (ObjectManager.Me.IsFacing(wowUnit.Location))
            {
                wowUnit.Face();
                Thread.Sleep(250);
            }
            wowSpell.Cast();
        }
               
    }

}
