﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Threading.Tasks;
using CommonBehaviors.Actions;
using Styx;
using Styx.CommonBot.Routines;
using Styx.Common;
using Styx.CommonBot;
using Styx.Helpers;
using Styx.Pathing;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using Styx.TreeSharp;
using Bots.DungeonBuddy.Attributes;
using Bots.DungeonBuddy.Helpers;
using Styx.CommonBot.Coroutines;
using Action = Styx.TreeSharp.Action;
using Buddy.Coroutines;
using Styx.CommonBot.POI;

namespace Bots.DungeonBuddy.Dungeon_Scripts.Burning_Crusade
{
    public class SlavePens : Dungeon
    {
        #region Overrides of Dungeon

        public override uint DungeonId => 140;

        public override Vector3 Entrance => new Vector3(740.8317f, 7013.667f, -72.97391f);

        public override Vector3 ExitLocation => new Vector3(118.778f, -139.3521f, -0.1595907f);

        public override async Task<bool> HandleMovement(MoveToParameters moveToParameters)
        {
            var quagmirran = ObjectManager.GetObjectsOfType<WoWUnit>().FirstOrDefault(u => u.Entry == MobId_Quagmirran);
            if (quagmirran != null && moveToParameters.Location.DistanceSquared(quagmirran.Location) < 3 * 3)
            {
                moveToParameters.DistanceTolerance = 20;
                return (await CommonCoroutines.MoveTo(moveToParameters)).IsSuccessful();
            }
            return false;
        }

        #endregion

        private const uint WastewalkerWorkerId = 17964;
        private const uint WastewalkerSlaveId = 17963;
        private const uint MennuTheBetrayer = 17941;
        private const uint CoilfangSoothsayerId = 17960;
        private const uint CoilfangScaleHealerId = 21126;
        private const uint CoilfangRayId = 21128;
        private const uint CoilfangChampionId = 17957;
        private const uint MennuHealingWard = 20208;
        private const uint TaintedStoneskinTotem = 18177;
       
        /// <summary>
        ///     Dungeon specific unit target removal.
        /// </summary>
        /// <param name="units"> The incomingunits. </param>
        public override void RemoveTargetsFilter(List<WoWObject> units)
        {
            units.RemoveAll(
                u =>
                {
                    var unit = u as WoWUnit;
                    if (unit != null)
                    {
                        if (unit is WoWPlayer)
                            return true;
                        if ((unit.Entry == WastewalkerSlaveId || unit.Entry == WastewalkerWorkerId) && (!unit.Combat || !unit.GotTarget))
                            return false;
                    }
                    return false;
                });
        }

        // for the mennu bossfight.
        public override void IncludeTargetsFilter(List<WoWObject> incomingunits, HashSet<WoWObject> outgoingunits)
        {
            foreach (WoWObject obj in incomingunits)
            {
                if (obj.Entry == MennuHealingWard || obj.Entry == TaintedStoneskinTotem)
                {
                    outgoingunits.Add(obj);
                }
            }
        }

        /// <summary>
        ///     Dungeon specific unit weighting.
        /// </summary>
        /// <param name="units"> The units. </param>
        public override void WeighTargetsFilter(List<Targeting.TargetPriority> units)
        {
            /*
			Information about Tainted Stoneskin Totem
			Name = Tainted Stoneskin Totem
			Wowhead Id = 18177
			Faction = 74 [Naga]
			
			Information about Mennu's Healing Ward
			Name = Mennu's Healing Ward
			Wowhead Id = 20208
			Faction = 74 [Naga]
			
			#1 Boss
			Information about Mennu the Betrayer
			Name = Mennu the Betrayer
			Wowhead Id = 17941
			Faction = 74 [Naga]
			
			#2 Boss
			Information about Rokmar the Crackler
			Name = Rokmar the Crackler
			Wowhead Id = 17991
			Faction = 16 [Monster]
			*/

            foreach (Targeting.TargetPriority p in units)
            {
                var unit = p.Object as WoWUnit;
                if (unit == null) continue;

                if (unit.Entry == MennuHealingWard)
                    p.Score += 4000;
                else if (unit.Entry == TaintedStoneskinTotem)
                    p.Score += 1000;
                else if (unit.Entry == CoilfangChampionId && Me.IsDps)
                    p.Score += 1000;
                else if (unit.Entry == CoilfangSoothsayerId && Me.IsDps)
                    p.Score += 850;
                else if (unit.Entry == CoilfangScaleHealerId && Me.IsDps)
                    p.Score += 800;
                else if (unit.Entry == CoilfangRayId && Me.IsDps)
                    p.Score += 900;
            }
        }

        private LocalPlayer Me => StyxWoW.Me;

        [EncounterHandler(54668, "Nahuud", Mode = CallBehaviorMode.Proximity, BossRange = 30)]
        public Composite QuestPickupHandler()
        {
            WoWUnit unit = null;
            return new PrioritySelector(
                ctx => unit = ctx as WoWUnit,
                new Decorator(
                    ctx => !Me.Combat && !ScriptHelpers.WillPullAggroAtLocation(unit.Location) && unit.QuestGiverStatus == QuestGiverStatus.Available,
                    ScriptHelpers.CreatePickupQuest(ctx => unit)),
                new Decorator(
                    ctx => !Me.Combat && !ScriptHelpers.WillPullAggroAtLocation(unit.Location) && unit.QuestGiverStatus == QuestGiverStatus.TurnIn,
                    ScriptHelpers.CreateTurninQuest(ctx => unit)));
        }

        public Func<WoWUnit, Task<bool>> RootHandler()
        {
            return async boss =>
            {
                return false;
            };
        }

        #region Mennu the Betrayer

        private const uint CorruptedNovaTotem = 18179;

        [EncounterHandler(17941, "Mennu the Betrayer", Mode = CallBehaviorMode.Proximity, BossRange = 80)]
        public Func<WoWUnit, Task<bool>> MennuTheBetrayerEncounter()
        {
            AddAvoidObject<WoWUnit>(() => true, 15f, u => u.Entry == CorruptedNovaTotem);

            return async boss =>
            {
                Vector3 trashPack = new Vector3(50.72f, -380.22f, 3.04f);
                Vector3 pullPosition = new Vector3(85.90821f, -327.0266f, 3.035716f);

                //var area = new []
                //{
                //    new Vector2(98.91142f, -308.0569f),
                //    new Vector2(128.5286f, -327.9367f),
                //    new Vector2(95.35251f, -426.5746f),
                //    new Vector2(-18.23826f, -390.6475f),
                //    new Vector2(-17.11243f, -368.3653f),
                //    new Vector2(34.51196f, -341.5864f),
                //    new Vector2(74.06205f, -333.3246f),
                //};

                //var trash = ScriptHelpers.GetUnfriendlyNpcsAtArea(area, u => u != boss).FirstOrDefault();
                var trash = ScriptHelpers.GetUnfriendlyNpsAtLocation(trashPack, 55, u => u != boss).FirstOrDefault();
                if (trash == null)
                    return false;

                return await ScriptHelpers.PullNpcToLocation(() => boss.Location.DistanceSquared(trashPack) >= 40, trash, pullPosition, 5000);
            };
        }

        #endregion

        [EncounterHandler(54667, "Watcher Jhang", Mode = CallBehaviorMode.Proximity, BossRange = 30)]
        public Composite WatcherJhangQuestHandler()
        {
            const int theHeartOfTheMatterQuestId = 29565;

            WoWUnit unit = null;
            return new PrioritySelector(
                ctx => unit = ctx as WoWUnit,
                new Decorator(
                    ctx =>
                    !Me.Combat && !ScriptHelpers.WillPullAggroAtLocation(unit.Location) && unit.QuestGiverStatus == QuestGiverStatus.Available &&
                    Me.QuestLog.GetQuestById(theHeartOfTheMatterQuestId) == null && Me.QuestLog.GetCompletedQuests().All(q => q != theHeartOfTheMatterQuestId),
                    ScriptHelpers.CreatePickupQuest(ctx => unit, theHeartOfTheMatterQuestId)),
                new Decorator(
                    ctx => !Me.Combat && !ScriptHelpers.WillPullAggroAtLocation(unit.Location) && unit.QuestGiverStatus == QuestGiverStatus.TurnIn,
                    ScriptHelpers.CreateTurninQuest(ctx => unit)));
        }

        #region Quagmire

        /*
        #region Naturalist Blite

        [EncounterHandler(17893, "Naturalist Blite", Mode = CallBehaviorMode.Proximity, BossRange = 100)]
        public Func<WoWUnit, Task<bool>> NaturalistBliteEncounter()
        {
            return async npc =>
            {
                bool hasAura = Me.HasAura("Mark of Bite");
                if (hasAura)
                    return false;

                const uint bliteCage = 182094;
                WoWGameObject cage = ObjectManager.GetObjectsOfType<WoWGameObject>().FirstOrDefault(g => g.Entry == bliteCage);
                if (cage != null)
                    return await ScriptHelpers.TalkToNpc(npc, 1);

                return false;
            };
        }

        #endregion*/
        private readonly Vector3 _quagmirranTankSpot = new Vector3(-264.7566f, -699.435f, 37.4649f);
        private const uint MobId_Quagmirran = 17942;

        [EncounterHandler(MobId_Quagmirran, "Quagmirran", BossRange = 100, Mode = CallBehaviorMode.Proximity)]
        public Func<WoWUnit, Task<bool>> QuagmirranEncounter()
        {
            AddAvoidUnitCone(() => !Me.IsTank(), 0, 40, 180, u => u.Entry == MobId_Quagmirran && u.IsCasting && !u.IsMoving && u.Combat);

            return async boss =>
            {
                if (Targeting.Instance.FirstUnit != null && Targeting.Instance.FirstUnit == boss)
                {
                    if (Me.IsTank())
                    {
                        if (boss.IsCasting)
                        {
                            WoWClass playerClass = Me.Class;

                            // taunt boss when he does the acid spray thing to make him face tank.
                            if (playerClass == WoWClass.Warrior && SpellManager.CanCast("Taunt"))
                                return SpellManager.Cast("Taunt", boss);

                            if (playerClass == WoWClass.DeathKnight && SpellManager.CanCast("Dark Command"))
                                return SpellManager.Cast("Dark Command", boss);

                            if (playerClass == WoWClass.Paladin && SpellManager.CanCast("Hand of Reckoning"))
                                return SpellManager.CanCast("Hand of Reckoning", boss);

                            if (playerClass == WoWClass.Monk && SpellManager.CanCast("Provoke"))
                                return SpellManager.CanCast("Provoke", boss);
                        }

                        if (await ScriptHelpers.TankUnitAtLocation(_quagmirranTankSpot, 17f))
                            return true;

                        if (await ScriptHelpers.TankFaceUnitAwayFromGroup(40))
                            return true;
                    }
                }

                // Clear the area first.
                Vector3 trashPack = new Vector3(-176.21f, -769.63f, 41.97f);

                if (BotPoi.Current.Type != PoiType.None || !Targeting.Instance.IsEmpty())
                    return false;

                if (ScriptHelpers.GetUnfriendlyNpsAtLocation(trashPack, 45, u => u != boss).Any())
                {
                    await ScriptHelpers.ClearArea(trashPack, 30f, u => u != boss);
                    return false;
                }

                return false;
            };
        }
        

        

        #endregion
    }

    public class SlavePensHeroic : SlavePens
    {
        public override uint DungeonId => 184;
    }

    public class SlavePensTimewalking : SlavePens
    {
        public override uint DungeonId => 1015;
    }
}