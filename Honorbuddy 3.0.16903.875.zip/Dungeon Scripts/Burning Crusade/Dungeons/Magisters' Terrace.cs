using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;
using Styx;
using Styx.CommonBot;
using Styx.CommonBot.Coroutines;
using Styx.CommonBot.POI;
using Styx.Pathing;
using Styx.TreeSharp;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using Bots.DungeonBuddy.Attributes;
using Bots.DungeonBuddy.Helpers;
using Bots.DungeonBuddy.Enums;
using Styx.Common;
using Styx.Common.Helpers;

namespace Bots.DungeonBuddy.Dungeon_Scripts.Burning_Crusade
{
    public class MagistersTerrace : Dungeon
    {
        #region Overrides of Dungeon

        public override uint DungeonId { get { return 198; } }

        public override Vector3 Entrance { get { return new Vector3(12882.49f, -7341.705f, 65.53025f); } }

        public override Vector3 ExitLocation { get { return new Vector3(-5.751736f, 0.2760417f, -0.2375327f); } }

        public override bool IsComplete
        {
            get
            {
                return base.IsComplete
                       &&
                       (!ScriptHelpers.HasQuest(HardToKillQuestId) ||
                        !ScriptHelpers.IsQuestInLogComplete(HardToKillQuestId))
                       &&
                       (!ScriptHelpers.HasQuest(ARadicalNotionQuestId) ||
                        !ScriptHelpers.IsQuestInLogComplete(ARadicalNotionQuestId))
                       &&
                       (!ScriptHelpers.HasQuest(TwistedAssociationsQuestId) ||
                        !ScriptHelpers.IsQuestInLogComplete(TwistedAssociationsQuestId));
            }
        }


        public override void IncludeLootTargetsFilter(List<WoWObject> incomingunits, HashSet<WoWObject> outgoingunits)
        {
            // if looting bosses then we don't need to proceed.
            if (DungeonBuddySettings.Instance.LootMode != LootMode.Off)
                return;

            var needItemOffKael = ScriptHelpers.HasQuest(HardToKillQuestId)
                                  && !ScriptHelpers.IsQuestInLogComplete(HardToKillQuestId);

            var needItemOffVexallus = ScriptHelpers.HasQuest(ARadicalNotionQuestId)
                                      && !ScriptHelpers.IsQuestInLogComplete(ARadicalNotionQuestId);

            // we only require special loot handling for quest item pickup
            if (!needItemOffKael && !needItemOffVexallus)
                return;

            foreach (var unit in incomingunits.OfType<WoWUnit>())
            {
                // make sure quest items gets looted off bosses.
                if (needItemOffKael && unit.Entry == KaelthasSunstriderId && unit.CanLoot)
                    outgoingunits.Add(unit);

                if (needItemOffVexallus && unit.Entry == VexallusId && unit.CanLoot)
                    outgoingunits.Add(unit);
            }
        }

        const uint MobId_PhoenixEgg = 24675;
        const uint MobId_FelCrystal = 24722;

        public override void IncludeTargetsFilter(List<WoWObject> incomingObjects, HashSet<WoWObject> outgoingObjects)
        {
            foreach (var obj in incomingObjects)
            {
                WoWUnit u = obj.ToUnit();

                if (u != null && u.CanSelect && (u.Entry == MobId_PhoenixEgg || u.Entry == MobId_FelCrystal))
                    outgoingObjects.Add(obj);
            }
        }

        private const uint MobId_PureEnergy = 24745;

        public override void WeighTargetsFilter(List<Targeting.TargetPriority> objPriorities)
        {
            foreach (var prio in objPriorities)
            {
                const uint phoenixEggId = 24675;
                const uint phoenixId = 24674;

                WoWUnit u = prio.Object.ToUnit();
                if (u != null && (u.Entry == phoenixEggId || u.Entry == phoenixId || u.Entry == MobId_FelCrystal || u.Entry == MobId_PureEnergy))
                {
                    prio.Score += 5000;
                }
            }
        }

        #endregion

        #region Root

        private LocalPlayer Me { get { return StyxWoW.Me; } }

        private const uint ARadicalNotionQuestId = 29686;
        private const uint TwistedAssociationsQuestId = 29687;
        private const uint TheScryersScryerQuestId = 11490;
        private const uint HardToKillQuestId = 29685;

        private const uint KaelthasSunstriderId = 24664;
        private const uint KalecgosId = 24848;
        private const uint VexallusId = 24744;

        [EncounterHandler(55007, "Exarch Larethor", Mode = CallBehaviorMode.Proximity)]
        [EncounterHandler(24822, "Tyrith", Mode = CallBehaviorMode.Proximity, BossRange = 40)]
        [EncounterHandler(24848, "Kalecgos", Mode = CallBehaviorMode.Proximity, BossRange = 40)]
        public async Task<bool> QuestPickupTurninBehavior(WoWUnit npc)
        {
            if (Me.Combat || ScriptHelpers.WillPullAggroAtLocation(npc.Location))
                return false;
            // pickup or turnin quests if any are available.
            return npc.HasQuestAvailable(true)
                ? await ScriptHelpers.PickupQuest(npc)
                : npc.HasQuestTurnin() && await ScriptHelpers.TurninQuest(npc);
        }


        [ObjectHandler(187578, "Scrying Orb", ObjectRange = 35)]
        public async Task<bool> ScryingOrbHandler(WoWGameObject gObj)
        {
            if (!ScriptHelpers.HasQuest(TheScryersScryerQuestId))
                return false;

            if (await ScriptHelpers.CancelCinematicIfPlaying())
                return true;

            if (ScriptHelpers.IsQuestInLogComplete(TheScryersScryerQuestId))
            {
                var kalecgos = ObjectManager.GetObjectsOfType<WoWUnit>().FirstOrDefault(u => u.Entry == KalecgosId);
                // wait for kalecgos to spawn.
                return kalecgos == null;
            }

            return await ScriptHelpers.InteractWithObject(gObj, 5000);
        }


        [ObjectHandler(188173, "Use object to port outside", ObjectRange = 100)]
        public async Task<bool> PortOutsideFarmMode(WoWGameObject obj)
        {
            return DungeonBuddySettings.Instance.DungeonType == DungeonType.Farm && IsComplete
                   && BotPoi.Current.Type == PoiType.None
                   && await ScriptHelpers.InteractWithObject(obj);
        }

        #endregion

        #region Trash/Safe pulling

        [LocationHandler(127.1436f, -175.8809f, -21.41846f, 40, "Area before Delrissa")]
        public Func<Vector3, Task<bool>> TrashHandlers()
        {
            Vector3 trashPackCenter = new Vector3(127.1604f, -130.9153f, -19.77326f);

            var lineStart = new Vector3(137.9934f, -181.1995f, -21.43855f); 
            var lineEnd = new Vector3(115.1176f, -181.1828f, -21.43628f);

            Vector3 pullPosition = new Vector3(127.0301f, -181.6251f, -21.42013f);

            return async loc =>
            {
                if (!Me.Location.IsPointLeftOfLine(lineStart, lineEnd))
                    return false;

                return await HandleTrashPulling(pullPosition, trashPackCenter, lineStart, lineEnd);
            };
        }

        private async Task<bool> HandleTrashPulling(Vector3 pullPosition, Vector3 trashPackCenter, Vector3 lineStart, Vector3 lineEnd, float radius = 50, int pullWaitTime = 6000)
        {
            List<WoWUnit> trashMobs = ScriptHelpers.GetUnfriendlyNpsAtLocation(trashPackCenter, radius);
            if (trashMobs.Count <= 4)
                return false;

            var trash = trashMobs.FirstOrDefault();
            if (trash == null)
                return false;

            bool meIsLeftOfLine = Me.Location.IsPointLeftOfLine(lineStart, lineEnd);

            WoWUnit manaUser = Targeting.Instance.TargetList.FirstOrDefault(u => u.PowerType == WoWPowerType.Mana);
            // Ignore if there's spellcasters in the targeting list.
            if (!Me.IsTank() && meIsLeftOfLine && manaUser == null)
            {
                await CommonCoroutines.MoveTo(pullPosition);
                return true;
            }

            return await ScriptHelpers.PullNpcToLocation(() => ScriptHelpers.IsViable(trash), trash, pullPosition, pullWaitTime);
        }

        #endregion

        #region Selin Fireheart

        [EncounterHandler(24723, "Selin Fireheart", Mode = CallBehaviorMode.Proximity)]
        public Func<WoWUnit, Task<bool>> SelinFireheartEncounter()
        {
            var insideDoor = new Vector3(220.0599f, 0.4775179f, -2.847029f);
            var doorLeftSide = new Vector3(214.8013f, 5.930538f, -2.826467f);
            var doorRightSide = new Vector3(214.563f, -5.284084f, -2.908259f);

            return async boss =>
            {
                if (!boss.Combat)
                {
                    var myLoc = Me.Location;

                    // move in the room if not inside already.
                    if (!myLoc.IsPointLeftOfLine(doorLeftSide, doorRightSide)
                        || myLoc.GetNearestPointOnSegment(doorLeftSide, doorRightSide).DistanceSquared(myLoc) < 2 * 2)
                    {
                        return (await CommonCoroutines.MoveTo(insideDoor)).IsSuccessful();
                    }

                    // Extra check to make sure everyone is inside before clearing the area.
                    if (Me.IsTank())
                    {
                        if (!Me.PartyMembers.All(p => p.Location.IsPointLeftOfLine(doorLeftSide, doorRightSide)))
                            return true;
                    }

                    var clearedRoom = !ScriptHelpers.GetUnfriendlyNpsAtLocation(insideDoor, 25, u => u != boss).Any();
                    if (clearedRoom)
                    {
                        if (Me.IsLeader())
                        {
                            return (await CommonCoroutines.MoveTo(boss.Location)).IsSuccessful();
                        }
                    }
                    else
                    {
                        var trashPackCenter = new Vector3(228.2339f, -3.076817f, -2.916973f);
                        var trash = ScriptHelpers.GetUnfriendlyNpsAtLocation(trashPackCenter, 50, u => u != boss).FirstOrDefault();
                        if (trash == null)
                            return false;

                        return await ScriptHelpers.PullNpcToLocation(() => ScriptHelpers.IsViable(trash), trash, insideDoor, 6000);
                    }
                }
                return false;
            };
        }

        #endregion

        #region Priestess Delreissa

        private const uint MobId_PriestessDelreissa = 24560;

        [EncounterHandler(MobId_PriestessDelreissa, "Priestess Delreissa", Mode = CallBehaviorMode.Proximity, BossRange = 90)]
        public Func<WoWUnit, Task<bool>> PriestessDelreissaEncounter()
        {
            return async boss =>
            {
                // Make sure this doesn't run when we are at the entrance...
                if (boss.Combat || boss.ZDiff > 10f)
                    return false;

                HashSet<uint> unwantedPulls = new HashSet<uint>
                {
                    24556, // Zelfan
                    24553, // Apoko
                    24555, // Garaxxas
                    24559, //Warlord Salaris
                    24561, // Yazzai
                    24554, // Eramas Brightblaze
                    24558, // Ellrys Duskhallow
                    24557, // Kagani Nightstrike
                };

                var trashpackCenter = new Vector3(126.6451f, -15.53155f, -20.0049f);
                var pullLocation = new Vector3(126.6242f, -58.54908f, -21.41323f);

                var trash = ScriptHelpers.GetUnfriendlyNpsAtLocation(trashpackCenter, 90, u => u.Elite && u != boss && !unwantedPulls.Contains(u.Entry)).FirstOrDefault();
                if (trash == null)
                    return false;

                return await ScriptHelpers.PullNpcToLocation(() => ScriptHelpers.IsViable(trash), trash, pullLocation, 6000);
            };
        }

        #endregion

        #region Vexallus

        private const uint MobId_Vexallus = 24744;

        [EncounterHandler(MobId_Vexallus, "Vexallus", Mode = CallBehaviorMode.Proximity)]
        public Func<WoWUnit, Task<bool>> VexallusEncounter()
        {
            return async boss => false;
        }

        #endregion

        #region Kael'thas Sunstrider

        private const uint MobId_KaelThasSunstrider = 24664;
        private const uint MobId_ArcaneSphere = 24708;

        private List<BoundingSphere> ArcaneSpheres => ObjectManager.GetObjectsOfType<WoWUnit>().Where(u => u.Entry == MobId_ArcaneSphere).Select(u => new BoundingSphere(u.Location, 15f)).ToList();

        private bool IsPointInSphere(Vector3 position, BoundingSphere sphere)
        {
            float radius = sphere.Radius;
            return position.DistanceSquared(sphere.Center) <= radius*radius;
        }

        private WaitTimer _moveOutOfSphereTimer = WaitTimer.FiveSeconds;

        private readonly HashSet<Vector3> _arcaneSphereAvoidPoints = new HashSet<Vector3>()
            {
                new Vector3(146.4634f, 166.6298f, -8f),
                new Vector3(160.5431f, 188.5492f, -8f),
                new Vector3(135.3072f, 187.2243f, -8f),
                new Vector3(129.448f, 168.2125f, -8f),
                new Vector3(167.1732f, 167.2784f, -8f),
                new Vector3(148.3326f, 159.6411f, -8f)
            };

        private Vector3 _moveToPoint = Vector3.Zero;
        [EncounterHandler(MobId_KaelThasSunstrider, "Kael'thas Sunstrider", Mode = CallBehaviorMode.Proximity)]
        public Func<WoWUnit, Task<bool>> KaelThasSunstriderEncounter()
        {
            return async boss =>
            {
                if (_moveToPoint != Vector3.Zero && Me.Location.DistanceSquared(_moveToPoint) < 3*3 && Me.IsMelee())
                    WoWMovement.ClickToMove(boss.Location);

                if (Me.HasAura("Gravity Lapse") && _moveOutOfSphereTimer.IsFinished)
                {
                    foreach (BoundingSphere sphere in ArcaneSpheres)
                    {
                        bool inSphere = IsPointInSphere(Me.Location, sphere);
                        if (inSphere)
                        {
                            // Find a point to move to to get out.
                            var availablePoints = _arcaneSphereAvoidPoints.Where(p => !IsPointInSphere(p, sphere)).ToList();
                            Vector3 moveTo = availablePoints[ScriptHelpers.Rnd.Next(0, availablePoints.Count)];
                            _moveToPoint = moveTo;

                            WoWMovement.ClickToMove(moveTo);
                            _moveOutOfSphereTimer.Reset();
                            return true;
                        }
                    }
                }

                return false;
            };
        }

        #endregion
    }

    public class MagistersTerraceHeroic : MagistersTerrace
    {
        public override uint DungeonId => 201;
    }

    public class MagistersTerraceTimewalking : MagistersTerrace
    {
        public override uint DungeonId => 1154;
    }
}