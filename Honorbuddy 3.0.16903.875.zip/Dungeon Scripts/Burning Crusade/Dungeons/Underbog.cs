using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using Styx;
using Styx.Common;
using Styx.CommonBot;
using Styx.CommonBot.Coroutines;
using Styx.CommonBot.POI;
using Styx.Pathing;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using Styx.TreeSharp;

using Bots.DungeonBuddy.Attributes;
using Bots.DungeonBuddy.Forms;
using Bots.DungeonBuddy.Helpers;
using Action = Styx.TreeSharp.Action;

namespace Bots.DungeonBuddy.Dungeon_Scripts.Burning_Crusade
{
    public class Underbog : Dungeon
    {
        #region Overrides of Dungeon

        public override Vector3 Entrance
        {
            get { return new Vector3(780.7808f, 6745.077f, -72.53828f); }
        }

        public override Vector3 ExitLocation
        {
            get { return new Vector3(4.695599f, -11.38073f, -2.751475f); }
        }

        public override uint DungeonId
        {
            get { return 146; }
        }

        public override void RemoveTargetsFilter(List<WoWObject> units)
        {
            units.RemoveAll(
                unit =>
                {
                    // remove Ghaz'an if swiming around.
                    if (unit.Entry == GhazanId && unit.Z < 70)
                        return true;
                    return false;
                });
        }


        public override void WeighTargetsFilter(List<Targeting.TargetPriority> units)
        {
            foreach (var targetPriority in units)
            {
                switch (targetPriority.Object.Entry)
                {
                    case MurkbloodHealerId:
                        if (StyxWoW.Me.IsDps)
                            targetPriority.Score += 220;
                        break;
                }
            }
        }

        public override void IncludeLootTargetsFilter(List<WoWObject> incomingunits, HashSet<WoWObject> outgoingunits)
        {
            var gatherHibiscus = ScriptHelpers.HasQuest(BringMeAShrubberyQuestId)
                && !ScriptHelpers.IsQuestInLogComplete(BringMeAShrubberyQuestId);
            foreach (var gObj in incomingunits.OfType<WoWGameObject>())
            {
                if (gObj.Entry == SanguineHibiscusId && gatherHibiscus
                    && !Me.Combat && gObj.DistanceSqr < 30 * 30
                    && !ScriptHelpers.WillPullAggroAtLocation(gObj.Location))
                {
                    outgoingunits.Add(gObj);
                }
            }
        }

        public override async Task<bool> HandleMovement(MoveToParameters moveToParameters)
        {
            var ghazan = ObjectManager.GetObjectsOfType<WoWUnit>().FirstOrDefault(u => u.Entry == GhazanId);
            moveToParameters.AllowSurfaceSnappingWhileSwimming = false;
            if (ghazan != null && moveToParameters.Location.DistanceSquared(ghazan.Location) < 3 * 3)
            {
                // boss moves around fast while swimming and it caused bot to constantly regen path if attempting to move to boss's location, so we 
                // make it move to some static location instead.
                if (ghazan.Z < 60)
                    return (await CommonCoroutines.MoveTo(_ghazanTankSpot, ghazan.SafeName)).IsSuccessful();

                moveToParameters.DistanceTolerance = 20;
                return (await CommonCoroutines.MoveTo(moveToParameters)).IsSuccessful();
            }
            return false;
        }

        #endregion

        #region Root

        private LocalPlayer Me => StyxWoW.Me;

        private const uint SanguineHibiscusId = 183385;
        private const uint RescuingTheExpeditionQuestId = 29570;
        private const uint BringMeAShrubberyQuestId = 29691;
        private const uint StalkTheStalkerQuestId = 29567;
        private const uint ANecessaryEvilQuestId = 29568;
        private static readonly uint[] s_entraceQuestIds =
        {
            RescuingTheExpeditionQuestId, BringMeAShrubberyQuestId, StalkTheStalkerQuestId, ANecessaryEvilQuestId
        };
        private const uint GhazanId = 18105;
        private const uint MurkbloodHealerId = 17730;
        private readonly Vector3 _ghazanFollowerWaitSpot = new Vector3(162.3641f, -445.7501f, 72.43507f);
        private readonly Vector3 _ghazanTankSpot = new Vector3(152.2157f, -467.3924f, 75.0878f);
        private WoWUnit _hungarfen;
        private readonly Vector3 _lastBossLocation = new Vector3(150.6087f, 21.06009f, 26.84999f);

        [EncounterHandler(0)]
        public async Task<bool> RootBehavior()
        {
            if (Me.IsSwimming && Me.X < 160 && !Me.Combat)
            {
                ScriptHelpers.TelportOutsideLfgInstance();
                return true;
            }
            // port outside and back in to hand in quests once dungeon is complete.
            // QuestPickupTurninHandler will handle the turnin
            return IsComplete && !Me.Combat
                    && s_entraceQuestIds.Any(ScriptHelpers.IsQuestInLogComplete)
                    && BotPoi.Current.Type == PoiType.None
                    && Me.Location.DistanceSquared((Vector3)_lastBossLocation) < 50 * 50
                    && await ScriptHelpers.PortOutsideAndBackIn();
        }



        [EncounterHandler(54678, "Naturalist Bite", Mode = CallBehaviorMode.Proximity, BossRange = 30)]
        [EncounterHandler(54674, "T'shu", Mode = CallBehaviorMode.Proximity, BossRange = 30)]
        [EncounterHandler(54675, "Watcher Jhang", Mode = CallBehaviorMode.Proximity, BossRange = 30)]
        public async Task<bool> QuestPickupTurninHandler(WoWUnit npc)
        {
            if (Me.Combat || ScriptHelpers.WillPullAggroAtLocation(npc.Location))
                return false;
            return npc.HasQuestAvailable()
                ? await ScriptHelpers.PickupQuest(npc)
                : npc.HasQuestTurnin() && await ScriptHelpers.TurninQuest(npc);
        }

        private const uint EarthbinderRaygeId = 17885;

        [LocationHandler(296.6974, -362.373, 50.15062, 65, "Earthbinder Rayge Area")]
        public async Task<bool> EarthbinderRaygeFindHandler(Vector3 location)
        {
            if (Me.Combat)
                return false;

            if (!ScriptHelpers.HasQuest(RescuingTheExpeditionQuestId))
                return false;
            if (ScriptHelpers.IsQuestInLogComplete(RescuingTheExpeditionQuestId))
                return false;
            if (ScriptHelpers.IsQuestObjectiveComplete(1, RescuingTheExpeditionQuestId))
                return false;

            var rayge = ObjectManager.GetObjectsOfType<WoWUnit>()
                .FirstOrDefault(u => u.Entry == EarthbinderRaygeId);

            if (rayge == null)
                return (await CommonCoroutines.MoveTo(location)).IsSuccessful();
            return await ScriptHelpers.TalkToNpc(rayge);
        }

        [EncounterHandler(17894, "Windcaller Claw", Mode = CallBehaviorMode.Proximity, BossRange = 85)]
        public async Task<bool> WindcallerClawEncounter(WoWUnit npc)
        {
            if (Me.Combat || npc.IsHostile)
                return false;

            if (!ScriptHelpers.HasQuest(RescuingTheExpeditionQuestId))
                return false;
            if (ScriptHelpers.IsQuestInLogComplete(RescuingTheExpeditionQuestId))
                return false;

            if (ScriptHelpers.IsQuestObjectiveComplete(2, RescuingTheExpeditionQuestId))
                return false;

            return await ScriptHelpers.TalkToNpc(npc);
        }

        #endregion



        [EncounterHandler(17770, "Hungarfen")]
        public Composite HungarfenEncounter()
        {
            const uint underbogMushroomId = 17990;

            AddAvoidObject(() => !Me.IsCasting, 10, underbogMushroomId);

            return new PrioritySelector(ctx => _hungarfen = ctx as WoWUnit, ScriptHelpers.CreateSpreadOutLogic(ctx => true, ctx => _hungarfen.Location, 10, 30));
        }


        private const uint MobId_Ghazan = 18105;

        [EncounterHandler(18105, "Ghaz'an", Mode = CallBehaviorMode.Proximity, BossRange = 105)]
        public Composite GhazanEncounter()
        {
            AddAvoidUnitCone(() => !Me.IsTank(), 0, 20, 100, u => u.Entry == MobId_Ghazan && u.CurrentTarget != Me && u.Combat);
            AddAvoidUnitCone(() => !Me.IsTank(), 180, 20, 100, u => u.Entry == MobId_Ghazan && u.CurrentTarget != Me && u.Combat);
            WoWUnit boss = null;
            return new PrioritySelector(
                ctx => boss = ctx as WoWUnit,
                // pull boss. check if he's not in the water first.
                new Decorator(
                    ctx => StyxWoW.Me.IsTank() && (Targeting.Instance.IsEmpty() || Targeting.Instance.FirstUnit.Entry == GhazanId) && boss.Z > 70 && Me.Y < -435,
                    new Sequence(
                        new DecoratorContinue(ctx => Me.CurrentTargetGuid != boss.Guid,
                            new Action(ctx => boss.Target())),
                        ScriptHelpers.CreateMoveToContinue(ctx => boss.Distance > 30, ctx => boss, false),
                        ScriptHelpers.CreateCastRangedAbility(),
                        ScriptHelpers.CreateMoveToContinue(ctx => _ghazanTankSpot))),
                // wait for tank to move in place.
                ScriptHelpers.CreateWaitAtLocationUntilTankPulled(ctx => StyxWoW.Me.Location.DistanceSquared((Vector3)_ghazanFollowerWaitSpot) < 15 * 15, ctx => _ghazanFollowerWaitSpot),
                new Decorator(ctx => boss.CurrentTargetGuid == Me.Guid && Me.IsTank(), ScriptHelpers.CreateTankUnitAtLocation(ctx => _ghazanTankSpot, 5f)));
        }

        [EncounterHandler(17826, "Swamplord Musel'ek", Mode = CallBehaviorMode.Proximity, BossRange = 100)]
        public Composite SwamplordMuselekEncounter()
        {
            return new PrioritySelector(
                ScriptHelpers.CreateClearArea(() => new Vector3(214.0852f, -131.6859f, 27.32064f), 50f, u => u.Entry == 17734) // kill the Underbog Lord
                );
        }

        [EncounterHandler(17882, "The Black Stalker")]
        public Composite TheBlackStalkerEncounter()
        {
            return new PrioritySelector(
                ScriptHelpers.CreateSpreadOutLogic(ctx => true, ctx => ScriptHelpers.Tank.Location, 13, 30f) // spread out
                );
        }
    }

    public class UnderbogHeroic : Underbog
    {
        public override uint DungeonId => 186;
    }
}