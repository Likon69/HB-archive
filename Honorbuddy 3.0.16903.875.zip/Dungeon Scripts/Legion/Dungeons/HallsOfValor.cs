﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Numerics;
using System.Threading.Tasks;
using System.Windows.Markup;
using Bots.DungeonBuddy.Attributes;
using Bots.DungeonBuddy.Enums;
using Bots.DungeonBuddy.Helpers;
using Buddy.Coroutines;
using Styx;
using Styx.Common;
using Styx.Common.Helpers;
using Styx.CommonBot;
using Styx.CommonBot.Bars;
using Styx.CommonBot.Coroutines;
using Styx.CommonBot.Frames;
using Styx.CommonBot.POI;
using Styx.CommonBot.Routines;
using Styx.Helpers;
using Styx.Pathing;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using Styx.WoWInternals.WoWObjects.AreaTriggerShapes;

// ReSharper disable CheckNamespace

namespace Bots.DungeonBuddy.DungeonScripts.Legion
// ReSharper restore CheckNamespace
{
    #region Normal Difficulty

    public class HallsOfValor : Dungeon
    {
        #region Overrides of Dungeon

        public override uint DungeonId => 1193;

        public override Vector3 Entrance { get; } = new Vector3(2453.057f, 813.8594f, 252.9257f);

        public override Vector3 ExitLocation => new Vector3(3817.4f, 529.1859f, 605.2512f);

        public override void RemoveTargetsFilter(List<WoWObject> units)
        {
            units.RemoveAll(
                ret =>
                {
                    var unit = ret as WoWUnit;
                    if (unit == null)
                        return false;

                    if (unit.Entry == MobId_Odyn && unit.CastingSpellId == SpellId_RadiantTempest && Me.IsMelee)
                        return true;

                    return false;
                });
        }

        public override void IncludeTargetsFilter(List<WoWObject> incomingunits, HashSet<WoWObject> outgoingunits)
        {
            foreach (var obj in incomingunits)
            {
                var unit = obj as WoWUnit;
                if (unit != null)
                {
                }
            }
        }

        public override void WeighTargetsFilter(List<Targeting.TargetPriority> units)
        {
            var isDps = Me.IsDps;

            foreach (var priority in units)
            {
                var unit = priority.Object as WoWUnit;
                if (unit != null)
                {
                    switch (unit.Entry)
                    {
                        case MobId_ValarjarPurifier:
                        case MobId_HonoredAncestor:
                            if (isDps)
                                priority.Score += 5000;
                            break;
                        case MobId_ValarjarAspirant:
                            if (isDps)
                                priority.Score += 5500;
                            break;
                    }
                }
            }
        }

        public override void IncludeLootTargetsFilter(List<WoWObject> incomingunits, HashSet<WoWObject> outgoingunits)
        {
            if (DungeonBuddySettings.Instance.LootMode == LootMode.Off)
                return;
            foreach (var lootTarget in incomingunits)
            {
                var gObj = lootTarget as WoWGameObject;
                if (gObj != null && gObj.Entry == GameObjectId_SpoilsOfTheWorthy && gObj.CanUse())
                    outgoingunits.Add(gObj);
            }
        }

        public override void OnEnter()
        {
            var displayPugGroupWarning = DungeonBuddySettings.Instance.PartyMode == PartyMode.Off ||
                (DungeonBuddySettings.Instance.PartyMode == PartyMode.Leader &&
                DungeonBuddySettings.Instance.PartyMembers.Count(s => !string.IsNullOrWhiteSpace(s)) < 4);

            if (displayPugGroupWarning)
            {
                Alert.Show(
                    "Dungeon not tested in PUGs",
                    $"{Name} dungeon has not been tested in PUGs so it's very important to not leave toon unattended",
                    15);
            }
        }

        public override DungeonStuckHandler[] StuckHandlers { get; } = {
            new BarrelStuckHandler(),
            new WaterFallStuckHandler(),
            new SimpleCtmStuckHandler(new Vector3(3327.432f, 497.6187f, 635.7642f), 3, 2,
                new Vector3(3318.944f, 497.7399f, 635.7814f), "Stuck between barrels2")
        };
        private class BarrelStuckHandler : DungeonStuckHandler
        {
            private readonly Vector3 _stuckLocation = new Vector3(3116.23f, 3171.34f, 593.2728f);

            protected override bool IsStuck
                => StyxWoW.Me.Location.DistanceSquared(_stuckLocation) < 2 * 2;

            protected override Vector3 UnstickMoveTo { get; } = new Vector3(3112.697f, 3174.921f, 594.2195f);
            protected override string StuckAreaName { get; } = "Stuck between barrels";

            protected override async Task Unstick()
            {
                Navigator.PlayerMover.MoveTowards(UnstickMoveTo);
                WoWMovement.Move(WoWMovement.MovementDirection.Forward, 1000);
                WoWMovement.Move(WoWMovement.MovementDirection.JumpAscend, 1000);
                await Coroutine.Wait(1000, () => !IsStuck);
            }
        }

        private class WaterFallStuckHandler : DungeonStuckHandler
        {
            private readonly Vector3 _stuckLocation = new Vector3(2991.42f, 3125.29f, 582.8854f);
            protected override bool IsStuck
                => StyxWoW.Me.Location.DistanceSquared(_stuckLocation) < 6 * 6 && Me.Z > 581;

            protected override Vector3 UnstickMoveTo { get; } = new Vector3(2997.748f, 3127.675f, 580.0848f);
            protected override string StuckAreaName { get; } = "Stuck under waterfall";

        }

        private class SimpleCtmStuckHandler : DungeonStuckHandler
        {
            private Vector3 _stuckLocation;
            private readonly float _stuckRadius;
            private readonly float _stuckAreaZDiff;

            public SimpleCtmStuckHandler(Vector3 stuckLocation, float stuckRadius, float stuckAreaZDiff, Vector3 ctmLocation,
                string name)
            {
                _stuckLocation = stuckLocation;
                _stuckRadius = stuckRadius;
                _stuckAreaZDiff = stuckAreaZDiff;
                UnstickMoveTo = ctmLocation;
                StuckAreaName = name;
            }

            protected override bool IsStuck
                =>
                    StyxWoW.Me.Location.DistanceSquared(_stuckLocation) < _stuckRadius * _stuckRadius &&
                    Math.Abs(Me.Z - _stuckLocation.Z) < _stuckAreaZDiff;

            protected override Vector3 UnstickMoveTo { get; }
            protected override string StuckAreaName { get; }
        }       

        public override async Task<bool> HandleMovement(MoveToParameters moveToParameters)
        {
            var destination = moveToParameters.Location;
            if (await HandlePortals(destination))
                return true;

            return false;
        }

        private static readonly Vector3 s_portalTofieldsOfEternalLoc = new Vector3(3231.198f, 653.467f, 633.1288f);
        private static readonly Vector3 s_portalToFieldsOfEternalHotspot = new Vector3(3234.421f, 647.592f, 634.1361f);
        private static readonly Vector3 s_portalFromfieldsOfEternalLoc = new Vector3(3210.003f, 2902.552f, 641.6155f);
        private static readonly Vector3 s_portalFromfieldsOfEternalHotspot = new Vector3(3201.973f, 2904.199f, 641.2003f);

        private async Task<bool> HandlePortals(Vector3 destination)
        {
            if (!BotPoi.Current.Type.IsOneOf(PoiType.None, PoiType.Hotspot))
                return false;

            var myLoc = (Me ?? WoWMovement.ActiveMover).Location;

            // both start and end locations are in same area
            if (InFieldsOfEternalHunt(myLoc) == InFieldsOfEternalHunt(destination))
                return false;

            Vector3 portalLoc, hotspotLoc;
            if (InFieldsOfEternalHunt(destination))
            {
                portalLoc = s_portalTofieldsOfEternalLoc;
                hotspotLoc = s_portalToFieldsOfEternalHotspot;
            }
            else
            {
                portalLoc = s_portalFromfieldsOfEternalLoc;
                hotspotLoc = s_portalFromfieldsOfEternalHotspot;
            }

            // We need to use hotspots when traveling long distance to avoid getting stuck because of long distance path generations getting throttled
            // Also we can't navigate to portal directly using hotspots because hotspot is cleared only when we arrive at hotspot 
            // and we can never arrive at portal location because we get teleported away
            if (myLoc.DistanceSquared(portalLoc) > 40 * 40)
            {
                if (BotPoi.Current.Type != PoiType.Hotspot || BotPoi.Current.Location != hotspotLoc)
                    BotPoi.Current = new BotPoi(hotspotLoc, PoiType.Hotspot);
                return true;
            }
            return (await CommonCoroutines.MoveTo(portalLoc)).IsSuccessful();
        }

        private bool InFieldsOfEternalHunt(Vector3 loc)
        {
            return loc.Y > 2500;
        }



        #endregion

        #region Root

        private const uint AreaTriggerId_CrashingStorm_3ydRadius = 10192;
        private const uint AreaTriggerId_CrashingStorm_8ydRadius = 11353;

        private static LocalPlayer Me => StyxWoW.Me;

        [EncounterHandler(0, "Root Handler")]
        public Func<WoWUnit, Task<bool>> RootBehavior()
        {
            AddAvoidObject<WoWAreaTrigger>(3, AreaTriggerId_CrashingStorm_3ydRadius);
            AddAvoidObject<WoWAreaTrigger>(8, AreaTriggerId_CrashingStorm_8ydRadius);

            return async npc =>
            {
                return false;
            };
        }

        #endregion


        #region Fork after first boss.

        public override DungeonPathForkInfo[] PathForks { get; } = {
            new DungeonPathForkInfo(
                rightSideDivider: new Vector3(3425.084f, 568.5236f, 615.817f),
                rightSideFromEntranceMoveTo: new Vector3(3409.562f, 550.7072f, 623.1298f),
                rightSideTowardsEntranceMoveTo: new Vector3(3438.836f, 558.0865f, 614.01f),
                leftSideDivider: new Vector3(3423.372f, 489.1288f, 616.297f),
                leftSideFromEntranceMoveTo: new Vector3(3412.451f, 503.5959f, 621.0197f),
                leftSideTowardsEntranceMoveTo: new Vector3(3438.474f, 502.4468f, 614.1643f),
                shouldTakeRightSide: () => ScriptHelpers.GetUnfriendlyNpsAtLocation(new Vector3(3428.239f, 499.1127f, 614.604f), 15).Any())
        };

        #endregion

        #region Hymdall

        #region Trash

        private const uint AreaTriggerId_CracklingStorm = 10192;

        private const uint MobId_StormDrake = 97068;

        [EncounterHandler(MobId_StormDrake, "Storm Drake")]
        public Func<WoWUnit, Task<bool>> StormDrakeHandler()
        {
            AddAvoidObject<WoWAreaTrigger>(3, AreaTriggerId_CracklingStorm);

            return async boss => { return false; };
        }

        #endregion

        private const uint AreaTriggerId_DancingBlade = 9700;
        private const uint MobId_Hymdall = 94960;

        [EncounterHandler((int)MobId_Hymdall, "Hymdall")]
        public Func<WoWUnit, Task<bool>> HymdallEncounter()
        {
            AddAvoidObject<WoWAreaTrigger>(6, AreaTriggerId_DancingBlade);
            return async boss =>
            {
                return false;
            };
        }

        #endregion

        #region Hyrja

        #region Trash

        private const uint AreaTriggerId_Crackle = 10295;
        private const int SpellId_Crackle = 199805;

        private const uint MobId_StormforgedSentinel = 96574;

        [EncounterHandler(MobId_StormforgedSentinel, "Hyrja")]
        public Func<WoWUnit, Task<bool>> StormforgedSentinelHandler()
        {
            // Stay out of range of the Charged Pulse ability, which does a knockback to all within 15yds
            AddAvoidObject<WoWUnit>(() => Me.IsRanged, 15, u => u.Entry == MobId_StormforgedSentinel && u.Combat);
            AddAvoidObject<WoWAreaTrigger>(2, AreaTriggerId_Crackle);

            WoWUnit hyrja = null;

            AddAvoidLine(() => hyrja != null && hyrja.IsValid && hyrja.CastingSpellId == SpellId_Crackle, () => 4,
                () => hyrja.Location,
                () => hyrja.Location.RayCast(hyrja.Rotation, 30));

            return async npc =>
            {
                hyrja = npc;
                return await ScriptHelpers.DispelEnemy("Protective Light", ScriptHelpers.EnemyDispelType.Magic, npc);
            };
        }

        [LocationHandler(3347.35f, 527.1163f, 632.4915f, 40, "Hyrja Trash Pull")]
        public Func<Vector3, Task<bool>> HyriaTrashPullHandler()
        {
            var tankLoc1 = new Vector3(3358.18f, 512.5076f, 631.8639f);
            var trashLoc1 = new Vector3(3302.29f, 530.2123f, 635.6654f);
            var waitAtLoc = new Vector3(3348.192f, 528.9712f, 632.4915f);

            var leftStationarySentinelLoc = new Vector3(3267.219f, 515.1875f, 634.985f);
            var rightStationarySentinelLoc = new Vector3(3266.774f, 543.2587f, 634.9832f);

            Func<WoWUnit, bool> isStationarySentinel =
                unit =>
                    unit.Location.DistanceSquared(leftStationarySentinelLoc) < 2 * 2 ||
                    unit.Location.DistanceSquared(rightStationarySentinelLoc) < 2 *2;

            return async loc =>
            {
                var trashPull1 = ScriptHelpers.GetUnfriendlyNpsAtLocation(trashLoc1, 10,
                    u => u.Entry != MobId_StormforgedSentinel).FirstOrDefault();

                // pull the first pack when the pathing sentinels are not close
                if (await ScriptHelpers.PullNpcToLocation(() => trashPull1 != null && trashPull1.IsValid,
                        () => !ScriptHelpers.GetUnfriendlyNpsAtLocation(trashLoc1, 40, u => u.Entry == MobId_StormforgedSentinel && !isStationarySentinel(u)).Any(),
                        trashPull1, tankLoc1,
                        Me.IsTank ? (Vector3?)waitAtLoc : null, 5000, 2, 5))
                {
                    return true;
                }

                var trashPull2 = ScriptHelpers.GetUnfriendlyNpsAtLocation(waitAtLoc, 100,
                    u => u.Entry == MobId_StormforgedSentinel && !isStationarySentinel(u)).FirstOrDefault();

                if (await ScriptHelpers.PullNpcToLocation(() => trashPull2 != null && trashPull2.IsValid,
                        () => trashPull2.Location.DistanceSquared(trashLoc1) < 25*25,
                        trashPull2, waitAtLoc,
                        Me.IsTank ? (Vector3?)waitAtLoc : null, 5000, 2, 5))
                {
                    return true;
                }

                return false;
            };
        }


        private const uint MobId_ValarjarShieldmaiden = 95832;
        [EncounterHandler(MobId_ValarjarShieldmaiden, "Valarjar Shieldmaiden")]
        public Func<WoWUnit, Task<bool>> ValarjarShieldmaidenHandler()
        {
            AddAvoidUnitCone(() => !Me.IsTank, 0, 5, 180, u => u.Entry == MobId_ValarjarShieldmaiden && u.Combat);
            return async boss => { return false; };
        }


        private const uint MobId_ValarjarPurifier = 97197;
        private const int MissileSpellId_CleansingFlames = 192569;
        private const int SpellId_CleansingFlames = 192563;

        [EncounterHandler(MobId_ValarjarPurifier, "Valarjar Purifier")]
        public Func<WoWUnit, Task<bool>> ValarjarPurifierHandler()
        {
            AddAvoidLocation(() => true, () => ScriptHelpers.Tank?.Location ?? Vector3.Zero, 30, 5,
                missile => missile.ImpactPosition,
                () => WoWMissile.InFlightMissiles.Where(m => m.SpellId == MissileSpellId_CleansingFlames));

            return async npc =>
            {
                return await ScriptHelpers.InterruptCast(npc, SpellId_CleansingFlames);
            };
        }

        private const int SpellId_BlastofLight = 191508;
        private const uint MobId_ValarjarAspirant = 101637;

        [EncounterHandler(MobId_ValarjarAspirant, "Valarjar Aspirant")]
        public Func<WoWUnit, Task<bool>> ValarjarAspirantHandler()
        {
            WoWUnit aspirant = null;
            // range should spread out to avoid taking extra damage from Valkyra's Advance ability.
            AddAvoidObject<WoWPlayer>(() => Me.IsRanged && ScriptHelpers.IsViable(aspirant) && aspirant.Combat, 5,
                player => !player.IsMe && player.IsAlive, ignoreIfBlocking: true);

            AddAvoidLine(() => ScriptHelpers.IsViable(aspirant) && aspirant.CastingSpellId == SpellId_BlastofLight,
                () => 4, () => aspirant.Location, () => aspirant.Location.RayCast(aspirant.Rotation, 30));


            return async npc =>
            {
                aspirant = npc;
                return false;
            };
        }

        private const int SpellId_SearingLight = 192288;
        private const uint MobId_OlmyrtheEnlightened = 97202;
        private const uint AreaTriggerId_Sanctify = 9601;

        [EncounterHandler(MobId_OlmyrtheEnlightened, "Olmyr the Enlightened")]
        public Func<WoWUnit, Task<bool>> OlmyrtheEnlightenedHandler()
        {
            AddAvoidObject<WoWAreaTrigger>(4, AreaTriggerId_Sanctify);

            return async boss => { return await ScriptHelpers.InterruptCast(boss, SpellId_SearingLight); };
        }


        private const uint MobId_Solsten = 97219;
        private const int SpellId_EyeoftheStorm = 200901;
        private const uint AreaTriggerId_EyeoftheStorm = 10675;

        [EncounterHandler(MobId_Solsten, "Solsten")]
        public Func<WoWUnit, Task<bool>> SolstenHandler()
        {

            return async boss =>
            {
                return await HandleEyeOfTheStorm(boss);
            };
        }

        private bool IsCastingEyeOfTheStorm(WoWUnit npc)
        {
            return npc.CastingSpellId == SpellId_EyeoftheStorm || npc.HasAura(SpellId_EyeoftheStorm);
        }

        private async Task<bool> HandleEyeOfTheStorm(WoWUnit npc)
        {
            return
                await
                    ScriptHelpers.StayAtLocationWhile(
                        () => IsCastingEyeOfTheStorm(npc),
                        ObjectManager.GetObjectsOfType<WoWAreaTrigger>()
                            .Where(a => a.Entry == AreaTriggerId_EyeoftheStorm)
                            .Select(a => a.Location)
                            .FirstOrDefault(),
                        "Eye of the Storm");
        }


        #endregion


        private const uint MobId_Hyrja = 95833;
        private const int SpellId_ShieldofLight = 192018;

        private const int AuraId_MysticEmpowerment_Thunder = 192130;
        private const int AuraId_MysticEmpowerment_Holy = 192133;

        private enum HyrjaPhase
        {
            Olmyr,
            Solsten
        }

        [EncounterHandler(MobId_Hyrja, "Hyrja")]
        public Func<WoWUnit, Task<bool>> HyrjaHandler()
        {
            WoWUnit hyrja = null;

            var olmyrLoc = new Vector3(3141.802f, 362.5226f, 655.1875f);
            var solstenLoc = new Vector3(3187.978f, 316.8229f, 655.1868f);

            HyrjaPhase phase = HyrjaPhase.Solsten;

            Func<HyrjaPhase, Vector3> getPhaseLoc =
                hyrjaPhase => hyrjaPhase == HyrjaPhase.Solsten ? solstenLoc : olmyrLoc;
            
            // range should avoid standing near other players to reduce damage from targeted AoE abilities.
            AddAvoidObject<WoWPlayer>(
                () => ScriptHelpers.IsViable(hyrja) && Me.IsRanged && !IsCastingEyeOfTheStorm(hyrja), player => 4,
                p => !p.IsMe && p.IsAlive);

            AddAvoidObject<WoWPlayer>(() => true, 8, p => !p.IsMe && p.HasAura("Expel Light"));

            // Run from Hyrja while she's casting Shield of light so we have time to avoid the orbs that radiate from her.
            AddAvoidObject<WoWUnit>(15, p => p.Entry == MobId_Hyrja && p.CastingSpellId == SpellId_ShieldofLight);

            AddAvoidLine(
                () => ScriptHelpers.IsViable(hyrja) && !Me.IsTank && hyrja.CastingSpellId == SpellId_ShieldofLight,
                () => 6, () => hyrja.Location, () => hyrja.Location.RayCast(hyrja.Rotation, 40));

            return async boss =>
            {
                hyrja = boss;
                if (IsCastingEyeOfTheStorm(boss))
                    return await HandleEyeOfTheStorm(boss);

                if (boss.CastingSpellId == SpellId_ShieldofLight )
                {
                    var thunderAuraStack = boss.GetAuraById(AuraId_MysticEmpowerment_Thunder)?.StackCount ?? 0;
                    var holyAuraStack = boss.GetAuraById(AuraId_MysticEmpowerment_Holy)?.StackCount ?? 0;

                    phase = holyAuraStack > thunderAuraStack  ? HyrjaPhase.Solsten : HyrjaPhase.Olmyr;

                    if (Me.IsTank)
                    {
                        var moveTo = WoWMathHelper.CalculatePointFrom(getPhaseLoc(phase), boss.Location, 5);
                        // Use knockback to move to other phase location.
                        return
                            await
                                ScriptHelpers.StayAtLocationWhile(
                                    () => boss.IsValid && boss.CastingSpellId == SpellId_ShieldofLight, moveTo,
                                    "Shield of light", 1);
                    }
                }

                return Me.IsTank && await ScriptHelpers.TankUnitAtLocation(getPhaseLoc(phase), 15);
            };
        }



        #endregion


        #region Fenryr

        #region Trash

        private const uint MobId_EbonclawWorg = 96608;

        [EncounterHandler(MobId_EbonclawWorg, "Ebonclaw Worg")]
        public Func<WoWUnit, Task<bool>> EbonclawWorgHandler()
        {
            WoWUnit worg = null;

            // Avoid other players to reduce damge from 'Leap for the Throat' ability.
            AddAvoidObject<WoWPlayer>(() => ScriptHelpers.IsViable(worg) && worg.Combat && Me.IsRanged, 4,
                player => !player.IsMe && player.IsAlive);

            return async boss =>
            {
                worg = boss;
                return false;
            };
        }

        #endregion

        private const int SpellId_UnnervingHowl = 196543;

        private const uint MobId_Fenryr = 95674;

        [EncounterHandler(MobId_Fenryr, "Fenryr")]
        public Func<WoWUnit, Task<bool>> FenryrHandler()
        {
            WoWUnit fenryr = null;

            // Avoid other players to reduce damge from 'Ravenous Leap' ability.
            AddAvoidObject<WoWPlayer>(() => ScriptHelpers.IsViable(fenryr) && fenryr.Combat && Me.IsRanged, 10,
                player => !player.IsMe && player.IsAlive);

            AddAvoidObject<WoWUnit>(() => Me.HasAura("Scent of Blood"), 30, unit => unit.Entry == MobId_Fenryr && unit.CurrentTargetGuid == Me.Guid);

            return async boss =>
            {
                fenryr = boss;

                if (boss.CastingSpellId == SpellId_UnnervingHowl && Me.IsCasting &&
                    Me.CurrentCastTimeLeft > boss.CurrentCastTimeLeft)
                {
                    SpellManager.StopCasting();
                    await Coroutine.Wait(4000, () => boss.IsValid && boss.CastingSpellId != SpellId_UnnervingHowl);
                    return true;
                }
                return false;
            };
        }

        #endregion

        #region God-King Skovald

        private const int SpellId_UnrulyYell = 199726;

        private const uint MobId_KingRanulf = 97083;
        private const uint MobId_KingHaldor = 95843;
        private const uint MobId_KingBjorn = 97081;
        private const uint MobId_KingTor = 97084;

        private const uint MobId_HonoredAncestor = 101326;

        [EncounterHandler(MobId_KingRanulf, "King Ranulf")]
        [EncounterHandler(MobId_KingHaldor, "King Haldor")]
        [EncounterHandler(MobId_KingBjorn, "King Bjorn")]
        [EncounterHandler(MobId_KingTor, "King Tor")]
        public Func<WoWUnit, Task<bool>> KingsHandler()
        {
            return async boss =>
            {
                if (await ScriptHelpers.InterruptCast(boss, SpellId_UnrulyYell))
                    return true;

                // Unruly Yell interrupts current spell cast.
                if (boss.CastingSpellId == SpellId_UnrulyYell &&
                    boss.CurrentCastTimeLeft < TimeSpan.FromMilliseconds(500) && Me.IsCasting &&
                    Me.CurrentCastTimeLeft > boss.CurrentCastTimeLeft)
                {
                    SpellManager.StopCasting();
                    await Coroutine.Wait(1000, () => !boss.IsCasting);
                    return true;
                }

                return false;
            };
        }

        private const uint MobId_GodKingSkovald = 95675;

        [EncounterHandler(MobId_GodKingSkovald, "God-King Skovald", Mode = CallBehaviorMode.CurrentBoss)]
        public Func<WoWUnit, Task<bool>> GodKingSkovaldStartHandler()
        {
            return async boss =>
            {
                if (!Me.IsTank || Me.Combat)
                    return false;

                return await TalkToNpcAndWaitForCombat(MobId_KingRanulf) || await TalkToNpcAndWaitForCombat(MobId_KingHaldor) ||
                       await TalkToNpcAndWaitForCombat(MobId_KingBjorn) || await TalkToNpcAndWaitForCombat(MobId_KingTor);
            };
        }

        private const int SpellId_Ragnarok = 193826;
        private const int AuraId_AegisOfAggramarActive = 202711;
        private const uint AreaTriggerId_InfernalFlames = 9749;
        private const uint AreaTriggerId_AegisofAggramar = 9758;

        [EncounterHandler(MobId_GodKingSkovald, "God-King Skovald")]
        public Func<WoWUnit, Task<bool>> GodKingSkovaldHandler()
        {
            WoWUnit skovald = null;
            AddAvoidObject<WoWAreaTrigger>(3, AreaTriggerId_InfernalFlames);

            Func<WoWUnit, bool> isCastingRagnarok =
                unit => unit.CastingSpellId == SpellId_Ragnarok || unit.HasAura(SpellId_Ragnarok);

            // Range should spread out to avoid damage from Felblaze Rush 
            AddAvoidObject<WoWPlayer>(
                () =>
                    Me.IsRanged && ScriptHelpers.IsViable(skovald) && !isCastingRagnarok(skovald) &&
                    !skovald.HasAura("Aegis of Aggramar"), 10, player => !player.IsMe && player.IsAlive);

            return async boss =>
            {
                skovald = boss;

                if (boss.CastingSpellId == SpellId_Ragnarok || boss.HasAura(SpellId_Ragnarok))
                {
                    if (Me.HasAura("Aegis of Aggramar"))
                    {
                        if (boss.HasAura(SpellId_Ragnarok) && ActionBar.Extra.Buttons[0].CanUse)
                        {
                            if (!Me.IsSafelyFacing(boss))
                                boss.Face();

                            ActionBar.Extra.Buttons[0].Use();
                            // wait for shield to activate and expire.
                            return await Coroutine.Wait(3000, () => Me.HasAura(AuraId_AegisOfAggramarActive)) &&
                                   await Coroutine.Wait(10000, () => !Me.HasAura(AuraId_AegisOfAggramarActive));

                        }
                        return false;
                    }

                    var shield =
                        ObjectManager.GetObjectsOfType<WoWAreaTrigger>()
                            .FirstOrDefault(a => a.Entry == AreaTriggerId_AegisofAggramar);

                    if (shield != null)
                    {
                        return await ScriptHelpers.StayAtLocationWhile(() => ScriptHelpers.IsViable(boss) && ScriptHelpers.IsViable(shield) && isCastingRagnarok(boss), shield.Location, precision: 4);
                    }

                }

                if (boss.HasAura("Aegis of Aggramar"))
                {
                    return await ScriptHelpers.StayAtLocationWhile(
                                () =>
                                    ScriptHelpers.IsViable(boss) && boss.HasAura("Aegis of Aggramar") && !Me.IsSafelyBehind(boss),
                                WoWMathHelper.CalculatePointBehind(boss.Location, boss.Rotation, 8), precision: 6);
                }

                return false;
            };
        }

        private const uint MobId_AegisofAggramar = 98364;

        [EncounterHandler(MobId_AegisofAggramar, "Aegis of Aggramar", 60, CallBehaviorMode.Proximity)]
        public Func<WoWUnit, Task<bool>> AegisofAggramarHandler()
        {
            return async boss => Me.IsTank && boss.HasAura("Aegis of Aggramar") && await ScriptHelpers.InteractWithObject(boss, ignoreCombat:true);
        }

        private async Task<bool> TalkToNpcAndWaitForCombat(uint unitId, bool hasConfirmation = false)
        {
            var unit =
               ObjectManager.GetObjectsOfType<WoWUnit>()
                   .FirstOrDefault(u => u.Entry == unitId && u.CanGossip);

            if (unit == null)
                return false;

            if (!unit.WithinInteractRange)
                return (await CommonCoroutines.MoveTo(unit.Location)).IsSuccessful();

            await CommonCoroutines.StopMoving();
            if (!GossipFrame.Instance.IsVisible)
            {
                unit.Interact();

                return await Coroutine.Wait(4000, () => GossipFrame.Instance.IsVisible && GossipFrame.Instance.GossipOptionEntries != null);
            }

            GossipFrame.Instance.SelectGossipOption(0);
            if (hasConfirmation)
            {
                await Coroutine.Sleep(1000);
                Lua.DoString("local name, frame = StaticPopup_Visible('GOSSIP_CONFIRM') if frame then StaticPopup_OnClick(frame, 1) end");
            }
            return await Coroutine.Wait(6000, () => unit.Combat);
        }

        #endregion

        #region Odyn

        private const uint MobId_Odyn = 95676;

        [EncounterHandler(MobId_Odyn, "Odyn", Mode = CallBehaviorMode.CurrentBoss)]
        public Func<WoWUnit, Task<bool>> OdynStartHandler()
        {
            return async boss =>
            {
                if (!Me.IsTank || Me.Combat || boss == null || !boss.CanGossip)
                    return false;

                if (boss.DistanceSqr < 10 * 10 &&
                    !GroupMember.GroupMembers.All(g => g.Distance < 45 && Math.Abs(g.Location.Z - Me.Z) < 10))
                {
                    TreeRoot.StatusText = "Waiting for group members to move closer before starting encounter";
                    return true;
                }

                return await TalkToNpcAndWaitForCombat(MobId_Odyn, true);
            };
        }

        private const uint GameObjectId_SpoilsOfTheWorthy = 245847;

        private const int MissileSpellId_SpearofLight = 198060;
        private const int SpellId_RadiantTempest = 198263;
        private const uint AreaTriggerId_SpearofLight = 10398;
        private const uint AreaTriggerId_GlowingFragment = 10126;

        [EncounterHandler(MobId_Odyn, "Odyn")]
        public Func<WoWUnit, Task<bool>> OdynHandler()
        {
            var runicBrandAreaTriggerIds = new Dictionary<int, uint>
            {
                {197963, 10111},
                {197964, 10112},
                {197965, 10113},
                {197966, 10116},
                {197967, 10117}
            };

            var runicBrandAuraIds = new HashSet<int>
            {
                197963,
                197964,
                197965,
                197966,
                197967
            };
            

            AddAvoidObject<WoWAreaTrigger>(4, AreaTriggerId_SpearofLight);
            AddAvoidObject<WoWAreaTrigger>(6, AreaTriggerId_GlowingFragment);

            AddAvoidObject<WoWUnit>(40, u => u.Entry == MobId_Odyn && u.CastingSpellId == SpellId_RadiantTempest);
            AddAvoidLocation(() => true, 8, missile => missile.ImpactPosition, () => WoWMissile.InFlightMissiles.Where(m => m.SpellId == MissileSpellId_SpearofLight));

            return async boss =>
            {
                var runicBrand = Me.GetAllAuras().FirstOrDefault(a => runicBrandAuraIds.Contains(a.SpellId));
                if (runicBrand != null)
                {
                    var areaTriggerId = runicBrandAreaTriggerIds[runicBrand.SpellId];
                    var areaTrigger =
                        ObjectManager.GetObjectsOfType<WoWAreaTrigger>().FirstOrDefault(a => a.Entry == areaTriggerId);

                    if (areaTrigger != null)
                    {
                        return await ScriptHelpers.StayAtLocationWhile(
                                    () => ScriptHelpers.IsViable(areaTrigger) && Me.HasAura(runicBrand.SpellId),
                                    areaTrigger.Location, "Runic Brand", 4);
                    }

                }

                return false;
            };
        }

        #endregion
    }

    #endregion

    #region Heroic Difficulty

    public class HallsOfValorHeroic : HallsOfValor
    {
        #region Overrides of Dungeon

        public override uint DungeonId => 1194;

        #endregion
    }

    #endregion
}
