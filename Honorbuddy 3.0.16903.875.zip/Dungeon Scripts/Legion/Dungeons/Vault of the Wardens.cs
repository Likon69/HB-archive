﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Threading.Tasks;
using Bots.DungeonBuddy.Attributes;
using Bots.DungeonBuddy.Enums;
using Bots.DungeonBuddy.Helpers;
using Bots.DungeonBuddy.Profiles;
using Buddy.Coroutines;
using CommonBehaviors.Actions;
using Styx;
using Styx.Common;
using Styx.Common.Helpers;
using Styx.CommonBot;
using Styx.CommonBot.Bars;
using Styx.CommonBot.Coroutines;
using Styx.CommonBot.Routines;
using Styx.Helpers;
using Styx.Patchables;
using Styx.Pathing;
using Styx.Pathing.Avoidance;
using Styx.TreeSharp;
using Styx.WoWInternals;
using Styx.WoWInternals.World;
using Styx.WoWInternals.WoWObjects;
using Styx.WoWInternals.WoWObjects.AreaTriggerShapes;

// ReSharper disable CheckNamespace

namespace Bots.DungeonBuddy.DungeonScripts.Legion
// ReSharper restore CheckNamespace
{

    #region Normal Difficulty
    public class VaultOfTheWardens : Dungeon
    {
        #region Overrides of Dungeon

        public override uint DungeonId => 1043;

        public override Vector3 Entrance { get; } = new Vector3(-1711.649f, 6648.844f, 124.9094f);

        public override Vector3 ExitLocation { get; } = new Vector3(4185.839f, -784.7863f, 281.7811f);

        public override void RemoveTargetsFilter(List<WoWObject> units)
        {
            units.RemoveAll(
                ret =>
                {
                    var unit = ret as WoWUnit;
                    if (unit == null)
                        return false;

                    // No point in trying to kill these imps when they are commiting suicide
                    if (unit.Entry == MobId_BlazingImp && unit.CastingSpellId == SpellId_Implosion)
                        return true;

                    if (unit.Entry == MobId_Glazer && unit.HasAura("Focusing"))
                        return true;

                    if (unit.Entry == MobId_InquisitorTormentorum && unit.HasAura("Void Shield"))
                        return true;

                    if (unit.Entry == MobId_CordanaFelsong && (unit.HasAura("Vengeance") || (!unit.Combat && !Me.HasAura("Elune's Light"))))
                        return true;

                    return false;
                });
        }

        public override void IncludeTargetsFilter(List<WoWObject> incomingunits, HashSet<WoWObject> outgoingunits)
        {
            var isTank = Me.IsTank;

            foreach (var obj in incomingunits)
            {
                var unit = obj as WoWUnit;
                if (unit != null)
                {

                }
            }
        }

        public override void WeighTargetsFilter(List<Targeting.TargetPriority> units)
        {
            var isDps = Me.IsDps;

            foreach (var priority in units)
            {
                var unit = priority.Object as WoWUnit;
                if (unit != null)
                {
                    switch (unit.Entry)
                    {
                        case MobId_FelInfusedFury:
                        case MobId_MalignantDefiler:
                            if (isDps)
                                priority.Score += 5000;
                            break;

                        case MobId_FelScorcher:
                        case MobId_EnormousStoneQuilen:
                            if (isDps)
                                priority.Score += 4000;
                            break;

                        // These are casters so they can't be tanked. 
                        case MobId_MogushanSecretKeeper:
                        case MobId_DerangedMindflayer:
                        case MobId_ShadowmoonTechnician:
                            priority.Score += isDps ? 5000 : -5000;
                            break;

                        case MobId_FacelessVoidcasters:
                        case MobId_ShadowmoonWarlock:
                            priority.Score += isDps ? 4000 : -5000;
                            break;

                        case MobId_VoidTouchedJuggernaut:
                        case MobId_LingeringCorruption:
                        case MobId_FelguardAnnihilator:
                        case MobId_AvatarofShadow:
                            if (isDps)
                                priority.Score += 3000;
                            break;

                        // These can't be tanked so tank should ignore
                        case MobId_Ember:
                            priority.Score += isDps && !_burnAshGolm && unit.CastingSpellId == SpellId_Detonate ? 5000 : -5000;
                            break;

                        case MobId_Grimguard:
                        case MobId_AvatarofVengeance:
                            priority.Score += isDps || !unit.Aggro ? 5000 : -5000;
                            break;
                    }
                }
            }
        }

        public override void IncludeLootTargetsFilter(List<WoWObject> incomingunits, HashSet<WoWObject> outgoingunits)
        {
            foreach (var lootTarget in incomingunits)
            {
                //var gObj = lootTarget as WoWGameObject;
                //if (gObj != null && gObj.Entry == GameObjectId_MillificentsDiscardedLockbox &&  gObj.CanLoot &&
                //    DungeonBuddySettings.Instance.LootMode != LootMode.Off)
                //{
                //    outgoingunits.Add(gObj);
                //}
            }
        }

        public override void OnEnter()
        {

            var displayPugGroupWarning = DungeonBuddySettings.Instance.PartyMode == PartyMode.Off ||
                                         (DungeonBuddySettings.Instance.PartyMode == PartyMode.Leader &&
                                          DungeonBuddySettings.Instance.PartyMembers.Count(
                                              s => !string.IsNullOrWhiteSpace(s)) < 4);

            if (displayPugGroupWarning)
            {
                Alert.Show(
                    "Dungeon not tested in PUGs",
                    $"{Name} dungeon has not been tested in PUGs so it's very important to not leave toon unattended",
                    15);
            }

        }

        public override DungeonPathForkInfo[] PathForks { get; } =
        {
            // First fork at entrance
            new MultifloorDungeonPathForkInfo(
                forkFloorLevel: 3,
                entranceSideFloorLevels: new int[0],
                rightSideDivider: new Vector3(4221.686f, -666.2428f, 257.4981f),
                rightSideFromEntranceMoveTo: new Vector3(4222.232f, -657.6765f, 257.4981f),
                rightSideTowardsEntranceMoveTo: new Vector3(4217.801f, -676.2899f, 260.1461f),
                leftSideDivider: new Vector3(4147.672f, -667.9437f, 257.4981f),
                leftSideFromEntranceMoveTo: new Vector3(4149.245f, -659.3022f, 257.4981f),
                leftSideTowardsEntranceMoveTo: new Vector3(4152.604f, -680.25f, 260.1461f),
                shouldTakeRightSide: () => !ScriptHelpers.GetUnfriendlyNpsAtLocation(new Vector3(4223.017f, -661.9684f, 257.4981f), 15).Any(),
                shouldHandleForkAdditionalCondition: moveto => Me.Z > 240 && Me.Y  < -600 && Me.X < 4250 && Me.Location.DistanceSquared(moveto) > 50*50,
                name: "First Fork at Entrance"),
               

            // Second fork at entrance
            new MultifloorDungeonPathForkInfo(
                forkFloorLevel: 3,
                entranceSideFloorLevels: new int[0],
                rightSideDivider:  new Vector3(4218.968f, -585.2231f, 257.8104f),
                rightSideFromEntranceMoveTo: new Vector3(4216.839f, -578.6421f, 260.1461f),
                rightSideTowardsEntranceMoveTo: new Vector3(4217.847f, -593.4012f, 257.4981f),
                leftSideDivider: new Vector3(4147.639f, -581.9956f, 258.7464f),
                leftSideFromEntranceMoveTo: new Vector3(4151.066f, -574.6063f, 260.1461f),
                leftSideTowardsEntranceMoveTo: new Vector3(4147.267f, -591.3701f, 257.4981f),
                shouldTakeRightSide: () => ScriptHelpers.GetUnfriendlyNpsAtLocation(new Vector3(4155.157f, -577.6362f, 260.1461f), 25).Any(),
                shouldHandleForkAdditionalCondition: moveto => Me.Z > 240 && Me.Y < -527 && Me.Y > -650 && Me.X < 4250 && Me.Location.DistanceSquared(moveto) >  50*50,
                name: "Second Fork at Entrance"),

            // Fork after first boss
            new MultifloorDungeonPathForkInfo(
                forkFloorLevel: 3,
                entranceSideFloorLevels: new int[0],
                rightSideDivider:  new Vector3(4355.772f, -484.2245f, 256.591f),
                rightSideFromEntranceMoveTo: new Vector3(4365.413f, -484.7657f, 256.3373f),
                rightSideTowardsEntranceMoveTo: new Vector3(4347.332f, -484.6702f, 256.5911f),
                leftSideDivider: new Vector3(4355.92f, -419.0131f, 256.591f),
                leftSideFromEntranceMoveTo: new Vector3(4363.878f, -419.0159f, 256.3373f),
                leftSideTowardsEntranceMoveTo: new Vector3(4342.859f, -418.5127f, 256.5911f),
                shouldTakeRightSide: () => ScriptHelpers.GetUnfriendlyNpsAtLocation(new Vector3(4359.163f, -484.6685f, 256.3373f), 20).Any(),
                shouldHandleForkAdditionalCondition: moveto => Me.Z > 240 && Me.Y > -504 && Me.X > 4313 && Me.X < 4427 && Me.Location.DistanceSquared(moveto) > 50*50,
                name: "Fork after first boss"),
        };

        public override DungeonStuckHandler[] StuckHandlers { get; } = {
            new BasicCtmStuckHandler(new Vector3(4403.585f, -457.0844f, 119.881f), 4, 119, 121,
                new Vector3(4407.1f, -461.48f, 118.6026f), "Left of ramp to 2nd boss"),
            new BasicCtmStuckHandler(new Vector3(4404.433f, -445.3065f, 119.8811f), 4, 119, 121,
                new Vector3(4408.479f, -441.5386f, 118.6027f), "Right of ramp to 2nd boss"),
            new BasicCtmStuckHandler(new Vector3(4404.127f, -444.2697f, 119.8811f), 8, 119, 121,
                new Vector3(4408.499f, -440.3266f, 118.6027f), "Right of ramp to 3nd boss"),
            new BasicCtmStuckHandler(new Vector3(4402.958f, -458.8272f, 119.8811f), 8, 119, 121,
                new Vector3(4407.371f, -460.4726f, 118.6026f), "Left of ramp to 3nd boss"),
            new BasicCtmStuckHandler(new Vector3(4442.622f, -498.2588f, 119.8811f), 8, 119, 121,
                new Vector3(4440.144f, -494.6948f, 118.6025f), "Right of ramp to 4th boss"),
            new BasicCtmStuckHandler(new Vector3(4458.544f, -497.5354f, 119.8811f), 8, 119, 121,
                new Vector3(4459.681f, -492.5688f, 118.6025f), "Left of ramp to 4th boss")
        };



        private class BasicCtmStuckHandler : DungeonStuckHandler
        {
            private readonly Vector3 _stuckLocation;
            private readonly float _stuckRadius, _stuckMinZ, _stuckMaxZ;

            public BasicCtmStuckHandler(Vector3 stuckLoc, float stuckRadius, float stuckMinZ, float stuckMaxZ,
                Vector3 unstickMoveTo, string name)
            {
                _stuckLocation = stuckLoc;
                _stuckRadius = stuckRadius;
                _stuckMinZ = stuckMinZ;
                _stuckMaxZ = stuckMaxZ;
                UnstickMoveTo = unstickMoveTo;
                StuckAreaName = name;
            }

            protected override bool IsStuck
                => StyxWoW.Me.Location.DistanceSquared(_stuckLocation) < _stuckRadius * _stuckRadius && StyxWoW.Me.Z >= _stuckMinZ && Me.Z < _stuckMaxZ;

            protected override Vector3 UnstickMoveTo { get; } 
            protected override string StuckAreaName { get; }
        }


        #region Embedded type: MultifloorDungeonPathForkInfo

        private class MultifloorDungeonPathForkInfo : DungeonPathForkInfo
        {
            private readonly int _forkFloorLevel;
            private readonly HashSet<int> _entranceSideFloorLevels;

    
            /// <param name="forkFloorLevel">The floor level that fork is on</param>
            /// <param name="entranceSideFloorLevels">The floor levels that need to be passed through to get to fork from entrance; none if fork is on entrance floor level</param>
            public MultifloorDungeonPathForkInfo(int forkFloorLevel, int[] entranceSideFloorLevels, Vector3 rightSideDivider,
                Vector3 rightSideFromEntranceMoveTo,
                Vector3 rightSideTowardsEntranceMoveTo, Vector3 leftSideDivider, Vector3 leftSideFromEntranceMoveTo,
                Vector3 leftSideTowardsEntranceMoveTo, Func<bool> shouldTakeRightSide,
                Func<Vector3, bool> shouldHandleForkAdditionalCondition = null, string name = null)
                : base(
                    rightSideDivider, rightSideFromEntranceMoveTo, rightSideTowardsEntranceMoveTo, leftSideDivider,
                    leftSideFromEntranceMoveTo, leftSideTowardsEntranceMoveTo, shouldTakeRightSide,
                    shouldHandleForkAdditionalCondition, name)
            {
                _forkFloorLevel = forkFloorLevel;
                _entranceSideFloorLevels = new HashSet<int>(entranceSideFloorLevels);
            }

            public override bool IsLocationOnEntranceSide(Vector3 location)
            {
                var floorLevel = GetFloorLevel(location);
                if (floorLevel == _forkFloorLevel)
                    return base.IsLocationOnEntranceSide(location);

                return _entranceSideFloorLevels.Contains(floorLevel);
            }
        }

        #endregion

        
        public override async Task<bool> HandleMovement(MoveToParameters moveToParameters)
        {
            if (await HandleElevator(moveToParameters.Location))
                return true;

            return false;
        }


        #endregion

        #region Root

        private static LocalPlayer Me => StyxWoW.Me;

        [EncounterHandler(0, "Root Handler")]
        public Func<WoWUnit, Task<bool>> RootBehavior()
        {
            return async npc =>
            {
                if (await FollowerElevatorHandler())
                    return true;
                return false;
            };
        }



        #region Elevator

        private static readonly ElevatorInfo s_floor2To3ElevatorInfo = new ElevatorInfo(3, 2, 10, 246047, 253.4846f,
            118.2794f,
            new Vector3(4450.073f, -450.7084f, 254.5883f),
            new Vector3(4462.923f, -451.2659f, 254.2638f), new Vector3(4450.073f, -450.7084f, 119.383f),
            new Vector3(4438.685f, -451.3062f, 119.1845f), "Floor 2-3 Elevator");

        private static readonly ElevatorInfo s_floor1To2ElevatorInfo = new ElevatorInfo(2, 1, 10, 246048, 125.3047f,
            -240.945f,
            new Vector3(4450.616f, -323.0656f, -239.9527f),
            new Vector3(4450.913f, -334.5222f, 126.1222f),
            new Vector3(4450.616f, -323.0656f, -239.9527f),
            new Vector3(4463.595f, -310.8108f, -240.7731f),
            "Floor 1-2 Elevator");

        private readonly ElevatorInfo[] _elevators =
        {
            s_floor2To3ElevatorInfo,
            s_floor1To2ElevatorInfo
        };

        private async Task<bool> HandleElevator(Vector3 destination)
        {
            if (await HandleBuggedElevator(destination))
                return true;

            WoWGameObject transport = Me.Transport as WoWGameObject;
            var elevatorInfo = GetElevatorInfoFromLocation(destination);

            Vector3 moveTo;
            // Destination is locatated in an elevator shaft.
            if (elevatorInfo != null)
            {
                if (transport == null || transport.Entry != elevatorInfo.GameObjectId)
                {
                    var exitLoc = elevatorInfo.GetExitLocation(destination);
                    if (!elevatorInfo.IsPointInElevatorShaft(Me.Location)  && Me.Location.DistanceSquared(exitLoc) > 3 * 3)
                        return (await CommonCoroutines.MoveTo(exitLoc, elevatorInfo.Name)).IsSuccessful();

                    transport =
                        ObjectManager.GetObjectsOfType<WoWGameObject>()
                            .FirstOrDefault(g => g.Entry == elevatorInfo.GameObjectId);

                    if (transport == null)
                    {
                        Logger.WriteWarning($"Could not find {elevatorInfo.Name} in the ObjectManager");
                        return false;
                    }

                    if (!IsElevatorAtRestPosition(transport))
                        return false;

                    moveTo = elevatorInfo.GetRandomBoardLocation(Me.Location);
                    Logger.Write($"Boarding {elevatorInfo.Name}");
                }
                else
                {
                    // From and To locations are on the elevator; just ctm to it
                    moveTo = destination;
                }
            }
            else
            {
                if (transport == null || !IsElevator(transport))
                    return false;

                elevatorInfo = GetElevatorInfo(transport);
                // handles getting off elevator because it can get stuck due to no mesh being under elevator, esp during DCs
                var myFloorLevel = GetFloorLevel(Me.Location);

                var moveToFloorLevel = GetFloorLevel(destination);

                int exitFloorLevel;
                if (moveToFloorLevel == elevatorInfo.TopFloor)
                    exitFloorLevel = elevatorInfo.TopFloor;
                else if (moveToFloorLevel == elevatorInfo.BottomFloor)
                    exitFloorLevel = elevatorInfo.BottomFloor;
                else
                {
                    // We're moving to a floor that our elevator isn't connected to.
                    // Try to find another elevator that's connected to one of the floors that our eleveator is linked to, and connenected to moveToFloorLevel.
                    var destFloorElevatorInfo =
                        _elevators.FirstOrDefault(
                            e => (e.TopFloor == moveToFloorLevel && e.BottomFloor == elevatorInfo.TopFloor) || (e.BottomFloor == moveToFloorLevel && e.TopFloor == elevatorInfo.BottomFloor));

                    if (destFloorElevatorInfo == null)
                    {
                        Logger.WriteWarning($"Unable to find an elavator to get from floor level {myFloorLevel} to {moveToFloorLevel}");
                        return false;
                    }
                    exitFloorLevel = destFloorElevatorInfo.TopFloor == elevatorInfo.BottomFloor ? elevatorInfo.BottomFloor : elevatorInfo.TopFloor;
                }

                if (myFloorLevel != exitFloorLevel)
                    return false;

                if (!IsElevatorAtRestPosition(transport))
                    return false;

                moveTo = WoWMathHelper.GetRandomPointInCircle(elevatorInfo.GetExitLocation(Me.Location), 1);
                Logger.Write($"Exiting {elevatorInfo.Name}");
            }

            Navigator.PlayerMover.MoveTowards(moveTo);
            await Coroutine.Wait(6000, () => !Me.IsMoving);
            return true;
        }

        private readonly WaitTimer _buggedElevatorTimer = new WaitTimer(TimeSpan.FromMinutes(1));
        private float _buggedElevatorMaxZ, _buggedElevatorMinZ;
        private ElevatorInfo _buggedElevatorInfo;

        private async Task<bool> HandleBuggedElevator(Vector3 destination)
        {
            var myFloor = GetFloorLevel(Me.Location);
            var destFloor = GetFloorLevel(destination);
            var transport = Me.Transport as WoWGameObject;

            var elevatorInfo = IsElevator(transport) ? GetElevatorInfo(transport) : null;

            if (myFloor == destFloor && elevatorInfo == null)
            {
                _buggedElevatorInfo = null;
                return false;
            }


            if (elevatorInfo == null)
                elevatorInfo = myFloor == 3 || (myFloor == 2 && destFloor == 3)
                    ? s_floor2To3ElevatorInfo
                    : s_floor1To2ElevatorInfo;

            bool waitingAtTop = false, waitingAtBottom = false;

            if (!IsElevator(transport))
            {
                waitingAtTop = myFloor == elevatorInfo.TopFloor && Navigator.AtLocation(elevatorInfo.TopGetOffLoc);
                waitingAtBottom = myFloor == elevatorInfo.BottomFloor &&
                                  Navigator.AtLocation(elevatorInfo.BottomGetOffLoc);

                if (!waitingAtTop && !waitingAtBottom)
                {
                    _buggedElevatorInfo = null;
                    return false;
                }
            }

            // start the timer...
            if (_buggedElevatorInfo != elevatorInfo)
            {
                _buggedElevatorTimer.Reset();
                _buggedElevatorMinZ = float.MaxValue;
                _buggedElevatorMaxZ = float.MinValue;
                _buggedElevatorInfo = elevatorInfo;
            }

            WoWGameObject elevator =
                    ObjectManager.GetObjectsOfType<WoWGameObject>()
                        .FirstOrDefault(g => g.Entry == elevatorInfo.GameObjectId);

            // should not happen, but log it if it does
            if (elevator == null)
            {
                Logger.WriteWarning($"Unable to find elevator gameobject for {elevatorInfo.Name}");
                return false;
            }

            if (!_buggedElevatorTimer.IsFinished)
            {
                if (elevator.Z > _buggedElevatorMaxZ)
                    _buggedElevatorMaxZ = elevator.Z;

                if (elevator.Z < _buggedElevatorMinZ)
                    _buggedElevatorMinZ = elevator.Z;

                return false;
            }

            if (waitingAtBottom || IsElevator(transport) && elevatorInfo.TopFloor == destFloor)
            {
                // it's impossible to get to destination without teleporting out
                if (Me.GroupInfo.LfgDungeonId != 0)
                    return await ScriptHelpers.PortOutsideAndBackIn();

                // Hearthing out may or may not solve the issue. 
                // Just stop bot instead and have user deal with it. 
                TreeRoot.Stop("Can't continue instance due to bugged elevator");
                return true;
            }

            var wantedElevatorZ = waitingAtTop ? _buggedElevatorMaxZ : _buggedElevatorMinZ;

            if (Math.Abs(elevator.Z - wantedElevatorZ) > 3)
                return false;

            Logger.Write($"Elevator is bugged so forcing bot to jump {(waitingAtTop ? "on" : "off")} it");
            var moveTo = waitingAtTop ? elevatorInfo.TopGetOnLoc : elevatorInfo.BottomGetOffLoc;
            Navigator.PlayerMover.MoveTowards(moveTo);
            await CommonCoroutines.SleepForLagDuration();
            await Coroutine.Wait(6000, () => !Me.IsMoving);
            return true;
        }


        private ElevatorInfo GetElevatorInfoFromLocation(Vector3 location)
        {
            return _elevators.FirstOrDefault(e => e.IsPointInElevatorShaft(location));
        }

        private static int GetFloorLevel(Vector3 location)
        {
            if (location.Z > 200)
                return 3;

            return location.Z > 100 ? 2 : 1;
        }


        private bool IsElevatorAtRestPosition(WoWGameObject elevator)
        {
            var elevatorInfo = GetElevatorInfo(elevator);
            if (elevatorInfo == null)
                throw new ArgumentException($"No elevator info found for {elevator.SafeName}");

            return Math.Abs(elevator.Z - elevatorInfo.TopRestingZ) < 0.5 ||
                   Math.Abs(elevator.Z - elevatorInfo.BottomRestingZ) < 0.5;
        }

        // Forces Followers to get off elevator when tank isn't on it and get on when tank is on it
        private async Task<bool> FollowerElevatorHandler()
        {
            var tank = ScriptHelpers.Tank;
            if (tank == null || tank.IsMe)
                return false;

            var tankTransport = tank.Transport as WoWGameObject;
            var myTransport = Me.Transport as WoWGameObject;

            if (myTransport == tankTransport && (myTransport == null || !IsElevator(myTransport)
                // makes sure we're fully on elevator so we don't fall off
                || (GetElevatorInfo(myTransport)?.IsFullyOnElevator(Me.Location) ?? true ) ))
            {
                return false;
            }


            if (GetFloorLevel(Me.Location) != GetFloorLevel(tank.Location))
                return false;


            if (!IsElevator(myTransport) && !IsElevator(tankTransport))
                return false;

            return (await CommonCoroutines.MoveTo(tank.Location)).IsSuccessful();
        }


        private bool IsElevator(WoWObject obj)
        {
            return ScriptHelpers.IsViable(obj) && _elevators.Any(e => obj.Entry == e.GameObjectId);
        }

        private ElevatorInfo GetElevatorInfo(WoWGameObject elevator)
        {
            return _elevators.FirstOrDefault(e => e.GameObjectId == elevator.Entry);
        }

        private class ElevatorInfo
        {
            public ElevatorInfo(int topFloor, int bottomFloor, float elevatorRadius, uint gameObjectId, float topRestingZ, float bottomRestingZ, Vector3 topGetOnLoc, Vector3 topGetOffLoc,
                Vector3 bottomGetOnLoc, Vector3 bottomGetOffLoc, string name)
            {
                TopFloor = topFloor;
                BottomFloor = bottomFloor;
                GameObjectId = gameObjectId;
                TopRestingZ = topRestingZ;
                BottomRestingZ = bottomRestingZ;
                TopGetOnLoc = topGetOnLoc;
                TopGetOffLoc = topGetOffLoc;
                BottomGetOnLoc = bottomGetOnLoc;
                BottomGetOffLoc = bottomGetOffLoc;
                Name = name;
                ElevatorRadius = elevatorRadius;
            }

            public int TopFloor { get; }
            public int BottomFloor { get; }
            public uint GameObjectId { get; }
            public float TopRestingZ { get; }
            public float BottomRestingZ { get; }
            public Vector3 TopGetOffLoc { get; }
            public Vector3 TopGetOnLoc { get; }
            public Vector3 BottomGetOffLoc { get; }
            public Vector3 BottomGetOnLoc { get; }
            public float ElevatorRadius { get; }
            public string Name { get; }

            public bool IsPointInElevatorShaft(Vector3 point)
            {
                return point.Z < TopRestingZ + 5 && point.Z > BottomRestingZ - 5 &&
                    point.Distance2DSquared(TopGetOnLoc) < ElevatorRadius * ElevatorRadius;
            }

            // Make sure we're completely on elevator, not just standing on the edge; which might cause toon to fall off and die.
            public bool IsFullyOnElevator(Vector3 myLoc)
            {
                var boardLoc = GetBoardLocation(Me.Location);
                return IsPointInElevatorShaft(Me.Location) &&
                       Me.Location.Distance2DSquared(boardLoc) <= (ElevatorRadius * ElevatorRadius) / 2f;
            }

            public Vector3 GetRandomBoardLocation(Vector3 myLoc)
            {
                var boardLoc = GetBoardLocation(myLoc);
                return WoWMathHelper.GetRandomPointInCircle(boardLoc, ElevatorRadius / 2f);
            }

            public Vector3 GetBoardLocation(Vector3 loc)
            {
                return loc.DistanceSquared(TopGetOnLoc) <
                       loc.DistanceSquared(BottomGetOnLoc)
                    ? TopGetOnLoc
                    : BottomGetOnLoc;
            }

            public Vector3 GetExitLocation(Vector3 loc)
            {
                return loc.DistanceSquared(TopGetOffLoc) <
                       loc.DistanceSquared(BottomGetOffLoc)
                    ? TopGetOffLoc
                    : BottomGetOffLoc;
            }
        }

        #endregion


        #endregion

        #region Tirathon Saltheril

        #region Trash

        #region Felsworn Infester
        private const uint MobId_FelswornInfester = 98271;
        private const int SpellId_Nightmares = 193069;

        [EncounterHandler(MobId_FelswornInfester, "Felsworn Infester")]
        public Func<WoWUnit, Task<bool>> FelswornInfesterHandler()
        {
            return async boss =>
            {
                return await ScriptHelpers.DispelGroup("Nightmares", ScriptHelpers.PartyDispelType.Magic) || await ScriptHelpers.InterruptCast(boss, SpellId_Nightmares);
            };
        }
        #endregion

        #region Immoliant Fury

        private const uint MobId_ImmoliantFury = 96584;

        [EncounterHandler(MobId_ImmoliantFury, "Immoliant Fury")]
        public Func<WoWUnit, Task<bool>> ImmoliantFuryHandler()
        {
            AddAvoidUnitCone(() => !Me.IsTank, 0, 10, 160, u => u.Entry == MobId_ImmoliantFury && u.IsAlive && u.DistanceSqr < 20 * 20);

            return async boss => false;
        }

        #endregion

        #region Glayvianna Soulrender

        private const uint MobId_GlayviannaSoulrender = 98177;

        [EncounterHandler(MobId_GlayviannaSoulrender, "Glayvianna Soulrender")]
        public Func<WoWUnit, Task<bool>> GlayviannaSoulrenderHandler()
        {
            // ToDO get Trap IDs
            return async boss => { return false; };
        }

        #endregion

        private const uint MobId_FelInfusedFury = 99956;

        #region Felsworn Myrmidon

        private const uint MobId_FelswornMyrmidon = 98954;
        private const int SpellId_DeafeningScreech = 191735;

        [EncounterHandler(MobId_FelswornMyrmidon, "Felsworn Myrmidon")]
        public Func<WoWUnit, Task<bool>> FelswornMyrmidonHandler()
        {
            AddAvoidObject<WoWUnit>(() => true, 5,
                // restrict distance because bots sometimes act crazy when near a fork due to path being blocked by avoid and it tring to take alt route. 
                u => u.Entry == MobId_FelswornMyrmidon && ((!Me.IsTank || u.CastingSpellId == SpellId_DeafeningScreech) && u.DistanceSqr < 20 * 20), 
                u => u.Location.RayCast(u.Rotation, 3));

            return async boss =>
            {
                return false;
            };
        }

        #endregion


        #endregion


        private const uint MobId_TirathonSaltheril = 95885;
        private const int SpellId_FuriousBlast = 191823;

        private const uint AreaTriggerId_ThrowGlaive = 9595;
        private const uint AreaTriggerId_FuriousFlames = 9573;

        private const uint AreaTriggerId_Hatred = 10572;
        private const uint MobId_Target = 96241;
        private const int MissileSpellId_FelMortar = 202920;
        private const int SpellId_Darkstrikes = 191941;
        private const uint MobId_Glaive_FelChainStart = 102644;
        private const uint MobId_Glaive_FelChainEnd = 102643;
        [EncounterHandler(MobId_TirathonSaltheril, "Tirathon Saltheril")]
        public Func<WoWUnit, Task<bool>> TirathonSaltherilHandler()
        {
            WoWUnit tirathonSaltheril = null;
            AddAvoidObject<WoWAreaTrigger>(3, AreaTriggerId_FuriousFlames);
            AddAvoidObject<WoWAreaTrigger>(2, AreaTriggerId_ThrowGlaive);
            AddAvoidObject<WoWUnit>(() => true, a => AvoidanceManager.IsRunningOutOfAvoid ? 20 : 10, a => a.Entry == MobId_Target);

            AddAvoidLocation(() => true, 3, m => m.ImpactPosition, () => WoWMissile.InFlightMissiles.Where(m => m.SpellId == MissileSpellId_FelMortar));

            // Avoid the hatred beam
            AddAvoidLine<WoWUnit>(() => ScriptHelpers.IsViable(tirathonSaltheril),
                u => u.Location,
                u => WoWMathHelper.CalculateNeededFacing(u.Location, tirathonSaltheril.Location),
                u => u.Location.Distance(tirathonSaltheril.Location),
                u => AvoidanceManager.IsRunningOutOfAvoid ? 20 : 10,
                u => u.Entry == MobId_Target);


            PerFrameCachedValue<WoWUnit> fellChainStartUnit = new PerFrameCachedValue<WoWUnit>(() => ObjectManager.GetObjectsOfType<WoWUnit>().FirstOrDefault(u => u.Entry == MobId_Glaive_FelChainStart));
            PerFrameCachedValue<WoWUnit> fellChainEndUnit = new PerFrameCachedValue<WoWUnit>(() => ObjectManager.GetObjectsOfType<WoWUnit>().FirstOrDefault(u => u.Entry == MobId_Glaive_FelChainEnd));

            // Avoid the fel chain
            AddAvoidLine<WoWUnit>(
                () => ScriptHelpers.IsViable(tirathonSaltheril) && tirathonSaltheril.Combat && ScriptHelpers.IsViable(fellChainEndUnit.Value),
                u => u.Location,
                u => WoWMathHelper.CalculateNeededFacing(u.Location, fellChainEndUnit.Value.Location),
                u => u.Location.Distance(fellChainEndUnit.Value.Location),
                u => 8,
                u => u.Entry == MobId_Glaive_FelChainStart,
                ignoreIfBlocking: true);

            AddAvoidObject<WoWUnit>(() => ScriptHelpers.IsViable(tirathonSaltheril) && tirathonSaltheril.Combat,
                u => 4,
                u => u.Entry == MobId_Glaive_FelChainStart || u.Entry == MobId_Glaive_FelChainEnd);

            var felChainSafeSpots = new[]
            {
                new Vector3(4290.709f, -450.1584f, 259.7367f),
                new Vector3(4287.359f, -460.175f, 259.5192f),
                new Vector3(4281.702f, -466.031f, 259.5192f),
                new Vector3(4276.455f, -470.3503f, 259.5192f),
                new Vector3(4268.286f, -470.6582f, 259.5192f),
                new Vector3(4262.292f, -465.1664f, 259.5192f),
                new Vector3(4258.599f, -454.8481f, 259.5192f),
                new Vector3(4261.25f, -439.4348f, 259.5192f),
                new Vector3(4267.981f, -432.6985f, 259.5192f),
                new Vector3(4277.609f, -430.7136f, 259.5192f),
                new Vector3(4285.707f, -433.0512f, 259.5192f),
            };

            return async boss =>
            {
                tirathonSaltheril = boss;

                if (await ScriptHelpers.InterruptCast(boss, SpellId_FuriousBlast))
                    return true;

                // Cast active mitigation to avoid boss from gaining Dark Energies buff
                if (boss.CastingSpellId == SpellId_Darkstrikes && await ScriptHelpers.CastActiveMitigationSpell(boss))
                    return true;

                Func<bool> isFelChainActive =
                    () =>
                        ScriptHelpers.IsViable(fellChainStartUnit.Value) &&
                        ScriptHelpers.IsViable(fellChainEndUnit.Value);

                if (isFelChainActive())
                {
                    if (await ScriptHelpers.CastHeroism())
                        return true;

                    var chainCenter = (fellChainStartUnit.Value.Location + fellChainEndUnit.Value.Location) / 2;
                    var safeSpot = felChainSafeSpots.OrderByDescending(l => l.DistanceSquared(chainCenter)).First();


                    if (Me.IsRanged)
                    {
                        // Healer needs to prioritize healing over moving.
                        return await ScriptHelpers.StayAtLocationWhile(() => isFelChainActive() && (!Me.IsHealer || !Me.RaidMembers.All(p => p.HealthPercent > 50)),
                            safeSpot,
                                    "Fel Chain Safe Location");

                    }

                    if (Me.IsTank)
                    {
                        if (Me.HealthPercent > 50)
                            return await ScriptHelpers.TankUnitAtLocation(safeSpot, 8);

                        if (await ScriptHelpers.CastActiveMitigationSpell(boss))
                            return true;
                    }
                }

                return false;
            };
        }

        #endregion

        #region Inquisitor Tormentorum

        #region Trash

        #region Blazing Imp

        private const uint MobId_BlazingImp = 98963;
        private const int SpellId_Implosion = 194682;

        [EncounterHandler(MobId_BlazingImp, "Blazing Imp")]
        public Func<WoWUnit, Task<bool>> BlazingImpHandler()
        {
            AddAvoidObject<WoWUnit>(4, u => u.Entry == MobId_BlazingImp && u.CastingSpellId == SpellId_Implosion);

            return async boss => { return false; };
        }

        #endregion

        #region Foul Mother

        private const uint MobId_FoulMother = 98533;
        private const int MissileSpellId_Mortar = 194036;
        private const int SpellId_AMothersLove = 194064;
        private const uint AreaTriggerId_ImpMother = 11290;
        private const uint AreaTriggerId_AMothersLove = 9786;

        [EncounterHandler(MobId_FoulMother, "Foul Mother")]
        public Func<WoWUnit, Task<bool>> FoulMotherHandler()
        {
            Vector2[] aMothersLovePoly = 
            {
                new Vector2(0f, 1f),
                new Vector2(0f, -1f),
                new Vector2(28.9778f, -7.76457f),
                new Vector2(28.9778f, 7.76457f)
            };

            AddAvoidLocation(() => true, 2.5f, m => m.ImpactPosition, () => WoWMissile.InFlightMissiles.Where(m => m.SpellId == MissileSpellId_Mortar));
            AddAvoidObject<WoWAreaTrigger>(5, AreaTriggerId_ImpMother);

            // Mob casts a frontal cone effect that is left on ground.
            AddAvoidPolygon(() => true, null, 40, a => a.Rotation, a => 1, a => 15,
                a => aMothersLovePoly, a => a.Location,
                () => ObjectManager.ObjectList.Where(a =>
                {
                    if (a.Entry == AreaTriggerId_AMothersLove && a is WoWAreaTrigger)
                        return true;

                    WoWUnit unit;
                    return a.Entry == MobId_FoulMother && (unit = a as WoWUnit) != null && unit.CastingSpellId == SpellId_AMothersLove;
                }));

            return async boss => false;
        }
        #endregion

        #endregion

        private const uint MobId_InquisitorTormentorum = 96015;
        private const int SpellId_SapSoul = 200905;

        [EncounterHandler(MobId_InquisitorTormentorum, "Inquisitor Tormentorum")]
        public Func<WoWUnit, Task<bool>> InquisitorTormentorumHandler()
        {
            return async boss =>
            {
                if (await ScriptHelpers.InterruptCast(boss, SpellId_SapSoul))
                    return true;

                return false;
            };
        }

        private const uint MobId_MogushanSecretKeeper = 99676;
        private const int MissileSpellId_StoneBlock = 204905;

        [EncounterHandler(MobId_MogushanSecretKeeper, "Mogu'shan Secret-Keeper")]
        public Func<WoWUnit, Task<bool>> MogushanSecretKeeperHandler()
        {
            AddAvoidLocation(() => true, 2.5f, m => m.ImpactPosition, () =>  WoWMissile.InFlightMissiles.Where(m => m.SpellId == MissileSpellId_StoneBlock));
            return async npc =>
            {
                if (await ScriptHelpers.DispelGroup("Flesh to Stone", ScriptHelpers.PartyDispelType.Magic))
                    return true;

                return false;
            };
        }

        private const uint MobId_EnormousStoneQuilen = 99675;
        private const int SpellId_MonstrousBite = 125096;

        [EncounterHandler(MobId_EnormousStoneQuilen, "Enormous Stone Quilen")]
        public Func<WoWUnit, Task<bool>> EnormousStoneQuilenHandler()
        {
            return async npc =>
            {
                // Monsrous Bite does big damage to the tank
                if (npc.CastingSpellId == SpellId_MonstrousBite && await ScriptHelpers.CastActiveMitigationSpell(npc))
                    return true;

                return false;
            };
        }

        private const uint MobId_VoidTouchedJuggernaut = 99655;

        [EncounterHandler(MobId_VoidTouchedJuggernaut, "Void-Touched Juggernaut")]
        public Func<WoWUnit, Task<bool>> VoidTouchedJuggernautHandler()
        {
            AddAvoidUnitCone(() => !Me.IsTank, 0, 10, 160, u => u.Entry == MobId_VoidTouchedJuggernaut && u.Combat);
            return async npc =>
            {
                if (await ScriptHelpers.DispelEnemy("Enrage", ScriptHelpers.EnemyDispelType.Enrage, npc))
                    return true;

                if (npc.HasAura("Enrage") && await ScriptHelpers.CastActiveMitigationSpell(npc))
                    return true;

                return false;
            };
        }

        private const uint MobId_DerangedMindflayer = 99657;
        private const int SpellId_FrighteningShout = 201488;

        [EncounterHandler(MobId_DerangedMindflayer, "Deranged Mindflayer")]
        public Func<WoWUnit, Task<bool>> DerangedMindflayerHandler()
        {
            return async npc =>
            {
                if (await ScriptHelpers.InterruptCast(npc, SpellId_FrighteningShout))
                    return true;
                
                return false;
            };
        }

        private const uint MobId_FacelessVoidcasters = 99651;
        private const int MissileSpellId_ShadowCrash = 199915;
        private const int MissileSpellId_ShadowCrashTargeting = 199919;
        private const uint AreaTriggerId_ShadowCrash = 10309;

        [EncounterHandler(MobId_FacelessVoidcasters, "Faceless Voidcaster")]
        public Func<WoWUnit, Task<bool>> FacelessVoidcastersHandler()
        {
            AddAvoidLocation(() => true, 10, m => m.ImpactPosition, 
                () => WoWMissile.InFlightMissiles.Where(m => m.SpellId == MissileSpellId_ShadowCrash || m.SpellId == MissileSpellId_ShadowCrashTargeting));

            AddAvoidObject<WoWAreaTrigger>(4, AreaTriggerId_ShadowCrash);

            return async npc => false;
        }

        private const uint MobId_LingeringCorruption = 99678;

        [EncounterHandler(MobId_LingeringCorruption, "Lingering Corruption")]
        public Func<WoWUnit, Task<bool>> LingeringCorruptionHandler()
        {
            AddAvoidObject<WoWPlayer>(8, p => !p.IsMe && (Me.HasAura("Corrupted Touch") || p.HasAura("Corrupted Touch")));

            return async npc =>
            {
                var corruptedTouchTarget =
                    Me.RaidMembers.FirstOrDefault(
                        p =>
                            p.HasAura("Corrupted Touch") &&
                            !Me.RaidMembers.Any(r => p != r && p.Location.DistanceSquared(r.Location) < 8 * 8));

                if (corruptedTouchTarget != null 
                    && await ScriptHelpers.DispelFriendlyUnit("Corrupted Touch", ScriptHelpers.PartyDispelType.Magic, corruptedTouchTarget))
                {
                    return true;
                }

                return false;
            };
        }

        private const uint MobId_FelguardAnnihilator = 99644;
        private const uint MobId_ShadowmoonTechnician = 99645;
        private const int MissileSpellId_ThrowProximityBomb = 196156;
        private const uint GameObjectId_ProximityBomb = 245335;

        [EncounterHandler(MobId_ShadowmoonTechnician, "Shadowmoon Technician")]
        public Func<WoWUnit, Task<bool>> ShadowmoonTechnicianHandler()
        {
            AddAvoidLocation(() => true, 5, m => m.ImpactPosition, () => WoWMissile.InFlightMissiles.Where(m=> m.SpellId == MissileSpellId_ThrowProximityBomb));
            AddAvoidObject<WoWGameObject>(5, GameObjectId_ProximityBomb);

            return async npc => false;
        }

        private const uint MobId_ShadowmoonWarlock = 99704;
        [EncounterHandler(MobId_ShadowmoonWarlock, "Shadowmoon Warlock")]
        public Func<WoWUnit, Task<bool>> ShadowmoonWarlockHandler()
        {
            // Run away from other players if has Seed of Corruption.
            AddAvoidObject<WoWPlayer>(() => !Me.IsTank, 10, p => !p.IsMe && (Me.HasAura("Seed of Corruption") || p.HasAura("Seed of Corruption")));

            return async npc =>
            {
                var seedOfCorruptionTarget =
                    Me.RaidMembers.FirstOrDefault(
                        p =>
                            p.HasAura("Seed of Corruption") &&
                            !Me.RaidMembers.Any(r => p != r && p.Location.DistanceSquared(r.Location) < 10 * 10));

                if (seedOfCorruptionTarget != null
                    &&  await ScriptHelpers.DispelFriendlyUnit("Seed of Corruption", ScriptHelpers.PartyDispelType.Magic, seedOfCorruptionTarget))
                {
                    return true;
                }

                if (await ScriptHelpers.DispelGroup("Curse of Tongues", ScriptHelpers.PartyDispelType.Curse))
                    return true;

                return false;
            };
        }

        #endregion

        #region Ash'Golm

        #region Trash

        #region Dreadlord Mendacius


        private const uint MobId_DreadlordMendacius = 99649;
        private const int MissileSpellId_Meteor = 199870;
        private const uint MobId_Grimguard = 99728;

        [EncounterHandler(MobId_DreadlordMendacius, "Dreadlord Mendacius")]
        public Func<WoWUnit, Task<bool>> DreadlordMendaciusHandler()
        {
            WoWUnit dreadlordMendacius = null;

            PerFrameCachedValue<WoWUnit> meteorTarget = new PerFrameCachedValue<WoWUnit>(() =>
                WoWMissile.InFlightMissiles.Where(m => m.SpellId == MissileSpellId_Meteor)
                    .Select(m => m.Target)
                    .FirstOrDefault());

            return async boss =>
            {
                dreadlordMendacius = boss;
                if (meteorTarget.Value != null && Me.IsDps)
                {
                    return
                        await
                            ScriptHelpers.StayAtLocationWhile(() => meteorTarget.Value != null,
                                meteorTarget.Value.Location, "Metor impact location", 7);
                }

                return false;
            };
        }
        #endregion

        #endregion

        private const uint MobId_AshGolm = 95886;
        private const uint MobId_Countermeasures = 99240;
        private const uint MobId_Ember = 99233;

        private const int SpellId_Detonate = 195187;

        private const int MissileSpellId_LavaWreath = 193354;
        private const int MissileSpellId_Pyroclast = 192621;
        private const int MissileSpellId_Fissure1 = 193355;
        private const int MissileSpellId_Fissure2 = 213217;

        private const uint AreaTriggerId_Volcano = 10225;
        private const uint AreaTriggerId_LavaWreath = 9709;
        private const uint AreaTriggerId_Fissure1 = 9701;
        private const uint AreaTriggerId_Fissure2 = 11552;
        private bool _burnAshGolm;

        [EncounterHandler(MobId_AshGolm, "Ash'Golm", Mode = CallBehaviorMode.Proximity)]
        public Func<WoWUnit, Task<bool>> AshGolmHandler()
        {
            var leftEntranceEdge = new Vector3(4274.552f, -457.0078f, 106.1051f);
            var rightEntranceEdge = new Vector3(4274.615f, -445.16f, 105.9242f);
            var locationOnPlatform = WoWMathHelper.GetRandomPointInCircle(
                new Vector3(4272.426f, -451.4417f, 105.8638f), 1);

            var roomCenterLoc = new Vector3(4238.941f, -451.2684f, 105.8638f);
            HashSet<int> missileIds = new HashSet<int>(new[] { MissileSpellId_LavaWreath, MissileSpellId_Pyroclast, MissileSpellId_Fissure1, MissileSpellId_Fissure2 });


            AddAvoidLocation(() => true, () => roomCenterLoc, 25, 5, m => m.ImpactPosition,
                () => WoWMissile.InFlightMissiles.Where(m => missileIds.Contains(m.SpellId)));

            AddAvoidObject<WoWAreaTrigger>(() => true, () => roomCenterLoc, 25, 2, a => a.Entry == AreaTriggerId_Volcano);
            AddAvoidObject<WoWAreaTrigger>(() => true, () => roomCenterLoc, 25, 4, a => a.Entry == AreaTriggerId_LavaWreath);
            AddAvoidObject<WoWAreaTrigger>(() => true, () => roomCenterLoc, 25, 3, a => a.Entry == AreaTriggerId_Fissure1 || a.Entry == AreaTriggerId_Fissure2);

            Vector2[] bridgePoly =
            {
                new Vector2(8.488281f, -5.355804f),
                new Vector2(-7.59375f, -5.96051f),
                new Vector2(-7.59082f, 7.125702f),
                new Vector2(8.407227f, 6.94281f),
            };

            var bridgeLoc = new Vector3(4283.035f, -450.5484f, 105.3744f);

            AddAvoidPolygon(() => true, null, 40, v => 0, v => 1, v => 15, v => bridgePoly, v => v, () => new[] { bridgeLoc });

            return async boss =>
            {
                if (await ScriptHelpers.MoveInsideBossRoom(boss, leftEntranceEdge, rightEntranceEdge, locationOnPlatform))
                    return true;


                if (!boss.Combat)
                    return false;

                _burnAshGolm = boss.HasAura("Brittle");

                if (_burnAshGolm)
                {
                    if (boss.HealthPercent > 20 && await ScriptHelpers.CastHeroism())
                        return true;
                }
                else if (!Me.GroupInfo.IsInParty
                        || GroupMember.GroupMembers.Where(g => g.IsDps && g.IsAlive && g.IsAlive).OrderByDescending(g => g.MaxHealth).First().Guid == Me.Guid)
                {
                    var statue =
                        ObjectManager.GetObjectsOfType<WoWUnit>()
                            .Where(u => u.Entry == MobId_Countermeasures && u.CanInteractNow)
                            .OrderBy(u => u.DistanceSqr)
                            .FirstOrDefault();

                    // Interact with statue to cause boss to become frozen and take 25% more damage for 20 seconds
                    if (statue != null && await ScriptHelpers.InteractWithObject(statue, 1000, true))
                        return true;
                }

                if (Me.IsRanged)
                {
                    // stay away from edge of platform to avoid getting knocked off by Pyroclast
                    return await ScriptHelpers.StayAtLocationWhile(() => boss.IsValid && boss.Combat, roomCenterLoc,
                        boss.SafeName, 25);
                }

                if (Me.IsTank)
                    return await ScriptHelpers.TankUnitAtLocation(roomCenterLoc, 8);

                return false;
            };

        }

        #endregion

        #region Glazer

        #region Trash

        private const uint MobId_MalignantDefiler = 102584;
        private const uint MobId_FelScorcher = 102583;

        #region Blade Dancer Illianna

        private const uint MobId_BladeDancerIllianna = 96657;
        private const int SpellId_Pierce = 191524;
        private const int SpellId_DeafeningShout = 191527;

        [EncounterHandler(MobId_BladeDancerIllianna, "Blade Dancer Illianna")]
        public Func<WoWUnit, Task<bool>> BladeDancerIlliannaHandler()
        {
            return async boss =>
            {
                // Pierce does heavy tank damage.
                if (boss.CastingSpellId == SpellId_Pierce && Me.IsTank && await ScriptHelpers.CastActiveMitigationSpell(boss))
                    return true;

                if (await ScriptHelpers.DispelGroup("Gift of the Doomsayer", ScriptHelpers.PartyDispelType.Magic))
                    return true;

                // stop casting to avoid getting locked out of spell school
                if (boss.CastingSpellId == SpellId_DeafeningShout && Me.IsCasting
                    && boss.CurrentCastEndTime < Me.CurrentCastEndTime)
                {
                    SpellManager.StopCasting();
                    return await Coroutine.Wait(2000, () => !boss.IsCasting);
                }

                return false;
            };
        }

        #endregion

        #endregion

        private const uint AreaTriggerId_Pulse = 9856;

        private const uint MobId_Glazer = 95887;
        private const uint AreaTriggerId_LingeringGaze = 9862;
        private const uint MobId_Lens = 98082;

        private readonly HashSet<int> MissileSpellIds_LingeringGaze = new HashSet<int>(new[] { 194942, 201395, 201396 });

        [EncounterHandler(MobId_Glazer, "Glazer")]
        public Func<WoWUnit, Task<bool>> GlazerHandler()
        {
            WoWUnit glazer = null;
            var leftEntranceEdge = new Vector3(4456.796f, -628.2187f, 117.1494f);
            var rightEntranceEdge = new Vector3(4445.41f, -628.2628f, 117.1494f);
            var locationOnPlatform = WoWMathHelper.GetRandomPointInCircle(
                new Vector3(4451.265f, -636.0923f, 117.1494f), 1.5f);

            Vector2[] bridgePoly =
            {
                new Vector2(-5.501953f, 4.533691f),
                new Vector2(-5.62793f, -8.326843f),
                new Vector2(6.716797f, -8.274536f),
                new Vector2(6.619141f, 4.899048f)
            };

            var bridgeLoc = new Vector3(4451.356f, -623.7938f, 117.1494f);

            AddAvoidPolygon(() => ScriptHelpers.IsViable(glazer) && glazer.Combat, null, 40, v => 0, v => 1, v => 15, v => bridgePoly, v => v, () => new[] { bridgeLoc });

            AddAvoidLine<WoWAreaTrigger>(() => true, u => u.Location, u => u.Rotation, u => 30, u => 4.5f, u => u.Entry == AreaTriggerId_Pulse);

            // Avoid the beam the boss casts.
            AddAvoidLine<WoWUnit>(() => true,
                // moves the start location to a location behind boss, so that players standing on boss don't get hit
                u => WoWMathHelper.CalculatePointBehind(u.Location, u.Rotation, 4), u => u.Rotation,
                u => 60, u => AvoidanceManager.IsRunningOutOfAvoid ? 10 : 4.5f,
                u => u.Entry == MobId_Glazer && u.HasAura("Focusing"));

            AddAvoidObject<WoWAreaTrigger>(4, AreaTriggerId_LingeringGaze);
            AddAvoidLocation(() => true, 4, m => m.ImpactPosition, () => WoWMissile.InFlightMissiles.Where(m => MissileSpellIds_LingeringGaze.Contains(m.SpellId)));

            return async boss =>
            {
                glazer = boss;

                if (!boss.Combat)
                {
                    return await ScriptHelpers.MoveInsideBossRoom(boss, leftEntranceEdge, rightEntranceEdge,
                                locationOnPlatform);
                }

                if (Me.IsTank)
                {
                    //var pulse =
                    //    ObjectManager.GetObjectsOfType<WoWAreaTrigger>()
                    //        .Where(a => a.Entry == AreaTriggerId_Pulse)
                    //        .OrderBy(a => a.DistanceSqr)
                    //        .FirstOrDefault();

                    //if (pulse != null)
                    //{
                    //    var nearestPointOnPulsePath = Me.Location.GetNearestPointOnSegment(pulse.Location,
                    //        pulse.Location.RayCast(pulse.Rotation, 80));

                    //    if (Me.Location.DistanceSquared(nearestPointOnPulsePath) < 25 * 25)
                    //    {
                    //        var tankLoc = WoWMathHelper.CalculatePointFrom(Me.Location, nearestPointOnPulsePath, -10);
                    //        return await ScriptHelpers.TankUnitAtLocation(tankLoc, 4);
                    //    }
                    //}
                }

                if (boss.HasAura("Focusing"))
                {
                    var lens = ObjectManager.GetObjectsOfType<WoWUnit>()
                        .Where(u => u.Entry == MobId_Lens).ToList();

                }

                return false;
            };
        }

        #endregion

        #region Cordana Felsong 

        #region Trash

        #region Grimhorn the Enslaver

        private const int MissileSpellId_AnguishedSouls = 202606;
        private const uint MobId_GrimhorntheEnslaver = 102566;
        private const uint AreaTriggerId_AnguishedSouls = 10546;
        private const uint MobId_Cage = 102572;

        [EncounterHandler(MobId_GrimhorntheEnslaver, "Grimhorn the Enslaver")]
        public Func<WoWUnit, Task<bool>> GrimhorntheEnslaverHandler()
        {
            AddAvoidLocation(() => true, 3, m => m.ImpactPosition, () => WoWMissile.InFlightMissiles.Where(m => m.SpellId == MissileSpellId_AnguishedSouls));
            AddAvoidObject<WoWAreaTrigger>(3, AreaTriggerId_AnguishedSouls);

            PerFrameCachedValue<WoWUnit> cage = new PerFrameCachedValue<WoWUnit>(() => ObjectManager.GetObjectsOfType<WoWUnit>()
                        .Where(u => u.Entry == MobId_Cage)
                        .OrderBy(u => u.DistanceSqr)
                        .FirstOrDefault());

            return async boss =>
            {
                if (Me.IsRanged && ScriptHelpers.IsViable(cage.Value) 
                    && await ScriptHelpers.StayAtLocationWhile(() => ScriptHelpers.IsViable(cage), cage.Value.Location, cage.Value.SafeName, 4))
                {
                    return true;
                }

                return false;
            };
        }

        #endregion

        #region Aranasi Broodmother

        private const uint MobId_AranasiBroodmother = 97678;
        private const int MissileSpellId_Razors = 193973;
        private const uint AreaTriggerId_Razors = 9777;

        [EncounterHandler(MobId_AranasiBroodmother, "Aranasi Broodmother")]
        public Func<WoWUnit, Task<bool>> AranasiBroodmotherHandler()
        {
            AddAvoidLocation(() => true, 5, m => m.ImpactPosition,
                () => WoWMissile.InFlightMissiles.Where(m => m.SpellId == MissileSpellId_Razors));

            AddAvoidObject<WoWAreaTrigger>(() => true, a => Me.HasAura("Pull") ? 8: 2, AreaTriggerId_Razors);

            return async boss => false;
        }


        #endregion
        private const uint MobId_SpiritofVengeance = 100364;
        private const uint AreaTriggerId_BarbedWeb = 9775;

        #endregion

        private const uint MobId_CordanaFelsong = 95888;
        private const uint MobId_GlowingSentry = 100525;
        private const uint MobId_ElunesLight = 103342;

        private const int MissileSpellId_DeepeningShadows = 213411;
        private const uint MobId_DeepeningShadows = 107533;
        private const uint MobId_AvatarofShadow = 104293;
        private const uint MobId_AvatarofVengeance = 100351;
        private const int MissileSpellId_AvatarofVengeance = 204984;

        private const uint AreaTriggerId_DeepeningShadows = 11568;
        private const uint AreaTriggerId_DetonatingMoonglaive = 10069;
        private const uint AreaTriggerId_FelGlaive = 10046;

        [EncounterHandler(MobId_CordanaFelsong, "Cordana Felsong", Mode = CallBehaviorMode.CurrentBoss)]
        public Func<WoWUnit, Task<bool>> CordanaFelsonHandler()
        {
            WoWUnit cordana = null;
            var roomCenter = new Vector3(4050f, -298f, -281.5898f);
            bool gettingLight = false;
            var platformPoly = new []
            {
                new Vector2(4083.029f, -265.066f),
                new Vector2(4018.874f, -265.3191f),
                new Vector2(4018.988f, -329.935f),
                new Vector2(4082.457f, -329.5442f),
            };

            var jumpOffPlatformPoints = new[]
            {
                new Vector3(4086.224f, -314.3956f, -281.1126f),
                new Vector3(4087.524f, -334.4145f, -281.1126f),
                new Vector3(4014.873f, -333.1892f, -281.1126f),
                new Vector3(4014.929f, -261.6658f, -281.1126f),
                new Vector3(4086.417f, -256.6658f, -281.1126f),
                new Vector3(4086.224f, -281.1126f, -281.1126f),
            };

            Func<Vector3> getNearestPlatformJumpOff = () =>
            {
                return GetNearestPointsOnSegments(jumpOffPlatformPoints)
                        .MinByOrDefault(l => Me.Location.DistanceSquared(l));
            };

            AddAvoidLocation(() => true, 3, m => m.ImpactPosition,
                        () => WoWMissile.InFlightMissiles.Where(m => m.SpellId == MissileSpellId_DeepeningShadows));


            AddAvoidObject<WoWAreaTrigger>(() => !gettingLight && !Me.HasAura("Elune's Light") && !Me.IsTank, 
                a =>
                {
                    var lightCarrier =
                        Me.RaidMembers.Where(m => m.HasAura("Elune's Light"))
                            .MinByOrDefault(r => r.Location.DistanceSquared(a.Location));

                    return lightCarrier?.Location.Distance(a.Location) + 1 ?? 15;
                }, 
                AreaTriggerId_DeepeningShadows);

            //AddAvoidObject<WoWAreaTrigger>(() => true, 4, a => a.Entry == AreaTriggerId_FelGlaive);

            AddAvoidObject<WoWUnit>(
                () =>
                    ScriptHelpers.IsViable(cordana) &&
                    (!Me.HasAura("Elune's Light") || Me.IsTank && !Me.PartyMembers.Any(p => p.HasAura("Elune's Light"))),
                u => u.MyAggroRange + 5, u => u.Entry == MobId_CordanaFelsong && u.IsAlive && !u.Combat);

            AddAvoidLine<WoWAreaTrigger>(() => ScriptHelpers.IsViable(cordana) && cordana.Combat,
                a => WoWMathHelper.CalculatePointFrom(a.Location, cordana.Location, -1),
                a => WoWMathHelper.CalculateNeededFacing(cordana.Location, a.Location), a => 40, a => 2, a => a.Entry == AreaTriggerId_DetonatingMoonglaive);

            return async boss =>
            {
                cordana = boss;
                if (!Me.HasAura("Elune's Light") && (!Me.IsTank || !Me.Combat || Targeting.Instance.TargetList.All(u => u.Aggro)))
                {
                    var light =
                        ObjectManager.GetObjectsOfType<WoWUnit>()
                            .Where(
                                u =>
                                    (u.Entry == MobId_GlowingSentry && u.HasAura("Elune's Light") ||
                                     u.Entry == MobId_ElunesLight) && u.DistanceSqr < 100 * 100)
                            .MinByOrDefault(u => u.DistanceSqr);

                    if (light != null)
                    {
                        var tank = ScriptHelpers.Tank;
                        WoWUnit designatedPickup = tank != null && tank.IsAlive && !tank.HasAura("Elune's Light")
                            ? tank
                            : Me.RaidMembers.Where(r => r.IsAlive && r.IsDps && !r.HasAura("Elune's Light"))
                                .OrderByDescending(r => r.MaxHealth)
                                .FirstOrDefault();

                        if (designatedPickup == Me)
                        {
                            var bossEncounterActive = boss != null && boss.Combat;
                            if (!bossEncounterActive && light.DistanceSqr > 40 * 40)
                            {
                                if (!Me.IsTank)
                                    return false;

                                if (!Me.Combat)
                                    return ScriptHelpers.SetLeaderMoveToPoi(light.Location, light.SafeName);
                            }

                            if (Me.IsFollower() && !bossEncounterActive && ScriptHelpers.WillPullAggroAtLocation(light.Location))
                            {
                                return false;
                            }
                            gettingLight = true;
                            return await ScriptHelpers.InteractWithObject(light, ignoreCombat: bossEncounterActive || Me.IsTank);
                        }
                    }
                }
                else
                {

                    if (boss != null && boss.Combat && !Me.IsTank && ScriptHelpers.Tank != null
                        && !WoWMathHelper.IsPointInPoly(ScriptHelpers.Tank.Location, platformPoly)
                        && WoWMathHelper.IsPointInPoly(Me.Location, platformPoly))
                    {
                        var moveTo = getNearestPlatformJumpOff();
                        Logger.Write("Jumping off platform because tank isn't on it");
                        Navigator.PlayerMover.MoveTowards(moveTo);
                        await Coroutine.Sleep(1000);
                        return true;
                    }

                    gettingLight = false;
                    var deepeningShadows =
                        ObjectManager.GetObjectsOfType<WoWAreaTrigger>()
                            .Where(a => a.Entry == AreaTriggerId_DeepeningShadows)
                            .MinByOrDefault(a => a.DistanceSqr);

                    if (deepeningShadows != null && (!Me.IsTank || Targeting.Instance.TargetList.All(u => u.Aggro)))
                    {
                        return await (Me.IsTank
                            ? ScriptHelpers.TankUnitAtLocation(deepeningShadows.Location, 4)
                            : ScriptHelpers.StayAtLocationWhile(() => ScriptHelpers.IsViable(deepeningShadows),
                                deepeningShadows.Location, deepeningShadows.SafeName));
                    }

                    if (boss == null)
                    {
                        var revealLoc = await GetShadowStepLoc();
                        if (revealLoc != Vector3.Zero)
                            return await RevealHiddenMob(revealLoc, "Cordana Felsong");
                    }
                    else
                    {


                        var revealLoc = await GetAvatarOfVengeance();
                        if (revealLoc != Vector3.Zero)
                            return await RevealHiddenMob(revealLoc, "Avatar of Vengeance");

                        return boss.Combat && await ScriptHelpers.TankUnitAtLocation(roomCenter, 8);
                    }
                }

                return false;
            };
        }

        private IEnumerable<Vector3> GetNearestPointsOnSegments(Vector3[] points)
        {
            var myLoc = Me.Location;
            for (int i = 1; i < points.Length; i++)
                yield return myLoc.GetNearestPointOnSegment(points[i - 1], points[i]);
        }

        private async Task<bool> RevealHiddenMob(Vector3 location, string name)
        {
            if (Me.IsTank)
                return (await CommonCoroutines.MoveTo(location, name)).IsSuccessful();

            return await ThrowLight(_avatarOfVengeanceLoc, name);
        }

        private readonly WaitTimer _shadowstepTimer = new WaitTimer(TimeSpan.FromSeconds(1));
        private Vector3 _shadowstepLoc = Vector3.Zero;

        private async Task<Vector3> GetShadowStepLoc()
        {
            if (!_shadowstepTimer.IsFinished)
                return _shadowstepLoc;

            Func<List<WoWAreaTrigger>> getFelGlaives = () => ObjectManager.GetObjectsOfType<WoWAreaTrigger>()
                .Where(a => a.Entry == AreaTriggerId_FelGlaive)
                .OrderByDescending(a => a.TimeLeft)
                .ToList();

            var felGlaives = getFelGlaives();
            _shadowstepLoc = Vector3.Zero;

            if (felGlaives.Count >= 2)
            {
                var savedLocs = felGlaives.ToDictionary(u => u.Guid, u => u.Location);
                await Coroutine.Sleep(1000);
                var glaiveCoords = (from glaive in getFelGlaives()
                    where savedLocs.ContainsKey(glaive.Guid)
                    let prevLocation = savedLocs[glaive.Guid]
                    select new {Start = prevLocation, End = glaive.Location}).Take(2).ToList();

                if (glaiveCoords.Count >= 2)
                {
                    Vector2 intersection;
                    var line1Start = glaiveCoords[0].Start.ToVector2();
                    var line1End = glaiveCoords[0].End.ToVector2();
                    var line2Start = glaiveCoords[1].Start.ToVector2();
                    var line2End = glaiveCoords[1].End.ToVector2();

                    Logger.Write($"Checking for intersection at {line1Start} to {line1End} and from {line2Start} to {line2End}");

                    if (LinesIntersect(line1Start, line1End,
                        line2Start, line2End, out intersection))
                    {
                        _shadowstepLoc = new Vector3(intersection, glaiveCoords[0].Start.Z);
                        _shadowstepTimer.Reset();
                    }
                }
            }
            return _shadowstepLoc;
        }

        private readonly WaitTimer _avatarOfVengeanceTimer = new WaitTimer(TimeSpan.FromSeconds(30));
        private Vector3 _avatarOfVengeanceLoc = Vector3.Zero;

        private async Task<Vector3> GetAvatarOfVengeance()
        {
            if (ObjectManager.GetObjectsOfType<WoWUnit>().Any(u => u.Entry == MobId_AvatarofVengeance))
                return Vector3.Zero;

            if (!_avatarOfVengeanceTimer.IsFinished)
                return _avatarOfVengeanceLoc;

            var avatarOfVengeanceMissile =
                WoWMissile.InFlightMissiles.FirstOrDefault(m => m.SpellId == MissileSpellId_AvatarofVengeance);

            if (avatarOfVengeanceMissile != null)
            {
                _avatarOfVengeanceTimer.Reset();
                _avatarOfVengeanceLoc = avatarOfVengeanceMissile.ImpactPosition;
                return _avatarOfVengeanceLoc;
            }
            return Vector3.Zero;
        }

        private async Task<bool> ThrowLight(Vector3 location, string name)
        {
            if (!Me.HasAura("Elune's Light"))
                return false;

            if (Me.Location.DistanceSquared(location) > 30 * 30)
                return (await CommonCoroutines.MoveTo(location, name)).IsSuccessful();

            var button = ActionBar.Extra.Buttons.FirstOrDefault();
            if (button == null)
                return false;

            button.Use();
            SpellManager.ClickRemoteLocation(location);
            return true;
        }

        #endregion


        #region Utility

        static bool LinesIntersect(Vector2 lineStart1, Vector2 lineEnd1, Vector2 lineStart2, Vector2 lineEnd2, out Vector2 intersection)
        {
            var a1 = lineEnd1.Y - lineStart1.Y;
            var b1 = lineStart1.X - lineEnd1.X;
            var c1 = a1 * lineStart1.X + b1 * lineStart1.Y;

            var a2 = lineEnd2.Y - lineStart2.Y;
            var b2 = lineStart2.X - lineEnd2.X;
            var c2 = a2 * lineStart2.X + b2 * lineStart2.Y;

            float determinant = a1 * b2 - a2 * b1;

            if (IsZero(determinant))
            {
                intersection = Vector2.Zero;
                return false;
            }

            float x = (b2 * c1 - b1 * c2) / determinant;
            float y = (a1 * c2 - a2 * c1) / determinant;
            intersection = new Vector2(x,y);
            return true;
        }


        private const double Epsilon = 1e-10;

        private static bool IsZero(float d)
        {
            return Math.Abs(d) < Epsilon;
        }

        #endregion

    }

    #endregion

    #region Heroic Difficulty

    public class VaultOfTheWardensHeroic : VaultOfTheWardens
    {
        public override uint DungeonId => 1044;
    }

    #endregion

}