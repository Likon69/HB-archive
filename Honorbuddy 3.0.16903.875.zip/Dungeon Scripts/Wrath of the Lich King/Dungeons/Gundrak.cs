using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Threading.Tasks;
using CommonBehaviors.Actions;
using Styx;
using Styx.Common.Helpers;
using Styx.CommonBot;
using Styx.Pathing;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using Styx.TreeSharp;
using Action = Styx.TreeSharp.Action;
using Bots.DungeonBuddy.Profiles;
using Bots.DungeonBuddy.Attributes;
using Bots.DungeonBuddy.Helpers;
using Buddy.Coroutines;
using Styx.Common;
using Styx.CommonBot.Coroutines;
using Styx.CommonBot.POI;

namespace Bots.DungeonBuddy.Dungeon_Scripts.Wrath_of_the_Lich_King
{
    public class Gundrak : Dungeon
    {
        #region Overrides of Dungeon

        private const float BridgeZ = 118;
        private const float SouthBridgeX = 1748;
        private const float NorthBridgeX = 1797;
        private const float BridgeMinY = 736;
        private const float BridgeMaxY = 751;
        private readonly Vector3 _northBridgeLocation = new Vector3(1800.753f, 743.4679f, 119.1964f);
        private readonly Vector3 _nwEntrance = new Vector3(6973.548f, -4399.409f, 441.5767f);
        private readonly Vector3 _seEntrance = new Vector3(6699.581f, -4662.947f, 441.5676f);
        private readonly Vector3 _southBridgeLocation = new Vector3(1751.669f, 744.2233f, 118.9558f);
        private WaitTimer _deathTimer;

        public override uint DungeonId
        {
            get { return 216; }
        }

        public override Vector3 Entrance
        {
            get
            {
                if (_deathTimer == null)
                {
                    _deathTimer = new WaitTimer(TimeSpan.FromMinutes(2));
                    _deathTimer.Reset();
                }
                var corsePoint = Me.CorpsePoint;
                if (corsePoint != Vector3.Zero)
                    return corsePoint.DistanceSquared(_nwEntrance) < corsePoint.DistanceSquared(_seEntrance) ? _nwEntrance : _seEntrance;
                return Me.Location.DistanceSquared(_nwEntrance) < Me.Location.DistanceSquared(_seEntrance) ? _nwEntrance : _seEntrance;
            }
        }

        public override Vector3 ExitLocation
        {
            get { return new Vector3(1898.504f, 657.7404f, 176.6373f); }
        }

        public override void RemoveTargetsFilter(List<WoWObject> units)
        {
            units.RemoveAll(
                ret =>
                {
                    if (ret.Entry == DrakkariFrenzyId && (!ret.ToUnit().Combat || Me.IsMoving))
                        return true;
                    if (ret.Entry == GaldarahId && ret.ToUnit().HasAura("Whirling Slash") && Me.IsMelee() && Me.IsDps)
                        return true;
                    return false;
                });
        }

        public override void IncludeTargetsFilter(List<WoWObject> incomingunits, HashSet<WoWObject> outgoingunits)
        {
            foreach (var obj in incomingunits)
            {
                var unit = obj as WoWUnit;
                if (unit != null)
                {
                    if (unit.Entry == SnakeWrapId)
                        outgoingunits.Add(unit);
                }
            }
        }

        public override void WeighTargetsFilter(List<Targeting.TargetPriority> units)
        {
            foreach (var priority in units)
            {
                var unit = priority.Object as WoWUnit;
                if (unit != null)
                {
                    if (unit.Entry == SnakeWrapId && StyxWoW.Me.IsDps)
                        priority.Score += 500;
                }
            }
        }

        public override void OnExit()
        {
            // Restore movement in case we fought with Eck.
            ScriptHelpers.RestoreMovement();
        }

        #endregion

        private const uint SnakeWrapId = 29742;
        private const uint SladranId = 29304;
        private const uint DrakkariFrenzyId = 29834;
        private const uint GaldarahId = 29306;
        private readonly int[] _frostNovaIds = new[] { 59842, 55081 };

        protected LocalPlayer Me => StyxWoW.Me;

        [EncounterHandler(0, "Root")]
        public Composite RootBehavior()
        {
            return new PrioritySelector(
                // make sure we're at the right entrance when porting in after dieing.
                // fixed by zoning out and back in.
                new Decorator(
                    ctx => _deathTimer != null,
                    new Sequence(
                        new DecoratorContinue(
                            ctx => !_deathTimer.IsFinished && Me.Location.Distance(ExitLocation) > 50,
                            new Sequence(
                                new Action(ctx => Logger.Write("Porting outside because I'm not at right entrance.")),
                                new Action(ctx => ScriptHelpers.TelportOutsideLfgInstance()),
                                new WaitContinue(2, ctx => !StyxWoW.IsInWorld, new ActionAlwaysSucceed()),
                                new WaitContinue(40, ctx => StyxWoW.IsInWorld, new ActionAlwaysSucceed()),
                                new Action(ctx => Lua.DoString("LFGTeleport(false)")))),
                        new Action(ctx => _deathTimer = null))),
                new PrioritySelector(
                    ctx => ScriptHelpers.Tank,
                    new Decorator<WoWPlayer>(
                        tank => !Me.IsTank() && Me.IsSwimming && tank != null && !tank.IsSwimming && Navigator.LookupPathInfo(tank).Navigability == PathNavigability.Navigable,
                        new Helpers.Action<WoWPlayer>(tank => Navigator.MoveTo(tank.Location)))));
        }

        #region Quests

        [EncounterHandler(55738, "Tol'mar", Mode = CallBehaviorMode.Proximity, BossRange = 75)]
        public Composite QuestPickupHandler()
        {
            WoWUnit unit = null;
            const int galdarahMustPayQuestId = 29834;
            const int forPosterityQuestId = 29844;
            const int oneOfAKindQuestId = 29839;

            return new PrioritySelector(
                ctx => unit = ctx as WoWUnit,
                new Decorator(
                    ctx => !Me.Combat && !ScriptHelpers.WillPullAggroAtLocation(unit.Location) && unit.QuestGiverStatus == QuestGiverStatus.Available,
                    new PrioritySelector(
                        new Decorator(
                            ctx => !Me.QuestLog.ContainsQuest(galdarahMustPayQuestId) && !Me.QuestLog.GetCompletedQuests().Contains(galdarahMustPayQuestId),
                            ScriptHelpers.CreatePickupQuest(ctx => unit, galdarahMustPayQuestId)))),
                        new Decorator(
                            ctx => !Me.QuestLog.ContainsQuest(forPosterityQuestId) && !Me.QuestLog.GetCompletedQuests().Contains(forPosterityQuestId),
                            ScriptHelpers.CreatePickupQuest(ctx => unit, forPosterityQuestId)),
                        new Decorator(
                            ctx => !Me.QuestLog.ContainsQuest(oneOfAKindQuestId) && !Me.QuestLog.GetCompletedQuests().Contains(oneOfAKindQuestId),
                            ScriptHelpers.CreatePickupQuest(ctx => unit, oneOfAKindQuestId)),

                new Decorator(
                    ctx => !Me.Combat && !ScriptHelpers.WillPullAggroAtLocation(unit.Location) && unit.QuestGiverStatus == QuestGiverStatus.TurnIn,
                    ScriptHelpers.CreateTurninQuest(ctx => unit)));
        }

        [ObjectHandler(192826, "Drakkari History Tablet", 50)]
        public async Task<bool> DrakkariHistoryTabletHandler(WoWGameObject tablet)
        {
            const uint forPosterityQuestId = 29844;

            // Ignore if we don't have it or if we completed it already.
            if (ScriptHelpers.IsQuestInLogComplete(forPosterityQuestId) || !Me.QuestLog.ContainsQuest(forPosterityQuestId) || Me.QuestLog.GetCompletedQuests().Contains(forPosterityQuestId))
                return false;

            if (Targeting.Instance.IsEmpty() && BotPoi.Current.Type == PoiType.None && !ScriptHelpers.WillPullAggroAtLocation(tablet.Location))
            {
                if (await ScriptHelpers.InteractWithObject(tablet))
                    return true;
            }

            return false;
        }

        #endregion

        [EncounterHandler(29304, "Slad'ran")]
        public Composite SladranEncounter()
        {
            WoWUnit boss = null;
            AddAvoidObject(() => true, 15, o => o.Entry == SladranId && _frostNovaIds.Contains(o.ToUnit().CastingSpellId));

            return new PrioritySelector(ctx => boss = ctx as WoWUnit);
        }

        [ObjectHandler(192518, "Altar of Slad'ran", ObjectRange = 2000)]
        [ObjectHandler(192520, "Altar of the Drakkari Colossus", ObjectRange = 2000)]
        [ObjectHandler(192519, "Altar of Moorabi", ObjectRange = 2000)]
        public async Task<bool> AltarHandler(WoWGameObject altar)
        {
            if (altar.CanUse() && Me.IsLeader())
                ScriptHelpers.SetInteractPoi(altar);
            return false;
        }

        [EncounterHandler(29307, "Drakkari Colossus")]
        public Composite DrakkariColossusEncounter()
        {
            const uint mojoPuddleId = 55627;
            AddAvoidObject(() => true, 3, mojoPuddleId);

            return new PrioritySelector();
        }

        [EncounterHandler(29306, "Gal'darah")]
        public Composite GaldarahEncounter()
        {
            WoWUnit _galdarah = null;
            AddAvoidObject(() => true, 15, o => o.Entry == GaldarahId && (o.ToUnit().HasAura("Whirling Slash") || Me.IsRange()));
            return new PrioritySelector(ctx => _galdarah = ctx as WoWUnit);
        }
    }

    public class GundrakTimewalking : Gundrak
    {
        public override uint DungeonId => 1017;
        
        private const int MobId_EckTheFerocious = 29932;
        private const int SpellId_EckSpit = 55814;

        [EncounterHandler(MobId_EckTheFerocious, "Eck the Ferocious", Mode = CallBehaviorMode.Proximity, BossRange = 100)]
        public Func<WoWUnit, Task<bool>> EckTheFerociousEncounter()
        {
            // Stay at 15 yards if possible.
            AddAvoidObject<WoWUnit>(() => Me.IsRangeDps(), 15, u => u.Entry == MobId_EckTheFerocious && u.Combat);

            return async boss =>
            {
                // Note that Eck Spit, whilst being a channeled ability, will follow its target if the target moves. 
                // If Eck Spit is being cast on you, stand still so that you do not drag the Spit effect over other players.
                ScriptHelpers.DisableMovement(() => boss.IsTargetingMeOrPet && boss.CastingSpellId == SpellId_EckSpit && Me.IsMoving);
                
                if (await ScriptHelpers.RunToTankIfAttacked())
                    return true;

                return await ScriptHelpers.TankFaceUnitAwayFromGroup(boss, 15);
            };
        }
    }
}