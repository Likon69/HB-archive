using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using Styx;
using Styx.Combat.CombatRoutine;
using Styx.Helpers;
using Styx.Logic;
using Styx.Logic.Combat;
using Styx.Logic.Pathing;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;

#pragma warning disable

namespace Paladin
{
    public class Paladin : CombatRoutine
    {
        private static ulong _lastGuid;

        private readonly Stopwatch _fightTimer = new Stopwatch();
        public static readonly LocalPlayer Me = ObjectManager.Me;
        private readonly TimeSpan _needBuffTimespan = new TimeSpan(0, 3, 0);
        private readonly List<uint> _runnerList = new List<uint>();
        private const double RestHealPercent = 55;
        private const double CombatHealPercent = 65;

        public override string Name
        {
            get { return "Hawker's Paladin 2.3"; }
        }

        public override WoWClass Class
        {
            get { return WoWClass.Paladin; }
        }

        private static WoWUnit MyTarget
        {
            get { return ObjectManager.Me.CurrentTarget; }
        }

        private static bool GotTarget
        {
            get { return ObjectManager.Me.CurrentTarget != null; }
        }

        private bool CombatChecks
        {
            get
            {
                if (!ObjectManager.Me.GotTarget || ObjectManager.Me.Dead || !ObjectManager.Me.Combat)
                {
                    return false;
                }

                if (!ObjectManager.Me.IsAutoAttacking)
                {
                    Lua.DoString("StartAttack()");
                }

                if (ObjectManager.Me.CurrentTarget.Distance > 50)
                {
                    if (ObjectManager.Me.CurrentTarget.IsPlayer)
                    {
                        Logging.Write("Out of range: Level " + ObjectManager.Me.CurrentTarget.Level + " " + ObjectManager.Me.CurrentTarget.Race + " " +
                                      Math.Round(ObjectManager.Me.CurrentTarget.Distance) + " yards away.");
                    }
                    else
                    {
                        Logging.Write("Out of range: Level " + ObjectManager.Me.CurrentTarget.Name + " is " +
                                      Math.Round(ObjectManager.Me.CurrentTarget.Distance) + " yards away.");
                    }


                    if (ObjectManager.Me.Combat)
                    {
                        Blacklist.Add(ObjectManager.Me.CurrentTarget.Guid, TimeSpan.FromSeconds(10));
                        Targeting.Instance.Clear();
                    }
                    ObjectManager.Me.ClearTarget();
                    return false;
                }

                double meleeRange = 5;

                if (Me.Level < 5)
                {
                    meleeRange = 1;
                }

                if (ObjectManager.Me.CurrentTarget.Distance > meleeRange)
                {
                    int a = 0;
                    while (a < 50 && ObjectManager.Me.IsAlive && ObjectManager.Me.GotTarget &&
                           ObjectManager.Me.CurrentTarget.Distance > meleeRange)
                    {
                        WoWMovement.Face();
                        Navigator.MoveTo(WoWMovement.CalculatePointFrom(
                            ObjectManager.Me.CurrentTarget.Location, 2.5f));
                        Thread.Sleep(250);
                        ++a;
                    }
                }

                WoWMovement.MoveStop();
                WoWMovement.Face();

                return true;
            }
        }

        private static void Player_OnMobKilled(BotEvents.Player.MobKilledEventArgs args)
        {
            StyxWoW.Me.ClearTarget();

            if (StyxWoW.Me.IsAutoAttacking)
            {
                StyxWoW.Me.ToggleAttack();
            }
        }

        /// <summary>
        /// Finds a list of all units in vicinity that are targetting you
        /// </summary>
        private static List<WoWUnit> AddsList
        {
            get
            {
                List<WoWUnit> mobList = ObjectManager.GetObjectsOfType<WoWUnit>(false);
                var enemyMobList = new List<WoWUnit>();

                foreach (WoWUnit thing in mobList)
                {
                    try
                    {
                        if ((thing.Guid != Me.Guid) && (thing.IsTargetingMeOrPet || thing.Fleeing))
                        {
                            enemyMobList.Add(thing);
                        }
                    }
                    catch (Exception ex)
                    {
                        Logging.WriteException(ex);
                        Logging.Write("Add error.");
                    }
                }

                if (enemyMobList.Count > 1)
                {
                    Logging.Write("Warning: there are " + enemyMobList.Count + " attackers.");
                }
                return enemyMobList;
            }
        }

        private static bool SafeCast(int spellId)
        {
            if (SpellManagerEx.HasSpell(spellId) && !StyxWoW.Me.IsCasting)
            {
                while (StyxWoW.GlobalCooldown)
                {
                    Thread.Sleep(100);
                }

                SpellManagerEx.Cast(spellId);
                return true;
            }

            return false;
        }

        private bool SafeCast(string spellName)
        {
            if (Me.IsCasting || !SpellManagerEx.HasSpell(spellName))
            {
                return false;
            }

            if (SpellManagerEx.HasSpell(spellName) && !StyxWoW.Me.IsCasting)
            {
                if (SpellManagerEx.Spells[spellName].CastTime > 1)
                {
                    WoWMovement.MoveStop();
                    WoWMovement.Face();
                }

                try
                {
                    if (GotTarget && MyTarget.Attackable)
                    {
                        WoWMovement.Face();
                    }
                }
                catch
                {
                    Logging.WriteDebug("No need to face target.");
                }

                while (StyxWoW.GlobalCooldown)
                {
                    Thread.Sleep(100);
                }

                SpellManagerEx.Cast(spellName);

                return true;
            }


            Logging.WriteDebug("{0} can't cast {1}.", Name, spellName);


            return false;
        }

        private static bool HasBuffProcced(string cSearchBuffName, int minStackCount)
        {
            int stackCount = 0;

            List<string> myBuffs = Lua.LuaGetReturnValue("return UnitBuff(\"player\",\"" + cSearchBuffName + "\")",
                                                         "hawker.lua");

            if (Equals(null, myBuffs))
            {
                return false;
            }

            string buffName = myBuffs[0];

            if (minStackCount > 0)
            {
                stackCount = Convert.ToInt32(myBuffs[3]);
            }

            if (buffName == cSearchBuffName || stackCount >= minStackCount)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        #region Buffs and Heals

        public override bool NeedRest
        {
            get
            {
                if (!Me.Mounted)
                {
                    if (SpellManagerEx.HasSpell("Seal of Command"))
                    {
                        if (!Me.Auras.ContainsKey("Seal of Command"))
                        {
                            return true;
                        }
                    }
                    else if (!Me.Auras.ContainsKey("Seal of Righteousness") &&
                             SpellManagerEx.HasSpell("Seal of Righteousness"))
                    {
                        return true;
                    }

                    if (SpellManagerEx.HasSpell("Blessing of Might") &&
                        !Me.Auras.ContainsKey("Blessing of Might") &&
                        !Me.Auras.ContainsKey("Greater Blessing of Might") &&
                        !Me.Auras.ContainsKey("Battle Shout"))
                    {
                        return true;
                    }

                    if (Battlegrounds.IsInsideBattleground)
                    {
                        return false;
                    }

                    if (SpellManagerEx.HasSpell("Blessing of Kings"))
                    {
                        if (Me.PartyMembers.Where(player => player.IsAlive && player.InLineOfSight &&
                            player.Distance < SpellManager.KnownSpells["Blessing of Kings"].MaxRange - 2 &&
                            (player.Class == WoWClass.Warrior || player.Class == WoWClass.Paladin)).Any(player => !player.Auras.ContainsKey("Blessing of Kings")))
                        {
                            return true;
                        }
                    }
                }

                if (ObjectManager.Me.HealthPercent <= RestHealPercent || ObjectManager.Me.ManaPercent <= 50)
                {
                    return true;
                }

                return false;
            }
        }

        public override bool NeedPreCombatBuffs
        {
            get { return NeedRest; }
        }

        public override bool NeedCombatBuffs
        {
            get { return false; }
        }

        public override bool NeedHeal
        {
            get
            {
                if (HealTarget.Dead)
                {
                    return false;
                }

                if (HealTarget.Combat && HealTarget.HealthPercent < CombatHealPercent)
                {
                    return true;
                }

                if (HealTarget.HealthPercent < RestHealPercent)
                {
                    return true;
                }

                return false;
            }
        }

        public override bool NeedPullBuffs
        {
            get
            {
                if (SpellManagerEx.HasSpell("Avenging Wrath") &&
                    !SpellManager.KnownSpells["Avenging Wrath"].Cooldown)
                {
                    return true;
                }
                return false;
            }
        }

        public override void Rest()
        {
            PaladinBuffs();

            if (Battlegrounds.IsInsideBattleground)
            {
                return;
            }

            if (Me.HealthPercent < RestHealPercent)
            {
                HolyLight();
            }

            if (SpellManagerEx.CanCast("Flash of Light") && Me.HealthPercent < 90)
            {
                FlashOfLight();
            }

            if (Me.ManaPercent < 60)
            {
                Styx.Logic.Common.Rest.Feed();
                if (Me.HealthPercent < RestHealPercent)
                {
                    Styx.Logic.Common.Rest.Feed();
                }
            }
        }

        public override void CombatBuff() { }

        public override void PullBuff()
        {
            AvengingWrath();
        }

        #endregion

        public override void Pull()
        {
            if (SpellManagerEx.HasSpell("Seal of Command"))
            {
                if (!Me.Auras.ContainsKey("Seal of Command"))
                {
                    SealOfCommand("Seal of Command.");
                }
            }
            else if (!Me.Auras.ContainsKey("Seal of Righteousness") &&
                     SpellManagerEx.HasSpell("Seal of Righteousness"))
            {
                SealOfRighteousness("Seal of Righteousness.");
            }

            if (!Me.GotTarget)
            {
                return;
            }

            if (!Battlegrounds.IsInsideBattleground && Me.PartyMembers.Count > 0 &&
                !Equals(null, Me.PartyMember1.CurrentTarget))
            {
                Logging.Write("Will on pull the party leader's target.");
                return;
            }

            if (ObjectManager.Me.GotTarget && !Me.IsAutoAttacking)
            {
                Lua.DoString("StartAttack()");
            }

            Logging.Write("Pull {0} at {1}.", Me.CurrentTarget.Name, Math.Round(Me.CurrentTarget.Distance));

            #region mobs

            if (!Me.CurrentTarget.IsPlayer && SpellManagerEx.HasSpell("Hand of Reckoning"))
            {
                if (ObjectManager.Me.CurrentTarget.Distance >
                    SpellManager.KnownSpells["Hand of Reckoning"].MaxRange - 2)
                {
                    Logging.Write("Get to {0} yards.", SpellManager.KnownSpells["Hand of Reckoning"].MaxRange);
                    int a = 0;
                    while (a < 50 && ObjectManager.Me.IsAlive && ObjectManager.Me.GotTarget &&
                           ObjectManager.Me.CurrentTarget.Distance >
                           SpellManager.KnownSpells["Hand of Reckoning"].MaxRange)
                    {
                        if (ObjectManager.Me.Combat)
                        {
                            Logging.Write("Combat has started.  Abandon pull.");
                            break;
                        }
                        WoWMovement.Face();
                        Navigator.MoveTo(
                            WoWMovement.CalculatePointFrom(ObjectManager.Me.CurrentTarget.Location, 25f));
                        Thread.Sleep(250);
                        ++a;
                    }
                }

                Logging.Write("Within HoR range.");
                WoWMovement.MoveStop();
                WoWMovement.Face();
                HandOfReckoning();
                if (Me.PartyMembers.Count == 0)
                {
                    Exorcism();
                }


                var pTimer = new Stopwatch();
                pTimer.Start();

                while (pTimer.ElapsedMilliseconds < 1500 && Me.GotTarget && Me.CurrentTarget.IsTargetingMeOrPet &&
                       Me.CurrentTarget.Distance > 5)
                {
                    Logging.Write("Waiting for " + Me.CurrentTarget.Name + " come into melee range.");
                    Thread.Sleep(250);
                }
            }
            #endregion

            else
            {
                float attackRange = 5;

                if (SpellManagerEx.HasSpell("Judgement of Light"))
                {
                    attackRange = SpellManager.KnownSpells["Judgement of Light"].MaxRange;
                }

                while (Me.GotTarget && Me.CurrentTarget.Distance > attackRange)
                {
                    Logging.Write("Get closer");
                    if (!Me.CurrentTarget.InLineOfSight)
                    {
                        Navigator.MoveTo(Me.CurrentTarget.Location);
                    }
                    else
                    {
                        WoWMovement.ClickToMove(Me.CurrentTarget.Location);
                    }
                }

                PaladinJudgements();
            }
        }

        public override void PreCombatBuff()
        {
            // check buffs 
            if (NeedCombatBuffs)
            {
                PaladinBuffs();
            }
        }

        public override void Heal()
        {
            if (Me.Combat)
            {
                if (Me.CurrentTarget.CreatureType != WoWCreatureType.Beast &&
                    Me.CurrentTarget.CreatureType != WoWCreatureType.Mechanical &&
                    SpellManagerEx.HasSpell("Repentance") &&
                    !SpellManager.KnownSpells["Repentance"].Cooldown)
                {
                    Repentance();
                }
                else
                {
                    HammerOfJustice();
                }

                if (HealTarget.Guid != Me.Guid)
                {
                    HealTarget.Target();
                }

                if (Equals(HealTarget, Me))
                {
                    DivineShield();
                }
                else if (HealTarget.Class != WoWClass.Warrior)
                {
                    HandOfProtection();
                }

                if (HealTarget.HealthPercent < 25)
                {
                    LayOnHands();
                }

                if (HealTarget.HealthPercent > CombatHealPercent &&
                    SpellManagerEx.HasSpell("Flash of Light"))
                {
                    FlashOfLight();
                }
                else
                {
                    HolyLight();
                }
            }
            else if (HealTarget.HealthPercent < CombatHealPercent)
            {
                HolyLight();
            }
            else if (HealTarget.HealthPercent < 90)
            {
                FlashOfLight();
            }
        }

        public override void Combat()
        {
            try
            {
                // Logging.Write(" Entered Combat() at {0}:{1}:{2}:{3}", DateTime.Now.Hour, DateTime.Now.Minute, DateTime.Now.Second, DateTime.Now.Millisecond);
                if (!Equals(null, Me.PartyMember1) && !Equals(Me.CurrentTarget, Me.PartyMember1.CurrentTarget) &&
                    Me.PartyMember1.Distance < 45)
                {
                    Me.PartyMember1.CurrentTarget.Target();
                    Me.CurrentTarget.Face();
                }

                if (!ObjectManager.Me.GotTarget)
                {
                    return;
                }

                if (ObjectManager.Me.GotTarget && !ObjectManager.Me.CurrentTarget.IsPlayer &&
                    ObjectManager.Me.CurrentTarget.Attackable)
                {
                    if (ObjectManager.Me.CurrentTarget.CurrentTargetGuid == ObjectManager.Me.Guid ||
                        (ObjectManager.Me.GotAlivePet &&
                         ObjectManager.Me.CurrentTarget.CurrentTargetGuid == ObjectManager.Me.Pet.Guid))
                    {
                        WoWMovement.MoveStop();
                        WoWMovement.Face();
                    }
                }

                if (Me.GotTarget && Me.CurrentTarget.Guid != _lastGuid)
                {
                    _fightTimer.Reset();
                    _fightTimer.Start();
                    _lastGuid = Me.CurrentTarget.Guid;
                }

                if (Me.GotTarget && !Me.CurrentTarget.IsPlayer && _fightTimer.ElapsedMilliseconds > 20 * 1000 &&
                    Me.CurrentTarget.HealthPercent > 95)
                {
                    Logging.Write(" This " + Me.CurrentTarget.Name + " is a bugged mob.  blacklisting for 1 hour.");

                    Blacklist.Add(Me.CurrentTarget.Guid, TimeSpan.FromHours(1.00));

                    KeyboardManager.PressKey('S');
                    Thread.Sleep(5 * 1000);
                    KeyboardManager.ReleaseKey('S');
                    Me.ClearTarget();
                    _lastGuid = 0;
                }

                #region buffs

                if (!CombatChecks)
                {
                    return;
                }
                else if (SpellManagerEx.HasSpell("Seal of Command"))
                {
                    if (!Me.Auras.ContainsKey("Seal of Command"))
                    {
                        SealOfCommand("Seal of Command.");
                    }
                }
                else if (!Me.Auras.ContainsKey("Seal of Righteousness") &&
                         SpellManagerEx.HasSpell("Seal of Righteousness"))
                {
                    SealOfRighteousness("Seal of Righteousness.");
                }

                #endregion

                #region heals

                if (CombatChecks)
                {
                    if (Me.HealthPercent < 35)
                    {
                        if (Me.HealthPercent < 25)
                        {
                            LayOnHands();
                        }
                        else
                        {
                            DivineShield();
                        }
                    }
                }
                else
                {
                    return;
                }

                if (CombatChecks)
                {
                    if ((Me.HealthPercent < 30 && Me.CurrentTarget.HealthPercent > Me.HealthPercent))
                    {
                        Healing.UseHealthPotion();
                        GiftOfTheNaaru();
                        DivineShield();
                    }

                    if (Me.ManaPercent < 30 && Me.CurrentTarget.HealthPercent > Me.HealthPercent)
                    {
                        Healing.UseManaPotion();
                    }

                    if (Me.HealthPercent < CombatHealPercent || NeedHeal)
                    {
                        Logging.Write("Heal.");
                        Heal();
                    }
                }
                else
                {
                    return;
                }

                #endregion

                #region open combat

                if (CombatChecks)
                {
                    if (Me.CurrentTarget.IsCasting)
                    {
                        WarStomp();
                        ArcaneTorrent();
                    }

                    Berserking();
                    Bloodrage();

                    PaladinJudgements();
                    if (SpellManagerEx.HasSpell("Divine Plea") && Me.ManaPercent < 50)
                    {
                        Logging.Write("Mana below 50%.");
                        DivinePlea();
                    }
                }
                else
                {
                    return;
                }

                #endregion

                #region handle adds


                if (AddsList.Count > 1)
                {
                    Consecration();
                    if (Me.HealthPercent < 80 && SpellManagerEx.HasSpell("Lifeblood") && SpellManager.KnownSpells["Lifeblood"].Cooldown)
                    {
                        SafeCast("Lifeblood");
                        Logging.Write("Lifeblood.");
                    }

                    Stoneform();
                    GiftOfTheNaaru();
                }

                #endregion

                #region dps

                if (Me.Level > 40 && Me.PartyMembers.Count == 0 && HasBuffProcced("The Art of War", 0) &&
                    CombatChecks)
                {
                    Exorcism();
                }

                if (CombatChecks)
                {
                    PaladinJudgements();
                    CrusaderStrike();
                }
                else
                {
                    return;
                }

                if (CombatChecks)
                {
                    DivineStorm();
                }
                else
                {
                    return;
                }

                if (CombatChecks)
                {
                    HammmerOfWrath();
                }
                else
                {
                    return;
                }

                #endregion
            }
            finally
            {
                if (SpellManagerEx.HasSpell("Judgement of Justice") && Me.CurrentTarget != null
                    && !_runnerList.Contains(Me.CurrentTarget.Entry) && Me.CurrentTarget.Fleeing)
                {
                    Logging.Write("{0}s are runners.  Use Judgement of Justice from now on.");
                    _runnerList.Add(Me.CurrentTarget.Entry);
                }
            }
        }



        #region paladin logic

        private void PaladinJudgements()
        {
            if (CombatChecks)
            {
                // stun before seal of command
                if (SpellManagerEx.HasSpell("Hammer of Justice") &&
                    Me.Auras.ContainsKey("Seal of Command"))
                {
                    if (Me.CurrentTarget.CreatureType != WoWCreatureType.Mechanical &&
                        SpellManagerEx.HasSpell("Repentance") &&
                        !SpellManager.KnownSpells["Repentance"].Cooldown)
                    {
                        Repentance();
                    }
                    else
                    {
                        HammerOfJustice();
                    }
                }

                if (SpellManagerEx.HasSpell("Judgement of Justice") &&
                    (Me.CurrentTarget.IsPlayer || _runnerList.Contains(Me.CurrentTarget.Entry)))
                {
                    JudgementOfJustice();
                    return;
                }

                if (SpellManagerEx.HasSpell("Judgement of Wisdom") && Me.ManaPercent < 75)
                {
                    JudgementOfWisdom();
                    return;
                }

                if (SpellManagerEx.HasSpell("Judgement of Light") &&
                    !SpellManager.KnownSpells["Judgement of Light"].Cooldown)
                {
                    JudgementOfLight();
                }
            }
        }

        /// <summary>
        /// Check buffs every 15 seconds between combat
        /// </summary>
        private void PaladinBuffs()
        {
            {
                if (SpellManagerEx.HasSpell("Seal of Command"))
                {
                    if (!Me.Auras.ContainsKey("Seal of Command"))
                    {
                        SealOfCommand("Seal of Command.");
                    }
                }
                else if (Me.Level == 4 && !Me.Auras.ContainsKey("Seal of Righteousness") &&
                         SpellManagerEx.HasSpell("Seal of Righteousness"))
                {
                    SafeCast(21084);
                }
                else if (!Me.Auras.ContainsKey("Seal of Righteousness") &&
                         SpellManagerEx.HasSpell("Seal of Righteousness"))
                {
                    SealOfRighteousness("Seal of Righteousness.");
                }

                // aura
                if (SpellManagerEx.HasSpell("Retribution Aura"))
                {
                    if (!Me.Auras.ContainsKey("Retribution Aura"))
                    {
                        RetributionAura();
                    }
                }
                else if (!Me.Auras.ContainsKey("Devotion Aura") &&
                         SpellManagerEx.HasSpell("Devotion Aura"))
                {
                    DevotionAura();
                }

                if (Me.Level > 3 &&
                    !Me.Auras.ContainsKey("Blessing of Might") &&
                    !Me.Auras.ContainsKey("Greater Blessing of Might") &&
                    !Me.Auras.ContainsKey("Battle Shout") &&
                    SpellManagerEx.HasSpell("Blessing of Might"))
                {
                    if (Me.GotTarget &&
                        Me.CurrentTarget.Guid == Me.Guid)
                    {
                        Me.ClearTarget();
                    }

                    BlessingOfMight("Blessing of Might.");
                }
            }


            if (SpellManagerEx.HasSpell("Seal of Command") && Me.Auras.ContainsKey("Seal of Command") &&
                Me.Auras["Seal of Command"].TimeLeft < _needBuffTimespan)
            {
                SealOfCommand("Refresh Seal of Command.");
            }
            else if (Me.Auras.ContainsKey("Seal of Righteousness") &&
                     Me.Auras["Seal of Righteousness"].TimeLeft < _needBuffTimespan)
            {
                SealOfRighteousness("Refresh Seal of Righteousness.");
            }

            if (SpellManagerEx.HasSpell("Blessing of Might") && Me.Auras.ContainsKey("Blessing of Might") &&
                Me.Auras["Blessing of Might"].TimeLeft < _needBuffTimespan)
            {
                if (Me.GotTarget &&
                    Me.CurrentTarget.Guid != Me.Guid)
                {
                    Me.ClearTarget();
                }

                BlessingOfMight("Refresh Blessing of Might.");
            }
        }

        #endregion

        #region paladin spells

        /// <summary>
        /// Heals a friendly target.
        /// </summary>
        private static Stopwatch _holyLightTimer;

        /// <summary>
        /// Increases all damage and healing caused by 20% for 20 sec.  Cannot be used within 30 sec 
        /// of being the target of Divine Shield, Divine Protection, or Hand of Protection, or of using Lay on Hands on oneself.
        /// </summary>
        private void AvengingWrath()
        {
            //http://www.wowhead.com/spell=31884
            if (SpellManagerEx.HasSpell("Avenging Wrath") &&
                !SpellManager.KnownSpells["Avenging Wrath"].Cooldown && SafeCast("Avenging Wrath"))
            {
                Logging.Write("Avenging Wrath.");
            }
        }

        /// <summary>
        /// Gives additional armor to party and raid members within 40 yards. 
        /// </summary>
        private void DevotionAura()
        {
            // http://www.wowhead.com/?spell=465
            if (SafeCast("Devotion Aura"))
            {
                Logging.Write("Devotion Aura.");
            }
        }

        private void HolyLight()
        {
            if (_holyLightTimer == null)
            {
                _holyLightTimer = new Stopwatch();
            }

            if (_holyLightTimer.IsRunning && _holyLightTimer.ElapsedMilliseconds < 300)
            {
                return;
            }


            if (!IsPartyMode)
            {
                HealTarget = Me;
            }

            if (HealTarget.HealthPercent > 95)
            {
                return;
            }

            if (HealTarget.HealthPercent < 95 && HealTarget.HealthPercent > 75)
            {
                FlashOfLight();
                return;
            }

            // http://www.wowhead.com/?spell=635
            if (SafeCast("Holy Light"))
            {
                Logging.Write("Holy Light.");

                Thread.Sleep(500);

                while (Me.IsCasting)
                {
                    if (HealTarget.HealthPercent > 85)
                    {
                        KeyboardManager.KeyUpDown(' ');
                        break;
                    }
                    Thread.Sleep(100);
                }

                _holyLightTimer.Reset();
                _holyLightTimer.Start();
            }
        }

        /// <summary>
        /// Fills the Paladin with holy spirit for 30 min, granting each melee attack additional Holy damage. 
        /// Unleashing this Seal's energy will cause extra Holy damage to an enemy.
        /// </summary>
        private void SealOfRighteousness(string msg)
        {
            // http://www.wowhead.com/?spell=21084
            bool castDone = SafeCast("Seal of Righteousness");
            if (castDone)
            {
                Logging.Write(msg);
            }
        }

        /// <summary>
        /// Places a Blessing on the friendly target, increasing attack power for 10 min. 
        /// </summary>
        private void BlessingOfMight(string msg)
        {
            // http://www.wowhead.com/?spell=19740
            if (SafeCast("Blessing of Might"))
            {
                Logging.Write(msg);
            }
        }

        /// <summary>
        /// Unleashes the energy of a Seal spell to judge an enemy for 20 sec, granting attacks made against the judged enemy a chance of healing the attacker for 2% of their maximum health. 
        /// </summary>
        private void JudgementOfLight()
        {
            // http://www.wowhead.com/?spell=20271
            if (Me.GotTarget && Me.CurrentTarget.Distance < SpellManager.KnownSpells["Judgement of Light"].MaxRange &&
                SafeCast("Judgement of Light"))
            {
                Logging.Write("Judgement of Light.");
            }
        }


        /// <summary>
        /// Stuns the target
        /// </summary>
        private void HammerOfJustice()
        {
            if (!SpellManagerEx.HasSpell("Hammer of Justice") ||
                SpellManager.KnownSpells["Hammer of Justice"].Cooldown)
            {
                return;
            }

            // http://www.wowhead.com/?spell=853
            if (Me.GotTarget && Me.CurrentTarget.Distance < SpellManager.KnownSpells["Hammer of Justice"].MaxRange &&
                SafeCast("Hammer of Justice"))
            {
                Logging.Write("Hammer of Justice.");
            }
        }

        /// <summary>
        /// A targeted party or raid member is protected from all physical attacks for 6 sec, but during that time they cannot attack or use physical abilities.
        /// </summary>
        private void HandOfProtection()
        {
            // http://www.wowhead.com/?spell=1022
            if (SafeCast("Hand of Protection"))
            {
                Logging.Write("Hand of Protection.");
            }
        }

        /// <summary>
        /// Protects the paladin from all damage and spells for 12 sec
        /// </summary>
        private void DivineShield()
        {
            if (Me.Auras.ContainsKey("Forbearance"))
            {
                return;
            }

            if (SafeCast("Divine Shield"))
            {
                Logging.Write("Divine Shield.");
            }
            if (SafeCast("Divine Protection"))
            {
                Logging.Write("Divine Protection.");
            }
        }

        /// <summary>
        /// Heals a friendly target for an amount equal to the Paladin's maximum health.
        /// </summary>
        private void LayOnHands()
        {
            // http://www.wowhead.com/?spell=633
            if (SafeCast("Lay on Hands"))
            {
                Logging.Write("Lay on Hands for " + Me.CurrentTarget.Class + ".");
            }
        }

        /// <summary>
        /// Unleashes the energy of a Seal spell to judge an enemy, giving each attack a chance to restore 2% of the attacker's base mana.
        /// </summary>
        private void JudgementOfWisdom()
        {
            // http://www.wowhead.com/?spell=53408
            if (Me.GotTarget && Me.CurrentTarget.Distance < SpellManager.KnownSpells["Judgement of Wisdom"].MaxRange &&
                SafeCast("Judgement of Wisdom"))
            {
                if (Me.ManaPercent < 75)
                {
                    Logging.Write("Mana is " + Math.Floor(Me.ManaPercent) + "% so casting Judgement of Wisdom.");
                }
                else
                {
                    Logging.Write("Judgement of Wisdom.");
                }
            }
        }

        /// <summary>
        /// Places a Blessing on the friendly target, restoring mana every 5 seconds for 10 min.
        /// </summary>
        private void BlessingOfWisdom(string msg)
        {
            // http://www.wowhead.com/?spell=19742
            if (SafeCast("Blessing of Wisdom"))
            {
                Logging.Write(msg);
            }
        }

        /// <summary>
        /// Taunts the target to attack you.  If the target is not currently targeting you, causes Holy damage.
        /// </summary>
        private void HandOfReckoning()
        {
            // http://www.wowhead.com/?spell=62124
            if (!SpellManagerEx.HasSpell("Hand of Reckoning"))
            {
                Logging.Write("Hand of Reckoning not known.");
            }

            if (Me.CurrentTarget.IsPlayer)
            {
                return;
            }

            bool castDone = SafeCast("Hand of Reckoning");

            Logging.Write(castDone ? "Pulling with Hand of Reckoning." : "Hand of Reckoning failed.");
        }

        /// <summary>
        /// All melee attacks deal additional Holy damage.  When used with attacks or abilities that strike a single target, this additional Holy damage will strike up to 2 additional targets.  Lasts 30 min.
        /// Unleashing this Seal's energy will judge an enemy, instantly causing Holy damage.
        /// </summary>
        private void SealOfCommand(string msg)
        {
            // http://www.wowhead.com/?spell=20375
            if (SafeCast("Seal of Command"))
            {
                Logging.Write(msg);
            }
        }

        /// <summary>
        /// Causes Holy damage to any enemy that strikes a party or raid member within 40 yards. 
        /// </summary>
        private void RetributionAura()
        {
            // http://www.wowhead.com/?spell=7294
            if (SafeCast("Retribution Aura"))
            {
                Logging.Write("Retribution Aura.");
            }
        }

        /// <summary>
        /// Consecrates the land beneath the Paladin, doing Holy damage over 8 sec to enemies who enter the area.
        /// </summary>
        private void Consecration()
        {
            // http://www.wowhead.com/?spell=26573
            if (SafeCast("Consecration"))
            {
                Logging.Write("Consecration.");
            }
        }

        /// <summary>
        /// Causes Holy damage to an enemy target.  If the target is Undead or Demon, it will always critically hit.
        /// </summary>
        private void Exorcism()
        {
            // http://www.wowhead.com/?spell=879
            if (Me.GotTarget && Me.CurrentTarget.Distance < SpellManager.KnownSpells["Exorcism"].MaxRange &&
                SafeCast("Exorcism"))
            {
                Logging.Write("Exorcism.");
            }
        }

        /// <summary>
        /// Heals a friendly target.  If the target has the Sacred Shield effect, they heal an additional 100% over 12 sec.
        /// </summary>
        private void FlashOfLight()
        {
            if (_holyLightTimer.IsRunning && _holyLightTimer.ElapsedMilliseconds < 300)
            {
                return;
            }

            if (HealTarget.HealthPercent > 95)
            {
                return;
            }

            // http://www.wowhead.com/?spell=19750
            if (Me.GotTarget && Me.CurrentTarget.Distance < SpellManager.KnownSpells["Flash of Light"].MaxRange &&
                SafeCast("Flash of Light"))
            {
                Logging.Write("Flash of Light.");
            }
        }

        /// <summary>
        /// Unleashes the energy of a Seal spell to judge an enemy for 20 sec, preventing them from fleeing and limiting their movement speed. 
        /// </summary>
        private void JudgementOfJustice()
        {
            // http://www.wowhead.com/?spell=53407
            if (Me.GotTarget && Me.CurrentTarget.Distance < SpellManager.KnownSpells["Judgement of Justice"].MaxRange &&
                SafeCast("Judgement of Justice"))
            {
                Logging.Write("Judgement of Justice.");
            }
        }

        /// <summary>
        /// Puts the enemy target in a state of meditation, incapacitating them for up to 1 min, and removing the effect of Righteous Vengeance.  
        /// Any damage caused will awaken the target.  Usable against Demons, Dragonkin, Giants, Humanoids and Undead.
        /// </summary>
        private void Repentance()
        {
            // http://www.wowhead.com/spell=20066
            if (Me.CurrentTarget.CreatureType == WoWCreatureType.Mechanical ||
                !SpellManagerEx.HasSpell("Repentance") || SpellManager.KnownSpells["Repentance"].Cooldown)
            {
                return;
            }

            // http://www.wowhead.com/?spell=20066
            if (Me.GotTarget && Me.CurrentTarget.Distance < SpellManager.KnownSpells["Repentance"].MaxRange &&
                SafeCast("Repentance"))
            {
                Logging.Write("Repentance.");
            }
        }

        /// <summary>
        /// Cleanses a friendly target, removing 1 poison effect, 1 disease effect, and 1 magic effect.
        /// </summary>
        private void Cleanse()
        {
            // http://www.wowhead.com/?spell=4987
            if (SafeCast("Cleanse"))
            {
                Logging.Write("Cleanse.");
            }
            else if (SafeCast("Purify"))
            {
                Logging.Write("Purify.");
            }
        }

        /// <summary>
        /// Hurls a hammer that strikes an enemy for Holy damage.  Only usable on enemies that have 20% or less health.
        /// </summary>
        private void HammmerOfWrath()
        {
            if (Me.Level < 44)
            {
                return;
            }

            // http://www.wowhead.com/?spell=24275
            if (Me.CurrentTarget.HealthPercent < 21)
            {
                SafeCast("Hammer of Wrath");
                Logging.Write("Hammer of Wrath.");
            }
        }

        /// <summary>
        /// Sends bolts of holy power in all directions, causing AOE Holy damage and stunning all Undead and Demon targets within 10 yds for 3 sec.
        /// </summary>
        private void HolyWrath()
        {
            // http://www.wowhead.com/?spell=2812
        }

        /// <summary>
        /// An instant strike that causes 75% weapon damage. 
        /// </summary>
        private void CrusaderStrike()
        {
            // http://www.wowhead.com/?spell=35395
            if (Me.Level < 50)
            {
                return;
            }

            if (Me.GotTarget && Me.CurrentTarget.Distance < 6 && SafeCast("Crusader Strike"))
            {
                Logging.Write("Crusader Strike.");
            }
        }

        /// <summary>
        /// An instant weapon attack that causes 110% of weapon damage to up to 4 enemies within 8 yards.  The Divine Storm heals up to 3 party or raid members totaling 25% of the damage caused.
        /// </summary>
        private void DivineStorm()
        {
            // http://www.wowhead.com/?spell=53385
            if (Me.Level < 60)
            {
                return;
            }

            if (Me.GotTarget && SafeCast("Divine Storm"))
            {
                Logging.Write("Divine Storm.");
            }
        }

        /// <summary>
        /// Increases the mounted speed by 20% for all party and raid members within 40 yards. 
        /// </summary>
        private void CrusaderAura()
        {
            // http://www.wowhead.com/?spell=32223
        }

        /// <summary>
        /// Fills the Paladin with holy power, causing attacks to apply Holy Vengeance, which deals additional Holy damage over 15 sec.  Holy Vengeance can stack up to 5 times.  Once stacked to 5 times, each of the Paladin's attacks also deals 33% weapon damage as additional Holy damage. 
        /// </summary>
        private void SealOfVengeance()
        {
            // http://www.wowhead.com/?spell=31801
        }

        /// <summary>
        /// Fills the Paladin with holy power, causing attacks to apply Holy Vengeance, which deals additional Holy damage over 15 sec.  Holy Vengeance can stack up to 5 times.  Once stacked to 5 times, each of the Paladin's attacks also deals 33% weapon damage as additional Holy damage. 
        /// </summary>
        private void SealOfCorruption()
        {
            // http://www.wowhead.com/?spell=53736
        }

        /// <summary>
        /// Each time the target takes damage they gain a Sacred Shield, 
        /// absorbing 500 damage and increasing the paladin's chance to 
        /// critically hit with Flash of Light by 50% for up to 6 sec.  
        /// They cannot gain this effect more than once every 6 sec.  Lasts 30 sec.
        /// </summary>
        private void SacredShield()
        {
            // http://www.wowhead.com/?spell=53601
        }

        /// <summary>
        /// You gain 25% of your total mana over 15 sec, but the amount healed by your Flash of Light, Holy Light, and Holy Shock spells is reduced by 50%.
        /// </summary>
        private void DivinePlea()
        {
            // http://www.wowhead.com/?spell=54428
            if (SafeCast("Divine Plea"))
            {
                Logging.Write("Divine Plea.");
            }
        }

        #endregion

        #region movement logic

        private static readonly Stopwatch MovementTimer = new Stopwatch();
        private static int _movementDuration;

        #endregion

        #region party logic

        private static bool IsPartyMode
        {
            get
            {
                if (Me.PartyMembers.Count > 0 || Me.RaidMembers.Count > 0)
                {
                    return true;
                }
                return false;
            }
        }

        private static WoWPlayer HealTarget
        {
            get
            {
                if (Battlegrounds.IsInsideBattleground && Me.HealthPercent < 90)
                {
                    return Me;
                }

                if (IsPartyMode)
                {
                    WoWPlayer healTarget = Me;

                    foreach (WoWPlayer pal in Me.PartyMembers)
                    {
                        if (pal.HealthPercent < CombatHealPercent && pal.InLineOfSight && pal.Distance <= 35)
                        {
                            if (healTarget == null || pal.HealthPercent < healTarget.HealthPercent)
                            {
                                healTarget = pal;
                            }
                        }
                    }

                    return healTarget;
                }

                return Me;
            }

            set { }
        }

        #endregion

        #region Horde racials

        private void Berserking()
        {
            if (ObjectManager.Me.Race == WoWRace.Troll && SafeCast("Berserking"))
            {
                Logging.Write("Berserking.");
            }
        }

        // Bloodrage
        private void Bloodrage()
        {
            if (ObjectManager.Me.Race == WoWRace.Orc &&
                SafeCast("Bloodrage"))
            {
                Logging.Write("Bloodrage.");
            }
        }

        // War Stomp
        private void WarStomp()
        {
            if (ObjectManager.Me.Race == WoWRace.Tauren &&
                SafeCast("War Stomp"))
            {
                Logging.Write("War Stomp.");
            }
        }

        // Arcane Torrent
        private void ArcaneTorrent()
        {
            if (ObjectManager.Me.Race == WoWRace.BloodElf &&
                SafeCast("Arcane Torrent"))
            {
                Logging.Write("Arcane Torrent.");
            }
        }

        // Will of the Forsaken 
        private void WillOfTheForsaken()
        {
            if (ObjectManager.Me.Race == WoWRace.Undead &&
                SafeCast("Will of the Forsaken"))
            {
                Logging.Write("Will of the Forsaken.");
            }
        }

        #endregion

        #region Alliance racials

        // Stoneform
        private void Stoneform()
        {
            if (ObjectManager.Me.Race == WoWRace.Dwarf &&
                SafeCast("Stoneform"))
            {
                Logging.Write("Stoneform.");
            }
        }

        // Gift of the Naaru
        private void GiftOfTheNaaru()
        {
            if (ObjectManager.Me.Race == WoWRace.Draenei && SafeCast("Gift of the Naaru"))
            {
                Logging.Write("Gift of the Naaru.");
            }
        }

        // Every Man for Himself
        private void EveryManForHimself()
        {
            if (ObjectManager.Me.Race == WoWRace.Human &&
                SafeCast("Every Man for Himself"))
            {
                Logging.Write("Every Man for Himself.");
            }
        }

        // Shadowmeld
        private void Shadowmeld()
        {
            if (ObjectManager.Me.Race == WoWRace.NightElf &&
                SafeCast("Shadowmeld"))
            {
                Logging.Write("Shadowmeld.");
            }
        }

        // Escape Artist
        private void EscapeArtist()
        {
            if (ObjectManager.Me.Race == WoWRace.Gnome &&
                SafeCast("Escape Artist"))
            {
                Logging.Write("Escape Artist.");
            }
        }

        #endregion
    }
}

#pragma warning restore