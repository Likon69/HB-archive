﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CommonBehaviors.Actions;
using Styx;
using Styx.Logic.Pathing;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using TreeSharp;
using Action = TreeSharp.Action;

#if USE_DUNGEONBUDDY_DLL
using Bots.DungeonBuddyDll;
using Bots.DungeonBuddyDll.Profiles;
using Bots.DungeonBuddyDll.Attributes;
using Bots.DungeonBuddyDll.Helpers;
namespace Bots.DungeonBuddyDll.Dungeon_Scripts.Classic
#else
    using Bots.DungeonBuddy.Profiles;
    using Bots.DungeonBuddy.Attributes;
    using Bots.DungeonBuddy.Helpers;
    namespace Bots.DungeonBuddy.Dungeon_Scripts.Classic
#endif
{
    class BlackfathomDeeps : Dungeon
    {
        #region Overrides of Dungeon
        public override uint DungeonId { get { return 10; } }

        public override WoWPoint Entrance { get { return new WoWPoint(4247.842, 750.5999, -22.39564); } }

        #endregion

        #region Encounter Handlers


        public WoWGameObject WoWGameObject
        {
            get 
            { 
                return (ObjectManager.GetObjectsOfType<WoWGameObject>().Where(u => (u.Entry == 21118 || u.Entry == 21121 || u.Entry == 21120 || u.Entry == 21119) && !u.Locked)).FirstOrDefault();
            }
        }


        public WoWUnit DetectedMobs
        {
            get
            {
                return (ObjectManager.GetObjectsOfType<WoWUnit>().Where(u => (u.Z >= WoWGameObject.Z - 5) && u.IsAlive  && u.IsHostile && u.Location.Distance(WoWGameObject.Location) < 50).OrderByDescending(u => u.DistanceSqr)).FirstOrDefault();

            }
        }
    

        [EncounterHandler(0)]
        public Composite RootLogic()
        {
            #region Torch event before final boss
            //Torch event, should light torch one at a time until completed
            if (ScriptHelpers.Tank != StyxWoW.Me)
            {
                return
                    new PrioritySelector();
            }

              /*if (woWGameObject == null)
            {
                return
                    new PrioritySelector();
            }*/

            
            

            return
                    new Decorator(ctx => ProfileManager.CurrentProfile.BossEncounters.Any(b => !b.IsAlive && b.Entry == 4832) && WoWGameObject != null && DetectedMobs == null, // Check if boss is dead
                        new PrioritySelector(
                            new Decorator(ctx => !WoWGameObject.WithinInteractRange, // If no mobs are detected that are hostile and there are still torches
                                       new Action(ctx => Navigator.MoveTo(WoWGameObject.Location))),
                            new Decorator(ctx => WoWGameObject.WithinInteractRange, // Activates the torches
                                       new Sequence(new Action(ctx => WoWGameObject.Interact()), new Wait(10, r=> DetectedMobs != null,new ActionAlwaysSucceed()))))
                                       );

            #endregion
        }

        #endregion
    }
}
