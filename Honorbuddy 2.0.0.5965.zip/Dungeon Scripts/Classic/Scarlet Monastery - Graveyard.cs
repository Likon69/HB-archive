﻿using System;
using System.Linq;
using CommonBehaviors.Actions;
using Styx.Helpers;
using Styx.Logic;
using Styx.Logic.Pathing;
using Styx.WoWInternals;
using TreeSharp;
using Styx;
using Styx.WoWInternals.WoWObjects;
using System.Collections.Generic;
using Action = TreeSharp.Action;

#if USE_DUNGEONBUDDY_DLL
using Bots.DungeonBuddyDll;
using Bots.DungeonBuddyDll.Profiles;
using Bots.DungeonBuddyDll.Attributes;
using Bots.DungeonBuddyDll.Helpers;
namespace Bots.DungeonBuddyDll.Dungeon_Scripts.Classic
#else
    using Bots.DungeonBuddy.Profiles;
    using Bots.DungeonBuddy.Attributes;
    using Bots.DungeonBuddy.Helpers;
namespace Bots.DungeonBuddy.Dungeon_Scripts.Classic
#endif
{
    public class ScarletMonestary : Dungeon
    {
        #region Overrides of Dungeon

        /// <summary> The mapid of this dungeon. </summary>
        /// <value>The map identifier.</value>
        public override uint DungeonId
        {
            get { return 18; }
        }

        public override WoWPoint Entrance { get { return new WoWPoint(2913.591, -802.4, 160.3327); } }

        public override void WeighTargetsFilter(List<Targeting.TargetPriority> units)
        {
            foreach (var t in units)
            {
                var prioObject = t.Object;

                //Target good ones first
                if (prioObject.Entry == 4306 || prioObject.Entry == 4293)
                {
                    t.Score += 400;
                }
            }
        }

        #endregion

        [EncounterHandler(0, "Root")]
        public Composite Root()
        {
            return
                new PrioritySelector();
        }

        [EncounterHandler(3983, "Interrogator Vishas")]
        public Composite InterrogatorVishasFight()
        {
            return
                new PrioritySelector();
        }

        [EncounterHandler(4543, "Bloodmage Thalnos")]
        public Composite BloodmageThalnosFight()
        {
            return
                new PrioritySelector();
        }
    }
}
