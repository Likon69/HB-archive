﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Threading.Tasks;
using Bots.DungeonBuddy.Enums;
using Buddy.Coroutines;
using Styx;
using Styx.Common.Helpers;
using Styx.CommonBot;
using Styx.CommonBot.Coroutines;
using Styx.CommonBot.POI;
using Styx.Helpers;
using Styx.Pathing;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using Bots.DungeonBuddy.Attributes;
using Bots.DungeonBuddy.Helpers;
using Styx.Common;
using Styx.Pathing.Avoidance;
using Styx.WoWInternals.World;

// ReSharper disable CheckNamespace

namespace Bots.DungeonBuddy.DungeonScripts.WarlordsOfDraenor
// ReSharper restore CheckNamespace
{
    public class UpperBlackrockSpire : WoDDungeon
    {
        #region Overrides of Dungeon

        public override uint DungeonId { get { return 330; } }

        public override Vector3 Entrance { get { return new Vector3(-7481.414f, -1323.271f, 301.3931f); } }

        public override Vector3 ExitLocation { get { return new Vector3(106.1491f, -318.6653f, 65.47925f); } }

        public override void IncludeTargetsFilter(List<WoWObject> incomingObjects, HashSet<WoWObject> outgoingObjects)
        {
            var isleader = Me.IsLeader();
            var isDps = Me.IsDps;
            foreach (var unit in incomingObjects.OfType<WoWUnit>())
            {
                if (unit.Entry == MobId_RallyingBanner && isDps)
                {
                    outgoingObjects.Add(unit);
                }
                else if (unit.Entry == MobId_SentryCannon && unit.IsHostile)
                {
                    outgoingObjects.Add(unit);
                }
                else if (unit.Entry == MobId_WindfuryTotem)
                {
                    outgoingObjects.Add(unit);
                }
            }
        }

        public override void WeighTargetsFilter(List<Targeting.TargetPriority> units)
        {
            var isDps = Me.IsDps;
            var isRangeDps = isDps && Me.IsRange();

            foreach (var p in units)
            {
                WoWUnit unit = p.Object.ToUnit();
                switch (unit.Entry)
                {
                    case MobId_DrakonidMonstrosity:
                    case MobId_DrakonidMonstrosityTrash:
                    case MobId_IronbarbSkyreaver:
                    case MobId_RagewingWhelp:
                        if (isDps)
                            p.Score += 3500;
                        break;

                    case MobId_VilemawHatchling:
                        p.Score += 3500;
                        break;
                    case MobId_RallyingBanner:
                    case MobId_WindfuryTotem:
                        if (isDps)
                            p.Score += 4500;
                        break;
                }
            }
        }

        public override void RemoveTargetsFilter(List<WoWObject> units)
        {
            var isMelee = Me.IsMelee();

            units.RemoveAll(
                o =>
                {
                    var unit = o as WoWUnit;
                    if (unit == null) return false;

                    // Melee should not try attack this boss she's while doing the cyclone ability 
                    if (unit.Entry == MobId_WarlordZaela && isMelee && IsCastingBlackIronCylone(unit))
                        return true;

                    if (unit.Entry == MobId_RagewingtheUntamed && isMelee && unit.Z > 119)
                        return true;

                    if (unit.Entry == MobId_SentryCannon && !unit.IsHostile)
                        return true;

                    if (unit.Entry == MobId_VilemawHatchling && Me.IsMelee() && unit.ZDiff > 8)
                        return true;

                    return false;
                });
        }

        public override void OnEnter()
        {
            Lua.Events.AttachEvent("RAID_BOSS_EMOTE", OnRaidBossEmote);
            GameWorld.UnitSpellLineOfSightTest += GameWorld_UnitSpellLineOfSightTest;
        }

        public override void OnExit()
        {
            Lua.Events.DetachEvent("RAID_BOSS_EMOTE", OnRaidBossEmote);
            GameWorld.UnitSpellLineOfSightTest -= GameWorld_UnitSpellLineOfSightTest;
        }

        public override async Task<bool> HandleMovement(MoveToParameters moveToParameters)
        {
            var location = moveToParameters.Location;
            if (location.DistanceSquared(_ragewingPhaseOneLoc) < 3 * 3 || location.DistanceSquared(_rageWingOOCLoc) <= 3 * 3)
                return (await CommonCoroutines.MoveTo(_ragewingBridgeCenter)).IsSuccessful();
            return false;
        }

        #endregion

        #region Root

        private const uint MobId_RuneGlow = 76396;
        private const uint MobId_SentryCannon = 76314;
        private const uint GameObjectId_RuneConduit = 226704;
        private const uint MobId_RallyingBanner = 76222;
        private const uint MobId_DrakonidMonstrosityTrash = 76018;
        private const uint MobId_BlackIronAlchemist = 76100;
        private const uint MobId_BlackIronVeteran = 77034;
        private const uint MobId_BlackIronEngineer = 76101;
        private const uint GameObjectId_TharbeksDoor = 164726;

        private readonly Vector3 _tharbeksDoorLoc = new Vector3(106.7544f, -421.1986f, 110.9228f);
        private readonly WaitTimer _tharbeksDoorTimer = new WaitTimer(TimeSpan.FromSeconds(2));

        private bool _shouldAvoidTharbeksDoor;

        private LocalPlayer Me { get { return StyxWoW.Me; } }

        [EncounterHandler(0, "Root")]
        public Func<WoWUnit, Task<bool>> RootHandler()
        {
            return async npc => { return false; };
        }


        private bool ShouldAvoidTharbeksDoor()
        {
            if (_tharbeksDoorTimer.IsFinished)
            {
                var tharbeksDoor =
                    ObjectManager.GetObjectsOfType<WoWGameObject>().FirstOrDefault(g => g.Entry == GameObjectId_TharbeksDoor);

                _shouldAvoidTharbeksDoor = tharbeksDoor != null && !((WoWDoor)tharbeksDoor.SubObj).IsOpen;
                _tharbeksDoorTimer.Reset();
            }

            return _shouldAvoidTharbeksDoor;
        }

        #endregion


        #region Garrison Inn Quests

        // Family Traditions
        [ObjectHandler(237468, "Finkle's Improved Skinner", ObjectRange = 35)]
        public async Task<bool> FinklesImprovedSkinnerHandler(WoWGameObject gObj)
        {
            return await SafeInteractWithGameObject(gObj, 45);
        }

        // Damsels and Dragons
        [ObjectHandler(237469, "Shed Proto-Dragon Claw", ObjectRange = 35)]
        public async Task<bool> ShedProtoDragonClawHandler(WoWGameObject gObj)
        {
            return await SafeInteractWithGameObject(gObj, 45);
        }

        // For the Children
        [ObjectHandler(237476, "Miniature Iron Star", ObjectRange = 35)]
        public async Task<bool> MiniatureIronStarHandler(WoWGameObject gObj)
        {
            return await SafeInteractWithGameObject(gObj, 45);
        }

        // Oralius' Adventure
        [ObjectHandler(237481, "Bottled Flamefly", ObjectRange = 25)]
        public async Task<bool> BottledFlameflyHandler(WoWGameObject gObj)
        {
            return await SafeInteractWithGameObject(gObj, 35);
        }

        #endregion

        [ScenarioStage(1, "Extinguish Runes")]
        public async Task<bool> StageOne(ScenarioStage stage)
        {
            if (BotPoi.Current.Type != PoiType.None || !Targeting.Instance.IsEmpty())
                return false;

            TreeRoot.StatusText = "Extinguishing Runes";
            if (BotPoi.Current.Type == PoiType.None && Me.IsLeader())
            {
                var rune =
                    ObjectManager.GetObjectsOfType<WoWUnit>()
                        .Where(u => u.Entry == MobId_RuneGlow && u.HasAura("Rune Glow"))
                        .OrderBy(u => u.DistanceSqr)
                        .FirstOrDefault();

                // should always be not null.
                if (rune != null)
                {
                    ScriptHelpers.SetLeaderMoveToPoi(rune.Location);
                }
            }

            // Idle if there is nothing to do as a tank.. (highly unlikely case)
            return Me.IsLeader();
        }

        #region Gor'ashan

        private static readonly Vector3[] s_lightningFieldPath =
        {
            new Vector3(126.2f, -240.748f, 91.83518f),
            new Vector3(162.3623f, -240.7054f, 91.83518f),
            new Vector3(162.6004f, -276.9333f, 91.83518f),
            new Vector3(126.2f, -276.9395f, 91.83518f),
        };

        private readonly Vector3 _conduitInteractRunbackWaypoint1 = new Vector3(138.1485f, -250.9003f, 92.09177f);
        private readonly Vector3 _conduitInteractRunbackWaypoint2 = new Vector3(151.1691f, -251.5334f, 92.09177f);

        private const float MinSafeLightningFieldToConduitDistance = 67; // the corners are 36 yds apart.
        private const float MaxSafeLightningFieldToConduitDistance = 72; // the corners are 36 yds apart.
        private const float LightningFieldPathSegDist = 36;
        private const float LightningFieldPathTotalDist = LightningFieldPathSegDist * 4;

        private const uint MobId_LightningField = 76464;
        private const int AuraTriggerId_LodestoneSpike = 6164;


        [EncounterHandler(76413, "Gor'ashan", Mode = CallBehaviorMode.Proximity)]
        public Func<WoWUnit, Task<bool>> GorashanEncounter()
        {
            var bottomOfRamp = new Vector3(144.004f, -274.0825f, 91.54816f);

            WoWGameObject conduit = null;
            // avoid these spikes
            AddAvoidObject(5, o => o.Entry == AuraTriggerId_LodestoneSpike, ignoreIfBlocking: true);

            // Avoid the lightning fields only of on the same level as them and they're not behind player. 
            AddAvoidObject(
                () => Math.Abs(Me.Z - 91.55) < 1.5,
                17,
                o => o.Entry == MobId_LightningField && o.ToUnit().HasAura("Electric Pulse")
                    && GetLightningFieldPathDistToLocation(o.Location, Me.Location) > 30);

            var bossLoc = new Vector3(144.5426f, -258.0315f, 96.32333f);
            var rightDoorEdge = new Vector3(174.7191f, -258.7988f, 91.54621f);
            var leftDoorEdge = new Vector3(174.8173f, -259.9115f, 91.54621f);

            var pointInsideRoom = new Vector3(164.4416f, -262.2839f, 91.54202f);
            var randomPointInsideRoom = WoWMathHelper.GetRandomPointInCircle(pointInsideRoom, 3);
            var randomPointAtBoss = WoWMathHelper.GetRandomPointInCircle(bossLoc, 4);

            return async boss =>
            {
                if (ScenarioInfo.Current.CurrentStageNumber != 2)
                    return false;

                var isHighestHpDps = ScriptHelpers.GroupMembers
                    .Where(g => g.IsAlive && g.IsDps)
                    .OrderByDescending(g => g.MaxHealth)
                    .Select(g => g.Player)
                    .FirstOrDefault() == Me;

                if ((Me.IsLeader() || isHighestHpDps) && (!ScriptHelpers.IsViable(conduit) || !conduit.CanUse()))
                {
                    var conduits = ObjectManager.GetObjectsOfType<WoWGameObject>()
                        .Where(u => u.Entry == GameObjectId_RuneConduit && u.CanUse() && !AvoidanceManager.Avoids.Any(a => a.IsPointInAvoid(u.Location)))
                        .OrderBy(u => GetLightningFieldPathDistToLocation(u.Location, bottomOfRamp))
                        .ToList();

                    if (isHighestHpDps)
                        conduit = conduits.Count > 1 ? conduits.FirstOrDefault() : null;
                    else
                        conduit = conduits.LastOrDefault();
                }

                if (!boss.Combat && boss.HasAura("Power Conduit"))
                {
                    if (ScriptHelpers.IsViable(conduit))
                        ScriptHelpers.SetInteractPoi(conduit);

                    return false;
                }

                if (await ScriptHelpers.MoveInsideBossRoom(
                    boss,
                    leftDoorEdge,
                    rightDoorEdge,
                    randomPointInsideRoom,
                    player => player.Z < 110 && player.Z > 85))
                {
                    return true;
                }

                if (!boss.Combat)
                    return false;

                if (boss.HealthPercent <= 97 && boss.HealthPercent > 25 && await ScriptHelpers.CastHeroism())
                    return true;

                TreeRoot.StatusText = "Doing Gor'ashan boss encounter";
                // having tank click the conduits seems to work best since they have larger hp pools thus can survive better
                // and dps can still continue dpsing.
                if (ScriptHelpers.IsViable(conduit) && IsSafeToInteractWithConduit(conduit.Location) && Me.HealthPercent > 50)
                {
                    // move to conduit..
                    bool ctmFailed = false;
                    Navigator.NavigationProvider.ClearStuckInfo();
                    while (true)
                    {
#warning FIXME IsStuck
                        // TODO: IsStuck
                        //						if (Navigator.NavigationProvider.StuckHandler.IsStuck())
                        //						{
                        //							ctmFailed = true;
                        //							break;
                        //						}

                        if (!ScriptHelpers.IsViable(conduit) || conduit.DistanceSqr <= 4 * 4)
                            break;

                        Navigator.PlayerMover.MoveTowards(WoWMathHelper.CalculatePointFrom(Me.Location, conduit.Location, 3));
                        await Coroutine.Yield();
                    }

                    if (ctmFailed)
                    {
                        await ScriptHelpers.MoveToContinue(() => WoWMathHelper.CalculatePointFrom(Me.Location, conduit.Location, 3),
                            () => ScriptHelpers.IsViable(conduit) && conduit.DistanceSqr > 4 * 4, true);
                    }

                    if (!ScriptHelpers.IsViable(conduit))
                        return false;

                    await CommonCoroutines.StopMoving();
                    conduit.Interact();
                    await Coroutine.Wait(1000, () => Me.IsCasting);
                    await Coroutine.Wait(3000, () => !Me.IsCasting);

                    conduit = null;

                    // move back to the platform taking the clockwise path.
                    // ToDO: check if a dynamic blackspot can be used to make the navigator to always take a clockwise path 
                    if (Me.X < _conduitInteractRunbackWaypoint1.X)
                        await ScriptHelpers.MoveToContinue(() => _conduitInteractRunbackWaypoint1, ignoreCombat: true);

                    if (Me.X < _conduitInteractRunbackWaypoint2.X)
                        await ScriptHelpers.MoveToContinue(() => _conduitInteractRunbackWaypoint2, ignoreCombat: true);

                    await ScriptHelpers.MoveToContinue(() => bossLoc, ignoreCombat: true);
                    return true;
                }

                if (Me.IsRange())
                {
                    return await ScriptHelpers.StayAtLocationWhile(
                        () => ScriptHelpers.IsViable(boss) && boss.Combat,
                        randomPointAtBoss,
                        "location near Gor'ashan", 2);
                }

                if (await ScriptHelpers.TankUnitAtLocation(bossLoc, 4))
                    return true;

                return false;
            };
        }

        private static bool IsSafeToInteractWithConduit(Vector3 conduitLoc)
        {
            var lighningFieldLocs = ObjectManager.GetObjectsOfType<WoWUnit>().Where(u => u.Entry == MobId_LightningField)
                .Select(u => u.Location).ToList();

            if (!lighningFieldLocs.Any())
                return true;

            int conduitIndex = GetSegmentStartIndexInLightningFieldPath(conduitLoc);

            var nearestLightningFieldDist = lighningFieldLocs
                .Select(l => GetLightningFieldPathDistToLocation(l, conduitLoc, conduitIndex))
                .OrderBy(l => l)
                .First();

            return nearestLightningFieldDist >= MinSafeLightningFieldToConduitDistance
                && nearestLightningFieldDist < MaxSafeLightningFieldToConduitDistance;
        }

        private static float GetLightningFieldPathDistToLocation(Vector3 start, Vector3 end)
        {
            var endIndex = GetSegmentStartIndexInLightningFieldPath(end);
            return GetLightningFieldPathDistToLocation(start, end, endIndex);
        }

        // Calculates how far behind a lightning field is to a conduit.
        // Lightning fields will travel clockwise around the platform that boss is on
        private static float GetLightningFieldPathDistToLocation(Vector3 lightningFieldLoc, Vector3 conduitLoc, int conduitPathSegIndex)
        {
            int lightningFieldIndex = GetSegmentStartIndexInLightningFieldPath(lightningFieldLoc);
            int index = conduitPathSegIndex;
            float dist;

            // if both lighting field and conduit are in same path segment then
            // return LightningFieldPathTotalDist - [Distance From lightningFieldLoc to conduitLoc]
            // if lighting field is further away from waypoint then conduit; otherwise just return  [Distance From lightningFieldLoc to conduitLoc]
            if (lightningFieldIndex == conduitPathSegIndex)
            {
                var wayPoint = s_lightningFieldPath[lightningFieldIndex];
                dist = lightningFieldLoc.Distance2D(conduitLoc);
                if (wayPoint.Distance2DSquared(lightningFieldLoc) > wayPoint.Distance2DSquared(conduitLoc))
                    dist = LightningFieldPathTotalDist - dist;

                return dist;
            }

            dist = s_lightningFieldPath[conduitPathSegIndex].Distance2D(conduitLoc);

            while (true)
            {
                index = index == 0 ? s_lightningFieldPath.Length - 1 : index - 1;
                if (index == lightningFieldIndex)
                    break;
                dist += LightningFieldPathSegDist;
            }

            dist += s_lightningFieldPath[(lightningFieldIndex + 1) % s_lightningFieldPath.Length].Distance2D(lightningFieldLoc);
            return dist;
        }


        private static int GetSegmentStartIndexInLightningFieldPath(Vector3 point)
        {
            int pathIndex = 0;
            var minDist = float.MaxValue;
            for (int i = 0, j = s_lightningFieldPath.Length - 1; i < s_lightningFieldPath.Length; j = i++)
            {
                var start = s_lightningFieldPath[j];
                var end = s_lightningFieldPath[i];
                if (start == point)
                {
                    minDist = 0;
                    pathIndex = j;
                    continue;
                }
                var distToLineSeg = WoWMathHelper.GetNearestPointOnLineSegment(point, start, end).Distance2D(point);
                if (distToLineSeg < minDist)
                {
                    minDist = distToLineSeg;
                    pathIndex = j;
                }
            }
            return pathIndex;
        }

        #endregion

        #region Kyrak

        private const uint MobId_DrakonidMonstrosity = 82556;
        private const uint AreaTriggerId_VilebloodSerum = 6823;
        private const int SpellId_Eruption = 155037;
        private const int SpellId_DebilitatingFixation = 161199;

        [EncounterHandler(82556, "Drakonid Monstrosity")]
        [EncounterHandler(76018, "Drakonid Monstrosity")]
        public Func<WoWUnit, Task<bool>> DrakonidMonstrosityEncounter()
        {
            // These NPCs casts a spell that does damage to enemies in a line in front of it.
            const float eruptionLineWidth = 2;
            AddAvoidLocation(() => true,
                eruptionLineWidth * 1.33f,
                o => (Vector3)o,
                () => ObjectManager.GetObjectsOfType<WoWUnit>()
                        .Where(u =>
                               (u.Entry == MobId_DrakonidMonstrosity || u.Entry == MobId_DrakonidMonstrosityTrash) &&
                               u.CastingSpellId == SpellId_Eruption)
                        .SelectMany(u =>
                                ScriptHelpers.GetPointsAlongLineSegment(
                                    u.Location,
                                    u.Location.RayCast(u.Rotation, 30),
                                    eruptionLineWidth / 2).OfType<object>()));

            // non-tanks should stay away from the front of these NPCs since they have a cleave.
            AddAvoidObject(
                () => !Me.IsLeader(),
                5,
                o =>
                    (o.Entry == MobId_DrakonidMonstrosity || o.Entry == MobId_DrakonidMonstrosityTrash),
                o => o.Location.RayCast(o.Rotation, 4));

            return async npc => await ScriptHelpers.DispelEnemy("Rejuvenating Serum", ScriptHelpers.EnemyDispelType.Magic, npc);
        }

        [EncounterHandler(76021, "Kyrak")]
        public Func<WoWUnit, Task<bool>> KyrakEncounter()
        {
            AddAvoidObject(() => true, 2.5f, AreaTriggerId_VilebloodSerum);

            var meIsPoisoned = new PerFrameCachedValue<bool>(() => Me.HasAura("Salve of Toxic Fumes"));

            AddAvoidObject(5f, o => o is WoWPlayer && !o.IsMe && (o.ToPlayer().HasAura("Salve of Toxic Fumes") || meIsPoisoned));

            return async boss =>
                        {
                            TreeRoot.StatusText = "Doing Kyrak boss encounter";

                            if (boss.HealthPercent > 25 && await ScriptHelpers.CastHeroism())
                                return true;
                            if (await ScriptHelpers.DispelEnemy("Rejuvenating Serum", ScriptHelpers.EnemyDispelType.Magic, boss))
                                return true;

                            if (await ScriptHelpers.InterruptCast(boss, SpellId_DebilitatingFixation))
                                return true;

                            if (await ScriptHelpers.DispelGroup("Salve of Toxic Fumes", ScriptHelpers.PartyDispelType.Poison))
                                return true;

                            return false;
                        };
        }

        #endregion

        #region Commander Tharbek

        private const int SpellId_Smash = 155572;

        private const int MissileSpellId_NoxiousSpit = 161824;
        private const int MissileSpellId_ImbuedIronAxe = 162090;

        private const uint AreaTriggerId_NoxiousSpit = 6880;
        private const uint MobId_BlackIronSiegebreaker = 77033;
        private const uint MobId_IronbarbSkyreaver = 80098;
        private const uint MobId_CommanderTharbek = 79912;
        private const uint MobId_VilemawHatchling = 77096;
        private const uint MobId_ImbuedIronAxe = 80307;

        // handles challenging trash pulls

        private PerFrameCachedValue<WoWUnit> _tharbek;

        private WoWUnit Tharbek
        {
            get
            {
                return _tharbek ??
                        (_tharbek = new PerFrameCachedValue<WoWUnit>(
                            () => ObjectManager.GetObjectsOfType<WoWUnit>().FirstOrDefault(u => u.Entry == MobId_CommanderTharbek)));
            }
        }

        [EncounterHandler((int)MobId_BlackIronSiegebreaker, "BlackIron Siegebreaker")]
        public Func<WoWUnit, Task<bool>> BlackIronSiegebreakerEncounter()
        {
            AddAvoidObject(
                8,
                o => o.Entry == MobId_BlackIronSiegebreaker && o.ToUnit().CastingSpellId == SpellId_Smash,
                o => o.Location.RayCast(o.Rotation, 7));

            return async npc => false;
        }

        [LocationHandler(112.2449, -312.1981, 106.4356, radius: 40)]
        public Func<Vector3, Task<bool>> TrashToTharbek()
        {
            var siegeBreakerWestPathEnd = new Vector3(151.4737f, -270.8368f, 110.9437f);
            var siegeBreakerEastPathEnd = new Vector3(151.8634f, -335.1172f, 110.9524f);

            var packByEastDoorLoc = new Vector3(140.1003f, -299.1566f, 110.9622f);
            var packTwoLoc = new Vector3(161.4485f, -317.8856f, 110.9393f);

            var losByEastDoorLoc = new Vector3(107.9661f, -305.4395f, 106.4356f);
            var pullFromLoc = new Vector3(126.643f, -312.1581f, 110.9481f);

            return async loc =>
                        {
                            var stage = ScenarioInfo.Current.CurrentStage;

							if (stage.StageNumber != 2 || !stage.GetCriteria(2).IsComplete)
                                return false;

                            if (Me.Z < 100)
                                return false;
                            var roamingSiegeBreaker = ObjectManager.GetObjectsOfType<WoWUnit>()
                                .FirstOrDefault(
                                    u =>
                                        u.Entry == MobId_BlackIronSiegebreaker && u.IsAlive &&
                                        WoWMathHelper.GetNearestPointOnLineSegment(
                                            u.Location,
                                            siegeBreakerWestPathEnd,
                                            siegeBreakerEastPathEnd).DistanceSquared(u.Location) < 5 * 5);

                            // pull the pack just to the left side of the east doorway.
                            var packByEastDoor =
                                ScriptHelpers.GetUnfriendlyNpsAtLocation(packByEastDoorLoc, 7).FirstOrDefault();
                            if (await ScriptHelpers.PullNpcToLocation(
                                () => packByEastDoor != null,
                                () =>
                                    roamingSiegeBreaker == null ||
                                    roamingSiegeBreaker.Location.DistanceSquared(packByEastDoor.Location) > 30 * 30,
                                packByEastDoor,
                                losByEastDoorLoc,
                                loc,
                                5000,
                                waitAtLocationRadius: 3))
                            {
                                return true;
                            }

                            // pack across the room of the east door entrance
                            var packTwo = ScriptHelpers.GetUnfriendlyNpsAtLocation(packTwoLoc, 7).FirstOrDefault();
                            if (await ScriptHelpers.PullNpcToLocation(
                                () => packTwo != null,
                                () =>
                                    roamingSiegeBreaker == null ||
                                    roamingSiegeBreaker.Location.DistanceSquared(packTwo.Location) > 30 * 30,
                                packTwo,
                                losByEastDoorLoc,
                                Me.IsLeader() ? pullFromLoc : loc,
                                5000,
                                waitAtLocationRadius: 3))
                            {
                                return true;
                            }

                            // Finally, pull the roaming Siege Breaker
                            if (await ScriptHelpers.PullNpcToLocation(
                                () => roamingSiegeBreaker != null,
                                () => roamingSiegeBreaker.Location.DistanceSquared(packTwoLoc) < 25 * 25,
                                roamingSiegeBreaker,
                                pullFromLoc,
                                Me.IsLeader() ? pullFromLoc : loc,
                                5000,
                                waitAtLocationRadius: 3))
                            {
                                return true;
                            }

                            return false;
                        };
        }


        [EncounterHandler(79912, "Commander Tharbek", Mode = CallBehaviorMode.CurrentBoss)]
        public Func<WoWUnit, Task<bool>> CommanderTharbekStartEncounter()
        {
            var tankSpot = new Vector3(169.1132f, -419.7492f, 110.4723f);

            return async boss =>
            {
                if (!Me.IsLeader())
                    return false;

                if (ScenarioInfo.Current.CurrentStageNumber != 2
                    || ScenarioInfo.Current.CurrentStage.GetCriteria(3).IsComplete)
                {
                    return false;
                }

                if (Me.Location.DistanceSquared(tankSpot) > 30 * 30)
                    return false;

                if (Tharbek != null && Tharbek.Combat)
                    return false;

                return await ScriptHelpers.StayAtLocationWhile(() => Tharbek == null || !Tharbek.Combat, tankSpot, precision: 15);
            };
        }

        [EncounterHandler(79912, "Commander Tharbek")]
        public Func<WoWUnit, Task<bool>> CommanderTharbekEncounter()
        {
            AddAvoidLocation(
                () => true,
                8,
                o => ((WoWMissile)o).ImpactPosition,
                () => WoWMissile.InFlightMissiles.Where(m => m.SpellId == MissileSpellId_ImbuedIronAxe));

            AddAvoidObject(() => true, 8, MobId_ImbuedIronAxe);

            return async boss => { return false; };
        }

        [EncounterHandler(80098, "Ironbarb Skyreaver")]
        public Func<WoWUnit, Task<bool>> IronbarbSkyreaverEncounter()
        {
            AddAvoidLocation(
                () => true,
                6,
                o => ((WoWMissile)o).ImpactPosition,
                () => WoWMissile.InFlightMissiles.Where(m => m.SpellId == MissileSpellId_NoxiousSpit));

            AddAvoidObject(() => true, 6, AreaTriggerId_NoxiousSpit);

            // his breath is very directional and deadly
            AddAvoidObject(
                () => true,
                7,
                o => o.Entry == MobId_IronbarbSkyreaver && o.ToUnit().HasAura("Incinerating Breath"),
                o => WoWMathHelper.GetNearestPointOnLineSegment(Me.Location, o.Location, o.Location.RayCast(o.Rotation, 30)));

            return async boss => false;
        }

        #endregion

        #region Son of the Beast

        private const uint MobId_SonoftheBeast = 77927;
        private const uint AreaTriggerId_FieryTrail = 6472;

        [EncounterHandler((int)MobId_SonoftheBeast, "Son of the Beast")]
        public Func<WoWUnit, Task<bool>> SonoftheBeastEncounter()
        {
            AddAvoidObject(4, AreaTriggerId_FieryTrail);

            return async boss => { return false; };
        }

        #endregion

        // http://www.wowhead.com/guide=2670/upper-blackrock-spire-dungeon-strategy-guide#ragewing-the-untamed
        #region Ragewing the Untamed

        #region Trash

        private const uint MobId_BlackIronGroundshaker = 76599;

        [EncounterHandler((int)MobId_BlackIronGroundshaker, "BlackIron Groundshaker")]
        public Func<WoWUnit, Task<bool>> BlackIronGroundshakeEncounter()
        {
            AddAvoidObject(
                8,
                o => o.Entry == MobId_BlackIronGroundshaker && o.ToUnit().HasAura("Earthpounder"),
                o => o.Location.RayCast(o.Rotation, 7));

            return async npc => false;
        }

        #endregion

        private readonly Vector3 _rageWingOOCLoc = new Vector3(34.52922f, -391.3831f, 51.63854f);
        private readonly Vector3 _ragewingPhaseOneLoc = new Vector3(20.56284f, -404.3033f, 113.1969f);
        private readonly Vector3 _ragewingBridgeCenter = new Vector3(30.37753f, -404.645f, 110.7197f);

        private const int MissileSpellId_MagmaSpit = 155053;
        private const int MissileSpellId_FireStorm = 155073;

        private const uint MobId_RagewingtheUntamed = 76585;
        private const uint MobId_RagewingWhelp = 76801;

        private const uint AreaTriggerId_MagmaSpit = 6204;
        private const uint MobId_EngulfingFireInvisibleStalkerRtoL = 76813;
        private const uint MobId_EngulfingFireInvisibleStalkerLtoR = 76837;


        private WoWUnit _ragewing;
        private readonly WaitTimer _engulfingFireTimer = new WaitTimer(TimeSpan.FromSeconds(3));
        // http://www.wowhead.com/guides/dungeons/upper-blackrock-spire-dungeon-strategy-guide#ragewing-the-untamed
        [EncounterHandler((int)MobId_RagewingtheUntamed, "Ragewing the Untamed", Mode = CallBehaviorMode.Proximity, BossRange = 100)]
        public Func<WoWUnit, Task<bool>> RagewingtheUntamedEncounter()
        {
            var westBridgeSide = new Vector3(29.50844f, -382.2311f, 110.7248f);
            var eastBridgeSide = new Vector3(30.42133f, -428.4159f, 110.975f);

            var avoidLeftToRightRagingFire =
                new PerFrameCachedValue<bool>(
                    () => ScriptHelpers.IsViable(_ragewing) && ObjectManager.GetObjectsOfType<WoWUnit>()
                        .Any(u => u.Entry == MobId_EngulfingFireInvisibleStalkerLtoR
                            && (u.HasAura("Engulfing Fire") || (!_engulfingFireTimer.IsFinished && _ragewing.IsSafelyFacing(u, 30)))));

            var avoidRightToLeftRagingFire = new PerFrameCachedValue<bool>(
                () => ScriptHelpers.IsViable(_ragewing) && ObjectManager.GetObjectsOfType<WoWUnit>()
                        .Any(u => u.Entry == MobId_EngulfingFireInvisibleStalkerRtoL
                            && (u.HasAura("Engulfing Fire") || (!_engulfingFireTimer.IsFinished && _ragewing.IsSafelyFacing(u, 30)))));

            // avoid the impact of magma spit missiles and the puddles they leave behind
            AddAvoidLocation(
                () => !avoidRightToLeftRagingFire && !avoidLeftToRightRagingFire,
                3.5f,
                o => ((WoWMissile)o).ImpactPosition,
                () => WoWMissile.InFlightMissiles.Where(m => m.SpellId == MissileSpellId_MagmaSpit),
                priority: AvoidancePriority.High);

            AddAvoidObject(
                () => !avoidRightToLeftRagingFire && !avoidLeftToRightRagingFire,
                3.5f,
                o => o.Entry == AreaTriggerId_MagmaSpit, ignoreIfBlocking: false, priority: AvoidancePriority.High);

            // Fire storm is the ability used while flying over bridge 
            //AddAvoidLocation(
            //	ctx => !Me.IsHealer(),
            //	8,
            //	o => ((WoWMissile)o).ImpactPosition,
            //	() => WoWMissile.InFlightMissiles.Where(m => m.SpellId == MissileSpellId_FireStorm));

            var leftDoorEdge = new Vector3(30.96826f, -438.6647f, 111.1953f);
            var rightDoorEdge = new Vector3(37.24679f, -438.27f, 111.0201f);

            // pick a random location inside door
            var randomPointOnBridge = WoWMathHelper.GetRandomPointInCircle(new Vector3(34.0181f, -431.451f, 110.975f), 2.5f);

            return async boss =>
            {
                _ragewing = boss;

                // Don't run if not on the floor level that boss is on. 
                if (Me.Z < 100)
                    return false;

                // Get onto the bridge before door closes.
                if (await ScriptHelpers.MoveInsideBossRoom(boss, leftDoorEdge, rightDoorEdge, randomPointOnBridge, p => p.X < 50 && p.X > 20))
                    return true;

                // Hero if available. 
                if (boss.HealthPercent <= 50 && boss.Z < 112 && boss.HealthPercent > 25 && await ScriptHelpers.CastHeroism())
                    return true;

                if (await ScriptHelpers.DispelEnemy("Burning Rage", ScriptHelpers.EnemyDispelType.Enrage, boss))
                    return true;

                if (avoidRightToLeftRagingFire)
                {
                    return await ScriptHelpers.StayAtLocationWhile(
                        () => avoidRightToLeftRagingFire,
                        westBridgeSide,
                        "West side of bridge that's safe from Raging Fire", 4);
                }

                if (avoidLeftToRightRagingFire)
                {
                    return await ScriptHelpers.StayAtLocationWhile(
                        () => avoidLeftToRightRagingFire,
                        eastBridgeSide,
                        "East side of bridge that's safe from Raging Fire", 4);
                }

                if (boss.HealthPercent > 50)
                {
                    return await ScriptHelpers.StayAtLocationWhile(
                        () => !avoidLeftToRightRagingFire && !avoidRightToLeftRagingFire && ScriptHelpers.IsViable(boss) && boss.Combat,
                        _ragewingBridgeCenter,
                        "Center of bridge", 8);
                }
                return false;
            };
        }

        private void OnRaidBossEmote(object sender, LuaEventArgs args)
        {
            if (!ScriptHelpers.IsViable(_ragewing) || !_ragewing.Combat || _ragewing.HasAura("Engulfing Fire"))
                return;

            if (!_engulfingFireTimer.IsFinished)
                return;

            _engulfingFireTimer.Reset();
        }

        private void GameWorld_UnitSpellLineOfSightTest(object sender, UnitSpellLineOfSightTestEventArgs e)
        {
            if (e.Unit.Entry != MobId_RagewingtheUntamed)
                return;

            var spellDist = e.Unit.CombatReach + 40;
            e.InSpellLineOfSight = e.Unit.DistanceSqr < spellDist * spellDist;
            e.Handled = true;
        }

        #endregion

        // http://www.wowhead.com/guide=2670/upper-blackrock-spire-dungeon-strategy-guide#warlord-zaela
        #region Warlord Zaela

        #region Trash

        private const uint MobId_WindfuryTotem = 80703;
        private const uint AreaTriggerId_FlameSpit = 6990;
        private const int SpellId_BurningBreath = 166040;

        private const uint MobId_EmberscaleIronflight = 82428;
        [EncounterHandler((int)MobId_EmberscaleIronflight, "Emberscale Ironflight")]
        public Func<WoWUnit, Task<bool>> EmberscaleIronflightEncounter()
        {
            AddAvoidObject(3, AreaTriggerId_FlameSpit);

            AddAvoidLocation(
                () => true,
                10,
                o => (Vector3)o,
                GetDrakeAvoidPoints);

            return async npc => false;
        }

        private IEnumerable<object> GetDrakeAvoidPoints()
        {
            return ObjectManager.GetObjectsOfType<WoWUnit>()
                .Where(drake => drake.Entry == MobId_EmberscaleIronflight && IsCastingBurningBreath(drake))
                .SelectMany(drake => ScriptHelpers.GetPointsAlongLineSegment(drake.Location, drake.Location.RayCast(drake.Rotation, 60), 5))
                .Cast<object>();
        }

        private bool IsCastingBurningBreath(WoWUnit unit)
        {
            return unit.CastingSpellId == SpellId_BurningBreath || unit.HasAura("Burning Breath");
        }

        #endregion

        private const int SpellId_BlackIronCyclone = 155721;
        private const int MissileSpellId_ReboundingBlade = 155711;

        private const uint MobId_WarlordZaela = 77120;
        private const uint AreaTriggerId_BurningBridge = 7387;

        [EncounterHandler((int)MobId_WarlordZaela, "Warlord Zaela", Mode = CallBehaviorMode.Proximity)]
        public Func<WoWUnit, Task<bool>> WarlordZaelaEncounter()
        {
            WoWUnit boss = null;

            AddAvoidObject(
                () => true,
                o => o.ToUnit().CurrentTargetGuid == Me.Guid ? 10 : 8,
                u => u.Entry == MobId_WarlordZaela && IsCastingBlackIronCylone(u.ToUnit()));

            // Range should always stay away from boss.
            AddAvoidObject(
                () => Me.IsRange(),
                8,
                u => u.Entry == MobId_WarlordZaela && u.ToUnit().Combat && boss.ZDiff < 5);

            AddAvoidObject(5, AreaTriggerId_BurningBridge);

            // Don't run into players while fixated by cylone
            AddAvoidObject(
                () => ScriptHelpers.IsViable(boss) && IsCastingBlackIronCylone(boss) && boss.CurrentTargetGuid == Me.Guid,
                8,
                o => o is WoWPlayer && !o.IsMe && o.ToPlayer().IsAlive);

            // Run away from the target of Rebounding Blade to avoid chaining it
            AddAvoidLocation(
                () => true,
                8,
                o => o,
                () => WoWMissile.InFlightMissiles
                    .Where(m => m.SpellId == MissileSpellId_ReboundingBlade)
                    .Select(m => m.Target)
                    .Where(t => t != null && !t.IsMe)
                    .Select(t => t.Location));

            var leftDoorEdge = new Vector3(20.35804f, -139.3033f, 97.76679f);
            var rightDoorEdge = new Vector3(27.55599f, -139.106f, 97.79568f);

            // pick a random location inside door
            var randomPointOnBridge = WoWMathHelper.GetRandomPointInCircle(new Vector3(25.55703f, -133.2437f, 97.73102f), 2.5f);
            return async npc =>
            {
                boss = npc;

                if (ScriptHelpers.IsBossAlive("Ragewing the Untamed"))
                    return false;

                // Get onto the bridge before door closes.
                if (await ScriptHelpers.MoveInsideBossRoom(boss, leftDoorEdge, rightDoorEdge, randomPointOnBridge))
                    return true;

                // Hero if available. 
                if (boss.HealthPercent <= 97 && boss.HealthPercent > 25 && await ScriptHelpers.CastHeroism())
                    return true;

                return false;
            };
        }

        private bool IsCastingBlackIronCylone(WoWUnit unit)
        {
            return unit.CastingSpellId == SpellId_BlackIronCyclone || unit.HasAura("Black Iron Cyclone");
        }

        #endregion
    }


    public class UpperBlackrockSpireHeroic : UpperBlackrockSpire
    {
        #region Overrides of Dungeon

        public override uint DungeonId { get { return 860; } }

        #endregion
    }
}