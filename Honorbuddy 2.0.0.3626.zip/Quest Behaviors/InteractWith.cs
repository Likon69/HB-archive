﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using Styx.Database;
using Styx.Helpers;
using Styx.Logic.Inventory.Frames.Gossip;
using Styx.Logic.Pathing;
using Styx.Logic.Questing;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using TreeSharp;
using Action = TreeSharp.Action;

namespace Styx.Bot.Quest_Behaviors
{
    public class InteractWith : CustomForcedBehavior
    {
        public InteractWith(Dictionary<string,string> args) 
            : base(args)
        {
            uint mobId;
            if(!uint.TryParse(Args["MobId"], out mobId))
                Logging.Write("Parsing mobid in InteractWith behavior failed! please check your profile!");

            int numOfTimes;
            if (!int.TryParse(Args["NumOfTimes"], out numOfTimes))
                Logging.Write("Parsing mobid in InteractWith behavior failed! please check your profile!");

            WoWPoint location;
            string locationString = Args["Location"];
            float x, y, z;
            if(!float.TryParse(locationString.Split(' ')[0], out x))
                Logging.Write("Couldn't parse X value in InteractWith behavior");

            if (!float.TryParse(locationString.Split(' ')[1], out y))
                Logging.Write("Couldn't parse Y value in InteractWith behavior");

            if (!float.TryParse(locationString.Split(' ')[2], out z))
                Logging.Write("Couldn't parse Z value in InteractWith behavior");

            NumOfTimes = numOfTimes;
            MobId = mobId;
            Location = new WoWPoint(x, y, z);
        }

        public WoWPoint Location { get; private set; }
        public int Counter { get; set; }
        public uint MobId { get; set; }
        public int NumOfTimes { get; set; }

        /// <summary>
        /// A Queue for npc's we need to talk to
        /// </summary>
        private WoWUnit CurrentUnit { get { return ObjectManager.GetObjectsOfType<WoWUnit>().FirstOrDefault(unit => unit.Distance < 100 && unit.Entry == MobId); } }

        #region Overrides of CustomForcedBehavior

        private Composite _root;
        protected override Composite CreateBehavior()
        {
            return _root ?? (_root =
                new PrioritySelector(

                    new Decorator(ret => Counter >= NumOfTimes,
                        new Action(ret => _isDone = true)),

                        new PrioritySelector(

                            new Decorator(ret => CurrentUnit != null && !CurrentUnit.WithinInteractRange,
                                new Action(ret => Navigator.MoveTo(CurrentUnit.Location))
                                ),

                            new Decorator(ret => StyxWoW.Me.IsMoving,
                                new Action(delegate
                                {
                                    WoWMovement.MoveStop();
                                    StyxWoW.SleepForLagDuration();
                                })
                                ),
                                    
                            new Action(delegate
                                            {
                                                CurrentUnit.Interact();
                                                StyxWoW.SleepForLagDuration();
                                                Counter++;
                                                Thread.Sleep(3000);
                                            }),

                            new Action(ret => Navigator.MoveTo(Location))
                        )
                    ));
        }

        private bool _isDone;
        public override bool IsDone
        {
            get { return _isDone; }
        }

        #endregion
    }
}
