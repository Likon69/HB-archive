﻿// Behavior originally contributed by Bobby53.
//
// LICENSE:
// This work is licensed under the
//     Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License.
// also known as CC-BY-NC-SA.  To view a copy of this license, visit
//      http://creativecommons.org/licenses/by-nc-sa/3.0/
// or send a letter to
//      Creative Commons // 171 Second Street, Suite 300 // San Francisco, California, 94105, USA.
//

#region Summary and Documentation
// Stops the Quest Bot.  Will write 'Msg' to the log and Goal Text.
// Also write the line number it halted at for easily locating in profile.
// 
// Useful for testing assumptions in quest profile and during profile
// development to force profile to automatically stop at designated point
// 
// ##Syntax##
// [optional] QuestId: Id of the quest (default is 0)
// [optional] Msg: text value to display (default says stopped by profile)
// [optional] Color: color to use for message in log (default is red)
// 
// Note:  QuestId behaves the same as on every other behavior.  If 0, then
// halt always occurs.  Otherwise, for non-zero QuestId only halts if the
// character has the quest and its not completed
#endregion


#region Examples
#endregion


#region Usings
using System;
using System.Collections.Generic;
using System.Drawing;

using Honorbuddy.QuestBehaviorCore;
using Styx.CommonBot;
using Styx.CommonBot.Profiles;
using Styx.TreeSharp;
#endregion


namespace Honorbuddy.Quest_Behaviors.Halt
{
    [CustomBehaviorFileName(@"Halt")]
    public class Halt : CustomForcedBehavior
    {
        public Halt(Dictionary<string, string> args)
            : base(args)
        {
            QBCLog.BehaviorLoggingContext = this;

            try
            {
                // QuestRequirement* attributes are explained here...
                //    http://www.thebuddyforum.com/mediawiki/index.php?title=Honorbuddy_Programming_Cookbook:_QuestId_for_Custom_Behaviors
                // ...and also used for IsDone processing.
                QuestId = GetAttributeAsNullable<int>("QuestId", false, ConstrainAs.QuestId(this), null) ?? 0;
                QuestRequirementComplete = GetAttributeAsNullable<QuestCompleteRequirement>("QuestCompleteRequirement", false, null, null) ?? QuestCompleteRequirement.NotComplete;
                QuestRequirementInLog = GetAttributeAsNullable<QuestInLogRequirement>("QuestInLogRequirement", false, null, null) ?? QuestInLogRequirement.InLog;

                Color = GetAttributeAsNullable<Color>("Color", false, null, null) ?? Color.Red;
                Message = GetAttributeAs<string>("Message", false, ConstrainAs.StringNonEmpty, new[] { "Msg", "Text" }) ?? "Quest Profile HALT";
            }

            catch (Exception except)
            {
                // Maintenance problems occur for a number of reasons.  The primary two are...
                // * Changes were made to the behavior, and boundary conditions weren't properly tested.
                // * The Honorbuddy core was changed, and the behavior wasn't adjusted for the new changes.
                // In any case, we pinpoint the source of the problem area here, and hopefully it
                // can be quickly resolved.
                QBCLog.Exception(except);
                IsAttributeProblem = true;
            }
        }


        // Attributes provided by caller
        public Color Color { get; private set; }
        public string Message { get; private set; }
        public int QuestId { get; private set; }
        public QuestCompleteRequirement QuestRequirementComplete { get; private set; }
        public QuestInLogRequirement QuestRequirementInLog { get; private set; }

        private bool _isDisposed;

        // DON'T EDIT THESE--they are auto-populated by Subversion
        public override string SubversionId { get { return ("$Id: Halt.cs 1085 2013-11-30 10:44:50Z Dogan $"); } }
        public override string SubversionRevision { get { return ("$Revision: 1085 $"); } }


        ~Halt()
        {
            Dispose(false);
        }


        public void Dispose(bool isExplicitlyInitiatedDispose)
        {
            if (!_isDisposed)
            {
                // NOTE: we should call any Dispose() method for any managed or unmanaged
                // resource, if that resource provides a Dispose() method.

                // Clean up managed resources, if explicit disposal...
                if (isExplicitlyInitiatedDispose)
                {
                    // empty, for now
                }

                // Clean up unmanaged resources (if any) here...
                TreeRoot.GoalText = string.Empty;
                TreeRoot.StatusText = string.Empty;

                // Call parent Dispose() (if it exists) here ...
                base.Dispose();
            }

            _isDisposed = true;
        }


        #region Overrides of CustomForcedBehavior

        protected override Composite CreateBehavior()
        {
            return (null);
        }


        public override void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }


        public override bool IsDone
        {
            get
            {
                return (!UtilIsProgressRequirementsMet(QuestId, QuestRequirementInLog, QuestRequirementComplete));
            }
        }


        public override void OnStart()
        {
            // This reports problems, and stops BT processing if there was a problem with attributes...
            // We had to defer this action, as the 'profile line number' is not available during the element's
            // constructor call.
            OnStart_HandleAttributeProblem();

            // If the quest is complete, this behavior is already done...
            // So we don't want to falsely inform the user of things that will be skipped.
            if (!IsDone)
            {
                QBCLog.DeveloperInfo("\n\n    " + Message + "\n");

                this.UpdateGoalText(QuestId, Message);

                TreeRoot.Stop("Bot stop requested by Halt quest behavior.");
            }
        }

        #endregion
    }
}

