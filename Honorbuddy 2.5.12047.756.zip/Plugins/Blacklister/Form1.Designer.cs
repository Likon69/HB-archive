﻿namespace Blacklister
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.trkDist = new System.Windows.Forms.TrackBar();
            this.label1 = new System.Windows.Forms.Label();
            this.lblDist = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.trkMaxMobs = new System.Windows.Forms.TrackBar();
            this.btnSave = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.lblMaxMobs = new System.Windows.Forms.Label();
            this.txt1 = new System.Windows.Forms.TextBox();
            this.btnListSave = new System.Windows.Forms.Button();
            this.txtSecs = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.trkDist)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trkMaxMobs)).BeginInit();
            this.SuspendLayout();
            // 
            // trkDist
            // 
            this.trkDist.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.trkDist.Location = new System.Drawing.Point(12, 29);
            this.trkDist.Maximum = 100;
            this.trkDist.Name = "trkDist";
            this.trkDist.Size = new System.Drawing.Size(267, 45);
            this.trkDist.TabIndex = 0;
            this.trkDist.TickFrequency = 5;
            this.trkDist.Value = 20;
            this.trkDist.ValueChanged += new System.EventHandler(this.trkDist_ValueChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(16, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(203, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Don\'t select nodes with mobs closer than:";
            // 
            // lblDist
            // 
            this.lblDist.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblDist.AutoSize = true;
            this.lblDist.Location = new System.Drawing.Point(279, 29);
            this.lblDist.Name = "lblDist";
            this.lblDist.Size = new System.Drawing.Size(19, 13);
            this.lblDist.TabIndex = 2;
            this.lblDist.Text = "20";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(16, 77);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(186, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "And maximum number of hostile mobs:";
            // 
            // trkMaxMobs
            // 
            this.trkMaxMobs.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.trkMaxMobs.Location = new System.Drawing.Point(16, 93);
            this.trkMaxMobs.Maximum = 100;
            this.trkMaxMobs.Name = "trkMaxMobs";
            this.trkMaxMobs.Size = new System.Drawing.Size(263, 45);
            this.trkMaxMobs.TabIndex = 5;
            this.trkMaxMobs.TickFrequency = 5;
            this.trkMaxMobs.ValueChanged += new System.EventHandler(this.trkMaxMobs_ValueChanged);
            // 
            // btnSave
            // 
            this.btnSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSave.Location = new System.Drawing.Point(169, 173);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(110, 23);
            this.btnSave.TabIndex = 6;
            this.btnSave.Text = "Save and Close";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button1.Location = new System.Drawing.Point(19, 173);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(110, 23);
            this.button1.TabIndex = 7;
            this.button1.Text = "Cancel";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // lblMaxMobs
            // 
            this.lblMaxMobs.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblMaxMobs.AutoSize = true;
            this.lblMaxMobs.Location = new System.Drawing.Point(285, 93);
            this.lblMaxMobs.Name = "lblMaxMobs";
            this.lblMaxMobs.Size = new System.Drawing.Size(13, 13);
            this.lblMaxMobs.TabIndex = 8;
            this.lblMaxMobs.Text = "0";
            // 
            // txt1
            // 
            this.txt1.Location = new System.Drawing.Point(304, 29);
            this.txt1.Multiline = true;
            this.txt1.Name = "txt1";
            this.txt1.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txt1.Size = new System.Drawing.Size(280, 141);
            this.txt1.TabIndex = 9;
            // 
            // btnListSave
            // 
            this.btnListSave.Location = new System.Drawing.Point(304, 1);
            this.btnListSave.Name = "btnListSave";
            this.btnListSave.Size = new System.Drawing.Size(165, 22);
            this.btnListSave.TabIndex = 10;
            this.btnListSave.Text = "Apply changes";
            this.btnListSave.UseVisualStyleBackColor = true;
            this.btnListSave.Click += new System.EventHandler(this.btnListSave_Click);
            // 
            // txtSecs
            // 
            this.txtSecs.Location = new System.Drawing.Point(19, 144);
            this.txtSecs.Name = "txtSecs";
            this.txtSecs.Size = new System.Drawing.Size(126, 20);
            this.txtSecs.TabIndex = 11;
            this.txtSecs.Text = "120";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(151, 151);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(128, 13);
            this.label3.TabIndex = 12;
            this.label3.Text = "Blacklist time, in seconds.";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(587, 211);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtSecs);
            this.Controls.Add(this.btnListSave);
            this.Controls.Add(this.txt1);
            this.Controls.Add(this.lblMaxMobs);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.trkMaxMobs);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblDist);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.trkDist);
            this.Name = "Form1";
            this.Text = "Blacklister";
            ((System.ComponentModel.ISupportInitialize)(this.trkDist)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trkMaxMobs)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TrackBar trkDist;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblDist;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TrackBar trkMaxMobs;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label lblMaxMobs;
        private System.Windows.Forms.TextBox txt1;
        private System.Windows.Forms.Button btnListSave;
        private System.Windows.Forms.TextBox txtSecs;
        private System.Windows.Forms.Label label3;
    }
}

