﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Blacklister
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            Blacklister.BlacklisterPlugin.load();
            trkDist.Value = Blacklister.BlacklisterPlugin.mindistance;
            trkMaxMobs.Value = Blacklister.BlacklisterPlugin.maxmobs;
            txt1.Text = Blacklister.BlacklisterPlugin.txtMobList;
            txtSecs.Text = Blacklister.BlacklisterPlugin.secs.ToString();
        }

        private void trkMaxMobs_ValueChanged(object sender, EventArgs e)
        {
            lblMaxMobs.Text = trkMaxMobs.Value.ToString();
        }

        private void trkDist_ValueChanged(object sender, EventArgs e)
        {
            lblDist.Text = trkDist.Value.ToString();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            saveall();
            txt1.Text = Blacklister.BlacklisterPlugin.txtMobList;
            Blacklister.BlacklisterPlugin.secs = Double.Parse(txtSecs.Text.ToString());
            
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnListSave_Click(object sender, EventArgs e)
        {
            saveall();
            txt1.Text = Blacklister.BlacklisterPlugin.txtMobList;
            Blacklister.BlacklisterPlugin.secs = Double.Parse(txtSecs.Text.ToString());
            txtSecs.Text = Blacklister.BlacklisterPlugin.secs.ToString();
        }

        void saveall()
        {
            Blacklister.BlacklisterPlugin.secs = Double.Parse(txtSecs.Text.ToString());
            Blacklister.BlacklisterPlugin.mindistance = trkDist.Value;
            Blacklister.BlacklisterPlugin.maxmobs = trkMaxMobs.Value;
            Blacklister.BlacklisterPlugin.textholder = txt1.Text.ToString();
            Blacklister.BlacklisterPlugin.saveList();

        }
    }
}
