﻿using System;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Windows.Forms;
using Styx;
using Styx.WoWInternals.WoWObjects;
using Styx.Plugins;


namespace CombatPuller.Settings
{
    public partial class GUI : Form
    {
		private Main main;
		
        public GUI(Main main)
        {
			this.main = main;
            InitializeComponent();
        }

        private void GUI_Load(object sender, EventArgs e)
        {
            pgSettings.SelectedObject = CPSettings.Instance;
            CPSettings.Instance.Load();
        }
				
        private void GUI_FormClosing(object sender, FormClosingEventArgs e)
        {
            CPSettings.Instance.Save();
			main.set_init();
        }
		
		private void pgSettings_PropertyValueChanged(object s, PropertyValueChangedEventArgs e)
        {
            if (pgSettings.SelectedObject != null && pgSettings.SelectedObject is CPSettings)
                ((CPSettings)pgSettings.SelectedObject).Save();
        }
		
        private void pgSettings_Click(object sender, EventArgs e)
        {

        }

        private void donateToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Donation welcome. Thanks!");
            Process.Start("https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=VAHEJLHYN3BRL&lc=RU&item_name=PLUGIN%20Combat%20Puller&currency_code=USD&bn=PP%2dDonationsBF%3abtn_donateCC_LG%2egif%3aNonHosted");
        }

		private void NameToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("HB Forum Link");
            Process.Start("http://www.thebuddyforum.com/honorbuddy-forum/plugins/combat/165213-plugin-combat-puller.html#post1533111");
        }
        
    }
}
