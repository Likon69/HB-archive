﻿using System.ComponentModel;
using Styx;
using Styx.Common;
using Styx.Helpers;
using Styx.WoWInternals.WoWObjects;

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Styx.WoWInternals;

namespace CombatPuller.Settings
{
    internal class CPSettings : Styx.Helpers.Settings
    {
        private static CPSettings _instance;
        private static LocalPlayer Me { get { return StyxWoW.Me; } }

        private CPSettings()
            : base(SettingsPath + ".config")
        {
        }

        public static CPSettings Instance
        {
            get { return _instance ?? (_instance = new CPSettings()); }
        }

        private static string SettingsPath
        {
            get
            {
                return string.Format("{0}\\Settings\\{1}\\{2}\\CombatPuller", Utilities.AssemblyDirectory, Realm, Me.Name);
            }
        }

		private static string Realm
        {
            get
            {
                string realm;
                try
                {
                    realm = Lua.GetReturnVal<string>("return GetRealmName()", 0);
                }
                catch (Exception)
                {
                    realm = "NOrealm";
                }
                return realm;
            }
        }

        [Setting]
        [Styx.Helpers.DefaultValue(3)]
        [Category("- Controls")]
        [DisplayName("几只怪开始攻击")]
        [Description("多少只怪物开始攻击")]
        public int MobMax { get; set; }
		
		[Setting]
        [Styx.Helpers.DefaultValue(50)]
        [Category("- Controls")]
        [DisplayName("范围")]
        [Description("在该范围内杀怪 单位码数")]
        public int PullRange { get; set; }
		
		[Setting]
        [Styx.Helpers.DefaultValue(50)]
        [Category("- Controls")]
        [DisplayName("停止拉怪生命值")]
        [Description("如果生命值低于％以下,停止拉怪，开始攻击")]
        public int MaxHealth { get; set; }
		
		[Setting]
        [Styx.Helpers.DefaultValue(10)]
        [Category("- Controls")]
        [DisplayName("拾取怪物尸体数量")]
        [Description("如果地上尸体大于该数量，开始拾取")]
        public int MaxCorpse { get; set; }
		
		[Setting]
        [Styx.Helpers.DefaultValue(0)]
        [Category("- Controls")]
        [DisplayName("定时器")]
        [Description("在多少分钟后激活插件")]
        public int RunTime { get; set; }
		
		[Setting]
        [Styx.Helpers.DefaultValue("0")]
        [Category("- Targets")]
        [DisplayName("按怪物ID拉怪")]
        [Description("按怪物ID拉怪，多个怪物ID用空格分开，如: 1 23 43 12 32 33")]
        public string FList { get; set; }
		
		[Setting]
        [Styx.Helpers.DefaultValue(false)]
        [Category("- Targets")]
        [DisplayName("杀死所有怪物")]
        [Description("无视黑名单的设置，杀死所有能杀的怪物 True=开启 False=关闭")]
        public bool AllFactions { get; set; }

		[Setting]
        [Styx.Helpers.DefaultValue("0")]
        [Category("- Targets")]
        [DisplayName("怪物黑名单")]
        [Description("怪物黑名单，不想杀的怪填这里屏蔽，多个怪用空格分开: 1 23 43 12 32 33")]
        public string BList { get; set; }
		
		[Setting]
        [Styx.Helpers.DefaultValue(false)]
        [Category("- non-Stop")]
        [DisplayName("Pull in fight")]
        [Description("Pull in fight if [pulled mobs] < [MAX Mobs]")]
        public bool PullInFight { get; set; }
		
		[Setting]
        [Styx.Helpers.DefaultValue(false)]
        [Category("- non-Stop")]
        [DisplayName("战斗中拾取")]
        [Description("这里开启之后，上面的拾取怪物尸体数量将失效")]
        public bool LootInCombat { get; set; }
		
    }
}
