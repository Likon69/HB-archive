﻿using System.Collections.Generic;
using Styx;
using Styx.CommonBot;
using Styx.WoWInternals.WoWObjects;

// ReSharper disable CheckNamespace
namespace Bots.DungeonBuddy.DungeonScripts.WarlordsOfDraenor
// ReSharper restore CheckNamespace
{
    #region Normal Difficulty

    public class BloodmaulSlagMines : Dungeon
    {
        #region Overrides of Dungeon

        public override uint DungeonId
        {
            get { return 787; }
        }

        public override WoWPoint Entrance
        {
            get { return new WoWPoint(7266.906, 4459.15, 129.4387); }
        }

        public override WoWPoint ExitLocation
        {
            get { return new WoWPoint(1819.533, -254.8778, 256.6878); }
        }

        public override void RemoveTargetsFilter(List<WoWObject> units)
        {
            units.RemoveAll(
                ret =>
                {
                    return false;
                });
        }

        public override void IncludeTargetsFilter(List<WoWObject> incomingunits, HashSet<WoWObject> outgoingunits)
        {
            foreach (var obj in incomingunits)
            {
                var unit = obj as WoWUnit;
                if (unit != null)
                {
                }
            }
        }

        public override void WeighTargetsFilter(List<Targeting.TargetPriority> units)
        {
            foreach (var priority in units)
            {
                var unit = priority.Object as WoWUnit;
                if (unit != null)
                {

                }
            }
        }


        #endregion

        /*
         Hi, I'm not sure who in charge of Dungeonbuddy, just want let you know that we need to blacklist 1 mob on The Slag Forge new dungeon. A mob hanging on the ceiling and we can't attack coz he never drop down.

This is my code, hope you can improve it

 if (Me.CurrentTarget != null
                && Me.CurrentTarget.Entry == 75814
                && Me.CurrentTarget.Location.Distance(new WoWPoint(2050.144, 18.67014, 237.2543)) < 2)
            {
                Logging.Write("Blaclist {0}", Me.CurrentTarget.SafeName);
                Blacklist.Add(Me.CurrentTarget.Guid, BlacklistFlags.Combat, TimeSpan.FromMinutes(5));
            }
         */

        private static LocalPlayer Me
        {
            get { return StyxWoW.Me; }
        }

        #region Root


        #endregion

    }

    #endregion

    #region Heroic Difficulty

    public class BloodmaulSlagMinesHeroic : BloodmaulSlagMines
    {
        #region Overrides of Dungeon

        public override uint DungeonId
        {
            get { return 859; }
        }

        #endregion
    }

    #endregion
}