﻿#region Revision Info

// This file is part of Singular - A community driven Honorbuddy CC
// $Author: apoc $
// $Date: 2011-03-18 18:36:36 +0200 (Cum, 18 Mar 2011) $
// $HeadURL: http://svn.apocdev.com/singular/trunk/Singular/ClassSpecific/Warrior/Fury.cs $
// $LastChangedBy: apoc $
// $LastChangedDate: 2011-03-18 18:36:36 +0200 (Cum, 18 Mar 2011) $
// $LastChangedRevision: 190 $
// $Revision: 190 $

#endregion

using System;
using System.Linq;

using Styx.Combat.CombatRoutine;
using Styx.Helpers;
using Styx.Logic.Combat;

using TreeSharp;

using Action = TreeSharp.Action;

namespace Singular
{
    partial class SingularRoutine
    {
        [Class(WoWClass.Warrior)]
        [Spec(TalentSpec.FuryWarrior)]
        [Context(WoWContext.All)]
        [Behavior(BehaviorType.Combat)]
        public Composite CreateWarriorFuryCombat()
        {
            return new PrioritySelector(
                CreateEnsureTarget(),
                //Move to range
                CreateFaceUnit(),
                CreateAutoAttack(true),
                //Make sure you are in the primary DPS stance for fury warriors
                CreateSpellBuffOnSelf("Berserker Stance", ret => Me.RagePercent > 10 || Me.Combat),
                CreateSpellCast("Battle Shout", ret => Me.RagePercent < 20 || !Me.HasAura("Battle Shout")),
                CreateSpellCast(
                    "Piercing Howl", ret => Me.CurrentTarget.Distance < 10 &&
                                            Me.CurrentTarget.IsPlayer &&
                                            (!Me.CurrentTarget.HasAura("Hamstring") ||
                                             !Me.CurrentTarget.HasAura("Piercing Howl") ||
                                             !Me.CurrentTarget.HasAura("Slowing Poison"))),
                CreateSpellCast(
                    "Intimidating Shout", ret => Me.CurrentTarget.Distance < 8 &&
                                                 Me.CurrentTarget.IsPlayer &&
                                                 Me.CurrentTarget.IsCasting),
                CreateSpellCast("Intercept", ret => Me.CurrentTarget.Distance >= 9),
                CreateSpellCast("Heroic Throw", ret => Me.CurrentTarget.IsPlayer),
                CreateSpellCast("Enraged Regeneration", ret => Me.HealthPercent < 60),
                new Decorator(
                    ret => SpellManager.CanCast("Heroic Leap") && Me.CurrentTarget.Distance > 13,
                    new Action(
                        ret =>
                            {
                                SpellManager.Cast("Heroic Leap");
                                LegacySpellManager.ClickRemoteLocation(Me.CurrentTarget.Location);
                            })),
                //Move to melee			
                CreateMoveToAndFace(),
                CreateSpellCast(
                    "Hamstring", ret => Me.CurrentTarget.IsPlayer &&
                                        (!Me.CurrentTarget.HasAura("Hamstring") ||
                                         !Me.CurrentTarget.HasAura("Piercing Howl") ||
                                         !Me.CurrentTarget.HasAura("Slowing Poison"))),
                new Decorator(
                    ret => NearbyUnfriendlyUnits.Count(u => u.Distance < 6) > 3,
                    new PrioritySelector(
                        CreateSpellCast("Cleave"),
                        CreateSpellCast("Whirlwind"),
                        CreateSpellCast("Raging Blow"),
                        CreateSpellCast("Bloodthirst")
                        )),
                new Decorator(
                    ret =>
                    Me.CurrentTarget.Distance > 5 &&
                    !WoWMathHelper.IsFacing(Me.CurrentTarget.Location, Me.CurrentTarget.Rotation, Me.Location, (float)Math.PI) &&
                    Me.CurrentTarget.IsMoving && Me.CurrentTarget.MovementInfo.RunSpeed > Me.MovementInfo.RunSpeed,
                    new PrioritySelector(
                        CreateSpellCast("Darkflight")
                        )),
                CreateSpellCast("War Stomp", ret => Me.CurrentTarget.IsCasting),
                CreateSpellCast("Pummel", ret => Me.CurrentTarget.IsCasting),
                CreateSpellCast("Arcane Torrent", ret => Me.CurrentTarget.IsCasting),
                CreateSpellCast("Colossus Smash"),
                CreateUseEquippedItem(9),
                CreateSpellCast("Execute", ret => Me.CurrentTarget.HealthPercent < 20),
                CreateSpellCast("Raging Blow"),
                CreateSpellCast("Bloodthirst"),
                CreateSpellCast("Slam", ret => HasAuraStacks("Bloodsurge", 1)),
                //Uses Incite if you are spec'd into it
                CreateSpellCast("Heroic Strike", ret => Me.RagePercent > 60 || HasAuraStacks("Incite", 1)),
                CreateSpellCast("Victory Rush", ret => Me.HealthPercent < 80),
                // Again; movement comes last in melee. We have spells we can use at long-range, and should do so when the opportunity
                // presents itself.
                // If none of our short-range attacks are... in range... then just move forward.
                CreateMoveToAndFace(ret => Me.CurrentTarget)
                );
        }

        [Class(WoWClass.Warrior)]
        [Spec(TalentSpec.FuryWarrior)]
        [Context(WoWContext.All)]
        [Behavior(BehaviorType.Pull)]
        public Composite CreateWarriorFuryPull()
        {
            return
                new PrioritySelector(
                    CreateEnsureTarget(),
                    CreateAutoAttack(true),
                    CreateFaceUnit(),
                    //Ensures that you are in the right stance, since you do not need to stay in battle stance
                    CreateSpellBuffOnSelf("Berserker Stance", ret => Me.RagePercent > 10 || Me.Combat),
                    CreateSpellCast("Battle Shout", ret => Me.RagePercent < 20),
                    CreateSpellCast("Intercept", ret => Me.CurrentTarget.Distance >= 9),
                    CreateSpellCast("Heroic Throw"),
                    new Decorator(
                        ret => SpellManager.CanCast("Heroic Leap") && Me.CurrentTarget.Distance > 8,
                        new Action(
                            ret =>
                                {
                                    SpellManager.Cast("Heroic Leap");
                                    LegacySpellManager.ClickRemoteLocation(Me.CurrentTarget.Location);
                                })),
                    // Keep this last, as we want to use spells above to pull with. Only move if we can't use any of them!
                    CreateMoveToAndFace()
                    //,
                    //CreateSpellCast("Throw", 
                    //	ret => Me.Inventory.Equipped.Ranged != null &&
                    //        Me.Inventory.Equipped.Ranged.ItemInfo.WeaponClass == WoWItemWeaponClass.Thrown),
                    //CreateSpellCast("Shoot",
                    //	ret => Me.Inventory.Equipped.Ranged != null &&
                    //       (Me.Inventory.Equipped.Ranged.ItemInfo.WeaponClass == WoWItemWeaponClass.Bow ||
                    //        Me.Inventory.Equipped.Ranged.ItemInfo.WeaponClass == WoWItemWeaponClass.Crossbow ||
                    //		Me.Inventory.Equipped.Ranged.ItemInfo.WeaponClass == WoWItemWeaponClass.Gun)),
                    );
        }

        [Class(WoWClass.Warrior)]
        [Spec(TalentSpec.FuryWarrior)]
        [Context(WoWContext.All)]
        [Behavior(BehaviorType.CombatBuffs)]
        public Composite CreateWarriorFuryCombatBuffs()
        {
            return
                new PrioritySelector(
                    CreateSpellCast("Lifeblood", ret => Me.HealthPercent < 70),
                    CreateSpellCast("Gift of the Naaru", ret => Me.HealthPercent < 50),
                    CreateSpellCast("Berserking"),
                    CreateSpellCast(
                        "Recklessness",
                        ret => Me.HasAura("Death Wish") && Me.HealthPercent > 20),
                    CreateSpellCast(
                        "Inner Rage",
                        ret => Me.HasAura("Recklessness") ||
                               Me.HasAura("Death Wish") ||
                               Me.RagePercent > 80),
                    CreateSpellBuffOnSelf(
                        "Berserker Rage",
                        ret => Me.Auras.Any(
                            aura => aura.Value.Spell.Mechanic == WoWSpellMechanic.Fleeing ||
                                    aura.Value.Spell.Mechanic == WoWSpellMechanic.Sapped ||
                                    aura.Value.Spell.Mechanic == WoWSpellMechanic.Incapacitated ||
                                    aura.Value.Spell.Mechanic == WoWSpellMechanic.Horrified)),
                    CreateSpellBuffOnSelf("Stoneform", ret => Me.HealthPercent < 60),
                    CreateSpellBuffOnSelf("Shadowmeld", ret => Me.HealthPercent < 20),
                    CreateSpellBuffOnSelf("Blood Fury"),
                    CreateSpellBuffOnSelf(
                        "Every Man for Himself",
                        ret => Me.Auras.Any(
                            aura => aura.Value.Spell.Mechanic == WoWSpellMechanic.Asleep ||
                                    aura.Value.Spell.Mechanic == WoWSpellMechanic.Stunned ||
                                    aura.Value.Spell.Mechanic == WoWSpellMechanic.Rooted)),
                    CreateSpellBuffOnSelf(
                        "Will of the Forsaken",
                        ret => Me.Auras.Any(
                            aura => aura.Value.Spell.Mechanic == WoWSpellMechanic.Charmed ||
                                    aura.Value.Spell.Mechanic == WoWSpellMechanic.Asleep ||
                                    aura.Value.Spell.Mechanic == WoWSpellMechanic.Horrified ||
                                    aura.Value.Spell.Mechanic == WoWSpellMechanic.Fleeing)),
                    CreateSpellBuffOnSelf(
                        "Escape Artist",
                        ret => Me.Auras.Any(
                            aura => aura.Value.Spell.Mechanic == WoWSpellMechanic.Slowed ||
                                    aura.Value.Spell.Mechanic == WoWSpellMechanic.Rooted)),
                    CreateSpellBuffOnSelf(
                        "Death Wish",
                        ret => (Me.CurrentTarget.MaxHealth > Me.MaxHealth &&
                                Me.CurrentTarget.HealthPercent < 95 &&
                                Me.RagePercent > 50) ||
                               (Me.CurrentTarget.MaxHealth > Me.MaxHealth &&
                                Me.HealthPercent > 10 && Me.HealthPercent < 75)),
                    //Do not need to be enraged
                    //ret => !Me.Auras.Any(
                    //aura => aura.Value.Spell.Mechanic == WoWSpellMechanic.Enraged)),
                    CreateSpellBuffOnSelf(
                        "Berserker Rage",
                        ret => !Me.Auras.Any(
                            aura => aura.Value.Spell.Mechanic == WoWSpellMechanic.Enraged)),
                    CreateSpellBuffOnSelf(
                        "Battle Shout", ret => !Me.HasAura("Horn of the Winter") &&
                                               !Me.HasAura("Roar of Courage") &&
                                               !Me.HasAura("Strength of Earth Totem"))
                    );
        }

        [Class(WoWClass.Warrior)]
        [Spec(TalentSpec.FuryWarrior)]
        [Context(WoWContext.All)]
        [Behavior(BehaviorType.PreCombatBuffs)]
        public Composite CreateWarriorFuryPreCombatBuffs()
        {
            return
                new PrioritySelector(
                    CreateSpellBuffOnSelf("Battle Stance", ret => Me.RagePercent <= 10 && !Me.Combat),
                    CreateSpellBuffOnSelf("Berserker Stance", ret => Me.RagePercent > 10 || Me.Combat),
                    CreateSpellCast("Battle Shout")
                    );
        }
    }
}