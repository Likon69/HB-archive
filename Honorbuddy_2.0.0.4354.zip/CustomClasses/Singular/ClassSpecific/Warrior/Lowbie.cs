﻿#region Revision Info

// This file is part of Singular - A community driven Honorbuddy CC
// $Author: apoc $ nuok
// $Date: 2011-03-18 18:31:29 +0200 (Cum, 18 Mar 2011) $
// $HeadURL: http://svn.apocdev.com/singular/trunk/Singular/ClassSpecific/Warrior/Lowbie.cs $
// $LastChangedBy: apoc $
// $LastChangedDate: 2011-03-18 18:31:29 +0200 (Cum, 18 Mar 2011) $
// $LastChangedRevision: 189 $
// $Revision: 189 $

#endregion

using System.Linq;

using Styx.Combat.CombatRoutine;

using TreeSharp;
using Styx;
using Styx.Logic.Combat;

namespace Singular
{
    partial class SingularRoutine
    {
        [Class(WoWClass.Warrior)]
        [Spec(TalentSpec.Lowbie)]
        [Context(WoWContext.Normal)]
        [Behavior(BehaviorType.Combat)]
        public Composite CreateLowbieWarriorCombat()
        {
            return new PrioritySelector(
			CreateEnsureTarget(),
			CreateMoveToAndFace(4f, ret => Me.CurrentTarget),
			CreateAutoAttack(true),
				CreateSpellCast("Charge"),
				CreateSpellCast("Victory Rush"),
				CreateSpellCast("Strike")
                );
        }

		[Class(WoWClass.Warrior)]
		[Spec(TalentSpec.Lowbie)]
		[Context(WoWContext.Normal)]
		[Behavior(BehaviorType.Pull)]
		public Composite CreateLowbieWarriorPull()
		{
			return 
					new PrioritySelector(
					CreateEnsureTarget(),
					CreateMoveToAndFace(4f, ret => Me.CurrentTarget),
					CreateSpellCast("Charge"),
					CreateAutoAttack(true)
					);
		}

		[Class(WoWClass.Warrior)]
		[Spec(TalentSpec.Lowbie)]
		[Context(WoWContext.Normal)]
		[Behavior(BehaviorType.CombatBuffs)]
		public Composite CreateLowbieWarriorCombatBuffs()
		{
			return
				new PrioritySelector(
					CreateSpellBuffOnSelf("Berserker Rage",
							ret => Me.Auras.Any(
								aura => aura.Value.Spell.Mechanic == WoWSpellMechanic.Fleeing ||
										aura.Value.Spell.Mechanic == WoWSpellMechanic.Sapped ||
										aura.Value.Spell.Mechanic == WoWSpellMechanic.Incapacitated ||
										aura.Value.Spell.Mechanic == WoWSpellMechanic.Horrified)),
					CreateSpellBuffOnSelf("Battle Shout", ret => !Me.HasAura("Horn of the Winter") &&
																 !Me.HasAura("Roar of Courage") &&
																 !Me.HasAura("Strength of Earth Totem"))
				);
		}

		[Class(WoWClass.Warrior)]
		[Spec(TalentSpec.Lowbie)]
		[Context(WoWContext.Normal)]
		[Behavior(BehaviorType.PreCombatBuffs)]
		public Composite CreateLowbieWarriorPreCombatBuffs()
		{
			return
				new PrioritySelector(
					CreateSpellBuffOnSelf("Battle Stance")
				);
		}
    }
}