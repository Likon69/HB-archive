﻿#region Revision Info

// This file is part of Singular - A community driven Honorbuddy CC
// $Author: apoc $
// $Date: 2011-03-20 23:29:16 +0200 (Paz, 20 Mar 2011) $
// $HeadURL: http://svn.apocdev.com/singular/trunk/Singular/ClassSpecific/Priest/Shadow.cs $
// $LastChangedBy: apoc $
// $LastChangedDate: 2011-03-20 23:29:16 +0200 (Paz, 20 Mar 2011) $
// $LastChangedRevision: 197 $
// $Revision: 197 $

#endregion

using Styx.Combat.CombatRoutine;

using TreeSharp;

namespace Singular
{
    partial class SingularRoutine
    {
        [Class(WoWClass.Priest)]
        [Spec(TalentSpec.ShadowPriest)]
        [Behavior(BehaviorType.Combat)]
        [Behavior(BehaviorType.Pull)]
        [Context(WoWContext.All)]
        public Composite CreateShadowPriestCombat()
        {
            return new PrioritySelector(
                CreateEnsureTarget(),
                CreateMoveToAndFace(30, ret => Me.CurrentTarget),
                CreateWaitForCast(true),
                CreateDiscHealOnlyBehavior(true),
                CreateSpellBuff("Vampiric Touch", ret => !Me.IsMoving, true),
                CreateSpellBuff("Devouring Plague"),
                CreateSpellBuff("Shadow Word: Pain"),
                CreateSpellBuff("Archangel", ret => HasAuraStacks("Evangelism", 5) && Me.ManaPercent <= 75),
                CreateSpellCast("Shadow Word: Death", ret => Me.CurrentTarget.HealthPercent < 25),
                CreateSpellCast("Shadow Fiend", ret => Me.ManaPercent < 50),
                CreateSpellCast("Mind Blast", ret => Me.HasAura("Shadow Orb") && !Me.HasAura("Empowered Shadow")),
                CreateSpellCast("Mind Flay", ret => !Me.IsMoving)
                );
        }
    }
}