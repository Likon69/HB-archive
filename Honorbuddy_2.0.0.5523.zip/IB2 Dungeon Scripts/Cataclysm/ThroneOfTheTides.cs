﻿using System;
using System.Linq;
using Bots.Instancebuddy2.Attributes;
using Bots.Instancebuddy2.Helpers;
using Styx.Logic;
using Styx.Logic.Pathing;
using Styx.WoWInternals;
using TreeSharp;
using Styx;
using Styx.WoWInternals.WoWObjects;
using System.Collections.Generic;
using Action = TreeSharp.Action;

namespace Bots.Instancebuddy2.Dungeons.Cataclysm
{
    public class ThroneOfTheTides : Dungeon
    {
        #region Overrides of Dungeon

        /// <summary> The Map Id of this dungeon. This is the unique id for dungeons thats used to determine which dungeon, 
        /// the script belongs to </summary>
        /// <value>The map identifier.</value>
        public override uint MapId
        {
            get { return 643; }
        }

        public override WoWPoint Entrance
        {
            get { return new WoWPoint(-5580.163f, 5399.8f, -1797.933f); }
        }

        public override void IncludeTargetsFilter(List<WoWObject> incomingunits, HashSet<WoWObject> outgoingunits)
        {
            foreach (var unit in incomingunits)
            {
                if (unit.Entry == Sapper || unit.Entry == Ozumat)
                    outgoingunits.Add(unit);
            }
        }

        public override void RemoveTargetsFilter(List<WoWObject> units)
        {
            units.RemoveAll(o =>
                                {
                                    var unit = o as WoWUnit;

                                    if (unit == null)
                                        return true;

                                    // Faceless watcher casting Ground Pound. Melee should stay away
                                    if (unit.CastingSpellId == 76590 && unit.DistanceSqr < 10*10)
                                        return true;

                                    // For Lady Naz'jar encounter. Lady Naz'jar becomes immune while casting Waterspout(40586)
                                    if (unit.HasAura("Waterspout"))
                                        return true;

                                    // For Mindbender encounter. Mindbender becomes immune to magic and heals itself on damage. We should stop dpsing
                                    if (unit.HasAura("Absorb Magic"))
                                        return true;

                                    return false;
                                });
        }

        private const uint Sapper = 44752;
        private const uint Ozumat = 42172;
        public override void WeighTargetsFilter(List<Targeting.TargetPriority> units)
        {
            foreach (var t in units)
            {
                var prioObject = t.Object;

                //We should prio Faceless Sappers for Ozumat fight
                if (prioObject.Entry == Sapper)
                {
                    t.Score += 500;
                }
            }
        }

        #endregion

        #region Encounter Handlers

        /// <summary>
        /// Using 0 as BossEntry will make that composite the main logic for the dungeon and it will be called in every tick
        /// You can only have one main logic for a dungeon
        /// The context of the main composite is all units around as List<WoWUnit/>
        /// </summary>
        /// <returns></returns>
        [EncounterHandler(0)]
        public Composite RootLogic()
        {
            return
                new PrioritySelector(
                    ScriptHelpers.CreateTeleporterLogic(51391, 51395),
                    ScriptHelpers.CreateRunAwayFromUnit(40597, 40784, 41201),
                    ScriptHelpers.CreateRunAwayFromAura("Mind Fog"),
                    CreateElevatorLogic()
                    );
        }

        [EncounterHandler(40825, "Erunak Stonespeaker")]
        public Composite ErunakStonespeakerLogic()
        {
            const int earthShardsSpellId = 84931;
            return
                new PrioritySelector(
                    new Decorator(
                        ctx => ((WoWUnit)ctx).CastingSpellId == earthShardsSpellId && ((WoWUnit)ctx).CurrentTarget != null &&
                               (((WoWUnit)ctx).IsTargetingMeOrPet || ((WoWUnit)ctx).CurrentTarget.DistanceSqr < 6*6),
                        new Sequence(
                            new Action(ctx => Logger.Write("[Erunak Encounter] Avoiding Earth Shards")),
                            new Action(ctx => WoWMovement.Move(WoWMovement.MovementDirection.StrafeRight, TimeSpan.FromSeconds(2)))))

                    );
        }

        private Composite CreateElevatorLogic()
        {
            return
                new PrioritySelector(
                        ctx =>
                        {
                            var tankInfo =
                                    StyxWoW.Me.PartyMemberInfos.FirstOrDefault(
                                        p => p.HasRole(WoWPartyMember.GroupRole.Tank)) ??
                                    StyxWoW.Me.PartyMemberInfos.OrderBy(p => p.HealthMax).FirstOrDefault();

                            if (tankInfo == null)
                                return null;

                            var tank = tankInfo.ToPlayer();

                            if (tank == null)
                                return null;

                            return tank;
                        },
                    new Decorator(
                        ctx => ctx != null && ((WoWPlayer)ctx).IsOnTransport && !StyxWoW.Me.IsOnTransport,
                        new Sequence(
                            new Action(ctx => Logger.Write("[Dungeon General] Getting on the elevator")),
                            new Action(ctx => Navigator.PlayerMover.MoveTowards(((WoWPlayer)ctx).Location)))
                    ));
        }

        #endregion
    }
}
