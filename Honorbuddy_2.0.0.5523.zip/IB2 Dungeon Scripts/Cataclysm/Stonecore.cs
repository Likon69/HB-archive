﻿using System;
using System.Linq;
using Bots.Instancebuddy2.Attributes;
using Bots.Instancebuddy2.Helpers;
using CommonBehaviors.Actions;
using Styx.Helpers;
using Styx.Logic;
using Styx.Logic.Pathing;
using Styx.WoWInternals;
using TreeSharp;
using Styx;
using Styx.WoWInternals.WoWObjects;
using System.Collections.Generic;
using Action = TreeSharp.Action;

namespace Bots.Instancebuddy2.Dungeons.Cataclysm
{
    public class Stonecore : Dungeon
    {
        #region Overrides of Dungeon

        /// <summary> The Map Id of this dungeon. This is the unique id for dungeons thats used to determine which dungeon, 
        /// the script belongs to </summary>
        /// <value>The map identifier.</value>
        public override uint MapId
        {
            get { return 725; }
        }

        public override WoWPoint Entrance
        {
            get
            {
                return new WoWPoint(1032.611f, 607.3205f, 160.9259f);
            }
        }

        public override bool IsFlyingCorpseRun { get { return true; } }

        /// <summary>
        /// IncludeTargetsFilter is used to add units to the targeting list. If you want to include a mob thats usually removed by the default
        /// filters, you shall use that.
        /// </summary>
        /// <param name="incomingunits">Units passed into the method</param>
        /// <param name="outgoingunits">Units passed to the targeting class</param>
        public override void IncludeTargetsFilter(List<WoWObject> incomingunits, HashSet<WoWObject> outgoingunits)
        {
            foreach (WoWObject obj in incomingunits)
            {

            }
        }

        /// <summary>
        /// RemoveTargetsFilter is used to remove units thats not wanted in target list. Like immune mobs etc.
        /// </summary>
        /// <param name="units"></param>
        public override void RemoveTargetsFilter(List<WoWObject> units)
        {
            units.RemoveAll(o =>
                    {
                        var unit = o as WoWUnit;

                        if (unit == null)
                            return false;

                        // For Ozruk fight. Ranged dps should stop dpsing if the boss has spell reflect buff
                        if (unit.HasAura("Elementium Bulwark") && unit.DistanceSqr > 8 * 8)
                            return true;

                        // For Priestess fight. It becomes immune with this shield on
                        if (unit.HasAura("Energy Shield"))
                            return true;

                        return false;
                    });
        }

        /// <summary>
        /// WeighTargetsFilter is used to weight units in the targeting list. If you want to give priority to a certain npc, you should
        /// use this method. 
        /// </summary>
        /// <param name="units"></param>
        public override void WeighTargetsFilter(List<Targeting.TargetPriority> units)
        {
            foreach (var t in units)
            {
                var prioObject = t.Object;

            }
        }

        #endregion

        #region Encounter Handlers
        
        /// <summary>
        /// Using 0 as BossEntry will make that composite the main logic for the dungeon and it will be called in every tick
        /// You can only have one main logic for a dungeon
        /// The context of the main composite is all units around as List<WoWUnit/>
        /// </summary>
        /// <returns></returns>
        [EncounterHandler(0)]
        public Composite RootLogic()
        {
            return
                new PrioritySelector(
                    ScriptHelpers.CreateTeleporterLogic(51396),
                    // Crystal Barrage -> Corborus fight, red things.
                    ScriptHelpers.CreateRunAwayFromAura("Crystal Barrage"),
                    // 42499 -> Gravity Wells in Priestess fight
                    // 43242 -> Lava Fissures in Slabhide fight
                    ScriptHelpers.CreateRunAwayFromUnit(42499, 43242)
                    );
        }

        /// <summary>
        /// BossEntry is the Entry of the boss unit. (WoWUnit.Entry)
        /// BossName is optional. Its there just to make it easier to find which boss that composite belongs to.
        /// The context of the encounter composites is the Boss as WoWUnit
        /// </summary>
        /// <returns></returns>
        [EncounterHandler(43438, "Corborus")]
        public Composite CorborusFight()
        {
            const int barrage = 86881;
            return
                new PrioritySelector(
                    new Decorator(
                // If Ozruk is casting the shatter spell get the hell outta there!
                        ctx => ((WoWUnit)ctx).CastingSpellId == barrage && ((WoWUnit)ctx).CurrentTarget != null &&
                               (((WoWUnit)ctx).IsTargetingMeOrPet || ((WoWUnit)ctx).CurrentTarget.DistanceSqr < 6 *6),
                        new Action(ctx =>
                            {
                                Logger.Write("[Corborus Encounter] Moving away from Crystal Barrage");

                                // Get the party member that has the most range from the boss to avoid aoe damage
                                var player = StyxWoW.Me.PartyMembers.
                                                    OrderByDescending(p =>
                                                        p.Location.DistanceSqr(((WoWUnit)ctx).Location)).
                                                    FirstOrDefault();

                                return Navigator.GetRunStatusFromMoveResult(Navigator.MoveTo(player.Location));
                            })
                        ));
        }

        [EncounterHandler(43214, "Slabhide")]
        public Composite SlabhideFight()
        {
            return
                new PrioritySelector();
        }

        [EncounterHandler(42188, "Ozruk")]
        public Composite OzrukFight()
        {
            const int shatter = 92662;
            return
                new PrioritySelector(
                    new Decorator(
                        // If Ozruk is casting the shatter spell get the hell outta there!
                        ctx => ((WoWUnit)ctx).CastingSpellId == shatter,
                        new Action(ctx =>
                                       {
                                           Logger.Write("[Ozruk Encounter] Moving away from Shatter");

                                           // Get the party member that has the most range from the boss to avoid aoe damage
                                           var player = StyxWoW.Me.PartyMembers.
                                                            OrderByDescending(p => 
                                                                p.Location.DistanceSqr(((WoWUnit)ctx).Location)).
                                                            FirstOrDefault();

                                           return Navigator.GetRunStatusFromMoveResult(Navigator.MoveTo(player.Location));
                                       })
                            ));
        }

        [EncounterHandler(42333, "High Priestess Azil")]
        public Composite HighPriestessAzilFight()
        {
            return
                new PrioritySelector();
        }

        

        #endregion
    }
}
