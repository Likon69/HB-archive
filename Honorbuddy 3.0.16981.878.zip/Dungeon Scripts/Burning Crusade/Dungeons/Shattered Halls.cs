using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Threading.Tasks;

using Styx;
using Styx.CommonBot;
using Styx.Pathing;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using Styx.TreeSharp;
using Bots.DungeonBuddy.Attributes;
using Bots.DungeonBuddy.Helpers;
using Styx.Common;
using Styx.CommonBot.Coroutines;
using Action = Styx.TreeSharp.Action;

namespace Bots.DungeonBuddy.Dungeon_Scripts.Burning_Crusade
{
    public class ShatteredHalls : Dungeon
    {
        #region Overrides of Dungeon

        public override uint DungeonId => 138;

        public override Vector3 Entrance => new Vector3(-310.2105f, 3087.014f, -3.916756f);

        public override Vector3 ExitLocation => new Vector3(-42.05605f, -26.77249f, -13.51534f);

        public override void RemoveTargetsFilter(List<WoWObject> units)
        {
            const uint shatteredHandCenturion = 17465;
            const uint shatteredHandGladiator = 17464;

            units.RemoveAll(
                u =>
                { // remove low level units.
                    var unit = u as WoWUnit;
                    if (unit != null)
                    {
                        if (unit is WoWPlayer)
                            return true;

                        uint entry = unit.Entry;
                        if ((entry == 17356 || entry == 17357) && !unit.Combat) // Creeping Ozzling
                            return true;

                        if (StyxWoW.Me.IsTank() && ScriptHelpers.IsBossAlive("Warchief Kargath Bladefist") &&
                            (entry == 17621 || entry == 17623 || entry == 17622))
                            // Heathen Guard, Reaver Guard, Sharpshooter Guard
                            return true;

                        // Ignore the gladiators unless we aggro them.
                        if (!unit.Aggro && (entry == shatteredHandGladiator || entry == shatteredHandCenturion))
                            return true;
                    }
                    return false;
                });
        }

        public override void WeighTargetsFilter(List<Targeting.TargetPriority> units)
        {
            foreach (var priority in units)
            {
                var unit = priority.Object as WoWUnit;
                if (unit != null)
                {
                    if (StyxWoW.Me.IsDps)
                    {
                        if (unit.Entry == 17621 || unit.Entry == 17623 || unit.Entry == 17622) // Heathen Guard, Reaver Guard, Sharpshooter Guard
                            priority.Score += 400;
                    }
                }
            }
        }

        public override async Task<bool> HandleMovement(MoveToParameters moveToParameters)
        {
            Vector3 lineStart = new Vector3(136.0583f, 272.7958f, -12.82495f);
            Vector3 lineEnd = new Vector3(135.073f, 257.6188f, -13.22214f);
            Vector3 centerNethekurseRoom = new Vector3(180.4858f, 265.101f, -13.13508f);

            var myLoc = Me.Location;
            // Use the door to Nethekurse's room if it's open.
            if (moveToParameters.Location.IsPointLeftOfLine(lineStart, lineEnd) 
                && (!myLoc.IsPointLeftOfLine(lineStart, lineEnd) || myLoc.GetNearestPointOnSegment(lineStart, lineEnd).DistanceSquared(myLoc) < 15 * 15))
            {
                const uint grandWarlockChamperDoorSouth = 182539;
                WoWGameObject door = ObjectManager.GetObjectsOfType<WoWGameObject>().FirstOrDefault(go => go.Entry == grandWarlockChamperDoorSouth);

                if (door != null && door.Distance < 40 && !door.Locked)
                {
                    WoWMovement.ClickToMove(centerNethekurseRoom);
                    return true;
                }
            }

            return false;
        }

        #endregion

        protected LocalPlayer Me => StyxWoW.Me;

        [EncounterHandler(0, "Root")]
        public Composite RootBehavior()
        {
            const uint blazeId = 181915;
            AddAvoidObject(() => !Me.IsCasting && !Me.IsHealer, 5, blazeId);

            return new PrioritySelector();
        }

        [EncounterHandler(16808, "Warchief Kargath Bladefist")]
        public Func<WoWUnit, Task<bool>> WarchiefKargathBladefistEncounter()
        {
            WoWUnit warchiefKargathBladefist = null;
            var platformCenterLocation = new Vector3(231.25f, -83.64489f, 4.940088f);

            AddAvoidObject<WoWPlayer>(
                () => Me.IsRanged &&  ScriptHelpers.IsViable(warchiefKargathBladefist) && Me.CurrentTargetGuid == warchiefKargathBladefist.Guid, 
                15, p => !p.IsMe && p.IsAlive);

            return async boss =>
            {
                warchiefKargathBladefist = boss;
                return await ScriptHelpers.TankUnitAtLocation(platformCenterLocation, 5);
            };
        }

        #region Grand Warlock Nethekurse

        private const uint GrandWarlockNethekurseId = 16807;

        [EncounterHandler(17356, "Creeping Ozze")]
        [EncounterHandler(17357, "Creeping Ozzling")]
        public Composite CreepingOzzlingEncounter()
        {
            var tankLoc = new Vector3(180.5946f, 227.8267f, -18.55346f);
            return
                new PrioritySelector(
                    new Decorator(
                        ctx =>
                        StyxWoW.Me.IsTank() && Me.PartyMembers.All(p => p.HealthPercent > 50) && !StyxWoW.Me.IsActuallyInCombat &&
                        StyxWoW.Me.Location.DistanceSquared(tankLoc) > 5,
                        new Action(ctx => Navigator.MoveTo(tankLoc))));
        }

        [ObjectHandler(182539, "Grand Warlock Chamber Door")]
        public Composite GrandWarlockChamberDoorHandler()
        {
            var roomBeforeFirstBossLoc = new Vector3(123.3501f, 264.7724f, -13.23036f);
            var dropDownLoc = new Vector3(121.9095f, 236.8019f, -46.10165f);
            var topOfJumpLoc = new Vector3(123.0873f, 250.3539f, -15.3936f);
            return
                new PrioritySelector(
                    new Decorator(
                        ctx =>
                        ((WoWGameObject)ctx).State == WoWGameObjectState.Ready && !StyxWoW.Me.Combat && StyxWoW.Me.Location.DistanceSquared(roomBeforeFirstBossLoc) <= 20 * 20 &&
                        StyxWoW.Me.Z > -25,
                        new PrioritySelector(
                            new Decorator(
                                ctx => StyxWoW.Me.IsTank() || (StyxWoW.Me.IsFollower() && ScriptHelpers.Tank != null && ScriptHelpers.Tank.Z < -25),
                                new PrioritySelector(
                                    new Decorator(ctx => StyxWoW.Me.Location.DistanceSquared(topOfJumpLoc) > 4 * 4, new Action(ctx => Navigator.MoveTo(topOfJumpLoc))),
                                    new Action(ctx => WoWMovement.ClickToMove(dropDownLoc)))))));
        }

        private const uint MobId_GrandWarlockNethekurse = 16807;

        [EncounterHandler(16807, "Grand Warlock Nethekurse")]
        public Composite GrandWarlockNethekurseEncounter()
        {
            WoWUnit boss = null;
            const uint lesserShadowFissureId = 17471;
            AddAvoidObject(() => !Me.IsCasting, 8, lesserShadowFissureId);
            AddAvoidUnitCone(() => !Me.IsTank(), 0, 8, 180, u => u.Entry == MobId_GrandWarlockNethekurse && !u.IsMoving && u.CurrentTarget != Me && u.Combat);

            return new PrioritySelector(
                ctx => boss = ctx as WoWUnit,
                ScriptHelpers.CreateTankFaceAwayGroupUnit(8));
        }

        #endregion
    }

    public class ShatteredHallsHeroic : ShatteredHallsTimewalking
    {
        public override uint DungeonId => 189;
    }

    public class ShatteredHallsTimewalking : ShatteredHalls
    {
        public override uint DungeonId => 1014;

        #region Trash/Safe pulls

        [LocationHandler(69.63805f, 48.94012f, -13.22182f, 30, "Halls of the Fathers Trash Handler 1")]
        public Func<Vector3, Task<bool>> HallsTrashHandler1()
        {
            return async loc =>
            {
                var trashPackCenter = new Vector3(69.25011f, 74.25182f, -13.22294f);

                var lineStart = new Vector3(64.6487f, 40.6663f, -13.22182f);
                var lineEnd = new Vector3(75.00951f, 41.31402f, -13.22183f);

                var pullPosition = new Vector3(70.09802f, 38.89187f, -13.22098f);

                return await HandleTrashPulling(pullPosition, trashPackCenter, lineStart, lineEnd);
            };
        }

        [LocationHandler(69.81902f, 227.0762f, -13.20553f, 30, "Halls of the Fathers Trash Handler 2")]
        public Func<Vector3, Task<bool>> HallsTrashHandler2()
        {
            return async loc =>
            {
                var trashPackCenter = new Vector3(69.09614f, 264.2446f, -13.19972f);

                var lineStart = new Vector3(64.55281f, 235.464f, -13.19364f);
                var lineEnd = new Vector3(75.13428f, 235.9928f, -13.19364f);

                var pullPosition = new Vector3(69.81902f, 227.0762f, -13.20553f);
                

                return await HandleTrashPulling(pullPosition, trashPackCenter, lineStart, lineEnd);
            };
        }


        private async Task<bool> HandleTrashPulling(Vector3 pullPosition, Vector3 trashPackCenter, Vector3 lineStart, Vector3 lineEnd, float radius = 50, int pullWaitTime = 6000)
        {
            List<WoWUnit> trashMobs = ScriptHelpers.GetUnfriendlyNpsAtLocation(trashPackCenter, radius);
            if (trashMobs.Count <= 4)
                return false;

            var trash = trashMobs.FirstOrDefault();
            if (trash == null)
                return false;

            bool meIsLeftOfLine = Me.Location.IsPointLeftOfLine(lineStart, lineEnd);

            WoWUnit manaUser = Targeting.Instance.TargetList.FirstOrDefault(u => u.PowerType == WoWPowerType.Mana);
            // Ignore if there's spellcasters in the targeting list.
            if (!Me.IsTank() && meIsLeftOfLine && manaUser == null)
            {
                await CommonCoroutines.MoveTo(pullPosition);
                return true;
            }

            return await ScriptHelpers.PullNpcToLocation(() => ScriptHelpers.IsViable(trash), trash, pullPosition, pullWaitTime);
        }

        #endregion
    }
}