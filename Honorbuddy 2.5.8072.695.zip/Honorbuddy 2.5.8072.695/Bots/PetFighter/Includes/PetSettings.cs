﻿using System.IO;
using System.Windows.Forms;
using Styx;
using Styx.Helpers;

namespace PetFighter
{
    public class PetRoutinesSettings : Settings
    {
        public static PetRoutinesSettings Instance = new PetRoutinesSettings();

        public PetRoutinesSettings()
            : base(Application.StartupPath + "\\Routines\\PetFighter\\Ability_" + PetSettingsHelper.Ability + "_" + PetSettingsHelper.PetID + ".xml")
        {
            Load();
        }

        ~PetRoutinesSettings()
        {
            Save();
        }

        [Setting(Explanation = "Keep Ability on CoolDown?"), DefaultValue(false)]
        public bool KeepOnCD { get; set; }

        [Setting(Explanation = "give Ability Health?"), DefaultValue(false)]
        public bool IsHealAbility { get; set; }

        [Setting(Explanation = "Bot need Health at (X%)"), DefaultValue(50)]
        public int NeedHealPercent { get; set; }

        [Setting(Explanation = "is this Ability the standart Ability"), DefaultValue(false)]
        public bool StandartAbility { get; set; }

        [Setting(Explanation = "use if meHealth < enemyHealth"), DefaultValue(false)]
        public bool LowHealthAbility { get; set; }
    }

    public class PetSettingsHelper
    {
        public static string Ability { get; set; }
        public static string PetID { get; set; }

        public static bool CanLoadPetSettings(string _ability, string _petID)
        {
            Ability = _ability;
            PetID = _petID;
            
            return true;
        }
    }
}
