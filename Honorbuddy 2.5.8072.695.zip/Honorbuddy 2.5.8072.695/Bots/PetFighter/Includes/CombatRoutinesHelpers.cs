﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PetFighter
{
    class CombatRoutineHelpers
    {
        public static int Round = 1;
        public static int Battle_WON = 0;
        public static int Battle_lost = 0;
        public static bool NewRound = false;
        public static List<string> FightLog = new List<string>();
        private static List<string> SelectedActionList = new List<string>();




        public static bool KeepOnCD //TODO autoRoutine - bool keepOnCD
        { get { return false; } }

        public static void CreateKeepOnCD() //TODO autoRoutine void CreateKeepOnCD
        { }

        public static void flog(bool newBattle, string text) //TODO flog()
        { }

        public static void CreateSelectedAction(List<string> SelectedAction) //TODO CreateSelectedAction
        {
            if (SelectedAction == null)
            {
                PetFighter.Instance.dlog("[Create Selected Action] actions = null");

                if (!PetBattle.IsWildBattle)
                { PetFighter.Instance.dlog("[CreateSelectedAction]", "SelectedAction == null && !IsWildBattle"); return; }

                Round = 1;
                return;
            }

            PetFighter.Instance.dlog("[Create Selected Action] actions = {0}/{1}", SelectedAction[0], SelectedAction[1]);
            Round++;
            SelectedActionList.Add(SelectedAction[1]);
        }

        public static List<string> GetAbilityInfoBySlotID_Me(int slotID)
        {
            List<string> _ability = new List<string>(); 
            _ability.Add(PetBattle.GetPetInfoBySlot(slotID)[1]);
            _ability.Add(PetBattle.GetPetInfoBySlot(slotID)[2]);
            _ability.Add(PetBattle.GetPetInfoBySlot(slotID)[3]);
            return _ability;
        }

        private static string lastHealAbility = "noLastHeal";
        public static bool needHeal
        {
            get
            {
                if (!GetAbilityInfoBySlotID_Me(PetBattle.GetActivePetID_Me).Contains(lastHealAbility))
                {
                    foreach (string _ability in GetAbilityInfoBySlotID_Me(PetBattle.GetActivePetID_Me))
                    {
                        if (PetSettingsHelper.CanLoadPetSettings(_ability, PetBattle.GetPetInfoBySlot(PetBattle.GetActivePetID_Me)[0]) &&
                            PetRoutinesSettings.Instance.IsHealAbility)
                        { lastHealAbility = _ability; break; } 
                    }
                }

                //TODO autoBattle needHeal
                //if (GetAbilityInfoBySlotID_Me(PetBattle.GetActivePetID_Me).Contains(lastHealAbility) &&
                //    PetSettingsHelper.CanLoadPetSettings(lastHealAbility, PetBattle.GetPetInfoBySlot(PetBattle.GetActivePetID_Me)[0]) &&
                //    PetBattle.GetHealthPercentBySlotID_Me(PetBattle.GetActivePetID_Me) <= PetRoutinesSettings.Instance.NeedHealPercent)
                //    return true;

                return false;
            }
        }

        public static void useHealAbility()
        { PetBattle.UseAbilityByKeyNum(GetAbilityInfoBySlotID_Me(PetBattle.GetActivePetID_Me).IndexOf(lastHealAbility) + 1); }
        
    }
}
