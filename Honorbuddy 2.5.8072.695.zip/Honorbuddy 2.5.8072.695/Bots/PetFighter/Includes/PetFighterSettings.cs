﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Styx.Helpers;
using System.Windows.Forms;


namespace PetFighter
{
    class PetFighterSettings : Settings
    {
        public static PetFighterSettings Instance = new PetFighterSettings();

        public PetFighterSettings()
            : base(Application.StartupPath + "\\Settings\\" + Styx.StyxWoW.Me.RealmName + "\\PetFighter\\PetFighter_GlobalSettings.xml")
        {
            Load();
        }

        ~PetFighterSettings()
        {
            Save();
        }

        [Setting(Explanation = "first start?"), DefaultValue(true)]
        public bool FirstStart { get; set; }

        [Setting(Explanation = "use debunging"), DefaultValue(false)]
        public bool UseDebug { get; set; }

        [Setting(Explanation = "use NotifyIcon"), DefaultValue(false)]
        public bool useNotifyIcon { get; set; }

        [Setting(Explanation = "use manual Routine"), DefaultValue(true)]
        public bool UseManualRoutines { get; set; }

        [Setting(Explanation = "manual Routine"), DefaultValue(null)]
        public string[] ManualRoutine { get; set; }

        [Setting(Explanation = "wait Xsec then do action"), DefaultValue(3)]
        public int WaitTime { get; set; }

        [Setting(Explanation = "trap all Pets?"), DefaultValue(false)]
        public bool TrapAll { get; set; }

        [Setting(Explanation = "trap if need"), DefaultValue(true)]
        public bool TrapIfNeed { get; set; }

        [Setting(Explanation = "check for updates"), DefaultValue(true)]
        public bool CeckForUpdates { get; set; }

        [Setting(Explanation = "new updates"), DefaultValue(true)]
        public bool NewUpdates { get; set; }

        [Setting(Explanation = "last DateTime for Updates check"), DefaultValue(null)]
        public DateTime CeckForUpdatesDateTime { get; set; }

        [Setting(Explanation = "start Pet slotID"), DefaultValue(1)]
        public int StartPetSlotID { get; set; }

        [Setting(Explanation = "trap all Pets?"), DefaultValue(true)]
        public bool PetBattle_Wild { get; set; }

        [Setting(Explanation = "trap all Pets?"), DefaultValue(false)]
        public bool PetBattle_PvP { get; set; }
    }
}
