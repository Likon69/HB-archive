﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Styx.CommonBot.Profiles;
using Styx.CommonBot.AreaManagement;
using Styx;
using Styx.TreeSharp;
using Action = Styx.TreeSharp.Action;
using Styx.CommonBot;
using CommonBehaviors.Actions;
using Styx.Pathing;

namespace PetFighter
{
    class ProfileHelper
    {
        private static PetFighter _PetFighter = PetFighter.Instance;

        public static void Initialize()
        {
            PetFighter.Instance.dlog("Loading Profile ..");
            _CurrentProfile.GrindArea.CycleToNearest();
        }
        private static Profile _CurrentProfile { get { return ProfileManager.CurrentProfile; } }
        private static Hotspot _CurrentHotSpot { get { return ProfileManager.CurrentProfile.GrindArea.CurrentHotSpot; } }

        public static Composite CreatePathBehavior()
        {
            return new Sequence(
                    new Action(ret => _PetFighter.dlog("[PathBehavior] create patch")),
                    new PrioritySelector(

                        PetFighter.Instance.CreateMountUpBehavior,

                        new Decorator(ret => _CurrentProfile.HotspotManager.Hotspots.Count == 0,
                            new Sequence(
                                new Action(ret => _PetFighter.slog("[ERROR] Profile has no hotspots!")),
                                new Action(ret => TreeRoot.Stop("[ERROR] Profile has no hotspots!")))),

                        new Decorator(ret => _CurrentHotSpot == null,
                            new Sequence(
                                new Action(ret => _PetFighter.dlog("[PatchBehavior] HotSpot = null")),
                                new Action(ret => _CurrentProfile.GrindArea.CycleToNearest())
                                //new Action(ret => search = false)
                                //new Wait(3, ret => _CurrentProfile.GrindArea.CurrentHotSpot == null, new Action(ret => { }))
                                )),

                        new Decorator(ret => StyxWoW.Me.Location.Distance(_CurrentHotSpot.Position) <= 50 && !Flightor.IsGeneratingPath,
                            new Sequence(
                                new Action(ret => _PetFighter.dlog("[PathBehavior] looking for new HotSpot ..")),
                                new Action(ret => _CurrentProfile.GrindArea.GetNextHotspot()),
                                //new Action(ret => search = false),
                                new Wait(2, ret => StyxWoW.Me.Location.Distance(_CurrentHotSpot.Position) <= 50, new ActionIdle())
                                )),

                            new Decorator(ret => _CurrentHotSpot != null,
                        new Sequence(
                            new ActionSetActivity("[PetFighter] Moving to next Hotspot .."),
                            new Action(ret => _PetFighter.dlog("[Navigation] Moving to Hotspot: {0} (Distance: {1})", _CurrentHotSpot.Position, _CurrentHotSpot.Position.Distance(StyxWoW.Me.Location))),
                            new Action(ret => Flightor.MoveTo(_CurrentHotSpot.Position))
                            //new Wait(2, ret => Flightor.IsGeneratingPath, new ActionIdle())
                            //new Decorator(ret => StyxWoW.Me.Location.Distance(_CurrentProfile.GrindArea.CurrentHotSpot.Position) <= 50,
                            //    new Action(ret => search = true))
                                //new Sequence(
                                //    new Action(ret => _PetFighter.dlog("[PathBehavior] looking for new HotSpot ..")),
                            //        new Action(ret => _CurrentProfile.GrindArea.GetNextHotspot())
                            //            ))
                            ))

                            ));
            
        }



    }
}
