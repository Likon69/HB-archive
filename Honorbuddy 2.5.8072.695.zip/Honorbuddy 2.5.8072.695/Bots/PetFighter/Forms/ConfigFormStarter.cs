﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace PetFighter
{
    public partial class ConfigFormStarter : Form
    {
        public ConfigFormStarter()
        {
            var _Form = new PetFighterConfigForm();
            _Form.Show();
            this.Dispose();
            //InitializeComponent();
        }
    }
}
