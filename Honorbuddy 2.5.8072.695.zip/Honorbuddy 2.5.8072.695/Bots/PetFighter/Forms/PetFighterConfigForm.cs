﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Threading;

namespace PetFighter
{
    public partial class PetFighterConfigForm : Form
    {
        private static Thread newUpdateStatesThread = new Thread(UpdateStates) { IsBackground = true, Priority = ThreadPriority.Highest };
        
        private static PetFighterConfigForm _Form;
        private int _sizeChanger = 245;

        public PetFighterConfigForm()
        {
            InitializeComponent();
            _Form = this;
        }

        private void PetFighterConfigForm_Load(object sender, EventArgs e)
        {
            _Form = this;
            if (PetFighterSettings.Instance.FirstStart)
                PetFighter.Instance.FirstStart();
            pb_Logo.Image = Image.FromFile(Application.StartupPath + "\\Bots\\PetFighter\\Forms\\Images\\header.jpg");
            btn_ReviveBattlePets.Image = Image.FromFile(Application.StartupPath + "\\Bots\\PetFighter\\Forms\\Images\\PF_logo.jpg");
            Icon = PetFighter.Instance.convertToIcon(Image.FromFile(Application.StartupPath + "\\Bots\\PetFighter\\BarryDurex"), Color.Empty);
            //btn_FightInfoForm.BackgroundImage = pb_Logo.Image;
            lb_versionText.Text = "v. " + PetFighter.Instance._Version.ToString() + " Alpha";

            chb_UpdatesCheck.Checked = PetFighterSettings.Instance.CeckForUpdates;
            chb_debug.Checked = PetFighterSettings.Instance.UseDebug;
            chb_Trap_All.Checked = PetFighterSettings.Instance.TrapAll;
            chb_Trap_inNeed.Checked = PetFighterSettings.Instance.TrapIfNeed;
            rb_Routine_Manual.Checked = PetFighterSettings.Instance.UseManualRoutines;
            chb_NotifyIcon.Checked = PetFighterSettings.Instance.useNotifyIcon;
            nud_waitTime.Value = PetFighterSettings.Instance.WaitTime;
            chb_useBattle_PvP.Checked = PetFighterSettings.Instance.PetBattle_PvP;
            chb_useBattle_Wild.Checked = PetFighterSettings.Instance.PetBattle_Wild;

            deselectPets();

            PetFighter.Instance.ReviveBattlePets = Styx.WoWInternals.WoWSpell.FromId(125439);
            if (!PetFighter.Instance.ReviveBattlePets.Cooldown)
                btn_ReviveBattlePets.Enabled = true;
            else
                btn_ReviveBattlePets.Enabled = false;

            if (PetFighterSettings.Instance.ManualRoutine != null && PetFighterSettings.Instance.ManualRoutine.ToList<string>().Count >= 1)
            {
                string text = string.Empty;
                foreach (string str in PetFighterSettings.Instance.ManualRoutine)
                {
                    if (text == string.Empty)
                    { text = str; continue; }
                    text = text + "-" + str;
                }
                tb_ManualRoutine.Text = text;
            }

            timer_Updater.Start();
        }

        private void btn_UpdateNow_Click(object sender, EventArgs e)
        {
            PetFighterSettings.Instance.NewUpdates = false;
            System.Diagnostics.Process.Start(PetFighter.Instance.ForumLink);
            btn_UpdateNow.Visible = false;
        }

        private void pb_Logo_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start(PetFighter.Instance.ForumLink);
        }

        private void btn_ReviveBattlePets_Click(object sender, EventArgs e)
        {
            //spell=125439/Revive Battle Pets/Haustiere beleben
            if (!PetFighter.Instance.ReviveBattlePets.Cooldown && PetFighter.Instance.ReviveBattlePets.CanCast)
            {
                PetFighter.Instance.ReviveBattlePets.Cast();
                btn_ReviveBattlePets.Enabled = false;
            }
        }

        private void PetFighterConfigForm_FormClosed(object sender, FormClosedEventArgs e)
        {
        }

        private void timer_ReviveBattlePets_Tick(object sender, EventArgs e)
        {
            if (!newUpdateStatesThread.IsAlive)
            { newUpdateStatesThread = new Thread(UpdateStates) { IsBackground = true, Priority = ThreadPriority.Highest }; newUpdateStatesThread.Start(); }

        }

        private static void UpdateStates()
        {
            try
            {
                PetFighter.Instance.dlog("[UpdateSates] start updates ..");
                if (PetFighterSettings.Instance.UseDebug && !PetFighterConfigForm._Form.prob_Update.Visible)
                    PetFighterConfigForm._Form.prob_Update.Visible = true;
                PetFighterConfigForm._Form.prob_Update.Value = 0;

                PetFighterConfigForm._Form.prob_Update.PerformStep(); //ProsessBar Update
                if (PetFighter.Instance.ReviveBattlePets != null && PetFighter.Instance.ReviveBattlePets.Cooldown)
                    PetFighterConfigForm._Form.btn_ReviveBattlePets.Enabled = false;
                else
                    PetFighterConfigForm._Form.btn_ReviveBattlePets.Enabled = true;

                if (PetBattle.IsInPetBattle)
                {
                    PetFighterConfigForm._Form.prob_Update.PerformStep(); //ProsessBar Update
                    PetFighterConfigForm._Form.prob_Health_Pet1.Maximum = PetBattle.GetMaxHealthBySlotID_Me(1);
                    PetFighterConfigForm._Form.prob_Health_Pet2.Maximum = PetBattle.GetMaxHealthBySlotID_Me(2);
                    PetFighterConfigForm._Form.prob_Health_Pet3.Maximum = PetBattle.GetMaxHealthBySlotID_Me(3);
                    PetFighterConfigForm._Form.prob_Health_Pet1.Value = PetBattle.GetHealthBySlotID_Me(1);
                    PetFighterConfigForm._Form.prob_Health_Pet2.Value = PetBattle.GetHealthBySlotID_Me(2);
                    PetFighterConfigForm._Form.prob_Health_Pet3.Value = PetBattle.GetHealthBySlotID_Me(3);

                    PetFighterConfigForm._Form.prob_Update.PerformStep(); //ProsessBar Update
                    PetFighterConfigForm._Form.lb_Pet_HP1.Text = string.Format("HP: {0} / {1}", PetBattle.GetHealthBySlotID_Me(1), PetBattle.GetMaxHealthBySlotID_Me(1));
                    PetFighterConfigForm._Form.lb_Pet_HP2.Text = string.Format("HP: {0} / {1}", PetBattle.GetHealthBySlotID_Me(2), PetBattle.GetMaxHealthBySlotID_Me(2));
                    PetFighterConfigForm._Form.lb_Pet_HP3.Text = string.Format("HP: {0} / {1}", PetBattle.GetHealthBySlotID_Me(3), PetBattle.GetMaxHealthBySlotID_Me(3));

                }
                else
                {
                    PetFighterConfigForm._Form.prob_Update.PerformStep(); //ProsessBar Update
                    PetFighterConfigForm._Form.prob_Health_Pet1.Maximum = (PetFighterConfigForm._Form.prob_Update.Maximum * 2);
                    PetFighterConfigForm._Form.prob_Health_Pet2.Maximum = (PetFighterConfigForm._Form.prob_Update.Maximum * 2);
                    PetFighterConfigForm._Form.prob_Health_Pet3.Maximum = (PetFighterConfigForm._Form.prob_Update.Maximum * 2);
                    if (PetFighterConfigForm._Form.prob_Health_Pet1.Value >= PetFighterConfigForm._Form.prob_Health_Pet1.Maximum)
                    {
                        PetFighterConfigForm._Form.prob_Health_Pet1.Value = 0;
                        PetFighterConfigForm._Form.prob_Health_Pet2.Value = 0;
                        PetFighterConfigForm._Form.prob_Health_Pet3.Value = 0;
                    }

                    PetFighterConfigForm._Form.prob_Health_Pet1.PerformStep();
                    PetFighterConfigForm._Form.prob_Health_Pet2.PerformStep();
                    PetFighterConfigForm._Form.prob_Health_Pet3.PerformStep();

                    PetFighterConfigForm._Form.prob_Update.PerformStep(); //ProsessBar Update
                    PetFighterConfigForm._Form.lb_Pet_HP1.Text = "HP can't load..";
                    PetFighterConfigForm._Form.lb_Pet_HP2.Text = "not in Battle ..";
                    PetFighterConfigForm._Form.lb_Pet_HP3.Text = "HP can't load..";
                }

                //lb_Pet_Name1.Text = PetBattle.GetPetInfoByPetID(Convert.ToInt32(PetBattle.GetPetInfoBySlot(1)[0]))[1];
                //lb_Pet_Name2.Text = PetBattle.GetPetInfoByPetID(Convert.ToInt32(PetBattle.GetPetInfoBySlot(2)[0]))[1];
                //lb_Pet_Name3.Text = PetBattle.GetPetInfoByPetID(Convert.ToInt32(PetBattle.GetPetInfoBySlot(3)[0]))[1];

                PetFighterConfigForm._Form.prob_Update.PerformStep(); //ProsessBar Update
                if (PetBattle.GetPetInfoByPetID(Convert.ToInt32(PetBattle.GetPetInfoBySlot(1)[0]))[1] == "nil")
                    PetFighterConfigForm._Form.lb_Pet_Name1.Text = PetBattle.GetPetInfoByPetID(Convert.ToInt32(PetBattle.GetPetInfoBySlot(1)[0]))[6];
                else PetFighterConfigForm._Form.lb_Pet_Name1.Text = PetBattle.GetPetInfoByPetID(Convert.ToInt32(PetBattle.GetPetInfoBySlot(1)[0]))[1];
                if (PetBattle.GetPetInfoByPetID(Convert.ToInt32(PetBattle.GetPetInfoBySlot(2)[0]))[1] == "nil")
                    PetFighterConfigForm._Form.lb_Pet_Name2.Text = PetBattle.GetPetInfoByPetID(Convert.ToInt32(PetBattle.GetPetInfoBySlot(2)[0]))[6];
                else PetFighterConfigForm._Form.lb_Pet_Name2.Text = PetBattle.GetPetInfoByPetID(Convert.ToInt32(PetBattle.GetPetInfoBySlot(2)[0]))[1];
                if (PetBattle.GetPetInfoByPetID(Convert.ToInt32(PetBattle.GetPetInfoBySlot(3)[0]))[1] == "nil")
                    PetFighterConfigForm._Form.lb_Pet_Name3.Text = PetBattle.GetPetInfoByPetID(Convert.ToInt32(PetBattle.GetPetInfoBySlot(3)[0]))[6];
                else PetFighterConfigForm._Form.lb_Pet_Name3.Text = PetBattle.GetPetInfoByPetID(Convert.ToInt32(PetBattle.GetPetInfoBySlot(3)[0]))[1];

                PetFighterConfigForm._Form.prob_Update.PerformStep(); //ProsessBar Update
                PetFighterConfigForm._Form.lb_Pet_Lvl1.Text = "Level: " + PetBattle.GetPetInfoByPetID(Convert.ToInt32(PetBattle.GetPetInfoBySlot(1)[0]))[2];
                PetFighterConfigForm._Form.lb_Pet_Lvl2.Text = "Level: " + PetBattle.GetPetInfoByPetID(Convert.ToInt32(PetBattle.GetPetInfoBySlot(2)[0]))[2];
                PetFighterConfigForm._Form.lb_Pet_Lvl3.Text = "Level: " + PetBattle.GetPetInfoByPetID(Convert.ToInt32(PetBattle.GetPetInfoBySlot(3)[0]))[2];

                PetFighterConfigForm._Form.prob_Update.Value = 0;
                PetFighterConfigForm._Form.prob_Update.Visible = false;
                PetFighter.Instance.dlog("[UpdateSates] completed ..");
            }
            catch (Exception ex)
            { PetFighter.Instance.dlog("UpdateStatesThread", "{0}", ex); }
        }

        private void PetFighterConfigForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            timer_Updater.Stop();

            PetFighterSettings.Instance.CeckForUpdates = chb_UpdatesCheck.Checked;
            PetFighterSettings.Instance.UseDebug = chb_debug.Checked;
            PetFighterSettings.Instance.TrapAll = chb_Trap_All.Checked;
            PetFighterSettings.Instance.TrapIfNeed = chb_Trap_inNeed.Checked;
            PetFighterSettings.Instance.UseManualRoutines = rb_Routine_Manual.Checked;
            PetFighterSettings.Instance.useNotifyIcon = chb_NotifyIcon.Checked;
            PetFighterSettings.Instance.WaitTime = (int)nud_waitTime.Value;
            PetFighterSettings.Instance.ManualRoutine = tb_ManualRoutine.Text.Split('-');
            PetFighterSettings.Instance.PetBattle_PvP = chb_useBattle_PvP.Checked;
            PetFighterSettings.Instance.PetBattle_Wild = chb_useBattle_Wild.Checked;
            PetFighterSettings.Instance.Save();

            //try { if (newUpdateStatesThread.IsAlive) Thread.Sleep(2000); /*newUpdateStatesThread.Abort();*/ }
            //catch (Exception ex) { }
        }

        private void Pet1_Click(object sender, EventArgs e)
        {
            if (panel_Pet1.BorderStyle == BorderStyle.FixedSingle)
            {
                deselectPets();
                selectPet(1);
                return;
            }
            deselectPets();
        }
        private void Pet2_Click(object sender, EventArgs e)
        {
            if (panel_Pet2.BorderStyle == BorderStyle.FixedSingle)
            {
                deselectPets();
                selectPet(2);
                return;
            }
            deselectPets();
        }
        private void Pet3_Click(object sender, EventArgs e)
        {
            if (panel_Pet3.BorderStyle == BorderStyle.FixedSingle)
            {
                deselectPets();
                selectPet(3);
                return;
            }
            deselectPets();
        }

        private void selectPet(int ID)
        {
            switch (ID)
            {
                case 1:
                    panel_Pet1.BorderStyle = BorderStyle.Fixed3D;
                    lb_Pet_desc.Text = PetBattle.GetPetInfoByIndex(PetBattle.GetPetIndexByPetID(Convert.ToInt32(PetBattle.GetPetInfoBySlot(1)[0])))[12];

                    lb_Ability1_Name.Text = PetBattle.GetAbilityInfosByID(Convert.ToInt32(PetBattle.GetPetInfoBySlot(1)[1]))[1];
                    lb_Ability2_Name.Text = PetBattle.GetAbilityInfosByID(Convert.ToInt32(PetBattle.GetPetInfoBySlot(1)[2]))[1];
                    lb_Ability3_Name.Text = PetBattle.GetAbilityInfosByID(Convert.ToInt32(PetBattle.GetPetInfoBySlot(1)[3]))[1];

                    lb_Ability1_PetTyp.Text = "PetTyp: " + PetBattle.GetAbilityInfosByID(Convert.ToInt32(PetBattle.GetPetInfoBySlot(1)[1]))[6];
                    lb_Ability2_PetTyp.Text = "PetTyp: " + PetBattle.GetAbilityInfosByID(Convert.ToInt32(PetBattle.GetPetInfoBySlot(1)[2]))[6];
                    lb_Ability3_PetTyp.Text = "PetTyp: " + PetBattle.GetAbilityInfosByID(Convert.ToInt32(PetBattle.GetPetInfoBySlot(1)[3]))[6];

                    lb_Ability1_maxCD.Text = "maxCD: " + PetBattle.GetAbilityInfosByID(Convert.ToInt32(PetBattle.GetPetInfoBySlot(1)[1]))[3];
                    lb_Ability2_maxCD.Text = "maxCD: " + PetBattle.GetAbilityInfosByID(Convert.ToInt32(PetBattle.GetPetInfoBySlot(1)[2]))[3];
                    lb_Ability3_maxCD.Text = "maxCD: " + PetBattle.GetAbilityInfosByID(Convert.ToInt32(PetBattle.GetPetInfoBySlot(1)[3]))[3];

                    lb_Ability1_desc.Text = PetBattle.GetAbilityInfosByID(Convert.ToInt32(PetBattle.GetPetInfoBySlot(1)[1]))[4];
                    lb_Ability2_desc.Text = PetBattle.GetAbilityInfosByID(Convert.ToInt32(PetBattle.GetPetInfoBySlot(1)[2]))[4];
                    lb_Ability3_desc.Text = PetBattle.GetAbilityInfosByID(Convert.ToInt32(PetBattle.GetPetInfoBySlot(1)[3]))[4];

                    break;
                case 2:
                    panel_Pet2.BorderStyle = BorderStyle.Fixed3D;
                    lb_Pet_desc.Text = PetBattle.GetPetInfoByIndex(PetBattle.GetPetIndexByPetID(Convert.ToInt32(PetBattle.GetPetInfoBySlot(2)[0])))[12];

                    lb_Ability1_Name.Text = PetBattle.GetAbilityInfosByID(Convert.ToInt32(PetBattle.GetPetInfoBySlot(2)[1]))[1];
                    lb_Ability2_Name.Text = PetBattle.GetAbilityInfosByID(Convert.ToInt32(PetBattle.GetPetInfoBySlot(2)[2]))[1];
                    lb_Ability3_Name.Text = PetBattle.GetAbilityInfosByID(Convert.ToInt32(PetBattle.GetPetInfoBySlot(2)[3]))[1];

                    lb_Ability1_PetTyp.Text = "PetTyp: " + PetBattle.GetAbilityInfosByID(Convert.ToInt32(PetBattle.GetPetInfoBySlot(2)[1]))[6];
                    lb_Ability2_PetTyp.Text = "PetTyp: " + PetBattle.GetAbilityInfosByID(Convert.ToInt32(PetBattle.GetPetInfoBySlot(2)[2]))[6];
                    lb_Ability3_PetTyp.Text = "PetTyp: " + PetBattle.GetAbilityInfosByID(Convert.ToInt32(PetBattle.GetPetInfoBySlot(2)[3]))[6];

                    lb_Ability1_maxCD.Text = "maxCD: " + PetBattle.GetAbilityInfosByID(Convert.ToInt32(PetBattle.GetPetInfoBySlot(2)[1]))[3];
                    lb_Ability2_maxCD.Text = "maxCD: " + PetBattle.GetAbilityInfosByID(Convert.ToInt32(PetBattle.GetPetInfoBySlot(2)[2]))[3];
                    lb_Ability3_maxCD.Text = "maxCD: " + PetBattle.GetAbilityInfosByID(Convert.ToInt32(PetBattle.GetPetInfoBySlot(2)[3]))[3];

                    lb_Ability1_desc.Text = PetBattle.GetAbilityInfosByID(Convert.ToInt32(PetBattle.GetPetInfoBySlot(2)[1]))[4];
                    lb_Ability2_desc.Text = PetBattle.GetAbilityInfosByID(Convert.ToInt32(PetBattle.GetPetInfoBySlot(2)[2]))[4];
                    lb_Ability3_desc.Text = PetBattle.GetAbilityInfosByID(Convert.ToInt32(PetBattle.GetPetInfoBySlot(2)[3]))[4];
                    break;
                default:
                    panel_Pet3.BorderStyle = BorderStyle.Fixed3D;
                    lb_Pet_desc.Text = PetBattle.GetPetInfoByIndex(PetBattle.GetPetIndexByPetID(Convert.ToInt32(PetBattle.GetPetInfoBySlot(3)[0])))[12];

                    lb_Ability1_Name.Text = PetBattle.GetAbilityInfosByID(Convert.ToInt32(PetBattle.GetPetInfoBySlot(3)[1]))[1];
                    lb_Ability2_Name.Text = PetBattle.GetAbilityInfosByID(Convert.ToInt32(PetBattle.GetPetInfoBySlot(3)[2]))[1];
                    lb_Ability3_Name.Text = PetBattle.GetAbilityInfosByID(Convert.ToInt32(PetBattle.GetPetInfoBySlot(3)[3]))[1];
                    
                    lb_Ability1_PetTyp.Text = "PetTyp: " + PetBattle.GetAbilityInfosByID(Convert.ToInt32(PetBattle.GetPetInfoBySlot(3)[1]))[6];
                    lb_Ability2_PetTyp.Text = "PetTyp: " + PetBattle.GetAbilityInfosByID(Convert.ToInt32(PetBattle.GetPetInfoBySlot(3)[2]))[6];
                    lb_Ability3_PetTyp.Text = "PetTyp: " + PetBattle.GetAbilityInfosByID(Convert.ToInt32(PetBattle.GetPetInfoBySlot(3)[3]))[6];

                    lb_Ability1_maxCD.Text = "maxCD: " + PetBattle.GetAbilityInfosByID(Convert.ToInt32(PetBattle.GetPetInfoBySlot(3)[1]))[3];
                    lb_Ability2_maxCD.Text = "maxCD: " + PetBattle.GetAbilityInfosByID(Convert.ToInt32(PetBattle.GetPetInfoBySlot(3)[2]))[3];
                    lb_Ability3_maxCD.Text = "maxCD: " + PetBattle.GetAbilityInfosByID(Convert.ToInt32(PetBattle.GetPetInfoBySlot(3)[3]))[3];

                    lb_Ability1_desc.Text = PetBattle.GetAbilityInfosByID(Convert.ToInt32(PetBattle.GetPetInfoBySlot(3)[1]))[4];
                    lb_Ability2_desc.Text = PetBattle.GetAbilityInfosByID(Convert.ToInt32(PetBattle.GetPetInfoBySlot(3)[2]))[4];
                    lb_Ability3_desc.Text = PetBattle.GetAbilityInfosByID(Convert.ToInt32(PetBattle.GetPetInfoBySlot(3)[3]))[4];
                    break;
            }
            

            if (!panel_AbilityInfo.Visible)
            {
                panel_AbilityInfo.Visible = true;
                Size = new Size(Size.Width, (Size.Height + _sizeChanger));
            }
        }

        private void deselectPets()
        {
            panel_Pet1.BorderStyle = BorderStyle.FixedSingle;
            panel_Pet2.BorderStyle = BorderStyle.FixedSingle;
            panel_Pet3.BorderStyle = BorderStyle.FixedSingle;

            if (panel_AbilityInfo.Visible)
            {
                panel_AbilityInfo.Visible = false;
                Size = new Size(Size.Width, (Size.Height - _sizeChanger));
            }
        }

        //private void button_TEST_Click(object sender, EventArgs e)
        //{
        //    if (PetSettingsHelper.CanLoadPetSettings("1", "2"))
        //    {
        //        var ini2 = new PetRoutinesSettings();
        //        bool x2 = ini2.IsHealAbility;
        //        MessageBox.Show("done");
        //    }
        //}
    }
}