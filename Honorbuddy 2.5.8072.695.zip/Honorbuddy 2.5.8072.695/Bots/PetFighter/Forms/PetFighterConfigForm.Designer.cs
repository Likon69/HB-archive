﻿namespace PetFighter
{
    partial class PetFighterConfigForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.pb_Logo = new System.Windows.Forms.PictureBox();
            this.prob_Health_Pet1 = new System.Windows.Forms.ProgressBar();
            this.lb_Pet_Lvl1 = new System.Windows.Forms.Label();
            this.lb_Pet_Name1 = new System.Windows.Forms.Label();
            this.lb_Pet_HP1 = new System.Windows.Forms.Label();
            this.panel_Pet1 = new System.Windows.Forms.Panel();
            this.panel_Pet2 = new System.Windows.Forms.Panel();
            this.prob_Health_Pet2 = new System.Windows.Forms.ProgressBar();
            this.lb_Pet_HP2 = new System.Windows.Forms.Label();
            this.lb_Pet_Lvl2 = new System.Windows.Forms.Label();
            this.lb_Pet_Name2 = new System.Windows.Forms.Label();
            this.panel_Pet3 = new System.Windows.Forms.Panel();
            this.prob_Health_Pet3 = new System.Windows.Forms.ProgressBar();
            this.lb_Pet_HP3 = new System.Windows.Forms.Label();
            this.lb_Pet_Lvl3 = new System.Windows.Forms.Label();
            this.lb_Pet_Name3 = new System.Windows.Forms.Label();
            this.lb_Pet_desc = new System.Windows.Forms.Label();
            this.panel_AbilityInfo = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.lb_Ability2_desc = new System.Windows.Forms.Label();
            this.lb_Ability2_maxCD = new System.Windows.Forms.Label();
            this.lb_Ability2_PetTyp = new System.Windows.Forms.Label();
            this.lb_Ability2_Name = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.lb_Ability3_desc = new System.Windows.Forms.Label();
            this.lb_Ability3_maxCD = new System.Windows.Forms.Label();
            this.lb_Ability3_Name = new System.Windows.Forms.Label();
            this.lb_Ability3_PetTyp = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.lb_Ability1_desc = new System.Windows.Forms.Label();
            this.lb_Ability1_PetTyp = new System.Windows.Forms.Label();
            this.lb_Ability1_maxCD = new System.Windows.Forms.Label();
            this.lb_Ability1_Name = new System.Windows.Forms.Label();
            this.lb_versionText = new System.Windows.Forms.Label();
            this.btn_FightInfoForm = new System.Windows.Forms.Button();
            this.btn_import = new System.Windows.Forms.Button();
            this.btn_export = new System.Windows.Forms.Button();
            this.btn_UpdateNow = new System.Windows.Forms.Button();
            this.chb_UpdatesCheck = new System.Windows.Forms.CheckBox();
            this.tb_ManualRoutine = new System.Windows.Forms.TextBox();
            this.rb_Routine_Auto = new System.Windows.Forms.RadioButton();
            this.rb_Routine_Manual = new System.Windows.Forms.RadioButton();
            this.nud_waitTime = new System.Windows.Forms.NumericUpDown();
            this.label13 = new System.Windows.Forms.Label();
            this.chb_debug = new System.Windows.Forms.CheckBox();
            this.panel8 = new System.Windows.Forms.Panel();
            this.chb_useBattle_Wild = new System.Windows.Forms.CheckBox();
            this.chb_useBattle_PvP = new System.Windows.Forms.CheckBox();
            this.btn_ReviveBattlePets = new System.Windows.Forms.Button();
            this.btn_ProfileSettings = new System.Windows.Forms.Button();
            this.chb_NotifyIcon = new System.Windows.Forms.CheckBox();
            this.chb_Trap_All = new System.Windows.Forms.CheckBox();
            this.chb_Trap_inNeed = new System.Windows.Forms.CheckBox();
            this.timer_Updater = new System.Windows.Forms.Timer(this.components);
            this.prob_Update = new System.Windows.Forms.ProgressBar();
            this.labelx = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Logo)).BeginInit();
            this.panel_Pet1.SuspendLayout();
            this.panel_Pet2.SuspendLayout();
            this.panel_Pet3.SuspendLayout();
            this.panel_AbilityInfo.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_waitTime)).BeginInit();
            this.panel8.SuspendLayout();
            this.SuspendLayout();
            // 
            // pb_Logo
            // 
            this.pb_Logo.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pb_Logo.Dock = System.Windows.Forms.DockStyle.Top;
            this.pb_Logo.Location = new System.Drawing.Point(0, 0);
            this.pb_Logo.Name = "pb_Logo";
            this.pb_Logo.Size = new System.Drawing.Size(416, 97);
            this.pb_Logo.TabIndex = 0;
            this.pb_Logo.TabStop = false;
            this.pb_Logo.Click += new System.EventHandler(this.pb_Logo_Click);
            // 
            // prob_Health_Pet1
            // 
            this.prob_Health_Pet1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.prob_Health_Pet1.Location = new System.Drawing.Point(0, 49);
            this.prob_Health_Pet1.Name = "prob_Health_Pet1";
            this.prob_Health_Pet1.Size = new System.Drawing.Size(122, 23);
            this.prob_Health_Pet1.TabIndex = 1;
            this.prob_Health_Pet1.Value = 50;
            this.prob_Health_Pet1.Click += new System.EventHandler(this.Pet1_Click);
            // 
            // lb_Pet_Lvl1
            // 
            this.lb_Pet_Lvl1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lb_Pet_Lvl1.Location = new System.Drawing.Point(3, 89);
            this.lb_Pet_Lvl1.Name = "lb_Pet_Lvl1";
            this.lb_Pet_Lvl1.Size = new System.Drawing.Size(116, 13);
            this.lb_Pet_Lvl1.TabIndex = 3;
            this.lb_Pet_Lvl1.Text = "Level: X";
            this.lb_Pet_Lvl1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lb_Pet_Lvl1.Click += new System.EventHandler(this.Pet1_Click);
            // 
            // lb_Pet_Name1
            // 
            this.lb_Pet_Name1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lb_Pet_Name1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Pet_Name1.Location = new System.Drawing.Point(3, 4);
            this.lb_Pet_Name1.Name = "lb_Pet_Name1";
            this.lb_Pet_Name1.Size = new System.Drawing.Size(117, 42);
            this.lb_Pet_Name1.TabIndex = 2;
            this.lb_Pet_Name1.Text = "Name";
            this.lb_Pet_Name1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lb_Pet_Name1.Click += new System.EventHandler(this.Pet1_Click);
            // 
            // lb_Pet_HP1
            // 
            this.lb_Pet_HP1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lb_Pet_HP1.Location = new System.Drawing.Point(3, 74);
            this.lb_Pet_HP1.Name = "lb_Pet_HP1";
            this.lb_Pet_HP1.Size = new System.Drawing.Size(116, 13);
            this.lb_Pet_HP1.TabIndex = 3;
            this.lb_Pet_HP1.Text = "HP: 100 / 100";
            this.lb_Pet_HP1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lb_Pet_HP1.Click += new System.EventHandler(this.Pet1_Click);
            // 
            // panel_Pet1
            // 
            this.panel_Pet1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel_Pet1.Controls.Add(this.prob_Health_Pet1);
            this.panel_Pet1.Controls.Add(this.lb_Pet_HP1);
            this.panel_Pet1.Controls.Add(this.lb_Pet_Lvl1);
            this.panel_Pet1.Controls.Add(this.lb_Pet_Name1);
            this.panel_Pet1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panel_Pet1.Location = new System.Drawing.Point(12, 144);
            this.panel_Pet1.Name = "panel_Pet1";
            this.panel_Pet1.Size = new System.Drawing.Size(122, 107);
            this.panel_Pet1.TabIndex = 5;
            this.panel_Pet1.Click += new System.EventHandler(this.Pet1_Click);
            // 
            // panel_Pet2
            // 
            this.panel_Pet2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel_Pet2.Controls.Add(this.prob_Health_Pet2);
            this.panel_Pet2.Controls.Add(this.lb_Pet_HP2);
            this.panel_Pet2.Controls.Add(this.lb_Pet_Lvl2);
            this.panel_Pet2.Controls.Add(this.lb_Pet_Name2);
            this.panel_Pet2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panel_Pet2.Location = new System.Drawing.Point(147, 144);
            this.panel_Pet2.Name = "panel_Pet2";
            this.panel_Pet2.Size = new System.Drawing.Size(122, 107);
            this.panel_Pet2.TabIndex = 5;
            this.panel_Pet2.Click += new System.EventHandler(this.Pet2_Click);
            // 
            // prob_Health_Pet2
            // 
            this.prob_Health_Pet2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.prob_Health_Pet2.Location = new System.Drawing.Point(0, 49);
            this.prob_Health_Pet2.Name = "prob_Health_Pet2";
            this.prob_Health_Pet2.Size = new System.Drawing.Size(122, 23);
            this.prob_Health_Pet2.TabIndex = 1;
            this.prob_Health_Pet2.Value = 50;
            this.prob_Health_Pet2.Click += new System.EventHandler(this.Pet2_Click);
            // 
            // lb_Pet_HP2
            // 
            this.lb_Pet_HP2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lb_Pet_HP2.Location = new System.Drawing.Point(3, 74);
            this.lb_Pet_HP2.Name = "lb_Pet_HP2";
            this.lb_Pet_HP2.Size = new System.Drawing.Size(116, 13);
            this.lb_Pet_HP2.TabIndex = 3;
            this.lb_Pet_HP2.Text = "HP can\'t load..";
            this.lb_Pet_HP2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lb_Pet_HP2.Click += new System.EventHandler(this.Pet2_Click);
            // 
            // lb_Pet_Lvl2
            // 
            this.lb_Pet_Lvl2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lb_Pet_Lvl2.Location = new System.Drawing.Point(6, 89);
            this.lb_Pet_Lvl2.Name = "lb_Pet_Lvl2";
            this.lb_Pet_Lvl2.Size = new System.Drawing.Size(113, 13);
            this.lb_Pet_Lvl2.TabIndex = 3;
            this.lb_Pet_Lvl2.Text = "Level: X";
            this.lb_Pet_Lvl2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lb_Pet_Lvl2.Click += new System.EventHandler(this.Pet2_Click);
            // 
            // lb_Pet_Name2
            // 
            this.lb_Pet_Name2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lb_Pet_Name2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Pet_Name2.Location = new System.Drawing.Point(3, 4);
            this.lb_Pet_Name2.Name = "lb_Pet_Name2";
            this.lb_Pet_Name2.Size = new System.Drawing.Size(117, 43);
            this.lb_Pet_Name2.TabIndex = 2;
            this.lb_Pet_Name2.Text = "Name";
            this.lb_Pet_Name2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lb_Pet_Name2.Click += new System.EventHandler(this.Pet2_Click);
            // 
            // panel_Pet3
            // 
            this.panel_Pet3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel_Pet3.Controls.Add(this.prob_Health_Pet3);
            this.panel_Pet3.Controls.Add(this.lb_Pet_HP3);
            this.panel_Pet3.Controls.Add(this.lb_Pet_Lvl3);
            this.panel_Pet3.Controls.Add(this.lb_Pet_Name3);
            this.panel_Pet3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panel_Pet3.Location = new System.Drawing.Point(282, 144);
            this.panel_Pet3.Name = "panel_Pet3";
            this.panel_Pet3.Size = new System.Drawing.Size(122, 107);
            this.panel_Pet3.TabIndex = 5;
            this.panel_Pet3.Click += new System.EventHandler(this.Pet3_Click);
            // 
            // prob_Health_Pet3
            // 
            this.prob_Health_Pet3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.prob_Health_Pet3.Location = new System.Drawing.Point(0, 49);
            this.prob_Health_Pet3.Name = "prob_Health_Pet3";
            this.prob_Health_Pet3.Size = new System.Drawing.Size(122, 23);
            this.prob_Health_Pet3.TabIndex = 1;
            this.prob_Health_Pet3.Value = 50;
            this.prob_Health_Pet3.Click += new System.EventHandler(this.Pet3_Click);
            // 
            // lb_Pet_HP3
            // 
            this.lb_Pet_HP3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lb_Pet_HP3.Location = new System.Drawing.Point(6, 74);
            this.lb_Pet_HP3.Name = "lb_Pet_HP3";
            this.lb_Pet_HP3.Size = new System.Drawing.Size(112, 13);
            this.lb_Pet_HP3.TabIndex = 3;
            this.lb_Pet_HP3.Text = "HP: 100 / 100";
            this.lb_Pet_HP3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lb_Pet_HP3.Click += new System.EventHandler(this.Pet3_Click);
            // 
            // lb_Pet_Lvl3
            // 
            this.lb_Pet_Lvl3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lb_Pet_Lvl3.Location = new System.Drawing.Point(5, 89);
            this.lb_Pet_Lvl3.Name = "lb_Pet_Lvl3";
            this.lb_Pet_Lvl3.Size = new System.Drawing.Size(113, 13);
            this.lb_Pet_Lvl3.TabIndex = 3;
            this.lb_Pet_Lvl3.Text = "Level: X";
            this.lb_Pet_Lvl3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lb_Pet_Lvl3.Click += new System.EventHandler(this.Pet3_Click);
            // 
            // lb_Pet_Name3
            // 
            this.lb_Pet_Name3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lb_Pet_Name3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Pet_Name3.Location = new System.Drawing.Point(3, 4);
            this.lb_Pet_Name3.Name = "lb_Pet_Name3";
            this.lb_Pet_Name3.Size = new System.Drawing.Size(117, 43);
            this.lb_Pet_Name3.TabIndex = 2;
            this.lb_Pet_Name3.Text = "Name";
            this.lb_Pet_Name3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lb_Pet_Name3.Click += new System.EventHandler(this.Pet3_Click);
            // 
            // lb_Pet_desc
            // 
            this.lb_Pet_desc.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lb_Pet_desc.Dock = System.Windows.Forms.DockStyle.Top;
            this.lb_Pet_desc.Location = new System.Drawing.Point(0, 0);
            this.lb_Pet_desc.Name = "lb_Pet_desc";
            this.lb_Pet_desc.Size = new System.Drawing.Size(412, 46);
            this.lb_Pet_desc.TabIndex = 6;
            this.lb_Pet_desc.Text = "pet_desc";
            this.lb_Pet_desc.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel_AbilityInfo
            // 
            this.panel_AbilityInfo.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel_AbilityInfo.Controls.Add(this.panel7);
            this.panel_AbilityInfo.Controls.Add(this.panel6);
            this.panel_AbilityInfo.Controls.Add(this.panel5);
            this.panel_AbilityInfo.Controls.Add(this.lb_Pet_desc);
            this.panel_AbilityInfo.Location = new System.Drawing.Point(0, 316);
            this.panel_AbilityInfo.Name = "panel_AbilityInfo";
            this.panel_AbilityInfo.Size = new System.Drawing.Size(416, 240);
            this.panel_AbilityInfo.TabIndex = 7;
            // 
            // panel7
            // 
            this.panel7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel7.Controls.Add(this.lb_Ability2_desc);
            this.panel7.Controls.Add(this.lb_Ability2_maxCD);
            this.panel7.Controls.Add(this.lb_Ability2_PetTyp);
            this.panel7.Controls.Add(this.lb_Ability2_Name);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel7.Location = new System.Drawing.Point(137, 46);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(138, 190);
            this.panel7.TabIndex = 7;
            // 
            // lb_Ability2_desc
            // 
            this.lb_Ability2_desc.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lb_Ability2_desc.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Ability2_desc.Location = new System.Drawing.Point(0, 56);
            this.lb_Ability2_desc.Name = "lb_Ability2_desc";
            this.lb_Ability2_desc.Size = new System.Drawing.Size(137, 132);
            this.lb_Ability2_desc.TabIndex = 0;
            this.lb_Ability2_desc.Text = "lb_Ability2_desc";
            // 
            // lb_Ability2_maxCD
            // 
            this.lb_Ability2_maxCD.Location = new System.Drawing.Point(-1, 43);
            this.lb_Ability2_maxCD.Name = "lb_Ability2_maxCD";
            this.lb_Ability2_maxCD.Size = new System.Drawing.Size(138, 13);
            this.lb_Ability2_maxCD.TabIndex = 0;
            this.lb_Ability2_maxCD.Text = "lb_Ability2_maxCD";
            this.lb_Ability2_maxCD.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Ability2_PetTyp
            // 
            this.lb_Ability2_PetTyp.Location = new System.Drawing.Point(0, 30);
            this.lb_Ability2_PetTyp.Name = "lb_Ability2_PetTyp";
            this.lb_Ability2_PetTyp.Size = new System.Drawing.Size(137, 13);
            this.lb_Ability2_PetTyp.TabIndex = 0;
            this.lb_Ability2_PetTyp.Text = "lb_Ability2_PetTyp";
            this.lb_Ability2_PetTyp.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Ability2_Name
            // 
            this.lb_Ability2_Name.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lb_Ability2_Name.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Ability2_Name.Location = new System.Drawing.Point(-1, 0);
            this.lb_Ability2_Name.Name = "lb_Ability2_Name";
            this.lb_Ability2_Name.Size = new System.Drawing.Size(138, 30);
            this.lb_Ability2_Name.TabIndex = 0;
            this.lb_Ability2_Name.Text = "lb_Ability2_Name";
            this.lb_Ability2_Name.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel6
            // 
            this.panel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel6.Controls.Add(this.lb_Ability3_desc);
            this.panel6.Controls.Add(this.lb_Ability3_maxCD);
            this.panel6.Controls.Add(this.lb_Ability3_Name);
            this.panel6.Controls.Add(this.lb_Ability3_PetTyp);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel6.Location = new System.Drawing.Point(275, 46);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(137, 190);
            this.panel6.TabIndex = 7;
            // 
            // lb_Ability3_desc
            // 
            this.lb_Ability3_desc.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lb_Ability3_desc.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Ability3_desc.Location = new System.Drawing.Point(-1, 56);
            this.lb_Ability3_desc.Name = "lb_Ability3_desc";
            this.lb_Ability3_desc.Size = new System.Drawing.Size(137, 132);
            this.lb_Ability3_desc.TabIndex = 0;
            this.lb_Ability3_desc.Text = "lb_Ability3_desc";
            // 
            // lb_Ability3_maxCD
            // 
            this.lb_Ability3_maxCD.Location = new System.Drawing.Point(-1, 43);
            this.lb_Ability3_maxCD.Name = "lb_Ability3_maxCD";
            this.lb_Ability3_maxCD.Size = new System.Drawing.Size(137, 13);
            this.lb_Ability3_maxCD.TabIndex = 0;
            this.lb_Ability3_maxCD.Text = "lb_Ability3_maxCD";
            this.lb_Ability3_maxCD.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Ability3_Name
            // 
            this.lb_Ability3_Name.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lb_Ability3_Name.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Ability3_Name.Location = new System.Drawing.Point(-1, 0);
            this.lb_Ability3_Name.Name = "lb_Ability3_Name";
            this.lb_Ability3_Name.Size = new System.Drawing.Size(137, 30);
            this.lb_Ability3_Name.TabIndex = 0;
            this.lb_Ability3_Name.Text = "lb_Ability3_Name";
            this.lb_Ability3_Name.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Ability3_PetTyp
            // 
            this.lb_Ability3_PetTyp.Location = new System.Drawing.Point(-1, 30);
            this.lb_Ability3_PetTyp.Name = "lb_Ability3_PetTyp";
            this.lb_Ability3_PetTyp.Size = new System.Drawing.Size(137, 13);
            this.lb_Ability3_PetTyp.TabIndex = 0;
            this.lb_Ability3_PetTyp.Text = "lb_Ability3_PetTyp";
            this.lb_Ability3_PetTyp.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel5
            // 
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.Controls.Add(this.lb_Ability1_desc);
            this.panel5.Controls.Add(this.lb_Ability1_PetTyp);
            this.panel5.Controls.Add(this.lb_Ability1_maxCD);
            this.panel5.Controls.Add(this.lb_Ability1_Name);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel5.Location = new System.Drawing.Point(0, 46);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(137, 190);
            this.panel5.TabIndex = 7;
            // 
            // lb_Ability1_desc
            // 
            this.lb_Ability1_desc.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lb_Ability1_desc.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Ability1_desc.Location = new System.Drawing.Point(-1, 56);
            this.lb_Ability1_desc.Name = "lb_Ability1_desc";
            this.lb_Ability1_desc.Size = new System.Drawing.Size(137, 132);
            this.lb_Ability1_desc.TabIndex = 0;
            this.lb_Ability1_desc.Text = "lb_Ability1_desc";
            // 
            // lb_Ability1_PetTyp
            // 
            this.lb_Ability1_PetTyp.Location = new System.Drawing.Point(-1, 30);
            this.lb_Ability1_PetTyp.Name = "lb_Ability1_PetTyp";
            this.lb_Ability1_PetTyp.Size = new System.Drawing.Size(137, 13);
            this.lb_Ability1_PetTyp.TabIndex = 0;
            this.lb_Ability1_PetTyp.Text = "lb_Ability1_PetTyp";
            this.lb_Ability1_PetTyp.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Ability1_maxCD
            // 
            this.lb_Ability1_maxCD.Location = new System.Drawing.Point(-1, 43);
            this.lb_Ability1_maxCD.Name = "lb_Ability1_maxCD";
            this.lb_Ability1_maxCD.Size = new System.Drawing.Size(137, 13);
            this.lb_Ability1_maxCD.TabIndex = 0;
            this.lb_Ability1_maxCD.Text = "lb_Ability1_maxCD";
            this.lb_Ability1_maxCD.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_Ability1_Name
            // 
            this.lb_Ability1_Name.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lb_Ability1_Name.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Ability1_Name.Location = new System.Drawing.Point(-3, 0);
            this.lb_Ability1_Name.Name = "lb_Ability1_Name";
            this.lb_Ability1_Name.Size = new System.Drawing.Size(139, 30);
            this.lb_Ability1_Name.TabIndex = 0;
            this.lb_Ability1_Name.Text = "lb_Ability1_Name";
            this.lb_Ability1_Name.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_versionText
            // 
            this.lb_versionText.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lb_versionText.BackColor = System.Drawing.Color.Gold;
            this.lb_versionText.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lb_versionText.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F);
            this.lb_versionText.Location = new System.Drawing.Point(315, -2);
            this.lb_versionText.Name = "lb_versionText";
            this.lb_versionText.Size = new System.Drawing.Size(100, 18);
            this.lb_versionText.TabIndex = 8;
            this.lb_versionText.Text = "v. 1.111.111 Alpha";
            this.lb_versionText.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btn_FightInfoForm
            // 
            this.btn_FightInfoForm.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btn_FightInfoForm.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_FightInfoForm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_FightInfoForm.Enabled = false;
            this.btn_FightInfoForm.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_FightInfoForm.Location = new System.Drawing.Point(306, 560);
            this.btn_FightInfoForm.Name = "btn_FightInfoForm";
            this.btn_FightInfoForm.Size = new System.Drawing.Size(97, 33);
            this.btn_FightInfoForm.TabIndex = 9;
            this.btn_FightInfoForm.Text = "FightInfoForm";
            this.btn_FightInfoForm.UseVisualStyleBackColor = true;
            // 
            // btn_import
            // 
            this.btn_import.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btn_import.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_import.Enabled = false;
            this.btn_import.Location = new System.Drawing.Point(95, 570);
            this.btn_import.Name = "btn_import";
            this.btn_import.Size = new System.Drawing.Size(75, 23);
            this.btn_import.TabIndex = 10;
            this.btn_import.Text = "import";
            this.btn_import.UseVisualStyleBackColor = true;
            // 
            // btn_export
            // 
            this.btn_export.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btn_export.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_export.Enabled = false;
            this.btn_export.Location = new System.Drawing.Point(12, 570);
            this.btn_export.Name = "btn_export";
            this.btn_export.Size = new System.Drawing.Size(75, 23);
            this.btn_export.TabIndex = 11;
            this.btn_export.Text = "export";
            this.btn_export.UseVisualStyleBackColor = true;
            // 
            // btn_UpdateNow
            // 
            this.btn_UpdateNow.BackColor = System.Drawing.Color.Gold;
            this.btn_UpdateNow.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_UpdateNow.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_UpdateNow.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_UpdateNow.Location = new System.Drawing.Point(0, 44);
            this.btn_UpdateNow.Name = "btn_UpdateNow";
            this.btn_UpdateNow.Size = new System.Drawing.Size(416, 53);
            this.btn_UpdateNow.TabIndex = 12;
            this.btn_UpdateNow.Text = "a new version is available!\r\nUpdateNow";
            this.btn_UpdateNow.UseVisualStyleBackColor = false;
            this.btn_UpdateNow.Visible = false;
            this.btn_UpdateNow.Click += new System.EventHandler(this.btn_UpdateNow_Click);
            // 
            // chb_UpdatesCheck
            // 
            this.chb_UpdatesCheck.AutoSize = true;
            this.chb_UpdatesCheck.BackColor = System.Drawing.Color.Gainsboro;
            this.chb_UpdatesCheck.Checked = true;
            this.chb_UpdatesCheck.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chb_UpdatesCheck.Cursor = System.Windows.Forms.Cursors.Hand;
            this.chb_UpdatesCheck.Location = new System.Drawing.Point(3, 104);
            this.chb_UpdatesCheck.Name = "chb_UpdatesCheck";
            this.chb_UpdatesCheck.Size = new System.Drawing.Size(164, 17);
            this.chb_UpdatesCheck.TabIndex = 13;
            this.chb_UpdatesCheck.Text = "check for Updates every 12h";
            this.chb_UpdatesCheck.UseVisualStyleBackColor = false;
            // 
            // tb_ManualRoutine
            // 
            this.tb_ManualRoutine.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_ManualRoutine.Location = new System.Drawing.Point(0, 31);
            this.tb_ManualRoutine.Name = "tb_ManualRoutine";
            this.tb_ManualRoutine.Size = new System.Drawing.Size(219, 20);
            this.tb_ManualRoutine.TabIndex = 14;
            this.tb_ManualRoutine.Text = "1-2-1-3";
            this.tb_ManualRoutine.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // rb_Routine_Auto
            // 
            this.rb_Routine_Auto.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rb_Routine_Auto.Enabled = false;
            this.rb_Routine_Auto.Location = new System.Drawing.Point(-6, 8);
            this.rb_Routine_Auto.Name = "rb_Routine_Auto";
            this.rb_Routine_Auto.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.rb_Routine_Auto.Size = new System.Drawing.Size(110, 17);
            this.rb_Routine_Auto.TabIndex = 15;
            this.rb_Routine_Auto.Text = "Auto Routine";
            this.rb_Routine_Auto.UseVisualStyleBackColor = true;
            // 
            // rb_Routine_Manual
            // 
            this.rb_Routine_Manual.Checked = true;
            this.rb_Routine_Manual.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rb_Routine_Manual.Location = new System.Drawing.Point(112, 8);
            this.rb_Routine_Manual.Name = "rb_Routine_Manual";
            this.rb_Routine_Manual.Size = new System.Drawing.Size(110, 17);
            this.rb_Routine_Manual.TabIndex = 15;
            this.rb_Routine_Manual.TabStop = true;
            this.rb_Routine_Manual.Text = "Manual Routine";
            this.rb_Routine_Manual.UseVisualStyleBackColor = true;
            // 
            // nud_waitTime
            // 
            this.nud_waitTime.Location = new System.Drawing.Point(289, 265);
            this.nud_waitTime.Name = "nud_waitTime";
            this.nud_waitTime.Size = new System.Drawing.Size(41, 20);
            this.nud_waitTime.TabIndex = 16;
            this.nud_waitTime.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_waitTime.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            // 
            // label13
            // 
            this.label13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label13.Location = new System.Drawing.Point(262, 261);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(127, 46);
            this.label13.TabIndex = 17;
            this.label13.Text = "Wait               sec before\r\nany action will be taken";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // chb_debug
            // 
            this.chb_debug.AutoSize = true;
            this.chb_debug.BackColor = System.Drawing.Color.Gainsboro;
            this.chb_debug.Cursor = System.Windows.Forms.Cursors.Hand;
            this.chb_debug.Location = new System.Drawing.Point(3, 122);
            this.chb_debug.Name = "chb_debug";
            this.chb_debug.Size = new System.Drawing.Size(78, 17);
            this.chb_debug.TabIndex = 13;
            this.chb_debug.Text = "use Debug";
            this.chb_debug.UseVisualStyleBackColor = false;
            // 
            // panel8
            // 
            this.panel8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel8.Controls.Add(this.tb_ManualRoutine);
            this.panel8.Controls.Add(this.rb_Routine_Auto);
            this.panel8.Controls.Add(this.rb_Routine_Manual);
            this.panel8.Location = new System.Drawing.Point(27, 258);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(219, 53);
            this.panel8.TabIndex = 18;
            // 
            // chb_useBattle_Wild
            // 
            this.chb_useBattle_Wild.AutoSize = true;
            this.chb_useBattle_Wild.Checked = true;
            this.chb_useBattle_Wild.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chb_useBattle_Wild.Cursor = System.Windows.Forms.Cursors.Hand;
            this.chb_useBattle_Wild.Enabled = false;
            this.chb_useBattle_Wild.Location = new System.Drawing.Point(271, 122);
            this.chb_useBattle_Wild.Name = "chb_useBattle_Wild";
            this.chb_useBattle_Wild.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.chb_useBattle_Wild.Size = new System.Drawing.Size(93, 17);
            this.chb_useBattle_Wild.TabIndex = 19;
            this.chb_useBattle_Wild.Text = "Wild-PetBattle";
            this.chb_useBattle_Wild.UseVisualStyleBackColor = true;
            // 
            // chb_useBattle_PvP
            // 
            this.chb_useBattle_PvP.AutoSize = true;
            this.chb_useBattle_PvP.Cursor = System.Windows.Forms.Cursors.Hand;
            this.chb_useBattle_PvP.Enabled = false;
            this.chb_useBattle_PvP.Location = new System.Drawing.Point(272, 104);
            this.chb_useBattle_PvP.Name = "chb_useBattle_PvP";
            this.chb_useBattle_PvP.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.chb_useBattle_PvP.Size = new System.Drawing.Size(92, 17);
            this.chb_useBattle_PvP.TabIndex = 19;
            this.chb_useBattle_PvP.Text = "PvP-PetBattle";
            this.chb_useBattle_PvP.UseVisualStyleBackColor = true;
            // 
            // btn_ReviveBattlePets
            // 
            this.btn_ReviveBattlePets.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_ReviveBattlePets.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_ReviveBattlePets.Enabled = false;
            this.btn_ReviveBattlePets.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_ReviveBattlePets.Location = new System.Drawing.Point(369, 100);
            this.btn_ReviveBattlePets.Name = "btn_ReviveBattlePets";
            this.btn_ReviveBattlePets.Size = new System.Drawing.Size(42, 42);
            this.btn_ReviveBattlePets.TabIndex = 20;
            this.btn_ReviveBattlePets.UseVisualStyleBackColor = true;
            this.btn_ReviveBattlePets.Click += new System.EventHandler(this.btn_ReviveBattlePets_Click);
            // 
            // btn_ProfileSettings
            // 
            this.btn_ProfileSettings.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btn_ProfileSettings.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_ProfileSettings.Enabled = false;
            this.btn_ProfileSettings.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ProfileSettings.Location = new System.Drawing.Point(178, 570);
            this.btn_ProfileSettings.Name = "btn_ProfileSettings";
            this.btn_ProfileSettings.Size = new System.Drawing.Size(75, 23);
            this.btn_ProfileSettings.TabIndex = 10;
            this.btn_ProfileSettings.Text = "Profile Settings";
            this.btn_ProfileSettings.UseVisualStyleBackColor = true;
            // 
            // chb_NotifyIcon
            // 
            this.chb_NotifyIcon.AutoSize = true;
            this.chb_NotifyIcon.Cursor = System.Windows.Forms.Cursors.Hand;
            this.chb_NotifyIcon.Enabled = false;
            this.chb_NotifyIcon.Location = new System.Drawing.Point(93, 122);
            this.chb_NotifyIcon.Name = "chb_NotifyIcon";
            this.chb_NotifyIcon.Size = new System.Drawing.Size(74, 17);
            this.chb_NotifyIcon.TabIndex = 21;
            this.chb_NotifyIcon.Text = "NotifyIcon";
            this.chb_NotifyIcon.UseVisualStyleBackColor = true;
            // 
            // chb_Trap_All
            // 
            this.chb_Trap_All.AutoSize = true;
            this.chb_Trap_All.Cursor = System.Windows.Forms.Cursors.Hand;
            this.chb_Trap_All.Location = new System.Drawing.Point(171, 122);
            this.chb_Trap_All.Name = "chb_Trap_All";
            this.chb_Trap_All.Size = new System.Drawing.Size(61, 17);
            this.chb_Trap_All.TabIndex = 21;
            this.chb_Trap_All.Text = "Trap all";
            this.chb_Trap_All.UseVisualStyleBackColor = true;
            // 
            // chb_Trap_inNeed
            // 
            this.chb_Trap_inNeed.AutoSize = true;
            this.chb_Trap_inNeed.Checked = true;
            this.chb_Trap_inNeed.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chb_Trap_inNeed.Cursor = System.Windows.Forms.Cursors.Hand;
            this.chb_Trap_inNeed.Location = new System.Drawing.Point(171, 104);
            this.chb_Trap_inNeed.Name = "chb_Trap_inNeed";
            this.chb_Trap_inNeed.Size = new System.Drawing.Size(95, 17);
            this.chb_Trap_inNeed.TabIndex = 21;
            this.chb_Trap_inNeed.Text = "Trap if needed";
            this.chb_Trap_inNeed.UseVisualStyleBackColor = true;
            // 
            // timer_Updater
            // 
            this.timer_Updater.Enabled = true;
            this.timer_Updater.Interval = 600;
            this.timer_Updater.Tick += new System.EventHandler(this.timer_ReviveBattlePets_Tick);
            // 
            // prob_Update
            // 
            this.prob_Update.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.prob_Update.Location = new System.Drawing.Point(-3, 596);
            this.prob_Update.Maximum = 7;
            this.prob_Update.Name = "prob_Update";
            this.prob_Update.Size = new System.Drawing.Size(120, 10);
            this.prob_Update.TabIndex = 22;
            // 
            // labelx
            // 
            this.labelx.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.labelx.AutoSize = true;
            this.labelx.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F);
            this.labelx.Location = new System.Drawing.Point(361, 597);
            this.labelx.Name = "labelx";
            this.labelx.Size = new System.Drawing.Size(55, 9);
            this.labelx.TabIndex = 56;
            this.labelx.Text = "by BarryDurex";
            // 
            // PetFighterConfigForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gainsboro;
            this.ClientSize = new System.Drawing.Size(416, 607);
            this.Controls.Add(this.labelx);
            this.Controls.Add(this.prob_Update);
            this.Controls.Add(this.chb_Trap_inNeed);
            this.Controls.Add(this.chb_Trap_All);
            this.Controls.Add(this.chb_NotifyIcon);
            this.Controls.Add(this.btn_ReviveBattlePets);
            this.Controls.Add(this.chb_useBattle_PvP);
            this.Controls.Add(this.chb_useBattle_Wild);
            this.Controls.Add(this.panel8);
            this.Controls.Add(this.nud_waitTime);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.chb_debug);
            this.Controls.Add(this.chb_UpdatesCheck);
            this.Controls.Add(this.btn_UpdateNow);
            this.Controls.Add(this.btn_export);
            this.Controls.Add(this.btn_ProfileSettings);
            this.Controls.Add(this.btn_import);
            this.Controls.Add(this.btn_FightInfoForm);
            this.Controls.Add(this.lb_versionText);
            this.Controls.Add(this.panel_AbilityInfo);
            this.Controls.Add(this.panel_Pet3);
            this.Controls.Add(this.panel_Pet2);
            this.Controls.Add(this.panel_Pet1);
            this.Controls.Add(this.pb_Logo);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "PetFighterConfigForm";
            this.Text = "[PetFighter]";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.PetFighterConfigForm_FormClosing);
            this.Load += new System.EventHandler(this.PetFighterConfigForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pb_Logo)).EndInit();
            this.panel_Pet1.ResumeLayout(false);
            this.panel_Pet2.ResumeLayout(false);
            this.panel_Pet3.ResumeLayout(false);
            this.panel_AbilityInfo.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.nud_waitTime)).EndInit();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pb_Logo;
        private System.Windows.Forms.ProgressBar prob_Health_Pet1;
        private System.Windows.Forms.Label lb_Pet_Lvl1;
        private System.Windows.Forms.Label lb_Pet_Name1;
        private System.Windows.Forms.Label lb_Pet_HP1;
        private System.Windows.Forms.Panel panel_Pet1;
        private System.Windows.Forms.Panel panel_Pet2;
        private System.Windows.Forms.ProgressBar prob_Health_Pet2;
        private System.Windows.Forms.Label lb_Pet_HP2;
        private System.Windows.Forms.Label lb_Pet_Lvl2;
        private System.Windows.Forms.Label lb_Pet_Name2;
        private System.Windows.Forms.Panel panel_Pet3;
        private System.Windows.Forms.ProgressBar prob_Health_Pet3;
        private System.Windows.Forms.Label lb_Pet_HP3;
        private System.Windows.Forms.Label lb_Pet_Lvl3;
        private System.Windows.Forms.Label lb_Pet_Name3;
        private System.Windows.Forms.Label lb_Pet_desc;
        private System.Windows.Forms.Panel panel_AbilityInfo;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label lb_versionText;
        private System.Windows.Forms.Label lb_Ability1_Name;
        private System.Windows.Forms.Button btn_FightInfoForm;
        private System.Windows.Forms.Button btn_import;
        private System.Windows.Forms.Button btn_export;
        private System.Windows.Forms.Button btn_UpdateNow;
        private System.Windows.Forms.Label lb_Ability1_maxCD;
        private System.Windows.Forms.Label lb_Ability1_desc;
        private System.Windows.Forms.CheckBox chb_UpdatesCheck;
        private System.Windows.Forms.TextBox tb_ManualRoutine;
        private System.Windows.Forms.RadioButton rb_Routine_Auto;
        private System.Windows.Forms.RadioButton rb_Routine_Manual;
        private System.Windows.Forms.NumericUpDown nud_waitTime;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label lb_Ability1_PetTyp;
        private System.Windows.Forms.Label lb_Ability2_desc;
        private System.Windows.Forms.Label lb_Ability2_maxCD;
        private System.Windows.Forms.Label lb_Ability2_PetTyp;
        private System.Windows.Forms.Label lb_Ability2_Name;
        private System.Windows.Forms.Label lb_Ability3_desc;
        private System.Windows.Forms.Label lb_Ability3_maxCD;
        private System.Windows.Forms.Label lb_Ability3_Name;
        private System.Windows.Forms.Label lb_Ability3_PetTyp;
        private System.Windows.Forms.CheckBox chb_debug;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.CheckBox chb_useBattle_Wild;
        private System.Windows.Forms.CheckBox chb_useBattle_PvP;
        private System.Windows.Forms.Button btn_ReviveBattlePets;
        private System.Windows.Forms.Button btn_ProfileSettings;
        private System.Windows.Forms.CheckBox chb_NotifyIcon;
        private System.Windows.Forms.CheckBox chb_Trap_All;
        private System.Windows.Forms.CheckBox chb_Trap_inNeed;
        private System.Windows.Forms.Timer timer_Updater;
        private System.Windows.Forms.ProgressBar prob_Update;
        private System.Windows.Forms.Label labelx;
    }
}