﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Globalization;
using Styx.Common;
using System.Diagnostics;
using Styx.WoWInternals.WoWObjects;
using Styx;
using Styx.CommonBot;
using Styx.TreeSharp;
using System.Windows.Forms;
using System.Windows.Media;

using Styx.TreeSharp;
using Action = Styx.TreeSharp.Action;
using CommonBehaviors;
using Styx.CommonBot.Routines;
using Styx.Pathing;
using Styx.WoWInternals;
using CommonBehaviors.Actions;
using Bots.Gatherbuddy;

namespace PetFighter
{
    public class PetFighter : BotBase
    {
        #region Nothing to see here!
        public readonly Version _Version = new Version(0, 8, 015);
        public override string Name { get { return "宠物对战"; } }
        public override PulseFlags PulseFlags { get { return PulseFlags.All; } }
        public override Form ConfigurationForm { get { return new ConfigFormStarter(); } }
        #endregion

        #region variables

        private Composite _root;
        private static LocalPlayer Me { get { return StyxWoW.Me; } }
        public string ForumLink = "http://www.thebuddyforum.com/honorbuddy-forum/plugins/uncataloged/81211-botbase-petfighter-your-honorbuddy-bot-petbattle.html";
        bool startUp = true;
        private Stopwatch waitTimer = new Stopwatch();
        //public WoWSpell ReviveBattlePets = WoWSpell.FromId(125439);
        public WoWSpell ReviveBattlePets;
        private DateTime startTime = DateTime.Now;

        public static PetFighter Instance;
        public PetFighter()
        { Instance = this; }
        #endregion

        #region sloging
        public void slog(Color color, string format, params object[] args)
        { Logging.Write(color, Name.Split(' ')[0] + ": " + format, args); }

        public void slog(string format, params object[] args)
        { slog(Colors.Goldenrod, format, args); }

        string oldStatus = string.Empty;
        public void dlog(string format, params object[] args)
        {
            if (PetFighterSettings.Instance.UseDebug && string.Format(format, args) != oldStatus)
            {
                CultureInfo oldCI = Thread.CurrentThread.CurrentCulture;
                Thread.CurrentThread.CurrentCulture = new CultureInfo("de-DE");
                Logging.Write(Colors.Red, DateTime.Now.ToLongTimeString() + " " + Name.Split(' ')[0] + ": " + format, args);
                Thread.CurrentThread.CurrentCulture = oldCI;
            }
        }

        public void dlog(string title, string format, params object[] args)
        { dlog("Error: " + title + "\n\n" + format + "\n\n", args); }

        public void flog(bool newBattle, string format, params object[] args)
        { CombatRoutineHelpers.flog(newBattle, string.Format(format, args)); }
        #endregion

        //public override void Initialize()
        //{
        //    //Styx.CommonBot.Profiles.ProfileManager.CurrentProfile.GrindArea.CycleToNearest();
        //}

        public override void Start()
        {
            if (PetFighterSettings.Instance.FirstStart)
                FirstStart();

            //BotEvents.OnBotStop += stopBot;
            //BotEvents.OnBotStart += startBot;
            //System.Media.SystemSounds.Asterisk.Play();

            slog("Remember that this is a Alpha version and maybe even still has some bugs, also many features are not available!");
            slog("");
            slog("will start .. please wait ..");

            startTime = DateTime.Now;
            ReviveBattlePets = WoWSpell.FromId(125439);
            waitTimer.Reset();
            ProfileHelper.Initialize();

            if (PetFighterSettings.Instance.ManualRoutine == null || PetFighterSettings.Instance.ManualRoutine.Length == 0)
                PetFighterSettings.Instance.ManualRoutine = new string[] { "1", "2", "1", "3" };

            TimeSpan ts = (DateTime.Now - PetFighterSettings.Instance.CeckForUpdatesDateTime);
            if (ts.TotalHours >= 12)
            {
                slog("Checking for Updates..");
                checkUpdates();
            }
        }

        public override void Stop()
        {
            double _static1 = (CombatRoutineHelpers.Battle_WON + CombatRoutineHelpers.Battle_lost) / ((DateTime.Now - startTime).TotalMinutes / 60);
            double _static2 = (CombatRoutineHelpers.Battle_WON) / ((DateTime.Now - startTime).TotalMinutes / 60);
            slog("");
            slog("#####################");
            slog("stopped after [{0}]", (DateTime.Now - startTime).ToString().Remove(8));
            slog("");
            slog("Statistics:");
            slog("胜利: {0}", CombatRoutineHelpers.Battle_WON);
            slog("失败: {0}", CombatRoutineHelpers.Battle_lost);
            slog("平均 {0} 次/h", _static1.ToString().Split(',')[0]);
            slog("平均 {0} 奖励/h", _static2.ToString().Split(',')[0]);
            slog("");
            slog("#####################");
            slog("");
        }

        public override Composite Root
        {
            get
            {
                return _root ?? (_root =
                    new PrioritySelector(
                        
                        #region <startUp Composite>
                        new Decorator(ret => startUp,
                            new Action(ret => startUp = false)),  

                        new Decorator(ret => Me == null || !StyxWoW.IsInGame || !StyxWoW.IsInWorld,
                            new Sequence(
                                new ActionSetActivity("[INVALID] Waiting.."),
                                new Action(ret => dlog("[INVALID] Waiting..")),
                                new ActionWaitForLuaEvent("", 5))),

                        new Decorator(ret => Me.IsDead || Me.IsGhost, 
                            new Sequence(
                                new ActionSetActivity("[Death] .."),
                                new Action(ret => dlog("[Death] CreateDeathBehavior")),
                                Bots.Grind.LevelBot.CreateDeathBehavior() )),

                        new Decorator(ret => Me.OnTaxi || Me.IsOnTransport,
                            new Sequence(
                                new ActionSetActivity("[On Taxi] Waiting.."),
                                new Action(ret => dlog("[On Taxi] Waiting..")),
                                new ActionWaitForLuaEvent("", 10))),

                        new Decorator(ret => Me.Combat && !Me.Mounted && !PetBattle.IsInPetBattle,
                            new Sequence(
                                new ActionSetActivity("[Combat] Fighting.."),
                                new Action(ret => dlog("[Combat] Fighting..")),
                                new PrioritySelector(
                                    new Decorator(ret => RoutineManager.Current.NeedHeal,
                                        RoutineManager.Current.HealBehavior),
                                    new Decorator(ret => RoutineManager.Current.NeedCombatBuffs,
                                        RoutineManager.Current.CombatBuffBehavior),
                                    new Decorator(ret => Me.GotTarget && (Me.CurrentTarget.IsPetBattleCritter || Me.CurrentTarget.IsFriendly || Me.CurrentTarget.IsDead),
                                        new Action(ret => Me.ClearTarget())),
                                    new Decorator(ret => Me.GotTarget && !Me.CurrentTarget.IsFriendly,
                                        RoutineManager.Current.CombatBehavior) ))),

                        new Decorator(ret => RoutineManager.Current.NeedPreCombatBuffs && !PetBattle.IsInPetBattle,
                            RoutineManager.Current.PreCombatBuffBehavior),

                        new Decorator(ret => RoutineManager.Current.NeedRest && !PetBattle.IsInPetBattle,
                            new Sequence(
                                new ActionSetActivity("[NeedRest] .."),
                                new Action(ret => RoutineManager.Current.Rest() ) 
                                
                            )),
                #endregion

                        #region <MoveToPetBattleCritter>

                        new Decorator(ret => !PetBattle.IsInPetBattle,
                            new PrioritySelector(

                                //TODO no PetBattle - PvP
                                //new Decorator(ret => PetFighterSettings.Instance.PetBattle_PvP, 
                                //    new Action(ret => { })),

                                new Decorator(ret => PetFighterSettings.Instance.PetBattle_Wild,
                                    new PrioritySelector(
                                        new Decorator(ret => !PetBattle.IsInPetBattle && NextPetBattleCritter == null,
                                            new Sequence(
                                                new Action(ret => dlog("[No PetBattle] ..")),
                                                ProfileHelper.CreatePathBehavior()
                                            )),

                                        new Decorator(ret => !PetBattle.IsInPetBattle && NextPetBattleCritter != null,
                                            new Sequence(
                                                new Action(ret => dlog("[Move To PetBattle] ..")),                                
                                                new Decorator(ret => PetBattleSateByName == "wait",
                                                    CreateMoveToPetBattleCritter() )))
                                            ))
                                    )),
                        #endregion
                           
                        #region <IsInPetBattle>

                        new Decorator(ret => PetBattle.IsInPetBattle,
                            new Sequence(
                                new Action(ret => dlog("[In PetBattle] IsWildBattle = {0} - waitTimerRunning = {1} - NewPound = {2}", PetBattle.IsWildBattle, waitTimer.IsRunning, CombatRoutineHelpers.NewRound)),
                                new PrioritySelector(

                                    new Decorator(ret => PetBattleSateByName == "endFight",
                                        new PrioritySelector(
                                            new Decorator(ret => (PetBattle.GetHealthBySlotID_Me(1) + PetBattle.GetHealthBySlotID_Me(2) + PetBattle.GetHealthBySlotID_Me(3)) != 0,
                                                new Sequence(
                                                    new ActionSetActivity("[PetFighter] Battle WON!"),
                                                    new Action(ret => slog("Battle WON!")),
                                                    new Action(ret => CombatRoutineHelpers.Battle_WON++),
                                                    new Action(ret => Thread.Sleep(4000)) )),

                                            new Decorator(ret => (PetBattle.GetHealthBySlotID_Me(1) + PetBattle.GetHealthBySlotID_Me(2) + PetBattle.GetHealthBySlotID_Me(3)) == 0,
                                                new Sequence(
                                                    new ActionSetActivity("[PetFighter] Battle lost..."),
                                                    new Action(ret => slog("Battle lost...")),
                                                    new Action(ret => CombatRoutineHelpers.Battle_lost++),
                                                    new Action(ret => Thread.Sleep(4000)) ))
                                                
                                                )),

                                    new Decorator(ret => PetBattleSateByName == "startFight",
                                    new Action(ret => Thread.Sleep(3000))),

                                    new Decorator(ret => PetBattle.IsWaitingToFight,
                                        new Sequence(
                                            new ActionSetActivity("[PetFighter] Waiting for round start .."),
                                            new Action(ret => slog("Waiting for round start ..")),
                                            //new Wait(2, ret => !CombatRoutineHelpers.NewRound, new ActionIdle()),
                                            new Decorator(ret => CombatRoutineHelpers.NewRound && PetBattle.GetSelectedAction != null,
                                                new Sequence(
                                                    new Action(ret => dlog("[GetSelectedAction] ..")),
                                                    new Action(ret => CombatRoutineHelpers.NewRound = false),
                                                    new Action(ret => waitTimer.Restart()),
                                                    new Action(ret => CombatRoutineHelpers.CreateSelectedAction(PetBattle.GetSelectedAction)),
                                                    new Wait(2, ret => PetBattle.IsWaitingToFight, new ActionIdle())
                                            ))
                                        )),

                                    new Decorator(ret => !PetBattle.IsWaitingToFight,
                                        new PrioritySelector(

                                    new Decorator(ret => !CombatRoutineHelpers.NewRound && !waitTimer.IsRunning,
                                        new Sequence(
                                            //new ActionSetActivity("[PetFighter] wait {0}sec before any action will be taken..", PetFighterSettings.Instance.WaitTime),
                                            new Action(ret => dlog("[waitTimer] start ..")),
                                            new Action(ret => { waitTimer.Reset(); waitTimer.Start(); }),
                                            new Action(ret => CombatRoutineHelpers.NewRound = true)
                                            //new Action(ret => Thread.Sleep(TimeSpan.FromSeconds(PetFighterSettings.Instance.WaitTime)))
                                        )),

                                    new Decorator(ret => PetBattleSateByName == "wait" && waitTimer.IsRunning,
                                        new Sequence(
                                            new ActionSetActivity(string.Format("[PetFighter] wait {0}sec before any action will be taken..", PetFighterSettings.Instance.WaitTime)),
                                            new Action(ret => slog("{0}sec ..", (PetFighterSettings.Instance.WaitTime - waitTimer.Elapsed.Seconds))),
                                            new Decorator(ret => TimeSpan.FromSeconds(PetFighterSettings.Instance.WaitTime - 1) <= TimeSpan.FromMilliseconds(waitTimer.ElapsedMilliseconds),                                                
                                                new Action(ret => { waitTimer.Reset(); waitTimer.Stop(); }))
                                            )),


                                    new Decorator(ret => PetBattle.IsWildBattle && !waitTimer.IsRunning,
                                        new PrioritySelector(

                                            new Decorator(ret => PetBattle.IsTrapAvailable && PetFighterSettings.Instance.TrapIfNeed && !PetBattle.isOwned,
                                                new Sequence(
                                                    new ActionSetActivity("[PetFighter] Trap is Available! Need [{0}], trying to catch..", PetBattle.GetNameByPetID(PetBattle.GetActivePetID_Enemy)),
                                                    new Action(ret => slog("[Trap] Trap is Available! Need Pet, trying to catch..")),
                                                    new Action(ret => PetBattle.UseTrap() ),
                                                    new Wait(2, ret => !PetBattle.IsWaitingToFight, new ActionIdle()) )),

                                            new Decorator(ret => PetBattle.IsTrapAvailable && PetFighterSettings.Instance.TrapAll,
                                                new Sequence(
                                                    new ActionSetActivity("[PetFighter] Trap is Available! Trying to catch [{0}]..", PetBattle.GetNameByPetID(PetBattle.GetActivePetID_Enemy)),
                                                    new Action(ret => slog("[Trap] Trap is Available! Trying to catch..")),
                                                    new Action(ret => PetBattle.UseTrap() ),
                                                    new Wait(2, ret => !PetBattle.IsWaitingToFight, new ActionIdle()) ))
                                            )),

                                    new Decorator(ret => PetBattleSateByName == "wait" && !waitTimer.IsRunning,
                                        CreateCombatRoutines() )


                                        )))))
                        #endregion
));
            }
        }



        private Composite CreateCombatRoutines()
        {
            return new Sequence(
                    new Action(ret => dlog("[CreateCombatRoutines] ..")),
                    //new ActionSetActivity("[PetFighter] wait {0}sec before any action will be taken..", PetFighterSettings.Instance.WaitTime),
                    //new Action(ret => slog("wait {0}sec before any action will be taken..", PetFighterSettings.Instance.WaitTime)),
                    //new Action(ret => Thread.Sleep(TimeSpan.FromSeconds(PetFighterSettings.Instance.WaitTime))),
                    new PrioritySelector(

                        new Decorator(ret => CombatRoutineHelpers.Round == 0 && !PetBattle.IsWildBattle,
                            new Sequence(
                                new ActionSetActivity("[PetFighter] (PvP Battle) StartFight, change Pet to {0} ..", PetFighterSettings.Instance.StartPetSlotID), //TODO Namen schreiben
                                new Action(ret => slog("(PvP Battle) StartFight, change Pet to {0} ..", PetFighterSettings.Instance.StartPetSlotID)), //TODO Namen schreiben
                                new Action(ret => dlog("[PvP Battle] start fight.. change Pet to {0} ..", PetFighterSettings.Instance.StartPetSlotID)),
                                new Action(ret => PetBattle.ChangePetBySlotID(PetFighterSettings.Instance.StartPetSlotID)),
                                new Action(ret => CombatRoutineHelpers.Round = 1) )),

                        new Decorator(ret => CombatRoutineHelpers.Round == 0 && PetBattle.IsWildBattle,
                            new Sequence( 
                                new ActionSetActivity("[PetFighter] (Wild Battle) StartFight .."),
                                new Action(ret => slog("(Wild Battle) StartFight ..")),
                                new Action(ret => CombatRoutineHelpers.CreateSelectedAction(null)) )),

                        new Decorator(ret => PetFighterSettings.Instance.UseManualRoutines,
                            new Sequence(
                                new Action(ret => dlog("[PetBattle] Use Manual Routine..")),
                                new PrioritySelector(

                                    new Decorator(ret => PetFighterSettings.Instance.ManualRoutine == null || PetFighterSettings.Instance.ManualRoutine.ToList<string>().Count == 0
                                    || (PetFighterSettings.Instance.ManualRoutine.ToList<string>().Count == 1 && PetFighterSettings.Instance.ManualRoutine.ToList<string>()[0].Length >= 2),
                                        new Action(ret => { dlog("[StopBot] no correct ManualRoutin available! Go to the settings and add a CombatRoutine like: 1-2-1-3"); 
                                                            TreeRoot.Stop("no correct ManualRoutin available!"); })),

                                    new Decorator(ret => CombatRoutineHelpers.Round > PetFighterSettings.Instance.ManualRoutine.ToList<string>().Count,
                                        new Action(ret => CombatRoutineHelpers.Round = 1)),

                                    new Decorator(ret => PetBattle.GetHealthBySlotID_Me(1) == 0 && PetBattle.GetHealthBySlotID_Me(2) != 0,
                                        new Sequence(
                                            new ActionSetActivity("[PetFighter] Pet 1 is death.. change to Pet 2.."),
                                            new Action(ret => slog("Pet 1 is death.. change to Pet 2..")),
                                            new Action(ret => PetBattle.ChangePetBySlotID(2))
                                        )),

                                    new Decorator(ret => true,
                                        new Sequence(
                                            new ActionSetActivity("[PetBattle] [ManualRoutine] press button {0}", Convert.ToInt32(PetFighterSettings.Instance.ManualRoutine[CombatRoutineHelpers.Round - 1])), //TODO Name ausgeben
                                            new Action(ret => slog("[ManualRoutine] press button {0}", Convert.ToInt32(PetFighterSettings.Instance.ManualRoutine[CombatRoutineHelpers.Round - 1]))),
                                            new Action(ret => PetBattle.UseAbilityByKeyNum(Convert.ToInt32(PetFighterSettings.Instance.ManualRoutine[CombatRoutineHelpers.Round - 1]) )),
                                            new Action(ret => CombatRoutineHelpers.Round++) )),
                                            new Wait(3, ret => !PetBattle.IsWaitingToFight, new ActionIdle())
                                ))),



                        new Decorator(ret => CombatRoutineHelpers.needHeal,
                             new Action(ret => CombatRoutineHelpers.useHealAbility() )),

                        new Decorator(ret => CombatRoutineHelpers.KeepOnCD,
                            new Action(ret => CombatRoutineHelpers.CreateKeepOnCD()))


                             //TODO (pull) -> (manualRoutine) -> pet vergleich -> needHeal -> lowHealthSwitch -> enemyHealth>meHealth -> keepOnCD -> standart
                    ));
        }

        private Composite CreateMoveToPetBattleCritter()
        {
            return new Sequence(
                    //new Action(ret => dlog("Composit CreateMoveToPetBattleCritter - dis: {0}", Me.Location.Distance(NextPetBattleCritter.Location))),
                    new PrioritySelector(

                        new Decorator(ret => Me.Location.Distance(NextPetBattleCritter.Location) <= 12.5,
                            new PrioritySelector(

                                new Decorator(ret => Me.Mounted,
                                    new Sequence(
                                        new ActionSetActivity("[PetFighter] Dismount .."),
                                        new Action(ret => dlog("[Dismount] mounted = {0}", Me.Mounted)),
                                        new Action( ret => Lua.DoString("Dismount()")),
                                        new Wait( 3, ret => Me.Mounted || Me.IsFalling, new ActionIdle()) )),

                                new Decorator(ret => !Me.Mounted && !Me.IsFalling,
                                    new Sequence(
                                        new Action(ret => CombatRoutineHelpers.Round = 0 ),
                                        new ActionSetActivity("[PetFighter] Interact .."),
                                        new Action(ret => dlog("[Interact] ..")),
                                        //new Action(ret => dlog("[Interact] {0} ", PetBattleCritter.Name)),
                                        new Action(ret => NextPetBattleCritter.Interact()),
                                        new Wait(2, ret => !PetBattle.IsInPetBattle, new ActionIdle()) 
                                        //new Wait( 2, ret => PetBattleSateByName != "startFight", new ActionIdle())    
                                   ))
                                )),

                        new Decorator(ret => StyxWoW.Me.Location.Distance(NextPetBattleCritter.Location) > 12.5,
                            new Sequence(
                                new Action(ret => dlog("[Move To] mounted = {0}", Me.Mounted)),
                                new PrioritySelector(

                                    new Decorator(ret => Me.Mounted,
                                        new Sequence(
                                            new ActionSetActivity("[PetFighter] FlyTo Pet dis: {0}", Me.Location.Distance(NextPetBattleCritter.Location)),
                                            new Action(ret => dlog("[FlyTo] Pet dis: {0}", Me.Location.Distance(NextPetBattleCritter.Location))),
                                            new Action(ret => Flightor.MoveTo(NextPetBattleCritter.Location))                                        
                                        )),

                                    new Decorator(ret => !Me.Mounted && StyxWoW.Me.Location.Distance(NextPetBattleCritter.Location) <= 30 && Navigator.CanNavigateFully(Me.Location, NextPetBattleCritter.Location) != null,
                                        new Sequence(
                                            new ActionSetActivity("[PetFighter] MoveTo Pet dis: {0}", Me.Location.Distance(NextPetBattleCritter.Location)),
                                            new Action(ret => dlog("[MoveTo] Pet dis: {0}", Me.Location.Distance(NextPetBattleCritter.Location))),
                                            new Action(ret => Navigator.MoveTo(NextPetBattleCritter.Location))
                                        )),

                                    CreateMountUpBehavior
                        )))
                    ));
        }

        public Decorator CreateMountUpBehavior
        {
            get
            {
                return new Decorator(ret => !Me.Mounted,
                        new Sequence(
                            new ActionSetActivity("[PetFighter] MountUp .."),
                            new Action(ret => dlog("[MountUp] ..")),
                            new Action(ret => Flightor.MountHelper.MountUp()),
                            new Wait(2, ret => !Me.Mounted, new ActionIdle()))
                            );
            }
        }

        private WoWUnit NextPetBattleCritter
        {
            get
            {
                if (startUp)
                { return ObjectManager.GetObjectsOfType<WoWUnit>().FirstOrDefault(); }
                
                WoWUnit _PetBattleCritter = null;
                foreach (WoWUnit unit in ObjectManager.GetObjectsOfType<WoWUnit>())
                {
                    if (!unit.IsDead && unit.IsPetBattleCritter && unit.IsOutdoors)
                        if (_PetBattleCritter == null)
                            _PetBattleCritter = unit;
                        else if (Me.Location.Distance(unit.Location) < Me.Location.Distance(_PetBattleCritter.Location))
                            _PetBattleCritter = unit;
                }
                //if (_PetBattleCritter != null && Me.CurrentTarget != _PetBattleCritter)
                //    _PetBattleCritter.Target();
                return _PetBattleCritter;
            }
        }

        /// <summary>
        /// ("startFight", "endFight" oder "wait")
        /// </summary>
        private string PetBattleSateByName
        {
            // 2 = fight start
            // 3 = waiting... ?!
            // 7 = fight ende
            get
            {
                string _State = PetBattle.PetBattleState.ToString();

                switch (_State)
                {
                    case "2":
                        _State = "startFight";
                        break;
                    case "7":
                        _State = "endFight";
                        break;
                    default:
                        if (_State != "3")
                            Styx.Common.Logging.Write(System.Windows.Media.Colors.Red, "NEW BattleState \n  state = {0}", _State);
                        _State = "wait";
                        break;
                }

                return _State;
            }
        }

        private void checkUpdates()
        {
            try
            {
                System.Net.WebClient wClient = new System.Net.WebClient();
                string strSource = wClient.DownloadString("http://shutup.googlecode.com/svn/trunk/version/PetFighter_Version.txt");
                Version _v = new Version(strSource);

                if (_v != _Version)
                {
                    System.Media.SystemSounds.Question.Play();
                    slog("a new version is available!");
                    PetFighterSettings.Instance.NewUpdates = true;

                    string _msg = string.Format("a new version is available! \n Version: {0} Alpha \nDo you want to visit the forum now?", strSource);

                    if (MessageBox.Show(_msg, "[PetFighter]", MessageBoxButtons.OKCancel) == DialogResult.OK)
                    { System.Diagnostics.Process.Start(ForumLink); PetFighterSettings.Instance.NewUpdates = false; }
                }

                PetFighterSettings.Instance.CeckForUpdatesDateTime = DateTime.Now;
                //var dt = PetFighterSettings.Instance.CeckForUpdatesDateTime;
                //lb_lastCheck.Text = string.Format("last check: {0} - ({1})", dt.ToShortDateString(), dt.ToShortTimeString());
            }
            catch (Exception ex)
            {
                MessageBox.Show(string.Format("VersionCheck Error \n\n{0}", ex), "Error", MessageBoxButtons.OK);
            }
        }

        public void FirstStart()
        {
            string text =
@"
宠物对战

";
            MessageBox.Show(text, "Info", MessageBoxButtons.OK);

            PetFighterSettings.Instance.FirstStart = false;
        }

        #region convertToIcon
        /// <summary>
        /// convert a Image to Icon
        /// </summary>
        /// <param name="image">Image file</param>
        /// <param name="color">Make Transparent</param>
        /// <returns>the Image as Icon</returns>
        public System.Drawing.Icon convertToIcon(System.Drawing.Image image, System.Drawing.Color color)
        {
            System.Drawing.Bitmap _bitmap = (System.Drawing.Bitmap)image;
            if (color != System.Drawing.Color.Empty)
                _bitmap.MakeTransparent(color);
            System.IntPtr _intPtr = _bitmap.GetHicon();
            System.Drawing.Icon _icon = System.Drawing.Icon.FromHandle(_intPtr);
            return _icon;
        }
        #endregion
    }
}
