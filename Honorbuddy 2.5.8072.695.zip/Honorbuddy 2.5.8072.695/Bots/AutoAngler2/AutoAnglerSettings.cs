﻿using System.ComponentModel;
using Styx.Helpers;

namespace HighVoltz
{
    public class AutoAnglerSettings : Settings
    {
        public AutoAnglerSettings(string path) : base(path)
        {
            Instance = this;
            Load();
        }

        public static AutoAnglerSettings Instance { get; private set; }

        [Setting, Styx.Helpers.DefaultValue(0u),
         Description("遇怪反击要切换的主手武器"), Category("武器")]
        public uint MainHand { get; set; }

        [Setting, Styx.Helpers.DefaultValue(0u),
         Description("遇怪反击要切换的副手武器"),
         Category("武器")]
        public uint OffHand { get; set; }

        [Setting, Styx.Helpers.DefaultValue(true),
         Description("True为寻找渔点钓鱼，False为原地定点钓鱼"), Category("钓鱼")]
        public bool Poolfishing { get; set; }

        [Setting, Styx.Helpers.DefaultValue(PathingType.Circle),
         Description(
             "Circle意为1-2-3-4-1-2-3-4如此循环，Bounce意为1-2-3-4-3-2-1如此循环"),
         Category("钓鱼")]
        public PathingType PathingType { get; set; }

        [Setting, Styx.Helpers.DefaultValue(true),
         Description("True为使用飞行坐骑，False为使用地面坐骑")
        , Category("钓鱼")]
        public bool Fly { get; set; }

        [Setting, Styx.Helpers.DefaultValue(true),
         Description("True为使用水上行走，包括职业的技能和药剂")
        , Category("钓鱼")]
        public bool UseWaterWalking { get; set; }

        [Setting, Styx.Helpers.DefaultValue(false),
         Description(
             "True为避免在岩浆此类危险地方着陆.一些只能站在冰块上的渔点也会被加入黑名单")
        , Category("钓鱼")]
        public bool AvoidLava { get; set; }

        [Setting, Styx.Helpers.DefaultValue(5),
         Description("在一个渔点的最大尝试失败时间，超过该时间此次运行将屏蔽")
        , Category("高级设置")]
        public int MaxTimeAtPool { get; set; }

        [Setting, Styx.Helpers.DefaultValue(15),
         Description("在一个渔点的最大尝试失败次数，超过该次数将会去下一个渔点")
        , Category("高级设置")]
        public int MaxFailedCasts { get; set; }


        [Setting, Styx.Helpers.DefaultValue(15f),
         Description("When bot is within this distance from current hotspot then it cycles to next hotspot. flymode only")
        , Category("Advanced")]
        public float PathPrecision { get; set; }

        [Setting, Styx.Helpers.DefaultValue(false),
         Description("True为抢其他玩家钓的渔点（感谢外国留学生告知Ninja其他含义.")
        , Category("钓鱼")]
        public bool NinjaNodes { get; set; }

        [Setting, Styx.Helpers.DefaultValue(40),
         Description(
             "360度的区域里越高越有可能找到一个着陆点，建议设置在20以上"
             )
        , Category("高级设置")]
        public int TraceStep { get; set; }

        [Setting, Styx.Helpers.DefaultValue(10),
         Description("站于距离渔点的最小范围, 建议10-14码")
        , Category("高级设置")]
        public int MinPoolRange { get; set; }

        [Setting, Styx.Helpers.DefaultValue(20),
         Description(
             "站于距离渔点的范围, 22码是最远距离. 建议18-22码，20码是最好距离))"
             )
        , Category("高级设置")]
        public int MaxPoolRange { get; set; }

        [Setting, Styx.Helpers.DefaultValue(0.5f),
         Description(
             "尝试寻找渔点钓鱼着陆点的最大次数"
             )
        , Category("高级设置")]
        public float PoolRangeStep { get; set; }

        [Setting, Styx.Helpers.DefaultValue("")]
        public string LastLoadedProfile { get; set; }

        [Setting, Styx.Helpers.DefaultValue(false),
         Description("True为拾取所有可拾取的物品")]
        public bool LootNPCs { get; set; }

        [Setting, Styx.Helpers.DefaultValue(0)]
        public int CurrentRevision { get; set; }
    }
}