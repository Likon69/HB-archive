﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing;
using Styx.Helpers;
using Styx.Common;

namespace Glue
{
    public static class Utils
    {
        public static Color LogColour = Color.Cyan;
        public static string PreText = "[Glue - Movement] ";

        public static void Write(string Value, params object[] args)
        {
            Value = string.Format(Value, args);

            Logging.Write(PreText + Value);
            Logging.Write(PreText + Value);
        }

        public static void WriteDebug(string Value, params object[] args)
        {
            Value = string.Format(Value, args);

            Logging.Write(PreText + Value);
        }

       /* public static void DoStats()
        {
            // Just some stats
            WebBrowser WBrowser = new WebBrowser();
            WBrowser.Navigate("http://swiny.net/glue/stats.php");
        }*/
    }
}
