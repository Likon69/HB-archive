﻿namespace PluginTidyBags3
{
    using Styx;
    using Styx.Common;
    using Styx.Common.Helpers;
	using Styx.CommonBot;
    using Styx.CommonBot.Frames;
    using Styx.CommonBot.Inventory;
    using Styx.CommonBot.Profiles;
    using Styx.Helpers;
    using Styx.Pathing;
    using Styx.Plugins;
    using Styx.WoWInternals;
	using Styx.WoWInternals.Misc;
	using Styx.WoWInternals.World;
    using Styx.WoWInternals.WoWObjects;

    using System;
    using System.Collections.Generic;
	using System.ComponentModel;
	using System.Data;
    using System.Diagnostics;
    using System.Drawing;
    using System.IO;
    using System.Linq;
	using System.Reflection;
    using System.Runtime.InteropServices;
    using System.Text;
    using System.Threading;
    using System.Windows.Forms;
    using System.Windows.Media;
    using System.Xml.Linq;

    public class TidyBags3 : HBPlugin
    {
        public override string Name { get { return "TidyBags 背包物品自动合成"; } }
        public override string Author { get { return "Damon Modified"; } }
        public override Version Version { get { return new Version(3,6,3,7); } }
		public bool InventoryCheck = false;
		private bool _init;

        public override void Initialize()
        {
            if (_init) return;
            base.Initialize();
			Lua.DoString("SetCVar('AutoLootDefault','1')");
			Lua.Events.AttachEvent("LOOT_CLOSED", LootFinished);
			Lua.Events.AttachEvent("MAIL_CLOSED", MailboxFinished);
            Logging.Write(LogLevel.Normal, Colors.Lime, "HBrelog.Damon提示您:TidyBags 3.6 启用");
            _init = true;
        }

        private void LootFinished(object sender, LuaEventArgs args)
        {
            if (InventoryCheck == false)
            {
                InventoryCheck = true;
            }
        }

		private void MailboxFinished(object sender, LuaEventArgs args)
        {
            if (InventoryCheck == false)
            {
                InventoryCheck = true;
            }
        }

        private HashSet<uint> _itemUseOnOne = new HashSet<uint>() {
		    45072,  // Brightly Color Egg
            113768,  // Brightly Colored Egg
            3352,  // Ooze-covered Bag
            6351,  // Dented Crate
            6352,  // Waterlogged Crate
            6353,  // Small Chest
            6356,  // Battered Chest
            6357,  // Sealed Crate
            5523,  // Small Barnacled Clam
            5524,  // Thick-shelled Clam
            7973,  // Big-mouth Clam
            13874, // Heavy Crate
            20708, // Tightly Sealed Trunk
            20766, // Slimy Bag
            20767, // Scum Covered Bag
            20768, // Oozing Bag
            21113, // Watertight Trunk
            21150, // Iron Bound Trunk
            21228, // Mithril Bound Trunk
            21746, // Lucky Red Envelope (Lunar Festival item)
            24476, // Jaggal Clam
            24881, // Satchel of Helpful Goods (5-15 1st)
            24889, // Satchel of Helpful Goods (5-15 others)
            24882, // Satchel of Helpful Goods (15-25 1st)
            24890, // Satchel of Helpful Goods (15-25 others)
            27481, // Heavy Supply Crate
            27511, // Inscribed Scrollcase
            27513, // Curious Crate
            32724, // Sludge Covered Object
			35792, // Mage Hunter Personal Effects
            35945, // Brilliant Glass (Daily Cooldown for Jewelcrafting - The Burning Crusade Edition)
            36781, // Darkwater Clam
            44475, // Reinforced Crate
            44663, // Abandoned Adventurer's Satchel
            44700, // Brooding Darkwater Clam
			45072, // Brightly Colored Egg (Noble Garden Event)
            45909, // Giant Darkwater Clam
            51999, // Satchel of Helpful Goods (iLevel 25)
            52000, // Satchel of Helpful Goods (31)
            52001, // Satchel of Helpful Goods (41)
            52002, // Satchel of Helpful Goods (50)
            52003, // Satchel of Helpful Goods (57)
            52004, // Satchel of Helpful Goods (62)
            52005, // Satchel of Helpful Goods (66)
            52340, // Abyssal Clam
            61387, // Hidden Stash
            62242, // Icy Prism (Daily Cooldown for Jewelcrafting - Wrath Edition)
            64657, // Canopic Jar (Archaeology Tol'vir relic)
            67248, // Satchel of Helpful Goods (39)
            67250, // Satchel of Helpful Goods (85)
            67495, // Strange Bloated Stomach (Cataclysm Skinning)
            67539, // Tiny Treasure Chest
            67597, // Sealed Crate (level 85 version)
            69903, // Satchel of Exotic Mysteries (LFD - Extra Reward)
			72201, // Plump Intestines (MoP Skinning)
            73478, // Fire Prism (Daily Cooldown for Jewelcrafting - Cataclysm Edition)
            78890, // Crystalline Geode (Dragon Soul Raid - Normal 10/25 every bossloot)
            78891, // Elementium-Coated Geode (Dragon Soul Raid - Normal 10/25 Deathwing Kill)
            78892, // Perfect Geode (Dragon Soul Raid - Heroic Hardmode 10/25 Deathwing Kill)
            78897, // Pouch o' Tokens (5 Darkmoon Faire Game Coins)
            78898, // Sack o' Tokens (20 Darkmoon Faire Game Coins)
            78899, // Pouch o' Tokens (5 Darkmoon Faire Game Coins)
            78900, // Pouch o' Tokens (5 Darkmoon Faire Game Coins)
            78901, // Pouch o' Tokens (5 Darkmoon Faire Game Coins)
            78902, // Pouch o' Tokens (5 Darkmoon Faire Game Coins)
            78903, // Pouch o' Tokens (5 Darkmoon Faire Game Coins)
            78905, // Sack o' Tokens (20 Darkmoon Faire Game Coins)
            78906, // Sack o' Tokens (20 Darkmoon Faire Game Coins)
            78907, // Sack o' Tokens (20 Darkmoon Faire Game Coins)
            78908, // Sack o' Tokens (20 Darkmoon Faire Game Coins)
            78909, // Sack o' Tokens (20 Darkmoon Faire Game Coins)
            78930, // Sealed Crate (around the Darkmoon Faire Island)
			79896, // Pandaren Tea Set (Archaeology)
			79897, // Pandaren Game Board (Archaeology)
			79898, // Twin Stein Set (Archaeology)
			79899, // Walking Cane (Archaeology)
			79900, // Empty Keg (Archaeology)
			79901, // Carved Bronze Mirror (Archaeology)
			79902, // Gold-Inlaid Figurine (Archaeology)
			79903, // Apothecary Tins (Archaeology)
			79904, // Pearl of Yu'lon (Archaeology)
			79905, // Standard of Niuzao (Archaeology)
			79908, // Manacles of Rebellion (Archaeology)
			79909, // Cracked Mogu Runestone (Archaeology)
			79910, // Terracotta Arm (Archaeology)
			79911, // Petrified Bone Whip (Archaeology)
			79912, // Thunder King Insignia (Archaeology)
			79913, // Edicts of the Thunder King (Archaeology)
			79914, // Iron Amulet (Archaeology)
			79915, // Warlord's Branding Iron (Archaeology)
			79916, // Mogu Coin (Archaeology)
			79917, // Worn Monument Ledger (Archaeology)
			87391, // Plundered Treasure (Luck of the Lotus Buff)
			88496, // Sealed Crate (MoP version)
			89610, // Pandaria Herbs (Trade for Spirit of Harmony)
			89613, // Cache of Treasures (Scenario Reward)
			89810, // Bounty of a Sundered Land (LFR Bonus Roll Gold Reward)
			90625, // Treasures of the Vale (Daily Quest Reward)
			90716, // Good Fortune (When using a Lucky Charm on a boss for loot)
			90839, // Cache of Sha-Touched Gold (World Boss gold drop)
			90840, // Marauder's Gleaming Sack of Gold (World Boss gold drop)
			92813, // Greater Cache of Treasures (Scenario Reward)
			92960, // Silkworm Cocoon (Tailoring Imperial Silk)
			94219, // Arcane Trove (Daily Quest Reward IoTK Alliance)
			94220, // Sunreaver Bounty (Daily Quest Reward IoTK Horde)
			94296, // Cracked Primal Egg
			94566, // Fortuitous Coffer (Loot Item IoTK)
			95343, // Treasures of the Thunder King (LFR Loot)
			95601, // Shiny Pile of Refuse (World Boss drop)
			95602, // Stormtouched Cache (World Boss drop)
			95617, // Dividends of the Everlasting Spring (LFR Loot)
			95618, // Cache of Mogu Riches (LFR Loot)
			95619, // Amber Encased Treasure Pouch (LFR Loot)
			98096, // Large Sack of Coins (Brawler Fight Reward)
			98097, // Huge Sack of Coins (Brawler Fight Reward)
			98098, // Bulging Sack of Coins (Brawler Fight Reward)
			98099, // Giant Sack of Coins (Brawler Fight Reward)
			98100, // Humongous Sack of Coins (Brawler Fight Reward)
			98101, // Enormous Sack of Coins (Brawler Fight Reward)
			98102, // Overflowing Sack of Coins (Brawler Fight Reward)
			98103, // Gigantic Sack of Coins (Brawler Fight Reward)
			98133, // Greater Cache of Treasures (Scenario Reward)
			98134, // Heroic Cache of Treasures (Heroic Scenario Reward)
			98560, // Arcane Trove (Vendor Version Alliance)
			98562, // Sunreaver Bounty (Vendor Version Horde)
			139776,// Banner of the Mantid Empire (Archaeology)
			139779,// Ancient Sap Feeder (Archaeology)
			139780,// The Praying Mantid (Archaeology)
			139781,// Inert Sound Beacon (Archaeology)
			139782,// Remains of a Paragon (Archaeology)
			139783,// Mantid Lamp (Archaeology)
			139784,// Pollen Collector (Archaeology)
			139785 // Kypari sap Container (Archaeology)
        };

        private HashSet<uint> _itemUseOnThree = new HashSet<uint>() {
			10938, // Lesser Magic Essence
			10998, // Lesser Astral Essence
			11134, // Lesser Mystic Essence
			11174, // Lesser Nether Essence
			16202, // Lesser Eternal Essence
			22447, // Lesser Planar Essence
			34053, // Small Dream Shard
			34056, // Lesser Cosmic Essence
			52718, // Lesser Celestial Essence
            74252, // Small Ethereal Shard
            52720  // Small Heavenly Shard
        };

        private HashSet<uint> _itemUseOnFive = new HashSet<uint>() {
            33567 // Borean Leather Scraps
        };

        private HashSet<uint> _itemUseOnTen = new HashSet<uint>() {
            22572, // Mote of Air
            22573, // Mote of Earth
            22574, // Mote of Fire
            22575, // Mote of Life
            22576, // Mote of Mana
            22577, // Mote of Shadow
            22578, // Mote of Water
            37700, // Crystallized Air
            37701, // Crystallized Earth
            37702, // Crystallized Fire
            37703, // Crystallized Shadow
            37704, // Crystallized Life
            37705, // Crystallized Water
            49655, // Lovely Charm (Love is in the Air item)
			86547, // Skyshard
			89112, // Mote of Harmony
			90407, // Sparkling Shard (from Prospecting ores)
			97512, // Ghost Iron Nugget
			97546, // Kyparite Fragment
			97619, // Torn Green Tea Leaf
            97620, // Rain Poppy Petal
            97621, // Silkweed Stem
            97622, // Snow Lily Petal
            97623, // Fool's Cap Spores
            97624  // Desecrated Herb Pod
        };

        private HashSet<uint> _itemRequiresSleep = new HashSet<uint>() {
            61387, // Hidden Stash
            67495, // Strange Bloated Stomach (Cataclysm Skinning)
            67539, // Tiny Treasure Chest
			72201, // Plump Intestines (MoP Skinning)
			87391, // Plundered Treasure (Luck of the Lotus Buff)
			88496, // Sealed Crate (MoP version)
			89610, // Pandaria Herbs (Trade for Spirit of Harmony)
			89613, // Cache of Treasures (Scenario Reward)
			89810, // Bounty of a Sundered Land (LFR Bonus Roll Gold Reward)
			90625, // Treasures of the Vale (Daily Quest Reward)
			90716, // Good Fortune (When using a Lucky Charm on a boss for loot)
			90839, // Cache of Sha-Touched Gold (World Boss gold drop)
			90840, // Marauder's Gleaming Sack of Gold (World Boss gold drop)
			92813, // Greater Cache of Treasures (Scenario Reward)
			92960, // Silkworm Cocoon (Tailoring Imperial Silk)
			94219, // Arcane Trove (Daily Quest Reward IoTK Alliance)
			94220, // Sunreaver Bounty (Daily Quest Reward IoTK Horde)
			94296, // Cracked Primal Egg
			94566, // Fortuitous Coffer (Loot Item IoTK)
			95343, // Treasures of the Thunder King (LFR Loot)
			95601, // Shiny Pile of Refuse (World Boss drop)
			95602, // Stormtouched Cache (World Boss drop)
			95617, // Dividends of the Everlasting Spring (LFR Loot)
			95618, // Cache of Mogu Riches (LFR Loot)
			95619, // Amber Encased Treasure Pouch (LFR Loot)
			98096, // Large Sack of Coins (Brawler Fight Reward)
			98097, // Huge Sack of Coins (Brawler Fight Reward)
			98098, // Bulging Sack of Coins (Brawler Fight Reward)
			98099, // Giant Sack of Coins (Brawler Fight Reward)
			98100, // Humongous Sack of Coins (Brawler Fight Reward)
			98101, // Enormous Sack of Coins (Brawler Fight Reward)
			98102, // Overflowing Sack of Coins (Brawler Fight Reward)
			98103, // Gigantic Sack of Coins (Brawler Fight Reward)
			98133, // Greater Cache of Treasures (Scenario Reward)
			98134, // Heroic Cache of Treasures (Heroic Scenario Reward)
			98560, // Arcane Trove (Vendor Version Alliance)
			98562  // Sunreaver Bounty (Vendor Version Horde)
        };

		private HashSet<uint> _destroyItems = new HashSet<uint>() {
			19221, // Darkmoon Special Reserve
			19222, // Cheap Beer
			19223, // Darkmoon Dog
			19224, // Red Hot Wings
			19225, // Deep Fried Candybar
			19299, // Fizzy Faire Drink
			19300, // Bottled Winterspring Water
			19304, // Spiced Beef Jerky
			19305, // Pickled Kodo Foot
			19306, // Crunchy Frog
			21151, // Rumsey Rum Black Label
			44940, // Corn-Breaded Sausage
			44941, // Fresh-Squeezed Limeade
			45188, // Whitered Kelp
			45189, // Torn Sail
			45190, // Driftwood
			45191, // Empty Clam
			45194, // Tangled Fishing Line
			45195, // Empty Rum Bottle
			45196, // Tattered Cloth
			45197, // Tree Branch
			45198, // Weeds
			45199, // Old Boot
			45200, // Sickly Fish
			45201, // Rock
			45202, // Water Snail
			73260, // Salty Sea Dog
			74822  // Sasparilla Sinker
		};

        public override void Pulse()
        {
		if (_init)
            if (StyxWoW.Me.IsActuallyInCombat
                || StyxWoW.Me.Mounted
                || StyxWoW.Me.IsDead
                || StyxWoW.Me.IsGhost
                ) {
                return;
            }

            if (InventoryCheck) { // Loot Event has Finished
                foreach (WoWItem item in ObjectManager.GetObjectsOfType<WoWItem>()) { // iterate over every item
                    if (item != null && item.BagSlot != -1 && StyxWoW.Me.FreeNormalBagSlots >= 1) { // check if item exists and is in bag and we have space
                        if (_itemUseOnOne.Contains(item.Entry)) { // stacks of 1
                            if (item.StackCount >= 1) {
                                this.useItem(item);
                            }
						} else if (_itemUseOnThree.Contains(item.Entry)) { // stacks of 3
                            if (item.StackCount >= 3) {
                                this.useItem(item);
                            }
						} else if (_itemUseOnFive.Contains(item.Entry)) { // stacks of 5
                            if (item.StackCount >= 5) {
                                this.useItem(item);
                            }
                        } else if (_itemUseOnTen.Contains(item.Entry)) { // stacks of 10
                            if (item.StackCount >= 10) {
                                this.useItem(item);
                            }
                        } else if (_destroyItems.Contains(item.Entry)) {
								this.destroyItem(item);
						}
                    }
                }
				InventoryCheck = false;
                StyxWoW.SleepForLagDuration();
            }
        }

        private void useItem(WoWItem item)
        {
            Logging.Write(LogLevel.Normal, Colors.Lime, "[{0} {1}]: 使用 {2} 当前有 {3}", this.Name, this.Version, item.Name, item.StackCount);

            if (_itemRequiresSleep.Contains(item.Entry)) {
                // some (soulbound) items require an additional sleep to prevent a loot bug
                StyxWoW.SleepForLagDuration();
            }
            Lua.DoString("UseItemByName(\"" + item.Name + "\")");
            StyxWoW.SleepForLagDuration();
        }

		private void destroyItem(WoWItem item) 
		{
			Logging.Write(LogLevel.Normal, Colors.Lime, "[{0} {1}]: 摧毁 {2} 当前有 {3}", this.Name, this.Version, item.Name, item.StackCount);
			item.PickUp();
			Lua.DoString("DeleteCursorItem()");
			StyxWoW.SleepForLagDuration();
		}
    }
}