﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using Styx.Common;
using Styx.CommonBot.Inventory;
using Styx.Helpers;
using DefaultValue = Styx.Helpers.DefaultValueAttribute;

namespace Styx.Bot.Plugins.AutoEquip2
{
    public class AutoEquipSettings : Settings
    {
        private static AutoEquipSettings _instance;

        public AutoEquipSettings()
            : base(Path.Combine(Path.Combine(Utilities.AssemblyDirectory, "Settings"), string.Format("AutoEquipSettings_{0}.xml", StyxWoW.Me.Name)))
        {
            if (IgnoreInvTypes == null)
            {
                IgnoreInvTypes = new[] { InventoryType.None};
            }
            if (ProtectedSlots == null)
            {
                ProtectedSlots = new[] { InventorySlot.None };
            }
        }

        public static AutoEquipSettings Instance { get { return _instance ?? (_instance = new AutoEquipSettings()); } }

        #region Category: Item Types

        [Setting]
        [DefaultValue(false)]
        [Category("Item Types")]
        [DisplayName("装备紫色品质物品")]
        [Description("Toggles if AutoEquip should equip purple items.")]
        public bool EquipPurples { get; set; }

        [Setting]
        [DefaultValue(true)]
        [Category("Item Types")]
        [DisplayName("装备蓝色品质物品")]
        [Description("Toggles if AutoEquip should equip blue items.")]
        public bool EquipBlues { get; set; }

        [Setting]
        [DefaultValue(true)]
        [Category("Item Types")]
        [DisplayName("装备绿色品质物品")]
        [Description("Toggles if AutoEquip should equip green items.")]
        public bool EquipGreens { get; set; }

        [Setting] 
        [DefaultValue(true)]
        [Category("Item Types")]
        [DisplayName("装备白色品质物品")]
        [Description("Toggles if AutoEquip should equip white items.")]
        public bool EquipWhites { get; set; }

        [Setting]
        [DefaultValue(false)]
        [Category("Item Types")]
        [DisplayName("装备灰色品质物品")]
        [Description("Toggles if AutoEquip should equip grey items.")]
        public bool EquipGrays { get; set; }

        [Setting]
        [DefaultValue(false)]
        [Category("Item Types")]
        [DisplayName("装备传家宝")]
        [Description("Toggles if AutoEquip should equip heirloom items.")]
        public bool EquipHeirlooms { get; set; }

        [Setting]
        [DefaultValue(true)]
        [Category("BoE Item Types")]
        [DisplayName("装备绿色品质装绑物品")]
        [Description("Toggles if AutoEquip should equip green 'Bind on Equip' items.")]
        public bool EquipBoEGreens { get; set; }

        [Setting]
        [DefaultValue(true)]
        [Category("BoE Item Types")]
        [DisplayName("装备蓝色品质装绑物品")]
        [Description("Toggles if AutoEquip should equip blue 'Bind on Equip' items.")]
        public bool EquipBoEBlues { get; set; }

        [Setting]
        [DefaultValue(false)]
        [Category("BoE Item Types")]
        [DisplayName("装备紫色品质装绑物品")]
        [Description("Toggles if AutoEquip should equip purple 'Bind on Equip' items.")]
        public bool EquipBoEPurples { get; set; }

        #endregion

        #region Category: Protected Slots and Types 

        [Setting]
        [Category("Protected Slots and Types")]
        [DisplayName("指定物品类型保护")]
        [Description("Items with this inventory type will be ignored when looking for new items to equip.")]
        public InventoryType[] IgnoreInvTypes { get; set; }

        [Setting]
        [Category("Protected Slots and Types")]
        [DisplayName("指定部位保护")]
        [Description("InventorySlots of this type will be protected, AutoEquip will never equip new items into theese slots.")]
        public InventorySlot[] ProtectedSlots { get; set; }

        [Setting]
        [DefaultValue(false)]
        [Category("Protected Slots and Types")]
        [DisplayName("更换传家宝")]
        [Description("Toggles if AutoEquip should replace heirlooms.")]
        public bool ReplaceHeirlooms { get; set; }

        #endregion

        #region Category: General

        [Setting]
        [DefaultValue(true)]
        [Category("General")]
        [DisplayName("装备物品")]
        [Description("Toggles if AutoEquip should equip items.")]
        public bool AutoEquipItems { get; set; }

        [Setting]
        [DefaultValue(true)]
        [Category("General")]
        [DisplayName("装备背包")]
        [Description("Toggles if AutoEquip should equip bags.")]
        public bool AutoEquipBags { get; set; }

        [Setting]
        [DefaultValue(false)]
        [Category("General")]
        [DisplayName("包括附魔过的")]
        [Description("Toggles if AutoEquip should include the stats of enchants on items when scoring items.")]
        public bool IncludeEnchants { get; set; }

        [Setting]
        [DefaultValue(WeaponStyle.None)]
        [Category("General")]
        [DisplayName("武器种类")]
        [Description("One hand and a shield为主副手,Dual-wield为双持,Twohandler为双手武器，Ranged为远程武器")]
        public WeaponStyle WeaponStyle { get; set; }

        [Setting]
        [DefaultValue(WeaponType.All)]
        [Category("General")]
        [DisplayName("武器类型")]
        [Description("None无 Axe斧子 Dagger匕首 Fist拳套 Mace锤 Polearms长柄武器 Spear矛 Staff法杖 Bow弓弩枪 All全部")]
        [Editor(typeof(FlagEnumUIEditor), typeof(System.Drawing.Design.UITypeEditor))]
        public WeaponType WeaponType { get; set; }

        #endregion

        #region Category: Loot Rolling

        [Setting]
        [DefaultValue(true)]
        [Category("Loot Rolling")]
        [DisplayName("Roll点获取")]
        [Description("在地下城或团队等与其他玩家组队时是否Roll点赢得装备")]
        public bool RollForLootInDungeons { get; set; }

        #endregion

        #region Category: Disenchanting

        [Setting]
        [DefaultValue(true)]
        [Category("Disenchanting")]
        [DisplayName("Roll点分解")]
        [Description("在Roll装时会尽可能自动选择分解选项")]
        public bool RollForLootDE { get; set; }

        [Setting]
        [DefaultValue(true)]
        [Category("Disenchanting")]
        [DisplayName("Roll点分解绿装")]
        [Description("Toggles if AutoEquip will select disenchant for green items when rolling for loot.")]
        public bool DisenchantBoEGreens { get; set; }

        [Setting]
        [DefaultValue(true)]
        [Category("Disenchanting")]
        [DisplayName("Roll点分解蓝装")]
        [Description("Toggles if AutoEquip will select disenchant for BoP blue items when rolling for loot.")]
        public bool DisenchantBoPBlues { get; set; }

        [Setting]
        [DefaultValue(false)]
        [Category("Disenchanting")]
        [DisplayName("Roll点分解装绑蓝装")]
        [Description("Toggles if AutoEquip will select disenchant for BoE blue items when rolling for loot.")]
        public bool DisenchantBoEBlues { get; set; }

        [Setting]
        [DefaultValue(true)]
        [Category("Disenchanting")]
        [DisplayName("Roll点分解拾绑紫装")]
        [Description("Toggles if AutoEquip will select disenchant for BoP purple items when rolling for loot.")]
        public bool DisenchantBoEPurples { get; set; }

        [Setting]
        [DefaultValue(false)]
        [Category("Disenchanting")]
        [DisplayName("Roll点分解装绑紫装")]
        [Description("Toggles if AutoEquip will select disenchant for BoE purple items when rolling for loot.")]
        public bool DisenchantBoPPurples { get; set; }

        #endregion
    }

    public enum WeaponStyle
    {
        None,
        OneHanderAndShield,
        DualWield,
        TwoHander,
        Ranged
    }

    [Flags]
    public enum WeaponType
    {
        None = 0x0,
        Axe = 0x1,
        Dagger = 0x2,
        Fist = 0x4,
        Mace = 0x8,
        Polearm = 0x10,
        Spear = 0x20,
        Staff = 0x40,
        Sword = 0x80,
        Ranged = 0x100,
        All = Axe | Mace | Sword | Dagger | Polearm | Spear | Staff | Fist | Ranged,
    }
}
