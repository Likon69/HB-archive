﻿using System;
using System.IO;
using System.Linq;
using System.Media;
using System.Threading;
using System.Runtime.InteropServices;

using Styx;
using Styx.Common.Helpers;
using Styx.CommonBot;
using Styx.WoWInternals;
using Styx.Plugins;
//using Styx.Logic;
using Styx.Helpers;
//using Styx.Logic.POI;
using Styx.WoWInternals;
//using Styx.Logic.Profiles;
//using Styx.Plugins.PluginClass;
using Styx.CommonBot.Profiles;
using Styx.WoWInternals.WoWObjects;
using Styx.Common;
using Styx.CommonBot.POI;
namespace RedAlert
{
    public class PlaySounds : HBPlugin
    {
        [DllImport("Kernel32.dll")]
        internal static extern int Beep(uint dwFreq, uint dwDuration);

        /*******************************************
        *                  Config                  *
        *         Edit this section only!          *
        *******************************************/

        /********************************************
         *          Audible Alert Options           *
         *******************************************/
        // Set to 1 to play sound for event, set to 0 to ignore an event.

        // Play sound on level?
        public int SoundOnLevel = 1;

        // Play sound on Death?
        public int SoundOnDeath = 1;

        // Play sound on Whisper?
        public int SoundOnWhisper = 1;

        // Play sound on Say?
        public int SoundOnSay = 1;

        // Play sound when we get disconnected?
        public int SoundOnDisconnect = 1;

        // Play sound when we think we're being followed?
        public int SoundOnPlayerFollowing = 1;

        // If the above option is 0 ignore this setting below ---
        /****************************************************************************************
         * How long do we want to be followed before we alert?                                  *
         * You could do some creative things when not near large cities like set distance       *
         * to 75 and place 5 second timer. You would be alerted before they could click         *
         * you or you could set the distance to shorter with a longer timer to only be          *
         * alerted when someone takes too much interest in you.                                 *
         ***************************************************************************************/
        // !!IMPORTANT!! TimeSpan Format (Hours, Minutes, Seconds) - Default 20 seconds.
        private readonly WaitTimer _playerNearbyTimer = new WaitTimer(new TimeSpan(0, 0, 20));



        /********************************************
         *            Safe botting options          *
         *******************************************/
        // Do we want to detect players following us? 1 for yes - 0 for no
        public int DetectFollowers = 1;

        // If the above option is 0 ignore this next bit.
        // How long do we want them to stay around before we consider them a threat.
        // !!IMPORTANT!! TimeSpan Format (Hours, Minutes, Seconds) - Default 20 seconds.
        private readonly WaitTimer _playerFollowTimer = new WaitTimer(new TimeSpan(0, 0, 20));

        // How far away a player needs to be for us to consider it 'following us'
        public double PlayerDistance = 25;


        /*******************************************
         *  Do not set both of these options to 1  *
         *  one of them must be set to 0. Turning  *
         *  both off is acceptable.                *
         ******************************************/

        // Futhermore would you like to stop botting while this person is around?
        // 1 to stop botting - 0 to continue
        public int ContinueBotting = 1;
        // How long do we wish to wait to see if they go away?
        // !!IMPORTANT!! TimeSpan Format (Hours, Minutes, Seconds) - Default 2 Minutes.
        private readonly WaitTimer _playerWaitTimer = new WaitTimer(new TimeSpan(0, 2, 0));

        // Would we like to vacate the area to go repair when followed? 
        // 1 to go repair - 0 to wait here
        public int GoRepair = 0;
        // How long do we wish to give the bot to repair and sit around?
        // !!IMPORTANT!! TimeSpan Format (Hours, Minutes, Seconds) - Default 5 Minutes.
        private readonly WaitTimer _playerRepairTimer = new WaitTimer(new TimeSpan(0, 5, 0));

        /*******************************************
        *               DO NOT EDIT                *
        *               BELOW HERE!                *
        *******************************************/




        public override string Name { get { return "RedAlert 意外警报提示"; } }
        public override string Author { get { return "Wired420 --- HBrelog"; } }
        public override Version Version { get { return new Version(1, 3); } }
        public override bool WantButton { get { return false; } }
        private readonly LocalPlayer Me = StyxWoW.Me;

        private bool _playerNearby;
        private bool _playerFollow;
        bool _initialized;


        // Setup Sound Players
        private static void PlaySound(string soundFile)
        {
            new SoundPlayer(Path.Combine(System.AppDomain.CurrentDomain.BaseDirectory, @"Plugins\RedAlert\Sounds\") + soundFile).Play();
            Beep(200, 1000);
        }

        public override void Pulse()
        {
            if (!_initialized)
            {
                _initialized = true;
                Initialize();
            }

            if (!_playerWaitTimer.IsFinished)
            {
                SetPOIWait();
            }

            if (!_playerRepairTimer.IsFinished)
            {
                SetPOIRepair();
            }

            if (!StyxWoW.IsInGame)
            {
                if (SoundOnDisconnect == 1)
                {
                    Logging.Write("RedAlert 断开连接.");
                    PlaySound("断开连接.wav");
                }
            }

        }

        private void Initialize()
        {
            Logging.Write("RedAlert 意外警报提示");
            Logging.Write("RedAlert v" + Version + " 版本");
            Logging.Write("HBrelog");

            
            BotEvents.Player.OnLevelUp += HandleLevelUp;
            BotEvents.Player.OnPlayerDied += HandlePlayerDied;

            Chat.Whisper += new Chat.ChatMessageHandlerEx<Chat.ChatWhisperEventArgs>(HandleIncomingWhisper);
            //WoWChat.NewWhisperFromMessage += HandleIncomingWhisper;
            Chat.Say += new Chat.ChatMessageHandlerEx<Chat.ChatLanguageSpecificEventArgs>(HandleIncomingSay);
           // WoWChat.NewSayMessage += HandleIncomingSay;
            //PlaySound("断开连接.wav");
            _playerWaitTimer.Stop();
            _playerRepairTimer.Stop();
        }


        private void HandleRepairItems()
        {
            SetPOIRepair();
        }
        private void HandleIncomingWhisper(Chat.ChatWhisperEventArgs e)
        {
            if (SoundOnWhisper == 1)
            {
                Logging.Write("RedAlert 玩家密语提示");
                PlaySound("玩家密语.wav");
            }
        }

        private void HandleIncomingSay(Chat.ChatLanguageSpecificEventArgs e)
        {
            if (SoundOnSay == 1)
            {
                Logging.Write("RedAlert 玩家附近说话提示");
                PlaySound("附近说话.wav");
            }
        }

        private void HandlePlayerDied()
        {
            if (!Battlegrounds.IsInsideBattleground)
            {
                if (SoundOnDeath == 1)
                {
                    Logging.Write("RedAlert 角色死亡提示");
                    PlaySound("死亡.wav");
                }
            }
        }

        private void HandleLevelUp(BotEvents.Player.LevelUpEventArgs e)
        {
            if (SoundOnLevel == 1)
            {
                Logging.Write("RedAlert 角色升级提示");
                PlaySound("升级.wav");
            }
        }

        private void SetPOIRepair()
        {

            BotPoi.Current = new BotPoi(ProfileManager.CurrentProfile.VendorManager.GetClosestVendor(Vendor.VendorType.Repair), PoiType.Sell);
            if (_playerRepairTimer.IsFinished)
            {
                _playerRepairTimer.Reset();
            }
        }

        private void SetPOIWait()
        {
            BotPoi.Clear();
            if (_playerWaitTimer.IsFinished)
            {
                _playerWaitTimer.Reset();
            }
        }

    }
}