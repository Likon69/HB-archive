﻿#region System Namespace
using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Threading;
using System.Globalization;
using CommonBehaviors.Actions;
#endregion System Namespace

#region Foreign Namespace
#endregion Foreign Namespace

#region Styx Namespace
using Styx;
using Styx.Helpers;
using Styx.Plugins;
using Styx.Common;
using Styx.CommonBot;
using Styx.WoWInternals.WoWObjects;
using Styx.CommonBot.Profiles;
using Styx.Pathing;
using Styx.TreeSharp;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using Tripper.Tools.Math;
using Action = Styx.TreeSharp.Action;
#endregion Styx Namespace


using System.Globalization;
using CommonBehaviors.Actions;




namespace OutCombat
{
    public class OutCombat : HBPlugin
    {
        public override string Name { get { return "【13GM】拉怪插件"; } }
        public override string Author { get { return "Feeling"; } }
        public override Version Version { get { return new Version(1, 1); } }
        public override bool WantButton { get { return true; } }


        public override void Initialize()
        {
            Logging.Write("OutCombat已加载");
        }

public override void Pulse()
        {
            if (StyxWoW.IsInGame)
            {
				if (StyxWoW.Me.Combat && !StyxWoW.Me.IsCasting && !StyxWoW.Me.IsMoving && (StyxWoW.Me.CurrentTarget == null || StyxWoW.Me.CurrentTarget.IsFriendly))
				{
                Lua.DoString("RunMacroText('/targetenemy')");
                KeyboardManager.KeyUpDown((char)KeyboardManager.eVirtualKeyMessages.VK_RIGHT);
                if (StyxWoW.Me.Class == WoWClass.Monk)
                {
					Lua.DoString("RunMacroText('/cast  嚎镇八方')");
                }
                if (StyxWoW.Me.Class == WoWClass.DeathKnight)
                {
					Lua.DoString("RunMacroText('/cast  冰冷触摸')");
                }
				if (StyxWoW.Me.Class == WoWClass.Druid)
                {
					Lua.DoString("RunMacroText('/cast  月火术')");
                }
				if (StyxWoW.Me.Class == WoWClass.Hunter)
                {
					Lua.DoString("RunMacroText('/cast  奥术射击')");
                }
				if (StyxWoW.Me.Class == WoWClass.Mage)
                {
					Lua.DoString("RunMacroText('/cast  火焰冲击')");
                }
				if (StyxWoW.Me.Class == WoWClass.Paladin)
                {
					Lua.DoString("RunMacroText('/cast  审判')");
                }
				if (StyxWoW.Me.Class == WoWClass.Priest)
                {
					Lua.DoString("RunMacroText('/cast  暗言术：痛 ')");
                }
				if (StyxWoW.Me.Class == WoWClass.Rogue)
                {
					Lua.DoString("RunMacroText('/cast  投掷')");
                }
				if (StyxWoW.Me.Class == WoWClass.Shaman)
                {
					Lua.DoString("RunMacroText('/cast  大地震击')");
                }
				if (StyxWoW.Me.Class == WoWClass.Warlock)
                {
					Lua.DoString("RunMacroText('/cast  腐蚀术')");
                }
				if (StyxWoW.Me.Class == WoWClass.Warrior)
                {
					Lua.DoString("RunMacroText('/cast  英勇投掷')");
                }

                }
            }
        }




    }
}