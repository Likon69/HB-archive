﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Numerics;
using System.Reflection;
using System.Threading.Tasks;
using System.Windows.Markup;
using Bots.DungeonBuddy.Attributes;
using Bots.DungeonBuddy.Enums;
using Bots.DungeonBuddy.Helpers;
using Buddy.Coroutines;
using Styx;
using Styx.Common;
using Styx.Common.Helpers;
using Styx.CommonBot;
using Styx.CommonBot.Coroutines;
using Styx.CommonBot.POI;
using Styx.CommonBot.Routines;
using Styx.Helpers;
using Styx.Pathing;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using Styx.WoWInternals.WoWObjects.AreaTriggerShapes;

// ReSharper disable CheckNamespace

/* Commented out because it needs some more testing

namespace Bots.DungeonBuddy.DungeonScripts.Legion
// ReSharper restore CheckNamespace
{
    #region Normal Difficulty

    public class DarkheartThicket : Dungeon
    {
        #region Overrides of Dungeon

        public override uint DungeonId => 1201;

        public override Vector3 Entrance => new Vector3(3831.037f, 6361.867f, 184.8298f);

        public override Vector3 ExitLocation => new Vector3(3265.236f, 1831.2f, 239.9943f);

        public override void RemoveTargetsFilter(List<WoWObject> units)
        {
            units.RemoveAll(
                ret =>
                {
                    var unit = ret as WoWUnit;
                    if (unit == null)
                        return false;

                    return false;
                });
        }

        public override void IncludeTargetsFilter(List<WoWObject> incomingunits, HashSet<WoWObject> outgoingunits)
        {
            var stranglingRootGuid =
                (Me.GetAuraByName("Strangling Roots") ??
                 Me.PartyMembers.Select(p => p.GetAuraByName("Strangling Roots")).FirstOrDefault())?.CreatorGuid;

            foreach (var obj in incomingunits)
            {
                var unit = obj as WoWUnit;
                if (unit != null)
                {
                    if (unit.Entry == MobId_StranglingRoots && stranglingRootGuid.HasValue && stranglingRootGuid.Value == unit.Guid)
                        outgoingunits.Add(unit);
                }
            }
        }

        public override void WeighTargetsFilter(List<Targeting.TargetPriority> units)
        {
            var isTank = Me.IsTank;

            foreach (var priority in units)
            {
                var unit = priority.Object as WoWUnit;
                if (unit != null)
                {
                    switch (unit.Entry)
                    {
                        case MobId_StranglingRoots:
                            if (!isTank)
                                priority.Score += 5000;
                            break;

                        case MobId_HatespawnWhelpling:
                            // fight other mobs if whelps have my aggro
                            if (isTank && unit.Aggro)
                                priority.Score -= 5000;
                            break;
                    }
                }
            }
        }

        #endregion

        #region Root

        private static LocalPlayer Me => StyxWoW.Me;


        [EncounterHandler(0, "Root Handler")]
        public Func<WoWUnit, Task<bool>> RootBehavior()
        {
            return async npc =>
            {
                if (await StuckHandler())
                    return true;

                return false;
            };
        }

        private Vector3 _stuckOnRockLoc1 = new Vector3(3088.177f, 1578.699f, 143.1691f);
        private Vector3 _stuckOnRockCTM = new Vector3(3092.326f, 1569.236f, 137.4397f);

        private async Task<bool> StuckHandler()
        {
            var myLoc = (WoWMovement.ActiveMover ?? Me).Location;
            if (myLoc.Distance2DSquared(_stuckOnRockLoc1) < 5 * 5 && Math.Abs(myLoc.Z - _stuckOnRockLoc1.Z) < 2)
            {
                WoWMovement.ClickToMove(_stuckOnRockCTM);
                await Coroutine.Sleep(2000);
                return true;
            }

            return false;
        }


        #endregion


        #region Archdruid Glaidalis

        #region Trash

        private const int SpellId_StarShower = 200658;
        private const int SpellId_Despair = 200642;
        private const int MissileSpellId_StarShower1 = 204407;
        private const int MissileSpellId_StarShower2 = 204383;

        private const uint MobId_DreadsoulRuiner = 95771;

        [EncounterHandler(MobId_DreadsoulRuiner, "Dreadsoul Ruiner")]
        public Func<WoWUnit, Task<bool>> DreadsoulRuinerHandler()
        {
            AddAvoidLocation(() => true, 3, missile => missile.ImpactPosition,
                () =>
                    WoWMissile.InFlightMissiles.Where(
                        m => m.SpellId == MissileSpellId_StarShower1 || m.SpellId == MissileSpellId_StarShower2));


            return async boss =>
            {
                return await ScriptHelpers.InterruptCast(boss, SpellId_StarShower, SpellId_Despair);
            };
        }

        private const uint MobId_MindshatteredScreecher = 95769;
        private const int SpellId_UnnervingScreech = 200630;


        [EncounterHandler(MobId_MindshatteredScreecher, "Mindshattered Screecher")]
        public Func<WoWUnit, Task<bool>> MindshatteredScreecherHandler()
        {
            return async boss =>
            {
                return await ScriptHelpers.InterruptCast(boss, SpellId_UnnervingScreech);
            };
        }

        private const uint MobId_FesterhideGrizzly = 95779;

        [EncounterHandler(MobId_FesterhideGrizzly, "Festerhide Grizzly")]
        public Func<WoWUnit, Task<bool>> FesterhideGrizzlyHandler()
        {
            AddAvoidUnitCone(() => !Me.IsTank, 0, 15, 90, unit => unit.Entry == MobId_FesterhideGrizzly && unit.CurrentTargetGuid != Me.Guid);

            return async boss => { return false; };
        }

        #endregion

        private const uint AreaTriggerId_Nightfall = 10154;
        private const int MissileSpellId_Nightfall = 198401;
        private const uint MobId_ArchdruidGlaidalis = 96512;

        [EncounterHandler(MobId_ArchdruidGlaidalis, "Archdruid Glaidalis")]
        public Func<WoWUnit, Task<bool>> ArchdruidGlaidalisHandler()
        {
            AddAvoidObject<WoWAreaTrigger>(4, AreaTriggerId_Nightfall);
            AddAvoidLocation(() => true, 4, missile => missile.ImpactPosition, () => WoWMissile.InFlightMissiles.Where(m => m.SpellId == MissileSpellId_Nightfall));
            AddAvoidUnitCone(() => !Me.IsTank, 0, 8, 60, u => u.Entry == MobId_ArchdruidGlaidalis && u.Combat && u.CurrentTargetGuid != Me.Guid);

            return async boss =>
            {

                return false;
            };
        }

        #endregion

        #region Oakheart

        #region Trash
        private const uint MobId_VilethornBlossom = 99360;
        private const uint MobId_RootBurstInvisibleStalker = 101958;

        [EncounterHandler(MobId_VilethornBlossom, "Vilethorn Blossom")]
        public Func<WoWUnit, Task<bool>> VilethornBlossomHandler()
        {
            AddAvoidObject<WoWUnit>(7, MobId_RootBurstInvisibleStalker);

            return async boss => false;
        }

        private const uint AreaTriggerId_VileMushroom = 10193;
        private const uint MobId_RotheartKeeper = 99359;
        private const int MissileSpellId_VileMushroom = 220369;

        [EncounterHandler(MobId_RotheartKeeper, "Rotheart Keeper")]
        public Func<WoWUnit, Task<bool>> RotheartKeeperHandler()
        {
            AddAvoidObject<WoWUnit>(6, AreaTriggerId_VileMushroom);
            AddAvoidLocation(() => true, 6, missile => missile.ImpactPosition, () => WoWMissile.InFlightMissiles.Where(m => m.SpellId == MissileSpellId_VileMushroom));

            return async boss => false;
        }

        #endregion

        private const uint MobId_Oakheart = 103344;

        private const int SpellId_NightmareBreath = 204667;
        private const uint MobId_StranglingRoots = 100991;

        [EncounterHandler(MobId_Oakheart, "Oakheart")]
        public Func<WoWUnit, Task<bool>> OakheartHandler()
        {
            AddAvoidUnitCone(() => true, 0, 25, 60, u => u.Entry == MobId_Oakheart && u.Combat && (!Me.IsTank || u.CastingSpellId == SpellId_NightmareBreath));
            AddAvoidObject<WoWUnit>(() => !Me.HasAura("Strangling Roots"), 2.5f, u => u.Entry == MobId_StranglingRoots);


            return async boss =>
            {
                return false;
            };
        }

        #endregion

        #region Dresaron

        #region Trash

        private const int SpellId_BloodAssault = 201226;
        private const int MissileSpellId_BloodBomb = 201272;

        private const uint MobId_BloodtaintedFury = 100531;

        [EncounterHandler(MobId_BloodtaintedFury, "BloodtaintedFury")]
        public Func<WoWUnit, Task<bool>> BloodtaintedFuryHandler()
        {
            WoWUnit bloodtaintedFury = null;

            AddAvoidLine(
                () =>
                    ScriptHelpers.IsViable(bloodtaintedFury) && bloodtaintedFury.CastingSpellId == SpellId_BloodAssault,
                () => 4, () => bloodtaintedFury.Location, () => bloodtaintedFury.Location.RayCast(bloodtaintedFury.Rotation, 15));

            AddAvoidLocation(() => true, 2, missile => missile.ImpactPosition, () => WoWMissile.InFlightMissiles.Where(m => m.SpellId == MissileSpellId_BloodBomb));

            return async boss =>
            {
                bloodtaintedFury = boss;
                return false;
            };
        }

        #endregion


        private const int SpellId_DownDraft = 199345;


        private const uint MobId_CorruptedDragonEgg = 101072;
        private const uint MobId_CorruptedEgg = 100533;
        private const uint MobId_Dresaron = 99200;
        private const uint MobId_AcidBreathInvisibleStalker = 101078;
        private const uint MobId_HatespawnWhelpling = 101074;

        private const uint AreaTriggerId_FallingRocks = 10253;

        [EncounterHandler(MobId_Dresaron, "Dresaron", 80, CallBehaviorMode.Proximity)]
        public Func<WoWUnit, Task<bool>> DresaronHandler()
        {
            WoWUnit dresaron = null;

            var rightDoorEdge = new Vector3(3057.92f, 1530.719f, 138.4122f);
            var leftDoorEdge = new Vector3(3062.269f, 1524.423f, 138.0279f);

            var randomPointInsideRoom = WoWMathHelper.GetRandomPointInCircle(new Vector3(3054.385f, 1523.222f, 138.0141f), 2);

            // Eggs encountered while moving to boss that spawn whelps when player moves near
            AddAvoidObject<WoWUnit>(5, u => u.Entry == MobId_CorruptedDragonEgg || u.Entry == MobId_CorruptedEgg, ignoreIfBlocking:  true);

            AddAvoidUnitCone(
                () =>
                    !Me.IsTank ||
                    ObjectManager.GetObjectsOfType<WoWUnit>().Any(u => u.Entry == MobId_AcidBreathInvisibleStalker), 0,
                15, 80, u => u.Entry == MobId_Dresaron, unit =>
                {
                    // Boss is flying so we need to bring the location to avoid down further...
                    var loc = unit.Location;

                    loc.Z = 138.4122f;
                    return loc;
                });


            var tankLoc = new Vector3(3032.412f, 1505.61f, 138.0186f);
            var capabilityHandle =  CapabilityManager.Instance.CreateNewHandle();

            Func<WoWUnit, bool> castingDownDraft = unit => unit.HasAura(SpellId_DownDraft) || unit.CastingSpellId == SpellId_DownDraft;

            AddAvoidObject<WoWAreaTrigger>(() => true, a => ScriptHelpers.IsViable(dresaron) && castingDownDraft(dresaron) ? 10 : 8, AreaTriggerId_FallingRocks);

            return async boss =>
            {
                dresaron = boss;

                // deal with any trash attacking us
                if (!Targeting.Instance.IsEmpty() && !boss.Combat && Targeting.Instance.FirstUnit != boss)
                    return false;

                if (await ScriptHelpers.MoveInsideBossRoom(boss, leftDoorEdge, rightDoorEdge, randomPointInsideRoom))
                    return true;

                if (!boss.Combat)
                    return false;

                if (castingDownDraft(boss) && boss.Distance2D > 3*3)
                {
                    CapabilityManager.Instance.Update(capabilityHandle, CapabilityFlags.Movement, () => boss.IsValid && castingDownDraft(boss));
                    Navigator.PlayerMover.MoveTowards(boss.Location);
                    return false;
                }

                // Stay near boss to avoid spawning 
                if (await ScriptHelpers.StayAtLocationWhile(() => !Me.IsTank && boss.IsValid && boss.Combat, boss.Location, boss.SafeName, 10))
                    return true;

                if (Me.CurrentTarget == boss)
                    return await ScriptHelpers.TankUnitAtLocation(tankLoc, 10 );

                return false;
            };
        }

        #endregion

        #region Shade of Xavius

        #region Trash

        private const int SpellId_DreadInferno = 201399;
        private const uint MobId_DreadfireImp = 100527;

        [EncounterHandler(MobId_DreadfireImp, "Dreadfire Imp")]
        public Func<WoWUnit, Task<bool>> DreadfireImpHandler()
        {
            return async boss => await ScriptHelpers.InterruptCast(boss, SpellId_DreadInferno);
        }

        private const uint MobId_TaintheartSummoner = 99366;
        [EncounterHandler(MobId_TaintheartSummoner, "Taintheart Summoner")]
        public Func<WoWUnit, Task<bool>> TaintheartSummonerHandler()
        {
            // Stay away from other players if has Curse of Isolation
            AddAvoidObject<WoWPlayer>(() => true, 6, p => !p.IsMe && p.IsAlive && (p.HasAura("Curse of Isolation") || Me.HasAura("Curse of Isolation")) );

            return async boss =>
            {
                return await ScriptHelpers.DispelGroup("Curse of Isolation", ScriptHelpers.PartyDispelType.Curse);
            };
        }

        #endregion
        private const uint MobId_ShadeofXavius = 99192;
        private const uint AreaTriggerId_GrowingParanoia = 10343;
        private const uint MobId_NightmareFire = 200067;
        private const int MissileSpellId_ApocalypticNightmare = 200067;

        [EncounterHandler(MobId_ShadeofXavius, "Shade of Xavius")]
        public Func<WoWUnit, Task<bool>> ShadeofXaviusHandler()
        {
            // Stay away from players with Growing Paranoia
            AddAvoidObject<WoWPlayer>(() => true, 5, p => !p.IsMe && p.IsAlive && (p.HasAura("Growing Paranoia") || Me.HasAura("Growing Paranoia")));
            AddAvoidLocation(() => true, 8, missile => missile.ImpactPosition, () => WoWMissile.InFlightMissiles.Where(m => m.SpellId == MissileSpellId_ApocalypticNightmare));
            AddAvoidObject(8, MobId_NightmareFire);

            return async boss =>
            {
                var fasteringRip = Me.RaidMembers.FirstOrDefault(p => p.HasAura("Festering Rip"));
                if (fasteringRip != null && await ScriptHelpers.DispelFriendlyUnit("Festering Rip", ScriptHelpers.PartyDispelType.Magic, fasteringRip))
                    return true;
                // ToDO Added Apocalyptic Fire
                return false;
            };
        }

        #endregion

    }

    #endregion

    #region Heroic Difficulty

    public class DarkheartThicketHeroic : DarkheartThicket
    {
        #region Overrides of Dungeon

        public override uint DungeonId => 1202;

        #endregion
    }

    #endregion
}
*/
