﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Numerics;
using System.Threading.Tasks;
using System.Windows.Markup;
using Bots.DungeonBuddy.Attributes;
using Bots.DungeonBuddy.Enums;
using Bots.DungeonBuddy.Helpers;
using Buddy.Coroutines;
using Styx;
using Styx.Common;
using Styx.Common.Helpers;
using Styx.CommonBot;
using Styx.CommonBot.Coroutines;
using Styx.CommonBot.POI;
using Styx.CommonBot.Routines;
using Styx.Helpers;
using Styx.Pathing;
using Styx.Pathing.Avoidance;
using Styx.WoWInternals;
using Styx.WoWInternals.World;
using Styx.WoWInternals.WoWObjects;
using Styx.WoWInternals.WoWObjects.AreaTriggerShapes;

// ReSharper disable CheckNamespace

/* Commented out because it needs some more testing
  
namespace Bots.DungeonBuddy.DungeonScripts.Legion
// ReSharper restore CheckNamespace
{
    #region Normal Difficulty

    public class NeltharionsLair : Dungeon
    {
        #region Overrides of Dungeon

        public override uint DungeonId => 1206;

        public override Vector3 Entrance
        {
            get
            {
                throw new NotImplementedException();
            }
        }

        public override Vector3 ExitLocation => new Vector3(2985.959f, 983.7914f, 379.7207f);

        public override void RemoveTargetsFilter(List<WoWObject> units)
        {
            units.RemoveAll(
                ret =>
                {
                    var unit = ret as WoWUnit;
                    if (unit == null)
                        return false;

                    if (unit.Entry == MobId_UlaroggCragshaper && unit.HasAura(AuraId_StanceOfTheMountain))
                        return true;

                    if (IsCastingSpikedTongue(unit) && unit.CurrentTargetGuid == Me.Guid && Me.IsMelee)
                        return true;

                    return false;
                });
        }

        public override void IncludeTargetsFilter(List<WoWObject> incomingunits, HashSet<WoWObject> outgoingunits)
        {
            foreach (var obj in incomingunits)
            {
                var unit = obj as WoWUnit;
                if (unit != null)
                {
                    if (unit.Entry == MobId_DrumsofWar &&
                        incomingunits.Any(
                            u =>
                                u.Entry == MobId_UnderstoneDrummer && u.Location.DistanceSquared(unit.Location) < 8 * 8 &&
                                u.ToUnit().HasAura("War Drums")))
                    {
                        outgoingunits.Add(unit);
                    }

                    if (_bellowingIdolIds.Contains(unit.Entry))
                        outgoingunits.Add(unit);

                    if (unit.Entry == MobId_WormspeakerDevout && unit.ZDiff < 10)
                        outgoingunits.Add(unit);

                }
            }
        }

        public override void WeighTargetsFilter(List<Targeting.TargetPriority> units)
        {
            var isDps = Me.IsDps;

            foreach (var priority in units)
            {
                var unit = priority.Object as WoWUnit;
                if (unit != null)
                {
                    switch (unit.Entry)
                    {
                        case MobId_DrumsofWar:
                        case MobId_BlightshardSkitter:
                        case MobId_TarspitterGrub:
                            if (isDps)
                                priority.Score += 5000;
                            break;

                        case MobId_MoltenCharskin:
                        case MobId_WormspeakerDevout:
                            // tanks should stay on boss when these adds spawn..
                            priority.Score += isDps ? 5000 : -5000;
                            break;

                        case MobId_RockbackGnasher:
                            // Kill last because it gets resummoned otherwise.
                            if (isDps)
                                priority.Score -= 5000;
                            break;
                    }

                    if (unit == _bellowingIdolTarget)
                        priority.Score += 5000;
                }
            }
        }

        public override void IncludeLootTargetsFilter(List<WoWObject> incomingunits, HashSet<WoWObject> outgoingunits)
        {
            foreach (var lootTarget in incomingunits)
            {
                var gObj = lootTarget as WoWGameObject;
                if (gObj != null && gObj.Entry == GameObjectId_RemainsoftheFallen && gObj.ZDiff < 10 && gObj.CanUse() &&
                    DungeonBuddySettings.Instance.LootMode != LootMode.Off)
                {
                    outgoingunits.Add(gObj);
                }
            }
        }

        public override void OnEnter()
        {
            GameWorld.UnitSpellLineOfSightTest += GameWorld_UnitSpellLineOfSightTest;
        }

        public override void OnExit()
        {
            GameWorld.UnitSpellLineOfSightTest -= GameWorld_UnitSpellLineOfSightTest;
        }

        private void GameWorld_UnitSpellLineOfSightTest(object sender, UnitSpellLineOfSightTestEventArgs e)
        {
            if (e.Unit.Entry != MobId_Naraxas)
                return;

            var spellDist = e.Unit.CombatReach + 40;
            e.InSpellLineOfSight = e.Unit.DistanceSqr < spellDist * spellDist;
            e.Handled = true;
        }

        #endregion

        #region Root

        private static LocalPlayer Me => StyxWoW.Me;

        private const uint MobId_DrumsofWar = 92387;

        private const uint MobId_UnderstoneDrummer = 92610;

        [EncounterHandler(0, "Root Handler")]
        public Func<WoWUnit, Task<bool>> RootBehavior()
        {
            return async npc =>
            {
                if (await ScriptHelpers.DispelGroup("Petrifying Cloud", ScriptHelpers.PartyDispelType.Magic))
                    return true;

                return false;
            };
        }

        #endregion

        #region Rokmora

        #region Trash

        private const uint MobId_VileshardCrawler = 96247;
        private const uint AreaTriggerId_AcidSplatter = 8790;

        [EncounterHandler((int)MobId_VileshardCrawler, "Vileshard Crawler")]
        public Func<WoWUnit, Task<bool>> VileshardCrawlerBehavior()
        {
            AddAvoidObject<WoWAreaTrigger>(3, AreaTriggerId_AcidSplatter);

            return async npc => false;
        }

        private const int SpellId_Crush = 226287;
        private const uint MobId_VileshardChunk = 101438;

        [EncounterHandler((int)MobId_VileshardChunk, "Vileshard Chunk")]
        public Func<WoWUnit, Task<bool>> VileshardChunkBehavior()
        {
            AddAvoidObject<WoWUnit>(10, u => u.Entry == MobId_VileshardChunk && u.CastingSpellId == SpellId_Crush);

            return async npc => false;
        }

        private const uint AreaTriggerId_RancidOoze = 12758;
        private const uint MobId_TarspitterLurker = 91001;
        private const int SpellId_ViscidBile = 183465;

        [EncounterHandler((int)MobId_TarspitterLurker, "Tarspitter Lurker")]
        public Func<WoWUnit, Task<bool>> TarspitterLurkerBehavior()
        {
            AddAvoidObject<WoWAreaTrigger>(4, AreaTriggerId_RancidOoze);
            AddAvoidObject<WoWUnit>(7, u => u.Entry == MobId_TarspitterLurker && u.CastingSpellId == SpellId_ViscidBile);

            return async npc => false;
        }

        private const uint MobId_VileshardHulk = 91000;
        private readonly HashSet<int> SpellIds_PiercingShards = new HashSet<int> { 226296, 226304 };

        [EncounterHandler((int)MobId_VileshardHulk, "Vileshard Hulk")]
        public Func<WoWUnit, Task<bool>> VileshardHulkBehavior()
        {
            AddAvoidUnitCone(() => true, 0, 45, 60,
                unit =>
                    unit.Entry == MobId_VileshardHulk && unit.Combat &&
                    !(Me.IsTank || SpellIds_PiercingShards.Contains(unit.CastingSpellId)));

            return async npc => false;
        }

        #endregion

        private const int SpellId_RazorShards = 188169;

        private const uint MobId_Rokmora = 91003;
        private const uint MobId_BlightshardSkitter = 97720;
        private const uint AreaTriggerId_ChokingDust = 9669;

        [EncounterHandler((int)MobId_Rokmora, "Rokmora")]
        public Func<WoWUnit, Task<bool>> RokmoraBehavior()
        {
            AddAvoidObject<WoWAreaTrigger>(5, AreaTriggerId_ChokingDust);

            AddAvoidUnitCone(() => true, 0, 100, 60,
                unit =>
                    unit.Entry == MobId_Rokmora && unit.Combat &&
                    !(Me.IsTank || unit.CastingSpellId == SpellId_RazorShards));

            var tankLoc = new Vector3(2870.726f, 1371.589f, -1.960059f);

            return async npc =>
            {
                return await ScriptHelpers.TankUnitAtLocation(tankLoc, 15);
            };
        }

        #endregion

        #region Ularogg Cragshaper

        #region Trash

        private const uint MobId_StoneclawHunter = 91332;

        [EncounterHandler(MobId_StoneclawHunter, "Stoneclaw Hunter")]
        public Func<WoWUnit, Task<bool>> StoneclawHunterHandler()
        {
            return async boss => { return false; };
        }

        private const uint MobId_RockbackGnasher = 91006;

        private const int SpellId_StoneGaze = 202181;

        [EncounterHandler((int)MobId_RockbackGnasher, "Rockback Gnasher")]
        public Func<WoWUnit, Task<bool>> RockbackGnasherBehavior()
        {
            return async npc => await ScriptHelpers.InterruptCast(npc, SpellId_StoneGaze);
        }


        private const uint MobId_PetrifyingTotem = 94224;
        private const int MissileSpellId_PetrifyingTotem = 202108;

        private const uint MobId_BlightshardShaper = 90998;

        [EncounterHandler((int)MobId_BlightshardShaper, "Blightshard Shaper")]
        public Func<WoWUnit, Task<bool>> BlightshardShaperBehavior()
        {
            AddAvoidObject<WoWUnit>(5, u => u.Entry == MobId_PetrifyingTotem);
            AddAvoidLocation(() => true, 5, missile => missile.ImpactPosition, () => WoWMissile.InFlightMissiles.Where(m => m.SpellId == MissileSpellId_PetrifyingTotem));

            return async npc => false;
        }

        private const int MissileSpellId_Scorch = 202086;
        private const uint MobId_BurningGeode = 101437;

        [EncounterHandler((int)MobId_BurningGeode, "Burning Geode")]
        public Func<WoWUnit, Task<bool>> BurningGeodeBehavior()
        {
            AddAvoidObject<WoWUnit>(5, u => u.Entry == MobId_PetrifyingTotem);
            AddAvoidLocation(() => true, 5, missile => missile.ImpactPosition, () => WoWMissile.InFlightMissiles.Where(m => m.SpellId == MissileSpellId_Scorch));

            return async npc => false;
        }

        private const int SpellId_Avalanche = 183088;
        private const int MissileSpellId_Avalanche = 183095;

        private const uint MobId_MightstoneBreaker = 90997;

        [EncounterHandler((int)MobId_MightstoneBreaker, "Mightstone Breaker")]
        public Func<WoWUnit, Task<bool>> MightstoneBreakerBehavior()
        {
            AddAvoidUnitCone(() => true, 0, 5, 60, unit => unit.Entry == MobId_MightstoneBreaker && unit.CastingSpellId == SpellId_Avalanche && unit.CurrentTargetGuid != Me.Guid);
            AddAvoidLocation(() => true, 5, missile => missile.ImpactPosition, () => WoWMissile.InFlightMissiles.Where(m => m.SpellId == MissileSpellId_Avalanche));

            return async npc => false;
        }

        #endregion

        private const int AuraId_StanceOfTheMountain = 198510;
        private const uint MobId_UlaroggCragshaper = 91004;
        private const uint AreaTriggerId_StrikeoftheMountain = 11899;
        private const uint MobId_BellowingIdolCopies = 100818;
        private const uint MobId_BellowingIdol = 98081;
        private readonly HashSet<uint> _bellowingIdolIds = new HashSet<uint> { MobId_BellowingIdol, MobId_BellowingIdolCopies };

        private WoWUnit _bellowingIdolTarget;

        [EncounterHandler(MobId_UlaroggCragshaper, "Ularogg Cragshaper", 100, CallBehaviorMode.Proximity)]
        public Func<WoWUnit, Task<bool>> UlaroggCragshaperHandler()
        {
            var roomCenter = new Vector3(2835.278f, 1667.152f, -40.68523f);
            var targetBellowingIdolLoc = new Vector3(2838.145f, 1667.873f, -40.74132f);

            AddAvoidObject<WoWAreaTrigger>(() => true, 4, trigger => trigger.Entry == AreaTriggerId_StrikeoftheMountain, trigger => trigger.Location.RayCast(trigger.Rotation, 4));

            return async boss =>
            {
                if (boss.ZDiff > 15)
                    return false;

                if (!boss.Combat)
                {
                    var trash = ScriptHelpers.GetUnfriendlyNpsAtLocation(roomCenter, 60, unit => unit != boss && unit.ZDiff < 15);
                    if (trash.Any())
                        return await ScriptHelpers.ClearArea(roomCenter, 60, unit => unit != boss && unit.ZDiff < 15, false);

                    return await ScriptHelpers.PullNpcToLocation(() => true, boss, roomCenter, 5000);
                }

                if (!boss.HasAura(AuraId_StanceOfTheMountain))
                {
                    if (Me.IsTank && Me.CurrentTargetGuid == boss.Guid)
                    {
                        var bellowingIdol =
                            ObjectManager.GetObjectsOfType<WoWUnit>()
                                .Where(u => u.Entry == MobId_BellowingIdol)
                                .OrderBy(u => u.DistanceSqr)
                                .FirstOrDefault();

                        // tank boss near bellowing idols so cleaves hit them
                        if (bellowingIdol != null)
                            return await ScriptHelpers.TankUnitAtLocation(bellowingIdol.Location, 3);
                    }
                }
                else
                {
                    if (!ScriptHelpers.IsViable(_bellowingIdolTarget))
                    {
                        _bellowingIdolTarget =
                            ObjectManager.GetObjectsOfType<WoWUnit>()
                                .FirstOrDefault(
                                    u =>
                                        u.Entry == MobId_BellowingIdolCopies &&
                                        u.Location.DistanceSquared(targetBellowingIdolLoc) < 3 * 3);
                    }
                }
                return false;
            };
        }

        #endregion

        #region Naraxas

        #region Trash
        private const uint MobId_TarspitterGrub = 92538;

        private const uint AreaTriggerId_RancidPool = 8802;

        private const uint MobId_RotdroolGrabber = 91002;
        [EncounterHandler((int)MobId_RotdroolGrabber, "Rotdrool Grabber")]
        public Func<WoWUnit, Task<bool>> RotdroolGrabberBehavior()
        {
            AddAvoidObject<WoWAreaTrigger>(7, AreaTriggerId_RancidPool);
            return async npc => false;
        }


        #endregion

        private const uint AreaTriggerId_ToxicRetch = 11287;
        private const uint AreaTriggerId_RancidMaw = 9239;

        private const uint MobId_WormspeakerDevout = 101075;
        private const uint MobId_Naraxas = 91005;


        private readonly HashSet<int> SpellIds_SpikedTongue = new HashSet<int>
        {
            199176,
            199178
        };

        private const int SpellId_SpikedTongue = 199176;

        private bool IsCastingSpikedTongue(WoWUnit unit)
        {
            return unit.CastingSpellId == SpellId_SpikedTongue || unit.HasAura("Spiked Tongue");
        }

        // loot chest for Naraxas
        private const uint GameObjectId_RemainsoftheFallen = 251482;

        [EncounterHandler((int)MobId_Naraxas, "Naraxa")]
        public Func<WoWUnit, Task<bool>> NaraxasBehavior()
        {
            AddAvoidObject<WoWAreaTrigger>(3, AreaTriggerId_ToxicRetch);
            AddAvoidObject<WoWAreaTrigger>(4, AreaTriggerId_RancidMaw);
            AddAvoidObject<WoWUnit>(() => true, 60, u => u.Entry == MobId_Naraxas && IsCastingSpikedTongue(u) && u.CurrentTargetGuid == Me.Guid);

            return async npc =>
            {
                if (await ScriptHelpers.DispelGroup("Toxic Retch", ScriptHelpers.PartyDispelType.Poison))
                    return true;
               
                return false;
            };
        }

        #endregion

        #region Dargrul

        #region Trash

        private const uint MobId_EmberhuskDominator = 113537;
        [EncounterHandler((int)MobId_EmberhuskDominator, "Emberhusk Dominator")]
        public Func<WoWUnit, Task<bool>> EmberhuskDominatorBehavior()
        {
            AddAvoidUnitCone(() => !Me.IsTank, 0, 15, 60, unit => unit.Entry == MobId_EmberhuskDominator && unit.CurrentTargetGuid != Me.Guid);

            return async npc =>
            {
                return false;
            };
        }

        private const uint MobId_UnderstoneDemolisher = 102253;
        [EncounterHandler((int)MobId_UnderstoneDemolisher, "Understone Demolisher")]
        public Func<WoWUnit, Task<bool>> UnderstoneDemolisherBehavior()
        {
            AddAvoidObject<WoWUnit>(() => Me.HasAura("Burning Hatred"),
              () => ScriptHelpers.Tank?.Location ?? Vector3.Zero, 40,
              20,
              unit => unit.Entry == MobId_UnderstoneDemolisher && unit.CurrentTargetGuid == Me.Guid);

            return async npc =>
            {
                return false;
            };
        }

        #endregion

        private const uint MobId_Dargrul = 91007;
        private const uint MobId_Drogbar = 113506;
        private const uint MobId_MoltenCharskin = 101476;
        private const uint MobId_CrystalWallStalker = 101593;
        private const uint GameObjectId_CrystalWallMinionCollision = 246251;
        private const int SpellId_MagmaWave = 200404;

        private const int SpellId_Landslide = 200700;

        [EncounterHandler((int)MobId_Dargrul, "Dargrul", 80, CallBehaviorMode.Proximity)]
        public Func<WoWUnit, Task<bool>> DargrulBehavior()
        {
            WoWUnit dargrul = null;

            var nearestCrystalSpike =
                new PerFrameCachedValue<WoWUnit>(
                    () =>
                        ObjectManager.GetObjectsOfType<WoWUnit>()
                            .Where(u => u.Entry == MobId_CrystalWallStalker)
                            .OrderBy(u => u.DistanceSqr)
                            .FirstOrDefault());

            AddAvoidObject<WoWUnit>(6, MobId_CrystalWallStalker);

            AddAvoidObject<WoWUnit>(6, MobId_Drogbar);

            AddAvoidLine(() => ScriptHelpers.IsViable(dargrul) && dargrul.CastingSpellId == SpellId_Landslide && dargrul.CurrentTargetGuid != Me.Guid,
                () => 6,
                () => dargrul.Location, () => dargrul.Location.RayCast(dargrul.Rotation, 50));

            AddAvoidObject<WoWUnit>(() => Me.HasAura("Burning Hatred") && nearestCrystalSpike.Value == null,
                  () => ScriptHelpers.Tank?.Location ?? Vector3.Zero, 40,
                  20,
                  unit => unit.Entry == MobId_MoltenCharskin && unit.CurrentTargetGuid == Me.Guid);

            var leftTrashLoc = new Vector3(2791.806f, 2003.354f, -210.6877f);
            var rightTrashLoc = new Vector3(2825.089f, 2046.08f, -210.4583f);
            var trashTankLoc = new Vector3(2834.589f, 2005.604f, -209.8708f);

            return async boss =>
            {
                dargrul = boss;

                if (!boss.Combat)
                {
                    // Pull trash groups.
                    var trash = ScriptHelpers.GetUnfriendlyNpsAtLocation(leftTrashLoc, 10).FirstOrDefault() ??
                                ScriptHelpers.GetUnfriendlyNpsAtLocation(rightTrashLoc, 10).FirstOrDefault();

                    if (await ScriptHelpers.PullNpcToLocation(() => trash != null, trash, trashTankLoc, 5000, 3))
                        return true;

                    return false;
                }

                if (boss.CastingSpellId == SpellId_Landslide)
                    return await ScriptHelpers.TankFaceUnitAwayFromGroup(boss, 40);

                var burningHatredAura = Me.GetAuraByName("Burning Hatred");
                
                // kite charskins into crystals to stun them
                if (burningHatredAura != null && !Me.IsTank && nearestCrystalSpike.Value != null)
                {
                    var charskin = ObjectManager.GetObjectByGuid<WoWUnit>(burningHatredAura.CreatorGuid);
                    if (charskin != null)
                    {
                        var moveTo = WoWMathHelper.CalculatePointFrom(charskin.Location,
                            nearestCrystalSpike.Value.Location, -8);

                        return (await CommonCoroutines.MoveTo(new MoveToParameters(moveTo) {DistanceTolerance = 8})).IsSuccessful();
                    }
                }

                if (boss.CastingSpellId == SpellId_MagmaWave && nearestCrystalSpike.Value != null)
                {
                    return
                        await
                            ScriptHelpers.MoveOutOfLos(
                                () =>
                                    ScriptHelpers.IsViable(boss) && ScriptHelpers.IsViable(nearestCrystalSpike) &&
                                    boss.CastingSpellId == SpellId_MagmaWave,
                                boss.Location, nearestCrystalSpike.Value.Location, 8);
                }

                if (nearestCrystalSpike.Value != null && Me.IsTank && Me.CurrentTargetGuid == boss.Guid)
                    return await ScriptHelpers.TankUnitAtLocation(nearestCrystalSpike.Value.Location, 15);

                // Stay near a crastal spike so that we can use it to LOS the Magma wave spell in time.
                return await ScriptHelpers.StayAtLocationWhile(
                            () =>
                                !Me.IsTank && !AvoidanceManager.IsRunningOutOfAvoid && ScriptHelpers.IsViable(boss) &&
                                ScriptHelpers.IsViable(nearestCrystalSpike.Value), nearestCrystalSpike.Value.Location,
                            "Crystal Spike", 15);

            };
        }

        #endregion
    }

#endregion

    #region Heroic Difficulty

    public class NeltharionsLairHeroic : NeltharionsLair
    {
        #region Overrides of Dungeon

        public override uint DungeonId => 1207;

        #endregion
    }

    #endregion
}

 */