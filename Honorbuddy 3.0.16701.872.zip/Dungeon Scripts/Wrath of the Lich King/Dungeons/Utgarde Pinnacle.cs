
using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Threading.Tasks;
using CommonBehaviors.Actions;
using Styx;
using Styx.CommonBot;
using Styx.CommonBot.POI;
using Styx.Helpers;
using Styx.Pathing;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using Styx.TreeSharp;
using Bots.DungeonBuddy.Attributes;
using Bots.DungeonBuddy.Helpers;
using Buddy.Coroutines;
using Styx.Common;
using Styx.CommonBot.Coroutines;
using Action = Styx.TreeSharp.Action;

namespace Bots.DungeonBuddy.Dungeon_Scripts.Wrath_of_the_Lich_King
{
    public class UtgardePinnacle : Dungeon
    {
        #region Overrides of Dungeon

        public override uint DungeonId
        {
            get { return 203; }
        }

        public override Vector3 Entrance
        {
            get { return new Vector3(1234.077f, -4860.071f, 218.295f); }
        }

        public override Vector3 ExitLocation
        {
            get { return new Vector3(590.6429f, -327.9592f, 110.1452f); }
        }

        public override void RemoveTargetsFilter(List<WoWObject> units)
        {
            units.RemoveAll(
                ret =>
                {
                    var unit = ret.ToUnit();
                    if (unit == null)
                        return false;

                    if (unit.Entry == MindlessServantId && !unit.Combat)
                        return true;
                    if (unit.Entry == DragonflayerSpectatorId)
                        return true;
                    if (ret.Entry == GraufId)
                        return true;
                    if (unit.Entry == SkadiId && (unit.HasAura("Ride Vehicle") || unit.HasAura("Whirlwind") && Me.IsDps && Me.IsMelee()))
                        return true;
                    return false;
                });
        }

        public override void IncludeTargetsFilter(List<WoWObject> incomingunits, HashSet<WoWObject> outgoingunits)
        {
            foreach (var obj in incomingunits)
            {
                var unit = obj as WoWUnit;
                if (unit != null) { }
            }
        }

        public override void WeighTargetsFilter(List<Targeting.TargetPriority> units)
        {
            foreach (var priority in units)
            {
                var unit = priority.Object as WoWUnit;
                if (unit != null)
                {
                    if (unit.Entry == RitualChannelerId)
                        priority.Score += 500;
                    if (unit.Entry == DragonflayerSeerId && StyxWoW.Me.IsDps)
                        priority.Score += 500;
                }
            }
        }

        public override void IncludeLootTargetsFilter(List<WoWObject> incomingunits, HashSet<WoWObject> outgoingunits)
        {
            if (!ScriptHelpers.HasQuest(JunkInMyTrunkQuestId) || ScriptHelpers.IsQuestInLogComplete(JunkInMyTrunkQuestId))
                return;

            foreach (var obj in incomingunits)
            {
                var gObj = obj as WoWGameObject;
                if (gObj != null)
                {
                    // objects for the quest 'Junk in my Trunk'
                    if (_questItemIds.Contains(gObj.Entry)
                        && !ScriptHelpers.WillPullAggroAtLocation(gObj.Location)
                        && gObj.DistanceSqr < 30 * 30
                        && !gObj.InUse && gObj.CanUse())
                    {
                        PathInformation pathInf = Navigator.LookupPathInfo(gObj, gObj.InteractRange);
                        if (pathInf.Navigability != PathNavigability.Navigable ||
                            pathInf.Distance >= 30)
                            continue;
                        outgoingunits.Add(gObj);
                    }
                }
            }
        }

        public override async Task<bool> HandleMovement(MoveToParameters moveToParameters)
        {
            var svala = ObjectManager.GetObjectsOfType<WoWUnit>().FirstOrDefault(u => u.Entry == MobId_SvalaSorrowgrave);
            if (svala != null && svala.Location.DistanceSquared(moveToParameters.Location) < 3 * 3)
            {
                moveToParameters.DistanceTolerance = 20;
                return (await CommonCoroutines.MoveTo(moveToParameters)).IsSuccessful();
            }

            var kingYmiron = ObjectManager.GetObjectsOfType<WoWUnit>().FirstOrDefault(u => u.Entry == MobId_KingYmiron);
            if (kingYmiron != null && kingYmiron.Location.DistanceSquared(moveToParameters.Location) < 3 * 3)
            {
                moveToParameters.DistanceTolerance = 10;
                return (await CommonCoroutines.MoveTo(moveToParameters)).IsSuccessful();
            }

            return false;
        }

        #endregion

        private const uint RitualChannelerId = 27281;
        private const uint DragonflayerSeerId = 26554;
        private const uint DragonflayerSpectatorId = 26667;
        private const uint GraufId = 26893;
        private const uint SkadiId = 26693;
        private const uint MindlessServantId = 26536;
        private const uint JadeStatueId = 192945;
        private const uint UntarnishedSilverBarId = 192941;
        private const uint ShinyBaubleId = 192943;
        private const uint GoldenGobletId = 192944;
        private const uint JunkInMyTrunkQuestId = 13131;
        private const uint VengeanceBeMineQuestId = 13132;
        private readonly Vector3 _lastBossLocation = new Vector3(392.8011f, -289.0229f, 109.2514f);

        private readonly uint[] _questItemIds = { JadeStatueId, UntarnishedSilverBarId, ShinyBaubleId, GoldenGobletId };

        private LocalPlayer Me => StyxWoW.Me;


        private readonly uint[] _questIdsAtEntrance =
        {
            JunkInMyTrunkQuestId,
            VengeanceBeMineQuestId
        };

        [EncounterHandler(30871, "Brigg Smallshanks", Mode = CallBehaviorMode.Proximity, BossRange = 30)]
        [EncounterHandler(56072, "Image of Argent Confessor Paletress", Mode = CallBehaviorMode.Proximity, BossRange = 35)]
        public async Task<bool> QuestPickupTurninHandler(WoWUnit npc)
        {
            if (Me.Combat || ScriptHelpers.WillPullAggroAtLocation(npc.Location))
                return false;
            // pickup or turnin quests if any are available.
            return npc.HasQuestAvailable(true)
                ? await ScriptHelpers.PickupQuest(npc)
                : npc.HasQuestTurnin() && await ScriptHelpers.TurninQuest(npc);
        }


        [EncounterHandler(0, "Root behavior")]
        public async Task<bool> RootHandler(WoWUnit npc)
        {
            // port outside and back in to hand in quests once dungeon is complete.
            // QuestPickupTurninHandler will handle the turnin
            return IsComplete && !Me.Combat
                    && _questIdsAtEntrance.Any(ScriptHelpers.IsQuestInLogComplete)
                    && BotPoi.Current.Type == PoiType.None
                    && Me.Location.DistanceSquared(_lastBossLocation) < 50 * 50
                    && await ScriptHelpers.PortOutsideAndBackIn();
        }

        private const uint MobId_KingYmiron = 26861;

        [EncounterHandler(26861, "King Ymiron")]
        public Composite KingYmironEncounter()
        {
            const uint spiritFountId = 27339;
            AddAvoidObject<WoWUnit>(() => true, o => Me.IsMoving && Me.IsRange() ? 15 : 10, spiritFountId);

            WoWUnit boss = null;
            return new PrioritySelector(ctx => boss = ctx as WoWUnit, ScriptHelpers.CreateDispelEnemy("Bane", ScriptHelpers.EnemyDispelType.Magic, ctx => boss));
        }

        #region Svala Sorrowgrave

        private const uint MobId_SvalaSorrowgrave = 26668;

        [EncounterHandler(26668, "Svala Sorrowgrave", Mode = CallBehaviorMode.Proximity)]
        public Composite SvalaSorrowgraveEncounter()
        {
            WoWUnit sorrowgrave = null;
            const uint ritualTargetId = 27327;
            const int ritualOfTheSwordId = 48276;

            AddAvoidObject<WoWUnit>(
                () =>
                    !Me.IsTank() && sorrowgrave != null && sorrowgrave.IsValid &&
                    (sorrowgrave.CastingSpellId == ritualOfTheSwordId || sorrowgrave.ChanneledCastingSpellId == ritualOfTheSwordId),
                10,
                o => o.Entry == ritualTargetId && !ScriptHelpers.GetUnfriendlyNpsAtLocation(o.Location, 30, u => u.Entry == RitualChannelerId).Any());

            return new PrioritySelector(
                ctx => sorrowgrave = ctx as WoWUnit,
                // wait for the bitch to spawn. 
                new Decorator<WoWUnit>(
                    svala => svala != null && StyxWoW.Me.IsTank() && !StyxWoW.Me.IsActuallyInCombat && !svala.Attackable && svala.DistanceSqr < 35 * 35,
                    new PrioritySelector(
                        new Decorator<WoWUnit>(svala => svala.DistanceSqr > 10 * 10, new Helpers.Action<WoWUnit>(svala => Navigator.MoveTo(svala.Location))),
                        new ActionAlwaysSucceed())));
        }

        [EncounterHandler(29281, "Svala", Mode = CallBehaviorMode.Proximity)]
        public Composite SvalaEncounter()
        {
            return new PrioritySelector(
                // wait for the bitch to spawn. 
                new Decorator<WoWUnit>(
                    svala => svala != null && StyxWoW.Me.IsTank() && !StyxWoW.Me.IsActuallyInCombat && svala.DistanceSqr < 35 * 35,
                    new PrioritySelector(
                        new Decorator<WoWUnit>(svala => svala.DistanceSqr > 10 * 10, new Helpers.Action<WoWUnit>(svala => Navigator.MoveTo(svala.Location))),
                        new ActionAlwaysSucceed())));
        }

        #endregion

        #region Gortok Palehoof

        private const uint StasisGeneratorId = 188593;
        private const uint GortokPalehoofId = 26687;
        private const uint MobId_MassiveJormungar = 26685;

        [EncounterHandler(26685, "Massive Jormungar")]
        public Composite MassiveJormungarEncounter()
        {
            // frontal spray. 
            AddAvoidUnitCone(() => !Me.IsTank(), 0, 15, 180, u => u.Entry == MobId_MassiveJormungar && !u.IsMoving && u.CurrentTarget != Me && u.Combat);

            WoWUnit boss = null;
            return new PrioritySelector(
                ctx => boss = ctx as WoWUnit,
                ScriptHelpers.CreateTankFaceAwayGroupUnit(15));
        }

        private const uint MobId_GortokPalehoof = 26687;

        [EncounterHandler(26687, "Gortok Palehoof")]
        public Composite GortokPalehoofEncounter()
        {
            // cleave
            AddAvoidUnitCone(() => !Me.IsTank(), 0, 8, 180, u => u.Entry == MobId_GortokPalehoof && !u.IsMoving && u.CurrentTarget != Me && u.Combat);

            WoWUnit boss = null;
            return new PrioritySelector(
                ctx => boss = ctx as WoWUnit,
                ScriptHelpers.CreateTankFaceAwayGroupUnit(8));
        }

        [LocationHandler(274.8584, -452.0601, 104.7027, 40, "Gortok Palehoof")]
        public Func<Vector3, Task<bool>> StartGortokPalehoofEncounter()
        {
            return async loc =>
            {
                WoWUnit gortokPalehoofUnit =
                    ObjectManager.GetObjectsOfTypeFast<WoWUnit>().FirstOrDefault(o => o.Entry == GortokPalehoofId);

                if (gortokPalehoofUnit == null)
                    return false;

                if (gortokPalehoofUnit.HasAura("Freeze Anim") && StyxWoW.Me.IsTank() && Targeting.Instance.IsEmpty())
                {
                    WoWGameObject stasisGenerator = ObjectManager.GetObjectsOfTypeFast<WoWGameObject>()
                    .First(g => g.Entry == StasisGeneratorId);

                    await ScriptHelpers.InteractWithObject(stasisGenerator, 8000);
                    SpellManager.StopCasting();
                    return true;
                }

                return false;
            };
        }

        #endregion

        #region Skadi the Ruthless

        private readonly Vector3 _skadiTankSpot = new Vector3(486.1297f, -515.4338f, 104.723f);

        [EncounterHandler(26893, "Grauf", Mode = CallBehaviorMode.Proximity, BossRange = 1000)]
        public Composite CreateBehavior_GraufEncounter()
        {
            WoWDynamicObject freezingCloud = null;
            WoWGameObject harpoon = null, harpoonLancher = null;
            var throwHarpoonsLoc = new Vector3(520.4827f, -541.5633f, 119.8416f);

            return new PrioritySelector(
                new Decorator<WoWUnit>(
                    grauf => grauf.HasAura("Ride Vehicle"),
                    new PrioritySelector(
                        ctx =>
                        {
                            freezingCloud = ObjectManager.GetObjectsOfType<WoWDynamicObject>().FirstOrDefault(o => o.Entry == 47579);
                            harpoon = ObjectManager.GetObjectsOfType<WoWGameObject>().Where(o => o.Entry == 192539).OrderBy(o => o.DistanceSqr).FirstOrDefault();
                            harpoonLancher =
                                ObjectManager.GetObjectsOfType<WoWGameObject>().Where(o => o.Entry == 192176 && o.CanUse()).OrderBy(o => o.DistanceSqr).FirstOrDefault();
                            return ctx;
                        },
                        // freezing cloud is on west/left side.
                        new Decorator(
                            ctx => freezingCloud != null && freezingCloud.Y >= -512 && StyxWoW.Me.Y > -516 && StyxWoW.Me.Y < -492,
                            new Action(
                                ctx =>
                                {
                                    var moveToLoc = StyxWoW.Me.Location;
                                    moveToLoc.Y = -516.5f;
                                    WoWMovement.ClickToMove(moveToLoc);
                                })),
                        // freezing cloud is on east/right side
                        new Decorator(
                            ctx => freezingCloud != null && freezingCloud.Y < -512 && StyxWoW.Me.Y < -510.5,
                            new Action(
                                ctx =>
                                {
                                    var moveToLoc = StyxWoW.Me.Location;
                                    moveToLoc.Y = -510f;
                                    WoWMovement.ClickToMove(moveToLoc);
                                })),
                        // only have the dps pick up the harpoons and only when there is no freezing cloud on ground.
                        new Decorator(
                            ctx => harpoon != null && freezingCloud == null && (StyxWoW.Me.IsDps || !Me.GroupInfo.IsInParty),
                            ScriptHelpers.CreateInteractWithObject(ctx => harpoon, 0, true)),
                        // check if shadi is in front of the harpoons and if we have any harpoons..
                        new Decorator<WoWUnit>(
                            grauf => grauf.Location.DistanceSquared(throwHarpoonsLoc) <= 20 * 20 && harpoonLancher != null && StyxWoW.Me.BagItems.Any(i => i.Entry == 37372),
                            ScriptHelpers.CreateInteractWithObject(ctx => harpoonLancher, 0, true)),
                        // move towards the end of the gauntlet
                        new Decorator(
                            ctx => StyxWoW.Me.IsTank() && StyxWoW.Me.Location.DistanceSquared(_skadiTankSpot) > 15 * 15,
                            new Action(ctx => ScriptHelpers.SetLeaderMoveToPoiPS(_skadiTankSpot))))));
        }

        [EncounterHandler(26693, "Skadi the Ruthless")]
        public Composite SkadiTheRuthlessEncounter()
        {
            AddAvoidObject<WoWUnit>(
                () => !Me.IsTank(),
                o => Me.IsRange() && Me.IsMoving ? 15 : 10,
                o => o.Entry == SkadiId && o.ToUnit().Combat && (o.ToUnit().HasAura("Whirlwind") || Me.IsRange()));

            return new Decorator<WoWUnit>(
                skadi => skadi.HasAura("Ride Vehicle"),
                new PrioritySelector(
                    new Decorator<WoWUnit>(
                        skadi => StyxWoW.Me.IsTank() && skadi.CurrentTargetGuid == Me.Guid,
                        ScriptHelpers.CreateTankUnitAtLocation(ctx => _skadiTankSpot, 5))));
        }

        #endregion
    }
}