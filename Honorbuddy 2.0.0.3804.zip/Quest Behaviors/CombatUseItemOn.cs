using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using Styx.Database;
using Styx.Helpers;
using Styx.Logic.Inventory.Frames.Gossip;
using Styx.Logic.Pathing;
using Styx.Logic.Questing;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using TreeSharp;
using Action = TreeSharp.Action;

namespace Styx.Bot.Quest_Behaviors
{
    public class CombatUseItemOn : CustomForcedBehavior
    {
        public CombatUseItemOn(Dictionary<string, string> args)
            : base(args)
        {
            if (args.Count != 5)
                Logging.Write("Inavlid number of arguments passed into CombatUseItem behavior!");

            uint itemId;
            if (!uint.TryParse(Args["ItemId"], out itemId))
                Logging.Write("Parsing mobid in CombatUseItem behavior failed! please check your profile!");

            int npcID;
            if (!int.TryParse(Args["NpcId"], out npcID))
                Logging.Write("Parsing mobid in CombatUseItem behavior failed! please check your profile!");

            int numberoftimes;
            if (!int.TryParse(Args["NumOfTimes"], out numberoftimes))
                Logging.Write("Parsing mobid in CombatUseItem behavior failed! please check your profile!");

            int hpleftamount;
            if (!int.TryParse(Args["HpLeftAmount"], out hpleftamount))
                Logging.Write("Parsing mobid in CombatUseItem behavior failed! please check your profile!");

            WoWPoint location;
            string locationString = Args["Location"];
            float x, y, z;
            if (!float.TryParse(locationString.Split(' ')[0], out x))
                Logging.Write("Couldn't parse X value in CombatUseItem behavior");

            if (!float.TryParse(locationString.Split(' ')[1], out y))
                Logging.Write("Couldn't parse Y value in CombatUseItem behavior");

            if (!float.TryParse(locationString.Split(' ')[2], out z))
                Logging.Write("Couldn't parse Z value in CombatUseItem behavior");

            ItemID = itemId;
            NPCID = npcID;
            Counter = 1;
            Counter123 = 0;
            HPLeftAmount = hpleftamount;
            MovedToTarget = false;
            NumberOfTimes = numberoftimes;
            Location = new WoWPoint(x, y, z);
        }

        public WoWPoint Location { get; private set; }
        public int Counter { get; set; }
        public int Counter123 { get; set; }
        public uint ItemID { get; set; }
        public int NPCID { get; set; }
        public bool MovedToTarget;
        public int NumberOfTimes { get; set; }
        public int HPLeftAmount { get; set; }

        public static LocalPlayer me = ObjectManager.Me;

        public List<WoWUnit> npcList;


        #region Overrides of CustomForcedBehavior

        private Composite _root;
        protected override Composite CreateBehavior()
        {
            return _root ?? (_root =
                new PrioritySelector(

                    new Decorator(ret => Counter > NumberOfTimes,
                        new Action(ret => _isDone = true)),

                        new PrioritySelector(

                           new Decorator(ret => !MovedToTarget,
                                new Action(delegate
                                {
                                    Counter123++;
                                    if (me.Auras.ContainsKey("Freezing Trap Effect"))
                                    {
                                        Logging.Write("HasAura");
                                        CastSpell();
                                        Counter++;
                                        return RunStatus.Success;
                                    }

                                    WoWPoint destination1 = new WoWPoint(Location.X, Location.Y, Location.Z);
                                    WoWPoint[] pathtoDest1 = Styx.Logic.Pathing.Navigator.GeneratePath(me.Location, destination1);

                                    foreach (WoWPoint p in pathtoDest1)
                                    {
                                        while (!me.Dead && p.Distance(me.Location) > 3)
                                        {
                                            Thread.Sleep(100);
                                            WoWMovement.ClickToMove(p);
                                        }
                                    }
                                    //Styx.Logic.Combat.SpellManager.

                                    return RunStatus.Running;

                                })
                                ),

                            new Decorator(ret => StyxWoW.Me.IsMoving,
                                new Action(delegate
                                {
                                    WoWMovement.MoveStop();
                                    StyxWoW.SleepForLagDuration();
                                })
                                ),

                            new Action(ret => Navigator.MoveTo(Location))
                        )
                    ));
        }

        public void CastSpell()
        {
            Logging.Write("Casted Spell " + Counter + " Times out of " + NumberOfTimes);
            WoWItem ItemUseage = me.CarriedItems.Where(item => item.Entry.Equals(ItemID)).FirstOrDefault();

            ItemUseage.Interact();
            Counter++;
            Thread.Sleep(3000);
        }



        private bool _isDone;
        public override bool IsDone
        {
            get { return _isDone; }
        }

        #endregion
    }
}
