using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using Styx.Database;
using Styx.Logic.Combat;
using Styx.Helpers;
using Styx.Logic.Inventory.Frames.Gossip;
using Styx.Logic.Pathing;
using Styx.Logic.Profiles.Quest.Order;
using Styx.Logic.Questing;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using TreeSharp;
using Action = TreeSharp.Action;

namespace Styx.Bot.Quest_Behaviors
{
    public class VehicleBehavior : CustomForcedBehavior
    {
        #region Overrides of CustomForcedBehavior

        public VehicleBehavior(Dictionary<string, string> args)
            : base(args)
        {
            if (args.Count == 7)
            {
                Logging.Write("Activating Emergency Gnome Bombing Tech!");

                uint npcmountid;
                if (!uint.TryParse(Args["NpcMountID"], out npcmountid))
                    Logging.Write("Parsing mobid in VehicleBehavior behavior failed! please check your profile!");

                uint vehicleID;
                if (!uint.TryParse(Args["VehicleID"], out vehicleID))
                    Logging.Write("Parsing mobid in VehicleBehavior behavior failed! please check your profile!");

                uint spellID;
                if (!uint.TryParse(Args["SpellID"], out spellID))
                    Logging.Write("Parsing mobid in VehicleBehavior behavior failed! please check your profile!");

                uint fireheight;
                if (!uint.TryParse(Args["FireHeight"], out fireheight))
                    Logging.Write("Parsing mobid in VehicleBehavior behavior failed! please check your profile!");

                string locationString = Args["FireLocation"];
                float x, y, z;
                if (!float.TryParse(locationString.Split(' ')[0], out x))
                    Logging.Write("Couldn't parse X value in VehicleBehavior behavior");

                if (!float.TryParse(locationString.Split(' ')[1], out y))
                    Logging.Write("Couldn't parse Y value in VehicleBehavior behavior");

                if (!float.TryParse(locationString.Split(' ')[2], out z))
                    Logging.Write("Couldn't parse Z value in VehicleBehavior behavior");

                string locationString1 = Args["TargetLocation"];
                float x1, y1, z1;
                if (!float.TryParse(locationString1.Split(' ')[0], out x1))
                    Logging.Write("Couldn't parse X value in CastSpellOn behavior");

                if (!float.TryParse(locationString1.Split(' ')[1], out y1))
                    Logging.Write("Couldn't parse Y value in CastSpellOn behavior");

                if (!float.TryParse(locationString1.Split(' ')[2], out z1))
                    Logging.Write("Couldn't parse Z value in CastSpellOn behavior");

                uint questId;
                if (!uint.TryParse(Args["QuestId"], out questId))
                    Logging.Write("Parsing QuestID in NoControlVehicle behavior failed! please check your profile!");

                QuestId = questId;

                NpcMountID = npcmountid;
                FireHeight = fireheight;
                SpellCastID = spellID;
                SpellType = 1;
                VehicleID = vehicleID;
                FirePoint = new WoWPoint(x, y, z);
                TargetPoint = new WoWPoint(x1, y1, z1);
            }
            else if (args.Count == 8)
            {

                Logging.Write("Activating Emergency Gnome Bombing Tech!");

                uint npcmountid;
                if (!uint.TryParse(Args["NpcMountID"], out npcmountid))
                    Logging.Write("Parsing mobid in InteractWith behavior failed! please check your profile!");

                uint vehicleID;
                if (!uint.TryParse(Args["VehicleID"], out vehicleID))
                    Logging.Write("Parsing mobid in InteractWith behavior failed! please check your profile!");

                uint spellID;
                if (!uint.TryParse(Args["SpellID"], out spellID))
                    Logging.Write("Parsing mobid in InteractWith behavior failed! please check your profile!");

                uint fireheight;
                if (!uint.TryParse(Args["FireHeight"], out fireheight))
                    Logging.Write("Parsing mobid in InteractWith behavior failed! please check your profile!");

                string locationString = Args["FireLocation"];
                float x, y, z;
                if (!float.TryParse(locationString.Split(' ')[0], out x))
                    Logging.Write("Couldn't parse X value in CastSpellOn behavior");

                if (!float.TryParse(locationString.Split(' ')[1], out y))
                    Logging.Write("Couldn't parse Y value in CastSpellOn behavior");

                if (!float.TryParse(locationString.Split(' ')[2], out z))
                    Logging.Write("Couldn't parse Z value in CastSpellOn behavior");

                string locationString1 = Args["TargetLocation"];
                float x1, y1, z1;
                if (!float.TryParse(locationString1.Split(' ')[0], out x1))
                    Logging.Write("Couldn't parse X value in CastSpellOn behavior");

                if (!float.TryParse(locationString1.Split(' ')[1], out y1))
                    Logging.Write("Couldn't parse Y value in CastSpellOn behavior");

                if (!float.TryParse(locationString1.Split(' ')[2], out z1))
                    Logging.Write("Couldn't parse Z value in CastSpellOn behavior");

                string locationString2 = Args["PreviousFireLocation"];
                float x2, y2, z2;
                if (!float.TryParse(locationString2.Split(' ')[0], out x2))
                    Logging.Write("Couldn't parse X value in CastSpellOn behavior");

                if (!float.TryParse(locationString2.Split(' ')[1], out y2))
                    Logging.Write("Couldn't parse Y value in CastSpellOn behavior");

                if (!float.TryParse(locationString2.Split(' ')[2], out z2))
                    Logging.Write("Couldn't parse Z value in CastSpellOn behavior");

                uint questId;
                if (!uint.TryParse(Args["QuestId"], out questId))
                    Logging.Write("Parsing QuestID in NoControlVehicle behavior failed! please check your profile!");

                QuestId = questId;

                NpcMountID = npcmountid;
                SpellType = 2;
                FireHeight = fireheight;
                SpellCastID = spellID;
                VehicleID = vehicleID;
                FirePoint = new WoWPoint(x, y, z);
                TargetPoint = new WoWPoint(x1, y1, z1);
                MountedPoint = new WoWPoint(x2, y2, z2);
            }
            else
            {
                Logging.Write("Invalid amount of Args!");
            }


            Counter = 0;
            SpellType = 0;


        }

        public WoWPoint FirePoint { get; private set; }
        public WoWPoint MountedPoint { get; private set; }
        public WoWPoint TargetPoint { get; private set; }
        public int Counter { get; set; }
        public int SpellType { get; set; }
        public uint SpellCastID { get; set; }
        public uint VehicleID { get; set; }
        public uint NpcMountID { get; set; }

        public uint QuestId { get; set; }
        public uint FireHeight { get; set; }
        public uint RotationFace { get; set; }

        public static LocalPlayer me = ObjectManager.Me;

        public List<WoWUnit> npcaroundlist;
        public List<WoWUnit> vehicleList;
        public List<WoWUnit> npcvehicleList;

        static public bool inVehicle { get { return Lua.GetReturnVal<bool>("return  UnitUsingVehicle(\"player\")", 0); } }

        /// <summary>
        /// A Queue for npc's we need to talk to
        /// </summary>
        //private WoWUnit CurrentUnit { get { return ObjectManager.GetObjectsOfType<WoWUnit>().FirstOrDefault(unit => unit.Entry == VehicleId); } }

        private Composite _root;
        protected override Composite CreateBehavior()
        {
            return _root ??
                   (_root =
                    new Decorator(
                        ret => // If QuestId is set, make sure we have the quest, and it's not completed.
                        (QuestId != 0 && me.QuestLog.GetQuestById(QuestId) != null &&
                         !me.QuestLog.GetQuestById(QuestId).IsCompleted)
                        // If no quest ID is set, just run it anyway. Lets hope there are proper checkpoints in place to avoid bugging out
                        || QuestId == 0,
                        new PrioritySelector(
                        new Decorator(ret => Counter >= 1, new Action(ret => _isDone = true)),
                        new PrioritySelector(
                        new Decorator(
                        ret => !inVehicle,
                        new Action(
                        delegate
                            {
                                UpdateNpcList();

                                if (npcvehicleList.Count >= 1 && npcvehicleList[0].WithinInteractRange)
                                {
                                    npcaroundlist =
                                        ObjectManager.GetObjectsOfType<WoWUnit>().Where(
                                            ret => (ret.Entry != VehicleID) && !ret.Dead).OrderBy(
                                                u => u.Location.Distance(me.Location)).ToList();

                                    npcaroundlist[0].Face();

                                    Styx.Logic.Combat.LegacySpellManager.CastSpellById(6603);

                                    MountedPoint = me.Location;
                                    npcvehicleList[0].Interact();
                                    return RunStatus.Success;
                                }
                                else
                                {
                                    Navigator.MoveTo(npcvehicleList[0].Location);
                                    Thread.Sleep(300);
                                    return RunStatus.Running;
                                }

                            })),
                        new Decorator(
                        ret => inVehicle,
                        new Action(
                        delegate
                            {
                                vehicleList =
                                    ObjectManager.GetObjectsOfType<WoWUnit>().Where(
                                        ret => (ret.Entry == VehicleID) && !ret.Dead).OrderBy(
                                            u => u.Location.Distance(MountedPoint)).ToList();

                                if (vehicleList[0].Location.Distance(FirePoint) > 10)
                                {

                                    WoWPoint destination1 = new WoWPoint(FirePoint.X, FirePoint.Y, FirePoint.Z);
                                    WoWPoint[] pathtoDest1 = Styx.Logic.Pathing.Navigator.GeneratePath(
                                        MountedPoint, destination1);

                                    foreach (WoWPoint p in pathtoDest1)
                                    {
                                        while (!vehicleList[0].Dead && p.Distance(vehicleList[0].Location) > 7)
                                        {
                                            Thread.Sleep(100);
                                            WoWMovement.ClickToMove(p);
                                        }
                                    }

                                    Thread.Sleep(400);
                                }

                                WoWMovement.ClickToMove(TargetPoint);
                                Thread.Sleep(500);
                                WoWMovement.MoveStop();

                                Lua.DoString("VehicleAimRequestNormAngle(0." + FireHeight + ")");
                                Thread.Sleep(400);

                                // Logging.Write("8 " + (Environment.TickCount - timer));

                                Lua.DoString("CastSpellByID(" + SpellCastID + ")");
                                // TimesUsedCounter++;
                                //Thread.Sleep(OftenToUse);
                                Thread.Sleep(700);
                                Counter++;


                                return RunStatus.Success;


                            })),
                        new Action(ret => Logging.Write(""))))));
        }

        public void UpdateNpcList()
        {
            ObjectManager.Update();

            vehicleList = ObjectManager.GetObjectsOfType<WoWUnit>()
              .Where(ret => (ret.Entry == VehicleID) && !ret.Dead).OrderBy(u => u.Distance).ToList();

            npcvehicleList = ObjectManager.GetObjectsOfType<WoWUnit>()
              .Where(ret => (ret.Entry == NpcMountID) && !ret.Dead).OrderBy(u => u.Distance).ToList();
        }

        private bool _isDone;
        public override bool IsDone
        {
            get { return _isDone; }
        }

        #endregion
    }
}
