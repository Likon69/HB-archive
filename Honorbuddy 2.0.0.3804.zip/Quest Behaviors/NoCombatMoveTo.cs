using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using Styx.Database;
using Styx.Logic.Combat;
using Styx.Helpers;
using Styx.Logic.Inventory.Frames.Gossip;
using Styx.Logic.Pathing;
using Styx.Logic.Profiles.Quest.Order;
using Styx.Logic.Questing;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using TreeSharp;
using Action = TreeSharp.Action;

namespace Styx.Bot.Quest_Behaviors
{
    public class NoCombatMoveTo : CustomForcedBehavior
    {
        #region Overrides of CustomForcedBehavior

        public NoCombatMoveTo(Dictionary<string, string> args)
            : base(args)
        {
            WoWPoint location;
            string locationString = Args["Location"];

            float x, y, z;
            if (!float.TryParse(locationString.Split(' ')[0], out x))
                Logging.Write("Couldn't parse X value in NoCombatMoveTo behavior");

            if (!float.TryParse(locationString.Split(' ')[1], out y))
                Logging.Write("Couldn't parse Y value in NoCombatMoveTo behavior");

            if (!float.TryParse(locationString.Split(' ')[2], out z))
                Logging.Write("Couldn't parse Z value in NoCombatMoveTo behavior");

            MovePoint = new WoWPoint(x,y,z);

            Counter = 0;
            uint questId;
            if (!uint.TryParse(Args["QuestId"], out questId))
                Logging.Write("Parsing QuestID in UseGameObject behavior failed! please check your profile!");
            QuestId = questId;
        }

        public uint QuestId { get; set; }

        public WoWPoint MovePoint { get; private set; }
        public int Counter { get; set; }

        public static LocalPlayer me = ObjectManager.Me;

        public List<WoWUnit> npcList;

        private Composite _root;
        protected override Composite CreateBehavior()
        {
            return _root ??
                   (_root =
                    new Decorator(
                        ret => // If QuestId is set, make sure we have the quest, and it's not completed.
                        (QuestId != 0 && me.QuestLog.GetQuestById(QuestId) != null &&
                         !me.QuestLog.GetQuestById(QuestId).IsCompleted)
                        // If no quest ID is set, just run it anyway. Lets hope there are proper checkpoints in place to avoid bugging out
                        || QuestId == 0,
                        new PrioritySelector(
                        new Decorator(ret => Counter >= 1, new Action(ret => _isDone = true)),
                        new PrioritySelector(
                        new Decorator(
                        ret => Counter == 0,
                        new Action(
                        delegate
                            {

                                WoWPoint destination1 = new WoWPoint(MovePoint.X, MovePoint.Y, MovePoint.Z);
                                WoWPoint[] pathtoDest1 = Styx.Logic.Pathing.Navigator.GeneratePath(
                                    me.Location, destination1);

                                foreach (WoWPoint p in pathtoDest1)
                                {
                                    while (!me.Dead && p.Distance(me.Location) > 3)
                                    {
                                        if (me.Combat)
                                        {
                                            break;
                                        }
                                        Thread.Sleep(100);
                                        WoWMovement.ClickToMove(p);
                                    }

                                    if (me.Combat)
                                    {
                                        break;
                                    }
                                }

                                if (me.Combat)
                                {

                                    return RunStatus.Success;
                                }
                                else if (!me.Combat)
                                {
                                    Counter++;
                                    return RunStatus.Success;
                                }

                                return RunStatus.Running;
                            })),
                        new Action(ret => Logging.Write(""))))));
        }

        private bool _isDone;
        public override bool IsDone
        {
            get { return _isDone; }
        }

        #endregion
    }
}

