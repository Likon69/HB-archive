using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using Styx.Database;
using Styx.Helpers;
using Styx.Logic.Inventory.Frames.Gossip;
using Styx.Logic.Pathing;
using Styx.Logic.Questing;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using TreeSharp;
using Action = TreeSharp.Action;

namespace Styx.Bot.Quest_Behaviors
{
    public class FollowNpcUntil : CustomForcedBehavior
    {
        public FollowNpcUntil(Dictionary<string, string> args)
            : base(args)
        {
            uint endnpcId;
            if (!uint.TryParse(Args["EndNpcId"], out endnpcId))
                Logging.Write("Parsing mobid in FollowNpcUntil behavior failed! please check your profile!");

            int npcID;
            if (!int.TryParse(Args["NpcId"], out npcID))
                Logging.Write("Parsing mobid in FollowNpcUntil behavior failed! please check your profile!");

            WoWPoint location;
            string locationString = Args["Location"];
            float x, y, z;
            if (!float.TryParse(locationString.Split(' ')[0], out x))
                Logging.Write("Couldn't parse X value in FollowNpcUntil behavior");

            if (!float.TryParse(locationString.Split(' ')[1], out y))
                Logging.Write("Couldn't parse Y value in FollowNpcUntil behavior");

            if (!float.TryParse(locationString.Split(' ')[2], out z))
                Logging.Write("Couldn't parse Z value in FollowNpcUntil behavior");

            EndNpcID = endnpcId;
            NPCID = npcID;
            Counter = 1;
            MovedToTarget = false;
            Location = new WoWPoint(x, y, z);
        }

        public WoWPoint Location { get; private set; }
        public int Counter { get; set; }
        public int NPCID { get; set; }
        public bool MovedToTarget;
        public uint EndNpcID { get; set; }

        public static LocalPlayer me = ObjectManager.Me;

        public List<WoWUnit> npcList;
        public List<WoWUnit> endList;

        /// <summary>
        /// A Queue for npc's we need to talk to
        /// </summary>
        //private WoWUnit CurrentUnit { get { return ObjectManager.GetObjectsOfType<WoWUnit>().FirstOrDefault(unit => unit.Distance < 100 && unit.Entry == MobId); } }

        #region Overrides of CustomForcedBehavior

        private Composite _root;
        protected override Composite CreateBehavior()
        {
            return _root ?? (_root =
                new PrioritySelector(

                    new Decorator(ret => Counter > 1,
                        new Action(ret => _isDone = true)),

                        new PrioritySelector(

                           new Decorator(ret => !MovedToTarget,
                                new Action(delegate
                                {
                                    ObjectManager.Update();

                                    npcList = ObjectManager.GetObjectsOfType<WoWUnit>()
                                        .Where(u => u.Entry == NPCID)
                                        .OrderBy(u => u.Distance).ToList();

                                    endList = ObjectManager.GetObjectsOfType<WoWUnit>()
                                        .Where(u => u.Entry == EndNpcID)
                                        .OrderBy(u => u.Distance).ToList();

                                    if (endList.Count >= 1 && endList[0].Location.Distance(me.Location) < 20)
                                    {
                                        Counter++;
                                        return RunStatus.Success;
                                    }
                                    else if (npcList.Count >= 1)
                                    {

                                        WoWPoint destination1 = new WoWPoint(npcList[0].X, npcList[0].Y, npcList[0].Z);
                                        WoWPoint[] pathtoDest1 = Styx.Logic.Pathing.Navigator.GeneratePath(me.Location, destination1);

                                        foreach (WoWPoint p in pathtoDest1)
                                        {
                                            while (!me.Dead && p.Distance(me.Location) > 3)
                                            {
                                                Thread.Sleep(100);
                                                WoWMovement.ClickToMove(p);
                                            }
                                        }

                                    } else
                                    {
                                        WoWPoint destination1 = new WoWPoint(Location.X, Location.Y, Location.Z);
                                        WoWPoint[] pathtoDest1 = Styx.Logic.Pathing.Navigator.GeneratePath(me.Location,
                                                                                                           destination1);

                                        foreach (WoWPoint p in pathtoDest1)
                                        {
                                            while (!me.Dead && p.Distance(me.Location) > 3)
                                            {
                                                Thread.Sleep(100);
                                                WoWMovement.ClickToMove(p);
                                            }
                                        }
                                    }

                                    return RunStatus.Running;

                                })
                                ),

                            new Action(ret => Navigator.MoveTo(Location))
                        )
                    ));
        }

        private bool _isDone;
        public override bool IsDone
        {
            get { return _isDone; }
        }

        #endregion
    }
}
