using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using Styx.Database;
using Styx.Helpers;
using Styx.Logic.Inventory.Frames.Gossip;
using Styx.Logic.Pathing;
using Styx.Logic.Questing;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using TreeSharp;
using Action = TreeSharp.Action;

namespace Styx.Bot.Quest_Behaviors
{
    public class ItemWhileMoving : CustomForcedBehavior
    {
        public ItemWhileMoving(Dictionary<string, string> args)
            : base(args)
        {
            if (args.Count != 2)
                Logging.Write("Inavlid number of arguments passed into ItemWhileMoving behavior!");

            uint itemId;
            if (!uint.TryParse(Args["ItemId"], out itemId))
                Logging.Write("Parsing mobid in ItemWhileMoving behavior failed! please check your profile!");

            WoWPoint location;
            string locationString = Args["EndLocation"];
            float x, y, z;
            if (!float.TryParse(locationString.Split(' ')[0], out x))
                Logging.Write("Couldn't parse X value in ItemWhileMoving behavior");

            if (!float.TryParse(locationString.Split(' ')[1], out y))
                Logging.Write("Couldn't parse Y value in ItemWhileMoving behavior");

            if (!float.TryParse(locationString.Split(' ')[2], out z))
                Logging.Write("Couldn't parse Z value in ItemWhileMoving behavior");

            ItemID = itemId;
            Counter = 0;
            Counter123 = 1;
            MovedToTarget = false;
            Location = new WoWPoint(x, y, z);
        }

        public WoWPoint Location { get; private set; }
        public int Counter { get; set; }
        public int Counter123 { get; set; }
        public uint ItemID { get; set; }
        public int NPCID { get; set; }
        public bool MovedToTarget;
        public int NumberOfTimes { get; set; }

        public static LocalPlayer me = ObjectManager.Me;

        public List<WoWUnit> npcList;


        #region Overrides of CustomForcedBehavior

        private Composite _root;
        protected override Composite CreateBehavior()
        {
            return _root ?? (_root =
                new PrioritySelector(

                    new Decorator(ret => Counter > 0,
                        new Action(ret => _isDone = true)),

                        new PrioritySelector(

                           new Decorator(ret => !MovedToTarget,
                                new Action(delegate
                                {
                                    if (Location.Distance(me.Location) > 10)
                                    {
                                        WoWMovement.ClickToMove(Location);
                                        Logging.Write("2");
                                        CastSpell();
                                        Counter123++;
                                    }
                                    else
                                    {
                                        Logging.Write("1");
                                        Counter++;
                                        return RunStatus.Success;
                                    }

                                    Thread.Sleep(1000);
                                    return RunStatus.Running;

                                })
                                ),

                            new Decorator(ret => StyxWoW.Me.IsMoving,
                                new Action(delegate
                                {
                                    WoWMovement.MoveStop();
                                    StyxWoW.SleepForLagDuration();
                                })
                                ),

                            new Action(ret => Navigator.MoveTo(Location))
                        )
                    ));
        }

        public void CastSpell()
        {
            Logging.Write("Casted Spell " + Counter + " Times out of " + NumberOfTimes);
            WoWItem ItemUseage = me.CarriedItems.Where(item => item.Entry.Equals(ItemID)).FirstOrDefault();
            Logging.Write("3");

            ItemUseage.Interact();
            Thread.Sleep(3000);
        }



        private bool _isDone;
        public override bool IsDone
        {
            get { return _isDone; }
        }

        #endregion
    }
}
