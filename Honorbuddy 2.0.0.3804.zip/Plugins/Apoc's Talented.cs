using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Styx.Combat.CombatRoutine;
using Styx.Plugins.PluginClass;
using Styx.WoWInternals;

namespace Styx.Bot.Plugins
{
    class TalentSpecs
    {
        public static Dictionary<WoWClass, Dictionary<int, List<TalentPlacement>>> Specs =
            new Dictionary<WoWClass, Dictionary<int, List<TalentPlacement>>>
                {

                    {
                        WoWClass.Druid, new Dictionary<int, List<TalentPlacement>>
                            {
                                // Balance
                                { 1, new List<TalentPlacement>() },

                                // Feral
                                {
                                    2, new List<TalentPlacement>
                                        {
                                            // Feral Swiftness
                                            new TalentPlacement(2, 1, 2),
                                            // Furor
                                            new TalentPlacement(2, 2, 3),
                                            // Fury Swipes
                                            new TalentPlacement(2, 5, 3),
                                            // Primal Fury
                                            new TalentPlacement(2, 6, 2),
                                            // King of the Jungle
                                            new TalentPlacement(2, 8, 3),
                                            // Feral Charge
                                            new TalentPlacement(2, 9, 1),
                                            // Stampede (1/2)
                                            new TalentPlacement(2, 10, 1),
                                            // Leader of the Pack
                                            new TalentPlacement(2, 12, 1),
                                            // Stampede (2/2)
                                            new TalentPlacement(2, 10, 2),
                                            // Predatory Strikes
                                            new TalentPlacement(2, 3, 2),
                                            // Feral Agression (1/2)
                                            new TalentPlacement(2, 7, 1),
                                            // Primal Madness
                                            new TalentPlacement(2, 15, 2),
                                            // Endless Carnage
                                            new TalentPlacement(2, 17, 2),
                                            // Feral Agression (2/2)
                                            new TalentPlacement(2, 7, 2),
                                            // Rend and Tear
                                            new TalentPlacement(2, 20, 3),
                                            // Blood in the Water
                                            new TalentPlacement(2, 19, 2),
                                            // Berserk
                                            new TalentPlacement(2, 22, 1),
                                            // Heart of the Wild
                                            new TalentPlacement(3, 4, 3),
                                            // Natural Shapeshifter
                                            new TalentPlacement(3, 2, 2),
                                            // Natural Shapeshifter
                                            new TalentPlacement(3, 6, 1),
                                            // Perseverance
                                            new TalentPlacement(3, 5, 3),
                                            // Infected Wounds
                                            new TalentPlacement(2, 4, 1),
                                        }
                                    },

                                // Resto
                                { 3, new List<TalentPlacement>() },
                            }
                        }
                };
    }

    class TalentPlacement
    {
        public int Tab;
        public int Index;
        public int Count;
        public string Name;

        public TalentPlacement(int tab, int index, int count)
        {
            Tab = tab;
            Index = index;
            Count = count;
        }

        public TalentPlacement(int tab, int index, int count, string name)
        {
            Tab = tab;
            Index = index;
            Count = count;
            Name = name;
        }

        public TalentPlacement(string name, int count)
        {
            Name = name;
            Count = count;
        }
    }

    class ApocTalented : HBPlugin
    {


        #region Non-HB Specific
        private bool HasLearnedMajorTree { get { return Lua.GetReturnVal<string>("return PlayerTalentFramePanel1SelectTreeButton:IsShown()", 0) != "1"; } }
        public void SelectMajorTalentTree(int index)
        {
            Lua.DoString("PlayerTalentFramePanel" + index + "SelectTreeButton:Click()");
        }

        private List<TalentPlacement> BuildLearnedTalentDictionary()
        {
            List<TalentPlacement> ret = new List<TalentPlacement>();
            using (new FrameLock())
            {
                for (int tabIndex = 1; tabIndex <= 3; tabIndex++)
                {
                    int numTalents = Lua.GetReturnVal<int>("return GetNumTalents(" + tabIndex + ", false, false)", 0);
                    for (int talentIndex = 1; talentIndex <= numTalents; talentIndex++)
                    {
                        var vals = Lua.GetReturnValues("return GetTalentInfo(" + tabIndex + ", " + talentIndex + ")");
                        var name = vals[0];
                        var rank = int.Parse(vals[4]);
                        ret.Add(new TalentPlacement(tabIndex, talentIndex, rank, name));
                    }
                }
            }
            return ret;
        }

        private void LearnTalent(int tab, int index)
        {
            Lua.DoString(string.Format("AddPreviewTalentPoints({0}, {1}, 1)", tab, index));
        }

        private List<TalentPlacement> GetCurrentSpecTalentPlacements()
        {
            var classDictionary = TalentSpecs.Specs[StyxWoW.Me.Class];
            var talentPoints = new List<int>(
                new[]
                    {
                        Lua.GetReturnVal<int>("return GetTalentTabInfo(1)", 4),
                        Lua.GetReturnVal<int>("return GetTalentTabInfo(2)", 4),
                        Lua.GetReturnVal<int>("return GetTalentTabInfo(2)", 4)
                    });

            var bestTab = talentPoints.IndexOf(talentPoints.Max());
            if (talentPoints.All(i => i == 0))
                bestTab = GetDefaultTalentsForClass()+1;

            var placement = classDictionary[bestTab];

            return placement;
        }

        private static int GetDefaultTalentsForClass()
        {
            switch (StyxWoW.Me.Class)
            {
                case WoWClass.Warrior:
                    return 1;
                case WoWClass.Paladin:
                    return 2;
                case WoWClass.Hunter:
                    return 0;
                case WoWClass.Rogue:
                    return 0;
                case WoWClass.Priest:
                    return 2;
                case WoWClass.DeathKnight:
                    return 0;
                case WoWClass.Shaman:
                    return 0;
                case WoWClass.Mage:
                    return 2;
                case WoWClass.Warlock:
                    return 1;
                case WoWClass.Druid:
                    return 1;
                default:
                    return 0;
            }
        }

        private void InitializeHooks()
        {
            Lua.Events.AttachEvent("CHARACTER_POINTS_CHANGED", HandleTalentPointsChanged);
        }

        private void HandleTalentPointsChanged(object sender, LuaEventArgs args)
        {
            if (!HasLearnedMajorTree)
                SelectMajorTalentTree(GetDefaultTalentsForClass() + 1);

            var learned = BuildLearnedTalentDictionary();
            var wanted = GetCurrentSpecTalentPlacements();

            int numAvailable = Lua.GetReturnVal<int>("return GetUnspentTalentPoints()", 0);

            foreach (var tp in wanted)
            {
                if (numAvailable == 0)
                    continue;

                var lt = learned.FirstOrDefault(t => (t.Name == tp.Name) || (t.Index == tp.Index && t.Tab == tp.Tab));

                int numLearned = 0;

                if (lt != null)
                    numLearned = lt.Count;

                while (numAvailable != 0 && numLearned < tp.Count)
                {
                    LearnTalent(tp.Tab, tp.Index);
                    numLearned++;
                    numAvailable--;
                }
            }

            Lua.DoString("LearnPreviewTalents() ");
        }
        #endregion

        private bool _initialized;
        public override void Pulse()
        {
            if (!_initialized)
            {
                InitializeHooks();
                _initialized = true;
            }
        }

        public override string Name { get { return "Apoc's Talented"; } }

        public override string Author { get { return "Apoc"; } }

        public override Version Version { get { return new Version(1,0,0,0); } }

        public override bool WantButton  { get { return true; } }

        public override void OnButtonPress()
        {
            HandleTalentPointsChanged(null, null);
        }
    }
}
