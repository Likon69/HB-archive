﻿using System;
using System.Reflection;
using System.Windows.Forms;
using System.Drawing;
using System.Threading;
using System.Globalization;
using Styx.Helpers;
using Styx.Plugins.PluginClass;
using TreeSharp;

namespace Styx.Bot.Plugins
{
    public class ABLoader : BotBase
    {
        private readonly BotBase _botBase;

        public ABLoader()
        {
			try
			{
				Thread.CurrentThread.CurrentCulture = new CultureInfo("en-US");
				Assembly HB = Assembly.GetEntryAssembly();
				string version = HB.GetName().Version.ToString();
				string ver = "2.0.0.3804";

				if (version != ver)
				{
					Logging.Write(Color.DarkSlateBlue, string.Format("ArchaeologyBuddy will only work with HB version: {0}. You are using version: {1}:", ver, version));
				}

				string path = Logging.ApplicationPath + @"\Bots\ArchaeologyBuddy\ArchaeologyBuddy.dll";
				Assembly asm = Assembly.LoadFrom(path);

				foreach(Type t in asm.GetTypes())
				{
					if(t.IsSubclassOf(typeof(BotBase)) && t.IsClass)
					{
						var obj = Activator.CreateInstance(t);
						_botBase = (BotBase)obj;
					}
				}
			}
			catch (System.Threading.ThreadAbortException) { throw; }
			catch (Exception e)
			{
				Logging.Write(Color.DarkRed, "An error occured while loading ArchaeologyBuddy");
				Logging.WriteDebug(e.ToString());
			}
        }

        #region Overrides of BotBase

        public override string Name
        {
            get { return _botBase.Name; }
        }

        public override Composite Root
        {
            get { return _botBase.Root; }
        }

        public override PulseFlags PulseFlags
        {
            get { return _botBase.PulseFlags; }
        }

        public override Form ConfigurationForm { get { return _botBase.ConfigurationForm; } }

        public override void Initialize()
        {
            _botBase.Initialize();
        }

        public override void Pulse()
        {
            _botBase.Pulse();
        }

        public override void Start()
        {
            _botBase.Start();
        }

        public override void Stop()
        {
            _botBase.Stop();
        }

        #endregion
    }
}
