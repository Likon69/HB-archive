﻿using System.Collections.Generic;

using Styx;
using Styx.CommonBot;
using Styx.TreeSharp;
using Styx.WoWInternals.WoWObjects;
#if USE_DUNGEONBUDDY_DLL
using Bots.DungeonBuddyDll.Attributes;
namespace Bots.DungeonBuddyDll.Dungeon_Scripts.Classic
#else
using Bots.DungeonBuddy.Profiles;
    using Bots.DungeonBuddy.Attributes;
    using Bots.DungeonBuddy.Helpers;
    namespace Bots.DungeonBuddy.Dungeon_Scripts.Classic
#endif
{
    public class RagefireChasm : Dungeon
    {
        #region Overrides of Dungeon

        /// <summary> The mapid of this dungeon. </summary>
        /// <value>The map identifier.</value>
        public override uint DungeonId
        {
            get { return 4; }
        }

        public override WoWPoint Entrance
        {
            get { return new WoWPoint(1820.646, -4427.459, -20.67462); }
        }

        public override void WeighTargetsFilter(List<Targeting.TargetPriority> units)
        {
            foreach (Targeting.TargetPriority t in units)
            {
                WoWObject prioObject = t.Object;

                //We kill his adds first
                if (prioObject.Entry == 11319 || prioObject.Entry == 11318)
                {
                    t.Score += 400;
                }
            }
        }

        #endregion

        [EncounterHandler(11517, "Oggleflint")]
        public Composite OggleflintFight()
        {
            return
                new PrioritySelector();
        }

        [EncounterHandler(11520, "Taragaman")]
        public Composite TaragamanFight()
        {
            return
                new PrioritySelector();
        }

        [EncounterHandler(11518, "Jergosh the Invoker")]
        public Composite JergoshFight()
        {
            return
                new PrioritySelector();
        }

        [EncounterHandler(11519, "Bazzalan")]
        public Composite BazzalanFight()
        {
            return
                new PrioritySelector();
        }
    }
}