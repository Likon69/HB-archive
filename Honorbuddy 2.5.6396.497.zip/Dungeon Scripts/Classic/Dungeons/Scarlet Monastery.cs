﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Styx;
using Styx.CommonBot;
using Styx.TreeSharp;
using Styx.Pathing;
#if USE_DUNGEONBUDDY_DLL
using Bots.DungeonBuddyDll;
using Bots.DungeonBuddyDll.Profiles;
using Bots.DungeonBuddyDll.Attributes;
using Bots.DungeonBuddyDll.Helpers;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using Action = Styx.TreeSharp.Action;

namespace Bots.DungeonBuddyDll.Dungeon_Scripts.Classic
#else
using Bots.DungeonBuddy.Profiles;
using Bots.DungeonBuddy.Attributes;
using Bots.DungeonBuddy.Helpers;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using Action = Styx.TreeSharp.Action;

namespace Bots.DungeonBuddy.Dungeon_Scripts.Classic
#endif
{
    public class ScarletMonastery : Dungeon
    {
        #region Overrides of Dungeon

        public override uint DungeonId { get { return 164; } }

        public override WoWPoint Entrance { get { return new WoWPoint(2920.317, -799.8921, 160.3323); } }
        public override WoWPoint ExitLocation { get { return new WoWPoint(1124.471, 504.2796, 0.9892024); } }


        public override void RemoveTargetsFilter(List<WoWObject> units)
        {
            units.RemoveAll(
                ret =>
                {
                    var unit = ret as WoWUnit;
                    if (unit != null)
                    {
                    }
                    return false;
                });
        }

        public override void IncludeTargetsFilter(List<WoWObject> incomingunits, HashSet<WoWObject> outgoingunits)
        {
            foreach (var obj in incomingunits)
            {
                var unit = obj as WoWUnit;
                if (unit != null)
                {
                }
            }
        }

        public override void WeighTargetsFilter(List<Targeting.TargetPriority> units)
        {
            foreach (var priority in units)
            {
                var unit = priority.Object as WoWUnit;
                if (unit != null)
                {
                    if (unit.Entry == PileOfCorpsesId && StyxWoW.Me.IsDps())
                        priority.Score += 500;

                   // if (unit.Entry == EmpoweredZombie && StyxWoW.Me.IsDps())
                   //     priority.Score += 500;

                    if (unit.Entry == EvictedSoul && StyxWoW.Me.IsDps())
                        priority.Score += 400;
                }
            }
        }

        #endregion

        private const uint PileOfCorpsesId = 59722;
        private const uint EmpoweredZombie = 59930;
        private const uint EvictedSoul = 59974;
        private const uint FuelTankId = 59706;

        private WoWUnit FuelTank { get { return ObjectManager.GetObjectsOfType<WoWUnit>().Where(u => u.Entry == FuelTankId && u.DistanceSqr <= 10 * 10).OrderBy(u => u.DistanceSqr).FirstOrDefault(); } }
        // spirit gale 115291

        [EncounterHandler(59789, "Thalnos the Soulrender", BossRange = 100, Mode = CallBehaviorMode.Proximity)]
        public Composite ThalnostheSoulrenderEncounter()
        {
            WoWUnit fuelTank = null;
            return new PrioritySelector(
                    new Decorator(
                        ctx => (fuelTank = FuelTank) != null,
                        new PrioritySelector(
                            new Decorator(ctx => fuelTank.WithinInteractRange, new Action(ctx => fuelTank.Interact())),
                            new Decorator(ctx => !fuelTank.WithinInteractRange, new Action(ctx => Navigator.MoveTo(fuelTank.Location)))))
                   // ScriptHelpers.CreateRunAwayFromBad(ctx => true, 4, )         Find the ID of Spirit Gale.
                            );
        }
    }
}