﻿using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Threading;
using Hera.SpellsMan;
using Styx;
using Styx.Helpers;
using Styx.Logic;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;

namespace Hera.Helpers
{
    public static class Utils
    {
        private static string _logSpam;
        private static LocalPlayer Me { get { return ObjectManager.Me; } }
        private static WoWUnit CT { get { return Me.CurrentTarget; } }

        public static void Log(string msg, Color colour) { if (msg == _logSpam) return; Logging.Write(colour, msg); _logSpam = msg; }
        public static void Log(string msg){ if (msg == _logSpam) return;  Logging.Write(msg); _logSpam = msg; }
        
        public static Color Colour(string nameOfColour) { return Color.FromName(nameOfColour); }

        /// <summary>
        /// Thread sleep for the duration of your current in-game lag
        /// </summary>
        public static void LagSleep() { StyxWoW.SleepForLagDuration(); }
        
        /// <summary>
        /// TRUE if you have adds
        /// NB: I personally don't use this as it will sometimes return odd results
        /// </summary>
        public static bool Adds { get { return (Targeting.Instance.TargetList.Count > 1); } }

        /// <summary>
        /// The nunmber of adds in combat with you.
        /// </summary>
        public static int AddsCount { get { return Targeting.Instance.TargetList.Count; } }

        /// <summary>
        /// Perform a LUA query and return the result as a string
        /// </summary>
        /// <param name="lua"></param>
        /// <returns></returns>
        public static string LuaGetReturnValueString(string lua)
        {
            return Lua.GetReturnValues(lua, "stuff.lua")[0];
        }
    

        /// <summary>
        /// Checks for GCD, if you are casting a spell, got a target.
        /// Optionally if you know the spell and its cooldown status
        /// </summary>
        /// <param name="spellName">Spell you want to check if it exists and cooldown status</param>
        /// /// <param name="skipTargetCheck">If TRUE will not check for a valid target</param>
        /// <returns>TRUE is everything is ok and you should continue</returns>
        public static bool IsCommonChecksOk(string spellName, bool skipTargetCheck)
        {
            if (Hera.SpellsMan.Spell.IsGCD) return false;
            if (Me.IsCasting) return false;
            if (Me.Dead) return false;

            // You want to skip the target check if you are healing or casting a spell that does not require a target
            if (!skipTargetCheck)
            {
                if (!Me.GotTarget) return false;
                if (CT.Dead) return false;
            }

            // if we're not checking a spell then all is good
            if (spellName == "") return true;

            // check if we know the spell and its not on cooldown
            if (!Spell.IsKnown(spellName)) return false;
            if (Spell.IsOnCooldown(spellName)) return false;

            // all is good lets continue
            return true;
        }


        // Auto attack, kind of useful for melee classes :)
        public static void AutoAttack(bool autoAttackOn)
        {
            if (autoAttackOn) { if (Me.IsAutoAttacking) return; Lua.DoString("StartAttack()"); return; }
            Lua.DoString("StopAttack()");
        }

        // Do a simple loop while casting a spell. 
        // Required so you don't double heal 
        public static void WaitWhileCasting()
        {
            Thread.Sleep(150);
            while (Me.IsCasting) { Thread.Sleep(100); }
            //while (Me.ChanneledCastingSpellId != 0 || Me.IsCasting) { Thread.Sleep(100); }
            //while (Me.Casting != 0 || Me.ChanneledCasting != 0 || Me.IsCasting) { Thread.Sleep(100); }
        }

        // Are you in a battleground
        public static bool IsBattleground { get { return Battlegrounds.IsInsideBattleground; } }

        /// <summary>
        /// Return a WoWUnit type of a player in your party/raid in need of healing. Null if noone is in need of healing
        /// </summary>
        /// <param name="minimumHealth">The health a player must be to be considered for healing</param>
        /// <returns>WoWUnit the player most in need of healing</returns>
        public static WoWUnit PlayerNeedsHealing(double minimumHealth)
        {
            // If you're not in a party then just leave
            if (!Me.IsInParty) return null;

            // MyGroup is populated with raid members or party members, whichever you are in
            List<WoWPlayer> myGroup = Me.IsInRaid ? Me.RaidMembers : Me.PartyMembers;

            // Enumerate all players in myGroup and find the person with the lowest health %
            List<WoWPlayer> playersToHeal = (from o in myGroup
                                            let p = o.ToPlayer()
                                            where p.Distance < 40
                                                  && !p.Dead
                                                  && !p.IsGhost
                                                  && p.InLineOfSight
                                                  && p.HealthPercent < minimumHealth
                                            orderby p.HealthPercent ascending
                                            select p).ToList();

            // If playersToHeal is more than 0 then we have someone to heal
            // So return the first person in the list, they will be the most in need
            return playersToHeal.Count > 0 ? playersToHeal[0] : null;
        }

        /// <summary>
        /// The best target to attack, the one with the lowest health % and the closest
        /// </summary>
        public static WoWUnit BestTarget
        {
            get
            {
                List<WoWUnit> mobsHealth = (from o in ObjectManager.ObjectList
                                            where o is WoWUnit && o.Distance < 40
                                            let u = o.ToUnit()
                                            where u.Attackable && u.IsAlive && Me.Aggro && !Blacklist.Contains(u.Guid)
                                            //where u.Attackable && u.IsAlive && u.IsTargetingMeOrPet && Me.CurrentTargetGuid != u.Guid
                                            orderby u.HealthPercent, u.Distance2D ascending
                                            select u).ToList();

                return mobsHealth.Count > 0 ? mobsHealth[0] : null;
            }
        }

        /// <summary>
        /// Scan the area [searchRange] yard for hostile mobs
        /// </summary>
        /// <param name="searchRange"></param>
        /// <returns></returns>
        public static bool HostileMobsInRange(double searchRange)
        {
            List<WoWUnit> hlist =
               (from o in ObjectManager.ObjectList
                where o is WoWUnit
                let p = o.ToUnit()
                where p.Distance2D < searchRange
                      && !p.Dead
                      && p.IsHostile
                select p).ToList();


            return hlist.Count > 0;
        }

        

    }
}
