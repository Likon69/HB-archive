﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using Styx.Database;
using Styx.Helpers;
using Styx.Logic.Inventory.Frames.Gossip;
using Styx.Logic.Pathing;
using Styx.Logic.Profiles.Quest.Order;
using Styx.Logic.Questing;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using TreeSharp;
using Action = TreeSharp.Action;

namespace Styx.Bot.Quest_Behaviors
{
    public class TalkToAndListenToStory : CustomForcedBehavior 
    {
        #region Overrides of CustomForcedBehavior

        private Composite _root;

        public TalkToAndListenToStory(params object[] args) : base(args)
        {
            foreach(object o in args)
            {
                if(o is string)
                {
                    var s = o as string;

                    uint id;
                    if (uint.TryParse(s, out id))
                        _npcResults.Enqueue(NpcQueries.GetNpcById(id));
                    else
                        Logging.Write("Unable to parse {0} as an integer! check your profile", s);
                }
            }
        }

        /// <summary>
        /// A Queue for npc's we need to talk to
        /// </summary>
        private readonly Queue<NpcResult> _npcResults = new Queue<NpcResult>();

        protected override Composite CreateBehavior()
        {
            return _root ?? (_root = 
                new PrioritySelector(ret => _npcResults.Count != 0 ? _npcResults.Peek() : null,

                    new Decorator(ret => ret == null,
                        new Action(ret => _isDone = true)),

                    // Move to it if we are too far away.
                    new Decorator(ret => ret is NpcResult && ((NpcResult)ret).Location.Distance(StyxWoW.Me.Location) > 3,
                        new Action(ret => Navigator.MoveTo(((NpcResult)ret).Location))),

                    new Sequence(ret => ObjectManager.GetObjectsOfType<WoWUnit>().FirstOrDefault(unit => unit.Entry == ((NpcResult)ret).Entry),
                        new DecoratorContinue(ret => ret != null,
                            new Sequence(

                                new DecoratorContinue(ret => StyxWoW.Me.IsMoving,
                                    new Action(delegate
                                                   {
                                                        WoWMovement.MoveStop();
                                                       StyxWoW.SleepForLagDuration();
                                                   })
                                    ),

                                new DecoratorContinue(ret => !GossipFrame.Instance.IsVisible,
                                    new Action(ret => ((WoWUnit)ret).Interact())),

                                new WaitContinue(3, ret => !GossipFrame.Instance.IsVisible, 
                                    new Sequence(
                                        new Action(delegate
                                                       {
                                                           Lua.DoString("GossipTitleButton1:Click()");
                                                           Thread.Sleep(500);

                                                           if (GossipFrame.Instance.IsVisible)
                                                               return RunStatus.Running;

                                                           _npcResults.Dequeue();
                                                           return RunStatus.Success;
                                                       })
                                        ))
    
                            )))
                    ));
        }

        private bool _isDone;
        public override bool IsDone
        {
            get { return _isDone; }
        }

        #endregion
    }
}
