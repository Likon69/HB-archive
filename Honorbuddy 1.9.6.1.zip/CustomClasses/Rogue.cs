

#pragma warning disable
namespace Rogue
{
    using System;
    using System.Collections.Generic;
    using System.Diagnostics;
    using System.Linq;
    using System.Threading;
    using Styx;
    using Styx.Combat.CombatRoutine;
    using Styx.Helpers;
    using Styx.Logic;
    using Styx.Logic.Combat;
    using Styx.Logic.Pathing;
    using Styx.WoWInternals;
    using Styx.WoWInternals.WoWObjects;
    using Styx.WoWInternals.World;

    public class Rogue : CombatRoutine
    {
        public override WoWClass Class { get { return WoWClass.Rogue; } }

        public override string Name { get { return "Hawker's Rogue 2.1"; } }

        private static WoWUnit MyTarget
        {
            get { return ObjectManager.Me.CurrentTarget; }
        }

        private static bool GotTarget
        {
            get { return ObjectManager.Me.CurrentTarget != null; }
        }

        private static void Player_OnMobKilled(BotEvents.Player.MobKilledEventArgs args)
        {
            StyxWoW.Me.ClearTarget();

            if (StyxWoW.Me.IsAutoAttacking)
            {
                StyxWoW.Me.ToggleAttack();
            }
        }

        #region helper functions

        private static readonly Stopwatch PotionTimer = new Stopwatch();

        private bool UseHealthPotion()
        {
            if (!PotionTimer.IsRunning || PotionTimer.ElapsedMilliseconds > (100 + (1000 * 60)))
            {
                Healing.UseHealthPotion();
                PotionTimer.Reset();
                PotionTimer.Start();
            }
            return false;
        }

        private void Slog(string msg)
        {
            if (msg == _logspam)
            {
                return;
            }

            Logging.Write(msg);
            _logspam = msg;
        }

        private void Slog(string msg, params object[] args)
        {
            if (msg != _logspam)
            {
                try
                {
                    Logging.Write(msg, args);
                    _logspam = msg;
                }
                catch (Exception ex)
                {
                    Logging.WriteDebug("Error in Log: ");
                    Logging.WriteDebug(ex.Source);
                }
            }
        }

        private bool SafeCast(int spellId)
        {
            if (SpellManagerEx.HasSpell(spellId) && !StyxWoW.Me.IsCasting)
            {
                while (StyxWoW.GlobalCooldown)
                {
                    Thread.Sleep(100);
                }

                SpellManagerEx.Cast(spellId);
                return true;
            }

            return false;
        }

        private bool SafeCast(string spellName)
        {
            if (Me.IsCasting || !SpellManagerEx.HasSpell(spellName) || SpellManagerEx.Spells[spellName].Cooldown)
            {
                return false;
            }

            if (SpellManagerEx.HasSpell(spellName) && !StyxWoW.Me.IsCasting)
            {
                if (SpellManagerEx.Spells[spellName].CastTime > 1)
                {
                    WoWMovement.MoveStop();
                    WoWMovement.Face();
                }

                try
                {
                    if (GotTarget && MyTarget.Attackable)
                    {
                        WoWMovement.Face();
                    }
                }
                catch
                {
                    Logging.WriteDebug("No need to face target.");
                }

                while (StyxWoW.GlobalCooldown)
                {
                    Thread.Sleep(100);
                }

                SpellManagerEx.Cast(spellName);

                return true;
            }

            Logging.WriteDebug("{0} can't cast {1}.", Name, spellName);

            return false;
        }

        private static void SafeMove(WoWMovement.MovementDirection direction, int duration)
        {
            DateTime start = DateTime.Now;

            if (direction == WoWMovement.MovementDirection.StrafeMovement)
            {
                // Backwards means we want to strafe... check that first.
                // Left first
                if (CanStrafeSafely(true, 15f))
                {
                    direction = WoWMovement.MovementDirection.StrafeLeft;
                }
                else if (CanStrafeSafely(false, 15f))
                {
                    direction = WoWMovement.MovementDirection.StrafeRight;
                }
                else
                {
                    direction = WoWMovement.MovementDirection.Backwards;
                }
            }

            WoWMovement.Move(direction);

            while (ObjectManager.IsInGame && ObjectManager.Me.HealthPercent > 1)
            {
                Thread.Sleep(335);

                if (DateTime.Now.Subtract(start).Milliseconds < 300 ||
                    DateTime.Now.Subtract(start).Milliseconds >= duration)
                {
                    break;
                }
            }

            WoWMovement.MoveStop(direction);
        }

        public static bool CanStrafeSafely(bool left, float distance)
        {
            // Do this in degrees, since I'm lazy for right now.
            float myFacing = StyxWoW.Me.RotationDegrees;
            float direction = left ? myFacing - 90f : myFacing + 90f;

            if (direction < 0)
            {
                direction += 360f;
            }
            else if (direction > 360)
            {
                direction -= 360f;
            }

            direction = WoWMathHelper.DegreesToRadians(direction);
            WoWPoint myLoc = StyxWoW.Me.Location;
            WoWPoint endPoint = WoWPoint.RayCast(myLoc, direction, distance);

            // First, check for terrain collisions.
            if (GameWorld.IsInLineOfSight(endPoint, myLoc))
            {
                // We can strafe on the terrain, so now we check if we will run into aggro over there
                return AggroWithin(endPoint, distance, false) == 0;
            }

            // Can't safely strafe, so return false.
            return false;
        }

        public static int AggroWithin(WoWPoint obj, float range, bool targetingMe)
        {
            if (targetingMe)
            {
                return (from o in ObjectManager.ObjectList
                        where o is WoWUnit && o.Location.Distance(obj) <= range
                        let u = o.ToUnit()
                        where u.Attackable && u.Aggro && !u.Dead && u.CurrentTarget == StyxWoW.Me
                        select o).Count();
            }
            return (from o in ObjectManager.ObjectList
                    where o is WoWUnit && o.Location.Distance(obj) <= range
                    let u = o.ToUnit()
                    where u.Attackable && u.Aggro && !u.Dead
                    select o).Count();
        }

        #endregion

        #region Global Variables

        private static readonly List<ulong> RunnerList = new List<ulong>();
        bool IsInGame = ObjectManager.IsInGame;
        private readonly LocalPlayer Me = ObjectManager.Me;
        private string _logspam;
        WoWPoint pointNow = new WoWPoint();
        private const uint KillComboCount = 4;
        private uint deathCount = 0;


        private double targetDistance
        {
            get
            {
                return GotTarget ? Me.CurrentTarget.Distance : uint.MaxValue - 1;

            }
        }

        private WoWPoint behindTarget
        {
            get
            {
                if (GotTarget)
                {
                    return WoWMathHelper.CalculatePointBehind(Me.CurrentTarget.Location, Me.CurrentTarget.Rotation, 4);
                }
                else
                {
                    WoWPoint noSpot = new WoWPoint();
                    return noSpot;
                }
            }
        }

        private WoWPoint targetLocation
        {
            get
            {
                if (GotTarget)
                {
                    return Me.CurrentTarget.Location;
                }
                else
                {
                    WoWPoint noSpot = new WoWPoint();
                    return noSpot;
                }
            }
        }

        private ulong targettingGuid
        {
            get
            {
                //    try
                //    {
                if (!Equals(null, Targeting.Instance.TargetList) &&
                    Targeting.Instance.TargetList.Count > 0)
                {
                    return Targeting.Instance.FirstUnit.Guid;
                }
                else
                {
                    return 0;
                }
            }
        }

        private static ulong lastGuid;
        private static Stopwatch fightTimer = new Stopwatch();

        private static ulong pullGuid;
        private static Stopwatch pullTimer = new Stopwatch();
        #endregion

        #region Rest

        public override bool NeedRest
        {
            get
            {
                if (NeedPoisons())
                {
                    return true;
                }

                if (Battlegrounds.IsInsideBattleground)
                {
                    return false;
                }

                if (ObjectManager.Me.Auras.ContainsKey("Resurrection Sickness"))
                {
                    return true;
                }

                return Me.GetPowerPercent(WoWPowerType.Health) <= 55;
            }
        }

        public override void Rest()
        {
            if (NeedPoisons())
            {
                ApplyPoisons();
                Thread.Sleep(3000);
            }
            Styx.Logic.Common.Rest.Feed();

        }

        #endregion

        #region Pull

        private WoWUnit FindPlayers()
        {
            var playerList = ObjectManager.GetObjectsOfType<WoWUnit>();

            foreach (WoWUnit players in playerList)
            {

                if (players.IsPlayer)
                {
                    Slog("Got Players! Run for the hills!");
                    return players;
                }
            }

            return null;
        }


        bool IsFacingAway
        {
            get
            {
                bool face = false;
                double bearing = Me.CurrentTarget.Rotation;
                //double Angle = bearing * 180 / Math.PI; 
                if (bearing > Math.PI / 2 || bearing < -Math.PI / 2)

                    face = true;
                return face;
            }
        }

        //degrees = radians * 180 / Math.PI
        public override void Pull()
        {
            try
            {
                if (Blacklist.Contains(Me.CurrentTarget.Guid))
                    Slog("Pull Blacklisted");

                if (Battlegrounds.IsInsideBattleground &&
                    GotTarget &&
                    Me.CurrentTarget.Mounted)
                {
                    Styx.Logic.Blacklist.Add(Me.CurrentTarget.Guid, System.TimeSpan.FromSeconds(30));
                    Me.ClearTarget();
                    return;
                }

                if (GotTarget && Me.CurrentTarget.Guid != pullGuid)
                {
                    pullTimer.Reset();
                    pullTimer.Start();
                    pullGuid = Me.CurrentTarget.Guid;

                    if (Me.CurrentTarget.IsPlayer)
                    {
                        Slog("Killing " + Me.CurrentTarget.Level.ToString() + " " + Me.CurrentTarget.Race.ToString() + " who is " + System.Math.Round(Me.CurrentTarget.Distance).ToString() + " yards away.");
                    }
                    else
                    {

                        Slog("Killing " + Me.CurrentTarget.Name + " is " + System.Math.Round(Me.CurrentTarget.Distance).ToString() + " yards away.");
                    }

                    if (RunnerList.Contains(MyTarget.Entry))
                    {
                        Logging.Write("{0} is likely to try to run away.", MyTarget.Name);
                    }
                }

                if (!Me.CurrentTarget.IsPlayer && pullTimer.ElapsedMilliseconds > 30 * 1000)
                {
                    Slog(" This " + Me.CurrentTarget.Name + " is a bugged mob.  Blacklisting for 1 hour.");

                    Blacklist.Add(Me.CurrentTarget.Guid, TimeSpan.FromHours(1.00));

                    Me.ClearTarget();
                    pullGuid = 0;
                }

                if (!Me.Buffs.ContainsKey("Stealth"))
                {
                    SafeCast("Stealth");
                }

                if (!Me.Combat && targetDistance > 5 && targetDistance < Styx.Logic.Targeting.PullDistance + 10)
                {
                    int a = 0;
                    while (a < 50 && ObjectManager.Me.IsAlive && GotTarget && ObjectManager.Me.CurrentTarget.Distance > 5)
                    {
                        if (ObjectManager.Me.Combat)
                        {
                            Logging.Write("Combat has started.  Abandon pull.");
                            break;
                        }
                        WoWMovement.Face();
                        Navigator.MoveTo(WoWMovement.CalculatePointFrom(ObjectManager.Me.CurrentTarget.Location, 2f));
                        Thread.Sleep(250);
                        ++a;
                    }
                }

                if (GotTarget && targetDistance <= 5)
                {
                    WoWMovement.MoveStop();
                    WoWMovement.Face();

                    if (MyTarget.CreatureType == WoWCreatureType.Humanoid)
                    {
                        SafeCast("Pick Pocket");
                    }

                    CheapShot();
                    Navigator.MoveTo(attackPoint);

                    if (!Me.IsAutoAttacking)
                    {
                        Lua.DoString("StartAttack()");
                    }

                    if (Me.ComboPoints > 1)
                    {
                        SliceAndDice();
                    }
                }
            }
            finally
            {
                Slog("Pull done.");
            }

        }

        #endregion



        #region Pull Buffs

        public override bool NeedPullBuffs { get { return false; } }

        public override void PullBuff()
        {
            //Slog("Got Here");
            //Stealth();
        }

        #endregion

        #region Pre Combat Buffs

        public override bool NeedPreCombatBuffs { get { return false; } }

        public override void PreCombatBuff()
        {
            //Slog("Got Here");
            //Stealth();
            //if (!Me.Buffs.ContainsKey("Stealth"))
            //{
            //SafeCast("Stealth", false);
            //}
        }

        #endregion

        #region Combat Buffs

        public override bool NeedCombatBuffs { get { return false; } }

        public override void CombatBuff() { }

        #endregion

        #region Heal

        public override bool NeedHeal { get { return false; } }// Me.GetPowerPercent(WoWPowerType.Health) <= 30; } }

        public override void Heal()
        {
            Gouge();
        }

        #endregion

        #region Falling

        public void HandleFalling() { }

        #endregion

        #region Combat

        public override void Combat()
        {
            if (Blacklist.Contains(Me.CurrentTarget.Guid))
                Slog("Pull Blacklisted");

            if (GotTarget && Me.CurrentTarget.Dead)
            {
                Me.ClearTarget();
                return;
            }

            if (Targeting.Instance.FirstUnit != null && Targeting.Instance.FirstUnit.CurrentTargetGuid == Me.Guid && (!GotTarget || !MyTarget.Combat))
            {
                Targeting.Instance.FirstUnit.Target();
                Slog("Switching to " + MyTarget.Name);
                Thread.Sleep(200);
            }

            if (GotTarget && (Me.CurrentTarget.Guid != lastGuid || InfoPanel.Deaths > deathCount))
            {
                if (InfoPanel.Deaths > deathCount)
                {
                    deathCount = InfoPanel.Deaths;
                }

                if (Me.CurrentTarget.IsPlayer)
                {
                    Slog("Killing level " + Me.CurrentTarget.Level.ToString() + " " + Me.CurrentTarget.Race.ToString() + " " + Me.CurrentTarget.Class.ToString() + " at range of " + System.Math.Round(Me.CurrentTarget.Distance).ToString() + " yards.");
                }
                else
                {
                    Slog("Killing " + Me.CurrentTarget.Name + " at range of " + System.Math.Round(Me.CurrentTarget.Distance).ToString() + " yards.");
                }

                if (RunnerList.Contains(MyTarget.Entry))
                {
                    Logging.Write("{0} is likely to try to run away.", MyTarget.Name);
                }

                fightTimer.Reset();
                fightTimer.Start();
                lastGuid = Me.CurrentTarget.Guid;
            }

            if (combatChecks)
            {
                Berserking();
                Bloodrage();

                if (Me.CurrentTarget.IsCasting)
                {
                    Kick();
                    ArcaneTorrent();
                }

                Riposte();

                if (SpellManagerEx.HasSpell("Eviscerate") && (Me.ComboPoints >= KillComboCount || (MyTarget.HealthPercent < 30 && Me.ComboPoints > 2)))
                {
                    Eviscerate();
                }
                else
                {
                    SinisterStrike();
                }


                uint targetEntry = MyTarget.Entry;

                if (MyTarget.Fleeing && !RunnerList.Contains(targetEntry))
                {
                    Logging.Write("Adding {0} to the list of running mobs.", MyTarget.Name);
                    RunnerList.Add(targetEntry);
                }

                if (SpellManagerEx.Spells.ContainsKey("Sprint") && !SpellManagerEx.Spells["Sprint"].Cooldown)
                {
                    if ((RunnerList.Contains(targetEntry) && MyTarget.HealthPercent < 45) || MyTarget.Fleeing)
                    {
                        Slog("Use Sprint for chasing {0}.", MyTarget.Name);
                        Sprint();
                    }
                }
            }
            else
            {
                return;
            }

            if (combatChecks && (Me.HealthPercent < 40 && (Me.CurrentTarget.HealthPercent > Me.CurrentTarget.HealthPercent) || AddsList.Count > 2))
            {
                if (SpellManagerEx.Spells.ContainsKey("Lifeblood") && !SpellManagerEx.Spells["Lifeblood"].Cooldown)
                {
                    SafeCast("Lifeblood");
                }
                else
                {
                    UseHealthPotion();
                }
            }

            if (combatChecks && (Me.HealthPercent < 40 && (Me.CurrentTarget.HealthPercent > Me.CurrentTarget.HealthPercent) || AddsList.Count > 1))
            {
                if (SpellManagerEx.Spells.ContainsKey("Lifeblood") && !SpellManagerEx.Spells["Lifeblood"].Cooldown)
                {
                    SafeCast("Lifeblood");
                }
                else
                {
                    UseHealthPotion();
                }
            }

            if (GotTarget && !Me.CurrentTarget.IsPlayer && fightTimer.ElapsedMilliseconds > 40 * 1000 && Me.CurrentTarget.HealthPercent < 95)
            {
                Slog(" This " + Me.CurrentTarget.Name + " is a bugged mob.  Combat blacklisting for 1 hour.");

                Blacklist.Add(Me.CurrentTarget.Guid, TimeSpan.FromHours(1.00));

                SafeMove(WoWMovement.MovementDirection.Backwards, 5000);
                Me.ClearTarget();
                lastGuid = 0;

            }

        }

        #endregion

        #region Spells

        void SinisterStrike()
        {
            if (GotTarget && targetDistance <= 5 && SafeCast("Sinister Strike"))
            {
                Slog("Sinister Strike.");
            }
        }

        bool Throw()
        {
            if (GotTarget && !Me.Combat)
            {
                if (Me.CurrentTarget.Distance >= 6 && Me.CurrentTarget.Distance <= 28)
                {
                    if (SafeCast("Throw")) //Found Throw
                    {
                        Slog("Throw.");
                        return true;
                    }
                }
            }
            return false;

        }

        //Eviscerate (Req Level 1)

        void Eviscerate()
        {
            if (GotTarget && Me.ComboPoints > 0 && Me.CurrentEnergy >= SpellManager.KnownSpells["Eviscerate"].PowerCost && SafeCast("Eviscerate"))
            {
                Slog("Eviscerate.");
            }
        }

        /// Stealth (Req Level 2)

        void Stealth()
        {
            if (!Me.Combat) //Cant stealth in combat!
            {
                if (!Me.Buffs.ContainsKey("Stealth") && SafeCast("Stealth"))
                {
                    Slog("Stealth.");
                }
            }
        }

        // Evasion
        void Evasion()
        {
            if (GotTarget && targetDistance <= 5 && SafeCast("Evasion"))
            {
                Slog("Evasion.");
            }
        }

        // Sprint
        void Sprint()
        {
            if (SafeCast("Sprint"))
            {
                Slog("Sprint.");
            }
        }

        // Backstab
        void Backstab()
        {
            if (GotTarget && targetDistance <= 5 && SafeCast("Backstab"))
            {
                Slog("Try to Backstab.");
            }
        }

        // Gouge
        void Gouge()
        {
            if (GotTarget && targetDistance <= 5 && SafeCast("Gouge"))
            {
                Slog("Gouge.");
            }
        }

        // Pick Pocket
        void PickPocket()
        {
            if (MyTarget.CreatureType == WoWCreatureType.Demon || MyTarget.CreatureType == WoWCreatureType.Dragon ||
                MyTarget.CreatureType == WoWCreatureType.Giant || MyTarget.CreatureType == WoWCreatureType.Humanoid ||
                MyTarget.CreatureType == WoWCreatureType.Undead)
            {
                SafeCast("Pick Pocket");
            }
        }

        // Cheap Shot or Backstab?
        void CheapShot()
        {
            if (GotTarget && targetDistance <= 5)
            {
                if (Me.CurrentTarget.IsPlayer && SpellManagerEx.Spells.ContainsKey("Garrote"))
                {
                    WoWSpell Garrote = SpellManagerEx.Spells["Garrote"];
                    var isUsable = Lua.LuaGetReturnValue("return IsUsableSpell('Garrote')", "hax.lua");
                    if (isUsable != null)
                    {
                        if (isUsable[0] == "1")
                        {
                            SafeCast("Garrote");
                            Slog("Garrote");
                        }
                    }
                }

                if (SafeCast("Cheap Shot"))
                {
                    Slog("Cheap Shot.");
                }
            }
        }

        // Kick
        void Kick()
        {
            if (GotTarget && targetDistance <= 5 && SafeCast("Kick"))
            {
                Slog("Kick.");
            }
        }

        // Garrote
        void Garrote()
        {
            if (GotTarget && targetDistance <= 5 && SafeCast("Garrote"))
            {
                Slog("Try to Garrote.");
            }
        }

        // Ambush
        void Ambush()
        {
            if (GotTarget && targetDistance <= 5 && SafeCast("Ambush"))
            {
                Slog("Try to Ambush.");
            }
            else
            {
                Backstab();
            }
        }

        void SliceAndDice()
        {
            if (SpellManagerEx.Spells.ContainsKey("Slice and Dice") && !Me.Buffs.ContainsKey("Slice and Dice") && GotTarget && targetDistance <= 5 &&
                MyTarget.HealthPercent > 50 && Me.ComboPoints > 1 && SafeCast("Slice and Dice"))
            {
                Slog("Slice and Dice.");
            }
        }

        /// <summary>
        /// Check's if Riposte is usable and if it is it casts it
        /// </summary>
        private void Riposte()
        {
            if (GotTarget && MyTarget.Distance > 5)
            {
                return;
            }

            if (SpellManagerEx.HasSpell("Riposte"))
            {
                var isUsable = Lua.LuaGetReturnValue("return IsUsableSpell('Riposte')", "hax.lua");

                if (isUsable != null)
                {
                    if (isUsable[0] == "1")
                    {
                        SafeCast("Riposte");
                        Logging.Write("Riposte.");
                    }
                }
            }
        }

        void BladeFlurry()
        {
            if (GotTarget && targetDistance <= 5 && SafeCast("Blade Flurry"))
            {
                Slog("Blade Flurry.");
            }
        }

        void AdrenalineRush()
        {
            if (GotTarget && targetDistance <= 5 && SafeCast("Adrenaline Rush"))
            {
                Slog("Adrenaline Rush.");
            }
        }

        void KillingSpree()
        {
            if (GotTarget && targetDistance <= 5 && SafeCast("Killing Spree"))
            {
                Slog("Killing Spree.");
            }
        }

        #endregion

        #region horde racials

        // Berserking
        void Berserking()
        {
            if (ObjectManager.Me.Race == WoWRace.Troll && !SpellManagerEx.Spells["Berserking"].Cooldown && SafeCast("Berserking"))
            {
                Logging.Write("Berserking.");
            }
        }

        // Bloodrage
        void Bloodrage()
        {
            if (ObjectManager.Me.Race == WoWRace.Orc && SafeCast("Bloodrage"))
            {
                Logging.Write("Bloodrage.");
            }
        }

        // War Stomp
        void WarStomp()
        {
            if (SafeCast("War Stomp"))
            {
                Styx.Helpers.Logging.Write("War Stomp.");
            }
        }

        // Arcane Torrent
        void ArcaneTorrent()
        {
            if (SafeCast("Arcane Torrent"))
            {
                Styx.Helpers.Logging.Write("Arcane Torrent.");
            }
        }

        // Will of the Forsaken 
        void WillOfTheForsaken()
        {
            if (SafeCast("Will of the Forsaken"))
            {
                Styx.Helpers.Logging.Write("Will of the Forsaken.");
            }
        }
        #endregion

        #region alliance racials

        // Stoneform
        void Stoneform()
        {
            if (SafeCast("Stoneform"))
            {
                Styx.Helpers.Logging.Write("Stoneform.");
            }
        }

        // Gift of the Naaru
        void GiftOfTheNaaru()
        {
            if (SafeCast("Gift of the Naaru"))
            {
                Styx.Helpers.Logging.Write("Gift of the Naaru.");
            }
        }

        // Every Man for Himself
        void EveryManForHimself()
        {
            if (SafeCast("Every Man for Himself"))
            {
                Styx.Helpers.Logging.Write("Every Man for Himself.");
            }
        }

        // Shadowmeld
        void Shadowmeld()
        {
            if (SafeCast("Shadowmeld"))
            {
                Styx.Helpers.Logging.Write("Shadowmeld.");
            }
        }

        // Escape Artist
        void EscapeArtist()
        {
            if (SafeCast("Escape Artist"))
            {
                Styx.Helpers.Logging.Write("Escape Artist.");
            }
        }


        #endregion

        #region combat checks
        // lua for when both hand shave the same weapon
        private bool IsWeaponEnhanceNeeded(out bool needMainhand, out bool needOffhand)
        {
            needMainhand = false;
            needOffhand = false;

            if (!IsInGame)
                return false;


            List<string> weaponEnchants = Lua.LuaGetReturnValue("return GetWeaponEnchantInfo()", "hawker.lua");

            if (Equals(null, weaponEnchants))
                return false;

            needMainhand = weaponEnchants[0] == "" || weaponEnchants[0] == "nil";
            if (Me.Offhand.Entry > 0)
                needOffhand = weaponEnchants[3] == "" || weaponEnchants[3] == "nil";


            if (needMainhand)
                Logging.Write("Mainhand weapon {0} needs enchancement", Me.Mainhand.Name);

            if (needOffhand)
                Logging.Write("Offhand weapon {0} needs enhancement", Me.Offhand == null ? "(none)" : Me.Offhand.Name);

            return needMainhand || needOffhand;
        }


        // Instant Poison Entry Ids
        private readonly List<uint> PoisonEntryIds = new List<uint>()
        {
            6947, 6949, 6950, 8926, 8927, 8928,21927,43230,43231
        };

        private List<uint> CripplingPoisonEntryID = new List<uint>() { 3775 };

        private Stopwatch poisonTimer = new Stopwatch();

        // Instant Poison Enchant Ids
        private readonly List<uint> PoisonEnchantIds = new List<uint>()
        {
            323, 324, 325, 623, 624, 625, 2641, 3768, 3769
        };

        private const uint CripplingEnchantId = 22;

        private bool NeedPoisons()
        {
            // over level 20
            if (Me.Level < 20)
            {
                return false;
            }
            // timer to ease burden on cpu
            if (!poisonTimer.IsRunning)
            {
                poisonTimer.Reset();
                poisonTimer.Start();
            }

            if (poisonTimer.ElapsedMilliseconds < 20 * 1000)
            {
                return false;
            }

            // look at all items in inventory and check we have poisons to apply
            WoWItem instantPoison = HaveItemCheck(PoisonEntryIds);
            WoWItem cripplingPoison = HaveItemCheck(CripplingPoisonEntryID);

            if (Equals(null, instantPoison))
            {
                return false;
            }

            // look at weapons and see if they have poisons applied

            if (Me.Mainhand.Entry == Me.Offhand.Entry)
            {
                bool needPoisonMainhand, needPoisonOffhand;

                return IsWeaponEnhanceNeeded(out needPoisonMainhand, out needPoisonOffhand);
            }

            // if you don't have crippling poisopn, use Deadly Poison on both hands
            if (cripplingPoison == null && PoisonEnchantIds.Contains(Me.Mainhand.TemporaryEnchantment.Id) && PoisonEnchantIds.Contains(Me.Offhand.TemporaryEnchantment.Id))
            {
                return false;
            }

            if (cripplingPoison != null && PoisonEnchantIds.Contains(Me.Mainhand.TemporaryEnchantment.Id) && Me.Offhand.TemporaryEnchantment.Id == CripplingEnchantId)
            {
                return false;
            }

            return true;
        }

        private void ApplyPoisons()
        {
            poisonTimer.Reset();
            poisonTimer.Start();

            WoWItem instantPoison = HaveItemCheck(PoisonEntryIds);
            WoWItem cripplingPoison = HaveItemCheck(CripplingPoisonEntryID);

            if (!Equals(null, instantPoison))
            {
                if (Me.Mounted)
                    Mount.Dismount();
            }

            WoWMovement.MoveStop();

            bool needPoisonMainhand, needPoisonOffhand;

            if (IsWeaponEnhanceNeeded(out needPoisonMainhand, out needPoisonOffhand))
            {
                if (needPoisonOffhand)
                {
                    Slog("Applying poison to offhand weapon: " + Me.Offhand.Name);

                    if (cripplingPoison != null)
                    {
                        Lua.DoString("UseItemByName(\"" + cripplingPoison.Entry + "\")");
                    }
                    else
                    {
                        Lua.DoString("UseItemByName(\"" + instantPoison.Entry + "\")");
                    }
                    Thread.Sleep(100);
                    Lua.DoString("UseInventoryItem(17)");
                    Thread.Sleep(3100);
                }

                if (needPoisonMainhand)
                {
                    Slog("Applying poison to main hand weapon: " + Me.Mainhand.Name);
                    Lua.DoString("UseItemByName(\"" + instantPoison.Entry + "\")");
                    Thread.Sleep(100);
                    Lua.DoString("UseInventoryItem(16)");
                    Thread.Sleep(3100);
                }
            }

        }

        private WoWItem HaveItemCheck(List<uint> listId)
        {
            foreach (WoWItem item in ObjectManager.GetObjectsOfType<WoWItem>(false))
            {
                if (listId.Contains(item.Entry))
                {
                    return item;
                }
            }
            return null;
        }

        private bool combatChecks
        {
            get
            {
                if (!GotTarget)
                {
                    Logging.Write("No target.");
                    return false;
                }

                if (ObjectManager.Me.Dead)
                {
                    Logging.Write("I died.");
                    return false;
                }

                if (GotTarget && !ObjectManager.Me.IsAutoAttacking)
                {
                    Lua.DoString("StartAttack()");
                }

                if (ObjectManager.Me.CurrentTarget.Distance > 50)
                {
                    if (ObjectManager.Me.CurrentTarget.IsPlayer)
                    {
                        Logging.Write("Out of range: Level " + ObjectManager.Me.CurrentTarget.Level.ToString() + " " + ObjectManager.Me.CurrentTarget.Race.ToString() + " " + System.Math.Round(ObjectManager.Me.CurrentTarget.Distance).ToString() + " yards away.");
                    }
                    else
                    {

                        Logging.Write("Out of range: Level " + ObjectManager.Me.CurrentTarget.Name + " is " + System.Math.Round(ObjectManager.Me.CurrentTarget.Distance).ToString() + " yards away.");
                    }

                    Me.ClearTarget();
                    return false;
                }

                double meleeRange = 5;

                if (ObjectManager.Me.CurrentTarget.Distance > meleeRange)
                {
                    int a = 0;
                    while (a < 50 && ObjectManager.Me.IsAlive && GotTarget && ObjectManager.Me.CurrentTarget.Distance > meleeRange)
                    {
                        WoWMovement.Face();
                        Navigator.MoveTo(WoWMovement.CalculatePointFrom(ObjectManager.Me.CurrentTarget.Location, 2.5f));
                        Thread.Sleep(250);
                        ++a;
                    }
                }

                WoWMovement.Face();

                return true;
            }
        }

        private static Stopwatch _addsWarning = new Stopwatch();
        private List<WoWUnit> AddsList
        {
            get
            {
                List<WoWUnit> mobList = ObjectManager.GetObjectsOfType<WoWUnit>(false);
                var enemyMobList = new List<WoWUnit>();

                foreach (WoWUnit thing in mobList)
                {
                    try
                    {
                        if ((thing.Guid != Me.Guid) && (thing.IsTargetingMeOrPet || thing.Fleeing))
                        {
                            enemyMobList.Add(thing);
                            if (!_addsWarning.IsRunning || _addsWarning.ElapsedMilliseconds > 15)
                            {
                                // Slog("Adding {0} {1} to attacker list.", thing.Name, thing.Guid);
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        Logging.WriteException(ex);
                        Slog("Add error.");
                    }
                }

                if (enemyMobList.Count > 1)
                {
                    if (!_addsWarning.IsRunning || _addsWarning.ElapsedMilliseconds > 15)
                    {
                        Slog("Warning: there are " + enemyMobList.Count + " attackers.");
                        _addsWarning.Reset();
                        _addsWarning.Start();
                    }
                }
                return enemyMobList;
            }
        }
        #endregion

        #region movement logic

        WoWPoint attackPointBuffer;
        WoWPoint attackPoint
        {
            get
            {
                if (GotTarget)
                {
                    attackPointBuffer = WoWMovement.CalculatePointFrom(Me.CurrentTarget.Location, 1.0f);
                    return attackPointBuffer;
                }
                else
                {
                    WoWPoint noSpot = new WoWPoint();
                    return noSpot;
                }
            }
        }

        private static bool UseNavigator;
        private WoWUnit _lastTarget;
        private WoWPoint _dest = WoWPoint.Zero;
        private WoWPoint GetTraceLinePos()
        {
            return new WoWPoint(Me.X, Me.Y, Me.Z + 2.132f);
        }

        private static Stopwatch movementTimer = new Stopwatch();

        #endregion
    }
}
#pragma warning restore