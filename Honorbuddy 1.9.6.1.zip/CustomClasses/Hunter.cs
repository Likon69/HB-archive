#pragma warning disable
namespace Hunttard
{
    using Styx.Combat.CombatRoutine;
    using Styx.Helpers;
    using Styx.Logic.Combat;
    using Styx.WoWInternals;
    using Styx.WoWInternals.WoWObjects;
    using Styx;
    using System;
    using System.Diagnostics;
    using Styx.Logic;
    using System.Collections.Generic;
    using Styx.Logic.Pathing;
    using System.Threading;

    class Hunter : CombatRoutine
    {
        #region variables
        public override WoWClass Class { get { return WoWClass.Hunter; } }
        public override string Name { get { return "Hawker's Beast Master 2.2"; } }

        private string _logspam;
        private readonly LocalPlayer Me = ObjectManager.Me;

        private static Stopwatch feedPetTimer = new Stopwatch();
        private static Stopwatch aspectTimer = new Stopwatch();
        private static Stopwatch petPresenceTimer = new Stopwatch();
        private static Stopwatch fightTimer = new Stopwatch();
        private static ulong lastGuid = 0;
        private bool noDrink;
        private bool noFood;
        private double restAspectOfTheViper = 90;
        private double restHealth = 55;

        private bool enemyClose = false;

        WoWPoint pointNow = new WoWPoint();

        List<WoWUnit> addsList = new List<WoWUnit>();

        private WoWUnit myTarget { get; set; }

        private double targetDistance
        {
            get
            {
                return Me.GotTarget ? Me.CurrentTarget.Distance : uint.MaxValue - 1;
            }
        }

        private static Stopwatch pullTimer = new Stopwatch();
        private static Stopwatch moveTimer = new Stopwatch();

        /// <summary>
        /// Item ID's of all ammos taken on 9/23/2009 from http://www.wowhead.com/?items=6 
        /// Total of 50 ID's were found.
        /// THANKS IGGY
        /// </summary>
        bool outOfAmmo
        {
            get
            {
                List<uint> _ammoEntryId = new List<uint>()
                {
                    30319,34581,34582,32760,32761,31737,31735,23773,33803,12654,10579,32883,30612,30611,32882,41164,
                    13377,11630,41165,31949,3465,3464,23772,10512,19316,19317,10513,9399,24417,18042,15997,11284,
                    28056,8068,8067,8069,4960,41584,2519,28060,28061,11285,2516,3030,2512,2515,5568,3033,41586,28053,52020,52021
                };

                List<WoWItem> itemList = ObjectManager.GetObjectsOfType<WoWItem>(false);

                foreach (WoWItem item in itemList)
                {
                    if (_ammoEntryId.Contains(item.Entry))
                        return false;
                }
                return true;
            }
        }

        #endregion

        #region rest and buffs
        public override bool NeedRest
        {
            get
            {
                bool restNeeded = false;

                if (!feedPetTimer.IsRunning)
                {
                    feedPetTimer.Reset();
                    feedPetTimer.Start();
                }

                if (!aspectTimer.IsRunning)
                {
                    aspectTimer.Reset();
                    aspectTimer.Start();
                }

                if (!petPresenceTimer.IsRunning)
                {
                    petPresenceTimer.Reset();
                    petPresenceTimer.Start();
                }

                if (!Me.Mounted)
                {
                    if (petPresenceTimer.ElapsedMilliseconds > 3000 && !Battlegrounds.IsInsideBattleground && SpellManager.KnownSpells.ContainsKey("Call Pet") && !Me.GotAlivePet)
                    {
                        slog("No pet.");
                        restNeeded = true;
                    }
                }

                // 3 second timer on aspect changes for the mobs that wander in and out of Pull distance
                if (aspectTimer.ElapsedMilliseconds > 3000 &&
                    Me.ManaPercent < restAspectOfTheViper &&
                    SpellManager.KnownSpells.ContainsKey("Aspect of the Viper") &&
                    !Me.Buffs.ContainsKey("Aspect of the Viper"))
                {
                    slog("Need Aspect of the Viper.");
                    restNeeded = true;
                }

                if ((feedPetTimer.IsRunning && feedPetTimer.ElapsedMilliseconds > 60 * 1000) && SpellManager.KnownSpells.ContainsKey("Feed Pet") &&
                    Me.GotAlivePet && Me.Pet.CurrentHappiness > 0 && Me.Pet.CurrentHappiness < 65 && !Me.Pet.Buffs.ContainsKey("Feed Pet"))
                {
                    slog("Pet happiness: " + Me.Pet.CurrentHappiness.ToString());
                    restNeeded = true;
                }

                if (SpellManager.KnownSpells.ContainsKey("Mend Pet") &&
                    Me.GotAlivePet &&
                    Me.Pet.HealthPercent < 50 &&
                    !Me.Pet.Buffs.ContainsKey("Mend Pet"))
                {
                    slog("Heal the pet.");
                    restNeeded = true;
                }

                if (Battlegrounds.IsInsideBattleground)
                {
                    return false;
                }

                if (!noFood && Me.HealthPercent < restHealth)
                {
                    slog("Low health.");
                    restNeeded = true;
                }

                if (!noDrink && Me.ManaPercent < 45)
                {
                    slog("Low mana");
                    restNeeded = true;
                }
                return restNeeded;
            }
        }



        public override void Rest()
        {
            if (Me.ManaPercent < restAspectOfTheViper && SpellManager.KnownSpells.ContainsKey("Aspect of the Viper") && !Me.Buffs.ContainsKey("Aspect of the Viper"))
            {
                slog("Aspect of the Viper.");
                AspectOfTheViper();
            }

            if (!Me.Mounted && !Battlegrounds.IsInsideBattleground && SpellManager.KnownSpells.ContainsKey("Call Pet") && !Me.GotAlivePet)
            {
                CallPet();
                Thread.Sleep(500);
                if (!Me.GotAlivePet)
                {
                    slog("No pet appeared.");
                    FreezingTrap();
                    RevivePet();
                }
            }

            if (SpellManager.KnownSpells.ContainsKey("Call Pet") && Me.GotAlivePet && Me.Pet.CurrentHappiness < 65)
            {
                FeedPet();
            }

            if (SpellManager.KnownSpells.ContainsKey("Mend Pet") && Me.GotAlivePet && Me.Pet.HealthPercent < restHealth)
            {
                MendPet();
            }

            if (Me.HealthPercent < restHealth)
            {
                int foodCount = Convert.ToInt32(Lua.LuaGetReturnValue("return GetItemCount(\"" + LevelbotSettings.Instance.FoodName + "\")", "hawker.lua")[0]);

                if (foodCount < 1)
                {
                    noFood = true;
                    Logging.Write("Hunter Rest - no food.");
                }
                else
                {
                    noFood = false;
                }

                if (!noFood &&
                    Me.HealthPercent < restHealth)
                {
                    Styx.Logic.Common.Rest.Feed();
                }
            }

            if (Me.ManaPercent < 40)
            {
                int DrinkCount = Convert.ToInt32(Lua.LuaGetReturnValue("return GetItemCount(\"" + LevelbotSettings.Instance.DrinkName + "\")", "hawker.lua")[0]);

                if (DrinkCount < 1)
                {
                    noDrink = true;
                }
                else
                {
                    noDrink = false;
                }

                if (!noDrink && Me.ManaPercent < 40)
                {
                    Styx.Logic.Common.Rest.Feed();
                }
            }
        }
        public override bool NeedPreCombatBuffs { get { return false; } }
        public override void PreCombatBuff() { }
        public override bool NeedCombatBuffs { get { return false; } }
        public override void CombatBuff() { }
        public override bool NeedHeal { get { return false; } }
        public override void Heal() { }
        public override bool NeedPullBuffs { get { return false; } }
        public override void PullBuff() { }
        #endregion

        #region pull
        public override void Pull()
        {
            try
            {
                #region checks
                if (Battlegrounds.IsInsideBattleground)
                {
                    if (Me.GotTarget &&
                        Me.CurrentTarget.IsPet)
                    {
                        Blacklist.Add(Me.CurrentTarget, TimeSpan.FromDays(1));
                        Me.ClearTarget();
                    }

                    if (Me.GotTarget && Me.CurrentTarget.Mounted)
                    {
                        Blacklist.Add(Me.CurrentTarget, TimeSpan.FromMinutes(1));
                        Me.ClearTarget();
                    }
                }

                if (Me.CurrentTarget.Guid != lastGuid)
                {
                    fightTimer.Reset();
                    lastGuid = Me.CurrentTarget.Guid;
                    slog("Killing " + Me.CurrentTarget.Name + " at distance " + System.Math.Round(targetDistance).ToString() + ".");
                    pullTimer.Reset();
                    pullTimer.Start();

                }
                else
                {
                    if (pullTimer.ElapsedMilliseconds > 30 * 1000)
                    {
                        slog("Cannot pull " + Me.CurrentTarget.Name + " now.  Blacklist for 3 minutes.");
                        Styx.Logic.Blacklist.Add(Me.CurrentTarget.Guid, System.TimeSpan.FromMinutes(3));
                    }
                }

                #endregion
                double shotRange = SpellManager.KnownSpells["Auto Shot"].MaxRange - 1;

                if (Me.CurrentTarget.Distance > shotRange)
                {
                    Navigator.MoveTo(attackPoint);

                    int i = 0;
                    while (i < 8 && Me.Location.Distance(attackPoint) > 1)
                    {
                        if (ObjectManager.Me.Combat)
                        {
                            Logging.Write("Combat has started.  Abandon pull.");
                            break;
                        }

                        Thread.Sleep(250);
                        ++i;
                    }

                    return;
                }
                else
                {
                    if (ObjectManager.Me.IsMoving)
                    {
                        WoWMovement.MoveStop();
                    }

                    if (Me.GotTarget && Me.GotAlivePet)
                    {
                        if (!Me.Pet.IsAutoAttacking)
                        {
                            Lua.DoString("PetAttack()");
                        }

                        petPresenceTimer.Reset();
                        if (Me.CurrentTarget.Level - Me.Level == 1)
                        {
                            slog("Let " + Me.Pet.Name + " gain aggro.");
                            Thread.Sleep(1000);
                        }
                        else if (Me.CurrentTarget.Level - Me.Level > 1)
                        {
                            slog("Let " + Me.Pet.Name + " face this mob alone for a bit.");
                            Thread.Sleep(2000);
                        }
                    }

                    WoWMovement.Face();

                    SelectAspect();
                    HuntersMark();

                    if (SpellManager.KnownSpells.ContainsKey("Concussive Shot") && !SpellManager.KnownSpells["Concussive Shot"].Cooldown)
                    {
                        ConcussiveShot();
                    }
                    else
                    {
                        ArcaneShot();

                        if (!Me.Combat)
                        {
                            AutoShot();
                        }
                    }

                    if (!Me.CurrentTarget.IsTargetingMeOrPet && SpellManager.KnownSpells.ContainsKey("Steady Shot") && !SpellManager.KnownSpells["Steady Shot"].Cooldown)
                    {
                        SteadyShot();
                    }

                    if (!Me.CurrentTarget.IsTargetingMeOrPet && !SpellManager.KnownSpells.ContainsKey("Arcane Shot") && !SpellManager.KnownSpells["Arcane Shot"].Cooldown)
                    {
                        ArcaneShot();
                    }

                    if (!Me.CurrentTarget.IsTargetingMeOrPet)
                    {
                        AutoShot();

                        for (int a = 0; a <= 10; ++a)
                        {
                            if (Me.CurrentTarget.IsTargetingMeOrPet)
                                return;
                        }
                    }

                }
            }
            finally
            {

            }
        }
        #endregion

        #region combat
        #region noammo
        private void NoAmmoCombat()
        {
            if (Me.GotTarget && Me.CurrentTarget.Distance > 4)
            {
                Navigator.MoveTo(Me.CurrentTarget.Location);

                int a = 0;
                while (Me.GotTarget && Me.CurrentTarget.Distance > 4 && a < 20)
                {
                    Thread.Sleep(250);
                    Navigator.MoveTo(Me.CurrentTarget.Location);
                    ++a;
                }
            }
            else
            {
                WoWMovement.Face();

                if (SpellManager.KnownSpells.ContainsKey("Immolation Trap") && !SpellManager.KnownSpells["Immolation Trap"].Cooldown)
                {
                    ImmolationTrap();
                }
                else if (SpellManager.KnownSpells.ContainsKey("Raptor Strike") && !SpellManager.KnownSpells["Raptor Strike"].Cooldown)
                {
                    RaptorStrike();
                }
                else if (SpellManager.KnownSpells.ContainsKey("Mongoose Bite") && !SpellManager.KnownSpells["Mongoose Bite"].Cooldown)
                {
                    MongooseBite();
                }
            }
        }
        #endregion
        #region ranged/normal dps
        private void RangedCombat()
        {
            double shotRange = SpellManager.KnownSpells["Auto Shot"].MaxRange - 1;

            if (Me.CurrentTarget.Distance > shotRange)
            {
                Navigator.MoveTo(attackPoint);
                return;
            }


            if (ObjectManager.Me.IsMoving)
            {
                WoWMovement.MoveStop();
            }

            WoWMovement.Face();

            HuntersMark();

            if (Me.GotTarget &&
                SpellManager.KnownSpells.ContainsKey("Kill Shot") && !SpellManager.KnownSpells["Kill Shot"].Cooldown && Me.CurrentTarget.HealthPercent < 20)
            {
                KillShot();
            }

            AimedShot();

            if (Me.GotTarget && !Me.CurrentTarget.Buffs.ContainsKey("Serpent Sting") && (Me.CurrentTarget.Elite || Me.CurrentTarget.Level > Me.Level + 2))
                SerpentSting();

            if (Me.GotTarget && SpellManager.KnownSpells.ContainsKey("Steady Shot"))
            {
                ConcussiveShot();
                SteadyShot();
            }

            if (Me.GotTarget && SpellManager.KnownSpells.ContainsKey("Arcane Shot"))
            {
                ArcaneShot();
            }
        }
        #endregion
        #region melee on me
        private void UsePet()
        {
            try
            {
                if (SpellManager.KnownSpells.ContainsKey("Disengage") && !SpellManager.KnownSpells["Disengage"].Cooldown)
                {
                    WingClip();
                    Disengage();
                }
                else if (SpellManager.KnownSpells.ContainsKey("Intimidation") && !SpellManager.KnownSpells["Intimidation"].Cooldown)
                {
                    Intimidation();
                    SafeMove(WoWMovement.MovementDirection.StrafeLeft, 1500);

                    if (Me.CurrentTarget != null)
                        WoWMovement.Face();
                }
                else if (SpellManager.KnownSpells.ContainsKey("Frost Trap") && !SpellManager.KnownSpells["Frost Trap"].Cooldown)
                {
                    FrostTrap();
                    SafeMove(WoWMovement.MovementDirection.StrafeRight, 1500);

                    if (Me.CurrentTarget != null)
                        WoWMovement.Face();

                }
                else if (SpellManager.KnownSpells.ContainsKey("Wing Clip") && !SpellManager.KnownSpells["Wing Clip"].Cooldown)
                {
                    WingClip();
                    SafeMove(WoWMovement.MovementDirection.StrafeLeft, 1500);

                    if (Me.CurrentTarget != null)
                        WoWMovement.Face();

                }
                else if (SpellManager.KnownSpells.ContainsKey("Immolation Trap") && !SpellManager.KnownSpells["Immolation Trap"].Cooldown)
                {
                    ImmolationTrap();
                }
                else if (SpellManager.KnownSpells.ContainsKey("Feign Death") && !SpellManager.KnownSpells["Feign Death"].Cooldown &&
                    Me.GotAlivePet)
                {
                    FeignDeath();
                    Thread.Sleep(5 * 1000);
                    KeyboardManager.KeyUpDown(' ');
                }
                else if (SpellManager.KnownSpells.ContainsKey("Raptor Strike") && !SpellManager.KnownSpells["Raptor Strike"].Cooldown)
                {
                    RaptorStrike();
                }
                else if (SpellManager.KnownSpells.ContainsKey("Mongoose Bite") && !SpellManager.KnownSpells["Mongoose Bite"].Cooldown)
                {
                    MongooseBite();
                }
            }
            finally
            {
                if (ObjectManager.Me.IsMoving)
                {
                    WoWMovement.MoveStop();
                }
            }
        }
        #endregion
        #region pvp
        private void KillPlayer()
        {
            if (!Me.GotTarget)
                return;

            double shotRange = SpellManager.KnownSpells["Auto Shot"].MaxRange - 1;

            ImmolationTrap();
            Intimidation();

            if (Me.CurrentTarget.Distance > 7 && Me.CurrentTarget.Distance < shotRange)
            {
                BestialWrath();
                SerpentSting();
                ArcaneShot();
                SteadyShot();
            }
            else if (Me.CurrentTarget.Distance < 6)
            {
                if (SpellManager.KnownSpells.ContainsKey("Disengage") && !SpellManager.KnownSpells["Disengage"].Cooldown)
                {
                    SnakeTrap();
                    WingClip();
                    Disengage();
                    ConcussiveShot();
                    return;
                }
                else
                {
                    FrostTrap();
                    WingClip();
                    SafeMove(WoWMovement.MovementDirection.StrafeLeft, 500);
                    RaptorStrike();
                    MongooseBite();
                }
                BestialWrath();
            }
        }
        #endregion

        public override void Combat()
        {
            try
            {
                if (SpellManager.KnownSpells.ContainsKey("Call Pet") &&
                    !Me.GotAlivePet)
                {
                    CallPet();
                }

                if (Battlegrounds.IsInsideBattleground)
                {
                    if (Me.GotTarget &&
                        Me.CurrentTarget.IsPet)
                    {
                        Blacklist.Add(Me.CurrentTarget, TimeSpan.FromDays(1));
                        Me.ClearTarget();
                        return;
                    }
                }

                if (Me.GotTarget)
                {
                    WoWMovement.Face();

                    if (!Me.Combat)
                    {
                        AutoShot();
                    }

                    if (Me.GotAlivePet)
                    {
                        Lua.DoString("PetAttack()");
                    }
                }

                // bugged mobs 
                if (Me.GotTarget && (!fightTimer.IsRunning || Me.CurrentTarget.Guid != lastGuid))
                {
                    fightTimer.Reset();
                    fightTimer.Start();
                    lastGuid = Me.CurrentTarget.Guid;
                }

                if (Me.IsSwimming)
                {
                    KeyboardManager.KeyUpDown(' ');
                    KeyboardManager.KeyUpDown(' ');
                }


                if (!Me.GotTarget && Me.Pet.GotTarget && Me.PetInCombat)
                {
                    Me.Pet.CurrentTarget.Target();
                    Thread.Sleep(300);
                    AutoShot();
                    slog("Take pet's target.");
                    WoWMovement.Face();
                }

                addsList = getAdds();
                if (addsList.Count > 1)
                {
                    if (Me.GotTarget && Me.CurrentTarget.HealthPercent > 50)
                    {
                        MendPet();
                        RapidFire();
                        BestialWrath();
                    }

                    if (Me.HealthPercent < restHealth)
                    {
                        FreezingTrap();
                    }
                    else
                    {
                        ImmolationTrap();
                    }

                    KillCommand();
                }

                // autoattack + pet attack = very cheap level 80
                if (Me.GotTarget && Me.GotAlivePet)
                {
                    if (!Me.Pet.IsAutoAttacking)
                    {
                        Lua.DoString("PetAttack()");
                    }

                    if (Me.CurrentTarget.HealthPercent > 60)
                    {
                        KillCommand();
                    }

                    petPresenceTimer.Reset();
                }

                if (Me.GotTarget && Me.CurrentTarget.HealthPercent > Me.HealthPercent)
                {
                    BestialWrath();
                }

                if (Me.GotAlivePet && Me.Pet.HealthPercent < 50 && !Me.Pet.Buffs.ContainsKey("Mend Pet"))
                {
                    MendPet();
                }

                SelectAspect();

                if (Me.HealthPercent < 40)
                {
                    Healing.UseHealthPotion();
                }

                if (Me.ManaPercent < 40)
                {
                    Healing.UseManaPotion();
                }

                if (!Me.GotTarget)
                {
                    Me.ClearTarget();
                    return;
                }
                else if (!Me.CurrentTarget.InLineOfSight)
                {
                    slog("{0} is not in line of sight.  Close and use melee.", Me.CurrentTarget.Name);
                    NoAmmoCombat();
                }
                else if (outOfAmmo)
                {
                    slog("No ammo.");
                    NoAmmoCombat();
                }
                else if (Me.CurrentTarget != null && ObjectManager.Me.CurrentTarget.IsPlayer)
                {
                    KillPlayer();
                }
                else
                {
                    if (Me.CurrentTarget != null && Me.GotTarget && !Me.IsAutoAttacking)
                    {
                        Lua.DoString("StartAttack()");
                    }

                    #region ranged

                    if (Me.GotTarget && Me.CurrentTarget != null && Me.CurrentTarget.Distance > 7)
                    {
                        RangedCombat();
                    }

                    #endregion

                    else if (Me.GotTarget && Me.CurrentTarget.IsAlive && Me.CurrentTarget.Distance < 8)
                    {
                        if (Me.GotAlivePet && Me.CurrentTarget != null && Me.CurrentTarget.CurrentTargetGuid == Me.Guid)
                        // slow the target and get range
                        {
                            slog(Me.CurrentTarget.Name + " is attacking me.  Use pet and get range.");
                            UsePet();
                        }
                        // get range and let pet fight

                        else if (Me.CurrentTarget != null && Me.GotAlivePet)
                        {
                            slog(Me.CurrentTarget.Name + " is too close.");

                            SafeMove(WoWMovement.MovementDirection.StrafeLeft, 1500);

                            if (Me.CurrentTarget != null)
                                WoWMovement.Face();
                        }
                        else
                        {
                            NoAmmoCombat();
                        }
                    }
                }

                if (Me.CurrentTarget != null && !Me.CurrentTarget.IsPlayer &&
                    fightTimer.ElapsedMilliseconds > 40 * 1000 &&
                    Me.CurrentTarget.HealthPercent > 95)
                {
                    slog(" This " + Me.CurrentTarget.Name + " is a bugged mob.  Blacklisting for 1 hour.");

                    Blacklist.Add(Me.CurrentTarget.Guid, TimeSpan.FromHours(1.00));

                    SafeMove(WoWMovement.MovementDirection.Backwards, 5000);
                    Me.ClearTarget();
                    lastGuid = 0;
                }
            }
            finally
            {
                if (ObjectManager.Me.IsMoving)
                {
                    WoWMovement.MoveStop();
                }
            }

        }
        public void HandleFalling() { }
        #endregion

        #region hunter spells

        /// <summary>
        /// Automatically shoots the target until cancelled.  Ranged attacks fired by a Hunter all have 15% increased attack speed.
        /// </summary>
        private bool AutoShot()
        {
            if (Me.GotTarget && SpellManager.CastSpell("Auto Shot"))
            {
                slog("Auto Shot.");
                return true;
            }
            else
            {
                // slog("Can't use shoot now.");
                return false;
            }
        }

        /// <summary>
        /// A strong attack that increases melee damage
        /// </summary>        
        private bool RaptorStrike()
        {
            if (Me.GotTarget && SpellManager.CastSpell("Raptor Strike"))
            {
                WoWMovement.Face();
                slog("Raptor Strike.");
                return true;
            }
            else
            {
                // slog("Can't use Raptor Strike now.");
                return false;
            }
        }

        /// <summary>
        /// The hunter takes on the aspects of a monkey, increasing chance to dodge by 18%.  Only one Aspect can be active at a time.
        /// </summary>        
        private bool AspectofTheMonkey()
        {
            if (SpellManager.CastSpell("Aspect of the Monkey"))
            {
                slog("Aspect of the Monkey.");
                aspectTimer.Reset();
                aspectTimer.Start();
                return true;
            }
            else
            {
                // slog("Can't use Aspect of the Monkey now.");
                return false;
            }
        }

        /// <summary>
        /// Stings the target, causing Nature damage over 15 sec.  Only one Sting per Hunter can be active on any one target.
        /// </summary>        
        private bool SerpentSting()
        {
            if (Me.GotTarget && SpellManager.CastSpell("Serpent Sting"))
            {
                slog("Serpent Sting.");
                return true;
            }
            else
            {
                // slog("Can't use Serpent Sting now.");
                return false;
            }
        }

        /// <summary>
        /// An instant shot that causes Arcane damage.
        /// </summary>        
        private bool ArcaneShot()
        {
            if (Me.GotTarget && SpellManager.CastSpell("Arcane Shot"))
            {
                slog("Arcane Shot.");
                return true;
            }
            else
            {
                // slog("Can't use Arcane Shot now.");
                return false;
            }
        }

        /// <summary>
        /// Places the Hunter's Mark on the target, increasing the ranged attack power of all attackers against that target by 20.  In addition, the target of this ability can always be seen by the hunter whether it stealths or turns invisible.  The target also appears on the mini-map.  Lasts for 5 min.
        /// </summary>        
        private bool HuntersMark()
        {
            if (Me.GotTarget &&
                Me.CurrentTarget.Buffs.ContainsKey("Hunter's Mark"))
                return false;

            if (Me.GotTarget && SpellManager.CastSpell("Hunter's Mark"))
            {
                slog("Hunter's Mark.");
                return true;
            }
            else
            {
                // slog("Can't use Hunter's Mark now.");
                return false;
            }
        }

        /// <summary>
        /// Dazes the target, slowing movement speed by 50% for 4 sec.
        /// </summary>        
        private bool ConcussiveShot()
        {
            if (Me.GotTarget && Me.CurrentTarget.Buffs.ContainsKey("Concussive Shot"))
            {
                return true;
            }
            if (Me.GotTarget && SpellManager.CastSpell("Concussive Shot"))
            {
                WoWMovement.Face();
                slog("Concussive Shot.");
                return true;
            }
            else
            {
                // slog("Can't use Concussive Shot now.");
                return false;
            }
        }

        /// <summary>
        /// The hunter takes on the aspects of a hawk, increasing ranged attack power by 20.  Only one Aspect can be active at a time.
        /// </summary>
        private bool AspectOfTheHawk()
        {
            if (SpellManager.CastSpell("Aspect of the Hawk"))
            {
                slog("Aspect of the Hawk.");
                aspectTimer.Reset();
                aspectTimer.Start();
                return true;
            }
            else
            {
                // slog("Can't use Aspect of the Hawk now.");
                return false;
            }
        }

        /// <summary>
        /// Summons your pet to you.
        /// </summary>        
        private bool CallPet()
        {
            if (SpellManager.CastSpell("Call Pet"))
            {
                slog("Call Pet.");
                return true;
            }
            else
            {
                // slog("Can't use Call Pet now.");
                return false;
            }
        }

        /// <summary>
        /// Dismiss your pet.  Dismissing your pet will reduce its happiness by 50.
        /// </summary>        
        private bool DismissPet()
        {
            if (SpellManager.CastSpell("Dismiss Pet", false))
            {
                slog("Dismiss Pet.");
                return true;
            }
            else
            {
                // slog("Can't use Dismiss Pet now.");
                return false;
            }
        }

        /// <summary>
        /// Feed your pet the selected item.  Feeding your pet increases happiness.  Using food close to the pet's level will have a better result.
        /// </summary>        
        private bool FeedPet()
        {

            if (!Me.GotAlivePet)
                return false;

            feedPetTimer.Reset();
            feedPetTimer.Start();

            int foodCount = Convert.ToInt32(Lua.LuaGetReturnValue("return GetItemCount(\"" + LevelbotSettings.Instance.FoodName + "\")", "hawker.lua")[0]);

            if (foodCount < 1)
            {
                slog("No food!!");
                return false;
            }

            if (SpellManager.CastSpell("Feed Pet"))
            {
                WoWMovement.MoveStop();
                Thread.Sleep(500);

                Lua.DoString("UseItemByName(\"" + LevelbotSettings.Instance.FoodName + "\")");
                slog("Feed Pet...");

                while (!Me.Combat && Me.Pet.Buffs.ContainsKey("Feed Pet"))
                {
                    Thread.Sleep(1000);
                }
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// Revive your pet, returning it to life with 15% of its base health.
        /// </summary>        
        private bool RevivePet()
        {
            if (SpellManager.CastSpell("Revive Pet"))
            {
                slog("Revive Pet.");
                return true;
            }
            else
            {
                slog("Can't use Revive Pet now.");
                return false;
            }
        }

        /// <summary>
        /// Heals your pet for 125 health over 15 sec.
        /// </summary>        
        private bool MendPet()
        {
            if (!SpellManager.KnownSpells.ContainsKey("Mend Pet"))
                return false;

            if (!Me.GotAlivePet || Me.Pet.Buffs.ContainsKey("Mend Pet"))
            {
                slog("Not Mend Pet time.");
                return true;
            }

            if (!Me.Pet.Buffs.ContainsKey("Mend Pet") &&
                SpellManager.CastSpell("Mend Pet"))
            {
                slog("Mend Pet.");
                return true;
            }
            else
            {
                // slog("Can't use Mend Pet now.");
                return false;
            }
        }

        /// <summary>
        /// Maims the enemy, reducing the target's movement speed by 50% for 10 sec.
        /// </summary>        
        private bool WingClip()
        {
            if (Me.GotTarget && Me.CurrentTarget.Distance < 6)
            {
                WoWMovement.Face();

                Thread.Sleep(250);

                if (SpellManager.CastSpell("Wing Clip"))
                {
                    slog("Wing Clip.");
                    return true;
                }
            }

            return false;
        }

        /// <summary>
        /// Scares a beast, causing it to run in fear for up to 10 sec.  Damage caused may interrupt the effect.  Only one beast can be feared at a time.
        /// </summary>        
        private bool ScareBeast()
        {
            if (Me.GotTarget && SpellManager.CastSpell("Scare Beast", false))
            {
                slog("Scare Beast.");
                return true;
            }
            else
            {
                // slog("Can't use Scare Beast now.");
                return false;
            }
        }

        /// <summary>
        /// Place a fire trap that will burn the first enemy to approach for Fire damage over 15 sec.  Trap will exist for 30 sec.  Only one trap can be active at a time.
        /// </summary>        
        private bool ImmolationTrap()
        {
            if (SpellManager.CastSpell("Immolation Trap"))
            {
                slog("Immolation Trap.");
                return true;
            }
            else
            {
                // slog("Can't use Immolation Trap now.");
                return false;
            }
        }

        /// <summary>
        /// Attack the enemy for damage.
        /// </summary>        
        private bool MongooseBite()
        {
            if (Me.GotTarget && SpellManager.CastSpell("Mongoose Bite"))
            {
                WoWMovement.Face();
                slog("Mongoose Bite.");
                return true;
            }
            else
            {
                // slog("Can't use Mongoose Bite now.");
                return false;
            }
        }

        /// <summary>
        /// The hunter takes on the aspect of the viper, causing ranged and melee attacks to regenerate mana but reducing your total damage done by 50%.  In addition, you gain 4% of maximum mana every 3 sec.  Mana gained is based on the speed of your ranged weapon. Requires a ranged weapon. Only one Aspect can be active at a time.
        /// </summary>        
        private bool AspectOfTheViper()
        {
            if (SpellManager.CastSpell("Aspect of the Viper"))
            {
                if (Me.CurrentTarget == Me)
                {
                    Me.ClearTarget();
                }

                aspectTimer.Reset();
                aspectTimer.Start();
                return true;
            }
            else
            {
                // slog("Can't use Aspect of the Viper now.");
                return false;
            }
        }

        /// <summary>
        /// You attempt to disengage from combat, leaping backwards. Can only be used while in combat.
        /// </summary>        
        private bool Disengage()
        {
            if (SpellManager.CastSpell("Disengage"))
            {
                slog("Disengage.");
                return true;
            }
            else
            {
                // slog("Can't use Disengage now.");
                return false;
            }
        }

        /// <summary>
        /// Place a frost trap that freezes the first enemy that approaches, preventing all action for up to 10 sec.  Any damage caused will break the ice.  Trap will exist for 30 sec.  Only one trap can be active at a time.
        /// </summary>        
        private bool FreezingTrap()
        {
            if (SpellManager.CastSpell("Freezing Trap"))
            {
                slog("Freezing Trap.");
                return true;
            }
            else
            {
                // slog("Can't use Freezing Trap now.");
                return false;
            }
        }

        /// <summary>
        /// Stings the target, reducing chance to hit with melee and ranged attacks by 3% for 20 sec.  Only one Sting per Hunter can be active on any one target.
        /// </summary>        
        private bool ScorpidSting()
        {
            if (Me.GotTarget && SpellManager.CastSpell("Scorpid Sting"))
            {
                slog("Scorpid Sting.");
                return true;
            }
            else
            {
                // slog("Can't use Scorpid Sting now.");
                return false;
            }
        }

        /// <summary>
        /// Increases ranged attack speed by 40% for 15 sec.
        /// </summary>        
        private bool RapidFire()
        {
            if (Me.GotTarget && SpellManager.CastSpell("Rapid Fire"))
            {
                slog("Rapid Fire.");
                return true;
            }
            else
            {
                // slog("Can't use Rapid Fire now.");
                return false;
            }
        }

        private bool AimedShot()
        {
            if (Me.GotTarget &&
                !Me.CurrentTarget.Buffs.ContainsKey("Aimed Shot") &&
                SpellManager.CastSpell("Aimed Shot"))
            {
                slog("Aimed Shot.");
                return true;
            }
            return false;
        }

        /// <summary>
        /// Place a frost trap that creates an ice slick around itself for 30 sec when the first enemy approaches it.  All enemies within 10 yards will be slowed by 50% while in the area of effect.  Trap will exist for 30 sec.  Only one trap can be active at a time.
        /// </summary>
        private bool FrostTrap()
        {
            if (SpellManager.CastSpell("Frost Trap"))
            {
                slog("Frost Trap.");
                return true;
            }
            else
            {
                // slog("Can't use use Frost Trap now.");
                return false;
            }
        }

        /// <summary>
        /// Command your pet to intimidate the target on the next successful melee attack, causing a high amount of threat and stunning the target for 3 sec. Lasts 15 sec.
        /// </summary>        
        private bool Intimidation()
        {
            if (SpellManager.CastSpell("Intimidation"))
            {
                slog("Intimidation.");
                return true;
            }
            else
            {
                // slog("Can't use Intimidation now.");
                return false;
            }
        }

        /// <summary>
        /// The hunter takes on the aspects of a beast, becoming untrackable and increasing melee attack power of the hunter and the hunter's pet by 10%.  Only one Aspect can be active at a time.
        /// </summary>        
        private bool AspectOfTheBeast()
        {
            if (SpellManager.CastSpell("Aspect of the Beast"))
            {
                slog("Aspect of the Beast.");
                aspectTimer.Reset();
                aspectTimer.Start();
                return true;
            }
            else
            {
                // slog("Can't use Aspect of the Beast now.");
                return false;
            }
        }

        /// <summary>
        /// Feign death which may trick enemies into ignoring you.  Lasts up to 6 min.
        /// </summary>
        private bool FeignDeath()
        {
            if (SpellManager.CastSpell("Feign Death"))
            {
                slog("Feign Death.");
                return true;
            }
            else
            {
                // slog("Can't use Feign Death now.");
                return false;
            }
        }

        /// <summary>
        /// Place a fire trap that explodes when an enemy approaches, causing [RAP * 0.1 + 100] to [RAP * 0.1 + 130] Fire damage and burning all enemies for 150 additional Fire damage over 20 sec to all within 10 yards.  Trap will exist for 30 sec.  Only one trap can be active at a time.
        /// </summary>        
        private bool ExplosiveTrap()
        {
            if (SpellManager.CastSpell("Explosive Trap"))
            {
                slog("Explosive Trap.");
                return true;
            }
            else
            {
                // slog("Can't use Explosive Trap now.");
                return false;
            }
        }

        /// <summary>
        /// A steady shot that causes unmodified weapon damage, plus ammo, plus [RAP * 0.1 + 45].  Causes an additional 175 against Dazed targets.
        /// </summary>        
        private bool SteadyShot()
        {
            if (Me.GotTarget && SpellManager.CastSpell("Steady Shot"))
            {
                slog("Steady Shot.");
                return true;
            }
            else
            {
                // slog("Can't use Steady Shot now.");
                return false;
            }
        }

        /// <summary>
        /// Send your pet into a rage causing 50% additional damage for 10 sec.  While enraged, the beast does not feel pity or remorse or fear and it cannot be stopped unless killed.
        /// </summary>        
        private bool BestialWrath()
        {
            if (SpellManager.CastSpell("Bestial Wrath"))
            {
                slog("Bestial Wrath.");
                return true;
            }
            else
            {
                // slog("Can't use Bestial Wrath now.");
                return false;
            }
        }

        /// <summary>
        /// When activated, increases parry chance by 100% and grants a 100% chance to deflect spells.  While Deterrence is active, you cannot attack.  Lasts 5 sec.
        /// </summary>        
        private bool Deterrence()
        {
            if (SpellManager.CastSpell("Deterrence", false))
            {
                slog("Deterrence.");
                return true;
            }
            else
            {
                // slog("Can't use Deterrence now.");
                return false;
            }
        }

        /// <summary>
        /// Give the command to kill, increasing your pet's damage done from special attacks by 60% for 30 sec.  Each special attack done by the pet reduces the damage bonus by 20%.
        /// </summary>
        private bool KillCommand()
        {
            if (SpellManager.CastSpell("Kill Command"))
            {
                slog("Kill Command.");
                return true;
            }
            else
            {
                // slog("Can't use Kill Command now.");
                return false;
            }
        }

        /// <summary>
        /// Place a trap that will release several venomous snakes to attack the first enemy to approach.  The snakes will die after 15 sec.  Trap will exist for 30 sec.  Only one trap can be active at a time.
        /// </summary>
        private bool SnakeTrap()
        {
            if (SpellManager.CastSpell("Snake Trap"))
            {
                slog("Snake Trap.");
                return true;
            }
            else
            {
                // slog("Can't use Snake Trap now.");
                return false;
            }
        }

        /// <summary>
        /// You attempt to finish the wounded target off, firing a long range attack dealing 200% weapon damage plus [RAP * 0.40 + 410]. Kill Shot can only be used on enemies that have 20% or less health.
        /// </summary>
        private bool KillShot()
        {
            if (Me.GotTarget && SpellManager.CastSpell("Kill Shot"))
            {
                slog("Kill Shot.");
                return true;
            }
            else
            {
                // slog("Can't use Kill Shot now.");
                return false;
            }
        }

        /// <summary>
        /// The hunter takes on the aspects of a dragonhawk, increasing ranged attack power by 230 and chance to dodge by 18%.  Only one Aspect can be active at a time.
        /// </summary>        
        private bool AspectOfTheDragonhawk()
        {
            if (SpellManager.CastSpell("Aspect of the Dragonhawk"))
            {
                slog("Aspect of the Dragonhawk.");
                aspectTimer.Reset();
                aspectTimer.Start();
                return true;
            }
            else
            {
                // slog("Can't use Aspect of the Dragonhawk now.");
                return false;
            }
        }

        /// <summary>
        /// Fire a freezing arrow that places a Freezing Trap at the target location, freezing the first enemy that approaches, preventing all action for up to 20 sec.  Any damage caused will break the ice.  Trap will exist for 30 sec.  Only one trap can be active at a time.
        /// </summary>
        /// <param name="targetSpot"></param>        
        private bool FreezingArrow(WoWPoint targetSpot)
        {
            if (SpellManager.CastSpell("Freezing Arrow"))
            {
                slog("Freezing Arrow.");
                return true;
            }
            else
            {
                // slog("Can't use Freezing Arrow now.");
                return false;
            }
        }

        #endregion

        #region aspects

        bool usingAspectOfTheViper = false;
        private void SelectAspect()
        {
            if (Me.ManaPercent < 15)
            {
                AspectOfTheViper();
                usingAspectOfTheViper = true;
            }

            if (usingAspectOfTheViper && Me.ManaPercent < 100)
            {
                return;
            }
            else
            {
                usingAspectOfTheViper = false;
            }

            if (Me.GotTarget)
            {
                // ranged
                if (Me.CurrentTarget.Distance > 10 || Me.HealthPercent > 50)
                {
                    if (SpellManager.KnownSpells.ContainsKey("Aspect of the Dragonhawk"))
                    {
                        if (!Me.Buffs.ContainsKey("Aspect of the Dragonhawk"))
                        {
                            AspectOfTheDragonhawk();
                        }
                    }
                    else if (SpellManager.KnownSpells.ContainsKey("Aspect of the Hawk"))
                    {
                        if (!Me.Buffs.ContainsKey("Aspect of the Hawk"))
                        {
                            AspectOfTheHawk();
                        }
                    }
                    else if (SpellManager.KnownSpells.ContainsKey("Aspect of the Monkey") &&
                        !Me.Buffs.ContainsKey("Aspect of the Monkey"))
                    {
                        AspectofTheMonkey();
                    }
                }
                else
                //melee
                {
                    if (SpellManager.KnownSpells.ContainsKey("Aspect of the Beast"))
                    {
                        if (!Me.Buffs.ContainsKey("Aspect of the Beast"))
                        {
                            AspectOfTheBeast();
                        }
                    }
                    else if (SpellManager.KnownSpells.ContainsKey("Aspect of the Monkey") &&
                        !Me.Buffs.ContainsKey("Aspect of the Monkey"))
                    {
                        AspectofTheMonkey();
                    }
                }
            }

        }
        #endregion

        #region melee

        #endregion

        #region ranged
        #endregion

        #region traps
        #endregion

        #region petcare
        #endregion

        #region utilities

        private List<WoWUnit> getAdds()
        {
            DateTime startLists = DateTime.Now;

            List<WoWUnit> mobList = ObjectManager.GetObjectsOfType<WoWUnit>(false);

            if (DateTime.Now.Subtract(startLists).Seconds > 0)
            {
                Logging.WriteDebug("Make Lists: " + DateTime.Now.Subtract(startLists).Seconds + "." + DateTime.Now.Subtract(startLists).Milliseconds);
            }

            List<WoWUnit> enemyMobList = new List<WoWUnit>();

            foreach (WoWUnit thing in mobList)
            {
                try
                {
                    if ((thing.Guid != Me.Guid) &&
                    thing.IsTargetingMe)
                    {
                        enemyMobList.Add(thing);
                    }
                }
                catch (Exception ex)
                {
                    Logging.WriteException(ex);
                    slog("Add error.");
                }
            }

            if (enemyMobList.Count > 1)
            {
                slog("Warning: there are " + enemyMobList.Count.ToString() + " attackers.");
            }
            return enemyMobList;
        }

        private void slog(string msg)
        {
            if (msg != _logspam)
            {
                Logging.Write(msg);
                _logspam = msg;
            }
        }

        private void slog(string format, params object[] args)
        {
            Logging.Write(format, args);
        }

        #endregion

        #region movement logic

        /// <summary>
        /// Move while alive and in game
        /// </summary>
        /// <param name="direction">The way to go</param>
        /// <param name="duration">Time to go in milliseconds</param>
        private void SafeMove(WoWMovement.MovementDirection direction, int duration)
        {
            DateTime start = DateTime.Now;

            WoWMovement.Move(direction);

            while (ObjectManager.IsInGame && ObjectManager.Me.HealthPercent > 1)
            {
                Thread.Sleep(335);

                if (DateTime.Now.Subtract(start).Milliseconds < 300 || DateTime.Now.Subtract(start).Milliseconds >= duration)
                {
                    break;
                }

            }

            WoWMovement.MoveStop(direction);
        }

        WoWPoint attackPoint
        {
            get
            {
                if (Me.GotTarget && SpellManager.KnownSpells.ContainsKey("Auto Shot"))
                {
                    return WoWMovement.CalculatePointFrom(Me.CurrentTarget.Location, (float)SpellManager.KnownSpells["Auto Shot"].MaxRange - 3);
                }
                else
                {
                    WoWPoint noSpot = new WoWPoint();
                    return noSpot;
                }
            }
        }



        #endregion

        #region horde racials

        // Berserking
        void Berserking()
        {
            if (ObjectManager.Me.Race == WoWRace.Troll &&
                SpellManager.CastSpell("Berserking"))
            {
                Styx.Helpers.Logging.Write("Berserking.");
            }
        }

        // Bloodrage
        void Bloodrage()
        {
            if (ObjectManager.Me.Race == WoWRace.Orc &&
                SpellManager.CastSpell("Bloodrage"))
            {
                Styx.Helpers.Logging.Write("Bloodrage.");
            }
        }

        // War Stomp
        void WarStomp()
        {
            if (ObjectManager.Me.Race == WoWRace.Tauren &&
                SpellManager.CastSpell("War Stomp"))
            {
                Styx.Helpers.Logging.Write("War Stomp.");
            }
        }

        // Arcane Torrent
        void ArcaneTorrent()
        {
            if (ObjectManager.Me.Race == WoWRace.BloodElf &&
                SpellManager.CastSpell("Arcane Torrent"))
            {
                Styx.Helpers.Logging.Write("Arcane Torrent.");
            }
        }

        // Will of the Forsaken 
        void WillOfTheForsaken()
        {
            if (ObjectManager.Me.Race == WoWRace.Undead &&
                SpellManager.CastSpell("Will of the Forsaken"))
            {
                Styx.Helpers.Logging.Write("Will of the Forsaken.");
            }
        }
        #endregion

        #region alliance racials

        // Stoneform
        void Stoneform()
        {
            if (ObjectManager.Me.Race == WoWRace.Dwarf &&
                SpellManager.CastSpell("Stoneform"))
            {
                Styx.Helpers.Logging.Write("Stoneform.");
            }
        }

        // Gift of the Naaru
        void GiftOfTheNaaru()
        {
            if (ObjectManager.Me.Race == WoWRace.Draenei &&
                SpellManager.CastSpell("Gift of the Naaru"))
            {
                Styx.Helpers.Logging.Write("Gift of the Naaru.");
            }
        }

        // Every Man for Himself
        void EveryManForHimself()
        {
            if (ObjectManager.Me.Race == WoWRace.Human &&
                SpellManager.CastSpell("Every Man for Himself"))
            {
                Styx.Helpers.Logging.Write("Every Man for Himself.");
            }
        }

        // Shadowmeld
        void Shadowmeld()
        {
            if (ObjectManager.Me.Race == WoWRace.NightElf &&
                SpellManager.CastSpell("Shadowmeld"))
            {
                Styx.Helpers.Logging.Write("Shadowmeld.");
            }
        }

        // Escape Artist
        void EscapeArtist()
        {
            if (ObjectManager.Me.Race == WoWRace.Gnome &&
                SpellManager.CastSpell("Escape Artist"))
            {
                Styx.Helpers.Logging.Write("Escape Artist.");
            }
        }


        #endregion
    }
}
#pragma warning restore