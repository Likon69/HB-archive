﻿/*
 * NOTICE:    DO NOT POST ANY MODIFIED VERSIONS OF THIS TO THE FORUMS.  ALL CHANGES
 *            TO THIS CC ARE TO BE REVIEWED AND INCORPORATED BY THE AUTHOR.
 * 
 * ShamWOW Shaman CC - Version: 4.1.3
 * 
 * Author:  Bobby53
 * 
 * General approach to leveling and spell rotations taken from:
 * 
 *          http://wow-pro.com/class_guides/shaman_leveling_talents_and_tips_180
 *          
 * For use of totems during leveling, I am using strategies outlined in :
 * 
 *          http://www.yawb.info/2009/08/25/learning-about-totems-tips-to-aid-your-growing-shamanism/
 * 
 * Change History moved to CHANGES.TXT file
 *
 */

#define BUNDLED_WITH_HONORBUDDY


/*************************************************************************
 *   !!!!! DO NOT CHANGE ANYTHING IN THIS FILE !!!!!
 *   
 *   User customization is only supported through changing the values
 *   in the SETTINGS.SETTINGS xml file in your Custom Classes folder tree
*************************************************************************/
#pragma warning disable 642

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading;
using Styx;
using Styx.Combat.CombatRoutine;
using Styx.Helpers;
using Styx.Logic;
using Styx.Logic.Combat;
using Styx.Logic.Pathing;
using Styx.Logic.Profiles;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;

// using ShamWOW.Properties;

namespace ShamWOW
{
    internal class ShamWOW : CombatRoutine
    {
        public static string Version
        {
            get { return "4.1.3"; }
        }

        public override WoWClass Class
        {
            get { return WoWClass.Shaman; }
        }

#if    BUNDLED_WITH_HONORBUDDY
        public override string Name
        {
            get { return "ShamWOW v" + Version + "-BUNDLED"; }
        }
#else
        public override string Name { get { return "ShamWOW v" + Version; } }
#endif

        #region Global Variables

        public static ConfigValues _cfg;
        public static ShamWOW _local;

        public static CC_PVP _pvp = new CC_PVP(); // pvp support class for CC's
        private readonly TalentGroup _primaryTalents = new TalentGroup();
        private readonly TalentGroup _secondaryTalents = new TalentGroup();

        public static readonly string ConfigPath =
            Path.Combine(Path.GetDirectoryName(Assembly.GetEntryAssembly().Location),
                         Path.Combine("CustomClasses/ShamWoW", "Config"));

        public static readonly string CCPath = Path.Combine(
            Path.GetDirectoryName(Assembly.GetEntryAssembly().Location), Path.Combine("CustomClasses", "ShamWOW"));

        public static string ConfigFilename;

        private uint _countDrinks;
        private uint _countFood;
        private readonly int _tickStart = Environment.TickCount;

        private double _maxDistForRangeAttack
        {
            get
            {
                // use Lightning Bolt range as ranged distance, 
                //  ... unless Nature Immune, figure out how close we need to be
                try
                {
                    return SpellManager.KnownSpells["Lightning Bolt"].MaxRange;
                }
                catch (ThreadAbortException)
                {
                    throw;
                }
                catch
                {
                    return 30;
                }
            }
        }

        private double _distForRangedPull
        {
            get
            {
                double dist = _maxDistForRangeAttack;
                if (_me.GotTarget && IsImmunneToNature(_me.CurrentTarget))
                {
                    if (Safe_KnownSpell("Lava Lash"))
                        dist = SpellManager.KnownSpells["Lava Lash"].MaxRange;
                    else if (Safe_KnownSpell("Flame Shock")) // go into melee then
                        dist = SpellManager.KnownSpells["Flame Shock"].MaxRange;
                    else
                        dist = _distForMeleePull + 4.0;

                    Slog("Nature immune:  making pull distance for target {0:F1} yds", dist - 4);
                }

                return dist - 4.0;
            }
        }

        private double _maxDistForMeleeAttack = 5.0;

        private double _distForMeleePull
        {
            get
            {
                if (_pvp.IsBattleground())
                {
                    if (_me.GotTarget && _me.CurrentTarget.Fleeing)
                    {
                        Dlog("using fleeing target range of 0.0");
                        return 0.0;
                    }

                    return 2.0;
                }

                return 3.0;
            }
        }

        private volatile LocalPlayer _me = ObjectManager.Me;

        private readonly Stopwatch _pullTimer = new Stopwatch(); // kill timer from when we target for pull
        private ulong _pullTargGuid;
        // private bool _pullTargHasBeenInMelee = false;       // flag indicating that we got in melee range of mob
        private int _pullAttackCount;
        private WoWPoint _pullStart;

        private uint _killCount;
        private uint _killCountBase;
        private uint _deathCount;
        private uint _deathCountBase;

        private bool _waterShieldUsedLast; // toggle remember which shield used last shield twist

        private readonly Stopwatch _TotemCheckTimer = new Stopwatch();
                                   // timer to prevent checking totems each time through Combat  (uses LUA funcs)

        private static bool _WereTotemsSet; // flag indicating whether any totems were cast
        private bool _RecallTotems;
        private WoWPoint _ptTotems;

        private bool _castGhostWolfForm; // 
        private bool _castMainHandEnchant;
        private bool _castOffHandEnchant;
        private bool _castCleanse;

        private bool _BigScaryGuyHittingMe; // mob sufficiently higher than us (3+ lvls)
        private bool _OpposingPlayerGanking; // player from other faction attacking me
        private static int _countMeleeEnemy; // # of melee mobs in combat with me
        private static int _countRangedEnemy; // # of ranged mobs in combat with me
        private int _countMobs; // # of faction mobs as spec'd in current profile
        //	private double _distClosestEnemy = 0;           // distance to closest hostile or faction mob
        //	private WoWPoint _ptClosestEnemy;

        private bool _needClearWeaponEnchants = true;
        private bool _needTotemBarSetup = true;


        private bool _lastCheckInBattleground; // 
        private bool _lastCheckInGroup;
        private ShamanType _lastCheckSpec = ShamanType.None;


        private bool DidWeSwitchModes()
        {
            bool inGroup = _me.PartyMembers.Count > 1 || _me.RaidMembers.Count > 1;
            if (_lastCheckInBattleground != _pvp.IsBattleground() || _lastCheckInGroup != inGroup ||
                _lastCheckSpec != _typeShaman)
            {
                _lastCheckInBattleground = _pvp.IsBattleground();
                _lastCheckInGroup = inGroup;
                _lastCheckSpec = _typeShaman;
                return true;
            }

            return false;
        }

        private readonly Stopwatch _potionTimer = new Stopwatch();


        private int _pointsImprovedStormstrike;

        public enum ShamanType
        {
            None,
            Elemental,
            Enhance,
            Resto
        } ;

        public ShamanType _typeShaman = ShamanType.None;

        private int countEnemy
        {
            get { return _countMeleeEnemy + _countRangedEnemy; }
        }

        private bool IsFightStressful()
        {
            return countEnemy >= _cfg.PVE_StressfulMobCount || _BigScaryGuyHittingMe || _OpposingPlayerGanking;
        }

        #endregion

        #region Private Members

        /// <summary>
        /// Initialize and post load messages/checks for user
        /// </summary>
        public override void Initialize()
        {
            Slog("LOADED:  " + Name);
            _local = this;

            // load config file (create if doesn't exist)
            var realmName = Lua.GetReturnVal<string>("return GetRealmName()", 0);
            ConfigFilename = Path.Combine(ConfigPath, "ShamWOW-" + realmName + "-" + _me.Name + ".config");

            if (!Directory.Exists(ConfigPath))
            {
                try
                {
                    Directory.CreateDirectory(ConfigPath);
                }
                catch (ThreadAbortException)
                {
                    throw;
                }
                catch
                {
                    Wlog("Path could not be created: '{0}'", ConfigPath);
                    Wlog("Create the path manually if needed and restart HB");
                    return;
                }
            }

            _cfg = new ConfigValues();
            if (File.Exists(ConfigFilename))
            {
                _cfg.FileLoad(ConfigFilename);
                Slog("Character specific config file loaded");
            }
            else
            {
                _cfg.Save(ConfigFilename);
                Slog("Creating a character specific config file ");
            }

            _cfg.DebugDump();

            _deathCountBase = InfoPanel.Deaths;

            _primaryTalents.Load(1);
            _secondaryTalents.Load(2);

            TalentGroup activeGrp;
            TalentGroup inactiveGrp;

            if (_primaryTalents.IsActiveGroup())
            {
                activeGrp = _primaryTalents;
                inactiveGrp = _secondaryTalents;
            }
            else
            {
                inactiveGrp = _primaryTalents;
                activeGrp = _secondaryTalents;
            }

            string sSpecType = activeGrp.TabName[activeGrp.Spec()];
            if (activeGrp.Spec() == 1)
                _typeShaman = ShamanType.Elemental;
            else if (activeGrp.Spec() == 2)
                _typeShaman = ShamanType.Enhance;
            else if (activeGrp.Spec() == 3)
                _typeShaman = ShamanType.Resto;
            else
            {
                _typeShaman = ShamanType.None;
                sSpecType = "Undefined";
            }

            Slog("  Your Level " + _me.Level + " " + _me.Race + " " + sSpecType + " Shaman Build is:  ");
            Slog("  " + activeGrp.TabName[1].Substring(0, 5) + "/" + activeGrp.TabName[2].Substring(0, 5) + "/" +
                 activeGrp.TabName[3].Substring(0, 5)
                 + "   " + activeGrp.TabPoints[1] + "/" + activeGrp.TabPoints[2] + "/" + activeGrp.TabPoints[3]);

            if (activeGrp.TotalPoints < (_me.Level - 9))
            {
                Wlog(
                    "WARNING: {0} unspent Talent Points. Use the eTalent plug-in or apply your talent points manually",
                    (_me.Level - 9) - activeGrp.TotalPoints);
            }

            RunLUA("CancelItemTempEnchantment(1)");
            RunLUA("CancelItemTempEnchantment(2)");

            Slog("Max Pull Ranged:   {0}", _maxDistForRangeAttack);
            Slog("HB Pull Distance:  {0}", Targeting.PullDistance);

            if (_typeShaman == ShamanType.Enhance)
            {
                _pointsImprovedStormstrike = activeGrp.GetTalentInfo(2, 24);
                Slog("Found {0} points in Improved Stormstrike", _pointsImprovedStormstrike);
            }

            // Styx.Helpers.InfoPanel.Reset();
            _killCountBase = InfoPanel.MobsKilled;
            _deathCountBase = InfoPanel.Deaths;

            const float minPathPrecision = 2.5f;
            float prevPrec = Navigator.PathPrecision;
            if (prevPrec != minPathPrecision)
            {
                Navigator.PathPrecision = minPathPrecision;
                Slog("Changed Navigator precision from {0} to {1}", prevPrec, minPathPrecision);
            }

            SequenceManager.AddSequenceExecutorOverride(Sequence.ReleaseSpirit, SequenceOverride_ReleaseSpirit);
            SequenceManager.AddSequenceExecutorOverride(Sequence.MountUp, SequenceOverride_MountUp);

            _cfg.DebugDump();

            TotemSetupBar(); // calling this hear to make sure that totem info is initialized
        }

        public static string SafeLogException(string msg)
        {
            msg = msg.Replace("{", "(");
            msg = msg.Replace("}", ")");
            return msg;
        }

        /* Log()
         * 
         * write 'msg' to log window.  message is suppressed if it is identical
         * to prior message.  Intent is to prevent log window spam
         */

        public static void Log(string msg, params object[] args)
        {
            try
            {
                Logging.Write(msg, args);
            }
            catch (ThreadAbortException)
            {
                throw;
            }
            catch (Exception e)
            {
                Logging.WriteDebug(">>> EXCEPTION: occurred logging msg: \n\t\"" + SafeLogException(msg) + "\"");
                Logging.WriteException(e);
            }
        }


        public static void Log(Color clr, string msg, params object[] args)
        {
            try
            {
                Logging.Write(clr, msg, args);
            }
            catch (ThreadAbortException)
            {
                throw;
            }
            catch (Exception e)
            {
                Logging.WriteDebug(">>> EXCEPTION: occurred logging msg: \n\t\"" + SafeLogException(msg) + "\"");
                Logging.WriteException(e);
            }
        }


        /* Slog()
         * 
         * write 'msg' to log window.  message is suppressed if it is identical
         * to prior message.  Intent is to prevent log window spam
         */
        private static string _Slogspam;

        public static void Slog(Color clr, string msg, params object[] args)
        {
            try
            {
                msg = String.Format(msg, args);
                if (msg == _Slogspam)
                    return;

                Log(clr, msg);
                _Slogspam = msg;
            }
            catch (ThreadAbortException)
            {
                throw;
            }
            catch (Exception e)
            {
                Logging.WriteDebug(">>> EXCEPTION: occurred logging msg: \n\t\"" + SafeLogException(msg) + "\"");
                Logging.WriteException(e);
            }
        }

        public static void Slog(string msg, params object[] args)
        {
            Slog(Color.Black, msg, args);
        }


        public static void Elog(string msg, params object[] args)
        {
            Slog(Color.Red, msg, args);
        }

        /* Wlog()
         * 
         * write 'msg' to log window, but only if it hasn't been written already.
         */
        private static readonly List<string> _warnList = new List<string>(); // tracks warning messages issued by Wlog()

        public static void Wlog(string msg, params object[] args)
        {
            msg = String.Format(msg, args);
            String found = _warnList.Find(s => 0 == s.CompareTo(msg));
            if (found == null)
            {
                _warnList.Add(msg);
                Log(Color.Red, msg);
            }
        }

        /* Dlog()
         * 
         * Write Debug log message to log window.  message is suppressed if it
         * is identical to prior log message or verbose mode is turned off.  These
         * messages are trace type in nature to follow in more detail what has occurred
         * in the code.
         * 
         * NOTE:  I am intentionally putting debug message in the Log().  At this point,
         * it helps more having all data be time sequenced in the same window.  This will
         * near the close of development move to the Debug window instead
         */
        private static string _Dlogspam;

        public static void Dlog(string msg, params object[] args)
        {
            try
            {
                msg = String.Format(msg, args);
                if (msg == _Dlogspam) // || _cfg.Debug == false)
                    return;

                if (_cfg.Debug)
                    Logging.WriteDebug("%   " + msg);
            }
            catch (ThreadAbortException)
            {
                throw;
            }
            catch (Exception e)
            {
                Logging.WriteDebug(">>> EXCEPTION: occurred logging msg: \n\t\"" + SafeLogException(msg) + "\"");
                Logging.WriteException(e);
            }

            _Dlogspam = msg;
        }

        private void ReportBodyCount()
        {
            bool rptKill = (_killCountBase + _killCount) < InfoPanel.MobsKilled;
            bool rptDeath = (_deathCountBase + _deathCount) < InfoPanel.Deaths;

            if (rptDeath)
            {
                _deathCount = InfoPanel.Deaths - _deathCountBase;
                Slog("! Death #{0} at {1:F1} per hour fighting at x={2},y={3},z={4}",
                     InfoPanel.Deaths,
                     InfoPanel.DeathsPerHour,
                     _me.Location.X,
                     _me.Location.Y,
                     _me.Location.Z
                    );
            }

            if (rptKill)
            {
                _killCount = InfoPanel.MobsKilled - _killCountBase;
                Slog("! Kill #{0} at {1:F0} xp per hour fighting at x={2},y={3},z={4}",
                     InfoPanel.MobsKilled,
//                     InfoPanel.XPPerHour,
                     _me.Location.X,
                     _me.Location.Y,
                     _me.Location.Z
                    );
            }
        }

        private static void SequenceOverride_ReleaseSpirit()
        {
            _countMeleeEnemy = 0; // # of melee mobs in combat with me
            _countRangedEnemy = 0; // # of ranged mobs in combat with me
            _WereTotemsSet = false;

            // next phase
            // ... if selfrez available, inspect surrounding area if clear within
            // ... a configurable time delay, then selfrez, otherwise repop
            List<string> hasSoulstone = Lua.LuaGetReturnValue("return HasSoulstone()", "hawker.lua");
            if (hasSoulstone != null && hasSoulstone.Count > 0 && hasSoulstone[0].ToLower() != "nil")
            {
                /*
                Lua.DoString("UseSoulstone()");
                int tickCount = Environment.TickCount;
                while (!ObjectManager.Me.IsAlive && Environment.TickCount - tickCount < 7500)
                    Thread.Sleep(100);
                if (ObjectManager.Me.IsAlive)
                    return;
                 */

                Slog("Skipping use of '{0}'", hasSoulstone[0]);
            }

            // SequenceManager.CallDefaultSequenceExecutor(Sequence.ReleaseSpirit);

            Lua.DoString("RepopMe()", "hawker.lua");

            int tickCount = Environment.TickCount;
            while (!ObjectManager.Me.IsAlive && Environment.TickCount - tickCount < 10000)
                Thread.Sleep(100);

            if (!ObjectManager.Me.IsAlive)
            {
                SequenceManager.CallDefaultSequenceExecutor(Sequence.ReleaseSpirit);
            }
        }

        private static void SequenceOverride_MountUp()
        {
            // Don't mount if we are dead
            if (StyxWoW.Me.Dead || StyxWoW.Me.IsGhost)
                return;

            // add a check here for ....
            //  ... if we are healing and heal targets nearby, suppress
            //  ... if we have attack targets nearby, suppress
            if (_local._typeShaman == ShamanType.Resto
                ||
                (Battlegrounds.IsInsideBattleground && _cfg.PVP_CombatStyle != ConfigValues.PvpCombatStyle.CombatOnly)
                || (IsRAF() && _cfg.RAF_CombatStyle != ConfigValues.RafCombatStyle.CombatOnly))
            {
                double healPct = _cfg.PVP_GroupNeedHeal;
                WoWPlayer p = CC_PVP.ChooseHealTarget(healPct);
                if (p != null && !p.IsMe)
                {
                    Dlog("MountUp:  suppressing mountup - {0}[{1}] at {2:F1} yds needs heal", p.Class, p.Level,
                         p.Distance);
                    return;
                }
            }

            if (_WereTotemsSet)
            {
                Dlog("MountUp:  HB wants to mount and totems exist... recalling totems");
                _local.RecallTotemsForMana();
            }

            Dlog("MountUp:  trying to mount");
            // if ( ObjectManager.Me.IsMoving )
            //     Safe_StopMoving();
            SequenceManager.CallDefaultSequenceExecutor(Sequence.MountUp);
        }

        #region SAFE_ Functions

        /*
         * Safe_ Functions.  These were created to handle unexpected errors and
         * situations occurring in HonorBuddy.  try/catch handling is provided
         * where an exception is thrown by HB that shouldn't be. multiple
         * attempts at something (like dismounting) are done until the desired
         * state (!_me.Mounted) is achieved
         */

        private string Safe_UnitName(WoWUnit unit)
        {
            if (unit == null)
                return "(null)";

            if (unit.IsPlayer && Safe_IsFriendly(unit)) // !unit.IsHostile ) // unit.IsFriendly)
                return unit.Class.ToString();

            return unit.Name;
        }

        // replacement for WoWUnit.IsFriendly
        // to handle bug in HB 1.9.2.5 where .IsFriendly throws exception casting WoWUnit -> WoWPlayer
        private static bool Safe_IsFriendly(WoWUnit unit)
        {
            if (!unit.IsPlayer)
                return unit.IsFriendly;

            WoWPlayer p = unit.ToPlayer();
            return p.IsHorde == ObjectManager.Me.IsHorde;
        }

        // replacement for WoWUnit.IsNeutral
        // to handle bug in HB 1.9.2.5 where .IsHostile throws exception casting WoWUnit -> WoWPlayer
        private static bool Safe_IsNeutral(WoWUnit unit)
        {
            if (!unit.IsPlayer)
                return unit.IsNeutral;

            return false;
        }

        // replacement for WoWUnit.IsHostile
        // to handle bug in HB 1.9.2.5 where .IsHostile throws exception casting WoWUnit -> WoWPlayer
        private static bool Safe_IsHostile(WoWUnit unit)
        {
            if (!unit.IsPlayer)
                return unit.IsHostile;

            WoWPlayer p = unit.ToPlayer();
            return p.IsHorde != ObjectManager.Me.IsHorde;
        }

        // replacement for WoWUnit.IsValid
        private bool Safe_IsValid(WoWUnit unit)
        {
            return unit != null;
        }

        // replacement for WoWPlayer.IsValid
        private bool Safe_IsValid(WoWPlayer p)
        {
            return p != null;
        }

        // replacement for SpellManager.KnownSpells.ContainsKey() which had a bug previously with Shaman spells
        private bool Safe_KnownSpell(string sSpellName)
        {
            bool bKnown = false;

            try
            {
                if (sSpellName == "")
                    return false;

                bKnown = SpellManager.KnownSpells.ContainsKey(sSpellName);
            }
            catch (ThreadAbortException)
            {
                throw;
            }
            catch (Exception e)
            {
                Logging.WriteDebug(
                    ">>> CRITICAL ERROR: SpellManager.KnownSpells.ContainsKey() is corrupt and fails when looking up \"" +
                    sSpellName + "\"");
                Logging.WriteDebug(">>> REPORT ERROR TO CC DEVELOPER WITH LOG");
                Logging.WriteException(e);
                throw;
            }

            return bKnown;
        }

        // replacement for SpellManager.GlobalCooldown -- bug in 1.9.2.3 and later on some systems causing it to always be true
        private bool _warnedGCD;

        private bool Safe_GlobalCooldown()
        {
            if (!_warnedGCD)
            {
                var timer = new Stopwatch();
                timer.Start();
                while (SpellManager.GlobalCooldown && timer.ElapsedMilliseconds < 1500)
                {
                    Thread.Sleep(50);
                }

                if (SpellManager.GlobalCooldown)
                {
                    _warnedGCD = true;
                    Slog("workaround enabled - disabling HonorBuddy use of SpellManager.GlobalCooldown");
                }
            }

            return false;
        }


        private bool Safe_AreSpellReagentsAvailable(string spellName)
        {
            List<string> info = CallLUA("return IsUsableSpell( \"" + spellName + "\")");
            if (Equals(null, info))
            {
                return false;
            }

            bool usableVal = !(info[0] == "" || info[0] == "nil");
            bool manaVal = !(info[1] == "" || info[1] == "nil");
            return usableVal; // && !manaVal;
        }

        private static bool MeImmobilized()
        {
            if (ObjectManager.Me.Stunned)
                Slog("You are stunned and unable to cast");
            else if (ObjectManager.Me.Possessed)
                Slog("You are possessed and unable to cast");
            else
                return false;

            return true;
        }

        private bool MeSilenced()
        {
            if (MeImmobilized())
                ;
            else if (ObjectManager.Me.Silenced)
                Slog("You are silenced and unable to cast");
            else
                return false;

            return true;
        }

        /*
         * Safe_CastSpell()
         * 
         * several different overloads providing the ability to safely
         * cast a spell with or without a range check
         */

        private enum SpellRange
        {
            NoCheck,
            Check
        } ;

        private enum SpellWait
        {
            NoWait,
            Complete
        } ;

        private bool Safe_CastSpell(string sSpellName)
        {
            return Safe_CastSpell(sSpellName, SpellRange.NoCheck, SpellWait.Complete);
        }

        private bool Safe_CastSpellWithRangeCheck(string sSpellName)
        {
            return Safe_CastSpell(sSpellName, SpellRange.Check, SpellWait.Complete);
        }

        private bool Safe_CastSpell(string sSpellName, SpellRange chkRng, SpellWait chkWait)
        {
            WoWSpell spell = null;

            try
            {
                spell = SpellManager.KnownSpells[sSpellName];
            }
            catch (ThreadAbortException)
            {
                throw;
            }
            catch (Exception e)
            {
                Logging.WriteDebug(">>> HB EXCEPTION in SpellManager.KnownSpells[" + sSpellName + "]");
                Logging.WriteDebug(">>> Spell '" + sSpellName + "' believed to be " +
                                   (Safe_KnownSpell(sSpellName) ? "KNOWN" : "UNKNOWN") + " was used ");
                Logging.WriteException(e);
                throw;
                // return false;
            }

            return Safe_CastSpell(spell, chkRng, chkWait);
        }

        private bool Safe_CastSpellWithRangeCheck(WoWSpell spell)
        {
            return Safe_CastSpell(spell, SpellRange.Check, SpellWait.Complete);
        }

        private bool Safe_CastSpell(WoWSpell spell)
        {
            return Safe_CastSpell(spell, SpellRange.NoCheck, SpellWait.Complete);
        }

        private bool Safe_CastSpell(WoWSpell spell, SpellRange chkRng, SpellWait chkWait)
        {
            bool enoughPower = false;
            bool bCastSuccessful = false;

            enoughPower = (_me.GetCurrentPower(spell.PowerType) >= spell.PowerCost);

            if (MeSilenced())
                ;
            else if (spell.Cooldown)
                Dlog("status: Spell '{0}' on cooldown - cant cast yet", spell.Name);
            else if (chkRng == SpellRange.Check && spell.MaxRange < _me.CurrentTarget.Distance)
                Dlog("status: Spell '{0}' has max range of {1:F1} but target is {2:F1} yds away - not cast", spell.Name,
                     spell.MaxRange, _me.CurrentTarget.Distance);
            else if (Safe_GlobalCooldown())
                Dlog("status: Global Cooldown (GCD) is active! can't cast '{0}'", spell.Name);
            else
            {
                WaitForCurrentSpell();
                if (false == SpellManager.CanCastSpell(spell.Name))
                {
                    Dlog("status: cannot cast spell '{0}' yet", spell.Name);
                }
                    //	    else if (SpellManager.GlobalCooldown)
                    //		Dlog("status:  GCD is active -- not cast");
                    //	    else if (spell.Cooldown)
                    //		Dlog("status:  spell [{0}] on cooldown - not cast", spell.Name );
                    //	    else if (!enoughPower)
                    //		Dlog("warning:  not enough mana/energy for spell - " + spell.Name);
                    //	    else if ( !SpellManager.CastableSpell( spell ))
                    //		Dlog("status:  missing proc/reagent/totem to cast spell - " + spell.Name);
                    //	    else if (!SpellManager.CanCastSpell( spell.Id ))                    // unclear what this spell does other than periodically
                    //		Dlog("warning:  cannot cast spell {0} due to missing proc/reagent/totem", spell.Name  );       // .. block casting which otherwise can occur... disabled
                else
                {
                    try
                    {
                        spell.Cast();
                    }
                    catch (ThreadAbortException)
                    {
                        throw;
                    }
                    catch (Exception e)
                    {
                        Logging.WriteDebug("HB EXCEPTION in spell.Cast([" + spell.Id + ":" + spell.Name + "])");
                        Logging.WriteException(e);
                        return false;
                    }

                    Slog(Color.DodgerBlue, "*" + spell.Name);
                    bCastSuccessful = true;

                    if (chkWait == SpellWait.Complete)
                    {
                        Thread.Sleep(75); // Thread.Sleep(250);
                        WaitForCurrentSpell();
                    }
                }
            }

            return bCastSuccessful;
        }

        private void WaitForCurrentSpell()
        {
            if (Safe_GlobalCooldown())
                Dlog("Waiting for global cooldown to finish");
            else if (_me.IsCasting || _me.ChanneledCasting != 0)
                Dlog("Waiting for current spell to finish casting");

            while (Safe_GlobalCooldown() || _me.IsCasting || _me.ChanneledCasting != 0)
            {
                Thread.Sleep(75);
            }
        }

        private void RunLUA(string sCmd)
        {
            WaitForCurrentSpell();
            Lua.DoString(sCmd, "hawker.lua");
        }

        private List<string> CallLUA(string sCmd)
        {
            WaitForCurrentSpell();
            return Lua.LuaGetReturnValue(sCmd, "hawker.lua");
        }


        /*
         * Only issues the Stop moving command if currently moving.  also
         * accounts for any lag which prevents immediate stop
         */

        public static void Safe_StopMoving()
        {
            if (_cfg.DisableMovement)
                return;

            int countTries = 0;
            var stopTimer = new Stopwatch();

            stopTimer.Start();
            while (ObjectManager.Me.IsMoving && stopTimer.ElapsedMilliseconds < 1000)
            {
                countTries++;
                WoWMovement.MoveStop();
                Thread.Sleep(100); // increased from 50 to handle flag update lag better
            }

            if (countTries > 1)
            {
                Dlog("Attempted to stop moving " + countTries);
            }

            if (!ObjectManager.Me.IsMoving)
                Dlog("Stopped Moving");
            else
            {
                if (MeImmobilized())
                    Slog("Immobilized is true but still moving and can't stop; am I Feared?");
                else
                    Slog("ERROR: " + countTries + " attempts to stop moving and failed; character Feared?");
            }
        }

        /*
         * Only issues the Stop moving command if currently moving.  also
         * accounts for any lag which prevents immediate stop
         */

        private void Safe_Dismount()
        {
            if (!_me.Mounted)
                return;

            int countTries = 0;
            var stopTimer = new Stopwatch();

            stopTimer.Start();
            while (_me.Mounted && stopTimer.ElapsedMilliseconds < 1500)
            {
                countTries++;
                Mount.Dismount();
                Thread.Sleep(100);
            }


            if (_me.Mounted)
            {
                Slog("LAG!! still mounted after {0} dismount attempts - timed out after {1} ms", countTries,
                     stopTimer.ElapsedMilliseconds);
            }
            else if (countTries > 1)
            {
                Dlog("Dismount needed {0} attempts - took {1} ms", countTries, stopTimer.ElapsedMilliseconds);
            }
        }

        /*
         * Only issues the Stop moving command if currently moving.  also
         * accounts for any lag which prevents immediate stop
         */

        private void Safe_SetCurrentTarget(WoWUnit target)
        {
            var stopTimer = new Stopwatch();

            stopTimer.Start();
            if (target == null)
                _me.ClearTarget();
            else
                target.Target();

            while (_me.CurrentTarget != target && stopTimer.ElapsedMilliseconds < 2000)
            {
                Thread.Sleep(60);
            }

            if (_me.Dead)
                ;
            else if (_me.CurrentTarget != target)
            {
                Dlog(
                    "Timeout:  must have died, game state change, or serious lag - .CurrentTarget not updated after {0} ms",
                    stopTimer.ElapsedMilliseconds);
            }
            else
            {
                Dlog("Safe_SetCurrentTarget() took {0} ms to update .CurrentTarget", stopTimer.ElapsedMilliseconds);
            }
        }


        private void MoveToAttackMelee()
        {
            if (_cfg.DisableMovement)
                return;

            Dlog("running to point {0:F2} yds of mob {1:F2} yds away", _distForMeleePull, _me.CurrentTarget.Distance);
            WoWPoint newPoint = WoWMovement.CalculatePointFrom(_me.CurrentTarget.Location, (float) _distForMeleePull);
            Navigator.MoveTo(newPoint); // WoWMovement.ClickToMove(newPoint);
        }

        private void MoveToAttackRanged()
        {
            if (_cfg.DisableMovement)
                return;

            Dlog("running to point {0:F2} yds of mob {1:F2} yds away", _distForRangedPull, _me.CurrentTarget.Distance);
            WoWPoint newPoint = WoWMovement.CalculatePointFrom(_me.CurrentTarget.Location, (float) _distForRangedPull);
            Navigator.MoveTo(newPoint); // WoWMovement.ClickToMove(newPoint);
        }

        private bool FindBestTarget()
        {
            return FindBestTarget(_maxDistForRangeAttack);
        }

        private bool FindBestMeleeTarget()
        {
            return FindBestTarget(_maxDistForMeleeAttack);
        }

        private bool FindBestTarget(double withinDist)
        {
            // find mobs in melee distance
            List<WoWUnit> mobs;

            if (!_pvp.IsBattleground())
            {
                mobs = (from o in ObjectManager.ObjectList
                        where o is WoWUnit && o.Distance <= withinDist
                        let unit = o.ToUnit()
                        where unit.Attackable
                              && unit.IsAlive
                              && unit.Combat
                              && !IsMeOrMyStuff(unit)
                              && (IsTargetingMeOrMyStuff(unit) || unit.CreatureType == WoWCreatureType.Totem)
                              && !Blacklist.Contains(unit.Guid)
                        orderby unit.CurrentHealth ascending
                        select unit
                       ).ToList();
            }
            else
            {
                mobs = (from o in ObjectManager.ObjectList
                        where o is WoWUnit && o.Distance <= withinDist
                        let unit = o.ToUnit()
                        where !unit.Dead && unit.IsPlayer && unit.ToPlayer().IsHorde != ObjectManager.Me.IsHorde
                              && unit.InLineOfSight && !unit.IsPet
                              && !Blacklist.Contains(unit.Guid)
                        orderby unit.CurrentHealth ascending
                        select unit
                       ).ToList();
            }

            if (mobs != null && mobs.Count > 0)
            {
                WoWUnit newTarget = mobs[0];

                if (newTarget != null && (!_me.GotTarget || newTarget.Guid != _me.CurrentTarget.Guid))
                {
                    Slog(">>> NEW TARGET:  {0}-{1}[{2}]",
                         newTarget.Class,
                         Safe_UnitName(newTarget),
                         newTarget.Level
                        );
                    Safe_SetCurrentTarget(newTarget);
                    return true;
                }
            }

            return false;
        }

        // compares targets to find one with the lowest health (not lowest % of health)
        // .. to hopefully score a quick kill
        private class HealthSorter : IComparer<WoWUnit>
        {
            public int Compare(WoWUnit obj1, WoWUnit obj2)
            {
                return obj1.CurrentHealth.CompareTo(obj2.CurrentHealth);
            }
        }

        private void CastFakeSpell()
        {
            if (MeSilenced())
                return;

            WoWSpell spell = SpellManager.KnownSpells["Healing Wave"];
            if (_me.GetCurrentPower(spell.PowerType) <= spell.PowerCost)
            {
                return;
            }

            while (true)
            {
                if (spell.Cooldown || Safe_GlobalCooldown() || false == SpellManager.CanCastSpell(spell.Name))
                {
                    Dlog("Fake cast not ready... Checking for adds while waiting...");
                    CheckForAdds();
                    continue;
                }

                try
                {
                    spell.Cast();
                }
                catch (ThreadAbortException)
                {
                    throw;
                }
                catch (Exception e)
                {
                    Logging.WriteDebug("Exception when casting Fake Healing Wave");
                    Logging.WriteException(e);
                    return;
                }

                Slog("Cast fake Healing Wave...");
                Thread.Sleep(500);
                if (!_me.IsCasting)
                    Slog("Fake cast was interrupted/stolen ... ugghhhh");
                else
                {
                    SpellManager.StopCasting();
                    Slog("... canceled fake cast");
                }

                break;
            }

            return;
        }

        #endregion

        /*
         * Summary:  returns 'true' if should attempt to heal group members, 'false' if dps only
         */

        private static bool IsRAF()
        {
            return !Battlegrounds.IsInsideBattleground && ObjectManager.Me.PartyMember1 != null;
        }

        private bool IsHealer()
        {
            if (_typeShaman == ShamanType.Resto)
                return true;
            if (_pvp.IsBattleground())
                return _cfg.PVP_Healer();
            return IsRAF() && _cfg.RAF_Healer();
        }

        private bool IsHealerOverCombat()
        {
            if (_typeShaman == ShamanType.Resto)
                return true;

            if (_pvp.IsBattleground())
                return _cfg.PVP_CombatStyle == ConfigValues.PvpCombatStyle.HealingOverCombat;
                    // || _cfg.PVP_CombatStyle == ConfigValues.PvpCombatStyle.HealingOnly;

            return IsRAF() &&
                   (_cfg.RAF_CombatStyle == ConfigValues.RafCombatStyle.HealingOverCombat ||
                    _cfg.RAF_CombatStyle == ConfigValues.RafCombatStyle.HealingOnly);
        }

        private bool IsHealerOnly()
        {
            /*
                        if (_pvp.IsBattleground())
                            return _cfg.PVP_CombatStyle == ConfigValues.PvpCombatStyle.HealingOnly ;
             */
            return _cfg.RAF_CombatStyle == ConfigValues.RafCombatStyle.HealingOnly && IsRAF();
        }

        private static bool IsMeOrMyStuff(WoWUnit unit)
        {
            if (unit == null)
                return false;

            if (unit.IsMe)
                return true;

            // check if this unit was created by me
            return IsMeOrMyStuff(ObjectManager.GetObjectByGuid<WoWUnit>(unit.CreatedByGuid));
        }

        private static bool IsTargetingMeOrMyStuff(WoWUnit unit)
        {
            return unit != null && IsMeOrMyStuff(unit.CurrentTarget);
        }

        private bool IsImmunneToNature(WoWUnit unit)
        {
            return Safe_IsValid(unit) && 0 != _listNatureImmune.Find(id => id == unit.Entry);
        }

        private bool IsImmunneToFire(WoWUnit unit)
        {
            return Safe_IsValid(unit) && 0 != _listFireImmune.Find(id => id == unit.Entry);
        }

        private bool IsImmunneToFrost(WoWUnit unit)
        {
            return Safe_IsValid(unit) && 0 != _listFrostImmune.Find(id => id == unit.Entry);
        }

        /*
         * Reports whether we to stop for any Weapon Buffs
         */

        private bool IsWeaponEnhanceNeeded(out bool needMainhand, out bool needOffhand)
        {
            needMainhand = false;
            needOffhand = false;

            // now make sure we have a mainhand weapon
            if (_me.Mainhand == null)
            {
                return false;
            }

         

            // see if we trained any weapon enchants yet... if not then don't need to imbue weapon
            string enchantMainhand;
            string enchantOffhand;
            GetBestWeaponEnchants(out enchantMainhand, out enchantOffhand);

            if (enchantMainhand == null)
                return false;

            // get the enchant info from LUA
            List<string> weaponEnchants = CallLUA("return GetWeaponEnchantInfo()");

            if (Equals(null, weaponEnchants))
                return false;

            needMainhand = weaponEnchants[0] == "" || weaponEnchants[0] == "nil";
            if (IsOffhandWeapon())
                needOffhand = weaponEnchants[3] == "" || weaponEnchants[3] == "nil";

            if (needMainhand)
                Dlog("Mainhand weapon {0} needs enhancement", _me.Mainhand == null ? "(none)" : _me.Mainhand.Name);

            if (needOffhand)
                Dlog("Offhand  weapon {0} needs enhancement", _me.Offhand == null ? "(none)" : _me.Offhand.Name);

            return needMainhand || needOffhand;
        }

        private void GetBestWeaponEnchants(out string enchantMainhand, out string enchantOffhand)
        {
            List<string> listMainhand = null;
            List<string> listOffhand = null;

            enchantMainhand = "";
            enchantOffhand = "";

            if (_pvp.IsBattleground())
            {
                enchantMainhand = _cfg.PVP_MainhandEnchant;
                enchantOffhand = _cfg.PVP_OffhandEnchant;
            }
            else
            {
                enchantMainhand = _cfg.PVE_MainhandEnchant;
                enchantOffhand = _cfg.PVE_OffhandEnchant;
            }

            // Dlog("gbwe1 --  mh:{0},  oh:{1}", enchantMainhand, enchantOffhand);
            switch (_typeShaman)
            {
                case ShamanType.Elemental:
                    // Dlog("Enchant - choosing Elemental Defaults for Auto");
                    listMainhand = _enchantElemental;
                    listOffhand = listMainhand;
                    break;
                case ShamanType.Resto:
                    // Dlog("Enchant - choosing Restoration Defaults for Auto");
                    listMainhand = _enchantResto;
                    listOffhand = _enchantResto;
                    break;
                case ShamanType.Enhance:
                    if (_pvp.IsBattleground())
                    {
                        // Dlog("Enchant - choosing PVP Enhancement Defaults for Auto");
                        listMainhand = _enchantEnhancementPVP;
                        listOffhand = _enchantEnhancementPVP;
                    }
                    else
                    {
                        // Dlog("Enchant - choosing PVE Enhancement Defaults for Auto");
                        listMainhand = _enchantEnhancementPVE_Mainhand;
                        listOffhand = _enchantEnhancementPVE_Offhand;
                    }
                    break;
            }

            // Dlog("gbwe2 --  mh:{0},  oh:{1}", enchantMainhand, enchantOffhand);

            if ('A' == enchantMainhand.ToUpper()[0])
            {
                enchantMainhand = listMainhand.Find(spellname => Safe_KnownSpell(spellname));
                //Dlog("Enchant - Mainhand:  configured for AUTO so choosing '{0}'", enchantMainhand);
            }
            else
            {
                //Dlog("Enchant - Mainhand:  configured for '{0}'", enchantMainhand);
            }

            if ('A' == enchantOffhand.ToUpper()[0])
            {
                enchantOffhand = listOffhand.Find(spellname => Safe_KnownSpell(spellname));
                //Dlog("Enchant - Offhand:   configured for AUTO so choosing '{0}'", enchantOffhand);
            }
            else
            {
                //Dlog("Enchant - Offhand:   configured for '{0}'", enchantOffhand);
            }

            return;
        }

        private string GetFirstKnownSpell(List<string> lst)
        {
            return lst.Find(spell => Safe_KnownSpell(spell));
        }

        /*
         * Checks to see if Off Hand slot currently has a weapon in it.
         * Uses a timer so that LUA call is not made more than once a minute
         */
        private Stopwatch _offhandCheck = new Stopwatch();
        private bool _offhandLastResult;

        private bool IsOffhandWeapon()
        {
            if (_me.Offhand == null)
                _offhandLastResult = false;
            else if (!Safe_KnownSpell("Dual Wield"))
                _offhandLastResult = false;
#if true
            else
            {
                List<string> offhandWeapons = CallLUA("return OffhandHasWeapon()");
                if (Equals(null, offhandWeapons))
                    return false;

                string isOffhandWeapon = offhandWeapons[0];
                // Dlog("return from OffhandHasWeapon() = '" + isOffhandWeapon + "'");
                if (isOffhandWeapon == null || isOffhandWeapon == "" || isOffhandWeapon == "nil")
                    _offhandLastResult = false;
                else
                    _offhandLastResult = true;
            }
#else
            else if (_offhandCheck.ElapsedMilliseconds == 0)
            {
                List<string> offhandWeapons = CallLUA("return OffhandHasWeapon()");

                if (Equals(null, offhandWeapons))
                    return false;

                string isOffhandWeapon = offhandWeapons[0];

                Dlog("return from OffhandHasWeapon() = '" + isOffhandWeapon + "'");

                if (isOffhandWeapon == null || isOffhandWeapon == "" || isOffhandWeapon == "nil")
                    _offhandLastResult = false;
                else
                    _offhandLastResult = true;

                _offhandCheck.Start();
            }
            else if (_offhandCheck.ElapsedMilliseconds > 60000)
            {
                _offhandCheck.Reset();
            }
#endif

            return _offhandLastResult;
        }

        private bool IsBuffPresent(string sBuff)
        {
            int stackCount;
            return IsBuffPresent(sBuff, out stackCount);
        }

        private bool IsBuffPresent(string sBuff, out int stackCount)
        {
            stackCount = 0;
            List<string> myBuffs = CallLUA("return UnitBuff(\"player\",\"" + sBuff + "\")");
            if (Equals(null, myBuffs))
                return false;

            string buffName = myBuffs[0];
            stackCount = Convert.ToInt32(myBuffs[3]);
            return true;
        }

        /*
         * CastBuff
         *      sBuff - name of buff as appears in buff/debuff list
         *      sSpell - name of spell that causes buff
         * 
         * Totems in particular have a different name than the buff they cast.
         * The name of the totem is passed as the "spell" and the name of the
         * buff it creates is passed separately
         */

        private bool CastBuff(string sSpell)
        {
            return CastBuff(sSpell, sSpell);
        }

        private bool CastBuff(string sSpell, string sBuff)
        {
            if (!Safe_KnownSpell(sSpell))
            {
                Dlog("attempt to cast unknown spell: " + sSpell);
                return false;
            }

            if (!Safe_AreSpellReagentsAvailable(sSpell))
            {
                Wlog("missing reagents needed to cast spell: " + sSpell);
                return false;
            }

            if (_me.Buffs.ContainsKey(sBuff))
            {
                // Dlog("buff already active: " + sBuff);
                return true;
            }

            return Safe_CastSpell(sSpell);
        }


        private bool HaveValidTarget()
        {
            return _me.GotTarget && _me.CurrentTarget.IsAlive;
            //                && !Styx.Logic.Blacklist.Contains( t.Guid );
        }

        /*
         * CurrentTargetInMeleeDistance()
         * 
         * Check to see if CurrentTarget is within melee range.  This allows
         * recognizing when a pulled mob is close enough to melee as well as 
         * as when a pulled mob moves out of melee
         */

        private bool CurrentTargetInMeleeDistance()
        {
            if (_me.Location.Distance(_me.CurrentTarget.Location) < 5.0)
                return true;

            return false;
        }

        /*
         * CurrentTargetInRangedDistance()
         * 
         * Check to see if CurrentTarget is within melee range.  This allows
         * recognizing when a pulled mob is close enough to melee as well as 
         * as when a pulled mob moves out of melee
         */

        private bool CurrentTargetInRangedDistance()
        {
            if (Safe_IsValid(_me.CurrentTarget) && _me.CurrentTarget.Distance < _maxDistForRangeAttack)
                return true;

            return false;
        }

        /*
         * trys to determine if 'unit' points to a mob that is a Caster.  Currently
         * only see .Class as being able to help determine.  the big question marks
         * are Druids and Shamans for grinding purposes, so even though we try
         * to guess we still make routines able to adapt on pulls, etc. to fact
         * mob may not behave like we guessed
         */

        private bool IsCaster(WoWUnit unit)
        {
            bool isCaster = false;

            switch (unit.Class.ToString().ToLower())
            {
                default:
                    Slog("UKNOWN MOB CLASS:  CONTACT CC DEVELOPER:  Please provide the class name '" + unit.Class +
                         "' and name [" + Safe_UnitName(unit) + "]");
                    break;

                case "paladin":
                case "druid":
                case "rogue":
                case "warrior":
                case "death knight":
                    break;

                case "mage":
                case "warlock":
                case "shaman":
                case "priest":
                    isCaster = true;
                    break;
            }

            // following test added because of "Unyielding Sorcerer" in Hellfire
            // .. having a class of Paladin, yet they fight as ranged casters

            if (!isCaster)
            {
                if (unit.Name.ToLower().Contains("sorcerer"))
                    isCaster = true;
                else if (unit.Name.ToLower().Contains("shaman"))
                    isCaster = true;
                else if (unit.Name.ToLower().Contains("mage"))
                    isCaster = true;
                else if (unit.Name.ToLower().Contains("warlock"))
                    isCaster = true;
                else if (unit.Name.ToLower().Contains("priest"))
                    isCaster = true;
                else if (unit.Name.ToLower().Contains("wizard"))
                    isCaster = true;
                else if (unit.Name.ToLower().Contains("adept"))
                    isCaster = true;
            }

            return isCaster;
        }

        private void AddToBlacklist(ulong guidMob)
        {
            if (Blacklist.Contains(guidMob))
                Dlog("already blacklisted mob: " + guidMob);
            else
            {
                Blacklist.Add(guidMob, TimeSpan.FromHours(24));
                Dlog("blacklisted mob: " + guidMob);
            }
        }

        /*
         * CheckForItem()
         * 
         * Lookup an item by its item # 
         * return null if not found
         */

        private WoWItem CheckForItem(List<uint> listId)
        {
            WoWItem item = ObjectManager.GetObjectsOfType<WoWItem>(false).Find(unit => listId.Contains(unit.Entry));
            return item;
        }

        #endregion

        #region REST

        public override bool NeedRest
        {
            get
            {
                bool doWeNeedRest = false;
                try
                {
                    doWeNeedRest = NeedRestLogic();
                }
                catch (ThreadAbortException)
                {
                    throw;
                }
                catch (Exception e)
                {
                    Logging.WriteDebug("HB EXCEPTION in NeedRest");
                    Logging.WriteException(e);
                }

                return doWeNeedRest;
            }
        }

        private bool NeedRestLogic()
        {
            ReportBodyCount();

            if (Battlegrounds.Finished)
                return false;

            if (MeImmobilized())
                return false;

            if (_me.Combat)
            {
                Slog("ALARM:  Invoking Combat() from NeedRest");
                Combat();
                return false;
            }

            // if we switched modes ( grouped, battleground, or spec chg)
            if (DidWeSwitchModes())
            {
                _needClearWeaponEnchants = true;
                _needTotemBarSetup = true;
                return true;
            }

            if (IsHealer())
            {
                if (HealRaid())
                {
                    return false;
                }
            }

            if (_pvp.IsBattleground())
            {
                if (_me.GotTarget && _me.CurrentTarget.IsPlayer && _me.CurrentTarget.ToPlayer().IsHorde != _me.IsHorde &&
                    _me.CurrentTarget.Distance < _maxDistForRangeAttack && !_me.CurrentTarget.Mounted)
                {
                    Slog("BGCHK:  calling Combat() myself from NeedRest for CurrentTarget");
                    Combat();
                    return false;
                }

                if (FindBestTarget())
                {
                    Slog("BGCHK:  calling Pull() myself from NeedRest for FindBestTarget()");
                    Pull();
                    return false;
                }
            }

            // check to be sure not in a travelling state before
            //.. setting switches that will cause a dismount or form change
            if (_me.Mounted && InGhostwolfForm())
            {
                Dlog("Mounted or Ghostwolf - will wait to buff/enchant out of form");
            }
            else
            {
                if (_WereTotemsSet && CheckForSafeDistance(_ptTotems, CheckDistanceForRecall()))
                {
                    Dlog("Need rest: TotemsWereSet() and CheckForSafeDistance({0:F1})= true", CheckDistanceForRecall());
                    _RecallTotems = true;
                    return true;
                }

                if (IsWeaponEnhanceNeeded(out _castMainHandEnchant, out _castOffHandEnchant))
                {
                    Dlog("Need rest: true, IsWeaponEnhanceNeeded mh:{0} oh:{1}", _castMainHandEnchant,
                         _castOffHandEnchant);
                    return true;
                }

                if (ShieldBuffNeeded(true))
                {
                    Dlog("Need rest: true, ShieldBuffNeeded");
                    return true;
                }
            }

            if (IsCleanseNeeded())
            {
                Dlog("Need rest: true, IsCleanseNeeded");
                _castCleanse = true;
                return true;
            }

            if (_me.HealthPercent <= _cfg.RestHealthPercent && !_me.IsSwimming)
            {
                Dlog("Need rest: true, CurrentHealth {0:F1}% less than RestHealthPercent {1:F1}%", _me.HealthPercent,
                     _cfg.RestHealthPercent);
                return true;
            }

            if (_me.ManaPercent <= _cfg.RestManaPercent && !_me.IsSwimming && !Styx.Logic.Common.Rest.NoDrink)
            {
                Dlog("Need rest: true, CurrentMana {0:F1}% less than RestManaPercent {1:F1}%", _me.ManaPercent,
                     _cfg.RestManaPercent);
                return true;
            }

            if (LevelbotSettings.Instance.UseMount && _cfg.UseGhostWolfForm)
            {
                Wlog(
                    "warning:  UseMount takes precedence over UseGhostWolf:  the Ghost Wolf setting ignored this session");
            }
            else if (!_me.Mounted && _cfg.UseGhostWolfForm)
            {
                if (Safe_KnownSpell("Ghost Wolf") && !InGhostwolfForm() && _me.IsOutdoors)
                {
                    if (CheckForSafeDistance(_me.Location, _cfg.DistanceForGhostWolf))
                    {
                        Dlog("Need rest: true, Ghost Wolf: closest enemy at least {0:F1} yds away",
                             _cfg.DistanceForGhostWolf);
                        if (SpellManager.CanCastSpell("Ghost Wolf")) // make sure we can so not stuck in loop
                            _castGhostWolfForm = true;
                        return true;
                    }
                }
            }

            return false;
        }

        // bool inRest = false;
        public override void Rest()
        {
            try
            {
                Dlog("RESTING START: " + _me.HealthPercent + "% health,  " + _me.ManaPercent + "% mana");
                RestLogic();
                Dlog("RESTING ENDED: " + _me.HealthPercent + "% health,  " + _me.ManaPercent + "% mana");
            }
            catch (ThreadAbortException)
            {
                throw;
            }
            catch (Exception e)
            {
                Logging.WriteDebug(">>> EXCEPTION: occurred in Rest()");
                Logging.WriteException(e);
            }
        }

        public void RestLogic()
        {
            ShowCurrentStatus();

            if (_castCleanse)
            {
                _castCleanse = !Cleanse();
                if (!_castCleanse)
                    return;
            }

            if (_RecallTotems)
            {
                _RecallTotems = false;
                RecallTotemsForMana();
                return;
            }

            // try to use bandages if requested
            if (_me.HealthPercent < _cfg.RestHealthPercent && _me.ManaPercent > _cfg.RestManaPercent)
            {
                if (_cfg.UseBandages)
                {
                    if (UseBandageIfAvailable())
                        return;
                }
            }

            // try to heal several times (quicker than eating)
            if (_me.HealthPercent < _cfg.RestHealthPercent && _me.ManaPercent > _cfg.RestManaPercent)
            {
                CheckForAdds();
                if (HealMyself())
                    return;
            }

            if (_needClearWeaponEnchants)
            {
                DidWeSwitchModes(); // make sure state saved for this test
                _needClearWeaponEnchants = false;

                RunLUA("CancelItemTempEnchantment(1)");
                RunLUA("CancelItemTempEnchantment(2)");
                return;
            }

            if (_needTotemBarSetup)
            {
                _needTotemBarSetup = false;
                TotemSetupBar();
            }

            ShamanBuffs(true);

            if (_castGhostWolfForm && SpellManager.CanCastSpell("Ghost Wolf"))
            {
                GhostWolf();
                _castGhostWolfForm = false;
            }

            // now eat/drink if needed
            if ((_me.HealthPercent < _cfg.RestHealthPercent || _me.ManaPercent < _cfg.RestManaPercent) &&
                !_me.IsSwimming)
            {
                bool stoppedToEat = _me.HealthPercent < _cfg.RestHealthPercent;
                bool stoppedToDrink = _me.ManaPercent < _cfg.RestManaPercent;

                WaitForCurrentSpell();
                if (stoppedToEat && Styx.Logic.Common.Rest.NoFood)
                    ;
                else if (stoppedToDrink && Styx.Logic.Common.Rest.NoDrink)
                    ;
                else
                {
                    Slog("Sitting down to {0}{1}{2}",
                         stoppedToEat ? "Eat" : "",
                         stoppedToEat && stoppedToDrink ? " and " : "",
                         stoppedToDrink ? "Drink" : ""
                        );
                }

                Styx.Logic.Common.Rest.Feed();
                if (stoppedToEat)
                {
                    if (Styx.Logic.Common.Rest.NoFood)
                        Wlog("No food in bags -- unable to eat");
                    else
                    {
                        _countFood++;
                        Dlog("Eating:  {0} total used, average {1:F0} per hour",
                             _countFood,
                             (60.0*60.0*1000.0*_countFood)/(Environment.TickCount - _tickStart)
                            );
                    }
                }
                if (stoppedToDrink)
                {
                    if (Styx.Logic.Common.Rest.NoDrink)
                        Wlog("No drinks in bags -- unable to drink");
                    else
                    {
                        _countDrinks++;
                        Dlog("Drinking: {0} total used, average {1:F0} per hour",
                             _countDrinks,
                             (60.0*60.0*1000.0*_countDrinks)/(Environment.TickCount - _tickStart)
                            );
                    }
                }
            }
        }

        private bool InGhostwolfForm()
        {
            return _me.Buffs.ContainsKey("Ghost Wolf");
        }

        private bool GhostWolf()
        {
            bool b = false;

            if (!_me.IsOutdoors || _me.IsIndoors)
                ;
            else if (!Safe_KnownSpell("Ghost Wolf"))
                ;
            else
            {
                var tg = new TalentGroup();
                int impGW = tg.GetTalentInfo(2, 6); // "Improved Ghost Wolf"
                if (impGW != 2)
                {
                    Safe_StopMoving();
                    Thread.Sleep(100);
                }
                b = Safe_CastSpell("Ghost Wolf", SpellRange.NoCheck, SpellWait.Complete);
            }

            return b;
        }

        #endregion

        #region HANDLE FALLING

        public void HandleFalling()
        {
        }

        #endregion

        #region Buffs

        /*
         * Note:  the following are interface functions that need to be implemented by the class.  
         * They are not used presently in the ShamWOW implementation.  Buffs are handled within the 
         * flow of the current Pull() and Combat() event handlers
         */

        public override bool NeedPreCombatBuffs
        {
            get { return false; }
        }

        public override void PreCombatBuff()
        {
        }

        public override bool NeedPullBuffs
        {
            get { return false; }
        }

        public override void PullBuff()
        {
        }

        public override bool NeedCombatBuffs
        {
            get { return false; }
        }

        public override void CombatBuff()
        {
        }


        public void ShamanBuffs(bool atRest)
        {
            var timer = new Stopwatch();

            if (!_me.IsAlive)
                return;

            // Shield Twisting:  Cast based upon amount of Mana available
            ShieldTwisting(atRest);

            Dlog("ShamanBuffs:  AllowNonHealSpells:{0}, atrest:{1}", AllowNonHealSpells(), atRest);
            //            if (AllowNonHealSpells() && atRest != false)
            if (atRest)
            {
                string enchantMainhand;
                string enchantOffhand;
                bool checkErrMain = false;
                bool checkErrOff = false;

                try
                {
                    GetBestWeaponEnchants(out enchantMainhand, out enchantOffhand);
                    Dlog("Weapon Enchant Check:  NeedOnMainhand={0}{1}, NeedOnOffhand={2}{3}", _castMainHandEnchant,
                         !_castMainHandEnchant ? "" : "-" + enchantMainhand, _castOffHandEnchant,
                         !_castOffHandEnchant ? "" : "-" + enchantOffhand);

                    if (_castMainHandEnchant)
                    {
                        while (!Safe_CastSpell(enchantMainhand, SpellRange.NoCheck, SpellWait.Complete))
                            ;

                        timer.Reset();
                        timer.Start();
                        do
                        {
                            IsWeaponEnhanceNeeded(out checkErrMain, out checkErrOff);
                            Thread.Sleep(100);
                        } while (checkErrMain && timer.ElapsedMilliseconds < 1000);

                        if (checkErrMain)
                        {
                            Dlog("failed to apply mainhand weapon enhancement - will reassess need for enchants again");
                            _castMainHandEnchant = false;
                            _castOffHandEnchant = false;
                        }
                    }

                    if (_castOffHandEnchant)
                    {
                        Safe_CastSpell(enchantOffhand, SpellRange.NoCheck, SpellWait.Complete);
                        Thread.Sleep(atRest ? 651 : 285);
                        _castOffHandEnchant = false;
                    }
                }
                catch (ThreadAbortException)
                {
                    throw;
                }
                catch (Exception e)
                {
                    Logging.WriteDebug("HB EXCEPTION in ShamanBuffs()");
                    Logging.WriteException(e);
                }
            }
        }

        #endregion

        #region Heal

        /*
         * NeedHeal
         * 
         * return a true/false indicating whether the Heal() event handler should be called by the
         * HonorBuddy engine.
         */

        public override bool NeedHeal
        {
            get
            {
                double threshhold = _cfg.NeedHealHealthPercent + (countEnemy >= _cfg.PVE_StressfulMobCount ? 10 : 0);

                if (_me.HealthPercent <= threshhold
                    && _me.GotTarget
                    && countEnemy == 1
                    && !IsFightStressful()
                    && (_typeShaman != ShamanType.Enhance || _countMeleeEnemy == 1)
                    && AllowNonHealSpells()
                    && _me.CurrentTarget.HealthPercent < 10.0
                    && _me.CurrentTarget.IsAlive
                    )
                {
                    Slog("^Enemy weak at {0:F0}%, skipping heal", _me.CurrentTarget.HealthPercent);
                    return false;
                }

                return !MeSilenced() && _me.HealthPercent <= threshhold;
            }
        }

        /*
         * Heal()
         * 
         * Called if a heal is needed.
         */

        public override void Heal()
        {
            Dlog("HEAL Enter");
            ShowCurrentStatus();
            HealMyself();
            Dlog("HEAL Exit");
        }

        private bool HealMyself()
        {
            bool healCast = false;

            var lagTimer = new Stopwatch();
            double startHealth = _me.HealthPercent;
            double startMana = _me.ManaPercent;

            // use safety heals if health is critical and in combat or being targeted by hostiles
            if ((_me.Combat || countEnemy > 0))
            {
                if (_me.HealthPercent < _cfg.LifebloodPercent)
                {
                    healCast = GiftOfTheNaaru();
                    if (!healCast)
                        healCast = Lifeblood();
                }

                if (_me.ManaPercent < _cfg.EmergencyManaPercent && _me.HealthPercent > _cfg.NeedHealHealthPercent)
                    UseManaPotionIfAvailable();

                if (_me.HealthPercent < _cfg.EmergencyHealthPercent)
                    UseHealthPotionIfAvailable();
            }

            // use warstomp here if we need to heal and have more than 1 melee enemy
            if (_countMeleeEnemy > 0)
                Warstomp();

            healCast = HealPlayer(null);

            if (!healCast)
            {
                Slog("Casting of heal prevented: Health={0:F0}% Mana={1:F0}%", _me.HealthPercent, _me.ManaPercent);
            }
            else
            {
                Dlog("^Heal begun @ health:{0:F2}% mana:{1:F2}%", startHealth, startMana);
                // wait for lagged update of health % if it isn't pvp
                if (!_pvp.IsBattleground() || _me.HealthPercent > 60)
                {
                    // DEAL WITH Health% UPDATE LAG ---
                    // .. Make sure before we leave here that if a heal was 
                    // .. cast, the .HealthPercent value has been updated
                    // .. so rest of code can make informed decisions
                    lagTimer.Start();
                    while (lagTimer.ElapsedMilliseconds < 1000 && Math.Abs(_me.HealthPercent - startHealth) < 7)
                    {
                        Thread.Sleep(100);
                    }

                    Dlog("^Heal ended @ health:{0:F2}% mana:{1:F2}% mana - took {2} ms for char to update",
                         _me.HealthPercent, _me.ManaPercent, lagTimer.ElapsedMilliseconds);
                }
            }

            return healCast;
        }

        private bool AllowNonHealSpells()
        {
            return _me.ManaPercent > _cfg.EmergencyManaPercent && _me.HealthPercent > _cfg.EmergencyHealthPercent;
        }


        /*
         * IsCleanseNeeded()
         * 
         * Called cleanse if needed.
         */

        public bool IsCleanseNeeded()
        {
            bool knowCureToxin = Safe_KnownSpell("Cure Toxins");
            bool knowCleansingTotem = Safe_KnownSpell("Cleansing Totem") && _me.Combat;
            bool knowCleanseSpirit = Safe_KnownSpell("Cleanse Spirit");

            bool canCleanPoison = knowCureToxin || knowCleansingTotem || knowCleanseSpirit;
            bool canCleanDisease = knowCleansingTotem || knowCleanseSpirit;
            bool canCleanCurse = knowCleansingTotem || knowCleanseSpirit;

            if (TotemExist(TOTEM_WATER) && _totemName[TOTEM_WATER] == "Cleansing Totem")
                return false;

            foreach (var dbf in _me.Debuffs)
            {
                if (dbf.Value.Spell.DispelType == WoWDispelType.Poison && canCleanPoison)
                    ;
                else if (dbf.Value.Spell.DispelType == WoWDispelType.Disease && canCleanDisease)
                    ;
                else if (dbf.Value.Spell.DispelType == WoWDispelType.Curse && canCleanCurse)
                    ;
                else
                {
                    Dlog("Non-dispellable Debuff: {0}-{1}", dbf.Value.Spell.DispelType, dbf.Value.Name);
                    continue;
                }

                Slog("Dispellable Debuff: {0}-{1}", dbf.Value.Spell.DispelType, dbf.Value.Name);
                return true;
            }

            return false;
        }

        public bool Cleanse()
        {
            bool castSpell = false;
            if (IsCleanseNeeded())
            {
                if (_me.Combat && Safe_KnownSpell("Cleansing Totem"))
                {
                    if (TotemExist(TOTEM_WATER) && _totemName[TOTEM_WATER] == "Cleansing Totem")
                        return true;

                    castSpell = Safe_CastSpell("Cleansing Totem");
                }

                if (!castSpell)
                {
                    if (Safe_KnownSpell("Cleanse Spirit"))
                        castSpell = Safe_CastSpell("Cleanse Spirit");
                    else if (Safe_KnownSpell("Cure Toxins"))
                        castSpell = Safe_CastSpell("Cure Toxins");
                    else if (Safe_KnownSpell("Cleansing Totem"))
                    {
                        if (TotemExist(TOTEM_WATER) && _totemName[TOTEM_WATER] == "Cleansing Totem")
                            return true;

                        castSpell = Safe_CastSpell("Cleansing Totem");
                    }
                }
            }

            if (castSpell)
                Thread.Sleep(201);

            return castSpell;
        }

        #endregion

        #region Pull

        /*
         * Pull()
         * 
         * Currently always do a ranged pull from '_distForRangedPull' way
         * If HB has given us a mob to pull that is further away, we will
         * run towards him up to within '_distForRangedPull' 
         * 
         */

        public override void Pull()
        {
            Dlog("Entered Pull");
            PullLogic();
            Dlog("Exited Pull");
        }

        public void PullInitialize()
        {
            _pullTargGuid = _me.CurrentTarget.Guid;
            // _pullTargHasBeenInMelee = false;
            _pullAttackCount = 0;
            _pullStart = _me.Location;

            _pullTimer.Reset(); //  reset timer for new pull 
            _pullTimer.Start(); //  start timer ticking
        }

        public void PullLogic()
        {
            if (IsHealerOverCombat())
            {
                if (HealRaid())
                {
                    Dlog("Healed raid member -- exiting pull");
                    return;
                }

                if (IsHealerOnly())
                {
                    Dlog("Flagged as healer only -- exiting pull");
                    return;
                }
            }

            if (!_me.GotTarget)
            {
                Dlog("HB gave (null) pull target");
                return;
            }

            if (_me.CurrentTarget.IsPet)
            {
                var petOwner = ObjectManager.GetObjectByGuid<WoWUnit>(_me.CurrentTarget.Pet.CreatedByGuid);
                if (petOwner != null)
                {
                    Dlog("Changing target from pet {0} to owner {1}", _me.CurrentTarget.Name, petOwner.Name);
                    petOwner.Target();
                }
                else
                {
                    Dlog("Appears that pet {0} does not have an owner?  guess we'll fight a pet", _me.CurrentTarget.Name);
                }
            }

            if (!_me.CurrentTarget.IsAlive)
            {
                Dlog("HB gave a Dead pull target: " + Safe_UnitName(_me.CurrentTarget) + "[" + _me.CurrentTarget.Level +
                     "]");
                _me.ClearTarget();
                return;
            }

            if (_me.CurrentTarget.TaggedByOther && !IsTargetingMeOrMyStuff(_me.CurrentTarget))
            {
                Slog("Combat Target is tagged by another player -- let them have it");
                _me.ClearTarget();
                return;
            }

            if (Blacklist.Contains(_me.CurrentTargetGuid))
            {
                Slog("Skipping pull of blacklisted mob: " + Safe_UnitName(_me.CurrentTarget) + "[" +
                     _me.CurrentTarget.Level + "]");
                _me.ClearTarget();
                return;
            }

            if (_pvp.IsBattleground())
            {
                if (_me.GotTarget && _me.CurrentTarget.IsPlayer && _me.CurrentTarget.Mounted &&
                    _me.IsHorde != _me.CurrentTarget.ToPlayer().IsHorde)
                {
                    Slog("Skipping mounted player: " + Safe_UnitName(_me.CurrentTarget) + "[" + _me.CurrentTarget.Level +
                         "]");
                    Blacklist.Add(_me.CurrentTarget.Guid, TimeSpan.FromSeconds(2));
                    _me.ClearTarget();
                    return;
                }
            }

            CheckForAdds();

            // reset state values we use to determine what point we are at in 
            //  .. in transition from Pull() to Combat()
            //---------------------------------------------------------------------------
            if (_pullTargGuid != _me.CurrentTarget.Guid)
            {
                PullInitialize();
                Slog(">>> PULL: " + (_me.CurrentTarget.Elite ? "[ELITE] " : "") + _me.CurrentTarget.Class + "-" +
                     Safe_UnitName(_me.CurrentTarget) + "[" + _me.CurrentTarget.Level + "] at " +
                     _me.CurrentTarget.Distance.ToString("F1") + " yds");
                Dlog("pull started at {0}% health, {1}% mana", _me.HealthPercent, _me.ManaPercent);
            }

            if (_pvp.IsBattleground() || _cfg.DisableMovement) // never timeout in PVP or when disable movement set
                ;
            else if (_pullTimer.ElapsedMilliseconds > ConfigValues.PullTimeout &&
                     !(_me.CurrentTarget.TaggedByMe || IsTargetingMeOrMyStuff(_me.CurrentTarget)))
            {
                Blacklist.Add(_me.CurrentTarget.Guid, TimeSpan.FromSeconds(30));
                Slog("Pull TIMED OUT for: " + _me.CurrentTarget.Class + "-" + Safe_UnitName(_me.CurrentTarget) + "[" +
                     _me.CurrentTarget.Level + "] after " + _pullTimer.ElapsedMilliseconds +
                     " ms -- blacklisted for 30 secs");
                _me.ClearTarget();
                return;
            }

            if (!WoWMovement.IsFacing)
            {
                WoWMovement.Face();
            }

            if (_typeShaman != ShamanType.Enhance)
                PullRanged();
            else if (_pvp.IsBattleground())
                PullFast();
            else
            {
                switch (_cfg.PVE_PullType)
                {
                    case ConfigValues.TypeOfPull.Auto:
                        PullAuto();
                        break;
                    case ConfigValues.TypeOfPull.Body:
                        PullBody();
                        break;
                    case ConfigValues.TypeOfPull.Fast:
                        PullFast();
                        break;
                    case ConfigValues.TypeOfPull.Ranged:
                        PullRanged();
                        break;
                }
            }


            Dlog("distance after pull: " + _me.CurrentTarget.Distance.ToString("F2"));
            // CheckForPlayers();
        }


        public void PullAuto()
        {
            Dlog("PullType Auto");
            if (IsCaster(_me.CurrentTarget))
                PullFast();
            else
                PullRanged();
        }

        public void PullBody()
        {
            Dlog("PullType Body");
            if (CurrentTargetInMeleeDistance())
                ShockOpener(false);
            else
                MoveToAttackMelee();
        }

        public void PullFast()
        {
            Dlog("PullType Fast");
            if (!CurrentTargetInMeleeDistance() && _pullTimer.ElapsedMilliseconds < ConfigValues.PullTimeout)
            {
                MoveToAttackMelee();
            }

            if (_me.CurrentTarget.Distance < 25)
            {
                ShockOpener(true);
            }

            if (_me.CurrentTarget.Distance < 8 && _me.Mounted)
            {
                Safe_Dismount();
            }
        }


        public void PullRanged()
        {
            Dlog("PullType Ranged");
            if (!CurrentTargetInRangedDistance())
            {
                MoveToAttackRanged();
                return;
            }

            if (_me.IsMoving)
                Safe_StopMoving();

            // set totems now for all specs except Enhancement (who does in Combat)
            if (_typeShaman != ShamanType.Enhance && !_pvp.IsBattleground())
            {
                SetTotemsAsNeeded();
            }

            if (_pullAttackCount > 0 && ShockOpener(false))
            {
                _pullAttackCount++;
            }
            else if (IsImmunneToNature(_me.CurrentTarget) && ShockOpener(false))
            {
                _pullAttackCount++;
            }
            else if (_typeShaman == ShamanType.Enhance && _me.CurrentTarget.Distance < 20 &&
                     IsTargetingMeOrMyStuff(_me.CurrentTarget) && ShockOpener(false))
            {
                _pullAttackCount++;
            }
            else if (LightningBolt())
            {
                _pullAttackCount++;
            }
        }

        #endregion

        #region Combat

        /*
         * Combat()
         * 
         */

        public override void Combat()
        {
            Dlog("Entered Combat");
            try
            {
                CombatLogic();
            }
            catch (ThreadAbortException)
            {
                throw;
            }
            catch (Exception e)
            {
                if (!_me.GotTarget)
                    Logging.WriteDebug("Exception:  referencing 'null' target: mob expired or out of range? no big deal");
                else
                    Logging.WriteDebug("EXCEPTION in Combat() - HonorBuddy API or CC Error");
                Logging.WriteException(e);
            }
            Dlog("Exiting Combat");
        }

        private void CombatLogic()
        {
            ShowCurrentStatus();
            // ListWowUnitsInRange();

            if (IsHealerOverCombat())
            {
                if (HealRaid())
                    return;

                if (IsHealerOnly())
                    return;
            }

            if (MeImmobilized())
            {
                // need to look at trinketting out here...
                // .. otherwise just return because we can't move and can't cast
                if (_typeShaman == ShamanType.Enhance && _me.GotAlivePet && SpellManager.CanCastSpell("Spirit Walk"))
                {
                    Log("^Pet Ability - Spirit Walk (remove movement impairing effects)");
                    Safe_CastSpell("Spirit Walk");
                }

                CheckForAdds();
                return;
            }

            if (!combatChecks())
                return;

            if (_me.CurrentTarget.TaggedByOther && !_me.CurrentTarget.TaggedByMe &&
                !IsTargetingMeOrMyStuff(_me.CurrentTarget))
            {
                Slog("Combat Target is tagged by another player -- let them have it");
                _me.ClearTarget();
                return;
            }

            // check if we agroed a mob unintentionally
            if (_pullTargGuid != _me.CurrentTarget.Guid)
            {
                Safe_StopMoving();
                Slog(">>> ADD: " + _me.CurrentTarget.Class + "-" + Safe_UnitName(_me.CurrentTarget) + "[" +
                     _me.CurrentTarget.Level + "] at " + _me.CurrentTarget.Distance.ToString("F1") + " yds");
                PullInitialize();
            }

            if (_timerCombatStats.ElapsedMilliseconds > 1000)
            {
                Dlog("status: currently at {0:F2}% health, {1:F2}% mana", _me.HealthPercent, _me.ManaPercent);
                _timerCombatStats.Reset();
                _timerCombatStats.Start();
            }

            if (_pullTimer.ElapsedMilliseconds > 20000 && _me.CurrentTarget.HealthPercent > 95 &&
                !_me.CurrentTarget.IsPlayer)
            {
                Slog("Evade bugged mob detected: blacklisting: " + _me.CurrentTarget.Class + "-" +
                     Safe_UnitName(_me.CurrentTarget) + "[" + _me.CurrentTarget.Level + "]");
                StopAutoAttack();
                Blacklist.Add(_me.CurrentTarget.Guid, TimeSpan.FromHours(1));
                _me.ClearTarget();
                return;
            }

            if (!WoWMovement.IsFacing)
                WoWMovement.Face();

            if (!_me.IsAutoAttacking && _me.GotTarget && _me.CurrentTarget.IsAlive && CurrentTargetInMeleeDistance() &&
                !_pvp.IsBattleground())
            {
                Dlog("** Auto-Attack started in Combat");
                AutoAttack();
            }

            // ok, reevaluate if still need healing in hopes we can attack
            if (NeedHeal && HealMyself())
                return;

            if (_me.GotTarget && _me.CurrentTarget.IsCasting && InterruptEnemyCast())
                return;
            /*      
             * duplicate call (look earlier in this func)
                        if (!combatChecks())
                            return;
            */
            if (!pvpChecks())
            {
                if (!FindBestTarget())
                    return;
            }

            if (_typeShaman == ShamanType.Enhance)
                CombatMelee();
            else
                CombatElemental();

            ShamanBuffs(false);
        }

        private readonly Stopwatch _timerCombatStats = new Stopwatch();

        #region Combat Styles

        /*
         * CombatMelee()
         * 
         * Rotation: Lightning Bolt, until the mob is near you, then spam Earth Shock while 
         * auto attacking.  Shield Twist between Water Shield and Lightning Shield.  Keep 
         * Windfury Weapon up, use Flametongue if not trained, and Rockbiter if no other choice
         * 
         * Looks redundant, but we use combatChecks() and AllowNonHealSpells() over and over.  They
         * are state checking functions and the conditions they check will change during the 
         * running of this function.  They need to be measured immediately before using an
         * ability.
         */

        private void CombatMelee()
        {
            // if I'm rooted then throw anything ranged at them
            if (!CurrentTargetInMeleeDistance())
            {
                if (!_me.Rooted)
                {
                    MoveToAttackMelee();
                    BestShockForMob(false);
                    CheckForAdds();
                    return;
                }

                Dlog("I'm melee and rooted and out of melee range, do something!!!");
                CheckForAdds();

                if (FeralSpirit())
                    return;

                if (FindBestMeleeTarget()) // check for weakest targets only first
                    ;
                else if (FindBestTarget()) // settle for weakest target within range
                {
                    CombatElemental();
                    return;
                }
                else
                {
                    Slog("Rooted:  no target in range so waiting it out...");
                    return;
                }
            }

            if (_me.IsMoving)
            {
                if (!_me.GotTarget)
                    Dlog("I don't have a target?");
                else
                    Dlog("Moving and {0:F1} yds away, stopping now...",
                         _me.Location.Distance(_me.CurrentTarget.Location));
                Safe_StopMoving();
            }

            if (!combatChecks())
                return;

            CheckForAdds();

            // use Shamanistic Rage when our mana is low and mob we are fighting has 
            // .. a lot of health left.  Since it gives mana back for 
            if (_me.ManaPercent < _cfg.RestManaPercent)
            {
                if (IsFightStressful() || (countEnemy > 1) || (_me.GotTarget && _me.CurrentTarget.HealthPercent >= 75))
                {
                    ShamanisticRage();
                }
            }

            // for Enhancement:  make first set of totems high priority
            if (!TotemsWereSet() && combatChecks() && AllowNonHealSpells())
            {
                SetTotemsAsNeeded();
            }

            if (CallForReinforcements())
                return;

            CastCombatSpecials();

            if (MaelstromCheck())
                return;

            if (_countMeleeEnemy > 1 && TotemExist(TOTEM_FIRE) && FireNova())
                return;

            if (Stormstrike())
                return;

            if (BestShockForMob(false))
                return;

            if (LavaLash())
                return;

            if (Cleanse())
                return;

            // now check to see if any totems still needed
            if (combatChecks() && AllowNonHealSpells())
            {
                SetTotemsAsNeeded();
            }
        }


        /*
         * CombatElemental()
         * 
         */

        private void CombatElemental()
        {
            if (!CurrentTargetInRangedDistance() && _me.Rooted)
            {
                // options -- trinket, heal (anticipating being hit)
                if (!FindBestTarget())
                {
                    Slog("Rooted:  no target in range so waiting it out...");
                    return;
                }
            }

            if (!CurrentTargetInRangedDistance())
            {
                // chase until in ranged distance or for 8 seconds
                Dlog("running to mob " + _me.CurrentTarget.Distance.ToString("F2") + " away");
                MoveToAttackRanged();
                // BestShockForMob(false);
                CheckForAdds();
                return;
            }

            if (_me.IsMoving)
                Safe_StopMoving();

            if (!combatChecks())
                return;

            CheckForAdds();

            // we already cast totems in pull, so this is just to see if we need to replace any if in crisis
            if (AllowNonHealSpells() && (countEnemy > 1 || (_me.GotTarget && _me.CurrentTarget.HealthPercent > 25)))
            {
                SetTotemsAsNeeded();
            }

            if (CallForReinforcements())
                return;

            CastCombatSpecials();

            if ((IsFightStressful() && _countMeleeEnemy == 1) || _me.ManaPercent < _cfg.EmergencyManaPercent)
            {
                if (Thunderstorm())
                    return;
            }

            if (_me.GotTarget && _me.CurrentTarget.IsPlayer && FrostShock())
                return;

            if (FlameShock(true))
                return;

            ElementalMastery();

            if (LavaBurst())
                return;

            if (countEnemy > 1 && WillChainLightningHop(_me.CurrentTarget) && ChainLightning())
                return;

            if (_countMeleeEnemy > 1 && TotemExist(TOTEM_FIRE) && FireNova())
                return;

            if (LightningBolt())
                return;

            if (BestShockForMob(false))
                return;

            if (Cleanse())
                return;
        }


        private void ShowCurrentStatus()
        {
            Dlog("- status [me]:  h/m:{0:F1}%/{1:F1}%, melee:{2}, range:{3}, rooted:{4}, immobile:{5}, silenced:{6}",
                 _me.HealthPercent,
                 _me.ManaPercent,
                 _countMeleeEnemy,
                 _countRangedEnemy,
                 _me.Rooted,
                 MeImmobilized(),
                 _me.Silenced
                );

            /*
                        if (_me.HealthPercent < 10)
                            ListWowUnitsInRange();
                        else if (_me.GotTarget)
                        {
                            Dlog("- my target:  {0}[{1}], dist:{2:F1} yds, h:{3:F1}%",
                                Safe_UnitName(_me.CurrentTarget),
                                _me.CurrentTarget.Level,
                                _me.CurrentTarget.Distance,
                                _me.CurrentTarget.HealthPercent
                                );
                        }
                        else
                        {
                            Dlog("my target:  none");
                        }
             */
        }

        private WoWPoint _pursuitStart;
        private readonly Stopwatch _pursuitTimer = new Stopwatch();

        public void PursuitBegin()
        {
            _pursuitTimer.Reset();
            _pursuitTimer.Start();
            _pursuitStart = _me.Location;
        }

        public bool InPursuit()
        {
            return _pursuitTimer.IsRunning;
        }

        public long PursuitTime
        {
            get { return _pursuitTimer.ElapsedMilliseconds; }
        }

        public WoWPoint PursuitOrigin
        {
            get { return _pursuitStart; }
        }

        #endregion

        #region Spells

        /// <summary>
        /// combatChecks() verifies the minimum necessary elements for combat between 
        /// _me and _me.CurrentTarget.  This verifies:
        ///     _me is alive
        ///     != null
        ///     .CurrentTarget is alive
        ///     .CurrentTarget is not self
        ///     .CurrentTarget is not my pet/totems/etc
        ///     _me is facing the .CurrentTarget
        ///     
        /// if no current target OR if .CurrentTarget is dead and still in combat or in a battleground
        ///     switch to the best available target
        ///     
        /// </summary>
        /// <returns>true - combat can continue
        /// false - unable to fight current target</returns>
        private bool combatChecks()
        {
            WoWUnit add = null;

            // if I am dead
            if (!_me.IsAlive)
            {
                ReportBodyCount();
                return false;
            }

            // if my target is dead
            if (_me.GotTarget && !_me.CurrentTarget.IsAlive)
            {
                ReportBodyCount();
                if (!_me.Combat && !_pvp.IsBattleground())
                    return false;
            }

            if (!_me.GotTarget || !_me.CurrentTarget.IsAlive)
            {
                if (_me.Combat || _pvp.IsBattleground())
                {
                    if (_me.GotAlivePet && _me.Pet.GotTarget && _me.Pet.CurrentTarget.IsAlive)
                    {
                        add = _me.Pet.CurrentTarget;
                        Slog(">>> SET PETS TARGET: {0}-{1}[{2}]", add.Class, Safe_UnitName(add), add.Level);
                    }
                    else if (FindBestTarget())
                    {
                        add = _me.CurrentTarget;
                    }

                    if (add == null)
                    {
                        // target an enemy totem (this just cleans up in some PVE fights)
                        List<WoWUnit> addList
                            = (from o in ObjectManager.ObjectList
                               where o is WoWUnit && o.Distance <= _maxDistForRangeAttack
                               let unit = o.ToUnit()
                               where unit.Attackable
                                     && unit.IsAlive
                                     && Safe_IsHostile(unit)
                                     && unit.InLineOfSight
                                     && unit.CreatedByGuid != _me.Guid && unit.SummonedByGuid != _me.Guid
                                     // guard against my own totems being selected
                                     && unit.CreatureType == WoWCreatureType.Totem
                               select unit
                              ).ToList();

                        if (addList != null && addList.Count > 0)
                        {
                            add = addList.First();
                            Slog("Setting to enemy totem: {0}-{1}[{2}]", add.Class, add.Name, add.Level);
                        }
                    }

                    if (add != null)
                    {
                        Safe_SetCurrentTarget(add);
                    }
                }

                if (!_me.GotTarget || !_me.GotTarget)
                {
                    Dlog("No Current Target and can't find adds -- why still in Combat()");
                    return false;
                }
            }

            if (_me.CurrentTarget.Guid == _me.Guid)
            {
                Dlog("Targeting myself -- clearing and bailing out of Combat()");
                _me.ClearTarget();
                return false;
            }

            if (_me.CurrentTarget.CreatedByGuid == _me.Guid || _me.CurrentTarget.SummonedByGuid == _me.Guid)
            {
                Slog("? HB targeted my own: " + Safe_UnitName(_me.CurrentTarget) + ", blacklisting ?");
                AddToBlacklist(_me.CurrentTarget.Guid);
                _me.ClearTarget();
                return false;
            }

            if (!WoWMovement.IsFacing)
                WoWMovement.Face();

            return true;
        }


        /// <summary>
        /// pvpChecks() 
        /// Inspects the current target and handles certain PvP specific issues
        ///     blacklists pet
        ///     purges player defensive ability (iceblock, divine shield)
        /// </summary>
        /// <returns>
        /// true - continue with fighting
        /// false- can't fight, find new target if needed
        /// </returns>
        private bool pvpChecks()
        {
            if (!_me.GotTarget)
                return false;

            if (_pvp.IsBattleground() ||
                (_me.CurrentTarget.IsPlayer && _me.IsHorde != _me.CurrentTarget.ToPlayer().IsHorde))
            {
                // check for things we can't fight and should blacklist
                if (_me.CurrentTarget.IsPet)
                {
                    Slog("PVP: Blacklisting pet " + _me.CurrentTarget.Name);
                    Blacklist.Add(_me.CurrentTarget.Guid, TimeSpan.FromMinutes(5));
                    _me.ClearTarget();
                    return false;
                }

                // test, if in battleground and someone is out of line of sight, blacklist for 5 seconds
                if (!_me.CurrentTarget.InLineOfSight)
                {
                    Slog("PVP: Target not in LoS, blacklisting for 2 seconds");
                    Blacklist.Add(_me.CurrentTarget.Guid, TimeSpan.FromSeconds(2));
                    _me.ClearTarget();
                    return false;
                }

                if (_typeShaman == ShamanType.Enhance && _me.CurrentTarget.Distance > _maxDistForRangeAttack)
                {
                    Slog("PVP: Target out of range (" + _me.CurrentTarget.Distance + " yds), blacklisting for 3 seconds");
                    Blacklist.Add(_me.CurrentTarget.Guid, TimeSpan.FromSeconds(3));
                    _me.ClearTarget();
                    return false;
                }

                _me.CurrentTarget.GetBuffs(true); // refresh buffs for checking need for blacklist or purge

                if (_me.CurrentTarget.GetBuffs(false).ContainsKey("Divine Shield"))
                {
                    Slog("PVP: Palidan popped Divine Shield, blacklisted 10 secs");
                    Blacklist.Add(_me.CurrentTarget.Guid, TimeSpan.FromSeconds(10));
                    _me.ClearTarget();
                    return false;
                }

                if (_me.CurrentTarget.GetBuffs(false).ContainsKey("Ice Block"))
                {
                    Slog("PVP: Mage popped Iceblock and Purge not available, blacklisted 10 secs");
                    Blacklist.Add(_me.CurrentTarget.Guid, TimeSpan.FromSeconds(10));
                    _me.ClearTarget();
                    return false;
                }

                if (Safe_KnownSpell("Purge") && SpellManager.KnownSpells["Purge"].Cooldown)
                {
                    Dlog("PVP:  Purge on cooldown, skipping buff tests");
                }
                else if (_me.CurrentTarget.GetBuffs(false).ContainsKey("Blessing of Protection") && Purge())
                {
                    Slog("PVP: Palidan popped Blessing of Protection, purging... lawl");
                }
                else if (_me.CurrentTarget.GetBuffs(false).ContainsKey("Fear Ward") && Purge())
                {
                    Slog("PVP: Priest popped Fear Ward, purging... lawl");
                }
            }

            return true;
        }

        #region ATTACK SPELLS

        private void AutoAttack()
        {
            Slog(Color.DodgerBlue, "*Auto-Attack");
            RunLUA("StartAttack()");
        }

        private void StopAutoAttack()
        {
            Slog(Color.DodgerBlue, "*Stop Auto-Attack");
            RunLUA("StopAttack()");
        }

        private bool CastCombatSpecials()
        {
            bool cast = false;

            if (combatChecks() && AllowNonHealSpells())
            {
                if (_pvp.IsBattleground() || IsFightStressful() || _me.CurrentTarget.HealthPercent > 75)
                {
                    /*
                                        if (_me.Buffs.ContainsKey("Elemental Mastery"))
                                            ;
                                        else 
                     */
                    if (_me.Buffs.ContainsKey("Berserking"))
                        ;
                    else if (_me.Buffs.ContainsKey("Blood Fury"))
                        ;
                    else if (_me.Buffs.ContainsKey("Bloodlust"))
                        ;
                    else if (_me.Buffs.ContainsKey("Heroism"))
                        ;
                    else
                    {
                        /*
                                                cast = ElementalMastery();  // elemental shaman
                                                if (!cast)
                         */
                        cast = Berserking(); // trolls
                        if (!cast)
                            cast = BloodFury(); // orcs
                        if (!cast)
                            cast = BloodlustHeroism(); // horde and alliance shaman
                    }
                }
            }

            return cast;
        }

        private bool LightningBolt()
        {
            if (!combatChecks())
                ;
            else if (!HaveValidTarget() && !AllowNonHealSpells())
                ;
            else if (IsImmunneToNature(_me.CurrentTarget))
                Dlog("skipping Lightning Bolt since {0}[{1}] is immune to Nature damage", _me.CurrentTarget.Name,
                     _me.CurrentTarget.Entry);
            else
            {
                Safe_StopMoving();
                return Safe_CastSpell("Lightning Bolt", SpellRange.Check, SpellWait.NoWait);
            }

            return false;
        }

        private bool WillChainLightningHop(WoWUnit target)
        {
            bool enemyClose = false;
            var timer = new Stopwatch();
            timer.Start();

            if (target == null)
                return false;

            try
            {
                if (!_pvp.IsBattleground())
                {
                    enemyClose = (from o in ObjectManager.ObjectList
                                  where o is WoWUnit && o.Location.Distance(target.Location) <= 12
                                  let unit = o.ToUnit()
                                  where unit != target
                                        && unit.Attackable
                                        && unit.IsAlive
                                        && unit.Combat
                                        && !IsMeOrMyStuff(unit)
                                        && IsTargetingMeOrMyStuff(unit)
                                        && !Blacklist.Contains(unit.Guid)
                                  orderby unit.CurrentHealth ascending
                                  select unit
                                 ).Any();
                }
                else
                {
                    enemyClose = (from o in ObjectManager.ObjectList
                                  where o is WoWUnit && o.Location.Distance(target.Location) <= 12
                                  let unit = o.ToUnit()
                                  where unit != target
                                        && !unit.Dead && unit.IsPlayer &&
                                        unit.ToPlayer().IsHorde != ObjectManager.Me.IsHorde
                                        && unit.InLineOfSight && !unit.IsPet
                                        && !Blacklist.Contains(unit.Guid)
                                  orderby unit.CurrentHealth ascending
                                  select unit
                                 ).Any();
                }
            }
            catch (ThreadAbortException)
            {
                throw;
            }
            catch (Exception e)
            {
                Logging.WriteDebug("HB EXCEPTION in WillChainLightningHop()");
                Logging.WriteException(e);
                return false;
            }

            Dlog("WillChainLightningHop(): took {0} ms", timer.ElapsedMilliseconds);
            return enemyClose;
        }

        private bool ChainLightning()
        {
            if (!combatChecks())
                ;
            else if (!Safe_KnownSpell("Chain Lightning"))
                ;
            else if (!HaveValidTarget() || !AllowNonHealSpells())
                ;
            else
            {
                Safe_StopMoving();
                return Safe_CastSpellWithRangeCheck("Chain Lightning");
            }

            return false;
        }

        private bool ShamanisticRage()
        {
            if (!combatChecks())
                ;
            else if (!Safe_KnownSpell("Shamanistic Rage"))
                ;
            else
            {
                return Safe_CastSpell("Shamanistic Rage");
            }

            return false;
        }

        private bool EarthShock(bool bIgnoreWaterShield)
        {
            // NOTE:  with patch 3.3 of WoW using Shock spells is not as much of a concern
            // ... since they drastically increased the mana regen
            // --- SO, force it to ignore Water Shield for now
            bIgnoreWaterShield = true;

            if (!combatChecks())
                Dlog("EarthShock:  failed combat check");
            else if (!HaveValidTarget() || !AllowNonHealSpells())
                ;
            else if (!Safe_KnownSpell("Earth Shock"))
                ;
            else if (_me.CurrentTarget.Buffs.ContainsKey("Earth Shock"))
                Dlog("EarthShock:  target already has DoT");
            else if (bIgnoreWaterShield == false && !Safe_KnownSpell("Water Shield"))
                ;
            else if (IsImmunneToNature(_me.CurrentTarget))
                Dlog("skipping Earth Shock since {0}[{1}] is immune to Nature damage", _me.CurrentTarget.Name,
                     _me.CurrentTarget.Entry);
            else
            {
                if (IsStormstrikeNeeded())
                {
                    Stormstrike();
                }

                return Safe_CastSpell("Earth Shock", SpellRange.Check, SpellWait.NoWait);
            }

            return false;
        }

        private bool FlameShock(bool bIgnoreWaterShield)
        {
            // NOTE:  with patch 3.3 of WoW using Shock spells is not as much of a concern
            // ... since they drastically increased the mana regen
            // --- SO, force it to ignore Water Shield for now
            bIgnoreWaterShield = true;

            if (!combatChecks())
                Dlog("FlameShock:  failed combat check");
            else if (!HaveValidTarget() || !AllowNonHealSpells())
                ;
            else if (!Safe_KnownSpell("Flame Shock"))
                ;
            else if (IsImmunneToFire(_me.CurrentTarget))
                Dlog("skipping Flame Shock since {0}[{1}] is immune to Fire damage", _me.CurrentTarget.Name,
                     _me.CurrentTarget.Entry);
            else if (_me.CurrentTarget.Buffs.ContainsKey("Flame Shock"))
                Dlog("FlameShock:  target already has DoT");
            else if (bIgnoreWaterShield == false && !Safe_KnownSpell("Water Shield"))
                ;
            else
                return Safe_CastSpell("Flame Shock", SpellRange.Check, SpellWait.NoWait);

            return false;
        }

        private bool FrostShock()
        {
            if (!combatChecks())
                ;
            else if (!HaveValidTarget() && !AllowNonHealSpells())
                ;
            else if (!Safe_KnownSpell("Frost Shock"))
                ;
            else if (IsImmunneToFrost(_me.CurrentTarget))
                Dlog("skipping Frost Shock since {0}[{1}] is immune to Frost damage", _me.CurrentTarget.Name,
                     _me.CurrentTarget.Entry);
            else if (_me.CurrentTarget.Buffs.ContainsKey("Frost Shock"))
                ;
            else
                return Safe_CastSpell("Frost Shock", SpellRange.Check, SpellWait.NoWait);

            return false;
        }

        /*
         * Summary:  determines the best Shock spell opener to
         * use.  This is for use during pull only.  
         */

        private bool ShockOpener(bool bIgnoreWaterShield)
        {
            bool bCast = false;

            if (_me.GotTarget && !IsHealerOnly())
            {
                if (_me.CurrentTarget.IsPlayer || _me.CurrentTarget.Fleeing)
                    bCast = FrostShock();

                if (!bCast)
                    bCast = FlameShock(bIgnoreWaterShield);

                if (!bCast)
                    bCast = EarthShock(bIgnoreWaterShield);

                if (!bCast)
                    bCast = FrostShock();
            }

            return bCast;
        }

        private bool BestShockForMob(bool bIgnoreWaterShield)
        {
            bool knowFrost = Safe_KnownSpell("Frost Shock");
            bool knowEarth = Safe_KnownSpell("Earth Shock");
            bool knowFire = Safe_KnownSpell("Fire Shock");

            if (!combatChecks())
                return false;

            if (knowFire && _me.CurrentTarget.Class == WoWClass.Rogue && FlameShock(bIgnoreWaterShield))
                return true;

            if (knowFrost && (_me.CurrentTarget.Fleeing || _me.CurrentTarget.IsPlayer) && FrostShock())
                return true;

            if (knowEarth && EarthShock(bIgnoreWaterShield))
                return true;

            if (knowFire && FlameShock(bIgnoreWaterShield))
                return true;

            //	    if (knowFrost && FrostShock())
            //		return true;

            return false;
        }

        private bool Stormstrike()
        {
            if (!combatChecks())
                ;
            else if (!HaveValidTarget() || !AllowNonHealSpells())
                ;
            else if (!Safe_KnownSpell("Stormstrike"))
                ;
            else if (!CurrentTargetInMeleeDistance())
                ;
            else if (_me.CurrentTarget.Buffs.ContainsKey("Stormstrike") && _pointsImprovedStormstrike == 0)
                ;
            else
                return Safe_CastSpell("Stormstrike", SpellRange.NoCheck, SpellWait.NoWait);

            return false;
        }

        private bool IsStormstrikeNeeded()
        {
            if (Safe_KnownSpell("Stormstrike"))
            {
                if (!_me.CurrentTarget.Buffs.ContainsKey("Stormstrike"))
                {
                    if (CurrentTargetInMeleeDistance())
                    {
                        return true;
                    }
                }
            }
            return false;
        }

        private bool LavaLash()
        {
            if (!combatChecks())
                ;
            else if (!HaveValidTarget() && !AllowNonHealSpells())
                ;
            else if (!Safe_KnownSpell("Lava Lash"))
                ;
            else if (!CurrentTargetInMeleeDistance())
                ;
            else if (IsImmunneToFire(_me.CurrentTarget))
                Dlog("skipping Lava Lash since {0}[{1}] is immune to Fire damage", _me.CurrentTarget.Name,
                     _me.CurrentTarget.Entry);
            else
                return Safe_CastSpell("Lava Lash", SpellRange.NoCheck, SpellWait.NoWait);

            return false;
        }

        private bool LavaBurst()
        {
            if (!combatChecks())
                ;
            else if (!HaveValidTarget() && !AllowNonHealSpells())
                ;
            else if (!Safe_KnownSpell("Lava Burst"))
                ;
            else if (IsImmunneToFire(_me.CurrentTarget))
                Dlog("skipping Lava Burst since {0}[{1}] is immune to Fire damage", _me.CurrentTarget.Name,
                     _me.CurrentTarget.Entry);
            else
                return Safe_CastSpell("Lava Burst", SpellRange.Check, SpellWait.NoWait);

            return false;
        }

        private bool ElementalMastery()
        {
            if (!combatChecks())
                ;
            else if (!HaveValidTarget() && !AllowNonHealSpells())
                ;
            else if (!Safe_KnownSpell("Elemental Mastery"))
                ;
            else
                return Safe_CastSpell("Elemental Mastery", SpellRange.NoCheck, SpellWait.NoWait);

            return false;
        }

        private bool Thunderstorm()
        {
            if (!combatChecks())
                ;
            else if (IsRAF() && !_cfg.RAF_UseThunderstorm)
                ;
            else if (!Safe_KnownSpell("Thunderstorm"))
                ;
            else
                return Safe_CastSpell("Thunderstorm", SpellRange.NoCheck, SpellWait.NoWait);

            return false;
        }

        private bool FireNova()
        {
            if (!combatChecks())
                ;
            else if (!HaveValidTarget() && !AllowNonHealSpells())
                ;
            else if (!Safe_KnownSpell("Fire Nova"))
                ;
            else if (IsImmunneToFire(_me.CurrentTarget))
                Dlog("skipping Fire Nova since {0}[{1}] is immune to Fire damage", _me.CurrentTarget.Name,
                     _me.CurrentTarget.Entry);
            else if (!TotemExist(TOTEM_FIRE))
                Dlog("fire totem doesn't exist, Fire Nova not cast");
            else if (_ptTotems.Distance(_me.Location) >= 10f)
                Dlog("Fire Totem is {0:F1} yds away, Fire Nova not cast", _ptTotems.Distance(_me.Location));
            else
                return Safe_CastSpell("Fire Nova", SpellRange.NoCheck, SpellWait.NoWait);

            return false;
        }

        private bool MaelstromCheck()
        {
            if (!combatChecks())
                ;
            else if (!HaveValidTarget())
                ;
            else
            {
                const string cMaelstromWeapon = "Maelstrom Weapon";
                List<string> myBuffs = CallLUA("return UnitBuff(\"player\",\"" + cMaelstromWeapon + "\")");

                if (Equals(null, myBuffs))
                    return false;

                string buffName = myBuffs[0];
                int stackCount = Convert.ToInt32(myBuffs[3]);

                if (buffName != cMaelstromWeapon)
                    ;
                else if (stackCount < 4)
                    ;
                else
                {
                    if (stackCount >= 4 && _me.HealthPercent < _cfg.EmergencyHealthPercent)
                    {
                        Slog("^Maelstrom Heal @ " + stackCount + " stks");
                        bool goodHeal = HealingWave();
                        if (!goodHeal)
                            goodHeal = LesserHealingWave();
                        return goodHeal;
                    }
                    else if (stackCount == 5)
                    {
                        Slog("^Maelstrom Attack @ " + stackCount + " stks");
                        Stormstrike(); // throw a Stormstrike if debuff not up
                        if (WillChainLightningHop(_me.CurrentTarget))
                            return ChainLightning();
                        else
                            return LightningBolt();
                    }
                }
            }

            return false;
        }


        private bool InterruptEnemyCast()
        {
            if (!combatChecks())
                Dlog("Failed combat checks - Wind Shear not cast");
            else if (!HaveValidTarget())
                Dlog("Don't have a valid target - Wind Shear not cast");
            else if (!AllowNonHealSpells())
                Dlog("Non-healing spells not allowed now - Wind Shear not cast");
            else if (!Safe_KnownSpell("Wind Shear"))
                Dlog("Have not trained spell yet - Wind Shear not cast");
            else if (Safe_CastSpellWithRangeCheck("Wind Shear"))
                return true;
            else if (_me.CurrentTarget.Distance < 8)
                return Warstomp();

            return false;
        }

        private bool Purge()
        {
            if (!combatChecks())
                Dlog("Failed combat checks - Purge not cast");
            else if (!AllowNonHealSpells())
                Dlog("Non-healing spells not allowed now - Purge not cast");
            else if (!Safe_KnownSpell("Purge"))
                Dlog("Have not trained spell yet - Purge not cast");
            else if (Safe_CastSpell("Purge", SpellRange.Check, SpellWait.NoWait))
                return true;

            return false;
        }

        private bool FeralSpirit()
        {
            bool castGood = false;

            if (_cfg.TotemsDisabled)
                return false;

            if (IsRAF()) // && _cfg.RAF_SaveFeralSpiritForBosses && false /* check if boss */)
                Dlog("Feral Spirit:  not cast because in RaF group");
            else if (!(_pvp.IsBattleground() || IsFightStressful() || !_cfg.PVE_SaveForStress_FeralSpirit))
            {
                Dlog(
                    "Feral Spirit:  not cast because  InBattleground={0}, IsFightStressful()={1}, and SaveForStress={2}",
                    _pvp.IsBattleground(),
                    IsFightStressful(),
                    _cfg.PVE_SaveForStress_FeralSpirit
                    );
            }
            else
            {
                if (Safe_KnownSpell("Feral Spirit"))
                {
                    castGood = Safe_CastSpell("Feral Spirit", SpellRange.NoCheck, SpellWait.Complete);
                    if (castGood)
                    {
                        Log("^Pet Defensive Mode");
                        RunLUA("PetDefensiveMode()"); // turn on defensive mode

                        Log("^Pet Attack");
                        RunLUA("PetAttack()"); // turn on defensive mode

                        if (!_pvp.IsBattleground())
                        {
                            Log("^Pet Ability - Twin Howl");
                            RunLUA("CastPetAction(5)"); // throw a twin howl immediately
                        }
                        else if (_me.Rooted || MeImmobilized())
                        {
                            Log("^Pet Ability - Spirit Walk (remove movement impairing effects)");
                            Safe_CastSpell("Spirit Walk");
                            // RunLUA("CastPetAction(5)");       // throw a twin howl immediately
                        }
                    }
                }
            }

            return castGood;
        }


        private bool EarthElementalTotem()
        {
            bool castGood = false;

            if (!Safe_KnownSpell("Earth Elemental Totem"))
                ;
            else if (!_pvp.IsBattleground() && !IsFightStressful() && _cfg.PVE_SaveForStress_ElementalTotems)
            {
                Dlog(
                    "Earth Elemental Totem:  not cast because  InBattleground={0}, IsFightStressful()={1}, and SaveForStress={2}",
                    _pvp.IsBattleground(),
                    IsFightStressful(),
                    _cfg.PVE_SaveForStress_ElementalTotems
                    );
            }
            else
            {
                castGood = TotemCast(TOTEM_EARTH, "Earth Elemental Totem");
            }

            return castGood;
        }

        private bool FireElementalTotem()
        {
            bool castGood = false;

            if (!Safe_KnownSpell("Fire Elemental Totem"))
                ;
            else if (!_pvp.IsBattleground() && !IsFightStressful() && _cfg.PVE_SaveForStress_ElementalTotems)
            {
                Dlog(
                    "Fire Elemental Totem:  not cast because  InBattleground={0}, IsFightStressful()={1}, and SaveForStress={2}",
                    _pvp.IsBattleground(),
                    IsFightStressful(),
                    _cfg.PVE_SaveForStress_ElementalTotems
                    );
            }
            else
            {
                castGood = TotemCast(TOTEM_FIRE, "Fire Elemental Totem");
            }

            return castGood;
        }

        private bool CallForReinforcements()
        {
            if (!_pvp.IsBattleground() && _cfg.PVE_CombatStyle == ConfigValues.PveCombatStyle.DisableTotemsCDs)
                return false;

            if (_me.GotAlivePet)
                return false;

            if (TotemExist(TOTEM_EARTH) && TotemName(TOTEM_EARTH) == "Earth Elemental Totem")
                return false;

            if (TotemExist(TOTEM_FIRE) && TotemName(TOTEM_EARTH) == "Fire Elemental Totem")
                return false;

            if (FeralSpirit())
                return true;

            if (_pvp.IsBattleground())
            {
                if (FireElementalTotem())
                    return true;

                if (EarthElementalTotem())
                    return true;
            }
            else
            {
                if (EarthElementalTotem())
                    return true;

                if (FireElementalTotem())
                    return true;
            }


            return false;
        }

        private bool BloodlustHeroism()
        {
            if (!_pvp.IsBattleground() && _cfg.PVE_CombatStyle == ConfigValues.PveCombatStyle.DisableTotemsCDs)
                return false;

            if (IsRAF()) // later check _cfg.RAF_UseBloodlustOnBosses and if its a boss
            {
                return false;
            }

            bool knowBloodlust = Safe_KnownSpell("Bloodlust");
            bool knowHeroism = Safe_KnownSpell("Heroism");
            if (_pvp.IsBattleground() || IsFightStressful() || !_cfg.PVE_SaveForStress_Bloodlust)
            {
                if (!knowBloodlust && !knowHeroism)
                    ;
                else if (_me.Debuffs.ContainsKey("Sated"))
                    ;
                else if (knowBloodlust && Safe_CastSpell("Bloodlust", SpellRange.NoCheck, SpellWait.NoWait))
                {
                    Slog("Bloodlust: just broke out a major can of whoop a$$!");
                    return true;
                }
                else if (knowHeroism && Safe_CastSpell("Heroism", SpellRange.NoCheck, SpellWait.NoWait))
                {
                    Slog("Heroism: just broke out a major can of whoop a$$!");
                    return true;
                }
            }

            return false;
        }

        #endregion

        #region HEALING

        private bool HealingWave()
        {
            return Safe_CastSpell("Healing Wave");
        }

        private bool LesserHealingWave()
        {
            if (!Safe_KnownSpell("Lesser Healing Wave"))
                return false;
            return Safe_CastSpell("Lesser Healing Wave");
        }

        private void UseManaPotionIfAvailable()
        {
            UsePotion(CheckForItem(_potionManaEID));
        }

        private void UseHealthPotionIfAvailable()
        {
            UsePotion(CheckForItem(_potionHealthEid));
        }

        private void UsePotion(WoWItem potion)
        {
            if (potion != null)
            {
                if (MeImmobilized())
                    Slog("Immobilized -- unable to use potion now");
                else
                {
                    if (!_potionTimer.IsRunning || _potionTimer.ElapsedMilliseconds > 60*1000)
                    {
                        Slog("POTION:  Using '" + potion.Name + "'");
                        Dlog("{0} has a cooldown of {1}", potion.Name, potion.Cooldown);
                        RunLUA("UseItemByName(\"" + potion.Name + "\")");
                        _potionTimer.Reset();
                        _potionTimer.Start();
                    }
                }
            }
        }

        private bool UseBandageIfAvailable()
        {
            WoWItem bandage = CheckForItem(_bandageEID);
            if (_cfg.UseBandages && !SpellManager.KnownSpells.ContainsKey("First Aid"))
            {
                Wlog("Use Bandages ignored : your Shaman has not trained First Aid");
            }
            else if (bandage == null)
                Wlog("FIRST-AID:  no bandages in inventory");
            else if (_me.Debuffs.ContainsKey("Recently Bandaged"))
                Dlog("FIRST-AID:  can't bandage -- currently under 'Recently Bandaged' debuff");
            else if (!MeImmobilized())
            {
                foreach (var dbf in _me.Debuffs)
                {
                    if (!dbf.Value.IsHarmful)
                        continue;
                    Dlog("FIRST-AID:  can't bandage -- harmful non-dispellable debuff '{0}' active", dbf.Key);
                    return false;
                }

                Safe_StopMoving();

                double healthStart = _me.HealthPercent;
                var timeBandaging = new Stopwatch();
                Slog("FIRST-AID:  using '{0}' at {1:F0}%", bandage.Name, _me.HealthPercent);
                timeBandaging.Start();

                try
                {
                    RunLUA("UseItemByName(\"" + bandage.Name + "\", \"player\")");
                    do
                    {
                        Thread.Sleep(100);
                        Dlog("dbg firstaid:  buff-present:{0}, casting:{1}, channeled:{2}",
                             IsBuffPresent("First Aid"),
                             _me.IsCasting,
                             _me.ChanneledCasting != 0);
                    } while ((IsBuffPresent("First Aid") || timeBandaging.ElapsedMilliseconds < 1000) &&
                             _me.HealthPercent < 100.0);
                }
                catch (ThreadAbortException)
                {
                    throw;
                }
                catch (Exception e)
                {
                    Logging.WriteDebug("WOW LUA Call to UseItemByName() failed");
                    Logging.WriteException(e);
                }

                Dlog("FIRST-AID:  used {0} for {1:F1} secs ending at {2:F0}%", bandage.Name,
                     timeBandaging.Elapsed.TotalSeconds, _me.HealthPercent);
                if (healthStart < _me.HealthPercent)
                    return true;
            }

            return false;
        }

        #endregion

        private bool ShieldBuffNeeded(bool atRest)
        {
            bool bKnowBuffSpell = Safe_KnownSpell("Water Shield") || Safe_KnownSpell("Lightning Shield") ||
                                  Safe_KnownSpell("Earth Shield");
            bool bNeedBuff = !_me.Buffs.ContainsKey("Water Shield") && !_me.Buffs.ContainsKey("Lightning Shield") &&
                             !_me.Buffs.ContainsKey("Earth Shield");

            if (atRest && !bNeedBuff && _me.Buffs.ContainsKey("Water Shield"))
            {
                if (_me.Buffs["Water Shield"].StackCount < 3)
                    bNeedBuff = true;
            }

            if (atRest && !bNeedBuff && _me.Buffs.ContainsKey("Lightning Shield"))
            {
                if (_me.Buffs["Lightning Shield"].StackCount < 3)
                    bNeedBuff = true;
            }

            if (atRest && !bNeedBuff && _me.Buffs.ContainsKey("Earth Shield"))
            {
                if (_me.Buffs["Earth Shield"].StackCount < 3)
                    bNeedBuff = true;
            }

            return bKnowBuffSpell && bNeedBuff;
        }

        /*
         * ShieldTwisting()
         * 
         * Implement a technique known as shield twisting where
         * you alternate between a damage shield and a mana restoration 
         * shield.  basically make sure one or the other is active.
         * 
         * Here is the general approach in priority order:
         * 
         * If Mana is low, then force Mana restoration
         * If Mana is full, then force Damage shield
         * Otherwise alterante between shield types
         * 
         * This is a Level 20 and Higher Technique
         */

        private void ShieldTwisting(bool atRest)
        {
            bool castShield = false;
            bool useWaterShieldThisTime = false;

            // for Resto Shaman in BGs, cast Earth Shield on self
            if (_typeShaman == ShamanType.Resto && _pvp.IsBattleground() && Safe_KnownSpell("Earth Shield"))
            {
                uint uEarthStacks = (!_me.Buffs.ContainsKey("Earth Shield") ? 0 : _me.Buffs["Earth Shield"].StackCount);
                if (uEarthStacks == 0 || (uEarthStacks < 3 && atRest))
                    castShield = Safe_CastSpell("Earth Shield", SpellRange.NoCheck, SpellWait.NoWait);
            }
                // for Resto or Elemental in RAF, cast Water Shield on self
            else if (_typeShaman != ShamanType.Enhance && IsRAF() && Safe_KnownSpell("Water Shield"))
            {
                uint uWaterStacks = (!_me.Buffs.ContainsKey("Water Shield") ? 0 : _me.Buffs["Water Shield"].StackCount);
                if (uWaterStacks == 0 || (uWaterStacks < 3 && atRest))
                    castShield = Safe_CastSpell("Water Shield", SpellRange.NoCheck, SpellWait.NoWait);
            }
            else
            {
                bool trainedWaterShield = Safe_KnownSpell("Water Shield");
                bool trainedLightningShield = Safe_KnownSpell("Lightning Shield");
                if (!trainedLightningShield && !trainedWaterShield)
                    return;

                uint uWaterStacks = (!_me.Buffs.ContainsKey("Water Shield") ? 0 : _me.Buffs["Water Shield"].StackCount);
                uint uLightningStacks = (!_me.Buffs.ContainsKey("Lightning Shield")
                                             ? 0
                                             : _me.Buffs["Lightning Shield"].StackCount);


                // check if water shield required
                if (trainedWaterShield && _me.ManaPercent <= _cfg.TwistManaPercent &&
                    (uWaterStacks == 0 || (atRest && uWaterStacks < 3)))
                {
                    castShield = true;
                    useWaterShieldThisTime = true;
                }
                    // check if lightning shield required
                else if (trainedLightningShield && _me.ManaPercent > _cfg.TwistDamagePercent &&
                         (uLightningStacks == 0 || (atRest && uLightningStacks < 3)))
                {
                    castShield = true;
                    useWaterShieldThisTime = false;
                }
                    // now check if missing a shield and need to Twist
                else if ((uWaterStacks + uLightningStacks) == 0 || (atRest && (uWaterStacks + uLightningStacks) < 3))
                {
                    useWaterShieldThisTime = !_waterShieldUsedLast ? trainedWaterShield : trainedLightningShield;
                    castShield = (trainedWaterShield || trainedLightningShield);
                }

                if (castShield)
                {
                    SpellWait sw = atRest ? SpellWait.Complete : SpellWait.NoWait;
                    string sShield = useWaterShieldThisTime ? "Water Shield" : "Lightning Shield";
                    castShield = Safe_CastSpell(sShield, SpellRange.NoCheck, sw);

                    if (castShield)
                        _waterShieldUsedLast = useWaterShieldThisTime;
                }
            }
        }


        /*
         * Summary: inspects the list of WoWUnits for one that is within the
         *	    maximum distance provided of the pt given.
         *          
         * Returns: true if clear for atleast that distance
         */

        private static bool CheckForSafeDistance(WoWPoint pt, double dist)
        {
            WoWUnit unitClose = null;
            var timer = new Stopwatch();

            timer.Start();
            try
            {
                if (!_pvp.IsBattleground())
                    unitClose = ObjectManager.GetObjectsOfType<WoWUnit>(false).Find(
                        unit => unit != null
                                && pt.Distance(unit.Location) < dist
                                && unit.Attackable
                                &&
                                (Safe_IsHostile(unit) || ProfileManager.CurrentProfile.Factions.Contains(unit.Faction))
                                && unit.IsAlive
                        );
                else
                    unitClose = ObjectManager.GetObjectsOfType<WoWPlayer>(false).Find(
                        unit => unit != null
                                && pt.Distance(unit.Location) < dist
                                && unit.IsPlayer
                                && unit.IsAlive
                                && unit.IsHorde != ObjectManager.Me.IsHorde
                        );

                if (unitClose == null)
                    Dlog("CheckForSafeDistance({0:F1}): no hostiles/profile mobs in range - took {1} ms", dist,
                         timer.ElapsedMilliseconds);
                else
                    Dlog("CheckForSafeDistance({0:F1}): saw {1}{2} - {3}[{4}] around {5:F0} yds away",
                         // - took {6} ms",
                         dist,
                         (unitClose.IsTargetingMeOrPet ? "*" : ""),
                         unitClose.Class,
                         unitClose.Name,
                         unitClose.Level,
                         5*Math.Round(pt.Distance(unitClose.Location)/5)
                        //			, timer.ElapsedMilliseconds
                        );
            }
            catch (ThreadAbortException)
            {
                throw;
            }
            catch (Exception e)
            {
                Logging.WriteDebug("HB EXCEPTION in CheckForSafeDistance()");
                Logging.WriteException(e);
            }

            return unitClose == null;
        }


        private static int _timerLastList = Environment.TickCount;

        public static void ListWowUnitsInRange()
        {
            if ((Environment.TickCount - _timerLastList) < 4000)
            {
                return;
            }

            _timerLastList = Environment.TickCount;
            List<WoWUnit> adds = ObjectManager.GetObjectsOfType<WoWUnit>(false).FindAll(
                unit => unit != null && unit.IsValid
                        && unit.Attackable
                        &&
                        (!Safe_IsFriendly(unit) ||
                         (unit.IsPlayer && unit.ToPlayer().IsHorde != ObjectManager.Me.IsHorde))
                        && unit.IsAlive
                        && unit.Distance <= Targeting.PullDistance
                );

            Slog("ADDLST  -- CURRENT WOWUNIT LIST --");
            foreach (WoWUnit unit in adds)
            {
                LogWowUnit(unit);
            }

            adds = (from o in ObjectManager.ObjectList
                    where o != null && o is WoWUnit
                    let unit = o.ToUnit()
                    where
                        IsMeOrMyStuff(unit) || IsTargetingMeOrMyStuff(unit) ||
                        (ObjectManager.Me.GotTarget && unit == ObjectManager.Me.CurrentTarget)
                    select unit
                   ).ToList();
            Slog(
                "QUERY   --GUID           Target           Summon           SumndBy          CreateBy         Critter          Charmed          CharmBy           Name-------");
            foreach (WoWUnit unit in adds)
            {
                DumpWowUnit(unit);
            }

            Slog(
                "ENUM    --GUID           Target           Summon           SumndBy          CreateBy         Critter          Charmed          CharmBy           Name-------");
            foreach (WoWUnit unit in ObjectManager.GetObjectsOfType<WoWUnit>(false, false))
            {
                // if ( unit != null && (IsMeOrMyStuff(unit) || IsTargetingMeOrMyStuff(unit)))
                DumpWowUnit(unit);
            }
        }

        public static void LogWowUnit(WoWUnit unit)
        {
            try
            {
                Slog("        {0}{1:F2} yds hostile:{2} attackable:{3}  {4}-{5} {6}[{7}] -->{8} | {9} | {10}",
                     IsTargetingMeOrMyStuff(unit) ? "X " : "  ",
                     unit.Distance,
                     Safe_IsHostile(unit),
                     unit.Attackable,
                     unit.CreatureType,
                     unit.Class,
                     unit.Name,
                     unit.Level,
                     !unit.GotTarget
                         ? "has no target"
                         : unit.CurrentTargetGuid == ObjectManager.Me.Guid ? "TARGETTING ME" : unit.CurrentTarget.Name,
                     ObjectManager.Me.CurrentTarget.Guid == unit.Guid ? "MY TARGET<---" : " ",
                     ObjectManager.Me.GotAlivePet && ObjectManager.Me.Pet.GotTarget &&
                     ObjectManager.Me.Pet.CurrentTargetGuid == unit.Guid
                         ? "PET TARGET<---"
                         : " "
                    );
            }
            catch
            {
            }
        }


        public static void DumpWowUnit(WoWUnit unit)
        {
            try
            {
                Slog("        {0:X16} {1:X16} {2:X16} {3:X16} {4:X16} {5:X16} {6:X16} {7:X16}  {8} [{9}]",
                     unit.Guid,
                     unit.GotTarget ? unit.CurrentTargetGuid : 0,
                     unit.Summon,
                     unit.SummonedByGuid,
                     unit.CreatedBy,
                     unit.Critter,
                     unit.Charmed,
                     unit.CharmedBy,
                     unit.Name,
                     unit.CreatureType
                    );
            }
            catch
            {
            }
        }

        /*
         * Summary: inspects the objects within ranged to check if they are targeting me
         *          and hostile.  breaks down counts between ranged and melee targets
         *          
         * Returns: total number of hostiles fighting me
         */
        private readonly Stopwatch _addsTimer = new Stopwatch();
        private List<WoWUnit> _mobList;

        private int CheckForAdds()
        {
            // ListWowUnitsInRange();

            var timerCFA = new Stopwatch();
            timerCFA.Start();

            try
            {
                // List<WoWObject> longList = ObjectManager.ObjectList;
                // List<WoWUnit> mobList = ObjectManager.GetObjectsOfType<WoWUnit>(false);
                // if (_mobList == null || (_addsTimer.ElapsedMilliseconds > 5000 && !_me.Combat ) ) 
                {
                    if (!_pvp.IsBattleground())
                    {
                        _mobList = (from o in ObjectManager.ObjectList
                                    where o is WoWUnit && o.Distance <= _maxDistForRangeAttack
                                    let unit = o.ToUnit()
                                    where unit.Attackable
                                          && unit.IsAlive
                                          && unit.Combat
                                          && !IsMeOrMyStuff(unit)
                                          &&
                                          (IsTargetingMeOrMyStuff(unit) || unit.CreatureType == WoWCreatureType.Totem)
                                    select unit
                                   ).ToList();
                        Dlog("CheckForAdds():  PVE list built has {0} entries within {1:F1} yds", _mobList.Count,
                             _maxDistForRangeAttack);
                    }
                    else
                    {
                        _mobList = (from o in ObjectManager.ObjectList
                                    where o is WoWUnit && o.Distance <= _maxDistForRangeAttack
                                    let unit = o.ToUnit()
                                    where
                                        !unit.Dead && !unit.IsGhost && unit.IsPlayer &&
                                        unit.ToPlayer().IsHorde != ObjectManager.Me.IsHorde
                                    // orderby o.Distance ascending
                                    select unit
                                   ).ToList();
                        Dlog("CheckForAdds():  PvP list built has {0} entries within {1:F1} yds", _mobList.Count,
                             _maxDistForRangeAttack);
                    }
                    _addsTimer.Reset();
                    _addsTimer.Start();
                }

                _countMeleeEnemy = 0;
                _countRangedEnemy = 0;
                _countMobs = 0;
                // _distClosestEnemy = 9999.99;
                _OpposingPlayerGanking = false;
                _BigScaryGuyHittingMe = false;

                // Dlog("CheckForAdds() can see:");
                try
                {
                    foreach (WoWUnit unit in _mobList)
                    {
                        if (unit == null || !unit.IsAlive) // check again incase one died since making list
                            continue;

                        if (unit.Distance < 5)
                            _countMeleeEnemy++;
                        else
                            _countRangedEnemy++;

                        if (unit.IsPlayer)
                        {
                            Dlog("  " + (unit.IsTargetingMeOrPet ? "*" : " ") + "PLAYER: (" +
                                 (unit.ToPlayer().IsHorde ? "H" : "A") + ") " + unit.Race + " " + unit.Class + " - " +
                                 unit.Name + "[" + unit.Level + "]  dist: " +
                                 _me.Location.Distance(unit.Location).ToString("F2"));
                            _OpposingPlayerGanking = !_pvp.IsBattleground();
                            if (_OpposingPlayerGanking && (!_me.GotTarget || !_me.CurrentTarget.IsPlayer))
                            {
                                Safe_SetCurrentTarget(unit);
                            }
                        }
                        else
                        {
                            string sType = "NPC";
                            if (ProfileManager.CurrentProfile.Factions.Contains(unit.Faction))
                            {
                                _countMobs++;
                                sType = "MOB";
                            }

                            Dlog("  " + (unit.IsTargetingMeOrPet ? "*" : " ") + sType + ": " + unit.Class + " - " +
                                 unit.Name + "[" + unit.Level + "]  dist: " +
                                 _me.Location.Distance(unit.Location).ToString("F2"));

                            if (unit.Elite || ((unit.Level - _me.Level) >= _cfg.PVE_LevelsAboveAsElite))
                                _BigScaryGuyHittingMe = true;
                        }
                    }
                }
                catch (ThreadAbortException)
                {
                    throw;
                }
                catch (Exception e)
                {
                    Logging.WriteDebug("EXCEPTION in code doing CheckForAdds(1)");
                    Logging.WriteException(e);
                }
            }
            catch (ThreadAbortException)
            {
                throw;
            }
            catch (Exception e)
            {
                Logging.WriteDebug("HB EXCEPTION in CheckForAdds(2)");
                Logging.WriteException(e);
            }

            Dlog("   Total  " + _countMeleeEnemy + "/" + _countRangedEnemy + " melee/ranged in Combat with me");

            Dlog("   ## CheckForAdds() took {0} ms", timerCFA.ElapsedMilliseconds);
            if (countEnemy > 1)
                Slog(">>> MULTIPLE TARGETS:  " + _countMeleeEnemy + " melee,  " + _countRangedEnemy + " ranged");
            if (_BigScaryGuyHittingMe)
                Slog(">>> BIG Scary Guy Hitting Me (elite or {0}+ levels)", _cfg.PVE_LevelsAboveAsElite);
            if (_OpposingPlayerGanking)
                Slog(">>> Opposing PLAYER is Attacking!!!!");


            return countEnemy;
        }

        private WoWUnit CheckForTotems()
        {
            var timerCFA = new Stopwatch();
            timerCFA.Start();
            WoWUnit totem = null;

            totem = ObjectManager.GetObjectsOfType<WoWUnit>(false).Find(
                unit => unit != null
                        && Safe_IsHostile(unit)
                        && unit.IsAlive
                        && unit.Distance <= Targeting.PullDistance
                        && unit.CreatureType == WoWCreatureType.Totem
                );

            return totem;
        }

        #endregion

        #region RACIALS

        private bool Warstomp()
        {
            if (!Safe_KnownSpell("War Stomp"))
                ;
            else if (_countMeleeEnemy < 1)
                ;
            else if (Safe_CastSpell("War Stomp", SpellRange.NoCheck, SpellWait.NoWait))
            {
                Slog("War Stomp: BOOM!");
                return true;
            }

            return false;
        }

        private bool Berserking()
        {
            if (_pvp.IsBattleground() || IsFightStressful() || !_cfg.PVE_SaveForStress_DPS_Racials)
            {
                if (!Safe_KnownSpell("Berserking"))
                    ;
                else if (Safe_CastSpell("Berserking", SpellRange.NoCheck, SpellWait.NoWait))
                {
                    Slog("Berserking: just broke out a can of whoop a$$!");
                    return true;
                }
            }

            return false;
        }

        private bool BloodFury()
        {
            if (_pvp.IsBattleground() || IsFightStressful() || !_cfg.PVE_SaveForStress_DPS_Racials)
            {
                if (!Safe_KnownSpell("Blood Fury"))
                    ;
                else if (Safe_CastSpell("Blood Fury", SpellRange.NoCheck, SpellWait.NoWait))
                {
                    Slog("Blood Fury: just broke out a can of whoop a$$!");
                    return true;
                }
            }

            return false;
        }

        private bool GiftOfTheNaaru()
        {
            if (!Safe_KnownSpell("Gift of the Naaru"))
                ;
            else if (Safe_CastSpell("Gift of the Naaru", SpellRange.NoCheck, SpellWait.NoWait))
            {
                Slog("Gift of the Naaru: it's good to be Draenei!");
                return true;
            }

            return false;
        }

        private bool Lifeblood()
        {
            if (!Safe_KnownSpell("Lifeblood"))
                ;
            else if (Safe_CastSpell("Lifeblood", SpellRange.NoCheck, SpellWait.NoWait))
            {
                Slog("Lifeblood: the benefit of being a flower picker!");
                return true;
            }

            return false;
        }

        #endregion

        /*
         * TotemExist()  checks to see if a totem of the specified class exists
         * 
         */
        private const int TOTEM_FIRE = 1;
        private const int TOTEM_EARTH = 2;
        private const int TOTEM_WATER = 3;
        private const int TOTEM_AIR = 4;

        private readonly string[] _totemBar = new string[5];
        private readonly string[] _totemName = new string[5];
        private readonly bool[] _totemExist = new bool[5];

        private string TotemName(int indexTotem)
        {
            return _totemName[indexTotem];
        }

        private bool TotemExist(int indexTotem)
        {
            _totemName[indexTotem] = "";

            List<string> totemInfo = CallLUA("return GetTotemInfo(" + indexTotem + ")");

            if (Equals(null, totemInfo))
                return false;

            string haveTotem = totemInfo[0];
            string totemName = totemInfo[1];
            string startTime = totemInfo[2];
            string duration = totemInfo[3];
            string icon = totemInfo[4];

            if (_totemName == null || totemName == "nil" || totemName == "")
            {
                _totemExist[indexTotem] = false;
            }
            else
            {
                _totemExist[indexTotem] = true;
                _totemName[indexTotem] = totemName;
                Dlog("   My Totem(" + indexTotem + ") exists:  " + totemName);
            }

            return _totemExist[indexTotem];
        }

        private bool TotemCast(int indexTotem, string sTotemName)
        {
            _totemExist[indexTotem] = Safe_CastSpell(sTotemName, SpellRange.NoCheck, SpellWait.NoWait);
            if (_totemExist[indexTotem])
            {
                _totemName[indexTotem] = sTotemName;
                _ptTotems = _me.Location;
            }

            return _totemExist[indexTotem];
        }

        private void TotemDestroy(int indexTotem)
        {
            RunLUA("DestroyTotem(" + indexTotem + ")");
            _totemName[indexTotem] = "";
        }

        private bool TotemSelect(int indexTotem, string sSpell)
        {
            WoWSpell spell;
            string sLua;

            _totemBar[indexTotem] = sSpell;
            Dlog("Totem Bar:  called with #{0} to '{1}'", indexTotem, sSpell);

            if (!Safe_KnownSpell("Call of the Elements"))
                return false;

            if (sSpell == "" || "none" == sSpell.ToLower())
            {
                Dlog("Totem Bar:  removing slot #{0}", indexTotem);
                sLua = String.Format("SetMultiCastSpell({0})", 132 + indexTotem);
                RunLUA(sLua);
                return true;
            }

            if (!Safe_KnownSpell(sSpell))
            {
                Dlog("Totem Bar:  cannot set slot #{0} to unknown spell '{1}'", indexTotem, sSpell);
                return false;
            }

            Dlog("Totem Bar:  setting slot #{0} to '{1}'", indexTotem, sSpell);
            spell = SpellManager.KnownSpells[sSpell];
            sLua = String.Format("SetMultiCastSpell({0}, {1})", 132 + indexTotem, spell.Id);
            RunLUA(sLua);

            return true;
        }

        private void TotemSetupBar()
        {
            _needTotemBarSetup = false;

            if (_pvp.IsBattleground())
            {
                _totemBar[TOTEM_EARTH] = _cfg.PVP_TotemEarth;
                _totemBar[TOTEM_FIRE] = _cfg.PVP_TotemFire;
                _totemBar[TOTEM_WATER] = _cfg.PVP_TotemWater;
                _totemBar[TOTEM_AIR] = _cfg.PVP_TotemAir;
            }
            else if (IsRAF())
            {
                _totemBar[TOTEM_EARTH] = _cfg.RAF_TotemEarth;
                _totemBar[TOTEM_FIRE] = _cfg.RAF_TotemFire;
                _totemBar[TOTEM_WATER] = _cfg.RAF_TotemWater;
                _totemBar[TOTEM_AIR] = _cfg.RAF_TotemAir;
            }
            else
            {
                _totemBar[TOTEM_EARTH] = _cfg.PVE_TotemEarth;
                _totemBar[TOTEM_FIRE] = _cfg.PVE_TotemFire;
                _totemBar[TOTEM_WATER] = _cfg.PVE_TotemWater;
                _totemBar[TOTEM_AIR] = _cfg.PVE_TotemAir;
            }
            /*
                        Dlog("value from cfgdlg:  Earth - {0}", _totemBar[TOTEM_EARTH]);
                        Dlog("value from cfgdlg:  Fire  - {0}", _totemBar[TOTEM_FIRE ]);
                        Dlog("value from cfgdlg:  Water - {0}", _totemBar[TOTEM_WATER]);
                        Dlog("value from cfgdlg:  Air   - {0}", _totemBar[TOTEM_AIR  ]);
            */
            // Earth - if configured spell is None or a real spellname, select that
            if (0 != String.Compare("Auto", _totemBar[TOTEM_EARTH], true))
                TotemSelect(TOTEM_EARTH, _totemBar[TOTEM_EARTH]);
            else if (_pvp.IsBattleground() && Safe_KnownSpell("Tremor Totem"))
                TotemSelect(TOTEM_EARTH, "Tremor Totem");
            else if (_typeShaman == ShamanType.Enhance && Safe_KnownSpell("Strength of Earth Totem"))
                TotemSelect(TOTEM_EARTH, "Strength of Earth Totem");
            else if (Safe_KnownSpell("Stoneskin Totem"))
                TotemSelect(TOTEM_EARTH, "Stoneskin Totem");
            else
                TotemSelect(TOTEM_EARTH, "None");

            // Fire - if configured spell is None or a real spellname, select that
            if (0 != String.Compare("Auto", _totemBar[TOTEM_FIRE], true))
                TotemSelect(TOTEM_FIRE, _totemBar[TOTEM_FIRE]);
            else if (Safe_KnownSpell("Totem of Wrath") && _typeShaman == ShamanType.Elemental)
                TotemSelect(TOTEM_FIRE, "Totem of Wrath");
            else if (Safe_KnownSpell("Flametongue Totem") &&
                     (_typeShaman == ShamanType.Elemental || _typeShaman == ShamanType.Resto))
                TotemSelect(TOTEM_FIRE, "Flametongue Totem");
            else if (Safe_KnownSpell("Searing Totem"))
                TotemSelect(TOTEM_FIRE, "Searing Totem");
            else
                TotemSelect(TOTEM_FIRE, "None");

            // Water - if configured spell is None or a real spellname, select that
            if (0 != String.Compare("Auto", _totemBar[TOTEM_WATER], true))
                TotemSelect(TOTEM_WATER, _totemBar[TOTEM_WATER]);
            else if (Safe_KnownSpell("Cleansing Totem") && _pvp.IsBattleground())
                TotemSelect(TOTEM_WATER, "Cleansing Totem");
            else if (Safe_KnownSpell("Healing Stream Totem") && _pvp.IsBattleground())
                TotemSelect(TOTEM_WATER, "Healing Stream Totem");
            else if (Safe_KnownSpell("Mana Spring Totem"))
                TotemSelect(TOTEM_WATER, "Mana Spring Totem");
            else
                TotemSelect(TOTEM_WATER, "None");

            // Air - if configured spell is None or a real spellname, select that
            if (0 != String.Compare("Auto", _totemBar[TOTEM_AIR], true))
                TotemSelect(TOTEM_AIR, _totemBar[TOTEM_AIR]);
            else if (Safe_KnownSpell("Grounding Totem") && _typeShaman == ShamanType.Resto)
                TotemSelect(TOTEM_AIR, "Grounding Totem");
            else if (Safe_KnownSpell("Windfury Totem") && _typeShaman == ShamanType.Enhance)
                TotemSelect(TOTEM_AIR, "Windfury Totem");
            else if (Safe_KnownSpell("Wrath of Air Totem") &&
                     (_typeShaman == ShamanType.Elemental || _typeShaman == ShamanType.Resto))
                TotemSelect(TOTEM_AIR, "Wrath of Air Totem");
            else
                TotemSelect(TOTEM_AIR, "None");

            Slog("^Totem Bar - Earth: {0}", _totemBar[TOTEM_EARTH]);
            Slog("^Totem Bar - Fire : {0}", _totemBar[TOTEM_FIRE]);
            Slog("^Totem Bar - Water: {0}", _totemBar[TOTEM_WATER]);
            Slog("^Totem Bar - Air  : {0}", _totemBar[TOTEM_AIR]);

            /*
            if (!Safe_AreSpellReagentsAvailable(sTotemName))
            {
                Wlog("warning: missing Relic necessary to cast '{0}' - spell not available", sTotemName);
                return false;
            }
             */
        }


        /// <summary>
        /// SetTotemsAsNeeded() - manages casting totems as called for by environment and
        /// user configuration values. This code uses:
        ///	    http://www.yawb.info/2009/08/25/learning-about-totems-tips-to-aid-your-growing-shamanism/
        /// as a guideline for totem usage while leveling.
        /// </summary>
        private void SetTotemsAsNeeded()
        {
            try
            {
                if (_cfg.TotemsDisabled)
                    return;

                // makes 4 LUA calls to get active totem info (1 per slot/family) so
                // .. make sure we don't get called more than once every 2 seconds
                // .. so we aren't spamming LUA calls
                if (_TotemCheckTimer.ElapsedMilliseconds < 4000)
                {
                    // if this isn't first time here since reset, then wait for 2 seconds
                    if (_TotemCheckTimer.ElapsedMilliseconds > 0)
                    {
                        return;
                    }

                    // otherwise, only 0 if first check after last .Reset
                    //  ..  so continue processing
                }

                if (TotemsWereSet() && _ptTotems.Distance(_me.Location) > _cfg.DistanceForTotemRecall)
                {
                    Dlog("Recalling Totems that were set {0:F1} yds away", _ptTotems.Distance(_me.Location));
                    RecallTotemsForMana();
                }

                _TotemCheckTimer.Reset();
                _TotemCheckTimer.Start();

                //-----
                // if you make it past the following gate, only limited tests are needed for each totem
                //-----
                if (_pvp.IsBattleground())
                    ;
                else if (IsFightStressful() || !_cfg.PVE_SaveForStress_TotemsSelected)
                    ;
                else
                {
                    Dlog("not setting totems until a stressful situation");
                    return;
                }

                // check which totems exist
                _totemExist[TOTEM_EARTH] = TotemExist(TOTEM_EARTH);
                _totemExist[TOTEM_FIRE] = TotemExist(TOTEM_FIRE);
                _totemExist[TOTEM_WATER] = TotemExist(TOTEM_WATER);
                _totemExist[TOTEM_AIR] = TotemExist(TOTEM_AIR);
                bool bAnyTotemsUp = _totemExist[TOTEM_EARTH] || _totemExist[TOTEM_FIRE] || _totemExist[TOTEM_WATER] ||
                                    _totemExist[TOTEM_AIR];

                Dlog("SetTotemsAsNeeded():  earth: " + _totemExist[TOTEM_EARTH] + "  fire: " + _totemExist[TOTEM_FIRE] +
                     "  water: " + _totemExist[TOTEM_WATER] + "  air: " + _totemExist[TOTEM_AIR]);

                _WereTotemsSet = _WereTotemsSet || bAnyTotemsUp;

                // Totem Bar Set
                //////////////////////////////////////////////////////////////////////
                if (!bAnyTotemsUp)
                {
                    string totemBar = "Call of the Elements";
                    if (Safe_KnownSpell(totemBar) && Safe_CastSpell(totemBar, SpellRange.NoCheck, SpellWait.NoWait))
                    {
                        _WereTotemsSet = true;
                        _ptTotems = _me.Location;
                        _totemExist[TOTEM_FIRE] = TotemExist(TOTEM_FIRE);
                        return;
                    }
                }

                // Earth Totems First
                //////////////////////////////////////////////////////////////////////
#if false
            if (!_totemExist[ TOTEM_EARTH] && (_countMeleeEnemy > 1 || _BigScaryGuyHittingMe))
            {
                if (Safe_KnownSpell("Stoneclaw Totem"))
                {
                    _totemExist[ TOTEM_EARTH] = Safe_CastSpell("Stoneclaw Totem");
                }
            }
#endif
                if ("NONE" != _totemBar[TOTEM_EARTH].ToUpper())
                {
                    if (!_totemExist[TOTEM_EARTH] && Safe_KnownSpell(_totemBar[TOTEM_EARTH]))
                        TotemCast(TOTEM_EARTH, _totemBar[TOTEM_EARTH]);

                    if (!_totemExist[TOTEM_EARTH] && _typeShaman == ShamanType.Enhance &&
                        Safe_KnownSpell("Strength of Earth Totem"))
                        TotemCast(TOTEM_EARTH, "Strength of Earth Totem");

                    if (!_totemExist[TOTEM_EARTH] && _typeShaman != ShamanType.Enhance &&
                        Safe_KnownSpell("Stoneskin Totem"))
                        TotemCast(TOTEM_EARTH, "Stoneskin Totem");
                }

                // Fire Totems
                //////////////////////////////////////////////////////////////////////
                if ("NONE" != _totemBar[TOTEM_FIRE].ToUpper() && !_totemExist[TOTEM_FIRE] &&
                    Safe_KnownSpell(_totemBar[TOTEM_FIRE]))
                    TotemCast(TOTEM_FIRE, _totemBar[TOTEM_FIRE]);

                if (!_totemExist[TOTEM_FIRE] && _countMeleeEnemy >= 3 && Safe_KnownSpell("Magma Totem"))
                    TotemCast(TOTEM_FIRE, "Magma Totem");

                if ("NONE" != _totemBar[TOTEM_FIRE].ToUpper())
                {
                    if (!_totemExist[TOTEM_FIRE] && _typeShaman != ShamanType.Enhance &&
                        Safe_KnownSpell("Totem of Wrath"))
                        TotemCast(TOTEM_FIRE, "Totem of Wrath");
                    if (!_totemExist[TOTEM_FIRE] && _typeShaman != ShamanType.Enhance &&
                        Safe_KnownSpell("Flametongue Totem"))
                        TotemCast(TOTEM_FIRE, "Flametongue Totem");
                    if (!_totemExist[TOTEM_FIRE] && Safe_KnownSpell("Searing Totem"))
                        TotemCast(TOTEM_FIRE, "Searing Totem");
                }

                // Water Totems
                //////////////////////////////////////////////////////////////////////
                if ("NONE" != _totemBar[TOTEM_WATER].ToUpper())
                {
                    if (!_totemExist[TOTEM_WATER] && Safe_KnownSpell(_totemBar[TOTEM_WATER]))
                        TotemCast(TOTEM_WATER, _totemBar[TOTEM_WATER]);

                    if (!_totemExist[TOTEM_WATER] && Safe_KnownSpell("Mana Spring Totem"))
                        TotemCast(TOTEM_WATER, "Mana Spring Totem");
                }

                // Air Totems
                //////////////////////////////////////////////////////////////////////
                if ("NONE" != _totemBar[TOTEM_AIR].ToUpper())
                {
                    if (!_totemExist[TOTEM_AIR] && Safe_KnownSpell(_totemBar[TOTEM_WATER]))
                        TotemCast(TOTEM_AIR, _totemBar[TOTEM_WATER]);
                    if (!_totemExist[TOTEM_AIR] && _typeShaman == ShamanType.Resto && Safe_KnownSpell("Grounding Totem"))
                        TotemCast(TOTEM_AIR, "Grounding Totem");
                    if (!_totemExist[TOTEM_AIR] && _typeShaman == ShamanType.Enhance &&
                        Safe_KnownSpell("Windfury Totem"))
                        TotemCast(TOTEM_AIR, "Windfury Totem");
                    if (!_totemExist[TOTEM_AIR] && _typeShaman == ShamanType.Elemental &&
                        Safe_KnownSpell("Wrath of Air Totem"))
                        TotemCast(TOTEM_AIR, "Wrath of Air Totem");
                }

                _WereTotemsSet = _WereTotemsSet || _totemExist[TOTEM_EARTH] || _totemExist[TOTEM_FIRE] ||
                                 _totemExist[TOTEM_WATER] || _totemExist[TOTEM_AIR];

                if (!bAnyTotemsUp && _WereTotemsSet)
                    _ptTotems = _me.Location;
            }
            catch (ThreadAbortException)
            {
                throw;
            }
            catch (Exception e)
            {
                Logging.WriteDebug("HB EXCEPTION in SetTotemsAsNeeded()");
                Logging.WriteException(e);
            }
        }

        private bool TotemsWereSet()
        {
            return _WereTotemsSet;
        }

        private double CheckDistanceForRecall()
        {
            double check = _cfg.DistanceForTotemRecall;
            if (_cfg.PVE_PullType == ConfigValues.TypeOfPull.Ranged || _typeShaman != ShamanType.Enhance)
            {
                check += _distForRangedPull*0.75;
            }

            return check;
        }

        public void RecallTotemsForMana()
        {
            if (_WereTotemsSet)
            {
                if (Safe_KnownSpell("Totemic Recall"))
                {
                    // set totem flag based on whether can cast spell yet
                    _WereTotemsSet = !Safe_CastSpell("Totemic Recall", SpellRange.NoCheck, SpellWait.NoWait);
                    if (!_WereTotemsSet)
                    {
                        _totemName[TOTEM_FIRE] = "";
                        _totemName[TOTEM_EARTH] = "";
                        _totemName[TOTEM_WATER] = "";
                        _totemName[TOTEM_AIR] = "";
                    }
                }
                else
                {
                    _WereTotemsSet = false;

                    if (_totemExist[TOTEM_FIRE])
                        TotemDestroy(TOTEM_FIRE);
                    if (_totemExist[TOTEM_EARTH])
                        TotemDestroy(TOTEM_EARTH);
                    if (_totemExist[TOTEM_WATER])
                        TotemDestroy(TOTEM_WATER);
                    if (_totemExist[TOTEM_AIR])
                        TotemDestroy(TOTEM_AIR);
                }

                _TotemCheckTimer.Reset();
            }
        }

        #endregion

        #region Item / Spell ID Lists

        /*
         * Following list of id's come from:
         * 
         *      http://www.wowhead.com
         * 
         */

        // Potion EntryId's taken from WoWHead
        private readonly List<uint> _potionHealthEid = new List<uint>
                                                           {
                                                               //=== RESTORATION POTIONS (HEALTH AND MANA)
                                                               40077,
                                                               // Crazy Alchemist's Potion 3500 (Alchemist)
                                                               34440,
                                                               // Mad Alchemist's Potion 2750   (Alchemist)
                                                               40087,
                                                               // Powerful Rejuvenation Potion 4125
                                                               22850,
                                                               // Super Rejuvenation Potion 2300
                                                               18253,
                                                               // Major Rejuvenation Potion 1760
                                                               9144,
                                                               // Wildvine Potion 1500
                                                               2456,
                                                               // Minor Rejuvenation Potion 150

                                                               //=== HEALTH POTIONS 
                                                               33447,
                                                               // Runic Healing Potion 4500

                                                               43569,
                                                               // Endless Healing Potion  2500
                                                               43531,
                                                               // Argent Healing Potion  2500
                                                               32947,
                                                               // Auchenai Healing Potion  2500
                                                               39671,
                                                               // Resurgent Healing Potion 2500
                                                               22829,
                                                               // Super Healing Potion 2500
                                                               33934,
                                                               // Crystal Healing Potion 2500
                                                               23822,
                                                               // Healing Potion Injector 2500
                                                               33092,
                                                               // Healing Potion Injector 2500

                                                               31852,
                                                               // Major Combat Healing Potion 1750
                                                               31853,
                                                               // Major Combat Healing Potion 1750
                                                               31839,
                                                               // Major Combat Healing Potion 1750
                                                               31838,
                                                               // Major Combat Healing Potion 1750
                                                               13446,
                                                               // Major Healing Potion 1750
                                                               28100,
                                                               // Volatile Healing Potion 1750 

                                                               18839,
                                                               // Combat Healing Potion 900 
                                                               3928,
                                                               // Superior Healing Potion 900
                                                               1710,
                                                               // Greater Healing Potion  585
                                                               929,
                                                               // Healing Potion  360
                                                               4596,
                                                               // Discolored Healing Potion 180
                                                               858,
                                                               // Lesser Healing Potion 180
                                                               118 // Minor Healing Potion 90
                                                           };

        // Mana Potion EntryId's taken from WoWHead
        private readonly List<uint> _potionManaEID = new List<uint>
                                                         {
                                                             //=== RESTORATION POTIONS (HEALTH AND MANA)
                                                             40077,
                                                             // Crazy Alchemist's Potion 4400 (Alchemist)
                                                             34440,
                                                             // Mad Alchemist's Potion 2750   (Alchemist)
                                                             40087,
                                                             // Powerful Rejuvenation Potion 4125
                                                             22850,
                                                             // Super Rejuvenation Potion 2300
                                                             18253,
                                                             // Major Rejuvenation Potion 1760
                                                             9144,
                                                             // Wildvine Potion 1500
                                                             2456,
                                                             // Minor Rejuvenation Potion 150

                                                             //=== MANA POTIONS 
                                                             43570,
                                                             // 3000 Endless Mana Potion 
                                                             33448,
                                                             // 4400 Runic Mana Potion
                                                             40067,
                                                             // 3000 Icy Mana Potion
                                                             31677,
                                                             // 3200 Fel Mana Potion
                                                             33093,
                                                             // 3000 Mana Potion Injector
                                                             43530,
                                                             // 3000 Argent Mana Potion
                                                             32948,
                                                             // 3000 Auchenai Mana Potion
                                                             22832,
                                                             // 3000 Super Mana Potion
                                                             28101,
                                                             // 2250 Unstable Mana Potion
                                                             13444,
                                                             // 2250 Major Mana Potion
                                                             13443,
                                                             // 1500 Superior Mana Potion
                                                             6149,
                                                             // 900 Greater Mana Potion
                                                             3827,
                                                             // 585 Mana Potion
                                                             3385,
                                                             // 360 Lesser Mana Potion
                                                             2455,
                                                             // 180 Minor Mana Potion
                                                         };

        // Bandage EntryId's taken from WoWHead
        private readonly List<uint> _bandageEID = new List<uint>
                                                      {
                                                          // ID,	BANDAGE NAME,           (Level, Healing)
                                                          34722,
                                                          // Heavy Frostweave,	(400, 5800)
                                                          34721,
                                                          // Frostweave,		    (350, 4800)
                                                          21991,
                                                          // Heavy Netherweave,	(325, 3400)
                                                          21990,
                                                          // Netherweave,		    (300, 2800)
                                                          14530,
                                                          // Heavy Runecloth,	    (225, 2000)
                                                          14529,
                                                          // Runecloth,		    (200, 1360)
                                                          8545,
                                                          // Heavy Mageweave,	    (175, 1104)
                                                          8544,
                                                          // Mageweave		    (150, 800)
                                                          6451,
                                                          // Heavy Silk,		    (125, 640)
                                                          6450,
                                                          // Silk			        (100, 400)
                                                          3531,
                                                          // Heavy Wool,		    ( 75, 301)
                                                          3530,
                                                          // Wool			        ( 50, 161)
                                                          2581,
                                                          // Heavy Linen,		    ( 20, 114)
                                                          1251,
                                                          // Linen		    (  1, 66)
                                                      };

        private readonly List<uint> _listFrostImmune = new List<uint>
                                                           {
                                                               24601,
                                                               // Steam Rager (65-71)
                                                               17358,
                                                               // Fouled Water Spirit (18-19)
                                                               3950,
                                                               // Minor Water Guardian (25)
                                                               14269,
                                                               // Seeker Aqualon (21)
                                                               3917,
                                                               // Befouled Water Elemental (23-25)
                                                               10757,
                                                               // Boiling Elemental (27-28)
                                                               10756,
                                                               // Scalding Elemental (28-29)
                                                               2761,
                                                               // Cresting Exile (38-39)
                                                               691,
                                                               // Lesser Water Elemental (35-37)
                                                               5461,
                                                               // Sea Elemental (46-49)
                                                               5462,
                                                               // Sea Spray (45-48)
                                                               8837,
                                                               // Muck Splash (47-49))
                                                               7132,
                                                               // Toxic Horror(53-54)
                                                               14458,
                                                               // Watery Invader (56-58)
                                                               20792,
                                                               // Bloodscale Elemental	(62-63)	
                                                               20090,
                                                               // Bloodscale Sentry (62-63)
                                                               20079,
                                                               // Darkcrest Sentry	(61-62)
                                                               17153,
                                                               // Lake Spirit (64-65)
                                                               17155,
                                                               // Lake Surger (64-66)
                                                               17154,
                                                               // Muck Spawn (63-66)
                                                               21059,
                                                               // Enraged Water Spirit	(68-69)
                                                               25419,
                                                               // Boiling Spirit (68-70)
                                                               25715,
                                                               // Frozen Elemental (65-71)
                                                               23919,
                                                               // Ice Elemental (64-69)
                                                               24228,
                                                               // Iceshard Elemental (70-71)	
                                                               26316,
                                                               // Crystalline Ice Elemental (73-74)
                                                               16570,
                                                               // Crazed Water Spirit (71-76)
                                                               28411,
                                                               // Frozen Earth	(76-77)
                                                               29436,
                                                               // Icetouched Earthrager (69-75)
                                                               29844,
                                                               // Icebound Revenant (78-80)
                                                               30633,
                                                               // Water Terror	(77-78)
                                                           };

        private readonly List<uint> _listFireImmune = new List<uint>
                                                          {
                                                              6073,
                                                              // Searing Infernal
                                                              4038,
                                                              // Burning Destroyer
                                                              4037,
                                                              // Burning Ravager
                                                              4036,
                                                              // Rogue Flame Spirit
                                                              2760,
                                                              // Burning Exile
                                                              5850,
                                                              // Blazing Elemental
                                                              5852,
                                                              // Inferno Elemental
                                                              5855,
                                                              // Magma Elemental
                                                              9878,
                                                              // Entropic Beast
                                                              9879,
                                                              // Entropic Horror
                                                              14460,
                                                              // Blazing Invader
                                                              6521,
                                                              // Living Blaze
                                                              6520,
                                                              // SScorching Elemental		
                                                              20514,
                                                              // Searing Elemental
                                                              21061,
                                                              // Enraged Fire Spirit	
                                                              29504,
                                                              // Seething Revenant	
                                                              6073,
                                                              // Searing Infernal
                                                              7136,
                                                              // Infernal Sentry
                                                              7135,
                                                              // Infernal Bodyguard
                                                              21419,
                                                              // Infernal Attacker

                                                              19261,
                                                              // Infernal Warbringer
                                                          };

        private readonly List<uint> _listNatureImmune = new List<uint>
                                                            {
                                                                18062,
                                                                // Enraged Crusher
                                                                11577,
                                                                // Whirlwind Stormwalker
                                                                11578,
                                                                // Whirlwind Shredder
                                                                11576,
                                                                // Whirlwind Ripper
                                                                4661,
                                                                // Gelkis Rumbler
                                                                832,
                                                                // Dust Devil		
                                                                4034,
                                                                // Enraged Stone Spirit
                                                                4035,
                                                                // Furious Stone Spirit
                                                                4499,
                                                                // Rok'Alim the Pounder
                                                                9377,
                                                                // Swirling Vortex
                                                                4120,
                                                                // Thundering Boulderkin
                                                                2258,
                                                                // Stone Fury
                                                                2592,
                                                                // Rumbling Exile
                                                                2762,
                                                                // Thundering Exile
                                                                2791,
                                                                // Enraged Rock Elemental
                                                                2919,
                                                                // Fam'retor Guardian
                                                                2736,
                                                                // GGreater Rock Elemental	
                                                                2735,
                                                                // Lesser Rock Elemental
                                                                92,
                                                                // Rock Elemental	
                                                                8667,
                                                                // Gusting Vortex
                                                                9396,
                                                                // Ground Pounder
                                                                5465,
                                                                // Land Rager
                                                                9397,
                                                                // Living Storm
                                                                14462,
                                                                // Thundering Invader
                                                                11745,
                                                                // Cyclone Warrior	
                                                                11746,
                                                                // Desert Rumbler
                                                                11744,
                                                                // Dust Stormer
                                                                14455,
                                                                // Whirling Invader	
                                                                17158,
                                                                // Dust Howler	
                                                                18062,
                                                                // Enraged Crusher
                                                                17160,
                                                                // Living Cyclone	
                                                                17157,
                                                                // Shattered Rumbler
                                                                17159,
                                                                // Storm Rager
                                                                17156,
                                                                // Tortured Earth Spirit
                                                                18882,
                                                                // Sundered Thunderer
                                                                20498,
                                                                // Sundered Shard
                                                                21060,
                                                                // Enraged Air Spirit
                                                                22115,
                                                                // Enraged Earth Shard
                                                                21050,
                                                                // Enraged Earth Spirit		
                                                                25415,
                                                                // Enraged Tempest
                                                                24229,
                                                                // Howling Cyclone	
                                                                24340,
                                                                // Rampaging Earth Elemental		
                                                                26407,
                                                                // Lightning Sentry
                                                                28784,
                                                                // Altar Warden
                                                                29124,
                                                                // Lifeblood Elemental	
                                                                28858,
                                                                // Storm Revenant
                                                            };


        private readonly List<string> _enchantElemental = new List<string>
                                                              {
                                                                  "Flametongue Weapon",
                                                                  "Windfury Weapon",
                                                                  "Rockbiter Weapon",
                                                                  "Frostbrand Weapon",
                                                              };

        private readonly List<string> _enchantEnhancementPVE_Mainhand = new List<string>
                                                                            {
                                                                                "Windfury Weapon",
                                                                                "Flametongue Weapon",
                                                                                "Rockbiter Weapon",
                                                                                "Frostbrand Weapon"
                                                                            };

        private readonly List<string> _enchantEnhancementPVE_Offhand = new List<string>
                                                                           {
                                                                               "Flametongue Weapon",
                                                                               "Windfury Weapon",
                                                                               "Rockbiter Weapon",
                                                                               "Frostbrand Weapon"
                                                                           };

        private readonly List<string> _enchantEnhancementPVP = new List<string>
                                                                   {
                                                                       "Flametongue Weapon",
                                                                       "Windfury Weapon",
                                                                       "Rockbiter Weapon",
                                                                       "Frostbrand Weapon"
                                                                   };

        private readonly List<string> _enchantResto = new List<string>
                                                          {
                                                              "Earthliving Weapon",
                                                              "Flametongue Weapon",
                                                              "Windfury Weapon",
                                                              "Rockbiter Weapon",
                                                              "Frostbrand Weapon"
                                                          };

        #endregion

        #region RAID HEALING FUNCTION

        private static bool WillChainHealHop(WoWUnit healTarget)
        {
            WoWPlayer player = null;
            var timer = new Stopwatch();
            double threshhold = _pvp.IsBattleground() ? _cfg.PVP_GroupNeedHeal : _cfg.RAF_GroupNeedHeal;
            timer.Start();

            if (healTarget == null)
                return false;

            try
            {
                player = ObjectManager.GetObjectsOfType<WoWPlayer>(false).Find(
                    p => p != null
                         && p.IsPlayer
                         && !p.IsPet
                         && p.IsAlive
                         && p.HealthPercent < threshhold
                         && healTarget.Location.Distance(p.Location) <= 12
                    );
            }
            catch (ThreadAbortException)
            {
                throw;
            }
            catch (Exception e)
            {
                Logging.WriteDebug("HB EXCEPTION in WillChainHealHop()");
                Logging.WriteException(e);
            }

            Dlog("WillChainHealHop(): took {0} ms", timer.ElapsedMilliseconds);
            return player != null;
        }

        private bool HealRaid()
        {
            bool WasHealCast = false;

            //            if (IsHealer() && _me.ManaPercent >= _cfg.RestHealthPercent && _me.HealthPercent >= _cfg.RestHealthPercent)
            if (IsHealer())
            {
                if (_me.ManaPercent >= _cfg.EmergencyManaPercent && _me.HealthPercent >= _cfg.EmergencyHealthPercent)
                {
                    double healPct = IsRAF() ? _cfg.RAF_GroupNeedHeal : _cfg.PVP_GroupNeedHeal;
                    WoWPlayer p = CC_PVP.ChooseHealTarget(healPct);
                    if (p != null)
                    {
                        double startHealth = p.HealthPercent;

                        Slog("^Heal Target: {0}[{1}] at {2:F1}% dist: {3:F1} in-los: {4}", p.Class, p.Level,
                             p.HealthPercent, p.Distance, p.InLineOfSight);
                        WasHealCast = HealPlayer(p);

                        // wait for lagged update of player health if we have the time and not urgent to heal again
                        if (WasHealCast && _pvp.IsBattleground() && p.HealthPercent > 40)
                        {
                            var lagTimer = new Stopwatch();
                            lagTimer.Start();
                            while (lagTimer.ElapsedMilliseconds < 400 && Math.Abs(p.HealthPercent - startHealth) < 5)
                            {
                                Thread.Sleep(100);
                            }
                        }
                    }

                    if (!WasHealCast && IsRAF() && Safe_KnownSpell("Earth Shield"))
                    {
                        List<WoWPlayer> grp = _me.IsInRaid ? _me.RaidMembers : _me.PartyMembers;
                        List<WoWPlayer> mbrs = (from m in grp
                                                where m.IsAlive
                                                orderby m.MaxHealth descending
                                                select m
                                               ).ToList();

                        if (mbrs != null && mbrs.Count > 0)
                        {
                            WoWPlayer tank = mbrs[0];
                            if (!tank.Buffs.ContainsKey("Earth Shield"))
                            {
                                Safe_SetCurrentTarget(tank);
                                Safe_CastSpell("Earth Shield");
                            }
                        }
                    }
                }
            }

            return WasHealCast;
        }

        private bool HealPlayer(WoWPlayer p)
        {
            bool WasHealCast = false;
            double targetHealth = (p == null ? _me.HealthPercent : p.HealthPercent);

            if (p != null && p.Dead)
                Dlog("Heal target is dead");
            else if (p != null && p.Location.Distance(_me.Location) > 35.0)
                Dlog("Heal target out of range");
            else
            {
                WoWUnit saveTarget = _me.CurrentTarget;
                if (p != null)
                    p.Target();

                Safe_Dismount();
                Safe_StopMoving();

                // wait for any current spell cast... this os overly cautious...
                // if in danger of dying, fastest heal possible
                if (targetHealth < _cfg.EmergencyHealthPercent && _me.Combat)
                {
                    if (Safe_KnownSpell("Nature's Swiftness"))
                    {
                        if (Safe_KnownSpell("Tidal Force"))
                        {
                            Safe_CastSpell("Tidal Force", SpellRange.NoCheck, SpellWait.NoWait);
                        }

                        WasHealCast = Safe_CastSpell("Nature's Swiftness", SpellRange.NoCheck, SpellWait.NoWait);
                        if (!WasHealCast)
                            Dlog(" Attempted Oh S@#$ heal but Nature's Swiftness not available");
                        else
                        {
                            WasHealCast = Safe_CastSpell("Healing Wave", SpellRange.NoCheck, SpellWait.Complete);
                            if (!WasHealCast)
                            {
                                WasHealCast = Safe_CastSpell("Lesser Healing Wave", SpellRange.NoCheck,
                                                             SpellWait.Complete);
                            }

                            if (WasHealCast)
                                Slog("Big Heals - clicked the Oh S@#$ button!");
                            else
                                Slog("Attempted Oh S@#$ heal but Healing Wave/LHW couldn't cast");
                        }
                    }
                }

                if (!WasHealCast && Safe_KnownSpell("Riptide"))
                {
                    WasHealCast = Safe_CastSpell("Riptide", SpellRange.NoCheck, SpellWait.NoWait);
                }

                if (!WasHealCast && p != null && Safe_KnownSpell("Chain Heal") && WillChainHealHop(p))
                {
                    WasHealCast = Safe_CastSpell("Chain Heal", SpellRange.NoCheck, SpellWait.Complete);
                }

                if (!WasHealCast &&
                    (!_pvp.IsBattleground() || countEnemy == 0 || !Safe_KnownSpell("Lesser Healing Wave")))
                {
                    Dlog(" Casting Healing Wave because pvp={0} and countEnemy={1}", _pvp.IsBattleground(), countEnemy);
                    WasHealCast = Safe_CastSpell("Healing Wave", SpellRange.NoCheck, SpellWait.Complete);
                }

                if (!WasHealCast && Safe_KnownSpell("Lesser Healing Wave"))
                {
                    WasHealCast = Safe_CastSpell("Lesser Healing Wave", SpellRange.NoCheck, SpellWait.Complete);
                }

                if (saveTarget == null)
                    _me.ClearTarget();
                else
                    Safe_SetCurrentTarget(saveTarget);
            }

            return WasHealCast;
        }

        #endregion

        /// <summary>
        /// Custom Class PVP Support.  Provides methods useful for adding PVP support to PVE
        /// based Custom Classes in HonorBuddy.  This includes both general PVP considerations
        /// and healing.
        /// </summary>
        public class CC_PVP
        {
            private volatile LocalPlayer _me = ObjectManager.Me;

            private static List<WoWPlayer> _healTargets;
            private static readonly Stopwatch RefreshTimer = new Stopwatch();

            public static bool IsAlliance;
            public static bool IsHorde;

            public CC_PVP()
            {
                IsAlliance = _me.IsAlliance;
                IsHorde = _me.IsHorde;
                RefreshTimer.Reset();
            }

            /// <summary>
            /// Checks to see if you are currently in a Battleground
            /// </summary>
            /// <returns>true if in a battleground, false otherwise</returns>
            public bool IsBattleground()
            {
                //            return false;
                return Battlegrounds.IsInsideBattleground;
            }

            /// <summary>
            /// Chooses a nearby target for healing.  Selection is based upon
            /// which nearby friendly needs heals.  Includes _me in list so
            /// will handle self-healing to you low
            /// </summary>
            /// <returns>WOWPlayer reference of nearby player needing heals</returns>
            public static WoWPlayer ChooseHealTarget(double healLessThan)
            {
                // use timer to ensure we aren't constantly rebuilding the list
                // .. player health and distance are very dynamic, but the number of players
                // .. in the vicinity won't change drastically in that time
                //--- NOTE:  timer is initially zero so first call builds list
                if (RefreshTimer.ElapsedMilliseconds > 5000)
                {
                    RefreshTimer.Reset();
                }

                // sort the list by healing priority
                if (!RefreshTimer.IsRunning)
                {
                    CreateHealTargetList();
                    RefreshTimer.Start();
                }

                _healTargets.Sort(CompareHealPriority);

                /*-----------------
                for (int b = 0; b < _healTargets.Count; b++)
                {
                    Slog("  Found: {0}[{1}] at {2:F0}% dist: {3:F1} in-los: {4}", _healTargets[b].Name, _healTargets[b].Level, _healTargets[b].HealthPercent, _healTargets[b].Distance, _healTargets[b].InLineOfSight );
                }
            
                Slog("  Total of " + _healTargets.Count);
                ------------------*/

                for (int a = 0; a < _healTargets.Count; a++)
                {
                    try
                    {
                        if (_healTargets[a] == null || !_healTargets[a].IsValid)
                            continue;
                    }
                    catch (ThreadAbortException)
                    {
                        throw;
                    }
                    catch
                    {
                        // if exception dealing with this WoWUnit, then try next in array
                        continue;
                    }

                    // stop looking in sorted list if we reach 85% health
                    if (_healTargets[a].HealthPercent > healLessThan)
                    {
                        break;
                    }

                    // since we don't rebuild the list each time, always need to retest for dead players
                    if (_healTargets[a].Dead || _healTargets[a].IsGhost || _healTargets[a].HealthPercent < 0.1)
                        ;
                    else if (_healTargets[a].Distance < 37 && _healTargets[a].InLineOfSight)
                    {
                        // Slog("Heal Target: {0}[{1}] at {2:F0}% dist: {3:F1} in-los: {4}", _healTargets[a].Name, _healTargets[a].Level, _healTargets[a].HealthPercent, _healTargets[a].Distance, _healTargets[a].InLineOfSight);
                        return _healTargets[a];
                    }
                }

                return null;
            }


            private static int CompareHealPriority(WoWUnit x, WoWUnit y)
            {
                try
                {
                    if (x == null || y == null)
                        return 0;

                    double healthDiff = x.HealthPercent - y.HealthPercent;

                    if (healthDiff < 0.0)
                        return -1;

                    if (healthDiff > 0.0)
                        return 1;
                }
                catch (ThreadAbortException)
                {
                    throw;
                }
                catch
                {
                    Dlog(">>> EXCEPTION: a heal target released or rezzed -- ignoring");
                }

                return 0;

                /*
                 * -- Eventually determine a priority based upon general health, 
                 * -- targets survivability, and targets savability (my word).
                 * -- this would factor in can they be saved, are they a plater 
                 * -- wearer, do they have a self-heal and mana, etc.
                 * 
                const double _priorityTiers = 5;

                int xHealthPriority = (int)Math.Ceiling(x.HealthPercent / _priorityTiers);
                int yHealthPriority = (int)Math.Ceiling(y.HealthPercent / _priorityTiers);

                return xHealthPriority - yHealthPriority;
                */
            }

            private static void CreateHealTargetList()
            {
                List<WoWPlayer> plist = ObjectManager.Me.RaidMembers.Count > 0
                                            ? ObjectManager.Me.RaidMembers
                                            : ObjectManager.Me.PartyMembers;
#if true
                _healTargets = plist.FindAll(
                    unit =>
                    unit.Distance <= 50.0
                    && unit.HealthPercent >= 0.1
                    // && unit.IsAlive 
                    // && unit.Guid != ObjectManager.Me.Guid
                    );
#else
            _healTargets = new List<WoWPlayer>();
            foreach (WoWPlayer p in plist)
            {
                if (p.Distance > 50 || p.Dead)
                    continue;

                if (p.Guid == _me.Guid)
                    continue;

                if (p.IsHorde != _me.IsHorde)
                    continue;

                if (p.HealthPercent < 0.1)         // players waiting on spirit rez pass the 
                    continue;                       //  .. the unit.Dead test above for some reason

                //               Slog("Heal target: " + p.Class + "-" + p.Name + "[" + p.Level + "]");
                _healTargets.Add(p);
            }
#endif
                if (_healTargets.Count > 1)
                {
                    _healTargets.Sort(CompareHealPriority);
                }
            }
        }

        public class TalentGroup
        {
            public string[] TabName = new string[4];
            public int[] TabPoints = new int[4];
            public int IdxGroup;

            public int TotalPoints
            {
                get
                {
                    int nPoints = 0;
                    for (int iTab = 1; iTab <= 3; iTab++)
                    {
                        nPoints += TabPoints[iTab];
                    }

                    return nPoints;
                }
            }

            public int Spec()
            {
                int nSpec = 0;
                if (TabPoints[1] >= (TabPoints[2] + TabPoints[3]))
                    nSpec = 1;
                else if (TabPoints[2] >= (TabPoints[1] + TabPoints[3]))
                    nSpec = 2;
                else if (TabPoints[3] >= (TabPoints[1] + TabPoints[2]))
                    nSpec = 3;

                return nSpec;
            }

            public bool Load(int nGroup)
            {
                int nTab;

                IdxGroup = nGroup;

                for (nTab = 1; nTab <= 3; nTab++)
                {
                    try
                    {
                        List<string> tabInfo =
                            Lua.LuaGetReturnValue("return GetTalentTabInfo(" + nTab + ",false,false," + IdxGroup + ")",
                                                  "hawker.lua");

                        if (Equals(null, tabInfo))
                            return false;

                        TabName[nTab] = tabInfo[0];
                        TabPoints[nTab] = Convert.ToInt32(tabInfo[2]);
                    }
                    catch (ThreadAbortException)
                    {
                        throw;
                    }
                    catch (Exception ex)
                    {
                        Logging.WriteDebug(">>> Exception in TalentGroup.Load()");
                        Logging.WriteException(ex);
                    }
                }

                return false;
            }

            public bool IsActiveGroup()
            {
                return GetActiveGroup() == IdxGroup;
            }

            public int GetActiveGroup()
            {
                List<string> activeTalents = Lua.LuaGetReturnValue("return GetActiveTalentGroup(false,false)",
                                                                   "hawker.lua");

                if (!Equals(null, activeTalents))
                {
                    int nActiveGroup = Convert.ToInt32(activeTalents[0]);
                    return nActiveGroup;
                }
                return 0;
            }

            public void ActivateGroup()
            {
                Lua.DoString("SetActiveTalentGroup(" + IdxGroup + ")", "hawker.lua");
            }

            public int GetNumGroups()
            {
                List<string> numberOfGroups = Lua.LuaGetReturnValue("return GetNumTalentGroups(false,false)",
                                                                    "hawker.lua");

                if (!Equals(null, numberOfGroups))
                {
                    int cntGroup = Convert.ToInt32(numberOfGroups[0]);
                    return cntGroup;
                }
                return 0;
            }

            public int GetTalentInfo(int idxTab, int idxTalent)
            {
                string sLuaCmd = String.Format("return GetTalentInfo( {0}, {1});", idxTab, idxTalent);
                List<string> retList = Lua.LuaGetReturnValue(sLuaCmd, "hawker.lua");
                if (Equals(null, retList))
                {
                    Slog("ERROR:  Talent {0}, {1} does not exist -- Notify CC developer", idxTab, idxTalent);
                    return 0;
                }

                return Convert.ToInt32(retList[4]);
            }
        }


        // public override bool WantButton { get { return true; } }
        public override bool WantButton
        {
            get { return true; }
        }

#if    BUNDLED_WITH_HONORBUDDY

        public override void OnButtonPress()
        {
            Process.Start("\"" + ConfigFilename + "\"");
        }

#else
        private Config.ConfigForm _frm;

        public override void OnButtonPress()
        {
            if (_frm == null)
                _frm = new Config.ConfigForm();

            Dlog(" About to show dialog");
            System.Windows.Forms.DialogResult rc = _frm.ShowDialog();
            if (rc == System.Windows.Forms.DialogResult.OK)
            {
                _cfg.DebugDump();
                try
                {
                    _cfg.Save(ConfigFilename);
                    Log("Options saved to ShamWOW-realm-char.config");
                }
                catch (System.Threading.ThreadAbortException) { throw; }
                catch (Exception e)
                {
                    Logging.WriteDebug("EXCEPTION Saving to ShamWOW-realm-char.config");
                    Logging.WriteException(e);
                }

                // TotemSetupBar(); // just for debug atm
                _needTotemBarSetup = true;
                _needClearWeaponEnchants = true;
            }
        }
#endif
    }
}

