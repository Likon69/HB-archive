﻿using System;
using System.IO;
using System.Reflection;
using System.Xml.Linq;
using Styx;
using Styx.Helpers;
using Styx.Common;

namespace Talented
{
    class TalentedSettings : Settings
    {
        public static TalentedSettings Instance = new TalentedSettings();

        public TalentedSettings() : base(Path.Combine(Path.Combine(Utilities.AssemblyDirectory, "Settings"), 
            string.Format("Talented2Settings_{0}.xml", StyxWoW.Me.Name)))
        {
        }

        public static readonly string PluginFolderPath = Path.Combine(Path.GetDirectoryName(Assembly.GetEntryAssembly().Location), Path.Combine("Plugins", "Talented2"));

        [Setting(Explanation = "The name of the last used Talent Build."), DefaultValue("")]
        public string ChoosenTalentBuildName { get; set; }

        [Setting(Explanation = "The class of the last used Talent Build."), DefaultValue(WoWClass.None)]
        public WoWClass ChoosenTalentClass { get; set; }

        [Setting]
        [DefaultValue(true)]
        public bool FirstUseAfterChange { get; set; }

        public TalentTree ChoosenTalentBuild
        {
            get
            {
                if (string.IsNullOrEmpty(ChoosenTalentBuildName) || ChoosenTalentClass == WoWClass.None)
                    return null;

                var dataDirectory = Path.Combine(Utilities.AssemblyDirectory, "Data");
                var talentBuildPath = Path.Combine(dataDirectory, "Talent Builds");
                string[] files = Directory.GetFiles(talentBuildPath, "*.xml", SearchOption.AllDirectories);
                for (int i = 0; i < files.Length; i++)
                {
                    string file = files[i];

                    TalentTree talentTree = TalentTree.FromXml(XElement.Load(file));
                    if (talentTree != null && talentTree.BuildName == ChoosenTalentBuildName && talentTree.Class == ChoosenTalentClass)
                        return talentTree;

                }

                return null;
            }
        }
    }
}
