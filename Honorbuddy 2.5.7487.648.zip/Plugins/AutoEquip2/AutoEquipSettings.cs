﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using Styx.Common;
using Styx.CommonBot.Inventory;
using Styx.Helpers;
using DefaultValue = Styx.Helpers.DefaultValueAttribute;

namespace Styx.Bot.Plugins.AutoEquip2
{
    public class AutoEquipSettings : Settings
    {
        private static AutoEquipSettings _instance;

        public AutoEquipSettings()
            : base(Path.Combine(Path.Combine(Utilities.AssemblyDirectory, "Settings"), string.Format("AutoEquipSettings_{0}.xml", StyxWoW.Me.Name)))
        {
            if (IgnoreInvTypes == null)
            {
                IgnoreInvTypes = new[] { InventoryType.None};
            }
            if (ProtectedSlots == null)
            {
                ProtectedSlots = new[] { InventorySlot.None };
            }
        }

        public static AutoEquipSettings Instance { get { return _instance ?? (_instance = new AutoEquipSettings()); } }

        #region Category: Item Types

        [Setting]
        [DefaultValue(false)]
        [Category("项目类型")]
        [DisplayName("装备紫色")]
        [Description("【False不装备 True装备】是否触发自动装备紫色装备")]
        public bool EquipPurples { get; set; }

        [Setting]
        [DefaultValue(true)]
        [Category("项目类型")]
        [DisplayName("蓝色装备")]
        [Description("【False不装备 True装备】是否触发自动装备蓝色装备")]
        public bool EquipBlues { get; set; }

        [Setting]
        [DefaultValue(true)]
        [Category("项目类型")]
        [DisplayName("绿色装备")]
        [Description("【False不装备 True装备】是否触发自动装备绿色装备")]
        public bool EquipGreens { get; set; }

        [Setting] 
        [DefaultValue(true)]
        [Category("项目类型")]
        [DisplayName("白色装备")]
        [Description("【False不装备 True装备】是否触发自动装备白色装备")]
        public bool EquipWhites { get; set; }

        [Setting]
        [DefaultValue(false)]
        [Category("项目类型")]
        [DisplayName("灰色装备")]
        [Description("【False不装备 True装备】是否触发自动装备灰色装备")]
        public bool EquipGrays { get; set; }

        [Setting]
        [DefaultValue(false)]
        [Category("项目类型")]
        [DisplayName("装备传家宝")]
        [Description("【False不装备 True装备】是否触发自动装备传家宝")]
        public bool EquipHeirlooms { get; set; }

        [Setting]
        [DefaultValue(true)]
        [Category("装绑 项目类型")]
        [DisplayName("装备 装绑绿色装备")]
        [Description("【False不装备 True装备】是否触发自动装备装绑绿色装备")]
        public bool EquipBoEGreens { get; set; }

        [Setting]
        [DefaultValue(true)]
        [Category("装绑 项目类型")]
        [DisplayName("装备 装绑蓝色装备")]
        [Description("【False不装备 True装备】是否触发自动装备装绑蓝色装备")]
        public bool EquipBoEBlues { get; set; }

        [Setting]
        [DefaultValue(false)]
        [Category("装绑 项目类型")]
        [DisplayName("装绑 装绑史诗装备")]
        [Description("【False不装备 True装备】是否触发自动装备装绑史诗装备")]
        public bool EquipBoEPurples { get; set; }

        #endregion

        #region Category: Protected Slots and Types 

        [Setting]
        [Category("保护和忽略类型")]
        [DisplayName("忽略装备类型")]
        [Description("选取该装备时将会被忽略.不会被装备.")]
        public InventoryType[] IgnoreInvTypes { get; set; }

        [Setting]
        [Category("保护和忽略类型")]
        [DisplayName("保护装备")]
        [Description("选取该装备时将会被忽略.不会被更换.")]
        public InventorySlot[] ProtectedSlots { get; set; }

        [Setting]
        [DefaultValue(false)]
        [Category("保护和忽略类型")]
        [DisplayName("更换传家宝")]
        [Description("【False不装备 True装备】如果启用将会更换传家宝")]
        public bool ReplaceHeirlooms { get; set; }

        #endregion

        #region Category: General

        [Setting]
        [DefaultValue(true)]
        [Category("一般")]
        [DisplayName("装备物品")]
        [Description("【False不装备 True装备】开启此项会自动装备比身上好的物品")]
        public bool AutoEquipItems { get; set; }

        [Setting]
        [DefaultValue(true)]
        [Category("一般")]
        [DisplayName("装备背包")]
        [Description("【False不装备 True装备】开启此项会自动装备大的背包.")]
        public bool AutoEquipBags { get; set; }

        [Setting]
        [DefaultValue(false)]
        [Category("一般")]
        [DisplayName("包括附魔")]
        [Description("【False不附魔 True附魔】自动切换装备计算得分时包括附魔物品.")]
        public bool IncludeEnchants { get; set; }

        [Setting]
        [DefaultValue(WeaponStyle.None)]
        [Category("一般")]
        [DisplayName("武器选择")]
        [Description("下拉选择，依次是-[无] [单手武器加副手] [单手武器双持] [双手武器][远程武器]")]
        public WeaponStyle WeaponStyle { get; set; }

        [Setting]
        [DefaultValue(WeaponType.All)]
        [Category("一般")]
        [DisplayName("武器类型")]
        [Description("选择只装备某种类型的武器 依次是-[无][斧][匕首][拳套][锤][长柄][矛][法杖][剑][弓][全部].")]
        [Editor(typeof(FlagEnumUIEditor), typeof(System.Drawing.Design.UITypeEditor))]
        public WeaponType WeaponType { get; set; }

        #endregion

        #region Category: Loot Rolling

        [Setting]
        [DefaultValue(true)]
        [Category("Roll点")]
        [DisplayName("Roll点 需求装备")]
        [Description("【False不需求 True需求】如果在副本中出的装备比自身的好就会需求，比自身的低会贪婪")]
        public bool RollForLootInDungeons { get; set; }

        #endregion

        #region Category: Disenchanting

        [Setting]
        [DefaultValue(true)]
        [Category("分解")]
        [DisplayName("分解装备")]
        [Description("【False不分解 True分解】当获取装备是否分解该装备")]
        public bool RollForLootDE { get; set; }

        [Setting]
        [DefaultValue(true)]
        [Category("分解")]
        [DisplayName("分解绿色装备?")]
        [Description("【False不分解 True分解】当获取装备是否分解该装备")]
        public bool DisenchantBoEGreens { get; set; }

        [Setting]
        [DefaultValue(true)]
        [Category("分解")]
        [DisplayName("分解蓝色拾取绑定")]
        [Description("【False不分解 True分解】当获取装备是否分解该装备.")]
        public bool DisenchantBoPBlues { get; set; }

        [Setting]
        [DefaultValue(false)]
        [Category("分解")]
        [DisplayName("分解蓝色装备绑定")]
        [Description("【False不分解 True分解】当获取装备是否分解该装备")]
        public bool DisenchantBoEBlues { get; set; }

        [Setting]
        [DefaultValue(true)]
        [Category("分解")]
        [DisplayName("分解紫色拾取绑定")]
        [Description("【False不分解 True分解】当获取装备是否分解该装备")]
        public bool DisenchantBoEPurples { get; set; }

        [Setting]
        [DefaultValue(false)]
        [Category("分解")]
        [DisplayName("分解紫色装备绑定")]
        [Description("Toggles if AutoEquip will select disenchant for BoE purple items when rolling for loot.")]
        public bool DisenchantBoPPurples { get; set; }

        #endregion
    }

    public enum WeaponStyle
    {
        None,
        OneHanderAndShield,
        DualWield,
        TwoHander,
        Ranged
    }

    [Flags]
    public enum WeaponType
    {
        None = 0x0,
        Axe = 0x1,
        Dagger = 0x2,
        Fist = 0x4,
        Mace = 0x8,
        Polearm = 0x10,
        Spear = 0x20,
        Staff = 0x40,
        Sword = 0x80,
        Ranged = 0x100,
        All = Axe | Mace | Sword | Dagger | Polearm | Spear | Staff | Fist | Ranged,
    }
}
