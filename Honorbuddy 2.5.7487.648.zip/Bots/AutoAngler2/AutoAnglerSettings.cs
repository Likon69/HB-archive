﻿using System.ComponentModel;
using Styx.Helpers;

namespace HighVoltz
{
    public class AutoAnglerSettings : Settings
    {
        public AutoAnglerSettings(string path) : base(path)
        {
            Instance = this;
            Load();
        }

        public static AutoAnglerSettings Instance { get; private set; }

        [Setting]
		[Styx.Helpers.DefaultValue(0u)]
		[Category("武器")]
		[DisplayName("主手")]
		[Description("进入战斗后切换主手武器ID")]
		public uint MainHand { get; set; }

        [Setting]
		[Styx.Helpers.DefaultValue(0u)]
		[Category("武器")]
		[DisplayName("副手")]
		[Description("进入战斗后切换副手武器ID")]
		public uint OffHand { get; set; }

        [Setting]
		[Styx.Helpers.DefaultValue(true)]
		[Category("钓鱼")]
		[DisplayName("鱼点钓鱼")]
		[Description("从鱼点中钓鱼。")]
        public bool Poolfishing { get; set; }

        [Setting]
		[Styx.Helpers.DefaultValue(PathingType.Circle)]
		[Category("钓鱼")]
		[DisplayName("路径类型")]
        [Description("Circle：从第一个点出发，结束于第一个点。Bounce：从第一个点出发，至最后一点后反向返回第一个点。")]
        public PathingType PathingType { get; set; }

        [Setting]
		[Styx.Helpers.DefaultValue(true)]
		[Category("钓鱼")]
		[DisplayName("飞行")]
		[Description("设置true则开启飞行模式，false则使用地面坐骑。")]
        public bool Fly { get; set; }

        [Setting]
		[Styx.Helpers.DefaultValue(true)]
		[Category("钓鱼")]
		[DisplayName("水上行走")]
		[Description("设置true则使用水上行走，否则使用种族天赋或其他。")]
        public bool UseWaterWalking { get; set; }

        [Setting]
		[Styx.Helpers.DefaultValue(false)]
		[Category("钓鱼")]
		[DisplayName("避开熔岩")]
		[Description("设置true则会尝试避免降落在熔岩中。如果设置为true有些水面漂浮物（如浮冰）将会被列入黑名单。")]
        public bool AvoidLava { get; set; }

        [Setting]
		[Styx.Helpers.DefaultValue(5)]
		[Category("高级")]
		[DisplayName("在鱼点最大时间")]
		[Description("花费在一个鱼点上的最大时间（分钟）")]
        public int MaxTimeAtPool { get; set; }

        [Setting]
		[Styx.Helpers.DefaultValue(15)]
		[Category("高级")]
		[DisplayName("最大拉杆失败次数")]
		[Description("最大拉杆失败次数前往下一个鱼点")]
        public int MaxFailedCasts { get; set; }


        [Setting]
		[Styx.Helpers.DefaultValue(15f)]
		[Category("高级")]
		[DisplayName("路径精度")]
		[Description("当bot在当前热点距离内，然后循环至下一热点，仅限飞行模式（有待验证）")]
        public float PathPrecision { get; set; }

        [Setting]
		[Styx.Helpers.DefaultValue(false)]
		[Category("钓鱼")]		
		[DisplayName("抢鱼点")]
		[Description("设置true则和其他玩家抢鱼点")]
        public bool NinjaNodes { get; set; }

        [Setting]
		[Styx.Helpers.DefaultValue(40)]
		[Category("高级")]
		[DisplayName("追踪步长")]
		[Description("360度区域内追踪线数量。值越高越有可能找到着陆点。建议设置为20的倍数。")]
        public int TraceStep { get; set; }

        [Setting]
		[Styx.Helpers.DefaultValue(10)]
		[Category("高级")]
		[DisplayName("距离最小距离范围")]
		[Description("距离鱼点最小范围，推荐10-14")]
        public int MinPoolRange { get; set; }

        [Setting]
		[Styx.Helpers.DefaultValue(20)]
		[Category("高级")]
		[DisplayName("最大距离范围")]
		[Description("距离鱼点最大范围，22为最大，推荐18-22（20最佳）")]
        public int MaxPoolRange { get; set; }

        [Setting]
		[Styx.Helpers.DefaultValue(0.5f)]
		[Category("高级")]
		[DisplayName("距离范围步长")]
        [Description("当Bot无法找到一个着陆点，则则增加值直到等于最大距离范围。可以使用小数。")]
        public float PoolRangeStep { get; set; }

        [Setting]
		[Styx.Helpers.DefaultValue("")]
		[DisplayName("最后加载脚本")]
        public string LastLoadedProfile { get; set; }

        [Setting]
		[Styx.Helpers.DefaultValue(false)]
		[DisplayName("拾取")]
		[Description("如果设置为true，则Bot将尝试拾取怪物尸体")]
        public bool LootNPCs { get; set; }

        [Setting]
		[Styx.Helpers.DefaultValue(0)]
		[DisplayName("当前版本")]
        public int CurrentRevision { get; set; }
    }
}