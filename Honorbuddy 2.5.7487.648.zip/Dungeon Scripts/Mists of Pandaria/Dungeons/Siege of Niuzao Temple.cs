﻿//#define USE_DUNGEONBUDDY_DLL

using System;
using System.Collections.Generic;
using System.Linq;
using CommonBehaviors.Actions;
using Styx;
using Styx.Common.Helpers;
using Styx.CommonBot;
using Styx.CommonBot.Frames;
using Styx.Helpers;
using Styx.Patchables;
using Styx.Pathing;
using Styx.TreeSharp;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using Styx.WoWInternals.World;
using Action = Styx.TreeSharp.Action;
#if USE_DUNGEONBUDDY_DLL
using Bots.DungeonBuddyDll;
using Bots.DungeonBuddyDll.Profiles;
using Bots.DungeonBuddyDll.Attributes;
using Bots.DungeonBuddyDll.Helpers;
using AvoidanceManager = Bots.DungeonBuddyDll.Avoidance.AvoidanceManager;

namespace Bots.DungeonBuddyDll.Dungeon_Scripts.Mists_of_Pandaria
#else
    using Bots.DungeonBuddy.Profiles;
    using Bots.DungeonBuddy.Attributes;
    using Bots.DungeonBuddy.Helpers;
    using AvoidanceManager = Bots.DungeonBuddy.Avoidance.AvoidanceManager;
namespace Bots.DungeonBuddy.Dungeon_Scripts.Mists_of_Pandaria
#endif
{
    public class Siege_OfNiuzaoTemple : Dungeon
    {
        #region Overrides of Dungeon

        public override uint DungeonId
        {
            get { return 630; }
        }

        public override WoWPoint Entrance
        {
            get { return new WoWPoint(1441.83, 5089.116, 139.3459); }
        }

        public override void RemoveTargetsFilter(List<WoWObject> units)
        {
            units.RemoveAll(
                ret =>
                {
                    var unit = ret.ToUnit();
                    if (unit != null)
                    {
                        if (_commanderVojakAdds.Contains(unit.Entry) && Me.IsTank() && unit.ZDiff > 5)
                            return true;
                        if ((unit.Entry == AmberWingId && Me.IsMelee()) || unit.Entry == SikthikFlyerId)
                            return true;
                        if (unit.Entry == SikthikDemolisherId && Me.IsTank())
                            return true;
                        if (unit.Entry == CommanderVojakId && Me.IsMelee() && (unit.HasAura("Thousand Blades") || unit.HasAura("Dashing Strike")))
                            return true;
                        if (unit.Entry == GeneralPavalakId && unit.HasAura("Bulwark"))
                            return true;
                    }
                    return false;
                });
        }

        public override void IncludeTargetsFilter(List<WoWObject> incomingunits, HashSet<WoWObject> outgoingunits)
        {
            foreach (var obj in incomingunits)
            {
                var unit = obj as WoWUnit;
                if (unit != null)
                {
                    if (unit.Entry == SikthikDemolisherId && unit.Y < 5380 && Me.IsRange() && Me.IsDps())
                        outgoingunits.Add(unit);

                    if ((_commanderVojakAdds.Contains(unit.Entry) || unit.Entry == CommanderVojakId) && Me.IsTank() && unit.ZDiff <= 5)
                        outgoingunits.Add(unit);
                }
            }
        }

        public override void WeighTargetsFilter(List<Targeting.TargetPriority> units)
        {
            foreach (var priority in units)
            {
                var unit = priority.Object as WoWUnit;
                if (unit != null)
                {
                    if (unit.Entry == SikthikDemolisherId)
                        priority.Score += 5500;

                    if (unit.Entry == SikthikWarriorId && Me.IsDps())
                        priority.Score = +5000;
                }
            }
        }

        #endregion

        private const uint SapPuddleId = 61965;
        private const uint SapPuddle2Id = 61579;
        private const uint SapPuddleBossId = 61613;
        private const uint VizierJinbakId = 61567;
        private const uint AmberWingId = 61699;

        private const int DetonateId = 120001;
        private const uint CommanderVojakId = 61634;
        private const uint SikthikDemolisherId = 61670;
        private const uint HardenResin = 213174;
        private const uint SikthikWarriorId = 61701;
        private const uint SikthikSwarmerId = 63106;
        private const uint SikthikFlyerId = 62091;
        private const uint ShadoPanPrisonerId = 64520;
        private const uint SomewhereInsideQuestId = 31365;
        private const uint CageId = 213935;
        private const uint GeneralPavalakId = 61485;
        private const uint SikthikSoldierId = 61448;
        private const uint SiegeExplosivesId = 61452;

        private readonly uint[] _commanderVojakAdds = new[] { SikthikDemolisherId, SikthikWarriorId, SikthikSwarmerId };
        private WoWUnit _generalPavalak;

        private LocalPlayer Me
        {
            get { return StyxWoW.Me; }
        }

        [EncounterHandler(0)]
        public Composite RootBehavior()
        {
            // avoid getting stuck at these cages.
            AddAvoidObject(ctx => true, 5f, CageId);
            AddAvoidObject(ctx => !Me.IsMoving, 4f, u => u.Entry == SapPuddleId && u.ToUnit().HasAura("Sap Puddle") && u.ZDiff < 6);
            WoWGameObject hardenedResin = null;

            return
                new PrioritySelector(
                    ctx =>
                    hardenedResin =
                    ObjectManager.GetObjectsOfType<WoWGameObject>().FirstOrDefault(u => u.Entry == HardenResin && u.State == WoWGameObjectState.Ready && u.Distance <= 10),
                    new Decorator(ctx => ctx != null, HardenedResinHandler()));
        }

        [EncounterHandler(64517, "Shado-Master Chum Kiu", Mode = CallBehaviorMode.Proximity)]
        public Composite QuestHandler()
        {
            const int takeDownTheWingLeaderQuestId = 31366;

            WoWUnit unit = null;
            return new PrioritySelector(
                ctx => unit = ctx as WoWUnit,
                new Decorator(
                    ctx =>
                    !Me.Combat && !ScriptHelpers.WillPullAggroAtLocation(unit.Location) && unit.QuestGiverStatus == QuestGiverStatus.Available &&
                    Me.QuestLog.GetCompletedQuests().All(q => q != takeDownTheWingLeaderQuestId) && !Me.QuestLog.ContainsQuest(takeDownTheWingLeaderQuestId),
                    ScriptHelpers.CreatePickupQuest(() => unit, takeDownTheWingLeaderQuestId)),
                new Decorator(
                    ctx => !Me.Combat && !ScriptHelpers.WillPullAggroAtLocation(unit.Location) && unit.QuestGiverStatus == QuestGiverStatus.TurnIn,
                    ScriptHelpers.CreateTurninQuest(() => unit)));
        }

        #region Vizier Jin'bak

        [EncounterHandler(61567, "Vizier Jin'bak", Mode = CallBehaviorMode.Proximity, BossRange = 100)]
        public Composite VizierJinbakEncounter()
        {
            WoWUnit boss = null;
            WoWUnit puddle = null;

            AddAvoidObject(
                ctx =>
                !(Me.IsCasting && Me.CurrentCastTimeLeft <= TimeSpan.FromSeconds(1)) &&
                (Me.HasAura("Sap Residue") || boss != null && boss.IsValid && boss.CastingSpellId == DetonateId),
                obj => 5 * (obj.Scale * 4 / 5 + 1),
                SapPuddleBossId);

            return new PrioritySelector(
                ctx =>
                {
                    puddle = ObjectManager.GetObjectsOfType<WoWUnit>().FirstOrDefault(u => u.Entry == SapPuddleBossId);
                    return boss = ctx as WoWUnit;
                },
                new Decorator(ctx => !boss.CanSelect, ScriptHelpers.CreateClearArea(() => boss.Location, 100, u => u.Z <= 175)),
                new Decorator(
                    ctx => boss.Combat,
                    new PrioritySelector(
                        new Decorator(
                            ctx => !Me.IsHealer && !Me.HasAura("Sap Residue") && boss.CastingSpellId != DetonateId && puddle.Distance > 5,
                            new Action(ctx => Navigator.MoveTo(puddle.Location))))));
        }

        #endregion


        #region Commander Vo'jak

        public Composite HardenedResinHandler()
        {
            WoWGameObject resin = null;
            return new PrioritySelector(
                ctx => resin = ctx as WoWGameObject,
                new Decorator<WoWGameObject>(
                    obj => !Me.Combat,
                    new Sequence(
                        new Action(ctx => Logger.Write("Knocking away hardened resin")),
                        new DecoratorContinue(ctx => Me.IsMoving, new Action(ctx => WoWMovement.MoveStop())),
                        new WaitContinue(2, ctx => !Me.IsMoving, new ActionAlwaysSucceed()),
                        new Action(ctx => resin.Interact()),
                        new WaitContinue(1, ctx => Me.IsCasting, new ActionAlwaysSucceed()),
                        new WaitContinue(3, ctx => !Me.IsCasting, new ActionAlwaysSucceed()))));
        }

        [EncounterHandler(61634, "Commander Vo'jak", Mode = CallBehaviorMode.Proximity, BossRange = 8000)]
        public Composite CommanderVojakEncounter()
        {
            WoWUnit boss = null;
            WoWUnit yang = null;
            WoWUnit keg = null;
            WoWUnit causticTarPuddle = null; // this will be used for clearing the Rising Speed buff on boss.

            var platformCenterLoc = new WoWPoint(1521.815, 5294.988, 184.6694);
            var barrelThrowStart = new WoWPoint(1505.429, 5329.327, 161.2022);
            var barrelThrowEnd = new WoWPoint(1561.556, 5333.001, 161.2266);
            var throwStart = new WoWPoint(1482.407, 5312.085, 184.6487);
            var throwEnd = new WoWPoint(1558.097, 5317.704, 184.6507);
            var incAddsLoc = new WoWPoint(1510.148, 5372.519, 139.0868);

            WoWPoint kegThrowFromLoc = WoWPoint.Zero;
            WoWPoint kegThrowFromTo = WoWPoint.Zero;
            WoWUnit[] incAdds = null;
            WoWPoint moveto = WoWPoint.Zero;

            WoWPoint dashingStrikeLoc = WoWPoint.Zero;
            var dashingStrikeTimer = new WaitTimer(TimeSpan.FromSeconds(5));

            AddAvoidObject(
                ctx => true,
                () => platformCenterLoc,
                25,
                15,
                u => u.Entry == CommanderVojakId && (u.ToUnit().HasAura("Thousand Blades") || u.ToUnit().HasAura("Dashing Strike")),
                o =>
                {
                    var unit = (WoWUnit)o;
                    if (unit.HasAura("Dashing Strike"))
                    { // run away from current target of boss 
                        if (dashingStrikeTimer.IsFinished && unit.CurrentTargetGuid > 0)
                        {
                            dashingStrikeLoc = unit.CurrentTarget.Location;
                            dashingStrikeTimer.Reset();
                        }
                        return dashingStrikeLoc;
                    }
                    return unit.Location;
                });

            AddAvoidObject(ctx => !Me.IsTank() || (Me.IsTank() && boss != null && boss.IsValid && !boss.HasAura("Rising Speed")), 8f, SapPuddle2Id);
            AddAvoidObject(ctx => !Me.IsTank(), 20f, u => u.Entry == SikthikDemolisherId && u.ZDiff <= 5);

            return new PrioritySelector(
                ctx =>
                {
                    yang = ObjectManager.GetObjectsOfType<WoWUnit>().FirstOrDefault(u => u.Entry == 61620);
                    incAdds =
                        ScriptHelpers.GetUnfriendlyNpsAtLocation(() => incAddsLoc, 90, u => _commanderVojakAdds.Contains(u.Entry) && u.Z < 176 && u.Y < 5380).ToArray();

                    keg =
                        ObjectManager.GetObjectsOfType<WoWUnit>()
                                     .Where(
                                         u =>
                                         u.Entry == 61817 && u.HasAura("Mantid Barrel Active") && u.TransportGuid == 0 &&
                                         Me.RaidMembers.OrderBy(r => r.Location.DistanceSqr(u.Location)).FirstOrDefault() == Me)
                                     .OrderBy(u => u.DistanceSqr)
                                     .FirstOrDefault();

                    causticTarPuddle =
                        ObjectManager.GetObjectsOfType<WoWUnit>().Where(u => u.Entry == SapPuddle2Id && u.Z > 182).OrderBy(u => u.DistanceSqr).FirstOrDefault();

                    boss = (WoWUnit)ctx;

                    return boss;
                },
                // start the event
                new Decorator(ctx => Me.IsTank() && yang != null && yang.CanGossip && Targeting.Instance.IsEmpty(), ScriptHelpers.CreateTalkToNpc(() => yang)),
                // Should I nuke down the demoishers?
                new Decorator(
                    ctx => Me.IsRange() && Me.IsDps() && !Targeting.Instance.IsEmpty() && Targeting.Instance.FirstUnit.Entry == SikthikDemolisherId,
                    new PrioritySelector(
                        new Decorator(
                            ctx =>
                            !Targeting.Instance.FirstUnit.InLineOfSpellSight &&
                            Me.Location.Distance((moveto = Me.Location.GetNearestPointOnSegment(throwStart, throwEnd))) > 1.5f,
                            new Action(ctx => PrecisionMoveto(moveto))),
                        new Decorator(
                            ctx => ScriptHelpers.MovementEnabled,
                            new Action(
                                ctx =>
                                ScriptHelpers.DisableMovement(
                                    () =>
                                    !Targeting.Instance.IsEmpty() && Targeting.Instance.FirstUnit.Entry == SikthikDemolisherId &&
                                    Targeting.Instance.FirstUnit.InLineOfSpellSight))))),
                //new Decorator(
                //    ctx =>
                //    Me.IsRange() && Me.IsDps() && Targeting.Instance.TargetList.Any(u => u.Entry == SikthikDemolisherId && !u.InLineOfSpellSight) &&
                //    !AvoidanceManager.IsRunningOutOfAvoid,
                //    new PrioritySelector(
                //        new ActionSetActivity("Nuking down demolishers."),
                //        new Decorator(ctx => Me.Location.Distance(Me.Location.GetNearestPointOnSegment(throwStart, throwEnd)) > 1.5f,
                //            new Action(ctx => PrecisionMoveto(Me.Location.GetNearestPointOnSegment(throwStart, throwEnd)))))),

                // should I pick up a keg of tar?
                new Decorator(
                    ctx =>
                    keg != null && !AvoidanceManager.IsRunningOutOfAvoid &&
                    (Targeting.Instance.IsEmpty() ||
                     (Me.IsDps() && (Me.IsRange() && Targeting.Instance.TargetList.All(u => u.Entry != SikthikDemolisherId) || !Me.IsRange()) &&
                      (incAdds.Any() || boss.Z > 182 && boss.HasAura("Rising Speed") && causticTarPuddle == null))),
                    new PrioritySelector(
                        new ActionSetActivity("Throwing Kegs"),
                        new Decorator(
                // dont have a keg? go pick one up.
                            ctx => !Me.HasAura("Carrying Caustic Tar"),
                            new PrioritySelector(
                                new Decorator(ctx => !keg.WithinInteractRange, new Action(ctx => PrecisionMoveto(keg.Location))),
                                new Decorator(
                                    ctx => keg.WithinInteractRange,
                                    new Sequence(new Action(ctx => Navigator.NavigationProvider.StuckHandler.Reset()), new Action(ctx => keg.Interact()))))))),
                new Decorator(
                    ctx => Me.HasAura("Carrying Caustic Tar") && !AvoidanceManager.IsRunningOutOfAvoid,
                    new PrioritySelector(
                        ctx =>
                        {
                            kegThrowFromTo = boss.Z > 182 ? boss.Location : Me.Location.GetNearestPointOnSegment(barrelThrowStart, barrelThrowEnd);
                            return
                                kegThrowFromLoc =
                                boss.Z > 182
                                    ? Me.Location.GetNearestPointOnSegment(boss.Location, WoWMathHelper.CalculatePointFrom(Me.Location, boss.Location, 25))
                                    : Me.Location.GetNearestPointOnSegment(throwStart, throwEnd);
                        },
                        new Decorator(ctx => kegThrowFromLoc.Distance(Me.Location) > 4f, new Action(ctx => PrecisionMoveto(kegThrowFromLoc))),
                        new Decorator(
                            ctx => kegThrowFromLoc.Distance(Me.Location) <= 4f,
                            new Sequence(
                                new Action(ctx => Navigator.NavigationProvider.StuckHandler.Reset()), new Action(ctx => SpellManager.ClickRemoteLocation(kegThrowFromTo)))))),
                new Decorator(
                    ctx => boss.HasAura("Rising Speed") && causticTarPuddle != null && Me.IsTank() && boss.CurrentTargetGuid == Me.Guid,
                    new Action(ctx => Navigator.GetRunStatusFromMoveResult(Navigator.MoveTo(WoWMathHelper.CalculatePointFrom(boss.Location, causticTarPuddle.Location, -5))))),
                // tank stuff in the center of the playform.
                new Decorator(
                    ctx => Me.IsTank() && Targeting.Instance.TargetList.All(u => u.CurrentTargetGuid == Me.Guid),
                    ScriptHelpers.CreateTankUnitAtLocation(() => platformCenterLoc, 5)),
                ScriptHelpers.CreateDispellParty("Caustic Tar", ScriptHelpers.PartyDispellType.Magic),
                // stay on playform.
                new Decorator(
                    ctx => Me.IsTank() && Targeting.Instance.IsEmpty(),
                    new PrioritySelector(
                        new Decorator(ctx => Me.Location.DistanceSqr(platformCenterLoc) > 30 * 30, new Action(ctx => Navigator.MoveTo(platformCenterLoc))),
                        new ActionAlwaysSucceed())));
        }

        private RunStatus PrecisionMoveto(WoWPoint destination)
        {
            var myLoc = Me.Location;
            if (myLoc.Distance(destination) > 15 || Math.Abs(myLoc.Z - destination.Z) > 3)
            {
                var moveResult = Navigator.MoveTo(destination);
                if (moveResult == MoveResult.PathGenerationFailed || moveResult == MoveResult.Failed)
                    return RunStatus.Failure;
            }
            else Navigator.PlayerMover.MoveTowards(destination);
            return RunStatus.Success;
        }

        #endregion


        #region General Pa'valak

        [EncounterHandler(61485, "General Pa'valak", BossRange = 300, Mode = CallBehaviorMode.Proximity)]
        public Composite GeneralPavalakEncounter()
        {
            WoWUnit trash = null;
            WoWUnit bomb = null;
            WoWPoint bombTarget = WoWPoint.Zero;

            var trashAreaCenterLoc = new WoWPoint(1694.098, 5275.564, 124.18);
            var trashPullToLoc = new WoWPoint(1715.117, 5240.054, 123.7021);
            const uint bladeRushId = 63720;
            // run from blade rush target.
            AddAvoidObject(ctx => true, 8, bladeRushId);
            // run from the bombs that have armed
            AddAvoidObject(ctx => true, 7, u => u.Entry == SiegeExplosivesId && u.ToUnit().HasAura("Bomb Armed"));

            return new PrioritySelector(
                ctx => _generalPavalak = ctx as WoWUnit,
                new Decorator(
                // clear the area near the boss before engaging
                    ctx => !_generalPavalak.Combat,
                    new PrioritySelector(
                        ctx => trash = ScriptHelpers.GetUnfriendlyNpsAtLocation(() => trashAreaCenterLoc, 70, u => u != _generalPavalak).FirstOrDefault(),
                        new Decorator(
                            ctx => trash != null,
                            new PrioritySelector(
                                new Decorator(ctx => Me.Location.Distance(trashPullToLoc) > 40, new Action(ctx => ScriptHelpers.MoveTankTo(trashPullToLoc))),
                                new Decorator(
                                    ctx => Me.Location.Distance(trashPullToLoc) <= 40, ScriptHelpers.CreatePullNpcToLocation(ctx => true, () => trash, () => trashPullToLoc, 6)))))),
                // the boss combat behavior. 
                new Decorator(
                    ctx => _generalPavalak.Combat,
                    new PrioritySelector(
                        ctx =>
                        bomb =
                        ObjectManager.GetObjectsOfType<WoWUnit>()
                                     .Where(
                                         u =>
                                         u.Entry == SiegeExplosivesId && !u.HasAura("Bomb Armed") && u.Distance <= 25 &&
                                         !ScriptHelpers.GroupMembers.Any(
                                             g =>
                                             !g.IsHealer && g.Player != null && g.Player.IsSafelyFacing(u, 45) &&
                                             g.Location.Distance(u.Location) < Me.Location.Distance(u.Location)))
                                     .OrderBy(u => u.DistanceSqr)
                                     .FirstOrDefault(),
                        new Decorator(
                            ctx => Me.HasAura("Siege Explosive"),
                            new PrioritySelector(
                                ctx => bombTarget = GetBestBombThrowLocation(),
                                new Decorator(ctx => bombTarget != WoWPoint.Zero, new Action(ctx => SpellManager.ClickRemoteLocation(bombTarget))),
                                new Decorator(ctx => bombTarget == WoWPoint.Zero, new Action(ctx => SpellManager.ClickRemoteLocation(_generalPavalak.Location))))),
                // pickup a bomb and throw it.
                        new Decorator(
                            ctx => bomb != null && !Me.HasAura("Siege Explosive") && (Me.IsDps() || Targeting.Instance.TargetList.All(t => t.CurrentTargetGuid == Me.Guid) && Me.IsTank()),
                            new PrioritySelector(
                                new Decorator(
                                    ctx => bomb.WithinInteractRange,
                                    new Sequence(
                                        new Action(ctx => bomb.Interact()),
                                        new WaitContinue(2, ctx => Me.HasAura("Siege Explosive"), new ActionAlwaysSucceed()),
                                        new DecoratorContinue(
                                            ctx => Me.HasAura("Siege Explosive"),
                                            new Sequence(
                                                ctx => GetBestBombThrowLocation(),
                                                new DecoratorContinue(ctx => bombTarget != WoWPoint.Zero, new Action(ctx => SpellManager.ClickRemoteLocation(bombTarget))))))),
                                new Decorator(ctx => !bomb.WithinInteractRange, new Action(ctx => Navigator.GetRunStatusFromMoveResult(Navigator.MoveTo(bomb.Location)))))),
                        new Decorator(ctx => _generalPavalak.HasAura("Bulwark"), ScriptHelpers.CreateTankUnitAtLocation(() => _generalPavalak.Location, 25)),
                        ScriptHelpers.CreateDispellParty("Temptest", ScriptHelpers.PartyDispellType.Magic),
                // spread out a little for blade rush.
                        ScriptHelpers.CreateSpreadOutLogic(ctx => !_generalPavalak.HasAura("Bulwark"), () => _generalPavalak.Location, 5, 30))));
        }

        private WoWPoint GetBestBombThrowLocation()
        {
            using (StyxWoW.Memory.AcquireFrame())
            {
                var myLoc = Me.Location;
                // cache locations to improve performance...
                var targets = (from unit in ObjectManager.GetObjectsOfType<WoWUnit>()
                               where unit.Entry == SikthikSoldierId && unit.CanSelect && unit.Attackable && unit.CurrentTargetGuid != 0
                               let loc = unit.Location
                               where loc.DistanceSqr(myLoc) < 1600
                               select new { Unit = unit, Location = loc }).ToList();

                var bombTarget =
                    targets.OrderByDescending(t => targets.Count(c => c.Location.DistanceSqr(t.Location) <= 100))
                           .Select(t => t.Location)
                           .FirstOrDefault(l => GameWorld.IsInLineOfSpellSight(myLoc, l));
                return bombTarget == WoWPoint.Zero ? _generalPavalak.Location : bombTarget;
            }
        }

        #endregion


        #region Wing Leader Ner'onok

        [EncounterHandler(62205, "Wing Leader Ner'onok")]
        public Composite WingLeaderNeronokEncounter()
        {
            const int causticPitchMissileId = 121441;
            const int causticPitchId = 121443;
            const int quickDryResinId = 121447;
            const int gustingWindsId = 121284;

            AddAvoidObject(ctx => !Me.IsMoving, 2.5f, causticPitchId);
            AddAvoidLocation(ctx => !Me.IsMoving, 2.5f, o => ((WoWMissile)o).ImpactPosition, () => WoWMissile.InFlightMissiles.Where(m => m.SpellId == causticPitchMissileId));

            WoWUnit boss = null;
            return new PrioritySelector(
                ctx => boss = ctx as WoWUnit,
                ScriptHelpers.CreateInterruptCast(() => boss, gustingWindsId),
                new Decorator(
                    ctx => Me.HasAura(quickDryResinId),
                    new Sequence(
                        new Action(ctx => WoWMovement.Move(WoWMovement.MovementDirection.JumpAscend)),
                        new Action(ctx => WoWMovement.MoveStop(WoWMovement.MovementDirection.JumpAscend)))));
        }

        #endregion

    }

    public class Siege_OfNiuzaoTempleHeroic : Siege_OfNiuzaoTemple
    {
        #region Overrides of Dungeon

        public override uint DungeonId
        {
            get { return 554; }
        }

        #endregion

    }
}