﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DungeonBuddyScripts.Dungeon_Scripts.Mists_of_Pandaria.Dungeons
{
    class Gate_of_the_Setting_Sun_Heroic
    {
    }
}
