﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using Styx;

namespace DungeonBuddyScripts.Dungeon_Scripts.Mists_of_Pandaria.Dungeons
{
    class Stormstout_Brewery_Heroic
    {
        public Stormstout_Brewery_Heroic()
        {
        }
    }
}
