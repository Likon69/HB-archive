﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DungeonBuddyScripts.Dungeon_Scripts.Mists_of_Pandaria.Scenarios
{
    class Battle_on_the_High_Seas_Heroic__Alliance
    {
    }
}
