﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DungeonBuddyScripts.Dungeon_Scripts.Mists_of_Pandaria.Scenarios
{
    class Crypt_of_Forgotten_Kings_Heroic
    {
    }
}
