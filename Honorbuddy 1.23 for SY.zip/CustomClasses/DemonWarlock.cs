﻿#pragma warning disable
namespace Styx.Bot.CustomClasses
{
    using Styx;
    using System;
    using System.Diagnostics;
    using Helpers;
    using Styx.Logic;
    using System.Collections.Generic;
    using Logic.Pathing;
    using System.Threading;
    using Logic.Common.Combat;
    using Object_Dumping_Enumeration;
    using CustomCombat.CombatInterface;
    using Object_Dumping_Enumeration.WoWObjects;
    using Styx.Memory_Read_Write_Inject.Lua;

    class DemonWarlock : ICombat
    {
        #region variables
        public WoWClass Class { get { return WoWClass.Warlock; } }
        public string Name { get { return "Hawker's Demon Warlock 1.0"; } }

        bool disenchantGreens = false;
        private string _logspam;
        private readonly LocalPlayer Me = ObjectManager.Me;

        private static Stopwatch feedPetTimer = new Stopwatch();
        private static Stopwatch aspectTimer = new Stopwatch();
        private static Stopwatch petPresenceTimer = new Stopwatch();
        private static Stopwatch fightTimer = new Stopwatch();
        private static ulong lastGuid;
        private bool noDrink;
        private bool noFood;

        private bool combatChecks
        {
            get
            {
                if (Me.GotTarget)
                {
                    WoWMovement.MoveStop();
                    WoWMovement.Face();
                    return true;
                }
                else
                {
                    return false;
                }

            }
        }

        private int maxShards = 4;

        private uint soulShardCount
        {
            get
            {
                uint tmpSoulShardCount = 0;
                uint SoulShardEntryId = 6265;

                Lua.DoString("luaSoulShardCount = GetItemCount(\"Soul Shard\")");
                tmpSoulShardCount = Lua.GetLocalizedUInt32("luaSoulShardCount", ObjectManager.Me.BaseAddress);

                // uint tmpSoulShardCount = Lua.LuaGetReturnValue("return GetItemCount(\"Soul Shard\")", "hax.lua");

                if (tmpSoulShardCount > maxShards + 1)
                {
                    slog("Soul Shard count: " + tmpSoulShardCount.ToString() + ".");
                }

                return tmpSoulShardCount;
            }
        }

        private WoWItem myHealthstone
        {
            get
            {
                return HaveItemCheck(_healthstoneEntryId);
            }
        }

        private bool enemyClose = false;

        Point pointNow = new Point();

        List<WoWUnit> addsList = new List<WoWUnit>();

        private double targetDistance
        {
            get
            {
                return Me.GotTarget ? Me.CurrentTarget.Distance : uint.MaxValue - 1;
            }
        }

        private static Stopwatch pullTimer = new Stopwatch();
        private static Stopwatch moveTimer = new Stopwatch();

        /// <summary>
        /// THANKS NINKO
        /// </summary>
        private readonly List<uint> _healthstoneEntryId = new List<uint>
        {
            5509, 5510, 5511, 5512, 9421, 19004, 19005, 19006,  
            19007, 19008, 19009, 19010, 19011, 19012, 19013, 
            22103, 22104, 22105, 36889, 36890, 36891, 36892,
            36893, 36894,
        };

        #endregion

        #region rest and buffs
        public bool NeedRest
        {
            get
            {

                if (SpellManager.KnownSpells.ContainsKey("Life Tap") &&
                    Me.HealthPercent > 75 &&
                    Me.ManaPercent < 55)
                {
                    return true;
                }

                if (soulShardCount > maxShards)
                {
                    return true;
                }

                if (!petPresenceTimer.IsRunning)
                {
                    petPresenceTimer.Reset();
                    petPresenceTimer.Start();
                }

                if (NeedWeaponEnchant)
                {
                    slog("Apply a spellstone.");
                    return true;
                }

                if (!Me.Mounted)
                {
                    if (petPresenceTimer.ElapsedMilliseconds > 3000 &&
                        SpellManager.KnownSpells.ContainsKey("Summon Imp") &&
                        !Me.GotAlivePet)
                    {
                        slog("No demon.");
                        petPresenceTimer.Reset();
                        return true;
                    }

                    if (SpellManager.KnownSpells.ContainsKey("Soul Link") &&
                        !Me.Buffs.ContainsKey("Soul Link"))
                    {
                        return true;
                    }

                    if (SpellManager.KnownSpells.ContainsKey("Fel Armor"))
                    {
                        if (!Me.Buffs.ContainsKey("Fel Armor"))
                        {
                            slog("Need Fel Armor");
                            return true;
                        }
                    }
                    else if (SpellManager.KnownSpells.ContainsKey("Demon Armor"))
                    {
                        if (!Me.Buffs.ContainsKey("Demon Armor"))
                        {
                            return true;
                        }
                    }
                    else if (SpellManager.KnownSpells.ContainsKey("Demon Skin"))
                    {
                        if (!Me.Buffs.ContainsKey("Demon Skin"))
                        {
                            return true;
                        }
                    }
                }

                if (soulShardCount > 0 &&
                    SpellManager.KnownSpells.ContainsKey("Create Healthstone"))
                {
                    WoWItem myHealthstone = HaveItemCheck(_healthstoneEntryId);
                    if (Equals(null, myHealthstone))
                    {
                        slog("Need a health stone.");
                        return true;
                    }
                }

                if (SpellManager.KnownSpells.ContainsKey("Health Funnel") &&
                    Me.GotAlivePet &&
                    Me.Pet.HealthPercent < 50 &&
                    !Me.Pet.Buffs.ContainsKey("Health Funnel"))
                {
                    slog("Heal {0}.", Me.Pet.Name);
                    return true;
                }

                if (Battlegrounds.Battlegroundstatus == BattlegroundStatus.Active)
                {
                    return false;
                }

                if (!Me.Buffs.ContainsKey("Food") &&
                    Me.HealthPercent < 50)
                {
                    slog("Low health.");
                    return true;
                }

                if (!Me.Buffs.ContainsKey("Drink") &&
                    Me.ManaPercent < 45)
                {
                    slog("Low mana");
                    return true;
                }
                return false;
            }

        }



        public void Rest()
        {
            if (Me.HealthPercent > 70 &&
                Me.ManaPercent < 50)
            {
                LifeTap();
            }

            if (!Me.GotAlivePet &&
                SpellManager.KnownSpells.ContainsKey("Summon Imp"))
            {
                if (soulShardCount == 0 ||
                     !SpellManager.KnownSpells.ContainsKey("Summon Voidwalker"))
                {
                    slog("Get my irratatingly chatty imp out.");
                    SummonImp();
                }
                if (SpellManager.KnownSpells.ContainsKey("Summon Felguard"))
                {
                    slog("Call out the bad one...");
                    SummonFelguard();
                }
                else
                {
                    slog("Call the beast in the blue blanket.");
                    SummonVoidwalker();
                }
            }

            if (Me.GotAlivePet &&
                SpellManager.KnownSpells.ContainsKey("Soul Link") &&
                !Me.Buffs.ContainsKey("Soul Link"))
            {
                SoulLink();
            }

            if (SpellManager.KnownSpells.ContainsKey("Fel Armor"))
            {
                if (!Me.Buffs.ContainsKey("Fel Armor"))
                {
                    slog("Apply Fel Armor.");
                    FelArmor();
                }
            }
            else if (SpellManager.KnownSpells.ContainsKey("Demon Armor"))
            {
                if (!Me.Buffs.ContainsKey("Demon Armor"))
                {
                    DemonArmor();
                }
            }
            else if (SpellManager.KnownSpells.ContainsKey("Demon Skin"))
            {
                if (!Me.Buffs.ContainsKey("Demon Skin"))
                {
                    DemonSkin();
                }
            }

            if (SpellManager.KnownSpells.ContainsKey("Health Funnel") &&
                    Me.GotAlivePet &&
                    Me.Pet.HealthPercent < 50 &&
                    !Me.Pet.Buffs.ContainsKey("Health Funnel"))
            {
                slog("Heal the pet.");
                HealthFunnel();
            }

            if (NeedWeaponEnchant)
            {
                slog("Applying spellstone.");
                ApplyWeaponEnchants();
            }

            if (soulShardCount > 0 &&
                SpellManager.KnownSpells.ContainsKey("Create Healthstone"))
            {
                WoWItem myHealthstone = HaveItemCheck(_healthstoneEntryId);

                if (Equals(null, myHealthstone))
                {
                    slog("Make a health stone.");
                    CreateHealthstone();
                }
            }

            Lua.DoString("luaFoodCount = GetItemCount(\"" + Logic.Common.Rest.FoodName + "\")");
            uint foodCount = Lua.GetLocalizedUInt32("luaFoodCount", ObjectManager.Me.BaseAddress);

            if (foodCount < 1)
            {
                noFood = true;
            }
            else
            {
                noFood = false;
            }

            if (!noFood &&
                Me.HealthPercent < 50)
            {
                Logic.Common.Rest.Feed();
            }

            Lua.DoString("luaDrinkCount = GetItemCount(\"" + Logic.Common.Rest.DrinkName + "\")");
            uint DrinkCount = Lua.GetLocalizedUInt32("luaDrinkCount", ObjectManager.Me.BaseAddress);

            if (DrinkCount < 1)
            {
                noDrink = true;
            }
            else
            {
                noDrink = false;
            }

            if (!noDrink && Me.ManaPercent < 40)
            {
                Logic.Common.Rest.Feed();
            }

            if (!NeedWeaponEnchant &&
                soulShardCount > maxShards)
            {
                DeleteShard();
            }

            DisenchantItems(GetItemsToDisenchant());
            Stacker();
        }

        public bool NeedPreCombatBuffs { get { return false; } }
        public void PreCombatBuff() { }
        public bool NeedCombatBuffs { get { return false; } }
        public void CombatBuff() { }
        public bool NeedHeal { get { return false; } }
        public void Heal() { }
        public bool NeedPullBuffs { get { return false; } }
        public void PullBuff() { }
        #endregion

        #region pull
        public void Pull()
        {
            #region checks

            if (Battlegrounds.Battlegroundstatus == BattlegroundStatus.Active && Me.GotTarget && Me.CurrentTarget.Mounted)
            {
                Styx.Logic.Blacklist.Add(Me.CurrentTarget.Guid, System.TimeSpan.FromSeconds(30));
                Me.ClearTarget();
                return;
            }
            if (Me.CurrentTarget.Guid != lastGuid)
            {
                fightTimer.Reset();
                lastGuid = Me.CurrentTarget.Guid;
                slog("Killing " + Me.CurrentTarget.Name + " at distance " +
                    System.Math.Round(targetDistance).ToString() + ".");
                pullTimer.Reset();
                pullTimer.Start();

            }
            else
            {
                if (pullTimer.ElapsedMilliseconds > 30 * 1000)
                {
                    slog("Cannot pull " + Me.CurrentTarget.Name + " now.  Blacklist for 3 minutes.");
                    Styx.Logic.Blacklist.Add(Me.CurrentTarget.Guid, System.TimeSpan.FromMinutes(3));
                }
            }

            #endregion
            double shadowRange = SpellManager.KnownSpells["Shadow Bolt"].MaxRange - 1;

            if (Me.CurrentTarget.Distance > shadowRange)
            {
                slog("{0} yard from {1}.", System.Math.Round(Me.CurrentTarget.Distance).ToString(), Me.CurrentTarget.Name);
                Navigator.MoveTo(attackPoint);
                Thread.Sleep(500);
                return;
            }


            if (combatChecks &&
                Me.GotAlivePet &&
                !SpellManager.KnownSpells.ContainsKey("Dark Pact"))
            {
                if (!Me.Pet.IsAutoAttacking)
                {
                    Lua.DoString("PetAttack()");
                }

                petPresenceTimer.Reset();
                if (Me.CurrentTarget.Level - Me.Level == 1)
                {
                    slog("Let " + Me.Pet.Name + " gain aggro.");
                    Thread.Sleep(1000);
                }
                else if (Me.CurrentTarget.Level - Me.Level > 1)
                {
                    slog("Let " + Me.Pet.Name + " face this mob alone for a bit.");
                    Thread.Sleep(2000);
                }
            }

            if (SpellManager.KnownSpells.ContainsKey("Haunt"))
            {
                Haunt();
            }
            else if (SpellManager.KnownSpells.ContainsKey("Unstable Affliction"))
            {
                UnstableAffliction();
            }
            else if (SpellManager.KnownSpells.ContainsKey("Curse of Agony"))
            {
                CurseOfAgony();
            }
            else
            {
                Immolate();
            }

        }
        #endregion

        #region combat
        public void Combat()
        {
            if (Battlegrounds.Battlegroundstatus == BattlegroundStatus.Active)
            {
                if (Me.GotTarget &&
                    Me.CurrentTarget.IsPet)
                {
                    Blacklist.Add(Me.CurrentTarget, TimeSpan.FromDays(1));
                    Me.ClearTarget();
                    return;
                }
            }

            #region bugged mobs
            if (!fightTimer.IsRunning ||
               Me.CurrentTarget.Guid != lastGuid)
            {
                fightTimer.Reset();
                fightTimer.Start();
                lastGuid = Me.CurrentTarget.Guid;
            }

            if (!Me.CurrentTarget.IsPlayer &&
                fightTimer.ElapsedMilliseconds > 40 * 1000 &&
                Me.CurrentTarget.HealthPercent > 95)
            {
                slog(" This " + Me.CurrentTarget.Name + " is a bugged mob.  Blacklisting for 1 hour.");

                Logic.Blacklist.Add(Me.CurrentTarget.Guid, TimeSpan.FromHours(1.00));

                Styx.Helpers.KeyboardManager.PressKey('S');
                Thread.Sleep(5 * 1000);
                Styx.Helpers.KeyboardManager.ReleaseKey('S');
                Me.ClearTarget();
                lastGuid = 0;
                return;
            }

            #endregion


            if (Me.HealthPercent < 50)
            {
                if (!Equals(null, myHealthstone))
                {
                    slog("Take a health stone.");
                    Lua.DoString("UseItemByName(\"" + myHealthstone.Name + "\")");
                }
                else
                {
                    Logic.Common.Combat.Healing.UseHealthPotion();
                }
            }

            if (Me.ManaPercent < 50)
            {
                Logic.Common.Combat.Healing.UseManaPotion();
            }

            if (Equals(null, myHealthstone) &&
                Me.HealthPercent < 40 &&
                SpellManager.KnownSpells.ContainsKey("Metamorphosis") &&
                !SpellManager.KnownSpells["Metamorphosis"].Cooldown)
            {
                Metamorphosis();

                if (Me.CurrentTarget.Distance > 5)
                {
                    WoWMovement.ClickToMove(Me.CurrentTarget.Location);
                    Thread.Sleep(1000);
                    return;
                }

                ImmolationAura();
                ShadowCleave();
            }

            // sometimes the attack is on the pet
            if (!Me.GotTarget)
            {
                slog("Find a target.");
                addsList = getAdds();
                if (addsList.Count > 0)
                {
                    addsList[0].Target();
                    WoWMovement.Face();
                }
            }

            #region range checks
            if (Me.CurrentTarget.Distance > SpellManager.KnownSpells["Shadow Bolt"].MaxRange)
            {
                Pull();
                return;
            }

            #endregion

            WoWUnit myMob = null;

            #region dots
            if (combatChecks)
            {
                CurseOfAgony();
                Corruption();

                if (Me.CurrentTarget.HealthPercent > 20)
                {
                    if (SpellManager.KnownSpells.ContainsKey("Haunt"))
                    {
                        Haunt();
                    }
                }

                if (Me.CurrentTarget.HealthPercent > 40)
                {
                    UnstableAffliction();
                }

            }
            #endregion

            addsList = getAdds();
            if (addsList.Count > 1)
            {
                DemonicEmpowerment();

                if (Me.GotTarget &&
                    Me.CurrentTarget.HealthPercent > 50)
                {
                    foreach (WoWUnit mob in addsList)
                    {
                        if (Me.CurrentTarget.Guid != mob.Guid)
                        {
                            myMob = Me.CurrentTarget;
                            CurseOfAgony();
                            Corruption();

                            if (!mob.Buffs.ContainsKey("Curse of Agony") &&
                                !mob.Buffs.ContainsKey("Corruption"))
                            {
                                mob.Target();

                                if (SpellManager.KnownSpells.ContainsKey("Haunt"))
                                {
                                    Haunt();
                                }

                                Corruption();
                                CurseOfAgony();
                                myMob.Target();
                                break;
                            }
                        }
                    }
                }
            }

            if (Me.GotAlivePet &&
                Me.Pet.Distance > 35)
            {
                Lua.DoString("PetFollow()");
            }

            if (Me.GotAlivePet &&
                Me.Pet.HealthPercent < 50 &&
                !Me.Pet.Buffs.ContainsKey("Health Funnel"))
            {
                HealthFunnel();
                while (Me.HealthPercent > 65 &&
                    Me.Pet.HealthPercent < 90)
                {
                    Thread.Sleep(200);
                }
            }

            #region dps

            if (Me.ManaPercent < 30)
            {
                if (Me.GotAlivePet &&
                    SpellManager.KnownSpells.ContainsKey("Dark Pact") &&
                    Me.Pet.ManaPercent > 5)
                {
                    DarkPact();
                }
                else
                    if (Me.HealthPercent > 20)
                    {
                        LifeTap();
                    }
            }

            addsList = getAdds();

            if (combatChecks &&
                addsList.Count > 1 &&
                SpellManager.KnownSpells.ContainsKey("Drain Life"))
            {
                DrainLife();
                while (Me.ChanneledCasting > 0 &&
                    Me.CurrentTarget.HealthPercent > 25)
                {
                    Thread.Sleep(250);
                }
            }
            else if (combatChecks &&
                Me.CurrentTarget.HealthPercent > 60 &&
                Me.HealthPercent > 80 &&
                Me.ManaPercent > 50)
            {
                ShadowBolt();
            }
            else if (combatChecks &&
            Me.CurrentTarget.HealthPercent > 20 &&
            SpellManager.KnownSpells.ContainsKey("Drain Life"))
            {
                DrainLife();
                Thread.Sleep(1000);
                while (Me.ChanneledCasting > 0 &&
                    Me.CurrentTarget.HealthPercent > 25)
                {
                    Thread.Sleep(250);
                }

                if (Me.CurrentTarget.HealthPercent < 26 &&
                    Me.HealthPercent > 25)
                {
                    Corruption();
                    DrainSoul();
                }
            }
            else if (combatChecks &&
                Me.HealthPercent < 30 &&
                SpellManager.KnownSpells.ContainsKey("Drain Life"))
            {
                DrainLife();
                while (Me.ChanneledCasting > 0 &&
                    Me.CurrentTarget.HealthPercent > 25)
                {
                    Thread.Sleep(250);
                }

                if (Me.CurrentTarget.HealthPercent < 26 &&
                    Me.HealthPercent > 25)
                {
                    Corruption();
                    DrainSoul();
                }
            }
            else if (combatChecks &&
                Me.CurrentTarget.HealthPercent <= 25 &&
                SpellManager.KnownSpells.ContainsKey("Drain Soul"))
            {
                DrainSoul();
                while (Me.ChanneledCasting > 0 &&
                    Me.CurrentTarget.IsAlive)
                {
                    Thread.Sleep(250);
                }
            }
            else
            {
                ShadowBolt();
            }

            #endregion

            #region oom

            WoWMovement.MoveStop();
            WoWMovement.Face();

            if (Me.GotTarget &&
                Me.Casting == 0 &&
                !Me.IsAutoAttacking &&
                Me.Level < 10)
            {
                Lua.DoString("StartAttack()");
            }
            #endregion

            if (Me.HealthPercent > 70 &&
                Me.ManaPercent < 90)
            {
                LifeTap();
            }
        }


        #endregion

        #region warlock spells
        /// <summary>
        /// Protects the caster, increasing armor by 90, and increasing the amount of 
        /// health generated through spells and effects by 20%. 
        /// Only one type of Armor spell can be active on the Warlock at any time.  Lasts 30 min.
        /// </summary>        
        private bool DemonSkin()
        {
            if (SpellManager.CastSpell("Demon Skin"))
            {
                slog("Demon Skin.");
                return true;
            }
            else
            {
                // slog("Can't use Demon Skin now.");
                return false;
            }
        }

        /// <summary>
        /// Burns the enemy for 8 Fire damage and then an additional Fire damage over 15 sec.
        /// </summary>        
        private bool Immolate()
        {
            if (Me.CurrentTarget.Distance > SpellManager.KnownSpells["Immolate"].MaxRange)
            {
                return false;
            }

            if (combatChecks && !Me.CurrentTarget.Buffs.ContainsKey("Immolate") && SpellManager.CastSpell("Immolate", false))
            {
                slog("Immolate.");
                return true;
            }
            else
            {
                // slog("Can't use Immolate now.");
                return false;
            }
        }

        /// <summary>
        /// Sends a shadowy bolt at the enemy, causing Shadow damage.
        /// </summary>        
        private bool ShadowBolt()
        {
            if (Me.CurrentTarget.Distance > SpellManager.KnownSpells["Shadow Bolt"].MaxRange)
            {
                return false;
            }

            if (SpellManager.CastSpell("Shadow Bolt", false))
            {
                slog("Shadow Bolt.");
                return true;
            }
            else
            {
                // slog("Can't use Shadow Bolt now.");
                return false;
            }
        }

        /// <summary>
        /// Summons an Imp under the command of the Warlock.
        /// </summary>

        private bool SummonImp()
        {
            if (SpellManager.CastSpell("Summon Imp", true))
            {
                slog("Summon Imp.");
                Thread.Sleep(1000);
                while (Me.Casting > 0)
                {
                    Thread.Sleep(100);
                    if (Me.GotAlivePet && Me.Pet.Entry == 416)
                    {
                        break;
                    }
                }
                return true;
            }
            else
            {
                // slog("Can't use Summon Imp now."); 
                return false;
            }
        }

        /// <summary>
        /// Corrupts the target, causing 40 Shadow damage over 12 sec.
        /// </summary>        
        private bool Corruption()
        {
            if (Me.CurrentTarget.Distance > SpellManager.KnownSpells["Shadow Bolt"].MaxRange)
            {
                return false;
            }

            if (combatChecks && !Me.CurrentTarget.Buffs.ContainsKey("Corruption") && SpellManager.CastSpell("Corruption", false))
            {
                slog("Corruption.");
                return true;
            }
            else
            {
                // slog("Can't use Corruption now.");
                return false;
            }
        }

        /// <summary>
        /// Converts health into [0 + SPI * 1] mana.  Spirit increases quantity of health converted.
        /// </summary>        
        private bool LifeTap()
        {
            if (SpellManager.CastSpell("Life Tap", false))
            {
                slog("Life Tap.");
                return true;
            }
            else
            {
                // slog("Can't use Life Tap now.");
                return false;
            }
        }

        /// <summary>
        /// Curses the target with agony, causing Shadow damage over 24 sec.  This damage is dealt 
        /// slowly at first, and builds up as the Curse reaches its full duration. 
        /// </summary>        
        private bool CurseOfAgony()
        {
            if (Me.CurrentTarget.Distance > SpellManager.KnownSpells["Shadow Bolt"].MaxRange)
            {
                return false;
            }

            if (combatChecks && !Me.CurrentTarget.Buffs.ContainsKey("Curse of Agony") && SpellManager.CastSpell("Curse of Agony", false))
            {
                slog("Curse of Agony.");
                return true;
            }
            else
            {
                // slog("Can't use Curse of Agony now.");
                return false;
            }
        }

        /// <summary>
        /// Creates a Healthstone that can be used to instantly restore health.
        /// </summary>        
        private bool CreateHealthstone()
        {
            if (SpellManager.CastSpell("Create Healthstone", false))
            {
                slog("Create Healthstone.");
                return true;
            }
            else
            {
                // slog("Can't use Create Healthstone now.");
                return false;
            }
        }

        /// <summary>
        /// Drains the soul of the target, causing 55 Shadow damage over 15 sec.  If the target is at or 
        /// below 25% health, Drain Soul causes four times the normal damage
        /// If the target dies while being drained, and yields experience or honor, 
        /// the caster gains a Soul Shard.  Each time the Drain Soul damages the target, 
        /// it also has a chance to generate a Soul Shard. 
        /// </summary>        
        private bool DrainSoul()
        {
            if (Me.CurrentTarget.Distance > SpellManager.KnownSpells["Shadow Bolt"].MaxRange)
            {
                return false;
            }

            if (SpellManager.CastSpell("Drain Soul", false))
            {
                slog("Drain Soul.");
                return true;
            }
            else
            {
                // slog("Can't use Drain Soul now.");
                return false;
            }
        }

        /// <summary>
        /// Summons a Voidwalker under the command of the Warlock.
        /// </summary>        
        private bool SummonVoidwalker()
        {
            if (SpellManager.CastSpell("Summon Voidwalker", true))
            {
                slog("Summon Voidwalker.");
                Thread.Sleep(1000);
                while (Me.Casting > 0)
                {
                    Thread.Sleep(100);
                    if (Me.GotAlivePet && Me.Pet.Entry == 1860)
                    {
                        break;
                    }
                }
                return true;
            }
            else
            {
                // slog("Can't use Summon Voidwalker now.");
                return false;
            }
        }

        /// <summary>
        /// Summons a Felguard under the command of the Warlock.
        /// </summary>        
        private bool SummonFelguard()
        {
            SpellManager.CastSpell("Fel Domination");

            Thread.Sleep(1000);

            if (SpellManager.CastSpell("Summon Felguard", true))
            {
                Thread.Sleep(1000);
                while (Me.Casting > 0)
                {
                    Thread.Sleep(100);
                    if (Me.GotAlivePet && Me.Pet.Entry == 17252)
                    {
                        break;
                    }
                }
                return true;
            }
            else
            {
                // slog("Can't use Summon Felguard now.");
                return false;
            }
        }

        /// <summary>
        /// Gives health to the caster's pet every second for 10 sec as long as the caster channels.
        /// </summary>        
        private bool HealthFunnel()
        {
            double myHealth = 60;

            if (Me.Combat)
            {
                myHealth = 35;
            }
            if (Me.HealthPercent > myHealth &&
                SpellManager.CastSpell("Health Funnel", true))
            {
                slog("Health Funnel.");
                Thread.Sleep(1000);
                while (Me.Casting > 0 && Me.HealthPercent > myHealth)
                {
                    Thread.Sleep(100);
                }

                return true;
            }
            else
            {
                slog("Don't use Health Funnel now.");
                return false;
            }
        }

        /// <summary>
        /// Transfers health every 1 sec from the target to the caster.  Lasts 5 sec.
        /// </summary>        
        private bool DrainLife()
        {
            if (Me.CurrentTarget.Distance > SpellManager.KnownSpells["Shadow Bolt"].MaxRange)
            {
                return false;
            }

            if (SpellManager.CastSpell("Drain Life", true))
            {
                slog("Drain Life.");
                return true;
            }
            else
            {
                // slog("Can't use Drain Life now.");
                return false;
            }
        }

        /// <summary>
        /// The Soulstone can be used to store one target's soul.  If the target dies while his soul is stored, 
        /// he will be able to resurrect.
        /// </summary>        
        private bool CreateSoulstone()
        {
            if (SpellManager.CastSpell("Create Soulstone", false))
            {
                slog("Create Soulstone.");
                return true;
            }
            else
            {
                // slog("Can't use Create Soulstone now.");
                return false;
            }
        }

        /// <summary>
        /// Protects the caster, increasing armor, and increasing the amount of health 
        /// generated through spells and effects by 20%
        /// </summary>        
        private bool DemonArmor()
        {
            if (SpellManager.CastSpell("Demon Armor", false))
            {
                slog("Demon Armor.");
                return true;
            }
            else
            {
                // slog("Can't use Demon Armor now.");
                return false;
            }
        }

        /// <summary>
        /// While applied to target weapon it increases damage dealt by direct spells by 1% 
        /// and spell critical strike rating. 
        /// </summary>        
        private bool CreateFirestone()
        {
            if (SpellManager.CastSpell("Create Firestone", false))
            {
                slog("Create Firestone.");
                return true;
            }
            else
            {
                // slog("Can't use Create Firestone now.");
                return false;
            }
        }

        /// <summary>
        /// While applied to target weapon it increases damage dealt by periodic spells by 1% and spell haste rating.
        /// </summary>        
        private bool CreateSpellstone()
        {
            if (SpellManager.CastSpell("Create Spellstone", false))
            {
                slog("Create Spellstone.");
                return true;
            }
            else
            {
                // slog("Can't use Create Spellstone now.");
                return false;
            }
        }

        /// <summary>
        /// Causes the enemy target to run in horror for 3 sec and causes Shadow damage.  
        /// The caster gains 300% of the damage caused in health.
        /// </summary>        
        private bool DeathCoil()
        {
            if (Me.CurrentTarget.Distance > SpellManager.KnownSpells["Shadow Bolt"].MaxRange)
            {
                return false;
            }

            if (combatChecks && !Me.CurrentTarget.Buffs.ContainsKey("Death Coil") && SpellManager.CastSpell("Death Coil", false))
            {
                slog("Death Coil.");
                return true;
            }
            else
            {
                // slog("Can't use Death Coil now.");
                return false;
            }
        }

        /// <summary>
        /// Voidwalker - Increases the Voidwalker's health by 20%, and its threat 
        /// generated from spells and attacks by 20% for 20 sec.
        /// 
        /// Increases the Felguard's attack speed by 20% and breaks all stun, 
        /// snare and movement impairing effects and makes your Felguard immune to them for 15 sec.
        /// </summary>
        /// <returns></returns>
        private bool DemonicEmpowerment()
        {

            if (SpellManager.CastSpell("Demonic Empowerment", false))
            {
                slog("Demonic Empowerment.");
                return true;
            }
            else
            {
                // slog("Can't use Demonic Empowerment now.");
                return false;
            }
        }

        /// <summary>
        /// Drains your summoned demon's Mana, returning 100% to you.
        /// </summary>        
        private bool DarkPact()
        {
            if (SpellManager.CastSpell("Dark Pact", false))
            {
                slog("Dark Pact.");
                return true;
            }
            else
            {
                // slog("Can't use Dark Pact now.");
                return false;
            }
        }

        /// <summary>
        /// Shadow energy slowly destroys the target, causing damage over 15 sec.  
        /// In addition, if the Unstable Affliction is dispelled it will cause serious damage to the dispeller 
        /// and silence them for 5 sec.
        /// </summary>        
        private bool UnstableAffliction()
        {
            if (Me.CurrentTarget.Distance > SpellManager.KnownSpells["Shadow Bolt"].MaxRange)
            {
                return false;
            }

            if (combatChecks && !Me.CurrentTarget.Buffs.ContainsKey("Unstable Affliction") && SpellManager.CastSpell("Unstable Affliction", false))
            {
                slog("Unstable Affliction.");
                return true;
            }
            else
            {
                // slog("Can't use Unstable Affliction now.");
                return false;
            }
        }

        /// <summary>
        /// Surrounds the caster with fel energy, increasing spell power plus additional spell 
        /// power equal to 30% of your Spirit. 
        /// In addition, you regain 2% of your maximum health every 5 sec.
        /// </summary>        
        private bool FelArmor()
        {
            if (SpellManager.CastSpell("Fel Armor", false))
            {
                slog("Fel Armor.");
                return true;
            }
            else
            {
                // slog("Can't use Fel Armor now.");
                return false;
            }
        }

        /// <summary>
        /// When active, 20% of all damage taken by the caster is taken by your Imp, Voidwalker, 
        /// Succubus, Felhunter, Felguard, or enslaved demon instead.  
        /// That damage cannot be prevented. Lasts as long as the demon is active and controlled.
        /// </summary>        
        private bool SoulLink()
        {
            if (SpellManager.CastSpell("Soul Link", false))
            {
                slog("Soul Link.");
                return true;
            }
            else
            {
                // slog("Can't use Soul Link now.");
                return false;
            }
        }

        /// <summary>
        /// You send a ghostly soul into the target, dealing Shadow damage and increasing all damage done 
        /// by your Shadow damage-over-time effects on the target by 20% for 12 sec. 
        /// When the Haunt spell ends or is dispelled, the soul returns to you, healing you for 100% of the 
        /// damage it did to the target.
        /// </summary>        
        private bool Haunt()
        {
            if (Me.CurrentTarget.Distance > SpellManager.KnownSpells["Shadow Bolt"].MaxRange)
            {
                return false;
            }

            if (combatChecks && !Me.CurrentTarget.Buffs.ContainsKey("Haunt") && SpellManager.CastSpell("Haunt", false))
            {
                slog("Haunt.");
                return true;
            }
            else
            {
                // slog("Can't use Haunt now.");
                return false;
            }
        }

        /// <summary>
        /// You transform into a Demon for 30 sec.  This form increases your armor by 600%, damage by 20%, 
        /// reduces the chance you'll be critically hit by melee attacks by 6% and reduces the duration of 
        /// stun and snare effects by 50%.
        ///  You gain some unique demon abilities in addition to your normal abilities.
        /// </summary>        
        private bool Metamorphosis()
        {
            if (combatChecks && SpellManager.CastSpell("Metamorphosis", false))
            {
                slog("Metamorphosis.");
                return true;
            }
            else
            {
                // slog("Can't use Metamorphosis now.");
                return false;
            }
        }

        /// <summary>
        /// Inflicts 110 Shadow damage to an enemy target and nearby allies, affecting up to 3 targets.
        /// </summary>        
        private bool ShadowCleave()
        {
            if (Me.CurrentTarget.Distance > 5)
            {
                return false;
            }

            if (combatChecks && SpellManager.CastSpell("Shadow Cleave", false))
            {
                slog("Shadow Cleave.");
                return true;
            }
            else
            {
                // slog("Can't use Shadow Cleave now.");
                return false;
            }
        }

        /// <summary>
        /// Ignites the area surrounds you, causing 251 Fire damage to all nearby enemies every 1 sec.  
        /// Lasts 15 sec.
        /// </summary>
        private bool ImmolationAura()
        {
            if (Me.CurrentTarget.Distance > 5)
            {
                return false;
            }

            if (combatChecks && SpellManager.CastSpell("Immolation Aura", false))
            {
                slog("Immolation Aura.");
                return true;
            }
            else
            {
                // slog("Can't use Immolation Aura now.");
                return false;
            }
        }


        /// <summary>
        /// Targets in a cone in front of the 
        /// caster take Shadow damage and an additional Fire damage over 8 sec.
        /// </summary>        
        private bool Shadowflame()
        {
            if (Me.CurrentTarget.Distance > SpellManager.KnownSpells["Shadow Bolt"].MaxRange)
            {
                return false;
            }

            if (combatChecks && !Me.CurrentTarget.Buffs.ContainsKey("ShadowFlame") && SpellManager.CastSpell("Shadowflame", false))
            {
                slog("Shadowflame.");
                return true;
            }
            else
            {
                // slog("Can't use Shadowflame now.");
                return false;
            }
        }

        #endregion

        #region spellstones

        private readonly List<short> _firestoneEnchantEntryId = new List<short>
        {
            3597, 3609, 3610, 3611, 3612, 3613, 3614,
        };

        private readonly List<uint> _firestoneEntryId = new List<uint>
        {
            40773, 41169, 41170, 41171, 41172, 41173, 41174,
        };

        private readonly List<short> _spellstoneEnchantEntryId = new List<short>
        {
            3615, 3616, 3617, 3618, 3619, 3620,
        };

        private readonly List<uint> _spellstoneEntryId = new List<uint>
        {
            41191, 41192, 41193, 41194, 41195, 41196,
        };

        private void ApplyWeaponEnchants()
        {
            if (!SpellManager.KnownSpells.ContainsKey("Create Firestone") ||
               _spellstoneEnchantEntryId.Contains(Me.Mainhand.ItemEnchant) ||
               _firestoneEnchantEntryId.Contains(Me.Mainhand.ItemEnchant))
            {
                return;
            }

            if (SpellManager.KnownSpells.ContainsKey("Create Spellstone"))
            {
                WoWItem mySpellstone = HaveItemCheck(_spellstoneEntryId);

                if (Equals(null, mySpellstone))
                {
                    if (soulShardCount == 0)
                    {
                        slog("Get soul shards.");
                        return;
                    }
                    else
                    {
                        slog("Make a spellstone.");
                        CreateSpellstone();
                        return;
                    }
                }
                else
                    slog("Apply Spellstone.");

                Lua.DoString("UseItemByName(\"" + mySpellstone.Entry + "\")");
                Thread.Sleep(100);
                Lua.DoString("UseInventoryItem(16)");
                Thread.Sleep(250);

                while (Me.Casting > 0 &&
                    !Me.Combat)
                {
                    Thread.Sleep(250);
                }


            }
            else if (SpellManager.KnownSpells.ContainsKey("Create Firestone"))
            {
                WoWItem mySpellstone = HaveItemCheck(_firestoneEntryId);

                if (Equals(null, mySpellstone))
                {
                    if (soulShardCount == 0)
                    {
                        slog("Make soul shards.");
                        return;
                    }
                    else
                    {
                        slog("Make a Firestone.");
                        CreateSpellstone();
                        return;
                    }
                }
                else
                    slog("Apply Firestone.");

                Lua.DoString("UseItemByName(\"" + mySpellstone.Entry + "\")");
                Thread.Sleep(100);
                Lua.DoString("UseInventoryItem(16)");
                Thread.Sleep(3100);
            }
        }

        private bool NeedWeaponEnchant
        {
            get
            {
                if (SpellManager.KnownSpells.ContainsKey("Create Firestone") &&
                    !_spellstoneEnchantEntryId.Contains(Me.Mainhand.ItemEnchant) &&
                    !_firestoneEnchantEntryId.Contains(Me.Mainhand.ItemEnchant))
                {
                    return true;
                }

                return false;
            }
        }
        #endregion

        #region utilities


        private WoWItem HaveItemCheck(List<uint> listId)
        {
            foreach (WoWItem item in ObjectManager.GetObjectsOfType<WoWItem>(false))
            {
                if (listId.Contains(item.Entry))
                {
                    return item;
                }
            }
            return null;
        }

        private static Stopwatch shardTimer = new Stopwatch();
        private void DeleteShard()
        {
            if (shardTimer.IsRunning &&
                shardTimer.ElapsedMilliseconds < 1000)
            {
                return;
            }
            if (soulShardCount > maxShards)
            {
                shardTimer.Reset();
                shardTimer.Start();

                string shardDelete = "i=\"Soul Shard\"d=1 for x=0,4 do for y=1,GetContainerNumSlots(x) do  if (d>0) then l=GetContainerItemLink(x,y)  if l and GetItemInfo(l)==i then PickupContainerItem(x,y) DeleteCursorItem() d=d-1 end end end end";

                Lua.DoString(shardDelete);
            }
        }


        private WoWUnit extraPull()
        {
            if (!Me.GotTarget)
                return null;

            WoWUnit extraMob = null;

            try
            {
                var p = new SearchParams
                {
                    Dead = false,
                    Critters = false,
                    Elite = false,
                    Player = false,
                    MinDistance = 0,
                    MaxDistance = 35,
                    Factions = Global.CurrentProfile.Factions.ToArray(),
                    MinLevel = Global.CurrentProfile.TargetMinLevel,
                    MaxLevel = Global.CurrentProfile.TargetMaxLevel,
                    HorizontallyReachable = true,
                };

                List<WoWUnit> shortList = new ObjectList<WoWUnit>(p);

                if (shortList.Contains(Me.CurrentTarget))
                {
                    shortList.Remove(Me.CurrentTarget);
                }

                if (shortList.Count < 1)
                {
                    return null;
                }

                double distance = 999999;

                foreach (WoWUnit mob in shortList)
                {
                    if (mob.Distance < distance)
                    {
                        extraMob = mob;
                        distance = mob.Distance;
                    }
                }
            }
            catch
            {
                slog("Failed to find extra target.");
            }

            return extraMob;
        }

        private List<WoWUnit> getAdds()
        {
            List<WoWUnit> mobList = ObjectManager.GetObjectsOfType<WoWUnit>(false);
            List<WoWUnit> enemyMobList = new List<WoWUnit>();

            foreach (WoWUnit thing in mobList)
            {
                try
                {
                    if ((thing.Guid != Me.Guid) &&
                    thing.IsTargetingMe)
                    {
                        enemyMobList.Add(thing);
                    }
                }
                catch (Exception ex)
                {
                    Logging.WriteException(ex);
                    slog("Add error.");
                }
            }

            if (enemyMobList.Count > 1)
            {
                slog("Warning: there are " + enemyMobList.Count.ToString() + " attackers.");
            }
            return enemyMobList;
        }

        private void slog(string msg, params object[] args)
        {
            if (msg != _logspam)
            {
                Logging.Write(msg, args);
                _logspam = msg;
            }
        }


        private void slog(string msg)
        {
            if (msg != _logspam)
            {
                Logging.Write(msg);
                _logspam = msg;
            }
        }

        public void HandleFalling() { }

        #endregion

        #region movement logic
        WoWPoint attackPoint
        {
            get
            {
                if (Me.GotTarget)
                {
                    if (!movementTimer.IsRunning ||
                        movementTimer.ElapsedMilliseconds > 2500)
                    {
                        movementTimer.Reset();
                        movementTimer.Start();
                        attackPointBuffer = WoWMovement.CalculatePointFrom(Me.CurrentTarget.Location, 25.0f);
                        return attackPointBuffer;
                    }
                    else
                    {
                        return attackPointBuffer;
                    }
                }
                else
                {
                    WoWPoint noSpot = new WoWPoint();
                    return noSpot;
                }
            }
        }

        WoWPoint attackPointBuffer;

        private static Stopwatch movementTimer = new Stopwatch();


        #endregion

        #region horde racials

        // Berserking
        void Berserking()
        {
            if (ObjectManager.Me.Race == WoWRace.Troll &&
                SpellManager.CastSpell("Berserking"))
            {
                Styx.Helpers.Logging.Write("Berserking.");
            }
        }

        // Bloodrage
        void Bloodrage()
        {
            if (ObjectManager.Me.Race == WoWRace.Orc &&
                SpellManager.CastSpell("Bloodrage"))
            {
                Styx.Helpers.Logging.Write("Bloodrage.");
            }
        }

        // War Stomp
        void WarStomp()
        {
            if (ObjectManager.Me.Race == WoWRace.Tauren &&
                SpellManager.CastSpell("War Stomp"))
            {
                Styx.Helpers.Logging.Write("War Stomp.");
            }
        }

        // Arcane Torrent
        void ArcaneTorrent()
        {
            if (ObjectManager.Me.Race == WoWRace.BloodElf &&
                SpellManager.CastSpell("Arcane Torrent"))
            {
                Styx.Helpers.Logging.Write("Arcane Torrent.");
            }
        }

        // Will of the Forsaken 
        void WillOfTheForsaken()
        {
            if (ObjectManager.Me.Race == WoWRace.Undead &&
                SpellManager.CastSpell("Will of the Forsaken"))
            {
                Styx.Helpers.Logging.Write("Will of the Forsaken.");
            }
        }
        #endregion

        #region alliance racials

        // Stoneform
        void Stoneform()
        {
            if (ObjectManager.Me.Race == WoWRace.Dwarf &&
                SpellManager.CastSpell("Stoneform"))
            {
                Styx.Helpers.Logging.Write("Stoneform.");
            }
        }

        // Gift of the Naaru
        void GiftOfTheNaaru()
        {
            if (ObjectManager.Me.Race == WoWRace.Draenei &&
                SpellManager.CastSpell("Gift of the Naaru"))
            {
                Styx.Helpers.Logging.Write("Gift of the Naaru.");
            }
        }

        // Every Man for Himself
        void EveryManForHimself()
        {
            if (ObjectManager.Me.Race == WoWRace.Human &&
                SpellManager.CastSpell("Every Man for Himself"))
            {
                Styx.Helpers.Logging.Write("Every Man for Himself.");
            }
        }

        // Shadowmeld
        void Shadowmeld()
        {
            if (ObjectManager.Me.Race == WoWRace.NightElf &&
                SpellManager.CastSpell("Shadowmeld"))
            {
                Styx.Helpers.Logging.Write("Shadowmeld.");
            }
        }

        // Escape Artist
        void EscapeArtist()
        {
            if (ObjectManager.Me.Race == WoWRace.Gnome &&
                SpellManager.CastSpell("Escape Artist"))
            {
                Styx.Helpers.Logging.Write("Escape Artist.");
            }
        }


        #endregion

        #region enchanting

        // ReplaceEnchant()
        // /click StaticPopup1Button1 

        private static List<WoWItem> alreadyDisenchanted = new List<WoWItem>();

        /// <summary>
        /// List from wowhead
        /// http://www.wowhead.com/?items=7.12#0+2-1
        /// </summary>
        private List<uint> doNotDisenchant = new List<uint>()
        {
            // mats
            10940, 10938, 10939, 10998, 10978, 11082, 11083, 11084, 11134, 11139, 11174, 11175,
            11176, 11177, 11178, 14343, 14344, 16202, 16203, 16204, 20725, 22445, 22446, 22447,
            22448, 22449, 22450, 34052, 34053, 34054, 34055, 34056, 34057, 46849, 49649,
            // rods
            44452,
            // lockbox
            43622,
            // healthstones
            5509, 5510, 5511, 5512, 9421, 19004, 19005, 19006,  
            19007, 19008, 19009, 19010, 19011, 19012, 19013, 
            22103, 22104, 22105, 36889, 36890, 36891, 36892,
            36893, 36894,
            // soulstones

            // firestones
            3615, 3616, 3617, 3618, 3619, 3620,

            // spellstones
            41191, 41192, 41193, 41194, 41195, 41196,

        };


        private List<WoWItem> GetItemsToDisenchant()
        {
            try
            {
                if (!disenchantGreens ||
                    !SpellManager.KnownSpells.ContainsKey("Disenchant") ||
                    Me.ZoneId == 3277 || Me.ZoneId == 3358 || Me.ZoneId == 2597) // wsg, ab and av
                {
                    return null;
                }

                List<WoWItem> targetItems = ObjectManager.GetObjectsOfType<WoWItem>(false);

                for (int a = targetItems.Count - 1; a >= 0; --a)
                {
                    if (doNotDisenchant.Contains(targetItems[a].Entry) ||
                        alreadyDisenchanted.Contains(targetItems[a]))
                    {
                        targetItems.RemoveAt(a);
                    }
                    else if (targetItems[a].IsSoulbound ||
                        targetItems[a].IsAccountBound ||
                        targetItems[a].Quality != WoWItemQuality.Uncommon)
                    {
                        alreadyDisenchanted.Add(targetItems[a]);
                        targetItems.RemoveAt(a);
                    }
                }

                if (targetItems.Count > 0)
                {
                    foreach (WoWItem deItem in targetItems)
                    {
                        slog("Disenchant: {0}.", deItem.Name);
                    }
                    return targetItems;
                }
            }
            catch
            {
                slog("Getting Disenchant list failed");
            }

            // slog("Nothing to Disenchant.");
            return null;
        }


        private bool DisenchantItems(List<WoWItem> targetList)
        {
            try
            {
                if (Equals(null, targetList))
                {
                    return true;
                }

                foreach (WoWItem deItem in targetList)
                {
                    slog("Disenchanting: {0} Entry: {1}.", deItem.Name, deItem.Entry);
                    SpellManager.CastSpell("Disenchant", false);
                    Thread.Sleep(500);
                    Lua.DoString("UseItemByName(\"" + deItem.Name + "\")");

                    Thread.Sleep(500);

                    while (Me.Casting > 0 &&
                        !Me.Combat)
                    {
                        Thread.Sleep(250);
                    }

                    Thread.Sleep(2500);

                    // wait for lootframe to close
                    Stopwatch timer = new Stopwatch();
                    timer.Start();

                    while (ObjectManager.Wow.ReadUInt((uint)GlobalOffsets.LootFrame) != 0
                        && !Me.Combat)
                    {
                        Thread.Sleep(1000);

                        if (timer.ElapsedMilliseconds >= 6000)
                        {
                            break;
                        }
                    }

                    if (!Me.Combat)
                    {
                        Thread.Sleep(1500);
                        alreadyDisenchanted.Add(deItem);
                    }
                    else
                    {
                        return false;
                    }
                }
            }
            catch
            {
                slog("DE failed");
                return false;
            }
            return true;
        }

        #endregion

        private bool Stacker()
        {
            // 33567

            try
            {
                List<WoWItem> allItems = ObjectManager.GetObjectsOfType<WoWItem>(false);

                int count = 0;

                foreach (WoWItem one in allItems)
                {
                    if (one.Entry == 33567)
                    {
                        ++count;
                        if (count > 4)
                        {
                            break;
                        }
                    }
                }

                if (count > 4)
                {
                    Lua.DoString("UseItemByName(\"" + 33567 + "\")");
                    slog("Borean Leather created.");
                    return true;
                }
            }
            catch (Exception ex)
            {
                slog(ex.Message);
            }
            return false;
        }
    }
}
#pragma warning restore