﻿#pragma warning disable
namespace Styx.Bot.CustomClasses
{
    using System;
    using Helpers;
    using Logic;
    using Logic.Pathing;
    using System.Threading;
    using System.Media;
    using Logic.Common.Combat;
    using Object_Dumping_Enumeration;
    using System.Runtime.InteropServices;
    using CustomCombat.CombatInterface;
    using Memory_Read_Write_Inject.Lua;
    using System.Diagnostics;
    using System.Collections.Generic;
    using Object_Dumping_Enumeration.WoWObjects;
    using Styx;

    public class Rogue : ICombat
    {
        public WoWClass Class { get { return WoWClass.Rogue; } }

        public string Name { get { return "Hawker's Rogue 1.1"; } }

        #region Private Members




        private void slog(string msg)
        {
            if (msg == _logspam)
            {
                return;
            }

            Logging.Write(msg);
            _logspam = msg;
        }

        #endregion

        #region Global Variables

        bool SliceAndDiceUsed = false;
        List<WoWUnit> addsList = new List<WoWUnit>();
        private readonly Object_Dumping_Enumeration.WoWObjects.LocalPlayer Me = ObjectManager.Me;
        private string _logspam;
        Point pointNow = new Point();
        private uint killComboCount = 4;
        private uint deathCount = 0;


        private double targetDistance
        {
            get
            {
                return Me.GotTarget ? Me.CurrentTarget.Distance : uint.MaxValue - 1;

            }
        }

        private WoWPoint behindTarget
        {
            get
            {
                if (Me.GotTarget)
                {
                    return WoWMathHelper.CalculatePointBehind(Me.CurrentTarget.Location, Me.CurrentTarget.Rotation, 4);
                }
                else
                {
                    WoWPoint noSpot = new WoWPoint();
                    return noSpot;
                }
            }
        }

        private WoWPoint targetLocation
        {
            get
            {
                if (Me.GotTarget)
                {
                    return Me.CurrentTarget.Location;
                }
                else
                {
                    WoWPoint noSpot = new WoWPoint();
                    return noSpot;
                }
            }
        }

        private ulong targettingGuid
        {
            get
            {
                //    try
                //    {
                if (!Equals(null, Logic.Targeting.TargetList) &&
                    Logic.Targeting.TargetList.Count > 0)
                {
                    return Logic.Targeting.TargetList[0].Guid;
                }
                else
                {
                    return 0;
                }
                //}
                //catch
                //{
                //    slog("No valid target.");
                //    return 0;
                //}
            }
        }

        private static ulong lastGuid;
        private static Stopwatch fightTimer = new Stopwatch();

        private static ulong pullGuid;
        private static Stopwatch pullTimer = new Stopwatch();
        #endregion

        #region Rest

        public bool NeedRest
        {
            get
            {
                if (NeedPoisons())
                {
                    return true;
                }

                if (Battlegrounds.Battlegroundstatus == BattlegroundStatus.Active)
                {
                    return false;
                }

                return Me.GetPowerPercent(WoWPowerType.Health) <= 55;
            }
        }

        public void Rest()
        {
            if (NeedPoisons())
            {
                ApplyPoisons();
                Thread.Sleep(3000);
            }
            Logic.Common.Rest.Feed();

        }

        #endregion

        #region Pull

        private WoWUnit FindPlayers()
        {
            List<WoWUnit> PlayerList = new List<WoWUnit>(ObjectManager.NpcObjectList.Values);

            foreach (WoWUnit Players in PlayerList)
            {

                if (Players.IsPlayer)
                {
                    slog("Got Players! Run for the hills!");
                    return Players;
                }
            }

            return null;
        }


        bool IsFacingAway
        {
            get
            {
                bool face = false;
                double bearing = Me.CurrentTarget.Rotation;
                //double Angle = bearing * 180 / Math.PI; 
                if (bearing > Math.PI / 2 || bearing < -Math.PI / 2)

                    face = true;
                return face;
            }
        }

        //degrees = radians * 180 / Math.PI
        public void Pull()
        {
            if (Battlegrounds.Battlegroundstatus == BattlegroundStatus.Active &&
                Me.GotTarget &&
                Me.CurrentTarget.Mounted)
            {
                Styx.Logic.Blacklist.Add(Me.CurrentTarget.Guid, System.TimeSpan.FromSeconds(30));
                Me.ClearTarget();
                return;
            }

            if (Me.GotTarget &&
                Me.CurrentTarget.Guid != pullGuid)
            {
                pullTimer.Reset();
                pullTimer.Start();
                pullGuid = Me.CurrentTarget.Guid;
                slog("Killing " + Me.CurrentTarget.Name + " at distance " + System.Math.Floor(Me.CurrentTarget.Distance));
            }

            if (!Me.CurrentTarget.IsPlayer && pullTimer.ElapsedMilliseconds > 30 * 1000)
            {
                slog(" This " + Me.CurrentTarget.Name + " is a bugged mob.  Blacklisting for 1 hour.");

                Logic.Blacklist.Add(Me.CurrentTarget.Guid, TimeSpan.FromHours(1.00));

                Me.ClearTarget();
                pullGuid = 0;
            }

            if (!Me.Buffs.ContainsKey("Stealth"))
            {
                SpellManager.CastSpell("Stealth");
            }

            if (!Me.Combat && targetDistance > 5 &&
                targetDistance < Styx.Logic.Targeting.PullDistance + 10)
            {
                WoWMovement.ClickToMove(attackPoint);
                Thread.Sleep(500);
                return;
            }
            else
            {
                WoWMovement.MoveStop();
                WoWMovement.Face();
            }


            if (Me.GotTarget &&
                targetDistance <= 5 &&
                !Me.IsAutoAttacking)
            {
                CheapShot();
                WoWMovement.ClickToMove(attackPoint);
                Lua.DoString("StartAttack()");
                
            }

        }

        #endregion



        #region Pull Buffs

        public bool NeedPullBuffs { get { return false; } }

        public void PullBuff()
        {
            //slog("Got Here");
            //Stealth();
        }

        #endregion

        #region Pre Combat Buffs

        public bool NeedPreCombatBuffs { get { return false; } }

        public void PreCombatBuff()
        {
            //slog("Got Here");
            //Stealth();
            //if (!Me.Buffs.ContainsKey("Stealth"))
            //{
            //SpellManager.CastSpell("Stealth", false);
            //}
        }

        #endregion

        #region Combat Buffs

        public bool NeedCombatBuffs { get { return false; } }

        public void CombatBuff() { }

        #endregion

        #region Heal

        public bool NeedHeal { get { return false; } }// Me.GetPowerPercent(WoWPowerType.Health) <= 30; } }

        public void Heal()
        {
            Gouge();
        }

        #endregion

        #region Falling

        public void HandleFalling() { }

        #endregion

        #region Combat

        public void Combat()
        {
            //try
            //{
            if (Me.GotTarget &&
                Me.ComboPoints == 0 &&
                targettingGuid > 0 &&
                Me.CurrentTarget.Guid != targettingGuid)
            {
                Logging.Write("Correct target is " + Logic.Targeting.TargetList[0].Name);

                if (Logic.Targeting.TargetList[0].CurrentTargetGuid == Me.Guid)
                {
                    Logic.Targeting.TargetList[0].Target();
                }
            }

            if (Me.GotTarget &&
                Me.CurrentTarget.Guid != lastGuid ||
                InfoPanel.Deaths > deathCount)
            {
                if (InfoPanel.Deaths > deathCount)
                {
                    deathCount = InfoPanel.Deaths;
                }

                fightTimer.Reset();
                fightTimer.Start();
                lastGuid = Me.CurrentTarget.Guid;
                SliceAndDiceUsed = false;
            }

            if (combatChecks())
            {
                addsList = getAdds();

                if (addsList.Count > 1)
                {
                    KillingSpree();
                    BladeFlurry();
                    AdrenalineRush();
                }

                if (Me.ComboPoints > 5)
                {
                    slog(Me.ComboPoints.ToString() + " combo points.  Need to restart WoW.");
                }

                if (Me.ComboPoints < 3 &&
                    !SliceAndDiceUsed)
                {
                    SliceAndDice();
                    SliceAndDiceUsed = true;
                }

            }
            else
            {
                // slog("combatChecks() failed 1");
            }

            if (combatChecks())
            {
                Berserking();
                Bloodrage();

                if (Me.CurrentTarget.IsCasting)
                {
                    Kick();
                    ArcaneTorrent();
                }

                if (Me.ComboPoints < killComboCount ||
                    Me.ComboPoints >= 5)    // allows for buggy combo count
                {
                    SinisterStrike();
                }
                else
                {
                    Eviscerate();
                }
            }
            else
            {
                // slog("combatChecks() failed 2");
            }


            if (Me.HealthPercent < 50)
            {
                slog("Health low.");
                KillingSpree();
                Evasion();
                AdrenalineRush();
                Stoneform();
            }

            if ((Me.HealthPercent < 30 &&
                Me.CurrentTarget.HealthPercent > Me.CurrentTarget.HealthPercent))
            {
                Logic.Common.Combat.Healing.UseHealthPotion();
            }

            if (Me.GotTarget
                && !Me.CurrentTarget.IsPlayer
                && fightTimer.ElapsedMilliseconds > 40 * 1000 &&
                Me.CurrentTarget.HealthPercent < 95)
            {
                slog(" This " + Me.CurrentTarget.Name + " is a bugged mob.  Combat blacklisting for 1 hour.");

                Logic.Blacklist.Add(Me.CurrentTarget.Guid, TimeSpan.FromHours(1.00));

                SafeMove(WoWMovement.MovementDirection.Backward, 5000);
                Me.ClearTarget();
                lastGuid = 0;

            }

        }

        #endregion

        #region Spells

        void SinisterStrike()
        {
            if (Me.GotTarget &&
                targetDistance <= 5 &&
                SpellManager.CastSpell("Sinister Strike"))
            {
                slog("Sinister Strike.");
            }
        }

        bool Throw()
        {
            if (Me.GotTarget &&
                !Me.Combat)
            {
                if (Me.CurrentTarget.Distance >= 6 && Me.CurrentTarget.Distance <= 28)
                {
                    if (SpellManager.CastSpell("Throw")) //Found Throw
                    {
                        slog("Throw.");
                        return true;
                    }
                }
            }
            return false;

        }

        //Eviscerate (Req Level 1)

        void Eviscerate()
        {
            if (Me.GotTarget &&
                targetDistance <= 5 &&
                SpellManager.CastSpell("Eviscerate"))
            {
                slog("Eviscerate.");
            }
        }

        /// Stealth (Req Level 2)

        void Stealth()
        {
            if (!Me.Combat) //Cant stealth in combat!
            {
                if (!Me.Buffs.ContainsKey("Stealth") &&
                    SpellManager.CastSpell("Stealth"))
                {
                    slog("Stealth.");
                }
            }
        }

        // Evasion
        void Evasion()
        {
            if (Me.GotTarget &&
                targetDistance <= 5 &&
                SpellManager.CastSpell("Evasion"))
            {
                slog("Evasion.");
            }
        }

        // Sprint
        void Sprint()
        {
            if (SpellManager.CastSpell("Sprint"))
            {
                slog("Sprint.");
            }
        }

        // Backstab
        void Backstab()
        {
            if (Me.GotTarget &&
                targetDistance <= 5 &&
                SpellManager.CastSpell("Backstab"))
            {
                slog("Try to Backstab.");
            }
        }

        // Gouge
        void Gouge()
        {
            if (Me.GotTarget &&
                targetDistance <= 5 &&
                SpellManager.CastSpell("Gouge"))
            {
                slog("Gouge.");
            }
        }

        // Gouge
        void CheapShot()
        {
            if (Me.GotTarget &&
                targetDistance <= 5 &&
                SpellManager.CastSpell("Cheap Shot"))
            {
                slog("Cheap Shot.");
            }
        }

        // Kick
        void Kick()
        {
            if (Me.GotTarget &&
                targetDistance <= 5 &&
                SpellManager.CastSpell("Kick"))
            {
                slog("Kick.");
            }
        }

        // Garrote
        void Garrote()
        {
            if (Me.GotTarget &&
                targetDistance <= 5 &&
                SpellManager.CastSpell("Garrote"))
            {
                slog("Try to Garrote.");
            }
        }

        // Ambush
        void Ambush()
        {
            if (Me.GotTarget &&
                targetDistance <= 5 &&
                SpellManager.CastSpell("Ambush"))
            {
                slog("Try to Ambush.");
            }
            else
            {
                Backstab();
            }
        }

        void SliceAndDice()
        {
            if (Me.GotTarget &&
                targetDistance <= 5 &&
                SpellManager.CastSpell("Slice and Dice")) //Found SS
            {
                slog("Slice and Dice.");
            }
        }

        void BladeFlurry()
        {
            if (Me.GotTarget &&
                targetDistance <= 5 &&
                SpellManager.CastSpell("Blade Flurry"))
            {
                slog("Blade Flurry.");
            }
        }

        void AdrenalineRush()
        {
            if (Me.GotTarget &&
                targetDistance <= 5 &&
                SpellManager.CastSpell("Adrenaline Rush"))
            {
                slog("Adrenaline Rush.");
            }
        }

        void KillingSpree()
        {
            if (Me.GotTarget &&
                targetDistance <= 5 &&
                SpellManager.CastSpell("Killing Spree"))
            {
                slog("Killing Spree.");
            }
        }

        #endregion

        #region horde racials

        // Berserking
        void Berserking()
        {
            if (SpellManager.CastSpell("Berserking"))
            {
                Styx.Helpers.Logging.Write("Berserking.");
            }
        }

        // Bloodrage
        void Bloodrage()
        {
            if (SpellManager.CastSpell("Bloodrage"))
            {
                Styx.Helpers.Logging.Write("Bloodrage.");
            }
        }

        // War Stomp
        void WarStomp()
        {
            if (SpellManager.CastSpell("War Stomp"))
            {
                Styx.Helpers.Logging.Write("War Stomp.");
            }
        }

        // Arcane Torrent
        void ArcaneTorrent()
        {
            if (SpellManager.CastSpell("Arcane Torrent"))
            {
                Styx.Helpers.Logging.Write("Arcane Torrent.");
            }
        }

        // Will of the Forsaken 
        void WillOfTheForsaken()
        {
            if (SpellManager.CastSpell("Will of the Forsaken"))
            {
                Styx.Helpers.Logging.Write("Will of the Forsaken.");
            }
        }
        #endregion

        #region alliance racials

        // Stoneform
        void Stoneform()
        {
            if (SpellManager.CastSpell("Stoneform"))
            {
                Styx.Helpers.Logging.Write("Stoneform.");
            }
        }

        // Gift of the Naaru
        void GiftOfTheNaaru()
        {
            if (SpellManager.CastSpell("Gift of the Naaru"))
            {
                Styx.Helpers.Logging.Write("Gift of the Naaru.");
            }
        }

        // Every Man for Himself
        void EveryManForHimself()
        {
            if (SpellManager.CastSpell("Every Man for Himself"))
            {
                Styx.Helpers.Logging.Write("Every Man for Himself.");
            }
        }

        // Shadowmeld
        void Shadowmeld()
        {
            if (SpellManager.CastSpell("Shadowmeld"))
            {
                Styx.Helpers.Logging.Write("Shadowmeld.");
            }
        }

        // Escape Artist
        void EscapeArtist()
        {
            if (SpellManager.CastSpell("Escape Artist"))
            {
                Styx.Helpers.Logging.Write("Escape Artist.");
            }
        }


        #endregion

        #region combat checks

        // Instant Poison Entry Ids
        private List<uint> PoisonEntryIds = new List<uint>()
        {
            6497, 6949, 6950, 8926, 8927,8928,21927,43230,43231
        };

        private Stopwatch poisonTimer = new Stopwatch();

        // Instant Poison Enchant Ids
        private List<short> PoisonEnchantIds = new List<short>()
        {
            323, 324, 325, 623, 624, 625, 2641, 3768, 3769
        };

        private bool NeedPoisons()
        {
            // over level 10
            if (Me.Level < 10)
            {
                return false;
            }
            // timer to ease burden on cpu
            if (!poisonTimer.IsRunning)
            {
                poisonTimer.Reset();
                poisonTimer.Start();
            }

            if (poisonTimer.ElapsedMilliseconds < 20 * 1000)
            {
                return false;
            }

            // look at weapons and see if they have poisons applied
            if (PoisonEnchantIds.Contains(Me.Mainhand.ItemEnchant) &&
                PoisonEnchantIds.Contains(Me.Offhand.ItemEnchant))
            {
                return false;
            }

            // look at all items in inventory and check we have poisons to apply
            WoWItem instantPoison = HaveItemCheck(PoisonEntryIds);

            if (Equals(null, instantPoison))
            {
                return false;
            }
            return true;
        }

        private void ApplyPoisons()
        {
            poisonTimer.Reset();
            poisonTimer.Start();

            WoWItem instantPoison = HaveItemCheck(PoisonEntryIds);

            if (!Equals(null, instantPoison))
            {
                if (Me.Mounted)
                    Logic.Mount.Dismount();
            }

            slog("Apply Poisons.");

            WoWMovement.MoveStop();

            // do offhand 
            if (!PoisonEnchantIds.Contains(Me.Offhand.ItemEnchant))
            {
                Lua.DoString("UseItemByName(\"" + instantPoison.Entry + "\")");
                Thread.Sleep(100);
                Lua.DoString("UseInventoryItem(17)");
                Thread.Sleep(3100);
            }

            // now mainhand
            if (!PoisonEnchantIds.Contains(Me.Mainhand.ItemEnchant))
            {
                Lua.DoString("UseItemByName(\"" + instantPoison.Entry + "\")");
                Thread.Sleep(100);
                Lua.DoString("UseInventoryItem(16)");
                Thread.Sleep(3100);
            }
        }

        private WoWItem HaveItemCheck(List<uint> listId)
        {
            foreach (WoWItem item in ObjectManager.GetObjectsOfType<WoWItem>(false))
            {
                if (listId.Contains(item.Entry))
                {
                    return item;
                }
            }
            return null;
        }

        private bool combatChecks()
        {

            if (!Me.GotTarget)
            {
                slog("No target.");
                return false;
            }

            if (Me.Dead)
            {
                slog("I died.");
                return false;
            }

            if (Me.GotTarget &&
                !Me.IsAutoAttacking)
            {
                Lua.DoString("StartAttack()");
            }

            if (targetDistance > 50)
            {
                slog("Out of range: " + Me.CurrentTarget.Name + " is " + System.Math.Round(targetDistance).ToString() + " yards away.");
                return false;
            }

            double meleeRange = 5;

            if (targetDistance > meleeRange)
            {
                slog(Me.CurrentTarget.Name + " is at " + System.Math.Round(targetDistance).ToString() + " yards.");

                // get within range
                WoWMovement.ClickToMove(attackPoint);
            }

            WoWMovement.Face();

            return true;
        }

        private List<WoWUnit> getAdds()
        {
            List<WoWUnit> mobList = ObjectManager.GetObjectsOfType<WoWUnit>(false);
            List<WoWUnit> enemyMobList = new List<WoWUnit>();

            foreach (WoWUnit thing in mobList)
            {
                try
                {
                    if ((thing.Guid != Me.Guid) &&
                    thing.IsTargetingMe)
                    {
                        enemyMobList.Add(thing);
                    }
                }
                catch (Exception ex)
                {
                    slog("Add error.");
                }
            }

            if (enemyMobList.Count > 1)
            {
                slog("Warning: there are " + enemyMobList.Count.ToString() + " attackers.");
            }
            return enemyMobList;

        }
        #endregion

        #region movement logic

        private void SafeMove(WoWMovement.MovementDirection direction, int duration)
        {
            DateTime start = DateTime.Now;

            WoWMovement.Move(direction);

            while (ObjectManager.Me.HealthPercent > 1)
            {
                Thread.Sleep(100);
                if (DateTime.Now.Subtract(start).Milliseconds >= duration)
                {
                    break;
                }                
            }

            WoWMovement.MoveStop();

        }

        WoWPoint attackPointBuffer;
        WoWPoint attackPoint
        {
            get
            {
                if (Me.GotTarget)
                {
                    if (!movementTimer.IsRunning ||
                        movementTimer.ElapsedMilliseconds > 2500)
                    {
                        movementTimer.Reset();
                        movementTimer.Start();
                        attackPointBuffer = WoWMovement.CalculatePointFrom(Me.CurrentTarget.Location, 4.5f);
                        return attackPointBuffer;
                    }
                    else
                    {
                        return attackPointBuffer;
                    }
                }
                else
                {
                    WoWPoint noSpot = new WoWPoint();
                    return noSpot;
                }
            }
        }

        WoWPath pathExists = new WoWPath(ObjectManager.Me.Location, ObjectManager.Me.Location);
        private static bool UseNavigator;
        private WoWUnit _lastTarget;
        private WoWPoint _dest = WoWPoint.Invalid;
        private WoWPoint GetTraceLinePos()
        {
            return new WoWPoint(Me.X, Me.Y, Me.Z + 2.132f);
        }

        private static Stopwatch movementTimer = new Stopwatch();

        #endregion
    }
}
#pragma warning restore