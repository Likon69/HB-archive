﻿#pragma warning disable
namespace Styx.Bot.CustomClasses
{
    using Styx;
    using System;
    using System.Diagnostics;
    using Helpers;
    using Styx.Logic;
    using System.Collections.Generic;
    using Logic.Pathing;
    using System.Threading;
    using Logic.Common.Combat;
    using Object_Dumping_Enumeration;
    using CustomCombat.CombatInterface;
    using Object_Dumping_Enumeration.WoWObjects;
    using Styx.Memory_Read_Write_Inject.Lua;

    class Hunter : ICombat
    {
        #region variables
        public WoWClass Class { get { return WoWClass.Hunter; } }
        public string Name { get { return "Hawker's Beast Master 1.3"; } }

        private string _logspam;
        private readonly LocalPlayer Me = ObjectManager.Me;

        private static Stopwatch feedPetTimer = new Stopwatch();
        private static Stopwatch aspectTimer = new Stopwatch();
        private static Stopwatch petPresenceTimer = new Stopwatch();
        private static Stopwatch fightTimer = new Stopwatch();
        private static ulong lastGuid;
        private bool noDrink;
        private bool noFood;
        private double restAspectOfTheViper = 90;

        private bool enemyClose = false;

        Point pointNow = new Point();

        List<WoWUnit> addsList = new List<WoWUnit>();

        private WoWUnit myTarget { get; set; }

        private double targetDistance
        {
            get
            {
                return Me.GotTarget ? Me.CurrentTarget.Distance : uint.MaxValue - 1;
            }
        }

        private static Stopwatch pullTimer = new Stopwatch();
        private static Stopwatch moveTimer = new Stopwatch();

        /// <summary>
        /// Item ID's of all ammos taken on 9/23/2009 from http://www.wowhead.com/?items=6 
        /// Total of 50 ID's were found.
        /// THANKS IGGY
        /// </summary>
        bool outOfAmmo
        {
            get
            {
                List<uint> _ammoEntryId = new List<uint>()
                {
                    30319,34581,34582,32760,32761,31737,31735,23773,33803,12654,10579,32883,30612,30611,32882,41164,
                    13377,11630,41165,31949,3465,3464,23772,10512,19316,19317,10513,9399,24417,18042,15997,11284,
                    28056,8068,8067,8069,4960,41584,2519,28060,28061,11285,2516,3030,2512,2515,5568,3033,41586,28053
                };
                List<WoWItem> itemList = ObjectManager.GetObjectsOfType<WoWItem>(false);
                foreach (WoWItem item in itemList)
                {
                    if (_ammoEntryId.Contains(item.Entry))
                        return false;
                }
                return true;
            }
        }

        #endregion

        #region rest and buffs
        public bool NeedRest
        {
            get
            {
                bool restNeeded = false;

                if (!feedPetTimer.IsRunning)
                {
                    feedPetTimer.Reset();
                    feedPetTimer.Start();
                }

                if (!aspectTimer.IsRunning)
                {
                    aspectTimer.Reset();
                    aspectTimer.Start();
                }

                if (!petPresenceTimer.IsRunning)
                {
                    petPresenceTimer.Reset();
                    petPresenceTimer.Start();
                }

                if (!Me.Mounted)
                {

                    if (petPresenceTimer.ElapsedMilliseconds > 3000 &&
                        SpellManager.KnownSpells.ContainsKey("Call Pet") &&
                        !Me.GotAlivePet)
                    {
                        slog("No pet.");
                        restNeeded = true;
                    }
                }

                // 3 second timer on aspect changes for the mobs that wander in and out of Pull distance
                if (aspectTimer.ElapsedMilliseconds > 3000 &&
                    Me.ManaPercent < restAspectOfTheViper &&
                    SpellManager.KnownSpells.ContainsKey("Aspect of the Viper") &&
                    !Me.Buffs.ContainsKey("Aspect of the Viper"))
                {
                    slog("Need Aspect of the Viper.");
                    restNeeded = true;
                }

                if ((feedPetTimer.IsRunning &&
                        feedPetTimer.ElapsedMilliseconds > 60 * 1000) &&
                    SpellManager.KnownSpells.ContainsKey("Call Pet") &&
                    Me.GotAlivePet &&
                    Me.Pet.CurrentHappiness > 0 &&
                    Me.Pet.CurrentHappiness < 65 &&
                    !Me.Pet.Buffs.ContainsKey("Feed Pet"))
                {
                    slog("Pet happiness: " + Me.Pet.CurrentHappiness.ToString());
                    restNeeded = true;
                }

                if (SpellManager.KnownSpells.ContainsKey("Mend Pet") &&
                    Me.GotAlivePet &&
                    Me.Pet.HealthPercent < 50 &&
                    !Me.Pet.Buffs.ContainsKey("Mend Pet"))
                {
                    slog("Heal the pet.");
                    restNeeded = true;
                }

                if (Battlegrounds.Battlegroundstatus == BattlegroundStatus.Active)
                {
                    return false;
                }

                if (!noFood && Me.HealthPercent < 50)
                {
                    slog("Low health.");
                    restNeeded = true;
                }

                if (!noDrink &&
                    Me.ManaPercent < 45)
                {
                    slog("Low mana");
                    restNeeded = true;
                }
                return restNeeded;
            }
        }



        public void Rest()
        {
            if (Me.ManaPercent < restAspectOfTheViper &&
                SpellManager.KnownSpells.ContainsKey("Aspect of the Viper") &&
                !Me.Buffs.ContainsKey("Aspect of the Viper"))
            {
                slog("Aspect of the Viper.");
                Thread.Sleep(1501); // why do I need this???
                AspectOfTheViper();
            }

            if (SpellManager.KnownSpells.ContainsKey("Call Pet") &&
                !Me.GotAlivePet)
            {
                CallPet();
                Thread.Sleep(500);
                if (!Me.GotAlivePet)
                {
                    slog("No pet appeared.");
                    Thread.Sleep(1100);
                    FreezingTrap();
                    Thread.Sleep(1500);
                    RevivePet();
                }
            }

            if (SpellManager.KnownSpells.ContainsKey("Call Pet") &&
                Me.GotAlivePet &&
                Me.Pet.CurrentHappiness < 65)
            {
                FeedPet();
            }

            if (SpellManager.KnownSpells.ContainsKey("Mend Pet") &&
                Me.GotAlivePet &&
                Me.Pet.HealthPercent < 50)
            {
                MendPet();
            }

            Lua.DoString("luaFoodCount = GetItemCount(\"" + Logic.Common.Rest.FoodName + "\")");
            uint foodCount = Lua.GetLocalizedUInt32("luaFoodCount", ObjectManager.Me.BaseAddress);

            if (foodCount < 1)
            {
                noFood = true;
            }
            else
            {
                noFood = false;
            }

            if (!noFood &&
                Me.HealthPercent < 50)
            {
                Logic.Common.Rest.Feed();
            }

            Lua.DoString("luaDrinkCount = GetItemCount(\"" + Logic.Common.Rest.DrinkName + "\")");
            uint DrinkCount = Lua.GetLocalizedUInt32("luaDrinkCount", ObjectManager.Me.BaseAddress);

            if (DrinkCount < 1)
            {
                noDrink = true;
            }
            else
            {
                noDrink = false;
            }

            if (!noDrink && Me.ManaPercent < 40)
            {
                Logic.Common.Rest.Feed();
            }
        }
        public bool NeedPreCombatBuffs { get { return false; } }
        public void PreCombatBuff() { }
        public bool NeedCombatBuffs { get { return false; } }
        public void CombatBuff() { }
        public bool NeedHeal { get { return false; } }
        public void Heal() { }
        public bool NeedPullBuffs { get { return false; } }
        public void PullBuff() { }
        #endregion

        #region pull
        public void Pull()
        {
            #region checks
            if (Battlegrounds.Battlegroundstatus == BattlegroundStatus.Active)
            {
                if (Me.GotTarget &&
                    Me.CurrentTarget.IsPet)
                {
                    Blacklist.Add(Me.CurrentTarget, TimeSpan.FromDays(1));
                    Me.ClearTarget();
                }

                if (Me.GotTarget && Me.CurrentTarget.Mounted)
                {
                    Blacklist.Add(Me.CurrentTarget, TimeSpan.FromMinutes(1));
                    Me.ClearTarget();
                }
            }

            if (Me.CurrentTarget.Guid != lastGuid)
            {
                fightTimer.Reset();
                lastGuid = Me.CurrentTarget.Guid;
                slog("Killing " + Me.CurrentTarget.Name + " at distance " +
                    System.Math.Round(targetDistance).ToString() + ".");
                pullTimer.Reset();
                pullTimer.Start();

            }
            else
            {
                if (pullTimer.ElapsedMilliseconds > 30 * 1000)
                {
                    slog("Cannot pull " + Me.CurrentTarget.Name + " now.  Blacklist for 3 minutes.");
                    Styx.Logic.Blacklist.Add(Me.CurrentTarget.Guid, System.TimeSpan.FromMinutes(3));
                }
            }

            #endregion
            double shotRange = SpellManager.KnownSpells["Auto Shot"].MaxRange - 1;

            if (Me.CurrentTarget.Distance > shotRange)
            {
                WoWMovement.ClickToMove(attackPoint);

                int i = 0;
                while (i < 8 &&
                    Me.Location.Distance(attackPoint) > 1)
                {
                    Thread.Sleep(250);
                    ++i;
                }

                return;
            }
            else
            {
                WoWMovement.MoveStop();

                if (Me.GotTarget && Me.GotAlivePet)
                {
                    if (!Me.Pet.IsAutoAttacking)
                    {
                        Lua.DoString("PetAttack()");
                    }

                    petPresenceTimer.Reset();
                    if (Me.CurrentTarget.Level - Me.Level == 1)
                    {
                        slog("Let " + Me.Pet.Name + " gain aggro.");
                        Thread.Sleep(1000);
                    }
                    else if (Me.CurrentTarget.Level - Me.Level > 1)
                    {
                        slog("Let " + Me.Pet.Name + " face this mob alone for a bit.");
                        Thread.Sleep(2000);
                    }
                }

                WoWMovement.Face();

                SelectAspect();
                HuntersMark();

                if (SpellManager.KnownSpells.ContainsKey("Concussive Shot") &&
                    !SpellManager.KnownSpells["Concussive Shot"].Cooldown)
                {
                    ConcussiveShot();
                }
                else
                {
                    ArcaneShot();
                    AutoShot();
                }

            }
        }
        #endregion

        #region combat
        #region noammo
        private void NoAmmoCombat()
        {
            if (Me.GotTarget &&
                Me.CurrentTarget.Distance > 4)
            {
                WoWMovement.ClickToMove(Me.CurrentTarget.Location);
            }
            else
            {
                WoWMovement.Face();

                if (SpellManager.KnownSpells.ContainsKey("Immolation Trap") &&
                            !SpellManager.KnownSpells["Immolation Trap"].Cooldown)
                {
                    ImmolationTrap();
                }
                else if (SpellManager.KnownSpells.ContainsKey("Raptor Strike") &&
                            !SpellManager.KnownSpells["Raptor Strike"].Cooldown)
                {
                    RaptorStrike();
                }
                else if (SpellManager.KnownSpells.ContainsKey("Mongoose Bite") &&
                    !SpellManager.KnownSpells["Mongoose Bite"].Cooldown)
                {
                    MongooseBite();
                }
            }
        }
        #endregion
        #region ranged/normal dps
        private void RangedCombat()
        {
            double shotRange = SpellManager.KnownSpells["Auto Shot"].MaxRange - 1;

            if (Me.CurrentTarget.Distance > shotRange)
            {
                Navigator.MoveTo(attackPoint);
                return;
            }

            WoWMovement.MoveStop();
            WoWMovement.Face();

            HuntersMark();

            if (Me.GotTarget &&
                SpellManager.KnownSpells.ContainsKey("Kill Shot") &&
                !SpellManager.KnownSpells["Kill Shot"].Cooldown &&
                Me.CurrentTarget.HealthPercent < 20)
            {
                KillShot();
            }

            AimedShot();

            if (Me.GotTarget &&
                SpellManager.KnownSpells.ContainsKey("Steady Shot"))
            {
                ConcussiveShot();
                SteadyShot();
            }

            if (Me.GotTarget &&
                SpellManager.KnownSpells.ContainsKey("Arcane Shot"))
            {
                ArcaneShot();
            }
        }
        #endregion
        #region melee on me
        private void UsePet()
        {
            if (SpellManager.KnownSpells.ContainsKey("Disengage") &&
                !SpellManager.KnownSpells["Disengage"].Cooldown)
            {
                WingClip();
                Thread.Sleep(1500);
                Disengage();
            }
            else if (SpellManager.KnownSpells.ContainsKey("Intimidation") &&
                    !SpellManager.KnownSpells["Intimidation"].Cooldown)
            {
                Intimidation();
                WoWMovement.Move(WoWMovement.MovementDirection.StrafeLeft);
                Thread.Sleep(1000);
                WoWMovement.MoveStop();
                WoWMovement.Face();
            }
            else if (SpellManager.KnownSpells.ContainsKey("Frost Trap") &&
                !SpellManager.KnownSpells["Frost Trap"].Cooldown)
            {
                FrostTrap();
                WoWMovement.Move(WoWMovement.MovementDirection.StrafeRight);
                Thread.Sleep(1000);
                WoWMovement.MoveStop();
                WoWMovement.Face();

            }
            else if (SpellManager.KnownSpells.ContainsKey("Wing Clip") &&
                !SpellManager.KnownSpells["Wing Clip"].Cooldown)
            {
                WingClip();
                WoWMovement.Move(WoWMovement.MovementDirection.StrafeLeft);
                Thread.Sleep(1000);
                WoWMovement.MoveStop();
                WoWMovement.Face();

            }
            else if (SpellManager.KnownSpells.ContainsKey("Immolation Trap") &&
                !SpellManager.KnownSpells["Immolation Trap"].Cooldown)
            {
                ImmolationTrap();
            }
            else if (SpellManager.KnownSpells.ContainsKey("Feign Death") &&
                !SpellManager.KnownSpells["Feign Death"].Cooldown &&
                Me.GotAlivePet)
            {
                FeignDeath();
                Thread.Sleep(5 * 1000);
                KeyboardManager.KeyUpDown(' ');
            }
            else if (SpellManager.KnownSpells.ContainsKey("Raptor Strike") &&
                !SpellManager.KnownSpells["Raptor Strike"].Cooldown)
            {
                RaptorStrike();
            }
            else if (SpellManager.KnownSpells.ContainsKey("Mongoose Bite") &&
                !SpellManager.KnownSpells["Mongoose Bite"].Cooldown)
            {
                MongooseBite();
            }
        }
        #endregion
        #region pvp
        private void KillPlayer()
        {
            double shotRange = SpellManager.KnownSpells["Auto Shot"].MaxRange - 1;

            
            ImmolationTrap();
            Intimidation();

            if (Me.CurrentTarget.Distance > 7 &&
                Me.CurrentTarget.Distance < shotRange)
            {                
                BestialWrath();
                SerpentSting();
                ArcaneShot();
            }
            else
            {
                
                if (SpellManager.KnownSpells.ContainsKey("Disengage") &&
                    !SpellManager.KnownSpells["Disengage"].Cooldown)
                {
                    SnakeTrap();
                    WingClip();
                    Thread.Sleep(1500);
                    Disengage();
                }
                else
                {
                    FrostTrap();
                    BestialWrath();
                    WingClip();
                    RaptorStrike();
                    MongooseBite();
                }
            }
        }
        #endregion

        public void Combat()
        {
            if (SpellManager.KnownSpells.ContainsKey("Call Pet") &&
                !Me.GotAlivePet)
            {
                CallPet();
            }

            if (Battlegrounds.Battlegroundstatus == BattlegroundStatus.Active)
            {
                if (Me.GotTarget &&
                    Me.CurrentTarget.IsPet)
                {
                    Blacklist.Add(Me.CurrentTarget, TimeSpan.FromDays(1));
                    Me.ClearTarget();
                    return;
                }
            }

            if (Me.GotTarget)
            {
                WoWMovement.Face();
                AutoShot();
                if (Me.GotAlivePet)
                {
                    Lua.DoString("PetAttack()");
                }
            }

            // bugged mobs 
            if (!fightTimer.IsRunning ||
               Me.CurrentTarget.Guid != lastGuid)
            {
                fightTimer.Reset();
                fightTimer.Start();
                lastGuid = Me.CurrentTarget.Guid;
            }

            // sometimes the attack is on the pet
            if (!Me.GotTarget)
            {
                addsList = getAdds();
                if (addsList.Count > 0)
                {
                    addsList[0].Target();
                    WoWMovement.Face();
                }
                else
                    if (Me.GotAlivePet &&
                        Me.Pet.Combat)
                    {
                        Lua.DoString("PetFollow()");
                        Me.Pet.CurrentTarget.Target();
                        WoWMovement.Face();
                    }
            }

            addsList = getAdds();
            if (addsList.Count > 1)
            {
                if (Me.GotTarget &&
                    Me.CurrentTarget.HealthPercent > 50)
                {
                    MendPet();
                    RapidFire();
                    BestialWrath();
                }

                if (Me.HealthPercent < 50)
                {
                    FreezingTrap();
                }
                else
                {
                    ImmolationTrap();
                }

                KillCommand();
            }

            // autoattack + pet attack = very cheap level 80
            if (Me.GotTarget && Me.GotAlivePet)
            {
                if (!Me.Pet.IsAutoAttacking)
                {
                    Lua.DoString("PetAttack()");
                }

                if (Me.CurrentTarget.HealthPercent > 60)
                {
                    KillCommand();
                }

                petPresenceTimer.Reset();
            }

            if (Me.GotTarget && Me.CurrentTarget.HealthPercent > Me.HealthPercent)
            {
                BestialWrath();
            }

            if (Me.GotAlivePet &&
                Me.Pet.HealthPercent < 50 &&
                !Me.Pet.Buffs.ContainsKey("Mend Pet"))
            {
                MendPet();
            }

            SelectAspect();

            if (Me.HealthPercent < 40)
            {
                Logic.Common.Combat.Healing.UseHealthPotion();
            }

            if (Me.ManaPercent < 40)
            {
                Logic.Common.Combat.Healing.UseManaPotion();
            }

            if (!Me.GotTarget)
            {
                Me.ClearTarget();
                return;
            }

            if (outOfAmmo)
            {
                slog("No ammo.");
                NoAmmoCombat();
            }
            else if (ObjectManager.Me.GotTarget && ObjectManager.Me.CurrentTarget.IsPlayer)
            {
                KillPlayer();
            }
            else
            {
                if (ObjectManager.Me.GotTarget && !Me.IsAutoAttacking)
                    Lua.DoString("StartAttack()");

                if (Me.GotTarget &&
                    Me.CurrentTarget.Distance > 7)
                #region ranged
                {
                    RangedCombat();
                }
                #endregion
                else
                {
                    if (Me.GotAlivePet &&
                        Me.CurrentTarget.CurrentTargetGuid == Me.Guid)
                    // slow the target and get range
                    {
                        slog(Me.CurrentTarget.Name + " is attacking me.  Use pet and get range.");
                        UsePet();
                    }
                    else if (Me.GotAlivePet)
                    // get range and let pet fight
                    {
                        slog(Me.CurrentTarget.Name + " is too close.");
                        WoWMovement.Move(WoWMovement.MovementDirection.StrafeLeft);
                        Thread.Sleep(1000);
                        WoWMovement.MoveStop();
                        WoWMovement.Face();
                    }
                    else
                    {
                        NoAmmoCombat();
                    }
                }
            }

            if (!Me.CurrentTarget.IsPlayer && 
                fightTimer.ElapsedMilliseconds > 40 * 1000 &&
                Me.CurrentTarget.HealthPercent > 95)
            {
                slog(" This " + Me.CurrentTarget.Name + " is a bugged mob.  Blacklisting for 1 hour.");

                Logic.Blacklist.Add(Me.CurrentTarget.Guid, TimeSpan.FromHours(1.00));

                Styx.Helpers.KeyboardManager.PressKey('S');
                Thread.Sleep(5 * 1000);
                Styx.Helpers.KeyboardManager.ReleaseKey('S');
                Me.ClearTarget();
                lastGuid = 0;
            }
             
        }
        public void HandleFalling() { }
        #endregion

        #region hunter spells

        /// <summary>
        /// Automatically shoots the target until cancelled.  Ranged attacks fired by a Hunter all have 15% increased attack speed.
        /// </summary>
        private bool AutoShot()
        {
            if (Me.GotTarget && SpellManager.CastSpell("Auto Shot"))
            {
                slog("Auto Shot.");
                return true;
            }
            else
            {
                // slog("Can't use shoot now.");
                return false;
            }
        }

        /// <summary>
        /// A strong attack that increases melee damage
        /// </summary>        
        private bool RaptorStrike()
        {
            if (Me.GotTarget && SpellManager.CastSpell("Raptor Strike"))
            {
                WoWMovement.Face();
                slog("Raptor Strike.");
                return true;
            }
            else
            {
                // slog("Can't use Raptor Strike now.");
                return false;
            }
        }

        /// <summary>
        /// The hunter takes on the aspects of a monkey, increasing chance to dodge by 18%.  Only one Aspect can be active at a time.
        /// </summary>        
        private bool AspectofTheMonkey()
        {
            if (SpellManager.CastSpell("Aspect of the Monkey"))
            {
                slog("Aspect of the Monkey.");
                aspectTimer.Reset();
                aspectTimer.Start();
                return true;
            }
            else
            {
                // slog("Can't use Aspect of the Monkey now.");
                return false;
            }
        }

        /// <summary>
        /// Stings the target, causing Nature damage over 15 sec.  Only one Sting per Hunter can be active on any one target.
        /// </summary>        
        private bool SerpentSting()
        {
            if (Me.GotTarget && SpellManager.CastSpell("Serpent Sting"))
            {
                slog("Serpent Sting.");
                return true;
            }
            else
            {
                // slog("Can't use Serpent Sting now.");
                return false;
            }
        }

        /// <summary>
        /// An instant shot that causes Arcane damage.
        /// </summary>        
        private bool ArcaneShot()
        {
            if (Me.GotTarget && SpellManager.CastSpell("Arcane Shot"))
            {
                slog("Arcane Shot.");
                return true;
            }
            else
            {
                // slog("Can't use Arcane Shot now.");
                return false;
            }
        }

        /// <summary>
        /// Places the Hunter's Mark on the target, increasing the ranged attack power of all attackers against that target by 20.  In addition, the target of this ability can always be seen by the hunter whether it stealths or turns invisible.  The target also appears on the mini-map.  Lasts for 5 min.
        /// </summary>        
        private bool HuntersMark()
        {
            if (Me.GotTarget &&
                Me.CurrentTarget.Buffs.ContainsKey("Hunter's Mark"))
                return false;

            if (Me.GotTarget && SpellManager.CastSpell("Hunter's Mark"))
            {
                slog("Hunter's Mark.");
                return true;
            }
            else
            {
                // slog("Can't use Hunter's Mark now.");
                return false;
            }
        }

        /// <summary>
        /// Dazes the target, slowing movement speed by 50% for 4 sec.
        /// </summary>        
        private bool ConcussiveShot()
        {
            if (Me.GotTarget && Me.CurrentTarget.Buffs.ContainsKey("Concussive Shot"))
            {
                return true;
            }
            if (Me.GotTarget && SpellManager.CastSpell("Concussive Shot"))
            {
                WoWMovement.Face();
                slog("Concussive Shot.");
                return true;
            }
            else
            {
                // slog("Can't use Concussive Shot now.");
                return false;
            }
        }

        /// <summary>
        /// The hunter takes on the aspects of a hawk, increasing ranged attack power by 20.  Only one Aspect can be active at a time.
        /// </summary>
        private bool AspectOfTheHawk()
        {
            if (SpellManager.CastSpell("Aspect of the Hawk"))
            {
                slog("Aspect of the Hawk.");
                aspectTimer.Reset();
                aspectTimer.Start();
                return true;
            }
            else
            {
                // slog("Can't use Aspect of the Hawk now.");
                return false;
            }
        }

        /// <summary>
        /// Summons your pet to you.
        /// </summary>        
        private bool CallPet()
        {
            if (SpellManager.CastSpell("Call Pet"))
            {
                slog("Call Pet.");
                return true;
            }
            else
            {
                // slog("Can't use Call Pet now.");
                return false;
            }
        }

        /// <summary>
        /// Dismiss your pet.  Dismissing your pet will reduce its happiness by 50.
        /// </summary>        
        private bool DismissPet()
        {
            if (SpellManager.CastSpell("Dismiss Pet", false))
            {
                slog("Dismiss Pet.");
                return true;
            }
            else
            {
                // slog("Can't use Dismiss Pet now.");
                return false;
            }
        }

        /// <summary>
        /// Feed your pet the selected item.  Feeding your pet increases happiness.  Using food close to the pet's level will have a better result.
        /// </summary>        
        private bool FeedPet()
        {
            feedPetTimer.Reset();
            feedPetTimer.Start();

            Lua.DoString("luaFoodCount = GetItemCount(\"" + Logic.Common.Rest.FoodName + "\")");
            uint foodCount = Lua.GetLocalizedUInt32("luaFoodCount", Me.BaseAddress);

            if (foodCount < 1)
            {
                slog("No food!!");
                return false;
            }

            if (!Me.Combat &&
                Me.Pet.Distance > 9)
            {
                Thread.Sleep(1000);
            }

            if (SpellManager.CastSpell("Feed Pet", false))
            {
                Thread.Sleep(500);
                WoWMovement.MoveStop();
                Lua.DoString("UseItemByName(\"" + Logic.Common.Rest.FoodName + "\")");
                slog("Feed Pet...");

                Stopwatch eatingTimer = new Stopwatch();
                eatingTimer.Start();
                while (!Me.Combat &&
                    eatingTimer.ElapsedMilliseconds < 10 * 1000)
                {
                    Thread.Sleep(1000);
                }
                return true;
            }
            else
            {
                // slog("Can't use Feed Pet now.");
                return false;
            }
        }

        /// <summary>
        /// Revive your pet, returning it to life with 15% of its base health.
        /// </summary>        
        private bool RevivePet()
        {
            if (SpellManager.CastSpell("Revive Pet"))
            {
                slog("Revive Pet.");
                return true;
            }
            else
            {
                slog("Can't use Revive Pet now.");
                return false;
            }
        }

        /// <summary>
        /// Heals your pet for 125 health over 15 sec.
        /// </summary>        
        private bool MendPet()
        {
            if (!Me.GotAlivePet ||
                Me.Pet.Buffs.ContainsKey("Mend Pet"))
            {
                slog("Not Mend Pet time.");
            }



            if (!Me.Pet.Buffs.ContainsKey("Mend Pet") &&
                SpellManager.CastSpell("Mend Pet"))
            {
                slog("Mend Pet.");
                return true;
            }
            else
            {
                // slog("Can't use Mend Pet now.");
                return false;
            }
        }

        /// <summary>
        /// Maims the enemy, reducing the target's movement speed by 50% for 10 sec.
        /// </summary>        
        private bool WingClip()
        {
            if (Me.GotTarget && SpellManager.CastSpell("Wing Clip"))
            {
                slog("Wing Clip.");
                return true;
            }
            else
            {
                // slog("Can't use Wing Clip now.");
                return false;
            }
        }

        /// <summary>
        /// Scares a beast, causing it to run in fear for up to 10 sec.  Damage caused may interrupt the effect.  Only one beast can be feared at a time.
        /// </summary>        
        private bool ScareBeast()
        {
            if (Me.GotTarget && SpellManager.CastSpell("Scare Beast", false))
            {
                slog("Scare Beast.");
                return true;
            }
            else
            {
                // slog("Can't use Scare Beast now.");
                return false;
            }
        }

        /// <summary>
        /// Place a fire trap that will burn the first enemy to approach for Fire damage over 15 sec.  Trap will exist for 30 sec.  Only one trap can be active at a time.
        /// </summary>        
        private bool ImmolationTrap()
        {
            if (SpellManager.CastSpell("Immolation Trap"))
            {
                slog("Immolation Trap.");
                return true;
            }
            else
            {
                // slog("Can't use Immolation Trap now.");
                return false;
            }
        }

        /// <summary>
        /// Attack the enemy for damage.
        /// </summary>        
        private bool MongooseBite()
        {
            if (Me.GotTarget && SpellManager.CastSpell("Mongoose Bite"))
            {
                WoWMovement.Face();
                slog("Mongoose Bite.");
                return true;
            }
            else
            {
                // slog("Can't use Mongoose Bite now.");
                return false;
            }
        }

        /// <summary>
        /// The hunter takes on the aspect of the viper, causing ranged and melee attacks to regenerate mana but reducing your total damage done by 50%.  In addition, you gain 4% of maximum mana every 3 sec.  Mana gained is based on the speed of your ranged weapon. Requires a ranged weapon. Only one Aspect can be active at a time.
        /// </summary>        
        private bool AspectOfTheViper()
        {
            if (SpellManager.CastSpell("Aspect of the Viper"))
            {
                if (Me.CurrentTarget == Me)
                {
                    Me.ClearTarget();
                }
                // slog("Aspect of the Viper.");
                aspectTimer.Reset();
                aspectTimer.Start();
                return true;
            }
            else
            {
                // slog("Can't use Aspect of the Viper now.");
                return false;
            }
        }

        /// <summary>
        /// You attempt to disengage from combat, leaping backwards. Can only be used while in combat.
        /// </summary>        
        private bool Disengage()
        {
            if (SpellManager.CastSpell("Disengage"))
            {
                slog("Disengage.");
                return true;
            }
            else
            {
                // slog("Can't use Disengage now.");
                return false;
            }
        }

        /// <summary>
        /// Place a frost trap that freezes the first enemy that approaches, preventing all action for up to 10 sec.  Any damage caused will break the ice.  Trap will exist for 30 sec.  Only one trap can be active at a time.
        /// </summary>        
        private bool FreezingTrap()
        {
            if (SpellManager.CastSpell("Freezing Trap"))
            {
                slog("Freezing Trap.");
                return true;
            }
            else
            {
                // slog("Can't use Freezing Trap now.");
                return false;
            }
        }

        /// <summary>
        /// Stings the target, reducing chance to hit with melee and ranged attacks by 3% for 20 sec.  Only one Sting per Hunter can be active on any one target.
        /// </summary>        
        private bool ScorpidSting()
        {
            if (Me.GotTarget && SpellManager.CastSpell("Scorpid Sting"))
            {
                slog("Scorpid Sting.");
                return true;
            }
            else
            {
                // slog("Can't use Scorpid Sting now.");
                return false;
            }
        }

        /// <summary>
        /// Increases ranged attack speed by 40% for 15 sec.
        /// </summary>        
        private bool RapidFire()
        {
            if (Me.GotTarget && SpellManager.CastSpell("Rapid Fire"))
            {
                slog("Rapid Fire.");
                return true;
            }
            else
            {
                // slog("Can't use Rapid Fire now.");
                return false;
            }
        }

        private bool AimedShot()
        {
            if (Me.GotTarget &&
                !Me.CurrentTarget.Buffs.ContainsKey("Aimed Shot") &&
                SpellManager.CastSpell("Aimed Shot"))
            {
                slog("Aimed Shot.");
                return true;
            }
            return false;
        }

        /// <summary>
        /// Place a frost trap that creates an ice slick around itself for 30 sec when the first enemy approaches it.  All enemies within 10 yards will be slowed by 50% while in the area of effect.  Trap will exist for 30 sec.  Only one trap can be active at a time.
        /// </summary>
        private bool FrostTrap()
        {
            if (SpellManager.CastSpell("Frost Trap"))
            {
                slog("Frost Trap.");
                return true;
            }
            else
            {
                // slog("Can't use use Frost Trap now.");
                return false;
            }
        }

        /// <summary>
        /// Command your pet to intimidate the target on the next successful melee attack, causing a high amount of threat and stunning the target for 3 sec. Lasts 15 sec.
        /// </summary>        
        private bool Intimidation()
        {
            if (SpellManager.CastSpell("Intimidation"))
            {
                slog("Intimidation.");
                return true;
            }
            else
            {
                // slog("Can't use Intimidation now.");
                return false;
            }
        }

        /// <summary>
        /// The hunter takes on the aspects of a beast, becoming untrackable and increasing melee attack power of the hunter and the hunter's pet by 10%.  Only one Aspect can be active at a time.
        /// </summary>        
        private bool AspectOfTheBeast()
        {
            if (SpellManager.CastSpell("Aspect of the Beast"))
            {
                slog("Aspect of the Beast.");
                aspectTimer.Reset();
                aspectTimer.Start();
                return true;
            }
            else
            {
                // slog("Can't use Aspect of the Beast now.");
                return false;
            }
        }

        /// <summary>
        /// Feign death which may trick enemies into ignoring you.  Lasts up to 6 min.
        /// </summary>
        private bool FeignDeath()
        {
            if (SpellManager.CastSpell("Feign Death"))
            {
                slog("Feign Death.");
                return true;
            }
            else
            {
                // slog("Can't use Feign Death now.");
                return false;
            }
        }

        /// <summary>
        /// Place a fire trap that explodes when an enemy approaches, causing [RAP * 0.1 + 100] to [RAP * 0.1 + 130] Fire damage and burning all enemies for 150 additional Fire damage over 20 sec to all within 10 yards.  Trap will exist for 30 sec.  Only one trap can be active at a time.
        /// </summary>        
        private bool ExplosiveTrap()
        {
            if (SpellManager.CastSpell("Explosive Trap"))
            {
                slog("Explosive Trap.");
                return true;
            }
            else
            {
                // slog("Can't use Explosive Trap now.");
                return false;
            }
        }

        /// <summary>
        /// A steady shot that causes unmodified weapon damage, plus ammo, plus [RAP * 0.1 + 45].  Causes an additional 175 against Dazed targets.
        /// </summary>        
        private bool SteadyShot()
        {
            if (Me.GotTarget && SpellManager.CastSpell("Steady Shot"))
            {
                slog("Steady Shot.");
                return true;
            }
            else
            {
                // slog("Can't use Steady Shot now.");
                return false;
            }
        }

        /// <summary>
        /// Send your pet into a rage causing 50% additional damage for 10 sec.  While enraged, the beast does not feel pity or remorse or fear and it cannot be stopped unless killed.
        /// </summary>        
        private bool BestialWrath()
        {
            if (SpellManager.CastSpell("Bestial Wrath"))
            {
                slog("Bestial Wrath.");
                return true;
            }
            else
            {
                // slog("Can't use Bestial Wrath now.");
                return false;
            }
        }

        /// <summary>
        /// When activated, increases parry chance by 100% and grants a 100% chance to deflect spells.  While Deterrence is active, you cannot attack.  Lasts 5 sec.
        /// </summary>        
        private bool Deterrence()
        {
            if (SpellManager.CastSpell("Deterrence", false))
            {
                slog("Deterrence.");
                return true;
            }
            else
            {
                // slog("Can't use Deterrence now.");
                return false;
            }
        }

        /// <summary>
        /// Give the command to kill, increasing your pet's damage done from special attacks by 60% for 30 sec.  Each special attack done by the pet reduces the damage bonus by 20%.
        /// </summary>
        private bool KillCommand()
        {
            if (SpellManager.CastSpell("Kill Command"))
            {
                slog("Kill Command.");
                return true;
            }
            else
            {
                // slog("Can't use Kill Command now.");
                return false;
            }
        }

        /// <summary>
        /// Place a trap that will release several venomous snakes to attack the first enemy to approach.  The snakes will die after 15 sec.  Trap will exist for 30 sec.  Only one trap can be active at a time.
        /// </summary>
        private bool SnakeTrap()
        {
            if (SpellManager.CastSpell("Snake Trap"))
            {
                slog("Snake Trap.");
                return true;
            }
            else
            {
                // slog("Can't use Snake Trap now.");
                return false;
            }
        }

        /// <summary>
        /// You attempt to finish the wounded target off, firing a long range attack dealing 200% weapon damage plus [RAP * 0.40 + 410]. Kill Shot can only be used on enemies that have 20% or less health.
        /// </summary>
        private bool KillShot()
        {
            if (Me.GotTarget && SpellManager.CastSpell("Kill Shot"))
            {
                slog("Kill Shot.");
                return true;
            }
            else
            {
                // slog("Can't use Kill Shot now.");
                return false;
            }
        }

        /// <summary>
        /// The hunter takes on the aspects of a dragonhawk, increasing ranged attack power by 230 and chance to dodge by 18%.  Only one Aspect can be active at a time.
        /// </summary>        
        private bool AspectOfTheDragonhawk()
        {
            if (SpellManager.CastSpell("Aspect of the Dragonhawk"))
            {
                slog("Aspect of the Dragonhawk.");
                aspectTimer.Reset();
                aspectTimer.Start();
                return true;
            }
            else
            {
                // slog("Can't use Aspect of the Dragonhawk now.");
                return false;
            }
        }

        /// <summary>
        /// Fire a freezing arrow that places a Freezing Trap at the target location, freezing the first enemy that approaches, preventing all action for up to 20 sec.  Any damage caused will break the ice.  Trap will exist for 30 sec.  Only one trap can be active at a time.
        /// </summary>
        /// <param name="targetSpot"></param>        
        private bool FreezingArrow(WoWPoint targetSpot)
        {
            if (SpellManager.CastSpell("Freezing Arrow"))
            {
                slog("Freezing Arrow.");
                return true;
            }
            else
            {
                // slog("Can't use Freezing Arrow now.");
                return false;
            }
        }

        #endregion

        #region aspects

        bool usingAspectOfTheViper = false;
        private void SelectAspect()
        {
            if (aspectTimer.IsRunning &&
                aspectTimer.ElapsedMilliseconds < 3)
            {
                return;
            }

            if (Me.ManaPercent < 15)
            {
                AspectOfTheViper();
                usingAspectOfTheViper = true;
            }

            if (usingAspectOfTheViper && Me.ManaPercent < 100)
            {
                return;
            }
            else
            {
                usingAspectOfTheViper = false;
            }

            if (Me.GotTarget)
            {
                // ranged
                if (Me.CurrentTarget.Distance > 10)
                {
                    if (SpellManager.KnownSpells.ContainsKey("Aspect of the Dragonhawk"))
                    {
                        if (!Me.Buffs.ContainsKey("Aspect of the Dragonhawk"))
                        {
                            AspectOfTheDragonhawk();
                        }
                    }
                    else if (SpellManager.KnownSpells.ContainsKey("Aspect of the Hawk"))
                    {
                        if (!Me.Buffs.ContainsKey("Aspect of the Hawk"))
                        {
                            AspectOfTheHawk();
                        }
                    }
                    else if (SpellManager.KnownSpells.ContainsKey("Aspect of the Monkey") &&
                        !Me.Buffs.ContainsKey("Aspect of the Monkey"))
                    {
                        AspectofTheMonkey();
                    }
                }
                else
                //melee
                {
                    if (SpellManager.KnownSpells.ContainsKey("Aspect of the Beast"))
                    {
                        if (!Me.Buffs.ContainsKey("Aspect of the Beast"))
                        {
                            AspectOfTheBeast();
                        }
                    }
                    else if (SpellManager.KnownSpells.ContainsKey("Aspect of the Monkey") &&
                        !Me.Buffs.ContainsKey("Aspect of the Monkey"))
                    {
                        AspectofTheMonkey();
                    }
                }
            }

            aspectTimer.Reset();
            aspectTimer.Start();
        }
        #endregion

        #region melee

        #endregion

        #region ranged
        #endregion

        #region traps
        #endregion

        #region petcare
        #endregion

        #region utilities

        #region dk pets
        private bool haveDkPet()
        {
            if (Me.Class != WoWClass.DeathKnight)
            {
                return false;
            }
            string petName = "Stonemonger";

            foreach (WoWObject thing in ObjectManager.ObjectList)
            {
                try
                {
                    if (thing.Name == petName)
                    {
                        slog("Entry: " + thing.Entry);
                        slog("Type: " + thing.Type);
                    }
                }
                catch
                {
                    slog("Stupid enumeration.");
                }
            }
            return false;
        }
        #endregion

        private List<WoWUnit> getAdds()
        {
            List<WoWUnit> mobList = ObjectManager.GetObjectsOfType<WoWUnit>(false);
            List<WoWUnit> enemyMobList = new List<WoWUnit>();

            foreach (WoWUnit thing in mobList)
            {
                try
                {
                    if ((thing.Guid != Me.Guid) &&
                    thing.IsTargetingMe)
                    {
                        enemyMobList.Add(thing);
                    }
                }
                catch (Exception ex)
                {
                    Logging.WriteException(ex);
                    slog("Add error.");
                }
            }

            if (enemyMobList.Count > 1)
            {
                slog("Warning: there are " + enemyMobList.Count.ToString() + " attackers.");
            }
            return enemyMobList;
        }

        private void slog(string msg)
        {
            if (msg != _logspam)
            {
                Logging.Write(msg);
                _logspam = msg;
            }
        }

        #endregion

        #region movement logic
        WoWPoint attackPoint
        {
            get
            {
                if (Me.GotTarget)
                {
                    if (!movementTimer.IsRunning ||
                        movementTimer.ElapsedMilliseconds > 2500)
                    {
                        movementTimer.Reset();
                        movementTimer.Start();
                        attackPointBuffer = WoWMovement.CalculatePointFrom(Me.CurrentTarget.Location, 30.0f);
                        return attackPointBuffer;
                    }
                    else
                    {
                        return attackPointBuffer;
                    }
                }
                else
                {
                    WoWPoint noSpot = new WoWPoint();
                    return noSpot;
                }
            }
        }

        WoWPoint attackPointBuffer;

        private static Stopwatch movementTimer = new Stopwatch();


        #endregion

        #region horde racials

        // Berserking
        void Berserking()
        {
            if (ObjectManager.Me.Race == WoWRace.Troll &&
                SpellManager.CastSpell("Berserking"))
            {
                Styx.Helpers.Logging.Write("Berserking.");
            }
        }

        // Bloodrage
        void Bloodrage()
        {
            if (ObjectManager.Me.Race == WoWRace.Orc &&
                SpellManager.CastSpell("Bloodrage"))
            {
                Styx.Helpers.Logging.Write("Bloodrage.");
            }
        }

        // War Stomp
        void WarStomp()
        {
            if (ObjectManager.Me.Race == WoWRace.Tauren &&
                SpellManager.CastSpell("War Stomp"))
            {
                Styx.Helpers.Logging.Write("War Stomp.");
            }
        }

        // Arcane Torrent
        void ArcaneTorrent()
        {
            if (ObjectManager.Me.Race == WoWRace.BloodElf &&
                SpellManager.CastSpell("Arcane Torrent"))
            {
                Styx.Helpers.Logging.Write("Arcane Torrent.");
            }
        }

        // Will of the Forsaken 
        void WillOfTheForsaken()
        {
            if (ObjectManager.Me.Race == WoWRace.Undead &&
                SpellManager.CastSpell("Will of the Forsaken"))
            {
                Styx.Helpers.Logging.Write("Will of the Forsaken.");
            }
        }
        #endregion

        #region alliance racials

        // Stoneform
        void Stoneform()
        {
            if (ObjectManager.Me.Race == WoWRace.Dwarf &&
                SpellManager.CastSpell("Stoneform"))
            {
                Styx.Helpers.Logging.Write("Stoneform.");
            }
        }

        // Gift of the Naaru
        void GiftOfTheNaaru()
        {
            if (ObjectManager.Me.Race == WoWRace.Draenei &&
                SpellManager.CastSpell("Gift of the Naaru"))
            {
                Styx.Helpers.Logging.Write("Gift of the Naaru.");
            }
        }

        // Every Man for Himself
        void EveryManForHimself()
        {
            if (ObjectManager.Me.Race == WoWRace.Human &&
                SpellManager.CastSpell("Every Man for Himself"))
            {
                Styx.Helpers.Logging.Write("Every Man for Himself.");
            }
        }

        // Shadowmeld
        void Shadowmeld()
        {
            if (ObjectManager.Me.Race == WoWRace.NightElf &&
                SpellManager.CastSpell("Shadowmeld"))
            {
                Styx.Helpers.Logging.Write("Shadowmeld.");
            }
        }

        // Escape Artist
        void EscapeArtist()
        {
            if (ObjectManager.Me.Race == WoWRace.Gnome &&
                SpellManager.CastSpell("Escape Artist"))
            {
                Styx.Helpers.Logging.Write("Escape Artist.");
            }
        }


        #endregion
    }
}
#pragma warning restore