﻿namespace Styx.Bot.CustomClasses
{
    using Styx;
    using System;
    using System.Diagnostics;
    using Helpers;
    using System.Linq;
    using System.Collections.Generic;
    using Logic.Pathing;
    using System.Threading;
    using Logic.Common.Combat;
    using Object_Dumping_Enumeration;
    using CustomCombat.CombatInterface;
    using Object_Dumping_Enumeration.WoWObjects;
    using Styx.Memory_Read_Write_Inject.Lua;

    class Mage : ICombat
    {
        public WoWClass Class { get { return WoWClass.Mage; } }

        public string Name { get { return "Hawker's Frost Mage 1.0"; } }


        /*
         * Recommended Talent Spec
         * http://talent.mmo-champion.com/?mage#_CF9MYlsbiafpk,,9947
         */

        #region Private Members

        //Buffing config
        private bool stopCombatForBuffs = false; // change to true if you want it to rebuff while in combat(personal choice), Default = false
        //eat And drink values
        private int DrinkWhenManaPercentage = 50; //At which percentage you want it to drink.
        private int EatWhenHealthPercentage = 60; //At which percentage you want it to eat.
        private uint deathCount = 0;

        /// <summary>
        /// ////////////////////////////////////////////
        /// </summary>



        System.Collections.Generic.Dictionary<uint, uint> _gem =
            new System.Collections.Generic.Dictionary<uint, uint>() //Mana gem dictionary, DONT EDIT!
        {
            //Mana Gem
            //(uint spellId, uint itemId)
            {42982, 33312},             //77
            {27101, 22044},             //68
            {10054, 8008},              //58
            {10053, 8007},              //48
            {3552, 5513},               //38
            {759, 5514}                 //28

        };

        System.Collections.Generic.Dictionary<uint, uint> _foodSpells =
            new System.Collections.Generic.Dictionary<uint, uint>() //Food Dictionary, DONT EDIT!
            {
            // Universal "all in one":	
            // {uint spellId, uint itemId},
            {42956, 43523},             // 80
            {42955,	43518},             // 75
            // Food:		
            {33717,	22019},             // 70
            {28612,	22895},             // 60
            {10145,	8076},              // 52
            {10144,	8075},              // 42
            {6129, 1487},               // 32
            {990, 1114},                // 22
            {597, 1113},                // 12
            {587, 5349},                // 6
            };

        System.Collections.Generic.Dictionary<uint, uint> _drinkSpells =
            new System.Collections.Generic.Dictionary<uint, uint>() //Drink Dictionary, DONT EDIT!
        {
            // Universal "all in one":	
            {42956, 43523},              // 80
            {42955,	43518},              // 75
            // Water:	
            {27090,	22018},              // 70
            {37420,	30703},              // 65
            {10140,	8079},               // 60
            {10139,	8078},               // 50
            {10138,	8077},               // 40
            {6127, 3772},                // 30
            {5506, 2136},                // 20
            {5505, 2288},                // 10
            {5504, 5350},                // 4
        };

        float pullDistance
        {
            get
            {
                try
                {
                    return (float)Logic.Targeting.PullDistance;
                }
                catch
                {
                    return 25;
                }
            }
        }

        private uint _foodSpellId = 0;
        private uint foodEntryId = 0;

        private uint drinkEntryId = 0;
        private uint _drinkSpellId = 0;

        private uint managemEntryId = 0;
        private uint _gemId = 0;
        //    List<uint> gemIds = new List<uint>() { 33312, 22044, 8008, 8007, 5513, 5514 };

        private bool updatedVictuals = false;

        private uint GetGemCount() //Name speaks for itself, modify with caution.
        {
            uint managemcount = 999;

            foreach (KeyValuePair<uint, uint> spellgem in _gem)
            {
                if (SpellManager.CanCastSpell(spellgem.Key))
                {
                    managemEntryId = spellgem.Value;
                    _gemId = spellgem.Key;
                    break;
                }
            }

            if (managemEntryId > 0)
            {
                Lua.DoString("luaManagemCount = GetItemCount(" + managemEntryId.ToString() + ")");
                managemcount = Lua.GetLocalizedUInt32("luaManagemCount", Me.BaseAddress);

            }

            return managemcount;
        }

        public uint GetFoodCount() //Name speaks for itself, modify with caution
        {
            uint foodCount = 999;

            foreach (KeyValuePair<uint, uint> spellFood in _foodSpells)
            {
                if (SpellManager.CanCastSpell(spellFood.Key))
                {
                    foodEntryId = spellFood.Value;
                    _foodSpellId = spellFood.Key;
                    break;
                }
            }

            if (foodEntryId > 0)
            {
                Lua.DoString("luaFoodCount = GetItemCount(" + foodEntryId.ToString() + ")");
                foodCount = Lua.GetLocalizedUInt32("luaFoodCount", Me.BaseAddress);
            }

            return foodCount;

        }

        private uint GetDrinkCount() //Name speaks for itself, modify with caution.
        {
            uint drinkCount = 999;

            foreach (KeyValuePair<uint, uint> spellDrink in _drinkSpells)
            {
                if (SpellManager.CanCastSpell(spellDrink.Key))
                {
                    drinkEntryId = spellDrink.Value;
                    _drinkSpellId = spellDrink.Key;
                    break;
                }
            }

            if (drinkEntryId > 0)
            {
                Lua.DoString("luaDrinkCount = GetItemCount(" + drinkEntryId.ToString() + ")");
                drinkCount = Lua.GetLocalizedUInt32("luaDrinkCount", Me.BaseAddress);
            }

            return drinkCount;
        }



        public void HandleFalling() { }

        private void slog(string format, params object[] args)
        {
            Logging.Write(format, args);
        }


        #endregion

        #region Global Variables



        private readonly LocalPlayer Me = ObjectManager.Me;
        private volatile List<ulong> _npcOnMeGuid = new List<ulong>();
        private volatile List<ulong> _npcTargetsGuid = new List<ulong>();
        private volatile List<ulong> _pullNpcAdd = new List<ulong>();
        List<WoWUnit> addsList = new List<WoWUnit>();

        #endregion

        #region Rest
        //private bool ValidUnitCheck(WoWUnit unit)
        //{
        //    if (unit.IsValid && !unit.Dead && !unit.IsMe &&
        //        unit.GetUnitRelation(Me) != WoWUnit.WoWUnitRelation.Friendly &&
        //        (!unit.Tagged || unit.TaggedByYou))
        //    {

        //        return true;
        //    }
        //    return false;
        //}

        //private void AggroCheck()
        //{
        //    foreach (WoWUnit unit in ObjectManager.NpcObjectList.Values)
        //    {
        //        if (ValidUnitCheck(unit) && 
        //            (unit.IsTargetingMe))
        //        {
        //            if (!_npcTargetsGuid.Contains(unit.Guid))
        //            {
        //                slog("Adding to NPC List: " + unit.Name + ":" + unit.Guid);
        //                _npcTargetsGuid.Add(unit.Guid);
        //            }
        //            if (unit.TargetingMe && !_npcOnMeGuid.Contains(unit.Guid))
        //            {
        //                slog("Adding to aggroed NPC List: " + unit.Name + ":" + unit.Guid);
        //                _npcOnMeGuid.Add(unit.Guid);
        //            }
        //            else if (!unit.TargetingMe && _npcOnMeGuid.Contains(unit.Guid))
        //            {
        //                slog("Removing from aggroed NPC List: " + unit.Name + ":" + unit.Guid);
        //                _npcOnMeGuid.Remove(unit.Guid);
        //            }
        //        }

        //    }

        public bool NeedRest
        {
            get
            {
                double myHealthPercentage = ObjectManager.Me.GetPowerPercent(WoWPowerType.Health);
                double myManaPercentage = ObjectManager.Me.GetPowerPercent(WoWPowerType.Mana);

                if (Me.HealthPercent < EatWhenHealthPercentage &&
                    !Me.Buffs.ContainsKey("Food")) //To prevent food spam.
                {
                    slog("Need food.");
                    return true;
                }

                if (Me.ManaPercent < DrinkWhenManaPercentage &&
                    !Me.Buffs.ContainsKey("Drink")) //To prevent drink spam.
                {
                    slog("Need drink.");
                    return true;
                }

                if (!Me.Buffs.ContainsKey("Arcane Intellect") &&
                    !Me.Buffs.ContainsKey("Arcane Brilliance") &&
                    !Me.Buffs.ContainsKey("Fel Intelligence") &&
                    SpellManager.KnownSpells.ContainsKey("Arcane Intellect"))
                {
                    slog("Need Arcane Intellect.");
                    return true;
                }

                if (!Me.Buffs.ContainsKey("Frost Armor") &&
                    SpellManager.KnownSpells.ContainsKey("Frost Armor") &&
                    !SpellManager.KnownSpells.ContainsKey("Ice Armor"))
                {
                    slog("Need Frost Armor.");
                    return true;
                }
                else if (!Me.Buffs.ContainsKey("Ice Armor") &&
                         SpellManager.KnownSpells.ContainsKey("Ice Armor"))
                {
                    slog("Need Ice Armor.");
                    return true;
                }

                if (!updatedVictuals)
                {
                    if (GetDrinkCount() < 4 &&
                        Me.Level > 3)
                    {
                        slog("Make drinks.");
                        return true;
                    }

                    if (GetFoodCount() < 4 &&
                        Me.Level > 5)
                    {
                        slog("Make food.");
                        return true;
                    }

                    if (GetGemCount() < 1 &&
                        Me.Level > 27)
                    {
                        slog("Make gems.");
                        return true;
                    }

                    updatedVictuals = true;
                }

                return false;
            }
        }

        public void Rest()
        {
            #region eat/drink
            double myHealthPercentage = ObjectManager.Me.GetPowerPercent(WoWPowerType.Health);
            double myManaPercentage = ObjectManager.Me.GetPowerPercent(WoWPowerType.Mana);

            WoWMovement.MoveStop();

            if (SpellManager.KnownSpells.ContainsKey("Evocation") &&
                Me.ManaPercent < 55 &&
                Me.HealthPercent > 30 &&
                Me.ManaPercent > 30)
            {
                WoWSpell evocationSpell = SpellManager.KnownSpells["Evocation"];
                bool evocationCooldown = evocationSpell.Cooldown;

                if (!evocationCooldown)
                {
                    Evocation();
                }
                else
                {
                    slog("Evocation is on cooldown.");
                }
            }

            if (Me.HealthPercent < EatWhenHealthPercentage &&
                !Me.Buffs.ContainsKey("Food")) //To prevent food spam.
            {
                Lua.DoString("RunMacroText(\"/use item:" + foodEntryId + "\");"); //Lua inject to eat the highest level food

                if (Me.ManaPercent < 90)
                {
                    Lua.DoString("RunMacroText(\"/use item:" + drinkEntryId + "\");");
                }
                slog("Resting || Health: " + myHealthPercentage.ToString());
            }

            if (Me.ManaPercent < DrinkWhenManaPercentage &&
                !Me.Buffs.ContainsKey("Drink")) //To prevent drink spam.
            {
                Lua.DoString("RunMacroText(\"/use item:" + drinkEntryId + "\");");
                if (Me.HealthPercent < 90)
                {
                    Lua.DoString("RunMacroText(\"/use item:" + foodEntryId + "\");"); //Lua inject to eat the highest level food

                }

                slog("Resting || Mana: " + myManaPercentage.ToString());
                Thread.Sleep(2000);

            }

            do
            {
                if (Me.Combat)
                {
                    slog("Combat!");
                }

                if (!Me.Buffs.ContainsKey("Drink")) //This line shouldnt be used because of the above code, but here to ensure that it actually is resting.
                {
                    if (Me.ManaPercent < DrinkWhenManaPercentage)
                    {
                        Lua.DoString("RunMacroText(\"/use item:" + drinkEntryId + "\");");
                        slog("Resting || Mana: " + myManaPercentage.ToString());
                        Thread.Sleep(1500);
                        if (Me.HealthPercent < 90)
                        {
                            Lua.DoString("RunMacroText(\"/use item:" + foodEntryId + "\");"); //Lua inject to eat the highest level food

                        }
                        updatedVictuals = true; //Prevent unnesesary lua injection.
                    }
                }

                if (Me.Buffs.ContainsKey("Drink") &&
                    Me.ManaPercent > 99)
                {
                    Lua.DoString("RunMacroText(\"/Cancelaura Drink\");");
                    slog("Mana: " + Me.ManaPercent.ToString() + " Resting Stopped");
                    updatedVictuals = false; //Lua injection needed to get the amount of water left
                }

                if (!Me.Buffs.ContainsKey("Food")) //This line shouldnt be used because of the above code, but here to ensure that it actually is resting.
                {
                    if (Me.HealthPercent < EatWhenHealthPercentage)
                    {
                        Lua.DoString("RunMacroText(\"/use item:" + foodEntryId + "\");");
                        slog("Resting || Health: " + myHealthPercentage.ToString());

                        if (Me.ManaPercent < 90)
                        {
                            Lua.DoString("RunMacroText(\"/use item:" + drinkEntryId + "\");");
                        }
                        Thread.Sleep(1500);
                        updatedVictuals = true; //Prevent unesesary lua injection
                    }
                }

                if (Me.Buffs.ContainsKey("Food") &&
                    Me.HealthPercent > 99) //Force it to jump out of the loop
                {
                    Lua.DoString("RunMacroText(\"/Cancelaura Food\");");
                    updatedVictuals = false; //Lua injection needed to get the amount of food left.
                }

            } while (!Me.Combat &&
                (Me.Buffs.ContainsKey("Drink") ||
                Me.Buffs.ContainsKey("Food"))); //do while i have the buffs: Food or Drink.

            #endregion

            if (Me.Combat)
            {
                return;
            }
            slog("Check food and drinks.");

            updatedVictuals = false;

            if (GetDrinkCount() < 4)
            {
                slog("Make drinks.");
                SpellManager.CastSpellById(_drinkSpellId);
                Thread.Sleep(4000);
            }

            if (GetGemCount() < 1)
            {
                slog("Make Mana Gem.");
                SpellManager.CastSpellById(_gemId);
                Thread.Sleep(4000);
            }

            if (GetFoodCount() < 4)
            {
                slog("Make food.");
                SpellManager.CastSpellById(_foodSpellId);
                Thread.Sleep(4000);
            }

            MageBuffs();



            // this ought never get run over level 3
            if (Me.HealthPercent < EatWhenHealthPercentage)
            {
                Logic.Common.Rest.Feed(); //these arent needed.
            }

            if (Me.ManaPercent < DrinkWhenManaPercentage)
            {
                Logic.Common.Rest.Feed(); //these arent needed.
            }
        }

        #endregion

        #region PreCombatBuffs

        public bool NeedPreCombatBuffs
        {
            get
            {
                return false;
            }
        }

        public void PreCombatBuff()
        {
            MageBuffs();
        }

        private void MageBuffs()
        {
            if (!Me.Buffs.ContainsKey("Arcane Intellect") &&
                !Me.Buffs.ContainsKey("Arcane Brilliance"))
            {
                if (Me.GotTarget &&
                    Me.CurrentTarget.Guid != Me.Guid)
                {
                    Me.ClearTarget();
                }

                SpellManager.CastSpell("Arcane Intellect", false);
            }

            if (!Me.Buffs.ContainsKey("Frost Armor") &&
                SpellManager.KnownSpells.ContainsKey("Frost Armor") &&
                !SpellManager.KnownSpells.ContainsKey("Ice Armor"))
            {
                SpellManager.CastSpell("Frost Armor", false);
            }
            else if (!Me.Buffs.ContainsKey("Ice Armor") &&
                     SpellManager.KnownSpells.ContainsKey("Ice Armor"))
            {
                SpellManager.CastSpell("Ice Armor", false);
            }
        }
        #endregion

        #region CombatBuffs

        public bool NeedCombatBuffs { get { return false; } }

        public void CombatBuff()
        {
            if (stopCombatForBuffs)
            {
                MageBuffs(); //Your choice.
            }
        }

        #endregion

        #region Heal

        public bool NeedHeal { get { return ObjectManager.Me.GetPowerPercent(WoWPowerType.Health) <= 50; } }

        public void Heal()
        {
            //Nothing cool here yet
        }

        #endregion

        #region Pull

        public bool NeedPullBuffs { get { return false; } }

        public void PullBuff()
        {
            MageBuffs(); //Nice to be buffed before pull.
        }

        public void Pull()
        {
            if (Me.CurrentTarget.Distance > pullDistance)
            {
                return;
            }

            if (SpellManager.KnownSpells.ContainsKey("Frostbolt"))
            {
                slog("Killing {0} at distance {1}", Me.CurrentTarget.Name, System.Math.Floor(Me.CurrentTarget.Distance));
                WoWMovement.MoveStop();
                WoWMovement.Face();
                Frostbolt();
            }
            else
            {
                double fireDistance = SpellManager.KnownSpells["Fireball"].MaxRange - 1;

                if (Me.CurrentTarget.Distance > fireDistance)
                {
                    pointNow = WoWMovement.CalculatePointFrom(Me.CurrentTarget.Location, (float)fireDistance);
                    Navigator.MoveTo(pointNow);
                    return;
                }
                Fireball();
                slog("Pull with Fireball.");
            }
        }

        #endregion

        #region Combat

        public void Combat()
        {
            if (!Me.GotTarget ||
                Me.CurrentTarget.Distance > 50 ||
                Me.CurrentTarget.Dead)
            {
                return;
            }
            else if (!SpellManager.KnownSpells.ContainsKey("Frostbolt"))
            {
                if (!Me.IsAutoAttacking)
                {
                    Lua.DoString("StartAttack()");
                }

                if (Me.ManaPercent > 50)
                {
                    Fireball();
                }
            }
            else
            {
                // have I died?
                if (deathCount < Helpers.InfoPanel.Deaths)
                {
                    fightTimer.Reset();
                    deathCount = Helpers.InfoPanel.Deaths;
                    slog("I died in last fight.");
                }

                #region survival
                // bugged mobs

                if (!fightTimer.IsRunning ||
                    Me.CurrentTarget.Guid != lastGuid)
                {
                    fightTimer.Reset();
                    fightTimer.Start();
                    lastGuid = Me.CurrentTarget.Guid;
                }

                if (!Me.CurrentTarget.IsPlayer && 
                    fightTimer.ElapsedMilliseconds > 40 * 1000 &&
                    Me.CurrentTarget.HealthPercent > 95)
                {
                    slog(" This " + Me.CurrentTarget.Name + " is a bugged mob.  blacklisting for 1 hour.");

                    Logic.Blacklist.Add(Me.CurrentTarget.Guid, TimeSpan.FromHours(1.00));

                    WoWMovement.Move(WoWMovement.MovementDirection.Backward);
                    Thread.Sleep(1000);
                    WoWMovement.MoveStop();
                    Me.ClearTarget();
                    lastGuid = 0;
                }

                // things you need to check before casting any spells
                if (Me.GotAlivePet && !Me.Pet.IsAutoAttacking)
                {
                    Lua.DoString("PetAttack()");
                }

                if (Me.HealthPercent < 30 &&
                    Me.CurrentTarget.HealthPercent > Me.CurrentTarget.HealthPercent)
                {
                    Logic.Common.Combat.Healing.UseHealthPotion();
                    GiftOfTheNaaru();
                    IceBarrier();

                    if (SpellManager.KnownSpells["Frost Nova"].Cooldown)
                    {
                        ColdSnap();
                    }

                    slog("UseHealthPotion: " + Me.CurrentTarget.ManaPercent + ":" + Me.CurrentTarget.HealthPercent + ":" + Me.CurrentTarget.HealthPercent);
                }

                if (Me.ManaPercent < 30 &&
                    Me.CurrentTarget.HealthPercent > Me.CurrentTarget.HealthPercent)
                {
                    Logic.Common.Combat.Healing.UseManaPotion();
                    IceBarrier();

                    if (SpellManager.KnownSpells["Frost Nova"].Cooldown)
                    {
                        ColdSnap();
                    }

                    slog("UseManaPotion: " + Me.CurrentTarget.ManaPercent + ":" + Me.CurrentTarget.HealthPercent + ":" + Me.CurrentTarget.HealthPercent);
                }

                if (Me.ManaPercent < 50 &&
                    Me.CurrentTarget.HealthPercent > Me.CurrentTarget.HealthPercent)
                {
                    Lua.DoString("RunMacroText(\"/use item:" + managemEntryId + "\");");
                }

                if (Me.CurrentTarget.HealthPercent > 70 &&
                    Me.HealthPercent < 40)
                {
                    Berserking();
                    Bloodrage();
                    WaterElemental();
                }

                if (Me.IsMoving)
                {
                    WoWMovement.MoveStop();
                    Thread.Sleep(100);
                }

                WoWMovement.Face();
            }
                #endregion
            #region defend
            // prevent casting
            if (Me.CurrentTarget.Casting)
            {
                if (Me.Race == WoWRace.BloodElf &&
                    !SpellManager.KnownSpells["Arcane Torrent"].Cooldown &&
                        Me.CurrentTarget.Distance < 6)
                {
                    ArcaneTorrent();
                }
                else
                {
                    Counterspell();
                }

            }
            // get distance
            if (Me.CurrentTarget.Distance < 7 &&
                SpellManager.KnownSpells.ContainsKey("Frost Nova") &&
                Me.CurrentTarget.HealthPercent > 20)
            {
                if (!SpellManager.KnownSpells["Frost Nova"].Cooldown &&
                    !Me.CurrentTarget.Buffs.ContainsKey("Frostbite") &&
                    !Me.CurrentTarget.Buffs.ContainsKey("Frost Nova"))
                {
                    Lua.DoString("RunMacroText(\"/stopcasting\")");
                    slog("Use Frost Nova to gain range.");
                    FrostNova();
                    WoWMovement.Move(WoWMovement.MovementDirection.Backward);
                    Lua.DoString("JumpOrAscendStart()");
                    Lua.DoString("AscendStop()");
                    WoWMovement.Move(WoWMovement.MovementDirection.Backward);
                    Thread.Sleep(1000);
                    WoWMovement.MoveStop();

                }
                else if (Me.CurrentTarget.Buffs.ContainsKey("Frostbite") ||
                        Me.CurrentTarget.Buffs.ContainsKey("Frost Nova"))
                {
                    slog("Move from frozen target.");
                    WoWMovement.Move(WoWMovement.MovementDirection.Backward);
                    Lua.DoString("JumpOrAscendStart()");
                    Lua.DoString("AscendStop()");
                    Thread.Sleep(1000);
                    WoWMovement.MoveStop();
                    WoWMovement.Face();
                }
                else if (SpellManager.KnownSpells["Frost Nova"].Cooldown)
                {
                    ColdSnap();
                    IceBarrier();
                }
            }

            addsList = getAdds();

            if (addsList.Count > 1 &&
                !SpellManager.KnownSpells["Polymorph"].Cooldown)
            {
                // polymorph time
                foreach (WoWUnit mob in addsList)
                {
                    if (Me.CurrentTarget.Guid != mob.Guid &&
                        !SpellManager.KnownSpells["Polymorph"].Cooldown)
                    {
                        if (mob.CreatureType == WoWCreatureType.Beast ||
                            mob.CreatureType == WoWCreatureType.Humanoid)
                        {
                            WoWUnit myMob = Me.CurrentTarget;
                            mob.Target();
                            SpellManager.CastSpell("Polymorph");
                            myMob.Target();
                            break;
                        }
                    }
                }

                IcyVeins();
                WaterElemental();

            }

            #endregion
            #region attack

            if (SpellManager.KnownSpells.ContainsKey("Deep Freeze") &&
                !SpellManager.KnownSpells["Deep Freeze"].Cooldown &&
                (Me.CurrentTarget.Buffs.ContainsKey("Frostbite") ||
                Me.CurrentTarget.Buffs.ContainsKey("Frost Nova")))
            {
                if (SpellManager.KnownSpells["Deep Freeze"].Cooldown)
                {
                    slog("Deep FreezeCooldown? " + SpellManager.KnownSpells["Deep Freeze"].Cooldown.ToString());
                    slog(deepFreezeTimer.ElapsedMilliseconds.ToString() + " milliseconds since last try.");
                }
                IceLance();
                DeepFreeze();                
            }
            else if (SpellManager.KnownSpells.ContainsKey("Cone of Cold") &&
                            !SpellManager.KnownSpells["Cone of Cold"].Cooldown &&
                            Me.HealthPercent < 30 &&
                            Me.CurrentTarget.Distance < 6)
            {
                if (!ConeOfCold())
                    slog("Why no Cone of Cold?");
            }
            else if (SpellManager.KnownSpells.ContainsKey("Fire Blast") &&
            !SpellManager.KnownSpells["Fire Blast"].Cooldown &&
            (Me.CurrentTarget.Buffs.ContainsKey("Frostbite") ||
                Me.CurrentTarget.Buffs.ContainsKey("Frost Nova")))
            {
                Frostbolt();                
                Fireblast();
            }

            else if (SpellManager.KnownSpells.ContainsKey("Frostbolt"))
            {
                Frostbolt();
            }

            #endregion

        }

        #region Spells

        /// <summary>
        /// Launches a bolt of frost at the enemy, causing Frost damage and slowing movement speed.
        /// </summary>
        
        private bool Frostbolt()
        {
            if (Me.GotTarget)
            {
                if (Me.CurrentTarget.Entry == 20079)
                {
                    Fireball();
                    return true;
                }

                if (combatChecks() &&
                    SpellManager.CastSpell("Frostbolt"))
                {
                    slog("Frostbolt.");
                    return true;
                }

            }
            return false;
        }

        /// <summary>
        /// Hurls a fiery ball that causes 14 to 22 Fire damage and an additional 2 Fire damage over 4 sec.
        /// We never use it after level 3.
        /// </summary>
        
        private bool Fireball()
        {
            if (Me.GotTarget)
            {
                WoWMovement.MoveStop();
                WoWMovement.Face();

                if (SpellManager.CastSpell("Fireball"))
                {
                    slog("Fireball.");
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// Hastens your spellcasting, increasing spell casting speed by 20% and reduces the pushback suffered from damaging attacks while casting by 100%.  Lasts 20 sec.
        /// </summary>
        private void IcyVeins()
        {
            if (Me.GotTarget &&
                SpellManager.CastSpell("Icy Veins"))
            {
                slog("Icy Veins.");
            }
        }

        /// <summary>
        /// Ice Lance
        /// Instantly deals 161 to 187 Frost damage to an enemy target.  Causes triple damage against Frozen targets.
        /// </summary>
        private void IceLance()
        {
            if (Me.GotTarget &&
                SpellManager.CastSpell("Ice Lance"))
            {
                slog("Ice Lance.");
            }
        }

        /// <summary>
        /// Deep Freeze
        /// Stuns the target for 5 sec.  Only usable on Frozen targets.
        /// </summary>
        private static Stopwatch deepFreezeTimer = new Stopwatch();
        private void DeepFreeze()
        {
            if (Me.GotTarget &&
                SpellManager.CastSpell("Deep Freeze"))
            {
                slog("Deep Freeze");
                deepFreezeTimer.Reset();
                deepFreezeTimer.Start();
            }
        }

        /// <summary>
        /// Targets in a cone in front of the caster take Frost damage and are slowed by 50% for 8 sec.
        /// </summary>
        private bool ConeOfCold()
        {
            if (Me.GotTarget &&
                SpellManager.KnownSpells.ContainsKey("Cone of Cold"))
            {
                WoWSpell coneOfCold = SpellManager.KnownSpells["Cone of Cold"];

                if (targetDistance <= 5 &&
                    !coneOfCold.Cooldown &&
                    SpellManager.CastSpell("Cone of Cold"))
                {
                    slog("Cone of Cold.");
                    return true;
                }
                else
                {
                    return false;
                }
            }
            return false;
        }

        /// <summary>
        /// When activated, this spell finishes the cooldown on all Frost spells you recently cast.
        /// </summary>
        private void ColdSnap()
        {
            if (Me.GotTarget &&
                SpellManager.CastSpell("Cold Snap"))
            {
                slog("Cold Snap.");
            }
        }

        /// <summary>
        /// Counters the enemy's spellcast, preventing any spell from that school of magic from being cast for 8 sec.
        /// </summary>
        private void Counterspell()
        {
            if (Me.GotTarget &&
                SpellManager.CastSpell("Counterspell"))
            {
                slog("Counterspell.");
            }
        }

        /// <summary>
        /// Instantly shields you, absorbing damage.  Lasts 1 min.  While the shield holds, spellcasting will not be delayed by damage.
        /// </summary>
        private void IceBarrier()
        {
            if (SpellManager.CastSpell("Ice Barrier"))
            {
                slog("Ice Barrier.");

            }
        }

        /// <summary>
        /// While channeling this spell, you gain 60% of your total mana over 8 sec.
        /// </summary>
        private void Evocation()
        {
            if (SpellManager.CastSpell("Evocation", false))
            {                
                slog("Evocation.");
                Thread.Sleep(500);
                while (Me.Casting > 0 &&
                    Me.ManaPercent < 100)
                {
                    Thread.Sleep(100);
                }

            }

        }

        /// <summary>
        /// Blasts enemies near the caster with Frost damage and freezes them in place for up to 8 sec.  Damage caused may interrupt the effect.
        /// </summary>        
        private bool FrostNova()
        {
            if (Me.GotTarget)
            {
                if (!Me.CurrentTarget.Dead)
                {
                    if (SpellManager.CastSpell("Frost Nova"))
                    {
                        slog("Frost Nova.");
                        return true;
                    }
                }
            }
            return false;
        }

        /// <summary>
        /// Instantly blasts the enemy for Fire damage.
        /// </summary>
        private void Fireblast()
        {
            if (Me.GotTarget &&
                SpellManager.KnownSpells.ContainsKey("Fire Blast"))
            {
                WoWSpell fireblast = SpellManager.KnownSpells["Fire Blast"];

                if (combatChecks() &&
                    targetDistance <= fireblast.MaxRange &&
                    SpellManager.CastSpell("Fire Blast"))
                {
                    slog("Fire Blast.");
                }
            }
        }
        private bool useManaGem() //your choice.
        {
            if ((Me.GotTarget &&
                Me.Combat &&
                Me.ManaPercent < 20 &&
                Me.CurrentTarget.HealthPercent > 20) ||
                (Me.Combat && Me.GotTarget && Me.ManaPercent <= 10))
            {
                Lua.DoString("luaDrinkCount = GetItemCount(" + managemEntryId.ToString() + ")");
                updatedVictuals = false;
            }
            return false;
        }

        /// <summary>
        /// Summon a Water Elemental to fight for the caster for 45 sec.
        /// </summary>
        private void WaterElemental()
        {
            if (Me.GotTarget &&
                SpellManager.CastSpell("Summon Water Elemental"))
            {
                slog("Summon Water Elemental.");
            }
        }

        #endregion

        #endregion

        #region combat utilities

        private static ulong lastGuid;
        private static Stopwatch fightTimer = new Stopwatch();
        Point pointNow = new Point();
        private double targetDistance
        {
            get
            {
                return Me.GotTarget ? Me.CurrentTarget.Distance : uint.MaxValue - 1;

            }
        }

        private bool combatChecks()
        {
            if (Me.GotTarget &&
                !Me.CurrentTarget.IsValid)
            {
                Logging.WriteDebug("Target killed.");
                return false;
            }

            if (Me.Dead)
            {
                slog("I died.");
                return false;
            }

            if (targetDistance > 50 &&
                targetDistance < 100)
            {
                slog("Out of range: " + Me.CurrentTarget.Name + " is " + System.Math.Round(targetDistance).ToString() + " yards away.");
                if (ObjectManager.Me.IsMoving)
                    WoWMovement.MoveStop();
                return false;
            }

            WoWSpell frostBolt = SpellManager.KnownSpells["Frostbolt"];
            double frostBoltRange = frostBolt.MaxRange;

            if (targetDistance > frostBoltRange)
            {
                slog(Me.CurrentTarget.Name + " is at " + System.Math.Round(targetDistance).ToString() + " yards.");
                int approachSeconds = 0;

                // get within range
                while (approachSeconds < 10 &&
                     targetDistance > frostBoltRange &&
                     targetDistance < 50)
                {
                    pointNow = WoWMovement.CalculatePointFrom(Me.CurrentTarget.Location, (float)frostBoltRange - 1);
                    Navigator.MoveTo(pointNow);

                    Thread.Sleep(250);

                    ++approachSeconds;
                }

                WoWMovement.MoveStop();
            }

            Thread.Sleep(10);

            if (ObjectManager.Me.IsMoving)
                WoWMovement.MoveStop();

            WoWMovement.Face();

            return true;
        }

        private void EvadeCheck()
        {
            for (int i = -1; i > -5; i--)
            {
                List<string> clog = Lua.LuaGetReturnValue(string.Format("CombatLogSetCurrentEntry({0}) return CombatLogGetCurrentEntry(\"true\")", i), "_main.lua");
                if (clog == null || clog.Count < 12)
                    return;

                string sourceName = clog[3];
                string destName = clog[6];
                string missType = clog[11];
                if (missType.ToUpper() == "EVADE" && sourceName == Me.Name && destName == Me.CurrentTarget.Name)
                {
                    slog(Me.CurrentTarget.Name + " is evading.");
                    Logic.Blacklist.Add(Me.CurrentTargetGuid, TimeSpan.FromMinutes(5));
                    break;
                }
                // Logging.WriteDebug(clog[0]);
            }
        }

        private List<WoWUnit> getAdds()
        {
            slog("Get adds: " + DateTime.Now.Minute + ":" + DateTime.Now.Second + ":" + DateTime.Now.Millisecond);

            List<WoWUnit> enemyMobList = new List<WoWUnit>();

            try
            {
                if (Equals(null, Logic.Targeting.TargetList) || Logic.Targeting.TargetList.Count < 2)
                {
                    return enemyMobList;
                }

                foreach (WoWUnit thing in Logic.Targeting.TargetList)
                {
                    try
                    {
                        if (thing.IsTargetingMe)
                        {
                            enemyMobList.Add(thing);
                        }
                    }
                    catch (Exception ex)
                    {
                        Logging.WriteException(ex);
                        slog("Add error.");
                    }
                }

                if (enemyMobList.Count > 1)
                {
                    slog("Warning: there are " + enemyMobList.Count.ToString() + " attackers.");
                }
                
            }
            catch (Exception ex)
            {
                slog("Getadds: " + ex.Source);
            }
            slog("Got adds." + DateTime.Now.Minute + ":" + DateTime.Now.Second + ":" + DateTime.Now.Millisecond);
            return enemyMobList;

        }

        /// <summary>
        /// Has this buff procced?
        /// </summary>
        /// <param name="cSearchBuffName"></param>
        /// <returns>True if the buff is present</returns>
        private bool HasBuffProcced(string cSearchBuffName, int minStackCount)
        {
            int stackCount = 0;
            Lua.DoString("buffName,_,_,stackCount,_,_,_,_,_=UnitBuff(\"player\",\"" + cSearchBuffName + "\")");
            string buffName = Lua.GetLocalizedText("buffName", Me.BaseAddress);
            if (minStackCount > 0)
            {
                stackCount = Lua.GetLocalizedInt32("stackCount", Me.BaseAddress);
            }

            if (buffName == cSearchBuffName ||
                stackCount >= minStackCount)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        #endregion

        #region horde racials

        // Berserking
        void Berserking()
        {
            if (ObjectManager.Me.Race == WoWRace.Troll &&
                SpellManager.CastSpell("Berserking"))
            {
                Styx.Helpers.Logging.Write("Berserking.");
            }
        }

        // Bloodrage
        void Bloodrage()
        {
            if (ObjectManager.Me.Race == WoWRace.Orc &&
                SpellManager.CastSpell("Bloodrage"))
            {
                Styx.Helpers.Logging.Write("Bloodrage.");
            }
        }

        // War Stomp
        void WarStomp()
        {
            if (ObjectManager.Me.Race == WoWRace.Tauren &&
                SpellManager.CastSpell("War Stomp"))
            {
                Styx.Helpers.Logging.Write("War Stomp.");
            }
        }

        // Arcane Torrent
        void ArcaneTorrent()
        {
            if (ObjectManager.Me.Race == WoWRace.BloodElf &&
                SpellManager.CastSpell("Arcane Torrent"))
            {
                Styx.Helpers.Logging.Write("Arcane Torrent.");
            }
        }

        // Will of the Forsaken 
        void WillOfTheForsaken()
        {
            if (ObjectManager.Me.Race == WoWRace.Undead &&
                SpellManager.CastSpell("Will of the Forsaken"))
            {
                Styx.Helpers.Logging.Write("Will of the Forsaken.");
            }
        }
        #endregion

        #region alliance racials

        // Stoneform
        void Stoneform()
        {
            if (ObjectManager.Me.Race == WoWRace.Dwarf &&
                SpellManager.CastSpell("Stoneform"))
            {
                Styx.Helpers.Logging.Write("Stoneform.");
            }
        }

        // Gift of the Naaru
        void GiftOfTheNaaru()
        {
            if (ObjectManager.Me.Race == WoWRace.Draenei &&
                SpellManager.CastSpell("Gift of the Naaru"))
            {
                Styx.Helpers.Logging.Write("Gift of the Naaru.");
            }
        }

        // Every Man for Himself
        void EveryManForHimself()
        {
            if (ObjectManager.Me.Race == WoWRace.Human &&
                SpellManager.CastSpell("Every Man for Himself"))
            {
                Styx.Helpers.Logging.Write("Every Man for Himself.");
            }
        }

        // Shadowmeld
        void Shadowmeld()
        {
            if (ObjectManager.Me.Race == WoWRace.NightElf &&
                SpellManager.CastSpell("Shadowmeld"))
            {
                Styx.Helpers.Logging.Write("Shadowmeld.");
            }
        }

        // Escape Artist
        void EscapeArtist()
        {
            if (ObjectManager.Me.Race == WoWRace.Gnome &&
                SpellManager.CastSpell("Escape Artist"))
            {
                Styx.Helpers.Logging.Write("Escape Artist.");
            }
        }


        #endregion

        #region Disenchanting

        private void GetGreens()
        {
            var items = ObjectManager.GetObjectsOfType<WoWItem>(false);
            var notSoulbound = items.Where(obj => !obj.IsSoulbound &&
                obj.Quality == WoWItemQuality.Uncommon).ToList();

            foreach (WoWItem item in notSoulbound)
            {
                Logging.Write("{0} is not soulbound", item.Name);
            }
        }
        #endregion

    }
}
