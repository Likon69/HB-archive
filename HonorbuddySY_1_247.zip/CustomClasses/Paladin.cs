﻿#pragma warning disable
namespace Styx.Bot.CustomClasses
{
    using Helpers;
    using Logic;
    using Logic.Pathing;
    using System;
    using System.Diagnostics;
    using System.Collections.Generic;
    using System.Threading;
    using Logic.Common.Combat;
    using Object_Dumping_Enumeration;
    using CustomCombat.CombatInterface;
    using Memory_Read_Write_Inject.Lua;
    using Object_Dumping_Enumeration.WoWObjects;

    class Paladin : ICombat
    {
        public WoWClass Class { get { return WoWClass.Paladin; } }

        public string Name { get { return "Hawker's Paladin 1.5"; } }

        // local variables
        private readonly Styx.Object_Dumping_Enumeration.WoWObjects.LocalPlayer Me = ObjectManager.Me;
        private string logspam;  // prevent logs filling with dupe entries
        Stopwatch buffTimer = new Stopwatch();
        Stopwatch sealTimer = new Stopwatch();
        Stopwatch blessingTimer = new Stopwatch();
        Stopwatch hammerOfJusticeTimer = new Stopwatch();
        Point pointNow = new Point();
        List<WoWUnit> addsList = new List<WoWUnit>();
        Dictionary<string, WoWAura> myBuffs = new Dictionary<string, WoWAura>();
        private double targetDistance
        {
            get
            {
                return Me.GotTarget ? Me.CurrentTarget.Distance : uint.MaxValue - 1;

            }
        }

        private static ulong lastGuid;
        private static Stopwatch fightTimer = new Stopwatch();

        # region buffs and heals

        public bool NeedRest
        {
            get
            {
                if (!Me.Mounted)
                {
                    if (sealTimer.ElapsedMilliseconds > 25 * 60 * 1000)
                    {
                        return true;
                    }

                    if (blessingTimer.ElapsedMilliseconds > 7 * 60 * 1000)
                    {
                        return true;
                    }

                    if (SpellManager.KnownSpells.ContainsKey("Seal of Command"))
                    {
                        if (!Me.Buffs.ContainsKey("Seal of Command"))
                        {
                            return true;
                        }
                    }
                    else if (!Me.Buffs.ContainsKey("Seal of Righteousness") &&
                        SpellManager.KnownSpells.ContainsKey("Seal of Righteousness"))
                    {
                        return true;
                    }

                    if (Me.Level > 3 &&
                        !Me.Buffs.ContainsKey("Blessing of Might") &&
                        !Me.Buffs.ContainsKey("Greater Blessing of Might") &&
                        !Me.Buffs.ContainsKey("Battle Shout") &&
                        SpellManager.KnownSpells.ContainsKey("Blessing of Might"))
                    {
                        return true;
                    }

                    if (Battlegrounds.Battlegroundstatus == BattlegroundStatus.Active)
                    {
                        return false;
                    }

                    if (!Me.Mounted)
                    {
                        if (SpellManager.KnownSpells.ContainsKey("Blessing of Might"))
                        {
                            foreach (WoWPlayer player in Me.PartyMembers)
                            {
                                if (player.IsAlive && player.InLineOfSight && player.Distance < (SpellManager.KnownSpells["Blessing of Might"].MaxRange - 2)
                                    && (player.Class == WoWClass.DeathKnight || player.Class == WoWClass.Druid
                                    || player.Class == WoWClass.Hunter || player.Class == WoWClass.Rogue))
                                {
                                    if (!player.Buffs.ContainsKey("Blessing of Might") && !player.Buffs.ContainsKey("Battle Shout"))
                                        return true;
                                }
                            }
                        }

                        if (SpellManager.KnownSpells.ContainsKey("Blessing of Wisdom"))
                        {
                            foreach (WoWPlayer player in Me.PartyMembers)
                            {
                                if (player.IsAlive && player.InLineOfSight && player.Distance < SpellManager.KnownSpells["Blessing of Wisdom"].MaxRange - 2
                                    && (player.Class == WoWClass.Mage || player.Class == WoWClass.Priest || player.Class == WoWClass.Shaman
                                    || player.Class == WoWClass.Warlock))
                                {
                                    if (!player.Buffs.ContainsKey("Blessing of Wisdom") && !player.Buffs.ContainsKey("Mana Spring"))
                                        return true;
                                }
                            }
                        }
                    }

                    if (SpellManager.KnownSpells.ContainsKey("Blessing of Kings"))
                    {
                        foreach (WoWPlayer player in Me.PartyMembers)
                        {
                            if (player.IsAlive && player.InLineOfSight && player.Distance < SpellManager.KnownSpells["Blessing of Kings"].MaxRange - 2
                                && (player.Class == WoWClass.Warrior || player.Class == WoWClass.Paladin))
                                if (!player.Buffs.ContainsKey("Blessing of Kings"))
                                    return true;
                        }
                    }

                    /*
                    if (Me.PartyMembers.Count > 0 && SpellManager.KnownSpells.ContainsKey("Purify"))
                    {
                        foreach (WoWPlayer player in Me.PartyMembers)
                        {
                            foreach (KeyValuePair<string, WoWAura> debuff in player.Buffs)
                            {
                                if (cleansedPlayers.ContainsKey(player.Guid) && DateTime.Now.Subtract(cleansedPlayers[player.Guid]).Minutes < 1)
                                {
                                    continue;
                                }
                                else if (debuff.Value.IsHarmful)
                                {
                                    return true;
                                }
                            }
                        }
                    }
                     */
                }

                if (ObjectManager.Me.GetPowerPercent(WoWPowerType.Health) <= 70 ||
                ObjectManager.Me.GetPowerPercent(WoWPowerType.Mana) <= 50)
                {
                    return true;
                }

                return false;
            }
        }
        public bool NeedPreCombatBuffs { get { return NeedRest; } }
        public bool NeedCombatBuffs { get { return false; } }
        public bool NeedHeal
        {
            get
            {
                if (healTarget.Dead)
                    return false;

                if (healTarget.Combat && healTarget.CurrentTarget.Elite && healTarget.HealthPercent < 75)
                {
                    return true;
                }

                if (healTarget.HealthPercent < 60)
                {
                    return true;
                }

                return false;
            }
        }

        public bool NeedPullBuffs { get { return false; } }

        private Dictionary<ulong, DateTime> cleansedPlayers = new Dictionary<ulong, DateTime>();

        public void Rest()
        {
            if (Me.ManaPercent > 35 &&
                Me.HealthPercent < 70)
            {
                Heal();
            }

            PaladinBuffs();

            if (Me.PartyMembers.Count > 0 && SpellManager.KnownSpells.ContainsKey("Purify"))
            {
                foreach (WoWPlayer player in Me.PartyMembers)
                {
                    foreach (KeyValuePair<string, WoWAura> debuff in player.Buffs)
                    {
                        if (cleansedPlayers.ContainsKey(player.Guid) && DateTime.Now.Subtract(cleansedPlayers[player.Guid]).Minutes < 1)
                        {
                            continue;
                        }
                        else if (debuff.Value.IsHarmful)
                        {
                            player.Target();
                            Thread.Sleep(200);
                            slog("Trying to remove {0} from {1}.", debuff.Value.Name, player.Class);
                            Cleanse();

                            if (cleansedPlayers.ContainsKey(player.Guid))
                            {
                                cleansedPlayers[player.Guid] = DateTime.Now;
                            }
                            else
                            {
                                cleansedPlayers.Add(player.Guid, DateTime.Now);
                            }
                        }
                    }
                }
            }


            if (Me.PartyMembers.Count > 0 && SpellManager.KnownSpells.ContainsKey("Blessing of Might"))
            {
                foreach (WoWPlayer player in Me.PartyMembers)
                {
                    if (player.IsAlive && player.InLineOfSight && player.Distance < SpellManager.KnownSpells["Blessing of Might"].MaxRange
                        && (player.Class == WoWClass.DeathKnight || player.Class == WoWClass.Druid || player.Class == WoWClass.Hunter
                        || player.Class == WoWClass.Rogue))
                    {
                        if (!player.Buffs.ContainsKey("Blessing of Might") && !player.Buffs.ContainsKey("Battle Shout"))
                        {
                            player.Target();
                            Thread.Sleep(200);
                            if (SpellManager.CastSpell("Blessing of Might"))
                            {
                                Me.ClearTarget();
                                slog("Blessing of Might on {0}.", player.Class);
                            }
                        }
                    }
                }
            }

            if (Me.PartyMembers.Count > 0 && SpellManager.KnownSpells.ContainsKey("Blessing of Wisdom"))
            {
                foreach (WoWPlayer player in Me.PartyMembers)
                {
                    if (player.IsAlive && player.InLineOfSight && player.Distance < SpellManager.KnownSpells["Blessing of Wisdom"].MaxRange
                        && (player.Class == WoWClass.Mage || player.Class == WoWClass.Priest || player.Class == WoWClass.Shaman
                        || player.Class == WoWClass.Warlock))
                    {
                        if (!player.Buffs.ContainsKey("Blessing of Wisdom") && !player.Buffs.ContainsKey("Mana Spring"))
                        {
                            player.Target();
                            Thread.Sleep(200);
                            if (SpellManager.CastSpell("Blessing of Wisdom"))
                            {
                                Me.ClearTarget();
                                slog("Blessing of Wisdom on {0}", player.Class);
                            }
                        }
                    }
                }
            }

            if (Me.PartyMembers.Count > 0 && SpellManager.KnownSpells.ContainsKey("Blessing of Kings"))
            {
                foreach (WoWPlayer player in Me.PartyMembers)
                {
                    if (player.IsAlive && player.InLineOfSight && player.Distance < SpellManager.KnownSpells["Blessing of Kings"].MaxRange
                        && (player.Class == WoWClass.Warrior || player.Class == WoWClass.Paladin))
                        if (!player.Buffs.ContainsKey("Blessing of Kings"))
                        {
                            player.Target();
                            Thread.Sleep(200);
                            if (SpellManager.CastSpell("Blessing of Kings"))
                            {
                                Me.ClearTarget();
                                slog("Blessing of Wisdom on {0}", player.Class);
                            }
                        }
                }
            }


            if (Battlegrounds.Battlegroundstatus == BattlegroundStatus.Active)
            {
                return;
            }

            if (Me.ManaPercent < 60)
            {
                Logic.Common.Rest.Feed();
            }
        }
        public void CombatBuff() { }
        public void PullBuff() { }
        #endregion

        public void Pull()
        {
            PaladinBuffs();

            if (!Me.GotTarget)
                return;

            if (Me.PartyMembers.Count > 0 && !Equals(null, Me.PartyMember1.CurrentTarget))
            {
                slog("Will on pull the party leader's target.");
                return;
            }

            slog("Pull {0} at {1}.", Me.CurrentTarget.Name, System.Math.Round(Me.CurrentTarget.Distance));

            if (!Me.CurrentTarget.IsPlayer && SpellManager.KnownSpells.ContainsKey("Hand of Reckoning"))
            {
                WoWSpell handOfReckoning = SpellManager.KnownSpells["Hand of Reckoning"];
                if (!Equals(null, handOfReckoning))
                {
                    if (Me.GotTarget &&
                        Me.CurrentTarget.Distance > handOfReckoning.MaxRange)
                    {
                        Navigator.MoveTo(WoWMovement.CalculatePointFrom(Me.CurrentTarget.Location, (float)handOfReckoning.MaxRange - 3));
                        return;
                    }
                    else
                    {
                        WoWMovement.MoveStop();
                        WoWMovement.Face();
                        HandOfReckoning();
                        if (Me.PartyMembers.Count == 0)
                        {
                            Exorcism();
                        }
                    }

                }

                Stopwatch pTimer = new Stopwatch();
                pTimer.Start();
                while (pTimer.ElapsedMilliseconds < 1500 &&
                    Me.GotTarget &&
                    Me.CurrentTarget.IsTargetingMe &&
                    Me.CurrentTarget.Distance > 5)
                {
                    slog("Wait 1.5 second for " + Me.CurrentTarget.Name + " come into melee range.");
                    Thread.Sleep(250);
                }
            }

            if (combatChecks())
            {
                PaladinJudgements();
                WoWMovement.MoveStop();
                WoWMovement.Face();
                if (ObjectManager.Me.GotTarget && !Me.IsAutoAttacking)
                    Lua.DoString("StartAttack()");
            }

        }

        public void HandleFalling() { }

        private void slog(string msg)
        {
            if (msg == logspam)
            {
                return;
            }

            Styx.Helpers.Logging.Write(msg);
            logspam = msg;
        }

        private void slog(string msg, params object[] args)
        {
            if (msg != logspam)
            {
                try
                {
                    Logging.Write(msg, args);
                    logspam = msg;
                }
                catch (Exception ex)
                {
                    Logging.WriteDebug("Error in slog: ");
                    Logging.WriteDebug(ex.Source);
                }

            }
        }

        public void PreCombatBuff()
        {
            // check buffs 
            buffTimer.Reset();
            if (NeedCombatBuffs)
            {
                PaladinBuffs();
            }
        }

        public void Heal()
        {
            if (Me.Combat)
            {
                HammerOfJustice();

                healTarget.Target();

                if (Equals(healTarget, Me))
                {
                    DivineShield();
                }
                else if (healTarget.Class != WoWClass.Warrior)
                {
                    HandOfProtection();
                }

                if (healTarget.HealthPercent < 25)
                {
                    LayOnHands();                    
                }

                if (SpellManager.KnownSpells.ContainsKey("Flash of Light")
                    && Me.ManaPercent < 35)
                {
                    FlashOfLight();
                }
                else
                {
                    HolyLight();
                }
            }
            else
            {
                HolyLight();
            }
        }

        private bool combatChecks()
        {
            if (!Me.GotTarget)
            {
                return false;
            }

            if (Me.Dead)
            {
                slog("I died.");
                return false;
            }

            if (ObjectManager.Me.GotTarget && !Me.IsAutoAttacking)
                Lua.DoString("StartAttack()");

            try
            {
                if (targetDistance > 50)
                {
                    slog("Out of range: " + Me.CurrentTarget.Name + " is " + System.Math.Round(targetDistance).ToString() + " yards away.");
                    addsList = getAdds();
                    if (!Equals(null, addsList) && addsList.Count > 0)
                    {
                        slog("Switching to {0}.", addsList[0].Name);
                        addsList[0].Target();
                    }
                    return false;
                }
            }
            catch
            {
                slog("Paladin targetting error.");
                return false;
            }

            float meleeRange = 5;

            try
            {
                if (targetDistance > meleeRange)
                {
                    slog(Me.CurrentTarget.Name + " is at " + System.Math.Round(targetDistance).ToString() + " yards.");
                    int approachSeconds = 0;

                    // get within range
                    while (approachSeconds < 45 &&
                         targetDistance > meleeRange &&
                         targetDistance < 50)
                    {
                        if (targetDistance > 20)
                        {
                            movementDuration = 1000;
                        }
                        else
                        {
                            movementDuration = 350;
                        }

                        if (!movementTimer.IsRunning ||
                                movementTimer.ElapsedMilliseconds > movementDuration)
                        {
                            WoWMovement.ClickToMove(Me.CurrentTarget.Location);
                        }

                        Thread.Sleep(movementDuration);

                        ++approachSeconds;
                    }

                    WoWMovement.MoveStop();
                }
                else
                {
                    if (Me.IsMoving)
                    {
                        WoWMovement.MoveStop();
                    }
                    WoWMovement.Face();
                }
            }
            catch
            {
                slog("Paladin range error.");
                return false;
            }

            return true;
        }

        public void Combat()
        {
            if (!Me.GotTarget)
                return;

            if (!Equals(null, Me.PartyMember1) && !Equals(Me.CurrentTarget, Me.PartyMember1.CurrentTarget) && Me.PartyMember1.Distance < 45)
            {
                Me.PartyMember1.CurrentTarget.Target();
                Me.CurrentTarget.Face();
            }

            if (!Me.Combat)
                slog("Not in combat");
            else
                slog("In combat now");

            if (Me.GotTarget && Me.CurrentTarget.Guid != lastGuid)
            {
                fightTimer.Reset();
                fightTimer.Start();
                lastGuid = Me.CurrentTarget.Guid;
            }

            if (Me.HealthPercent < 25)
            {
                LayOnHands();
            }

            if (Me.HealthPercent < 30)
            {
                DivineShield();
            }

            if (combatChecks())
            {
                if ((Me.HealthPercent < 30 && Me.CurrentTarget.HealthPercent > Me.CurrentTarget.HealthPercent))
                {
                    Logic.Common.Combat.Healing.UseHealthPotion();
                    GiftOfTheNaaru();
                    DivineShield();
                }

                if (Me.ManaPercent < 30 &&
                    Me.CurrentTarget.HealthPercent > Me.CurrentTarget.HealthPercent)
                {
                    Logic.Common.Combat.Healing.UseManaPotion();
                }

                if (NeedHeal)
                {                    
                    Heal();
                }
            }

            if (combatChecks())
            {
                if (Me.CurrentTarget.IsCasting)
                {
                    WarStomp();
                    ArcaneTorrent();
                }

                Berserking();
                Bloodrage();

                PaladinJudgements();
                if (Me.ManaPercent < 50)
                {
                    slog("Mana below 50%.");
                    DivinePlea();
                }
            }

            try
            {
                addsList = getAdds();
            }
            catch
            {
                slog("oops");
            }

            if (addsList.Count > 1)
            {
                Consecration();
            }

            if (Me.PartyMembers.Count == 0 && combatChecks())
            {
                Exorcism();
            }

            if (combatChecks())
            {
                CrusaderStrike();
            }

            if (combatChecks())
            {
                DivineStorm();
            }

            if (combatChecks())
            {
                HammmerOfWrath();
            }

            buffTimer.Reset();

            if (Me.GotTarget && !Me.CurrentTarget.IsPlayer && fightTimer.ElapsedMilliseconds > 20 * 1000 && Me.CurrentTarget.HealthPercent > 95)
            {
                slog(" This " + Me.CurrentTarget.Name + " is a bugged mob.  blacklisting for 1 hour.");

                Logic.Blacklist.Add(Me.CurrentTarget.Guid, TimeSpan.FromHours(1.00));

                Styx.Helpers.KeyboardManager.PressKey('S');
                Thread.Sleep(5 * 1000);
                Styx.Helpers.KeyboardManager.ReleaseKey('S');
                Me.ClearTarget();
                lastGuid = 0;
            }
        }

        /// <summary>
        /// Finds a list of all units in vicinity that are targetting you
        /// </summary>

        private List<WoWUnit> getAdds()
        {
            List<WoWUnit> mobList = ObjectManager.GetObjectsOfType<WoWUnit>(false);
            List<WoWUnit> enemyMobList = new List<WoWUnit>();

            foreach (WoWUnit thing in mobList)
            {
                if ((thing.Guid != Me.Guid) &&
                    thing.IsTargetingMe)
                {
                    enemyMobList.Add(thing);
                }
            }

            if (enemyMobList.Count > 1)
            {
                slog("Warning: there are " + enemyMobList.Count.ToString() + " attackers.");
            }
            return enemyMobList;

        }

        #region paladin logic

        void PaladinJudgements()
        {
            if (combatChecks())
            {
                // stun before seal of command
                if (!hammerOfJusticeTimer.IsRunning ||
                    hammerOfJusticeTimer.ElapsedMilliseconds > 60 * 1000)
                {
                    if (Me.Buffs.ContainsKey("Seal of Command"))
                    {
                        HammerOfJustice();
                    }
                }

                if (SpellManager.KnownSpells.ContainsKey("Judgement of Justice") && (Me.CurrentTarget.IsPlayer ||Me.CurrentTarget.Elite ))
                {
                    JudgementOfJustice();
                    return;
                }

                if (SpellManager.KnownSpells.ContainsKey("Judgement of Wisdom"))
                {
                    if (Me.Level > 59 || Me.ManaPercent < 70)
                        JudgementOfWisdom();
                }

                if (SpellManager.KnownSpells.ContainsKey("Judgement of Light") &&
                    !SpellManager.KnownSpells["Judgement of Light"].Cooldown)
                {
                    JudgementOfLight();
                }
            }
        }

        /// <summary>
        /// Check buffs every 15 seconds between combat
        /// </summary>
        void PaladinBuffs()
        {
            if (!buffTimer.IsRunning ||
                    buffTimer.ElapsedMilliseconds > 5 * 1000)
            {
                {
                    if (SpellManager.KnownSpells.ContainsKey("Seal of Command"))
                    {
                        if (!Me.Buffs.ContainsKey("Seal of Command"))
                        {
                            SealOfCommand("Seal of Command.");
                        }

                    }
                    else if (!Me.Buffs.ContainsKey("Seal of Righteousness") &&
                        SpellManager.KnownSpells.ContainsKey("Seal of Righteousness"))
                    {
                        SealOfRighteousness("Seal of Righteousness.");
                    }

                    // aura
                    if (SpellManager.KnownSpells.ContainsKey("Retribution Aura"))
                    {
                        if (!Me.Buffs.ContainsKey("Retribution Aura"))
                        {
                            RetributionAura();
                        }
                    }
                    else if (!Me.Buffs.ContainsKey("Devotion Aura") &&
                        SpellManager.KnownSpells.ContainsKey("Devotion Aura"))
                    {
                        DevotionAura();
                    }

                    if (Me.Level > 3 &&
                        !Me.Buffs.ContainsKey("Blessing of Might") &&
                        !Me.Buffs.ContainsKey("Greater Blessing of Might") &&
                        !Me.Buffs.ContainsKey("Battle Shout") &&
                        SpellManager.KnownSpells.ContainsKey("Blessing of Might"))
                    {
                        if (Me.GotTarget &&
                            Me.CurrentTarget.Guid == Me.Guid)
                        {
                            Me.ClearTarget();
                        }

                        BlessingOfMight("Blessing of Might.");
                    }

                    buffTimer.Reset();
                    buffTimer.Start();
                }

                if (!sealTimer.IsRunning ||
                    sealTimer.ElapsedMilliseconds > 25 * 60 * 1000)
                {

                    if (SpellManager.KnownSpells.ContainsKey("Seal of Command"))
                    {
                        SealOfCommand("Refresh Seal of Command.");
                    }
                    else
                    {
                        SealOfRighteousness("Refresh Seal of Righteousness.");
                    }

                    sealTimer.Reset();
                    sealTimer.Start();
                }

                if (!blessingTimer.IsRunning ||
                    blessingTimer.ElapsedMilliseconds > 7 * 60 * 1000)
                {
                    if (Me.GotTarget &&
                        Me.CurrentTarget.Guid != Me.Guid)
                    {
                        Me.ClearTarget();
                    }

                    BlessingOfMight("Refresh Blessing of Might.");
                    blessingTimer.Reset();
                    blessingTimer.Start();
                }
            }
        }




        #endregion

        #region paladin spells
        /// <summary>
        /// Gives additional armor to party and raid members within 40 yards. 
        /// </summary>
        void DevotionAura()
        {
            // http://www.wowhead.com/?spell=465
            if (SpellManager.CastSpell("Devotion Aura"))
            {
                slog("Devotion Aura.");
            }
        }

        /// <summary>
        /// Heals a friendly target.
        /// </summary>
        void HolyLight()
        {
            // http://www.wowhead.com/?spell=635
            if (SpellManager.CastSpell("Holy Light", true))
            {
                slog("Holy Light.");
                while (Me.IsCasting)
                {
                    if (healTarget.HealthPercent > 75)
                    {
                        KeyboardManager.KeyUpDown(' ');
                        break;
                    }
                    Thread.Sleep(200);
                }
            }
        }

        /// <summary>
        /// Fills the Paladin with holy spirit for 30 min, granting each melee attack additional Holy damage. 
        /// Unleashing this Seal's energy will cause extra Holy damage to an enemy.
        /// </summary>
        void SealOfRighteousness(string msg)
        {
            // http://www.wowhead.com/?spell=21084
            bool castDone = SpellManager.CastSpell("Seal of Righteousness");
            if (castDone)
            {
                slog(msg);
            }
        }

        /// <summary>
        /// Places a Blessing on the friendly target, increasing attack power for 10 min. 
        /// </summary>
        void BlessingOfMight(string msg)
        {
            // http://www.wowhead.com/?spell=19740
            if (SpellManager.CastSpell("Blessing of Might"))
            {
                slog(msg);
            }
        }

        /// <summary>
        /// Unleashes the energy of a Seal spell to judge an enemy for 20 sec, granting attacks made against the judged enemy a chance of healing the attacker for 2% of their maximum health. 
        /// </summary>
        void JudgementOfLight()
        {
            // http://www.wowhead.com/?spell=20271
            if (Me.GotTarget &&
                SpellManager.CastSpell("Judgement of Light"))
            {
                slog("Judgement of Light.");
            }
        }

        /// <summary>
        /// Reduces all damage taken by 50% for 12 sec. 
        /// </summary>
        void DivineProtection()
        {
            // http://www.wowhead.com/?spell=498
        }

        /// <summary>
        /// Purifies the friendly target, removing 1 disease effect and 1 poison effect.
        /// </summary>
        void Purify()
        {
            // http://www.wowhead.com/?spell=1152
        }

        /// <summary>
        /// Stuns the target
        /// </summary>
        void HammerOfJustice()
        {
            if (!hammerOfJusticeTimer.IsRunning ||
                hammerOfJusticeTimer.ElapsedMilliseconds > 60 * 1000)
            {
                // http://www.wowhead.com/?spell=853
                if (Me.GotTarget &&
                    SpellManager.CastSpell("Hammer of Justice"))
                {
                    slog("Hammer of Justice.");
                    hammerOfJusticeTimer.Reset();
                    hammerOfJusticeTimer.Start();
                }
            }
        }

        /// <summary>
        /// A targeted party or raid member is protected from all physical attacks for 6 sec, but during that time they cannot attack or use physical abilities.
        /// </summary>
        void HandOfProtection()
        {
            // http://www.wowhead.com/?spell=1022
            if (SpellManager.CastSpell("Hand of Protection"))
            {
                slog("Hand of Protection.");
            }
            else
            {
                // slog("Can't use Hand of Protection now.");
            }

        }

        /// <summary>
        /// Protects the paladin from all damage and spells for 12 sec
        /// </summary>
        private bool DivineShield()
        {
            if (SpellManager.CastSpell("Divine Shield"))
            {
                slog("Divine Shield.");
                return true;
            }
            else if (SpellManager.CastSpell("Divine Protection"))
            {
                slog("Divine Protection.");
                return true;
            }
            else
            {
                // slog("Can't use Divine Shield now.");
                return false;
            }
        }

        /// <summary>
        /// Heals a friendly target for an amount equal to the Paladin's maximum health.
        /// </summary>
        void LayOnHands()
        {
            // http://www.wowhead.com/?spell=633
            if (SpellManager.CastSpell("Lay on Hands"))
            {
                slog("Lay on Hands for " + Me.CurrentTarget.Class  + ".");
            }
            else
            {
                // slog("Can't use Lay on Hands now.");
            }
        }

        /// <summary>
        /// Unleashes the energy of a Seal spell to judge an enemy, giving each attack a chance to restore 2% of the attacker's base mana.
        /// </summary>
        void JudgementOfWisdom()
        {
            // http://www.wowhead.com/?spell=53408
            if (Me.GotTarget &&
                SpellManager.CastSpell("Judgement of Wisdom") &&
                Me.Level < 60)
            {
                slog("Mana is " + System.Math.Floor(Me.ManaPercent).ToString() + "% so casting Judgement of Wisdom.");
            }
        }

        /// <summary>
        /// Places a Blessing on the friendly target, restoring mana every 5 seconds for 10 min.
        /// </summary>
        void BlessingOfWisdom(string msg)
        {
            // http://www.wowhead.com/?spell=19742
            if (SpellManager.CastSpell("Blessing of Wisdom"))
            {
                slog(msg);
            }
        }

        /// <summary>
        /// Taunts the target to attack you.  If the target is not currently targeting you, causes Holy damage.
        /// </summary>
        void HandOfReckoning()
        {
            // http://www.wowhead.com/?spell=62124
            if (!SpellManager.KnownSpells.ContainsKey("Hand of Reckoning"))
            {
                slog("Hand of Reckoning not known.");
            }

            if (Me.CurrentTarget.IsPlayer)
                return;

            bool castDone = SpellManager.CastSpell("Hand of Reckoning");
            if (castDone)
            {
                slog("Pulling with Hand of Reckoning.");
            }
            else
            {
                slog("Hand of Reckoning failed.");
            }
        }

        /// <summary>
        /// All melee attacks deal additional Holy damage.  When used with attacks or abilities that strike a single target, this additional Holy damage will strike up to 2 additional targets.  Lasts 30 min.
        /// Unleashing this Seal's energy will judge an enemy, instantly causing Holy damage.
        /// </summary>
        void SealOfCommand(string msg)
        {
            // http://www.wowhead.com/?spell=20375
            if (SpellManager.CastSpell("Seal of Command"))
            {
                slog(msg);
            }
        }

        /// <summary>
        /// Causes Holy damage to any enemy that strikes a party or raid member within 40 yards. 
        /// </summary>
        void RetributionAura()
        {
            // http://www.wowhead.com/?spell=7294
            if (SpellManager.CastSpell("Retribution Aura"))
            {
                slog("Retribution Aura.");
            }
        }

        /// <summary>
        /// Consecrates the land beneath the Paladin, doing Holy damage over 8 sec to enemies who enter the area.
        /// </summary>
        void Consecration()
        {
            // http://www.wowhead.com/?spell=26573
            if (SpellManager.CastSpell("Consecration"))
            {
                slog("Consecration.");
            }
        }

        /// <summary>
        /// Causes Holy damage to an enemy target.  If the target is Undead or Demon, it will always critically hit.
        /// </summary>
        void Exorcism()
        {
            // http://www.wowhead.com/?spell=879
            if (Me.GotTarget &&
                SpellManager.CastSpell("Exorcism"))
            {
                slog("Exorcism.");
            }

        }

        /// <summary>
        /// Heals a friendly target.  If the target has the Sacred Shield effect, they heal an additional 100% over 12 sec.
        /// </summary>
        void FlashOfLight()
        {
            // http://www.wowhead.com/?spell=19750
            if (SpellManager.CastSpell("Flash of Light"))
            {
                slog("Flash of Light.");
            }
        }

        /// <summary>
        /// Unleashes the energy of a Seal spell to judge an enemy for 20 sec, preventing them from fleeing and limiting their movement speed. 
        /// </summary>
        void JudgementOfJustice()
        {
            // http://www.wowhead.com/?spell=53407
            if (Me.GotTarget &&
                SpellManager.CastSpell("Judgement of Justice"))
            {
                slog("Judgement of Justice.");
            }


        }

        /// <summary>
        /// Cleanses a friendly target, removing 1 poison effect, 1 disease effect, and 1 magic effect.
        /// </summary>
        void Cleanse()
        {
            // http://www.wowhead.com/?spell=4987
            if (SpellManager.CastSpell("Cleanse"))
            {
                slog("Cleanse.");
            }
            else if (SpellManager.CastSpell("Purify"))
            {
                slog("Purify.");
            }
        }

        /// <summary>
        /// Hurls a hammer that strikes an enemy for Holy damage.  Only usable on enemies that have 20% or less health.
        /// </summary>
        void HammmerOfWrath()
        {
            if (Me.Level < 44) return;

            // http://www.wowhead.com/?spell=24275
            if (Me.CurrentTarget.HealthPercent < 21)
            {
                SpellManager.CastSpell("Hammer of Wrath");
                slog("Hammer of Wrath.");
            }
        }

        /// <summary>
        /// Sends bolts of holy power in all directions, causing AOE Holy damage and stunning all Undead and Demon targets within 10 yds for 3 sec.
        /// </summary>
        void HolyWrath()
        {
            // http://www.wowhead.com/?spell=2812
        }

        /// <summary>
        /// An instant strike that causes 75% weapon damage.
        /// </summary>
        void CrusaderStrike()
        {
            // http://www.wowhead.com/?spell=35395
            if (Me.Level < 50) return;
            if (Me.GotTarget &&
                SpellManager.CastSpell("Crusader Strike"))
            {
                slog("Crusader Strike.");
            }

        }

        /// <summary>
        /// An instant weapon attack that causes 110% of weapon damage to up to 4 enemies within 8 yards.  The Divine Storm heals up to 3 party or raid members totaling 25% of the damage caused.
        /// </summary>
        void DivineStorm()
        {
            // http://www.wowhead.com/?spell=53385
            if (Me.Level < 60) return;

            if (Me.GotTarget &&
                SpellManager.CastSpell("Divine Storm"))
            {
                slog("Divine Storm.");
            }
        }

        /// <summary>
        /// Increases the mounted speed by 20% for all party and raid members within 40 yards. 
        /// </summary>
        void CrusaderAura()
        {
            // http://www.wowhead.com/?spell=32223
        }

        /// <summary>
        /// Fills the Paladin with holy power, causing attacks to apply Holy Vengeance, which deals additional Holy damage over 15 sec.  Holy Vengeance can stack up to 5 times.  Once stacked to 5 times, each of the Paladin's attacks also deals 33% weapon damage as additional Holy damage. 
        /// </summary>
        void SealOfVengeance()
        {
            // http://www.wowhead.com/?spell=31801
        }

        /// <summary>
        /// Fills the Paladin with holy power, causing attacks to apply Holy Vengeance, which deals additional Holy damage over 15 sec.  Holy Vengeance can stack up to 5 times.  Once stacked to 5 times, each of the Paladin's attacks also deals 33% weapon damage as additional Holy damage. 
        /// </summary>
        void SealOfCorruption()
        {
            // http://www.wowhead.com/?spell=53736
        }

        /// <summary>
        /// Each time the target takes damage they gain a Sacred Shield, 
        /// absorbing 500 damage and increasing the paladin's chance to 
        /// critically hit with Flash of Light by 50% for up to 6 sec.  
        /// They cannot gain this effect more than once every 6 sec.  Lasts 30 sec.
        /// </summary>
        void SacredShield()
        {
            // http://www.wowhead.com/?spell=53601
        }

        /// <summary>
        /// You gain 25% of your total mana over 15 sec, but the amount healed by your Flash of Light, Holy Light, and Holy Shock spells is reduced by 50%.
        /// </summary>
        void DivinePlea()
        {
            // http://www.wowhead.com/?spell=54428
            if (SpellManager.CastSpell("Divine Plea"))
            {
                slog("Divine Plea.");
            }
        }
        #endregion

        #region movement logic
        WoWPoint attackPoint
        {
            get
            {
                if (Me.GotTarget)
                {
                    return WoWMovement.CalculatePointFrom(Me.CurrentTarget.Location, 1.0f);
                }
                else
                {
                    WoWPoint noSpot = new WoWPoint();
                    return noSpot;
                }
            }
        }
        WoWPath pathExists = new WoWPath(ObjectManager.Me.Location, ObjectManager.Me.Location);
        private static bool UseNavigator;
        private WoWUnit _lastTarget;
        private WoWPoint _dest = WoWPoint.Invalid;
        private WoWPoint GetTraceLinePos()
        {
            return new WoWPoint(Me.X, Me.Y, Me.Z + 2.132f);
        }
        private static ulong lastPullGuid;
        private static Stopwatch movementTimer = new Stopwatch();
        private static int movementDuration;

        private void MoveToTarget()
        {
            try
            {
                pathExists = Navigator.GeneratePath(ObjectManager.Me.Location, attackPoint, false, true);
            }
            catch (Exception ex)
            {
                Logging.WriteException(ex);
            }

            if (Me.CurrentTarget.Guid != lastPullGuid)
            {
                UseNavigator = false;
                lastPullGuid = Me.CurrentTarget.Guid;
            }

            if (WorldManager.IsInLineOfSight(GetTraceLinePos(), attackPoint + new WoWPoint(0, 0, 2.132f)) &&
                !UseNavigator)
            {
                WoWMovement.ClickToMove(attackPoint);
                Thread.Sleep(150);
                if (StuckDetector.IsStuck)
                {
                    UseNavigator = true;
                }
            }
            else
            {
                if (_lastTarget == null)
                    _lastTarget = Me.CurrentTarget;

                if (_lastTarget != null)
                {
                    if (Me.CurrentTarget == _lastTarget)
                    {
                        if (!_dest.IsValid)
                            _dest = attackPoint;

                        Navigator.MoveTo(_dest);
                    }
                    else
                    {
                        _lastTarget = null;
                        _dest = WoWPoint.Invalid;
                    }
                }
            }
        }
        #endregion

        #region party logic

        private bool isPartyMode
        {
            get
            {
                if (Me.PartyMembers.Count > 0 || Me.RaidMembers.Count > 0)
                {
                    return true;
                }
                return false;
            }
        }

        private List<ulong> partyGuids
        {
            get
            {
                List<ulong> _partyGuids = new List<ulong>();

                if (!isPartyMode)
                    return _partyGuids;

                foreach (WoWPlayer player in Me.PartyMembers)
                {
                    _partyGuids.Add(player.Guid);
                }

                if (!_partyGuids.Contains(Me.Guid))
                {
                    _partyGuids.Add(Me.Guid);
                }
                return _partyGuids;
            }
        }

        private List<WoWPlayer> partyMembers
        {
            get
            {
                List<WoWPlayer> _partyMembers = new List<WoWPlayer>();

                if (!isPartyMode)
                    return partyMembers;

                foreach (WoWPlayer player in Me.PartyMembers)
                {
                    _partyMembers.Add(player);
                }

                if (!_partyMembers.Contains(Me))
                {
                    _partyMembers.Add(Me);
                }
                return partyMembers;

            }
        }

        private WoWPlayer healTarget
        {
            get
            {
                if (isPartyMode)
                {
                    WoWPlayer _healTarget = Me;

                    foreach (WoWPlayer pal in Me.PartyMembers)
                    {
                        if (pal.HealthPercent < 100 && pal.InLineOfSight)
                        {
                            if (Equals(null, _healTarget) || pal.HealthPercent < _healTarget.HealthPercent)
                            {
                                _healTarget = pal;
                            }
                        }
                    }

                    return _healTarget;
                }
                else
                {
                    return Me;
                }
            }
        }


        #endregion

        #region horde racials

        // Berserking
        void Berserking()
        {
            if (ObjectManager.Me.Race == WoWRace.Troll &&
                SpellManager.CastSpell("Berserking"))
            {
                Styx.Helpers.Logging.Write("Berserking.");
            }
        }

        // Bloodrage
        void Bloodrage()
        {
            if (ObjectManager.Me.Race == WoWRace.Orc &&
                SpellManager.CastSpell("Bloodrage"))
            {
                Styx.Helpers.Logging.Write("Bloodrage.");
            }
        }

        // War Stomp
        void WarStomp()
        {
            if (ObjectManager.Me.Race == WoWRace.Tauren &&
                SpellManager.CastSpell("War Stomp"))
            {
                Styx.Helpers.Logging.Write("War Stomp.");
            }
        }

        // Arcane Torrent
        void ArcaneTorrent()
        {
            if (ObjectManager.Me.Race == WoWRace.BloodElf &&
                SpellManager.CastSpell("Arcane Torrent"))
            {
                Styx.Helpers.Logging.Write("Arcane Torrent.");
            }
        }

        // Will of the Forsaken 
        void WillOfTheForsaken()
        {
            if (ObjectManager.Me.Race == WoWRace.Undead &&
                SpellManager.CastSpell("Will of the Forsaken"))
            {
                Styx.Helpers.Logging.Write("Will of the Forsaken.");
            }
        }
        #endregion

        #region alliance racials

        // Stoneform
        void Stoneform()
        {
            if (ObjectManager.Me.Race == WoWRace.Dwarf &&
                SpellManager.CastSpell("Stoneform"))
            {
                Styx.Helpers.Logging.Write("Stoneform.");
            }
        }

        // Gift of the Naaru
        void GiftOfTheNaaru()
        {
            if (ObjectManager.Me.Race == WoWRace.Draenei &&
                SpellManager.CastSpell("Gift of the Naaru"))
            {
                Styx.Helpers.Logging.Write("Gift of the Naaru.");
            }
        }

        // Every Man for Himself
        void EveryManForHimself()
        {
            if (ObjectManager.Me.Race == WoWRace.Human &&
                SpellManager.CastSpell("Every Man for Himself"))
            {
                Styx.Helpers.Logging.Write("Every Man for Himself.");
            }
        }

        // Shadowmeld
        void Shadowmeld()
        {
            if (ObjectManager.Me.Race == WoWRace.NightElf &&
                SpellManager.CastSpell("Shadowmeld"))
            {
                Styx.Helpers.Logging.Write("Shadowmeld.");
            }
        }

        // Escape Artist
        void EscapeArtist()
        {
            if (ObjectManager.Me.Race == WoWRace.Gnome &&
                SpellManager.CastSpell("Escape Artist"))
            {
                Styx.Helpers.Logging.Write("Escape Artist.");
            }
        }


        #endregion


    }
}
#pragma warning restore