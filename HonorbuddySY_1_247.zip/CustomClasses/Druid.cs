﻿#pragma warning disable
namespace Styx.Bot.CustomClasses
{
    using Styx;
    using Styx.Logic;
    using System;
    using System.Diagnostics;
    using System.Collections.Generic;
    using Helpers;
    using System.Linq;
    using Logic.Pathing;
    using System.Threading;
    using Logic.Common.Combat;
    using Object_Dumping_Enumeration;
    using CustomCombat.CombatInterface;
    using Object_Dumping_Enumeration.WoWObjects;
    using Memory_Read_Write_Inject.Lua;

    public class Druid : ICombat
    {
        public WoWClass Class { get { return WoWClass.Druid; } }

        public string Name { get { return "Hawker's Druid 1.3"; } }

        #region Private Members

        public void HandleFalling() { }

        private void slog(string msg)
        {
            if (msg == _logspam)
            {
                return;
            }

            Logging.Write(msg);
            _logspam = msg;
        }

        #endregion

        #region Global Variables

        private string _logspam;
        private readonly LocalPlayer Me = ObjectManager.Me;

        Stopwatch buffTimer = new Stopwatch();
        private Stopwatch thornsTimer = new Stopwatch();
        private Stopwatch markOfTheWildTimer = new Stopwatch();
        private uint killComboCount = 4;
        Dictionary<WoWPlayer, DateTime> followers = new Dictionary<WoWPlayer, DateTime>();
        Point pointNow = new Point();
        WoWUnit.ShapeshiftForm myForm = ObjectManager.Me.Shapeshift;
        List<WoWUnit> addsList = new List<WoWUnit>();
        private Stopwatch rakeTimer = new Stopwatch();

        private WoWUnit myTarget = null;

        private double targetDistance
        {
            get
            {
                return Me.GotTarget ? Me.CurrentTarget.Distance : uint.MaxValue - 1;

            }
        }
        private static ulong lastGuid;

        private static Stopwatch fightTimer = new Stopwatch();
        private static Stopwatch pullTimer = new Stopwatch();
        private static Stopwatch moveTimer = new Stopwatch();

        #endregion

        #region Rest

        public bool NeedRest
        {
            get
            {
                bool ret = false;

                // forms test
                if (Me.Level > 9 &&
                    !Me.Mounted)
                {
                    myForm = ObjectManager.Me.Shapeshift;

                    if (SpellManager.KnownSpells.ContainsKey("Cat Form"))
                    {
                        if (myForm != WoWUnit.ShapeshiftForm.Cat)
                        {
                            slog("Enter cat form.");
                            ret = true;
                        }
                    }
                    else if (myForm != WoWUnit.ShapeshiftForm.Bear &&
                        SpellManager.KnownSpells.ContainsKey("Bear Form"))
                    {
                        slog("Enter bear form.");
                        ret = true;
                    }

                    // buffs rest
                    if (thornsTimer.ElapsedMilliseconds > 7 * 60 * 1000 ||
                        (SpellManager.KnownSpells.ContainsKey("Thorns") &&
                            !Me.Buffs.ContainsKey("Thorns")))
                    {
                        slog("I need Thorns.");
                        ret = true;
                    }

                    if (markOfTheWildTimer.ElapsedMilliseconds > 27 * 60 * 1000 ||
                        (SpellManager.KnownSpells.ContainsKey("Mark of the Wild") &&
                            !Me.Buffs.ContainsKey("Mark of the Wild") &&
                            !Me.Buffs.ContainsKey("Gift of the Wild")))
                    {
                        slog("I need Mark of the Wild");
                        ret = true;
                    }
                }


                // health/mana test
                if (ObjectManager.Me.HealthPercent <= 50)
                {
                    slog("Health: " + System.Math.Round(ObjectManager.Me.HealthPercent).ToString() + "%");
                    ret = true;
                }

                if (ObjectManager.Me.ManaPercent <= 40)
                {
                    slog("Health: " + System.Math.Round(ObjectManager.Me.ManaPercent).ToString() + "%");
                    ret = true;
                }

               return ret;
            }
        }

        public void Rest()
        {
            if (ObjectManager.Me.GetPowerPercent(WoWPowerType.Health) <= 60)
            {
                Heal();
            }

            DruidBuffs();

            if (Me.HealthPercent < 40)
            {
                Logic.Common.Rest.Feed();
            }

            // reserve Innervate for combat emergencies
            if (Me.ManaPercent < 40)
            {
                Logic.Common.Rest.Feed();
            }

            if (!Me.Mounted)
            {
                TakeForm();
                if (!Equals(null, prettyFlower) && Me.HealthPercent > 95)
                {
                    harvestFlower(prettyFlower);
                }
            }



        }

        #endregion

        #region PreCombatBuffs

        public bool NeedPreCombatBuffs
        {
            get
            {
                return true;
            }
        }

        public void PreCombatBuff()
        {
            DruidBuffs();
        }

        private void DruidBuffs()
        {
            if (!Me.Combat &&
                !Me.Mounted)
            {
                if (!buffTimer.IsRunning ||
                    buffTimer.ElapsedMilliseconds > 15 * 1000)
                {
                    if (Me.GotTarget &&
                      Me.CurrentTarget.Guid != Me.Guid)
                    {
                        Me.ClearTarget();
                    }

                    Thorns();
                    MarkOfTheWild();
                    buffTimer.Reset();
                    buffTimer.Start();
                }
            }
        }

        #endregion

        #region Combat Buffs

        public bool NeedCombatBuffs { get { return false; } }

        public void CombatBuff()
        {
            DruidBuffs();
        }

        /// <summary>
        /// Has this buff procced?
        /// </summary>
        /// <param name="cSearchBuffName"></param>
        /// <returns>True if the buff is present</returns>
        private bool HasBuffProcced(string cSearchBuffName, int minStackCount)
        {
            int stackCount = 0;

            List<string> myBuffs = Lua.LuaGetReturnValue("return UnitBuff(\"player\",\"" + cSearchBuffName + "\")", "hawker.lua");

            if (Equals(null, myBuffs))
                return false;

            string buffName = myBuffs[0];

            if (minStackCount > 0)
            {
                stackCount = Convert.ToInt32(myBuffs[3]);
            }

            if (buffName == cSearchBuffName ||
                stackCount >= minStackCount)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        #endregion

        #region Heal

        public bool NeedHeal
        {
            get
            {
                if (ObjectManager.Me.HealthPercent < 55)
                {
                    if (!Me.Combat)
                    {
                        Me.ClearTarget();
                    }
                    return true;
                }
                return false;
            }
        }

        public void Heal()
        {
            Regrowth();
        }

        #endregion

        #region Pull

        public bool NeedPullBuffs { get { return false; } }

        public void PullBuff()
        {
            DruidBuffs();
        }

        public void Pull()
        {
            #region checks
            if (!Me.GotTarget)
            {
                return;
            }

            if (targetDistance > 100)
            {
                return;
            }

            if (Me.CurrentTarget.Guid != lastGuid)
            {
                fightTimer.Reset();
                lastGuid = Me.CurrentTarget.Guid;
                slog("Killing " + Me.CurrentTarget.Name + " at distance " +
                    System.Math.Round(targetDistance).ToString() + ".");
                pullTimer.Reset();
                pullTimer.Start();

            }
            else
            {
                if (pullTimer.ElapsedMilliseconds > 30 * 1000)
                {
                    slog("Cannot pull " + Me.CurrentTarget.Name + " now.  Blacklist for 3 minutes.");
                    Styx.Logic.Blacklist.Add(Me.CurrentTarget.Guid, System.TimeSpan.FromMinutes(3));
                }
            }

            #endregion

            #region cat
            if (SpellManager.KnownSpells.ContainsKey("Cat Form"))
            {
                if (ObjectManager.Me.Shapeshift != WoWUnit.ShapeshiftForm.Cat)
                {
                    slog("Enter Cat Form.");
                    SpellManager.CastSpell("Cat Form");
                }

                if (!Me.Buffs.ContainsKey("Prowl"))
                {
                    SpellManager.CastSpell("Prowl");
                }

                if (SpellManager.KnownSpells.ContainsKey("Pounce"))
                {
                    if (!Me.Combat && targetDistance > 4.5 &&
                        targetDistance < Styx.Logic.Targeting.PullDistance + 10)
                    {
                        int approachSeconds = 0;

                        // get within range
                        while (approachSeconds < 10 &&
                             targetDistance > 4.75 &&
                             targetDistance < 50)
                        {
                            pointNow = WoWMovement.CalculatePointFrom(Me.CurrentTarget.Location, 0);
                            Navigator.MoveTo(pointNow);

                            Thread.Sleep(250);

                            ++approachSeconds;
                        }

                        WoWMovement.MoveStop();
                    }
                    else
                    {
                        WoWMovement.MoveStop();
                        WoWMovement.Face();
                        Pounce();
                        Navigator.MoveTo(Me.CurrentTarget.Location);
                        Shred();
                    }
                }
                else if (SpellManager.KnownSpells.ContainsKey("Feral Charge - Cat"))
                {
                    double fcDistance = SpellManager.KnownSpells["Feral Charge - Cat"].MaxRange - 1;

                    if (Me.CurrentTarget.Distance > fcDistance)
                    {
                        int approachSeconds = 0;

                        // get within range
                        while (approachSeconds < 10 &&
                             targetDistance > fcDistance &&
                             targetDistance < 50)
                        {
                            pointNow = WoWMovement.CalculatePointFrom(Me.CurrentTarget.Location, (float)fcDistance - 15);
                            Navigator.MoveTo(pointNow);

                            Thread.Sleep(250);

                            ++approachSeconds;
                        }

                        WoWMovement.MoveStop();
                    }
                    else
                    {
                        SpellManager.CastSpell("Feral Charge - Cat");
                        if (!Me.IsAutoAttacking && Me.GotTarget)
                        {
                            Lua.DoString("StartAttack()");
                        }

                        WoWMovement.Face();
                        WoWMovement.ClickToMove(Me.CurrentTarget.Location);
                        Thread.Sleep(500);
                    }
                }
                else if (SpellManager.KnownSpells.ContainsKey("Faerie Fire (Feral)"))
                {
                    double fffDistance = SpellManager.KnownSpells["Faerie Fire (Feral)"].MaxRange - 1;

                    if (Me.CurrentTarget.Distance > fffDistance)
                    {
                        int approachSeconds = 0;

                        // get within range
                        while (approachSeconds < 10 &&
                             targetDistance > fffDistance &&
                             targetDistance < 50)
                        {
                            pointNow = WoWMovement.CalculatePointFrom(Me.CurrentTarget.Location, (float)fffDistance - 15);
                            Navigator.MoveTo(pointNow);

                            Thread.Sleep(250);

                            ++approachSeconds;
                        }

                        WoWMovement.MoveStop();

                    }
                    else
                    {
                        SpellManager.CastSpell("Faerie Fire (Feral)");
                    }
                }

            }
            #endregion
            #region bear
            else if (SpellManager.KnownSpells.ContainsKey("Bear Form"))
            {
                if (ObjectManager.Me.Shapeshift != WoWUnit.ShapeshiftForm.Bear)
                {
                    slog("Enter Bear Form.");
                    if (SpellManager.KnownSpells.ContainsKey("Dire Bear Form"))
                    {
                        SpellManager.CastSpell("Dire Bear Form");
                    }
                    else
                    {
                        SpellManager.CastSpell("Bear Form");
                    }
                }

                if (SpellManager.KnownSpells.ContainsKey("Feral Charge)"))
                {
                    double fcDistance = SpellManager.KnownSpells["Feral Charge)"].MaxRange - 1;

                    if (Me.CurrentTarget.Distance > fcDistance)
                    {
                        if (!movementTimer.IsRunning ||
                            movementTimer.ElapsedMilliseconds > 1000)
                        {
                            pointNow = WoWMovement.CalculatePointFrom(Me.CurrentTarget.Location, (float)fcDistance);
                            movementTimer.Reset();
                            movementTimer.Start();
                        }

                        WoWPoint myPoint = ObjectManager.Me.Location;
                        myPoint.Z += 2.5f;
                        pointNow.Z += 2.5f;

                        if (WorldManager.IsInLineOfSight(myPoint, pointNow))
                        {
                            WoWMovement.ClickToMove(pointNow);
                        }
                        else
                        {

                            Navigator.MoveTo(pointNow);
                        }
                        return;
                    }
                    else
                    {
                        SpellManager.CastSpell("Feral Charge)");
                        slog("Pulled Feral Charge.");
                    }
                }
                else if (SpellManager.KnownSpells.ContainsKey("Faerie Fire (Feral)"))
                {
                    double fffDistance = SpellManager.KnownSpells["Faerie Fire (Feral)"].MaxRange - 1;

                    if (Me.CurrentTarget.Distance > fffDistance)
                    {
                        if (!movementTimer.IsRunning ||
                            movementTimer.ElapsedMilliseconds > 1000)
                        {
                            pointNow = WoWMovement.CalculatePointFrom(Me.CurrentTarget.Location, (float)fffDistance);
                            movementTimer.Reset();
                            movementTimer.Start();
                        }

                        WoWPoint myPoint = ObjectManager.Me.Location;
                        myPoint.Z += 2.5f;
                        pointNow.Z += 2.5f;

                        if (WorldManager.IsInLineOfSight(myPoint, pointNow))
                        {
                            WoWMovement.ClickToMove(pointNow);
                        }
                        else
                        {

                            Navigator.MoveTo(pointNow);
                        }
                        return;
                    }
                    else
                    {
                        SpellManager.CastSpell("Faerie Fire (Feral)");
                    }
                }
                else
                {
                    WoWSpell wrath = SpellManager.KnownSpells["Wrath"];

                    if (Me.GotTarget &&
                        Me.CurrentTarget.Distance > wrath.MaxRange)
                    {
                        WoWPoint myPoint = ObjectManager.Me.Location;
                        myPoint.Z += 2.5f;
                        WoWPoint pointNow = WoWMovement.CalculatePointFrom(Me.CurrentTarget.Location, (float)wrath.MaxRange - 3);
                        pointNow.Z += 2.5f;

                        if (WorldManager.IsInLineOfSight(myPoint, pointNow))
                        {
                            WoWMovement.ClickToMove(pointNow);
                        }
                        else
                        {

                            Navigator.MoveTo(pointNow);
                        }
                        return;

                    }
                    else
                    {
                        WoWMovement.MoveStop();
                        WoWMovement.Face();
                        slog("Pull with Moonfire.");
                        Moonfire();
                    }
                }
            }
            #endregion
            #region squishy
            else if (SpellManager.KnownSpells.ContainsKey("Moonfire"))
            {
                WoWSpell wrath = SpellManager.KnownSpells["Wrath"];

                if (Me.GotTarget &&
                    Me.CurrentTarget.Distance > wrath.MaxRange)
                {
                    WoWPoint myPoint = ObjectManager.Me.Location;
                    myPoint.Z += 2.5f;
                    WoWPoint pointNow = WoWMovement.CalculatePointFrom(Me.CurrentTarget.Location, (float)wrath.MaxRange - 3);
                    pointNow.Z += 2.5f;

                    if (WorldManager.IsInLineOfSight(myPoint, pointNow))
                    {
                        WoWMovement.ClickToMove(pointNow);
                    }
                    else
                    {

                        Navigator.MoveTo(pointNow);
                    }
                    return;
                }
                else
                {
                    WoWMovement.MoveStop();
                    WoWMovement.Face();
                    slog("Pull with Moonfire.");
                    Moonfire();
                }
            }
            else
            {
                WoWSpell wrath = SpellManager.KnownSpells["Wrath"];

                if (Me.GotTarget &&
                    Me.CurrentTarget.Distance > wrath.MaxRange)
                {
                    WoWPoint myPoint = ObjectManager.Me.Location;
                    myPoint.Z += 2.5f;
                    WoWPoint pointNow = WoWMovement.CalculatePointFrom(Me.CurrentTarget.Location, (float)wrath.MaxRange - 3);
                    pointNow.Z += 2.5f;

                    if (WorldManager.IsInLineOfSight(myPoint, pointNow))
                    {
                        WoWMovement.ClickToMove(pointNow);
                    }
                    else
                    {

                        Navigator.MoveTo(pointNow);
                    }
                    return;
                }
                else
                {
                    WoWMovement.MoveStop();

                    slog("Pull with Wrath.");
                    Wrath();
                }
            }
            #endregion
        }

        #endregion

        #region Combat

        public void Combat()
        {
            if (Battlegrounds.Battlegroundstatus == BattlegroundStatus.Active)
            {
                lastGuid = 0;
            }
            else if (!fightTimer.IsRunning ||
               Me.CurrentTarget.Guid != lastGuid)
            {
                fightTimer.Reset();
                fightTimer.Start();
                lastGuid = Me.CurrentTarget.Guid;
            }

            if ((Me.HealthPercent < 30 &&
                Me.CurrentTarget.HealthPercent > Me.CurrentTarget.HealthPercent))
            {
                Logic.Common.Combat.Healing.UseHealthPotion();
                GiftOfTheNaaru();
            }

            if (Me.ManaPercent < 30 &&
                Me.CurrentTarget.HealthPercent > Me.CurrentTarget.HealthPercent)
            {
                Logic.Common.Combat.Healing.UseManaPotion();
            }

            isHorde = Me.IsHorde;
            isAlliance = Me.IsAlliance;

            if (Me.IsMoving)
            {
                WoWMovement.MoveStop();
                Thread.Sleep(100);
            }

            if (Battlegrounds.Battlegroundstatus == BattlegroundStatus.Active)
            {
                WoWPlayer healYou = chooseHealTarget();
                if (!Equals(null, healYou) &&
                    Me.ManaPercent > 50)
                {
                    healYou.Target();
                    Regrowth();
                    return;
                }
            }

            addsList = getAdds();
            if (addsList.Count > 1)
            {
                double enemyHealth = 101;

                foreach (WoWUnit mob in addsList)
                {
                    if (mob.Distance < 10 &&
                    mob.HealthPercent < enemyHealth)
                    {
                        enemyHealth = mob.HealthPercent;
                        myTarget = mob;
                    }
                }

                myTarget.Target();
            }

            WoWMovement.Face();

            if (!Me.IsAutoAttacking && Me.GotTarget)
            {
                Lua.DoString("StartAttack()");
            }

            if (SpellManager.KnownSpells.ContainsKey("Cat Form"))
            {
                Fluffycat();
            }
            else if (SpellManager.KnownSpells.ContainsKey("Bear Form") ||
                SpellManager.KnownSpells.ContainsKey("Dire Bear Form"))
            {
                HuggyBear();
            }
            else
            {
                SquishyNoob();
            }

            addsList = getAdds();

            if (addsList.Count > 1)
            {
                Barkskin();
                Berserk();
            }

            buffTimer.Reset();

            if (!Me.CurrentTarget.IsPlayer && 
                fightTimer.ElapsedMilliseconds > 40 * 1000 &&
                Me.CurrentTarget.HealthPercent > 95)
            {
                slog(" This " + Me.CurrentTarget.Name + " is a bugged mob.  blacklisting for 1 hour.");

                Logic.Blacklist.Add(Me.CurrentTarget.Guid, TimeSpan.FromHours(1.00));

                Styx.Helpers.KeyboardManager.PressKey('S');
                Thread.Sleep(5 * 1000);
                Styx.Helpers.KeyboardManager.ReleaseKey('S');
                Me.ClearTarget();
                lastGuid = 0;
            }

        }
        #region Combat Styles

        private void TakeForm()
        {
            if (Me.Level < 10)
            {
                return;
            }

            myForm = ObjectManager.Me.Shapeshift;

            if (SpellManager.KnownSpells.ContainsKey("Cat Form"))
            {
                if (myForm == WoWUnit.ShapeshiftForm.Cat)
                {
                    return;
                }
                else
                {
                    slog("Enter Cat Form.");
                    SpellManager.CastSpell("Cat Form");
                }
            }
            else if (myForm != WoWUnit.ShapeshiftForm.Bear &&
                SpellManager.KnownSpells.ContainsKey("Bear Form"))
            {
                slog("Enter bear form.");
                if (SpellManager.KnownSpells.ContainsKey("Dire Bear Form"))
                {
                    SpellManager.CastSpell("Dire Bear Form");
                }
                else
                {
                    SpellManager.CastSpell("Bear Form");
                }
            }
        }

        private void Fluffycat()
        {
            #region survival
            // predator's swiftness
            //if (Me.HealthPercent < 70 &&
            //    Me.ManaPercent > 50 &&
            //    HasBuffProcced("Predator's Swiftness", 0))
            //{
            //    slog("Predator's Swiftness.");
            //    HealingTouch();
            //    return;                
            //}
            //else 
            if (Me.HealthPercent < 50 &&
                Me.ManaPercent > 25)
            {

                if (Me.HealthPercent < 30 &&
                    Me.ManaPercent > 35)
                {
                    Rejuvenation();
                }
                Regrowth();

                if (Me.ManaPercent < 35)
                {
                    Innervate();
                }
                return;
            }
            #endregion

            #region combat casting
            // try to execute runners
            if (Me.GotTarget && Me.CurrentTarget.HealthPercent < 20 &&
                    targetDistance > 15)
            {
                Moonfire();
            }

            // combat
            TakeForm();

            if (combatChecks() &&
                Me.GetCurrentPower(WoWPowerType.Energy) < 60)
            {
                TigersFury();
            }

            if (combatChecks())
            {
                if (SpellManager.KnownSpells.ContainsKey("Ferocious Bite") &&
                    (Me.ComboPoints >= killComboCount ||
                    Me.CurrentTarget.HealthPercent < 30))
                {
                    FerociousBite();
                }
                else
                {
                    if (!Me.CurrentTarget.Buffs.ContainsKey("Faerie Fire (Feral)"))
                    {
                        FaerieFireFeral();
                    }
                    else if (Me.ComboPoints > 0 &&
                        !Me.CurrentTarget.Buffs.ContainsKey("Rip"))
                    {
                        Rip();
                    }
                    else if (SpellManager.KnownSpells.ContainsKey("Rake") &&
                        !Me.CurrentTarget.Buffs.ContainsKey("Rake"))
                    {
                        Rake();
                    }
                    else if (SpellManager.KnownSpells.ContainsKey("Mangle (Cat)"))
                    {
                        SpellManager.CastSpell("Mangle (Cat)");
                        slog("Mangle (Cat).");
                    }
                    else
                    {
                        SpellManager.CastSpell("Claw");
                        slog("Claw.");
                    }
                }

            }
            #endregion
        }

        private void HuggyBear()
        {

            if (NeedHeal &&
                Me.ManaPercent > 30) // don't leave bear form if you can't get back in
            {
                Bash();
                Regrowth();
            }


            TakeForm();

            if (combatChecks())
            {
                Enrage();
            }

            if (combatChecks())
            {
                Maul();
            }

            if (combatChecks())
            {
                Warstomp();
            }

            if (combatChecks())
            {
                MangleBear();
            }

            if (Me.CurrentTarget.HealthPercent < 20 &&
                targetDistance > 15)
            {
                Moonfire();
            }

            if (!combatChecks())
            {
                return;
            }
        }

        private void SquishyNoob()
        {

            if (NeedHeal)
            {
                HealingTouch();
            }

            if (combatChecks() &&
                Me.ManaPercent > 30)
            {
                Moonfire();
            }

            if (combatChecks() &&
                Me.ManaPercent > 30)
            {
                Wrath();
            }

            if (combatChecks())
            {
                Warstomp();
            }

        }
        #endregion

        #region Spells

        private void Moonfire()
        {
            if (!Me.CurrentTarget.Buffs.ContainsKey("Moonfire"))
            {
                if (Me.GotTarget && SpellManager.CastSpell("Moonfire"))
                {
                    slog("Moonfire.");
                }

            }
        }

        private void Wrath()
        {
            if (Me.GotTarget && SpellManager.CastSpell("Wrath"))
            {
                WoWMovement.MoveStop();
                slog("Wrath.");
            }

            Thread.Sleep(200);

        }

        private void Starfire()
        {
            if (Me.GotTarget && SpellManager.CastSpell("Starfire"))
            {
                slog("Starfire.");
            }
        }

        private void HealingTouch()
        {
            if (SpellManager.CastSpell("Healing Touch"))
            {
                slog("Healing Touch.");
            }
        }

        private void Regrowth()
        {
            if (Me.Buffs.ContainsKey("Rejuvenation") &&
                Me.ManaPercent > 30)
            {
                HealingTouch();
            }

            if (Me.Buffs.ContainsKey("Regrowth"))
            {
                Rejuvenation();
            }
            if (SpellManager.CastSpell("Regrowth"))
            {
                slog("Regrowth.");
            }
        }

        private void Rejuvenation()
        {
            if (SpellManager.CastSpell("Rejuvenation"))
            {
                slog("Rejuvenation.");
            }
        }

        /// <summary>
        /// http://www.wowhead.com/?spell=22812
        /// The druid's skin becomes as tough as bark.  All damage taken is reduced by 20%.  While protected, damaging attacks will not cause spellcasting delays for 12 seconds.
        /// </summary>
        private void Barkskin()
        {
            if (SpellManager.CastSpell("Barkskin"))
            {
                slog("Barkskin.");
            }
        }

        /// <summary>
        /// http://www.wowhead.com/?spell=29166
        /// Causes the target to regenerate mana equal to 225% of the casting Druid's base mana pool over 10 sec.
        /// </summary>
        private void Innervate()
        {
            if (SpellManager.CastSpell("Innervate"))
            {
                slog("Innervate.");
            }
        }

        /// <summary>
        /// Renews MotW every 28 minutes or when it has been purged
        /// </summary>
        private void MarkOfTheWild()
        {
            if (markOfTheWildTimer.ElapsedMilliseconds > 27 * 60 * 1000)
            {
                if (SpellManager.CastSpell("Mark of the Wild"))
                {
                    slog("Refreshing Mark of the Wild.");
                    markOfTheWildTimer.Reset();
                    markOfTheWildTimer.Start();
                    return;
                }
            }

            if (SpellManager.KnownSpells.ContainsKey("Mark of the Wild") &&
                !Me.Buffs.ContainsKey("Mark of the Wild") &&
                !Me.Buffs.ContainsKey("Gift of the Wild"))
            {
                if (SpellManager.CastSpell("Mark of the Wild"))
                {
                    slog("Mark of the Wild");
                    markOfTheWildTimer.Reset();
                    markOfTheWildTimer.Start();
                }
            }
        }

        /// <summary>
        /// Renews Thorns every 8 minutes or when it has been purged.
        /// </summary>
        private void Thorns()
        {
            if (thornsTimer.ElapsedMilliseconds > 7 * 60 * 1000)
            {
                if (SpellManager.CastSpell("Thorns"))
                {
                    slog("Refreshing Thorns.");
                    thornsTimer.Reset();
                    thornsTimer.Start();
                    return;
                }
            }

            if (SpellManager.KnownSpells.ContainsKey("Thorns") &&
                        !Me.Buffs.ContainsKey("Thorns"))
            {
                if (SpellManager.CastSpell("Thorns"))
                {
                    slog("Thorns");
                    thornsTimer.Reset();
                    thornsTimer.Start();
                }
            }
        }

        private void Rip()
        {
            if (Me.Shapeshift != WoWUnit.ShapeshiftForm.Cat)
            {
                slog("Not in Cat Form.");
                return;
            }

            if (Me.CurrentTarget.Buffs.ContainsKey("Rip"))
            {
                return;
            }

            if (Me.GotTarget && SpellManager.CastSpell("Rip"))
            {
                slog("Rip.");
            }
        }

        private void FaerieFireFeral()
        {
            if (Me.Shapeshift != WoWUnit.ShapeshiftForm.Cat)
            {
                slog("Not in Cat Form.");
                return;
            }

            if (Me.CurrentTarget.Buffs.ContainsKey("Faerie Fire (Feral)"))
            {
                return;
            }

            if (Me.GotTarget && SpellManager.CastSpell("Faerie Fire (Feral)"))
            {
                slog("Faerie Fire (Feral).");
            }
        }


        private void Prowl()
        {
            if (Me.Shapeshift != WoWUnit.ShapeshiftForm.Cat)
            {
                slog("Not in Cat Form.");
                return;
            }

            if (Me.CurrentTarget.Buffs.ContainsKey("Prowl"))
            {
                return;
            }

            if (SpellManager.CastSpell("Prowl"))
            {
                slog("Prowl.");
            }
        }

        private void Pounce()
        {
            if (Me.Shapeshift != WoWUnit.ShapeshiftForm.Cat)
            {
                slog("Not in Cat Form.");
                return;
            }

            if (Me.GotTarget && SpellManager.CastSpell("Pounce"))
            {
                slog("Pounce.");
            }
        }

        private void Rake()
        {
            if (Me.Shapeshift != WoWUnit.ShapeshiftForm.Cat)
            {
                slog("Not in Cat Form.");
                return;
            }

            if (Me.GotTarget && SpellManager.CastSpell("Rake"))
            {
                slog("Rake.");
                rakeTimer.Reset();
                rakeTimer.Start();
            }
        }

        private void Bash()
        {
            if (Me.Shapeshift != WoWUnit.ShapeshiftForm.Bear)
            {
                slog("Not in Bear Form.");
                return;
            }

            if (Me.GotTarget && SpellManager.CastSpell("Bash"))
            {
                slog("Bash.");
            }
        }

        private void TigersFury()
        {
            if (Me.Shapeshift != WoWUnit.ShapeshiftForm.Cat)
            {
                slog("Not in Cat Form.");
                return;
            }

            if (Me.GetCurrentPower(WoWPowerType.Energy) > 50)
            {
                return;
            }

            if (SpellManager.CastSpell("Tiger's Fury"))
            {
                slog("Tiger's Fury.");
            }
        }

        private bool FerociousBite()
        {
            if (Me.Shapeshift != WoWUnit.ShapeshiftForm.Cat)
            {
                slog("Not in Cat Form.");
                return false;
            }

            if (Me.GotTarget && SpellManager.CastSpell("Ferocious Bite"))
            {
                slog("Ferocious Bite.");
                return true;
            }
            return false;
        }

        private bool Shred()
        {
            if (Me.Shapeshift != WoWUnit.ShapeshiftForm.Cat)
            {
                slog("Not in Cat Form.");
                return false;
            }

            if (Me.GotTarget && SpellManager.CastSpell("Shred"))
            {
                slog("Shred.");
                return true;
            }
            return false;
        }

        private bool Ravage()
        {
            if (Me.Shapeshift != WoWUnit.ShapeshiftForm.Cat)
            {
                slog("Not in Cat Form.");
                return false;
            }

            if (Me.GotTarget && SpellManager.CastSpell("Ravage"))
            {
                slog("Ravage.");
                return true;
            }
            return false;
        }
        private void MangleBear()
        {
            if (Me.Shapeshift != WoWUnit.ShapeshiftForm.Bear)
            {
                slog("Not in Bear Form.");
                return;
            }

            if (Me.GotTarget && SpellManager.CastSpell("Mangle (Bear)"))
            {
                slog("Mangle (Bear).");
            }
        }

        private void MangleCat()
        {
            if (Me.Shapeshift != WoWUnit.ShapeshiftForm.Cat)
            {
                slog("Not in Cat Form.");
                return;
            }

            if (SpellManager.KnownSpells.ContainsKey("Mangle (Cat)"))
            {
                SpellManager.CastSpell("Mangle (Cat)");
                slog("Mangle (Cat).");
            }
            else
            {
                SpellManager.CastSpell("Claw");
                slog("Claw.");
            }
        }

        private void Maul()
        {
            if (Me.Shapeshift != WoWUnit.ShapeshiftForm.Bear)
            {
                slog("Not in Bear Form.");
                return;
            }

            if (Me.GotTarget && SpellManager.CastSpell("Maul"))
            {
                slog("Maul.");
            }
        }

        private void Warstomp()
        {
            if (Me.CurrentTarget.IsCasting &&
                SpellManager.CastSpell("War Stomp"))
            {
                slog("Warstomp: BOOM!");
            }
        }

        private void Enrage()
        {
            if (Me.Shapeshift != WoWUnit.ShapeshiftForm.Bear)
            {
                slog("Not in Bear Form.");
                return;
            }
            if (Me.GotTarget && SpellManager.CastSpell("Enrage"))
            {
                slog("Enrage.");
            }
        }

        /// <summary>
        /// When activated, this ability causes your Mangle (Bear) ability to hit up to 3 targets 
        /// and have no cooldown, 
        /// and reduces the energy cost of all your Cat Form abilities by 50%.
        /// </summary>
        private void Berserk()
        {
            if (!SpellManager.KnownSpells.ContainsKey("Berserk"))
            {
                return;
            }

            if (Me.Shapeshift != WoWUnit.ShapeshiftForm.Bear &&
                Me.Shapeshift != WoWUnit.ShapeshiftForm.Cat)
            {
                slog("Not in Bear or Cat Form.");
                return;
            }
            if (Me.GotTarget && SpellManager.CastSpell("Berserk"))
            {
                slog("Berserk.");
            }
        }

        #endregion

        private List<WoWUnit> getAdds()
        {
            List<WoWUnit> mobList = ObjectManager.GetObjectsOfType<WoWUnit>(false);
            List<WoWUnit> enemyMobList = new List<WoWUnit>();

            foreach (WoWUnit thing in mobList)
            {
                try
                {
                    if ((thing.Guid != Me.Guid) &&
                    thing.IsTargetingMe)
                    {
                        enemyMobList.Add(thing);
                    }
                }
                catch (Exception ex)
                {
                    Logging.WriteException(ex);
                    slog("Add error.");
                }
            }

            if (enemyMobList.Count > 1)
            {
                slog("Warning: there are " + enemyMobList.Count.ToString() + " attackers.");
            }
            return enemyMobList;

        }


           private bool combatChecks()
        {
            if (!Me.GotTarget && !Me.CurrentTarget.IsValid)
            {
                return false;
            }

            if (Me.Dead)
            {
                slog("I died.");
                return false;
            }

            if (targetDistance > 50)
            {
                slog("Out of range: " + Me.CurrentTarget.Name + " is " + System.Math.Round(targetDistance).ToString() + " yards away.");
                Me.ClearTarget();
                return false;
            }

            WoWMovement.Face();

            double meleeRange = 4;

            if (!SpellManager.KnownSpells.ContainsKey("Bear Form") &&
                !SpellManager.KnownSpells.ContainsKey("Dire Bear Form"))
            {
                meleeRange = 28;
            }

            if (targetDistance > meleeRange)
            {
                slog(Me.CurrentTarget.Name + " is at " + System.Math.Round(targetDistance).ToString() + " yards.");
                int approachSeconds = 0;

                // get within range
                Logging.Write("Get into {0} range. ", meleeRange.ToString());
                while (approachSeconds < 10 &&
                     targetDistance > meleeRange &&
                     targetDistance < 50)
                {
                    if (!movementTimer.IsRunning ||
                            movementTimer.ElapsedMilliseconds > 1000)
                    {
                        pointNow = WoWMovement.CalculatePointFrom(Me.CurrentTarget.Location, 1f);
                        movementTimer.Reset();
                        movementTimer.Start();
                    }

                    WoWPoint myPoint = ObjectManager.Me.Location;
                    myPoint.Z += 2.5f;
                    pointNow.Z += 2.5f;

                    if (WorldManager.IsInLineOfSight(myPoint, pointNow))
                    {
                        slog("Move to target.");
                        WoWMovement.ClickToMove(pointNow);
                        Thread.Sleep(500);
                    }
                    else
                    {
                        slog("Navigate to target.");
                        Navigator.MoveTo(pointNow);
                    }

                    Thread.Sleep(350);

                    ++approachSeconds;
                }

                WoWMovement.MoveStop();
            }

            return true;
        }

        #endregion

        #region PVP
        private static bool isAlliance = false;
        private static bool isHorde = false;
        private static SearchParams p = new SearchParams
        {
            Alliance = isAlliance,
            Horde = isHorde,
            LineOfSight = true,
            Dead = false,
            Player = true,
            ObjectType = 4,
            SortByDistance = ObjSearchSort.Descending,
        };

        List<WoWPlayer> healTargets = new ObjectList<WoWPlayer>(p);

        private WoWPlayer chooseHealTarget()
        {
            for (int a = healTargets.Count - 1; a >= 0; --a)
            {
                if (healTargets[a].Distance > 25 ||
                    healTargets[a].HealthPercent > 90)
                {
                    healTargets.RemoveAt(a);
                }
                else
                {
                    return healTargets[a];
                }
            }

            return null;
        }

        #endregion

        #region movement logic
        WoWPoint attackPoint
        {
            get
            {
                if (Me.GotTarget)
                {
                    return Me.CurrentTarget.Location;
                    //return WoWMovement.CalculatePointFrom(Me.CurrentTarget.Location, 3.5f);
                }
                else
                {
                    WoWPoint noSpot = new WoWPoint();
                    return noSpot;
                }
            }
        }
        WoWPath pathExists = new WoWPath(ObjectManager.Me.Location, ObjectManager.Me.Location);
        private static bool UseNavigator;
        private WoWUnit _lastTarget;
        private WoWPoint _dest = WoWPoint.Invalid;
        private WoWPoint GetTraceLinePos()
        {
            return new WoWPoint(Me.X, Me.Y, Me.Z + 2.132f);
        }
        private static ulong lastPullGuid;
        private static Stopwatch movementTimer = new Stopwatch();
        private static uint movementDuration;

        //private void MoveToTarget()
        //{
        //    try
        //    {
        //        pathExists = Navigator.GeneratePath(ObjectManager.Me.Location, attackPoint, false, true);
        //    }
        //    catch (Exception ex)
        //    {
        //        Logging.WriteException(ex);
        //    }

        //    if (Me.CurrentTarget.Guid != lastPullGuid)
        //    {
        //        UseNavigator = false;
        //        lastPullGuid = Me.CurrentTarget.Guid;
        //    }

        //    if (WorldManager.IsInLineOfSight(GetTraceLinePos(), attackPoint + new WoWPoint(0, 0, 2.132f)) &&
        //        !UseNavigator)
        //    {
        //        WoWMovement.ClickToMove(attackPoint);
        //        Thread.Sleep(150);
        //        if (StuckDetector.IsStuck)
        //        {
        //            UseNavigator = true;
        //        }
        //    }
        //    else
        //    {
        //        if (_lastTarget == null)
        //            _lastTarget = Me.CurrentTarget;

        //        if (_lastTarget != null)
        //        {
        //            if (Me.CurrentTarget == _lastTarget)
        //            {
        //                if (!_dest.IsValid)
        //                    _dest = attackPoint;

        //                Navigator.MoveTo(_dest);
        //            }
        //            else
        //            {
        //                _lastTarget = null;
        //                _dest = WoWPoint.Invalid;
        //            }
        //        }
        //    }
        //}
        #endregion

        #region horde racials

        // Berserking
        void Berserking()
        {
            if (ObjectManager.Me.Race == WoWRace.Troll &&
                SpellManager.CastSpell("Berserking"))
            {
                Styx.Helpers.Logging.Write("Berserking.");
            }
        }

        // Bloodrage
        void Bloodrage()
        {
            if (ObjectManager.Me.Race == WoWRace.Orc &&
                SpellManager.CastSpell("Bloodrage"))
            {
                Styx.Helpers.Logging.Write("Bloodrage.");
            }
        }

        // War Stomp
        void WarStomp()
        {
            if (ObjectManager.Me.Race == WoWRace.Tauren &&
                SpellManager.CastSpell("War Stomp"))
            {
                Styx.Helpers.Logging.Write("War Stomp.");
            }
        }

        // Arcane Torrent
        void ArcaneTorrent()
        {
            if (ObjectManager.Me.Race == WoWRace.BloodElf &&
                SpellManager.CastSpell("Arcane Torrent"))
            {
                Styx.Helpers.Logging.Write("Arcane Torrent.");
            }
        }

        // Will of the Forsaken 
        void WillOfTheForsaken()
        {
            if (ObjectManager.Me.Race == WoWRace.Undead &&
                SpellManager.CastSpell("Will of the Forsaken"))
            {
                Styx.Helpers.Logging.Write("Will of the Forsaken.");
            }
        }
        #endregion

        #region alliance racials

        // Stoneform
        void Stoneform()
        {
            if (ObjectManager.Me.Race == WoWRace.Dwarf &&
                SpellManager.CastSpell("Stoneform"))
            {
                Styx.Helpers.Logging.Write("Stoneform.");
            }
        }

        // Gift of the Naaru
        void GiftOfTheNaaru()
        {
            if (ObjectManager.Me.Race == WoWRace.Draenei &&
                SpellManager.CastSpell("Gift of the Naaru"))
            {
                Styx.Helpers.Logging.Write("Gift of the Naaru.");
            }
        }

        // Every Man for Himself
        void EveryManForHimself()
        {
            if (ObjectManager.Me.Race == WoWRace.Human &&
                SpellManager.CastSpell("Every Man for Himself"))
            {
                Styx.Helpers.Logging.Write("Every Man for Himself.");
            }
        }

        // Shadowmeld
        void Shadowmeld()
        {
            if (ObjectManager.Me.Race == WoWRace.NightElf &&
                SpellManager.CastSpell("Shadowmeld"))
            {
                Styx.Helpers.Logging.Write("Shadowmeld.");
            }
        }

        // Escape Artist
        void EscapeArtist()
        {
            if (ObjectManager.Me.Race == WoWRace.Gnome &&
                SpellManager.CastSpell("Escape Artist"))
            {
                Styx.Helpers.Logging.Write("Escape Artist.");
            }
        }


        #endregion

        #region flowers

        private WoWGameObject prettyFlower = new WoWGameObject(0);

        private void harvestFlower(WoWGameObject flower)
        {
            Stopwatch harvestTimer = new Stopwatch();
            if (flower.IsValid &&
                walkToFlower(flower))
            {

                Thread.Sleep(3500);
                if (Me.Combat)
                {
                    return;
                }
                else
                {
                    WoWMovement.MoveStop();
                    flower.Interact();
                    harvestTimer.Start();
                    Thread.Sleep(1000);
                    while (harvestTimer.ElapsedMilliseconds < 3500 &&
                        !Me.Combat &&
                        Me.IsCasting)
                    {
                        Thread.Sleep(251);
                    }

                    if (!Me.Combat)
                    {
                        Blacklist.Add(flower.Guid, TimeSpan.FromMinutes(15));
                        slog("Flower picked.");
                        prettyFlower = null;
                    }
                    else
                    {
                        return;
                    }
                }

            }
        }

        private bool walkToFlower(WoWGameObject flower)
        {
            Stopwatch walkTimer = new Stopwatch();
            if (flower.Location.IsValid)
            {
                walkTimer.Start();

                while (!Me.Combat &&
                    flower.Distance > 5 &&
                    walkTimer.ElapsedMilliseconds < 30 * 1000)
                {
                    Navigator.MoveTo(flower.Location);
                }

                if (flower.Distance < 7)
                {
                    return true;
                }
                else
                {
                    Blacklist.Add(flower.Guid, TimeSpan.FromMinutes(15));
                    return false;
                }
            }
            return false;
        }

        private WoWGameObject localFlower()
        {
            foreach (WoWObject obj in ObjectManager.ObjectList)
            {
                if (SpellManager.KnownSpells.ContainsKey("Find Herbs") &&
                    obj is WoWGameObject &&
                    !Blacklist.Contains(obj.Guid) &&
                    _herbs.ContainsKey(obj.Entry) &&
                    obj.Distance < 70)
                {
                    return obj.ToGameObject();
                }
            }

            return null;
        }

        private readonly Dictionary<uint, string> _herbs = new Dictionary<uint, string>()
        {
            {1, "example"},
        };

        #endregion

    }
}
#pragma warning restore