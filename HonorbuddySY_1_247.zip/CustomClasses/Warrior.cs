﻿/* likWarrior v0.5.5
 * by likwid818
 * * v0.5.5 * Changelog
 * -----------------------------
 * Added ability to condense Crystallized elements into Eternals.  Off by default. (Credit to TIA for example code)
 * Tweaked the logic of some abilities (bladestorm, bloodrage, berserker rage)
 * Tweaked timings on many abilities
 * Fixed Sudden Death by using a workaround for the bug in HB (Credit to Bobby53 for the workaround)
 * Fixed a huge bug preventing skills from being used in Berserker Stance if certain talents were
 *  not already learned.  (Credit to Retsalk for bug report)
 *  
 *   
 * To-Do:
 * Still Better Targeting Logic
 * Fix Fear logic
 * Add Heroic Throw Logic to ranged pulls
 * PVP!
*/


namespace Styx.Bot.CustomClasses
{
    using Helpers;
    using Logic.Pathing;
    using System;
    using System.Diagnostics;
    using System.Threading;
    using System.Collections.Generic;
    using Logic.Common.Combat;
    using Object_Dumping_Enumeration;
    using CustomCombat.CombatInterface;
    using Memory_Read_Write_Inject.Lua;
    using Styx.Object_Dumping_Enumeration.WoWObjects;

    public class Warrior : ICombat
    {
        public WoWClass Class { get { return WoWClass.Warrior; } }
        public string Name { get { return "likWarrior v0.5.5"; } }

        #region Private Members

        private void Slog(string msg)
        {
            if (msg == _logspam)
            {
                return;
            }

            Logging.Write(msg);
            _logspam = msg;
        }

        #endregion

        #region Global Variables

        private readonly LocalPlayer _me = ObjectManager.Me;
        private Object_Dumping_Enumeration.WoWObjects.WoWUnit target = new Styx.Object_Dumping_Enumeration.WoWObjects.WoWUnit(3);
        private string _logspam;


        //      !!! USER DEFINED VARIABLES - All your settings here !!!!
        private int _healHP = 45;                           // Start Self-Healing logic at 45%.
        private int _restHP = 35;                           // Rest at 51% HP.  (Res at 50%)
        private int _rageDumpVal = 35;                      // When to use rage dump (Heroic Strike) in Zerker stance.
        private int _addNumToFear = 2;                      // How many adds to have on us before we fear.
        private int _hamstringPct = 30;                     // % of HP to Hamstring at if _useHamstring = true.
        private bool _useDemoShout = true;                  // Use Demoralizing Shout?
        private bool _useBattleShout = true;                // Use Battle Shout?
        private bool _useCommShout = true;                  // Use Commanding Shout?
        private bool _useThunderClap = true;                // Use Thunder Clap?
        private bool _useRend = true;                       // Use Rend?
        private bool _useBloodrage = true;                  // Use Bloodrage?
        private bool _useHamstring = false;                 // Use Hamstring?
        private bool _useRangedPull = false;                // Use Ranged Pulling?
        private bool _usePVEFear = true;                    // Use Intimidating Shout on adds
        private bool _usePotion = true;                     // Try to use a potion first before Last Stand/Enraged Regen
        private bool _useWarbringer = true;                 // Use Warbringer if we are Prot? ** This setting doesnt really apply atm **
        private bool _useSuddenDeath = true;                // Use Sudden Death in Arms? ** NOT WORKING **
        private bool _useBladestorm = true;                 // Use Bladestorm in Arms?
        private bool _condenseEternals = true;              // Make Crystallized into Eternal?
        //      !!! END USER DEFINED VARIABLES - DO NOT MODIFY ANYTHING BELOW THIS LINE.  !!!

        // Potion EntryId's taken from WoWHead
        private List<uint> _potionEID = new List<uint>()
        {
            43569, 43531, 32947, 18839, 33934, 4596, 1710,
            929, 23822, 33092, 858, 31852, 31853, 31839,
            31838, 13446, 118, 39671, 33447, 22829, 3928,
            28100,
        };

        List<WoWUnit> _addsList = new List<WoWUnit>();

        private bool _fearAdds;                             // Internal Variable ** DO NOT CHANGE **



        #endregion

        #region Rest

        public bool NeedRest { get { return _me.GetPowerPercent(WoWPowerType.Health) <= _restHP; } }
        public void Rest()
        {
            if (!_me.Buffs.ContainsKey("Food"))
                Logic.Common.Rest.Feed();
        }

        #endregion

        #region Pull

        public void Pull()
        {
            if (_me.Mounted)
            {
                Logic.Mount.Dismount();
                while (_me.Mounted)
                    Thread.Sleep(50);
                if (NeedRest)
                    Rest();
            }

            if (_condenseEternals)
                CheckEternals();

            if (_me.CurrentTarget.IsValid && !_me.CurrentTarget.Elite && (!_me.CurrentTarget.Tagged))
            {
                if (_me.IsMoving)
                {
                    WoWMovement.MoveStop();
                }

                Logging.Write("[ " + Name + " ]: Pulling: {0}", _me.CurrentTarget.Name);

                if (_useRangedPull &&
                    _me.Shapeshift == Object_Dumping_Enumeration.WoWObjects.WoWUnit.ShapeshiftForm.DefensiveStance &&
                    SpellManager.KnownSpells.ContainsKey("Taunt"))
                    Taunt();

                if ((_useRangedPull && _me.CurrentTarget.Distance >= 5 &&
                    _me.CurrentTarget.Distance <= 29 &&
                    _me.Shapeshift == Object_Dumping_Enumeration.WoWObjects.WoWUnit.ShapeshiftForm.BattleStance) ||
                    (_useRangedPull && _me.CurrentTarget.Distance >= 5 &&
                    _me.CurrentTarget.Distance <= 29 &&
                    _me.Shapeshift == Object_Dumping_Enumeration.WoWObjects.WoWUnit.ShapeshiftForm.BerserkerStance))
                {
                    Logging.Write("Trying Ranged pull...");
                    if (_me.IsMoving)
                    {
                        WoWMovement.MoveStop();
                        Thread.Sleep(300);
                    }
                    //if (HeroicThrow())
                    //    Slog("[ " + Name + " ]: Heroic Throw!");
                    Shoot();
                    Throw();
                    Thread.Sleep(2200);
                }

                if (!_me.IsAutoAttacking && _me.GotTarget)
                {
                    DistanceCheck();
                    Lua.DoString("StartAttack()");
                }

                Stopwatch pullTimer = new Stopwatch();
                pullTimer.Start();
                WoWMovement.Face();

                //Slog("Killing " + _me.CurrentTarget.Name + " at distance " + Math.Floor(_me.CurrentTarget.Distance));


                while (_me.CurrentTarget.Distance >= 5.0f)
                {
                    if (pullTimer.ElapsedMilliseconds > 20 * 1000)
                    {
                        TimeSpan duration = new TimeSpan(0, 3, 0);
                        Logic.Blacklist.Add(_me.CurrentTarget, duration);

                        WoWMovement.MoveStop();

                        if (_me.GotTarget)
                            _me.ClearTarget();

                        return;
                    }

                    WoWPoint newPoint = WoWMovement.CalculatePointFrom(_me.CurrentTarget.Location, 2.0f);

                    WoWMovement.ClickToMove(newPoint);
                    Thread.Sleep(100);

                    if (_me.Shapeshift == Object_Dumping_Enumeration.WoWObjects.WoWUnit.ShapeshiftForm.BattleStance ||
                        (_me.Shapeshift == Object_Dumping_Enumeration.WoWObjects.WoWUnit.ShapeshiftForm.DefensiveStance &&
                        _useWarbringer))
                    {
                        if (Charge())
                        {
                            Logging.Write("[ " + Name + " ]: Charging at {0}", _me.CurrentTarget.Name);
                            Thread.Sleep(300);
                            if (Rend())
                                Slog("[ " + Name + " ]: Rend!");
                        }
                    }

                    else
                        if (!_me.IsAutoAttacking && _me.GotTarget)
                        {
                            DistanceCheck();
                            Lua.DoString("StartAttack()");
                        }
                }
            }
        }

        #endregion

        #region Pull Buffs

        public bool NeedPullBuffs { get { return false; } }

        public void PullBuff() { }

        #endregion

        #region Pre Combat Buffs

        public bool NeedPreCombatBuffs { get { return false;/*!_me.Buffs.ContainsKey("Battle Stance");*/ } }

        public void PreCombatBuff()
        {
            return;
        }

        #endregion

        #region Combat Buffs

        public bool NeedCombatBuffs { get { return false; } }

        public void CombatBuff()
        {
            if (_me.CurrentTarget.HealthPercent > 50 && _me.HealthPercent <= 35 && _me.Race == WoWRace.Dwarf)
                Stoneform();

            if (_me.CurrentTarget.HealthPercent >= 60 && _me.HealthPercent <= 40 && _me.Race == WoWRace.Troll)
                Berserking();

            if (_me.CurrentTarget.HealthPercent > 50 && _me.HealthPercent <= 80 && _me.Race == WoWRace.Orc)
                BloodFury();
        }

        #endregion

        #region Heal

        public bool NeedHeal { get { return _me.GetPowerPercent(WoWPowerType.Health) <= _healHP; } }

        public void Heal()
        {
            if (_usePotion)
                DrinkPotion();

            if (_me.HealthPercent <= _healHP)
            {
                Logging.Write("[ " + Name + " ]: !!! HP STILL LOW! *{0}%* Last Stand/Enraged Regen! !!!", _me.HealthPercent);
                if (SpellManager.KnownSpells.ContainsKey("Last Stand") && _me.Shapeshift == Object_Dumping_Enumeration.WoWObjects.WoWUnit.ShapeshiftForm.DefensiveStance)
                {
                    LastStand();
                    Thread.Sleep(500);
                }
            }

            if (_me.HealthPercent <= _healHP)
            {
                Logging.Write("[ " + Name + " ]: !!! HP STILL LOW! *{0}%* Last Stand/Enraged Regen! !!!", _me.HealthPercent);
                if (SpellManager.KnownSpells.ContainsKey("Enraged Regeneration"))
                    EnragedRegeneration();
            }
        }

        #endregion

        #region Falling

        public void HandleFalling() { }

        #endregion

        #region Combat

        public void Combat()
        {
            if (_me.CurrentTarget.IsValid)
            {
                if (_me.IsMoving)
                    WoWMovement.MoveStop();

                DistanceCheck();
                WoWMovement.Face();

                if (_me.GetCurrentPower(WoWPowerType.Rage) <= 25 && _me.CurrentTarget.HealthPercent > 70 && _me.HealthPercent > 60)
                    Bloodrage();


                if (!_me.IsAutoAttacking && _me.GotTarget)
                {
                    if (!_me.CurrentTarget.Dead)
                    {
                        DistanceCheck();
                        Logging.Write("AutoAttack:{0}", _me.IsAutoAttacking);
                        Lua.DoString("StartAttack()");
                    }
                }

                if (_me.Shapeshift == Object_Dumping_Enumeration.WoWObjects.WoWUnit.ShapeshiftForm.BerserkerStance)
                    BerserkerCombat();

                if (_me.Shapeshift == Object_Dumping_Enumeration.WoWObjects.WoWUnit.ShapeshiftForm.DefensiveStance)
                    DefensiveCombat();

                if (_me.Shapeshift == Object_Dumping_Enumeration.WoWObjects.WoWUnit.ShapeshiftForm.BattleStance)
                    BattleCombat();

                if (NeedHeal)
                    Heal();

                DistanceCheck();

                if (!_me.IsAutoAttacking && _me.GotTarget)
                {
                    if (!_me.CurrentTarget.Dead)
                    {
                        DistanceCheck();
                        Logging.Write("AutoAttack:{0}", _me.IsAutoAttacking);
                        Lua.DoString("StartAttack()");
                    }
                }
            }
        }

        #endregion

        #region Spells

        #region Offensive Spells

        /// <summary>
        /// http://www.wowhead.com/?spell=5308
        /// Attempt to finish off a wounded foe.  Only usable on enemies that have less than 20% health.
        /// </summary>
        void Execute()
        {
            DistanceCheck();
            if (_me.Shapeshift == Object_Dumping_Enumeration.WoWObjects.WoWUnit.ShapeshiftForm.BattleStance ||
                _me.Shapeshift == Object_Dumping_Enumeration.WoWObjects.WoWUnit.ShapeshiftForm.BerserkerStance)
            {
                if (SpellManager.KnownSpells.ContainsKey("Execute"))
                {
                    WoWSpell execute = SpellManager.KnownSpells["Execute"];
                    if (!execute.Cooldown && _me.GetCurrentPower(WoWPowerType.Rage) >= 15)
                    {
                        SpellManager.CastSpellById(execute.Id);
                        Logging.Write("[ " + Name + " ]: Mob at {0}% HP, Executing!", _me.CurrentTarget.HealthPercent);
                        Thread.Sleep(1500);
                    }
                }
            }
        }

        /// <summary>
        /// Check's if Overpower is usable and if it is it casts it
        /// </summary>
        private bool Overpower()
        {
            DistanceCheck();
            if (SpellManager.KnownSpells.ContainsKey("Overpower") && _me.Shapeshift == Object_Dumping_Enumeration.WoWObjects.WoWUnit.ShapeshiftForm.BattleStance)
            {
                WoWSpell overpower = SpellManager.KnownSpells["Overpower"];
                /*
                if (!overpower.Cooldown && _me.GetCurrentPower(WoWPowerType.Rage) >= 5)
                {
                    SpellManager.CastSpellById(overpower.Id);
                    Thread.Sleep(1500);
                    return true;
                }
                */
                var isUsable = Lua.LuaGetReturnValue("return IsUsableSpell('Overpower')", "hax.lua");
                if (isUsable != null)
                {
                    if (isUsable[0] == "1")
                    {
                        SpellManager.CastSpellById(overpower.Id);
                        Thread.Sleep(1500);
                        return true;
                    }
                }
            }
            return false;
        }

        /// <summary>
        /// http://www.wowhead.com/?spell=100
        /// Charge an _enemy, generating rage, and stun it for 1.50 sec.  Cannot be used in combat.        
        /// </summary>
        bool Charge()
        {
            if (!_me.Combat)
            {
                if (SpellManager.KnownSpells.ContainsKey("Charge"))
                {
                    if (_me.CurrentTarget.Distance >= 8 && _me.CurrentTarget.Distance <= 23 && SpellManager.CanCastSpell("Charge"))
                    {
                        return SpellManager.CastSpell("Charge");
                    }
                }
                Slog("[ " + Name + " ]: Can't Charge!");
                return false;
            }
            return false;
        }

        /// <summary>
        /// http://www.wowhead.com/?spell=78
        /// A strong attack that increases melee damage by 11 and causes a high amount of threat.        
        /// Rage cost reduces with talents
        /// </summary>
        private bool HeroicStrike()
        {
            DistanceCheck();
            if (Overpower())
            {
                Slog("[ " + Name + " ]: Overpower!");
                Thread.Sleep(1500);
            }

            if (SpellManager.KnownSpells.ContainsKey("Heroic Strike") && !_me.CurrentTarget.Dead)
            {
                WoWSpell hs = SpellManager.KnownSpells["Heroic Strike"];
                if (!hs.Cooldown && _me.GetCurrentPower(WoWPowerType.Rage) > 15)
                {
                    SpellManager.CastSpellById(hs.Id);
                    Thread.Sleep(1500);
                    return true;
                }
            }

            Logging.Write("[ " + Name + " ]: Can't cast Heroic Strike!");
            return false;
        }

        /// <summary>
        /// http://www.wowhead.com/?spell=772
        /// Wounds the target causing immediate damage and them to bleed over 15 sec.
        /// </summary>
        private bool Rend()
        {
            DistanceCheck();
            if (Overpower())
            {
                Slog("[ " + Name + " ]: Overpower!");
                Thread.Sleep(1500);
            }

            if (_useRend)
            {
                if (!_me.CurrentTarget.Buffs.ContainsKey("Rend"))
                {
                    if (SpellManager.CanCastSpell("Rend") && _me.CurrentTarget.HealthPercent >= 45)
                    {
                        return SpellManager.CastSpell("Rend");
                    }
                }
            }
            return false;
        }

        /// <summary>
        /// http://www.wowhead.com/?spell=2687
        /// Generates 20 rage at the cost of health, and then generates an additional 10 rage over 10 sec.
        /// </summary>
        void Bloodrage()
        {
            if (Overpower())
            {
                Slog("[ " + Name + " ]: Overpower!");
                Thread.Sleep(1500);
            }

            if (_useBloodrage && SpellManager.KnownSpells.ContainsKey("Bloodrage"))
            {
                WoWSpell bloodrage = SpellManager.KnownSpells["Bloodrage"];
                if (!bloodrage.Cooldown)
                {
                    SpellManager.CastSpellById(bloodrage.Id);
                    Slog("[ " + Name + " ]: Bloodrage!");
                }
            }
        }

        /// <summary>
        /// http://www.wowhead.com/?spell=845
        /// A sweeping attack that does your weapon damage plus 15 to the target and his nearest ally.
        /// </summary>
        void Cleave()
        {
            DistanceCheck();
            if (SpellManager.KnownSpells.ContainsKey("Cleave"))
            {
                if (SpellManager.CanCastSpell("Cleave"))
                {
                    SpellManager.CastSpell("Cleave");
                    Slog("[ " + Name + " ]: Cleave!");
                }
            }
        }

        /// <summary>
        /// http://www.wowhead.com/?spell=20230
        /// Instantly counterattack any _enemy that strikes you in melee for 12 sec.  Melee attacks made from behind cannot be counterattacked.  A maximum of 20 attacks will cause retaliation.
        /// </summary>
        private bool Retaliation()
        {
            DistanceCheck();
            if (_me.Shapeshift == Object_Dumping_Enumeration.WoWObjects.WoWUnit.ShapeshiftForm.BattleStance && SpellManager.KnownSpells.ContainsKey("Retaliaion"))
            {
                WoWSpell retaliation = SpellManager.KnownSpells["Retaliation"];
                if (!retaliation.Cooldown)
                {
                    SpellManager.CastSpellById(retaliation.Id);
                    Thread.Sleep(1500);
                    return true;
                }
            }
            return false;
        }

        private bool Bloodthirst()
        {
            if (SpellManager.KnownSpells.ContainsKey("Bloodthirst"))  //Bug here reported by Retsalk
            {
                DistanceCheck();
                WoWSpell bloodthirst = SpellManager.KnownSpells["Bloodthirst"];
                if (!bloodthirst.Cooldown && _me.GetCurrentPower(WoWPowerType.Rage) >= 20)
                {
                    SpellManager.CastSpellById(bloodthirst.Id);
                    Thread.Sleep(1500);
                    return true;
                }
            }
            return false;
        }

        private bool Whirlwind()
        {
            DistanceCheck();
            /*
            if (SpellManager.KnownSpells.ContainsKey("Whirlwind") &&
                SpellManager.CanCastSpell("Whirlwind"))
            {
                return SpellManager.CastSpell("Whirlwind");
            }
            return false;
            */
            if (SpellManager.KnownSpells.ContainsKey("Whirlwind"))
            {
                if (!_me.CurrentTarget.Dead)
                {
                    WoWSpell whirlwind = SpellManager.KnownSpells["Whirlwind"];
                    if (!whirlwind.Cooldown && _me.GetCurrentPower(WoWPowerType.Rage) >= 25)
                    {
                        SpellManager.CastSpellById(whirlwind.Id);
                        Thread.Sleep(1500);
                        return true;
                    }
                }
            }
            return false;
        }

        private bool BerserkerRage()
        {
            //DistanceCheck();
            //if (SpellManager.KnownSpells.ContainsKey("Berserker Rage") &&
            //    SpellManager.CanCastSpell("Berserker Rage"))
            //{
            //    return SpellManager.CastSpell("Berserker Rage");
            //}
            if (SpellManager.KnownSpells.ContainsKey("Berserker Rage"))
            {
                if (!_me.CurrentTarget.Dead)
                {
                    WoWSpell zerkrage = SpellManager.KnownSpells["Berserker Rage"];
                    if (!zerkrage.Cooldown)
                    {
                        SpellManager.CastSpellById(zerkrage.Id);
                        Thread.Sleep(500);
                        return true;
                    }
                }
            }
            return false;
        }

        private bool Recklessness()
        {
            if (SpellManager.KnownSpells.ContainsKey("Recklessness") &&
                SpellManager.CanCastSpell("Recklessness"))
            {
                return SpellManager.CastSpell("Recklessness");
            }
            return false;
        }

        private bool MortalStrike()
        {
            DistanceCheck();
            if (SpellManager.KnownSpells.ContainsKey("Mortal Strike") &&
                SpellManager.CanCastSpell("Mortal Strike"))
            {
                return SpellManager.CastSpell("Mortal Strike");
            }
            return false;
        }

        private void SunderArmor()
        {
            DistanceCheck();
            if (SpellManager.KnownSpells.ContainsKey("Sunder Armor"))
            {
                WoWSpell sunder = SpellManager.KnownSpells["Sunder Armor"];
                if (!sunder.Cooldown && _me.GetCurrentPower(WoWPowerType.Rage) >= 15)
                {
                    SpellManager.CastSpellById(sunder.Id);
                    Thread.Sleep(1500);
                }
            }
        }

        private bool Revenge()
        {
            DistanceCheck();
            if (SpellManager.KnownSpells.ContainsKey("Revenge"))
            {
                WoWSpell revenge = SpellManager.KnownSpells["Revenge"];
                if (!revenge.Cooldown)
                {
                    SpellManager.CastSpellById(revenge.Id);
                    Thread.Sleep(1500);
                    return true;
                }
            }
            return false;
        }

        private bool Shockwave()
        {
            DistanceCheck();
            if (SpellManager.KnownSpells.ContainsKey("Shockwave") &&
                SpellManager.CanCastSpell("Shockwave"))
            {
                WoWMovement.Move(WoWMovement.MovementDirection.Backward);
                Thread.Sleep(300);
                WoWMovement.MoveStop();
                return SpellManager.CastSpell("Shockwave");
            }
            return false;
        }

        private bool DeathWish()
        {
            if (SpellManager.KnownSpells.ContainsKey("Death Wish"))
            {
                WoWSpell dw = SpellManager.KnownSpells["Death Wish"];
                if (!dw.Cooldown && _me.GetCurrentPower(WoWPowerType.Rage) >= 10)
                {
                    SpellManager.CastSpellById(dw.Id);
                    Thread.Sleep(1500);
                    return true;
                }
            }
            return false;
        }

        private bool ShieldSlam()
        {
            DistanceCheck();
            if (SpellManager.KnownSpells.ContainsKey("Shield Slam"))
            {
                WoWSpell shieldslam = SpellManager.KnownSpells["Shield Slam"];
                if (!shieldslam.Cooldown && _me.GetCurrentPower(WoWPowerType.Rage) >= 20)
                {
                    SpellManager.CastSpellById(shieldslam.Id);
                    Thread.Sleep(1500);
                    return true;
                }
            }
            return false;
        }

        private bool Slam()
        {
            DistanceCheck();
            if (SpellManager.KnownSpells.ContainsKey("Slam"))
            {
                if (_me.Buffs.ContainsKey("Slam!"))
                {
                    WoWSpell slam = SpellManager.KnownSpells["Slam"];
                    if (!slam.Cooldown && _me.GetCurrentPower(WoWPowerType.Rage) >= 15)
                    {
                        SpellManager.CastSpellById(slam.Id);
                        Thread.Sleep(1500);
                        return true;
                    }
                }
            }
            return false;
        }

        private void Shoot()
        {
            if (SpellManager.KnownSpells.ContainsKey("Shoot"))
            {
                WoWSpell shoot = SpellManager.KnownSpells["Shoot"];
                if (!shoot.Cooldown)
                {
                    SpellManager.CastSpellById(shoot.Id);
                    //Thread.Sleep(2200);
                }
            }
        }

        private void Throw()
        {
            if (SpellManager.KnownSpells.ContainsKey("Throw"))
            {
                WoWSpell wthrow = SpellManager.KnownSpells["Throw"];
                if (!wthrow.Cooldown)
                {
                    SpellManager.CastSpellById(wthrow.Id);
                    //Thread.Sleep(2200);
                }
            }
        }

        private bool Devastate()
        {
            if (SpellManager.KnownSpells.ContainsKey("Devastate"))
            {
                WoWSpell devastate = SpellManager.KnownSpells["Devastate"];
                if (!devastate.Cooldown && _me.GetCurrentPower(WoWPowerType.Rage) >= 15)
                {
                    SpellManager.CastSpellById(devastate.Id);
                    Thread.Sleep(1500);
                    return true;
                }
            }
            return false;
        }

        private bool VictoryRush()
        {
            if (SpellManager.KnownSpells.ContainsKey("Victory Rush"))
            {
                WoWSpell vr = SpellManager.KnownSpells["Victory Rush"];
                //if (vr.Cooldown && SpellManager.CanCastSpell("Victory Rush"))
                //{
                //    SpellManager.CastSpellById(vr.Id);                            <===  doesn't work for some reason?
                //    Thread.Sleep(1200);
                //    return true;
                //}
                var isUsable = Lua.LuaGetReturnValue("return IsUsableSpell('Victory Rush')", "hax.lua");
                if (isUsable != null)
                {
                    if (isUsable[0] == "1")
                    {
                        SpellManager.CastSpellById(vr.Id);
                        Thread.Sleep(1500);
                        return true;
                    }
                }
            }
            return false;
        }

        private bool Intercept()
        {
            if (SpellManager.KnownSpells.ContainsKey("Intercept"))
            {
                WoWSpell intercept = SpellManager.KnownSpells["Intercept"];
                if (!intercept.Cooldown && _me.GetCurrentPower(WoWPowerType.Rage) >= 10)
                {
                    SpellManager.CastSpellById(intercept.Id);
                    Thread.Sleep(1300);
                    return true;
                }
            }
            return false;
        }

        private void Taunt()
        {
            if (SpellManager.KnownSpells.ContainsKey("Taunt"))
            {
                WoWSpell taunt = SpellManager.KnownSpells["Taunt"];
                if (!taunt.Cooldown)
                {
                    SpellManager.CastSpellById(taunt.Id);
                    Thread.Sleep(3000);
                }
            }
        }

        private bool Bladestorm()
        {
            if (!_me.CurrentTarget.Dead)
            {
                if (SpellManager.KnownSpells.ContainsKey("Bladestorm"))
                {
                    WoWSpell bs = SpellManager.KnownSpells["Bladestorm"];
                    if (!bs.Cooldown && _me.GetCurrentPower(WoWPowerType.Rage) >= 25)
                    {
                        SpellManager.CastSpellById(bs.Id);
                        Thread.Sleep(1200);
                        return true;
                    }
                }
            }
            return false;
        }

        #endregion

        #region Defensive Spells

        /// <summary>
        /// http://www.wowhead.com/?spell=6343
        /// Blasts nearby enemies increasing the time between their attacks by 10% for 10 sec and doing 15 damage to them.  Damage increased by attack power.  This ability causes additional threat.
        /// </summary>
        private bool ThunderClap()
        {
            if (Overpower())
            {
                Slog("[ " + Name + " ]: Overpower!");
                Thread.Sleep(1500);
            }

            if (_useThunderClap &&
                !_me.CurrentTarget.Buffs.ContainsKey("Thunder Clap") &&
                _me.CurrentTarget.HealthPercent > 30 &&
                !_me.CurrentTarget.Fleeing)
            {
                if (SpellManager.KnownSpells.ContainsKey("Thunder Clap"))
                {
                    WoWSpell tc = SpellManager.KnownSpells["Thunder Clap"];
                    if (!tc.Cooldown && _me.GetCurrentPower(WoWPowerType.Rage) >= 20)
                    {
                        SpellManager.CastSpellById(tc.Id);
                        Thread.Sleep(1500);
                        return true;
                    }
                }
            }
            return false;
        }

        /// <summary>
        /// http://www.wowhead.com/?spell=1715
        /// Maims the _enemy, reducing movement speed by 50% for 15 sec.    
        /// </summary>
        void Hamstring()
        {
            DistanceCheck();
            if (Overpower())
            {
                Slog("[ " + Name + " ]: Overpower!");
                Thread.Sleep(1500);
            }
            if (SpellManager.KnownSpells.ContainsKey("Hamstring"))
            {
                if (SpellManager.CanCastSpell("Hamstring") && !_me.CurrentTarget.Dead && _me.CurrentTarget.Distance < 2)
                {
                    SpellManager.CastSpell("Hamstring");
                    Logging.Write("[ " + Name + " ]: Hamstring on {0}", _me.CurrentTarget.Name);
                }
            }
        }

        private bool ShieldBlock()
        {
            if (SpellManager.KnownSpells.ContainsKey("Shield Block"))
            {
                WoWSpell shieldblock = SpellManager.KnownSpells["Shield Block"];
                if (!shieldblock.Cooldown)
                {
                    SpellManager.CastSpellById(shieldblock.Id);
                    //Thread.Sleep(1500);  No GCD on Shield Block?
                    return true;
                }
            }
            return false;
        }

        private bool ConcussionBlow()
        {
            DistanceCheck();
            if (SpellManager.KnownSpells.ContainsKey("Concussion Blow") &&
                SpellManager.CanCastSpell("Concussion Blow"))
            {
                return SpellManager.CastSpell("Concussion Blow");
            }
            return false;
        }

        private bool ShieldWall()
        {
            if (SpellManager.KnownSpells.ContainsKey("Shield Wall") &&
                SpellManager.CanCastSpell("Shield Wall"))
            {
                return SpellManager.CastSpell("Shield Wall");
            }
            return false;
        }

        private bool Disarm()
        {
            DistanceCheck();
            if (SpellManager.KnownSpells.ContainsKey("Disarm"))
            {
                WoWSpell disarm = SpellManager.KnownSpells["Disarm"];
                if (!disarm.Cooldown && _me.GetCurrentPower(WoWPowerType.Rage) >= 15)
                {
                    SpellManager.CastSpellById(disarm.Id);
                    Thread.Sleep(1500);
                    return true;
                }
            }
            return false;
        }

        private void EnragedRegeneration()
        {
            if (SpellManager.KnownSpells.ContainsKey("Enraged Regeneration"))
            {
                WoWSpell regen = SpellManager.KnownSpells["Enraged Regeneration"];
                if (!regen.Cooldown && CheckEnrage())
                {
                    SpellManager.CastSpellById(regen.Id);
                    Thread.Sleep(500);
                    Logging.Write("[ " + Name + " ]: Enraged Regen used!");
                }
            }
        }

        private void LastStand()
        {
            if (SpellManager.KnownSpells.ContainsKey("Last Stand"))
            {
                WoWSpell laststand = SpellManager.KnownSpells["Last Stand"];
                if (!laststand.Cooldown)
                {
                    SpellManager.CastSpellById(laststand.Id);
                    Thread.Sleep(500);
                    Logging.Write("[ " + Name + " ]: Last stand used!");
                }
            }
        }

        private bool Pummel()
        {
            DistanceCheck();
            if (SpellManager.KnownSpells.ContainsKey("Pummel"))
            {
                WoWSpell pummel = SpellManager.KnownSpells["Pummel"];
                if (!pummel.Cooldown && _me.GetCurrentPower(WoWPowerType.Rage) >= 10)
                {
                    SpellManager.CastSpellById(pummel.Id);
                    Thread.Sleep(1500);
                    return true;
                }
            }
            return false;
        }

        private bool ShieldBash()
        {
            DistanceCheck();
            if (SpellManager.KnownSpells.ContainsKey("Shield Bash"))
            {
                WoWSpell shieldbash = SpellManager.KnownSpells["Shield Bash"];
                if (!shieldbash.Cooldown)
                {
                    SpellManager.CastSpellById(shieldbash.Id);
                    Thread.Sleep(1500);
                    return true;
                }
            }
            return false;
        }

        #endregion

        #region Stances

        /// <summary>
        /// http://www.wowhead.com/?spell=2457
        /// A balanced combat stance that increases the armor penetration of all of your attacks by 10%.        
        /// </summary>
        void BattleStance()
        {
            if (SpellManager.KnownSpells.ContainsKey("Battle Stance") && _me.Shapeshift != Object_Dumping_Enumeration.WoWObjects.WoWUnit.ShapeshiftForm.BattleStance)
            {
                SpellManager.CastSpell("Battle Stance");
                Slog("[ " + Name + " ]: Battle Stance!");
            }
        }

        /// <summary>
        /// http://www.wowhead.com/?spell=71
        /// A defensive combat stance.  Decreases damage taken by 10% and damage caused by 5%.  Increases threat generated.
        /// </summary>
        void DefensiveStance()
        {
            //Overpower();

            if (SpellManager.KnownSpells.ContainsKey("Defensive Stance") && _me.Shapeshift != Object_Dumping_Enumeration.WoWObjects.WoWUnit.ShapeshiftForm.DefensiveStance)
            {
                SpellManager.CastSpell("Defensive Stance");
                Slog("[ " + Name + " ]: Defensive Stance!");
            }
        }

        /// <summary>
        /// http://www.wowhead.com/?spell=2458
        /// An aggressive stance.  Critical hit chance is increased by 3% and all damage taken is increased by 5%.
        /// </summary>
        void BerserkerStance()
        {
            //Overpower();

            if (SpellManager.KnownSpells.ContainsKey("Berserker Stance") && _me.Shapeshift != Object_Dumping_Enumeration.WoWObjects.WoWUnit.ShapeshiftForm.BerserkerStance)
            {
                SpellManager.CastSpell("Berserker Stance");
                Slog("[ " + Name + " ]: Berserker Stance!");
            }
        }

        #endregion

        #region Shouts

        /// <summary>
        /// http://www.wowhead.com/?spell=6673
        /// The warrior shouts, increasing attack power of all raid and party members within 30 yards by 15.  Lasts 2 min.
        /// </summary>
        private bool BattleShout()
        {
            if (Overpower())
            {
                Slog("[ " + Name + " ]: Overpower!");
                Thread.Sleep(1500);
            }

            if (_useBattleShout)
            {
                if (SpellManager.KnownSpells.ContainsKey("Battle Shout"))
                {
                    if (SpellManager.CanCastSpell("Battle Shout") && !_me.Buffs.ContainsKey("Battle Shout"))
                    {
                        return SpellManager.CastSpell("Battle Shout");
                    }
                }
            }
            return false;
        }

        /// <summary>
        /// http://www.wowhead.com/?spell=1160
        /// Reduces the melee attack power of all enemies within 10 yards by 35 for 30 sec.
        /// </summary>
        private bool DemoShout()
        {
            if (Overpower())
            {
                Slog("[ " + Name + " ]: Overpower!");
                Thread.Sleep(1500);
            }

            if (_useDemoShout && _me.GotTarget)
            {
                if (!_me.CurrentTarget.Buffs.ContainsKey("Demoralizing Shout") && _me.CurrentTarget.HealthPercent > 40)
                {
                    if (_me.CurrentTarget.IsPlayer)
                        return false;

                    if (_me.CurrentTarget.Distance > 10)
                        return false;

                    if (SpellManager.CanCastSpell("Demoralizing Shout"))
                    {
                        return SpellManager.CastSpell("Demoralizing Shout");
                    }
                }
            }
            return false;
        }

        /// <summary>
        /// http://www.wowhead.com/?spell=5246
        /// The warrior shouts, causing up to 5 enemies within 8 yards to cower in fear.  The targeted _enemy will be unable to move while cowering.  Lasts 8 sec.
        /// </summary>
        private bool IntimidatingShout()
        {
            if (SpellManager.KnownSpells.ContainsKey("Intimidating Shout"))
            {
                WoWSpell fear = SpellManager.KnownSpells["Intimidating Shout"];
                if (!fear.Cooldown && _me.GetCurrentPower(WoWPowerType.Rage) >= 25)
                {
                    SpellManager.CastSpellById(fear.Id);
                    Thread.Sleep(1500);
                    _fearAdds = false;
                    return true;
                }
            }
            return false;
        }

        private bool CommandingShout()
        {
            if (_useCommShout)
            {
                if (SpellManager.KnownSpells.ContainsKey("Commanding Shout"))
                {
                    if (SpellManager.CanCastSpell("Commanding Shout") && !_me.Buffs.ContainsKey("Commanding Shout"))
                    {

                        return SpellManager.CastSpell("Commanding Shout");
                    }
                }
            }
            return false;
        }


        #endregion

        #endregion

        #region Racials

        void BloodFury()
        {
            if (Overpower())
            {
                Slog("[ " + Name + " ]: Overpower!");
                Thread.Sleep(1500);
            }

            if (SpellManager.KnownSpells.ContainsKey("Blood Fury"))
            {
                if (SpellManager.CanCastSpell("Blood Fury"))
                {
                    SpellManager.CastSpell("Blood Fury");
                    Logging.Write("[ " + Name + " ]: Casting Blood Fury - Mob {0}% HP, Me {1}% HP!", _me.CurrentTarget.HealthPercent, _me.HealthPercent);
                }
            }
        }

        void Stoneform()
        {
            if (SpellManager.KnownSpells.ContainsKey("Stoneform"))
            {
                if (SpellManager.CanCastSpell("Stoneform"))
                {
                    SpellManager.CastSpell("Stoneform");
                    Slog("[ " + Name + " ]: Low on health.  Stoneform used!");
                }
            }
        }

        void Berserking()
        {
            if (SpellManager.KnownSpells.ContainsKey("Berserking"))
            {
                if (SpellManager.CanCastSpell("Berserking"))
                {
                    SpellManager.CastSpell("Berserking");
                    Slog("[ " + Name + " ]: Berserking!");
                }
            }
        }


        #endregion

        #region Combat Styles

        void BattleCombat()
        {
            CombatBuff();
            if (CombatCheck())
            {
                if (Rend())
                    Slog("[ " + Name + " ]: Rend!");

                if (BerserkerRage())
                    Slog("[ " + Name + " ]: Berserker Rage!");

                if (ThunderClap())
                    Logging.Write("[ " + Name + " ]: Thunder Clap on {0} with {1}% HP left!", _me.CurrentTarget.Name, _me.CurrentTarget.HealthPercent);

                if (_me.CurrentTarget.HealthPercent <= _hamstringPct && _useHamstring)  // does this work as intended?
                    Hamstring();

                if (VictoryRush())
                    Slog("[ " + Name + " ]: Victory Rush!");

                if (Bladestorm() && _me.CurrentTarget.HealthPercent >= 40)
                {
                    Slog("[ " + Name + " ]: Bladestorm!");
                    Thread.Sleep(4800);
                }

                if (HeroicStrike())
                    Slog("[ " + Name + " ]: Heroic Strike!");

                if (MortalStrike())
                    Slog("[ " + Name + " ]: Mortal Strike!");

                if (_me.CurrentTarget.HealthPercent <= _hamstringPct && _useHamstring)  // does this work as intended?
                    Hamstring();

                if (_me.CurrentTarget.HealthPercent >= 60 && _me.HealthPercent <= 50 && Retaliation())
                    Slog("[ " + Name + " ]: Retaliation!");
            }
            return;
        }

        void BerserkerCombat()
        {
            CombatBuff();
            if (CombatCheck())
            {
                if (CastingCheck())
                {
                    Slog("[ " + Name + " ]: Mob is casting, pummel!");
                    if (Pummel())
                        Slog("[ " + Name + " ]: Pummel used!");
                    else
                        Slog("[ " + Name + " ]: Pummel on cooldown or not enough rage!");
                }

                if (_me.CurrentTarget.HealthPercent <= _hamstringPct && _useHamstring)  // does this work as intended?
                    Hamstring();

                if (BerserkerRage())
                    Slog("[ " + Name + " ]: Bersker Rage!");

                if (Slam())
                    Slog("[ " + Name + " ]: Slam!");

                if ((_me.CurrentTarget.HealthPercent <= 20) || (_useSuddenDeath && CheckSD()))
                {
                    Execute();
                }

                if (VictoryRush())
                    Slog("[ " + Name + " ]: Victory Rush!");

                if (DeathWish())
                    Slog("[ " + Name + " ]: Death Wish!");

                if (Bloodthirst())
                    Slog("[ " + Name + " ]: Bloodthirst!");

                if ((_me.CurrentTarget.HealthPercent <= 20) || (_useSuddenDeath && CheckSD()))
                {
                    Execute();
                }

                if (Whirlwind())
                    Slog("[ " + Name + " ]: Whirlwind!");

                if (CastingCheck())
                {
                    Slog("[ " + Name + " ]: Mob is casting, pummel!");
                    if (Pummel())
                        Slog("[ " + Name + " ]: Pummel used!");
                    else
                        Slog("[ " + Name + " ]: Pummel on cooldown or not enough rage!");
                }

                if (_me.GetCurrentPower(WoWPowerType.Rage) >= _rageDumpVal)
                {
                    if (!Whirlwind())
                    {
                        if (HeroicStrike())
                            Slog("[ " + Name + " ]: Heroic Strike!");
                    }
                }

                if (_me.HealthPercent >= 80 && _me.CurrentTarget.HealthPercent >= 50 && Recklessness())
                    Slog("[ " + Name + " ]: Recklessness!");

                if (_me.CurrentTarget.HealthPercent <= _hamstringPct && _useHamstring)  // does this work as intended?
                    Hamstring();

                if ((_me.CurrentTarget.HealthPercent <= 20) || (_useSuddenDeath && CheckSD()))
                {
                    Execute();
                }

                if (Slam())
                    Slog("[ " + Name + " ]: Slam!");

                if (CastingCheck())
                {
                    Slog("[ " + Name + " ]: Mob is casting, pummel!");
                    if (Pummel())
                        Slog("[ " + Name + " ]: Pummel used!");
                    else
                        Slog("[ " + Name + " ]: Pummel on cooldown or not enough rage!");
                }
            }

        }

        void DefensiveCombat()
        {
            CombatBuff();
            if (CombatCheck())
            {
                if (CastingCheck())
                {
                    Slog("[ " + Name + " ]: Mob is casting, Shield Bash!");
                    if (ShieldBash())
                        Slog("[ " + Name + " ]: Shield Bash used!");
                    else
                        Slog("[ " + Name + " ]: Shield Bash on cooldown or not enough rage!");
                }

                if (ThunderClap())
                    Logging.Write("[ " + Name + " ]: Thunder Clap on {0} with {1}% HP left!", _me.CurrentTarget.Name, _me.CurrentTarget.HealthPercent);

                if (Shockwave())
                    Slog("[ " + Name + " ]: Shockwave!");

                if (Revenge())
                    Slog("[ " + Name + " ]: Revenge!");

                if (Disarm())
                    if (_me.CurrentTarget.Buffs.ContainsKey("Disarm"))
                        Slog("[ " + Name + " ]: Disarmed!");

                if (Rend())
                    Slog("[ " + Name + " ]: Rend!");

                if (ShieldBlock())
                    Slog("[ " + Name + " ]: Shield Block!");

                if (ShieldSlam())
                    Slog("[ " + Name + " ]: Shield Slam!");

                if (CastingCheck())
                {
                    Slog("[ " + Name + " ]: Mob is casting, Shield Bash!");
                    if (ShieldBash())
                        Slog("[ " + Name + " ]: Shield Bash used!");
                    else
                        Slog("[ " + Name + " ]: Shield Bash on cooldown or not enough rage!");
                }

                if (HeroicStrike())
                    Slog("[ " + Name + " ]: Heroic Strike!");

                if (ConcussionBlow())
                    Slog("[ " + Name + " ]: Concussion Blow!");

                if (SpellManager.KnownSpells.ContainsKey("Devastate"))
                {
                    if (Devastate())
                        Slog("[ " + Name + " ]: Devastate!");
                }
                else
                {
                    SunderArmor();
                    Slog("[ " + Name + " ]: Sunder Armor!");
                }

                if (_me.HealthPercent < 30)
                    if (ShieldWall())
                        Logging.Write("[ " + Name + " ]: Low HP!  {0}% - Shield Wall!");

                if (CastingCheck())
                {
                    Slog("[ " + Name + " ]: Mob is casting, Shield Bash!");
                    if (ShieldBash())
                        Slog("[ " + Name + " ]: Shield Bash used!");
                    else
                        Slog("[ " + Name + " ]: Shield Bash on cooldown or not enough rage!");
                }

            }
        }

        #endregion

        #region Checks and Custom Methods

        public bool CombatCheck()
        {
            if (_me.CurrentTarget.Guid == _me.Guid)
                _me.ClearTarget();

            if (_me.Dead)
            {
                Slog("I'm dead.");
                return false;
            }

            DistanceCheck();
            _addsList = GetAdds();
            WoWMovement.Face();

            if ((_me.CurrentTarget.HealthPercent <= 20) || (_useSuddenDeath && CheckSD()))
            {
                Execute();
            }

            if (_me.GetCurrentPower(WoWPowerType.Rage) <= 25 && _me.CurrentTarget.HealthPercent > 70 && _me.HealthPercent > 60)
                Bloodrage();

            if (DemoShout())
                Slog("[ " + Name + " ]: Demo Shout!");

            if (_me.Shapeshift == Object_Dumping_Enumeration.WoWObjects.WoWUnit.ShapeshiftForm.DefensiveStance && CommandingShout())
                Slog("[ " + Name + " ]: Commanding Shout!");

            if ((_me.Shapeshift == Object_Dumping_Enumeration.WoWObjects.WoWUnit.ShapeshiftForm.BattleStance && BattleShout()) || _me.Shapeshift == Object_Dumping_Enumeration.WoWObjects.WoWUnit.ShapeshiftForm.BerserkerStance && BattleShout())
                Slog("[ " + Name + " ]: Battle Shout!");

            if (_me.CurrentTarget.HealthPercent <= _hamstringPct && _useHamstring)  // does this work as intended?
                Hamstring();

            if (_addsList.Count >= _addNumToFear)
                _fearAdds = true;


            return true;
        }

        void DistanceCheck()
        {
            WoWMovement.Face();
            if ((_me.Shapeshift == Object_Dumping_Enumeration.WoWObjects.WoWUnit.ShapeshiftForm.BerserkerStance &&
                _me.CurrentTarget.Distance > 8 &&
                _me.CurrentTarget.Distance < 25 &&
                Intercept()) ||
                (_me.Shapeshift == Object_Dumping_Enumeration.WoWObjects.WoWUnit.ShapeshiftForm.DefensiveStance &&
                _me.CurrentTarget.Distance > 8 &&
                _me.CurrentTarget.Distance < 30 &&
                _me.Buffs.ContainsKey("Warbringer") &&
                Charge()) ||
                (_me.Shapeshift == Object_Dumping_Enumeration.WoWObjects.WoWUnit.ShapeshiftForm.DefensiveStance &&
                _me.CurrentTarget.Distance > 8 &&
                _me.CurrentTarget.Distance < 25 &&
                _me.Buffs.ContainsKey("Warbringer") &&
                Intercept()))
                Slog("[ " + Name + " ]: Getting range.. Charge/Intercept!");

            if (_me.CurrentTarget.Distance > 4 && !_me.CurrentTarget.Dead)
            {
                WoWPoint point = WoWMovement.CalculatePointFrom(_me.CurrentTarget.Location, 2.0f);
                WoWMovement.ClickToMove(point);
                Thread.Sleep(300);
                WoWMovement.Face();
            }

        }

        private WoWItem CheckForItem(List<uint> listId)
        {
            foreach (WoWItem item in ObjectManager.ItemObjectList.Values)
            {
                if (listId.Contains(item.Entry))
                {
                    return item;
                }
            }
            return null;
        }

        private bool CastSpell(string spell, int rage)
        {
            if (SpellManager.KnownSpells.ContainsKey(spell))
            {
                WoWSpell myspell = SpellManager.KnownSpells[spell];
                if (!myspell.Cooldown && _me.GetCurrentPower(WoWPowerType.Rage) >= rage)
                {
                    SpellManager.CastSpellById(myspell.Id);
                    Thread.Sleep(1500);
                    return true;
                }
            }
            return false;
        }

        //GetAdds() credits to Hawker and team
        private List<WoWUnit> GetAdds()
        {
            List<WoWUnit> mobList = new List<WoWUnit>();
            List<WoWObject> longList = new List<WoWObject>();
            List<WoWUnit> enemyMobList = new List<WoWUnit>();
            longList = ObjectManager.ObjectList;

            foreach (WoWObject thing in longList)
            {
                if (thing.Type == 3)
                {
                    mobList.Add(thing.ToUnit());
                }
            }

            foreach (WoWUnit thing in mobList)
            {
                if ((thing.Guid != _me.Guid) &&
                    thing.IsTargetingMe)
                {
                    enemyMobList.Add(thing);
                }

            }

            if (_fearAdds && _usePVEFear)
            {
                if (IntimidatingShout())
                {
                    Logging.Write("[ " + Name + " ]: Picked up {0} adds!  FEAR!", enemyMobList.Count.ToString());
                    _fearAdds = false;
                }
            }

            return enemyMobList;

        }

        public bool CastingCheck()
        {
            if (_me.CurrentTarget.Casting)
                return true;
            else
                return false;
        }

        private bool CheckEnrage()
        {
            if (_me.Buffs.ContainsKey("Rampage"))
                return true;
            if (_me.Buffs.ContainsKey("Death Wish"))
                return true;
            if (_me.Buffs.ContainsKey("Berserker Rage"))
                return true;
            if (_me.Buffs.ContainsKey("Enrage"))
                return true;
            if (_me.Buffs.ContainsKey("Bloodrage"))
                return true;
            else
                return false;
        }

        public void DrinkPotion()
        {
            WoWItem potion = CheckForItem(_potionEID);
            if (potion != null)
            {
                Logging.Write("[ " + Name + " ]: !! HEALTH LOW !! Using Potion: {0}", potion.Name);
                Lua.DoString("UseItemByName(\"" + potion.Name + "\")");
                Thread.Sleep(500);
            }
            else
                Slog("[ " + Name + " ]: !! HEALTH LOW !! No potions!");
        }
        /*
                public void RemoveDead()
                {
                    List<ulong> removeGuid = new List<ulong>();
                    foreach (ulong unitGuid in enemyMobList)
                    {
                        if (ObjectManager.NpcObjectList.ContainsKey(unitGuid))
                        {
                            WoWUnit unit = ObjectManager.NpcObjectList[unitGuid];
                            if (unit.Dead)
                                removeGuid.Add(unitGuid);
                        }
                        else
                            removeGuid.Add(unitGuid);
                    }
                    foreach (ulong unitGuid in removeGuid)
                    {
                        enemyMobList.Remove(unitGuid);
                        if (enemyMobList.Contains(unitGuid))
                            enemyMobList.Remove(unitGuid);
                    }
                }
         */

        private WoWPoint targetLocation
        {
            get
            {
                if (_me.CurrentTarget.IsValid)
                {
                    return _me.CurrentTarget.Location;
                }
                else
                {
                    WoWPoint noSpot = new WoWPoint();
                    return noSpot;
                }
            }
        }

        private bool CheckSD()
        {
            const string cSearchBuffName = "Sudden Death";
            Lua.DoString("buffName,_,_,stackCount,_,_,_,_,_=UnitBuff(\"player\",\"" + cSearchBuffName + "\")");
            string buffName = Lua.GetLocalizedText("buffName", _me.BaseAddress);
            int stackCount = Lua.GetLocalizedInt32("stackCount", _me.BaseAddress);

            //if (buffName == cSearchBuffName && stackCount >= 0)
            if (buffName == cSearchBuffName)
            {
                Logging.Write("[ " + Name + " ]: Sudden Death proc!");
                return true;
            }
            return false;
        }

        private void CheckEternals() // Credit to TIA & HB Forum
        {
            Lua.DoString("RunMacroText(\"/use Crystallized Life\")");
            Lua.DoString("RunMacroText(\"/use Crystallized Fire\")");
            Lua.DoString("RunMacroText(\"/use Crystallized Water\")");
            Lua.DoString("RunMacroText(\"/use Crystallized Mana\")");
            Lua.DoString("RunMacroText(\"/use Crystallized Earth\")");
            Lua.DoString("RunMacroText(\"/use Crystallized Air\")");
            Lua.DoString("RunMacroText(\"/use Crystallized Shadow\")");
            Lua.DoString("RunMacroText(\"/script UIErrorsFrame:Clear()\")");
            return;
        }

        #endregion

    }
}