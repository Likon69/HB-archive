﻿/*
 * ShamWOW Shaman CC - Version: 2.02
 * 
 * Note: in general, approach to rotations and leveling taken from:
 * 
 *          http://wow-pro.com/class_guides/shaman_leveling_talents_and_tips_180
 *          
 * For use of totems during leveling, I am using strategies outlined in :
 * 
 *          http://www.yawb.info/2009/08/25/learning-about-totems-tips-to-aid-your-growing-shamanism/
 * 
 * Change History moved to CHANGES.TXT file
 */
#pragma warning disable 642

/*************************************************************************
 *   !!!!! DO NOT CHANGE ANYTHING IN THIS FILE !!!!!
 *   
 *   User customization is only supported through changing the values
 *   in the SHAMAN.CONFIG xml file in your Custom Classes folder
*************************************************************************/
namespace Styx.Bot.CustomClasses
{
    using Helpers;
    using Logic.Pathing;
    using Logic.Common.Combat;
    using System;
    using System.IO;
    using System.Xml;
    using System.Threading;
    using System.Diagnostics;
    using System.Collections.Generic;
    using System.Runtime.InteropServices;
    using Object_Dumping_Enumeration;
    using Styx.Object_Dumping_Enumeration.WoWObjects;
    using CustomCombat.CombatInterface;
    using Memory_Read_Write_Inject.Lua;

    /*
     * 
     *  TODO:
     *  
     *  add check for potions being on CD.  currently attempts to
     *  use potion even when on cooldown.  not a huge deal, but 
     *  message in Log is misleading
     *  
     *  support selective use of health, mana, or rejuv potions
     *  based upon current health and mana levels
     *  
     *  [possible bug] appeared that potion not consumed on first attempt
     *  could have been that character was stunned.  only saw once
     *  
     *  support use of any food in bags
     *  
     *  support use of buff food only when Well Fed is not up
     *  
     */
    class Shaman : ICombat
    {
        public WoWClass Class { get { return WoWClass.Shaman; } }
        public string Name { get { return "ShamWOW v2.03"; } }


        #region Global Variables

        ConfigValues _cfg = new ConfigValues();          // object holding user configurable values
        CC_PVP _pvp = new CC_PVP();                      // pvp support class for CC's
        CC_TalentGroup _primaryTalents = new CC_TalentGroup();
        CC_TalentGroup _secondaryTalents = new CC_TalentGroup();

        double _distForRangedPull = 23.0;         // distance from target to setup for Ranged Pull
        double _distForMeleePull = 3.0;           // distance from target to runt to for Melee pull

        private volatile LocalPlayer _me = ObjectManager.Me;

        Stopwatch _pullTimer = new Stopwatch();             // kill timer from when we target for pull
        private ulong _pullTargGuid = 0;
        private bool _pullTargHasBeenInMelee = false;       // flag indicating that we got in melee range of mob

        private ulong _lastDeadMobReported = 0;             // guid of last mob we informed user about killing
        private int _killCount = 0;
        private int _deathCount = 0;

        private bool _lastShieldCastWasWater = false;       // toggle remember which shield used last shield twist

        Stopwatch _TotemCheckTimer = new Stopwatch(); // timer to prevent checking totems each time through Combat  (uses LUA funcs)
        private bool _WereTotemsSet = false;             // flag indicating whether any totems were cast
        private bool _castGhostWolfForm = false;            // 
        private bool _castMainHandEnchant = false;
        private bool _castOffHandEnchant = false;

        private bool _BigScaryGuyHittingMe = false;      // mob sufficiently higher than us (3+ lvls)
        private bool _OpposingPlayerGanking = false;    // player from other faction attacking me
        private int _countMeleeEnemy = 0;               // # of melee mobs in combat with me
        private int _countRangedEnemy = 0;              // # of ranged mobs in combat with me
        private int _countMobs = 0;                     // # of faction mobs as spec'd in current profile
        private double _distClosestEnemy = 0;           // distance to closest hostile or faction mob

        private bool _bFireTotem = false;

        private bool _lastHealerCheck = false;    // 
        private bool _needInitialization = true;

        enum ShamanType
        {
            None,
            Elemental,
            Enhance,
            Resto
        };

        ShamanType eType = ShamanType.None;

        private int countEnemy
        {
            get
            {
                return _countMeleeEnemy + _countRangedEnemy;
            }
        }

        #endregion

        #region Private Members

        private bool IsInGame { get { return ObjectManager.Wow.Read<bool>((uint)GlobalOffsets.IsInGame); } }

        /*
         * Ctor
         * 
         * initialize and post load messages/checks for user
         */
        public Shaman()
        {
            if (!IsInGame || _me.Class != WoWClass.Shaman)
            {
                return;
            }

            // just set this to possibly correct value for now.  will revise later
            _cfg.Load("CustomClasses\\Config\\Shaman.Config");

            Logging.Write("LOADED:  " + Name);

            _primaryTalents.Load(1);
            _secondaryTalents.Load(2);

            CC_TalentGroup activeGrp;
            CC_TalentGroup inactiveGrp;

            

            if (_primaryTalents.IsActiveGroup())
            {
                activeGrp = _primaryTalents;
                inactiveGrp = _secondaryTalents;
            }
            else
            {
                inactiveGrp = _primaryTalents;
                activeGrp = _secondaryTalents;
            }

            string sSpecType = activeGrp._tabName[activeGrp.Spec()];
            if (activeGrp.Spec() == 1)
                eType = ShamanType.Elemental;
            else if (activeGrp.Spec() == 2)
                eType = ShamanType.Enhance;
            else if (activeGrp.Spec() == 3)
                eType = ShamanType.Elemental;
            else
            {
                eType = ShamanType.None;
                sSpecType = "Undefined";
            }

            Logging.Write("  Your Level " + _me.Level + " " + _me.Race + " " + sSpecType + " Shaman Build is:  ");
            Logging.Write("  " + activeGrp._tabName[1].Substring(0, 5) + "/" + activeGrp._tabName[2].Substring(0, 5) + "/" + activeGrp._tabName[3].Substring(0, 5)
                + "   " + activeGrp._tabPoints[1] + "/" + activeGrp._tabPoints[2] + "/" + activeGrp._tabPoints[3]);
            /*
                        if (_me.Level <= 60)
                        {
                            if ((offspecPoints) > 0)
                            {
                                Logging.Write("NOTE: For best results, only spend talent points in the " + sSpecType + " tree through level 60");
                            }
                        }
                        else
                        {
                            // check there is at least a 28 point difference in talent points
                            if ((secondTabPoints - (firstTabPoints + thirdTabPoints) < 21))
                            {
                                Logging.Write("NOTE: For best results, fill the " + sSpecType + " talent tree before spending points in other trees");
                            }
                        }
             */
           
            if (activeGrp.totalPoints < (_me.Level - 9))
            {
                Logging.Write("= = = = = = = = = = = = = = = = ");
                Logging.Write("WARNING:  You have " + (_me.Level - 9 - activeGrp.totalPoints) + " UNSPENT Talent Points and are gimping your Shaman.");
                Logging.Write("= = = = = = = = = = = = = = = = ");
            }
                   
           

            Lua.DoString("CancelItemTempEnchantment(1)");
            Lua.DoString("CancelItemTempEnchantment(2)");


            WoWSpell spell = SpellManager.KnownSpells["Lightning Bolt"];
            _distForRangedPull = spell.MaxRange - 4;
            Logging.Write("Max Pull Ranged:   {0}", _distForRangedPull);
            Logging.Write("HB Pull Distance:  {0}", Logic.Targeting.PullDistance);
        }

        /*
         * Dtor
         */
        ~Shaman()
        {
            if (!IsInGame || _me.Class != WoWClass.Shaman)
            {
                return;
            }

            Dlog("UNLOAD:  " + Name);
        }

        string _logspam;



        /* Slog()
         * 
         * write 'msg' to log window.  message is suppressed if it is identical
         * to prior message.  Intent is to prevent log window spam
         */
        private void Log(string msg, params object[] args)
        {
            Logging.Write("* " + msg, args);
        }


        /* Slog()
         * 
         * write 'msg' to log window.  message is suppressed if it is identical
         * to prior message.  Intent is to prevent log window spam
         */
        private void Slog(string msg, params object[] args)
        {
            msg = String.Format(msg, args);
            if (msg == _logspam)
                return;

            Log(msg);
            _logspam = msg;
        }

        /* Dlog()
         * 
         * Write Debug log message to log window.  message is suppressed if it
         * is identical to prior log message or verbose mode is turned off.  These
         * messages are trace type in nature to follow in more detail what has occurred
         * in the code.
         * 
         * NOTE:  I am intentionally putting debug message in the Log().  At this point,
         * it helps more having all data be time sequenced in the same window.  This will
         * near the close of development move to the Debug window instead
         */
        private void Dlog(string msg, params object[] args)
        {
            msg = String.Format(msg, args);
            if (msg == _logspam) // || _cfg.Debug == false)
                return;

            if (_cfg.Debug)
                Logging.Write("% " + msg);
            else
                Logging.WriteDebug("% " + msg);

            _logspam = msg;
        }


        #region SAFE_ Functions
        /*
         * Safe_ Functions.  These were created to handle unexpected errors and
         * situations occurring in HonorBuddy.  try/catch handling is provided
         * where an exception is thrown by HB that shouldn't be. multiple
         * attempts at something (like dismounting) are done until the desired
         * state (!_me.Mounted) is achieved
         */
        private bool Safe_IsValid(WoWUnit unit)
        {
            return unit != null;
        }

        private bool Safe_IsValid(WoWPlayer p)
        {
            return p != null;
        }

        /*
         * Safe_KnownSpell()
         * 
         */
        private bool Safe_KnownSpell(string sSpellName)
        {
            bool bKnown = false;

            try
            {
                bKnown = SpellManager.KnownSpells.ContainsKey(sSpellName);
            }
            catch (Exception e)
            {
                Slog("HB EXCEPTION in SpellManager.KnownSpells.ContainsKey(" + sSpellName + "): " + e.ToString());
                Slog(">>> REPORT ERROR TO CC DEVELOPER WITH LOG");
            }

            return bKnown;
        }

        /*
         * Safe_CastSpell()
         * 
         * temporary replacement for CastSpell() that prevents errors on 
         * self-cast spells like buffs, temp weapon enchants, etc.
         */
        private bool Safe_CastSpell(string sSpellName)
        {
            WoWSpell spell = null;
            bool enoughPower = false;
            bool bCastSuccessful = false;

            try
            {
                spell = SpellManager.KnownSpells[sSpellName];
            }
            catch (Exception e)
            {
                Slog(">>> HB EXCEPTION in SpellManager.KnownSpells[" + sSpellName + "]: " + e.ToString());
                Slog(">>> Spell '" + sSpellName + "' believed to be " + (Safe_KnownSpell(sSpellName) ? "KNOWN" :
                    "UNKNOWN") + " was used ");
                Slog(">>> REPORT ERROR TO CC DEVELOPER WITH LOG");
                return false;
            }

            enoughPower = (_me.GetCurrentPower(spell.PowerType) >= spell.PowerCost);

            if (SpellManager.GlobalCooldown)
                Dlog("status:  global cooldown active");
            else if (spell.Cooldown)
                Dlog("status:  spell on cooldown - " + sSpellName);
            else if (!enoughPower)
                Dlog("warning:  not enough power for spell - " + sSpellName);
            //          else if (!SpellManager.CanCastSpell( spell.Id ))                    // unclear what this spell does other than periodically
            //              Dlog("warning:  cannot cast spell {0} yet", sSpellName );       // .. block casting which otherwise can occur... disabled
            else
            {
                try
                {
                    SpellManager.CastSpellById(spell.Id);
                }
                catch (Exception e)
                {
                    Slog("HB EXCEPTION in SpellManager.CastSpellById[" + spell.Id + ":" + sSpellName + "]: " + e.ToString());
                    Slog(">>> REPORT ERROR TO CC DEVELOPER WITH LOG");
                    return false;
                }

                Log("*" + sSpellName);
                bCastSuccessful = true;

                Thread.Sleep(250);
                while (SpellManager.GlobalCooldown || _me.Casting != 0 || _me.ChanneledCasting != 0)
                {
                    Thread.Sleep(50);
                }
            }

            return bCastSuccessful;
        }

        /*
         * Only issues the Stop moving command if currently moving.  also
         * accounts for any lag which prevents immediate stop
         */
        private void Safe_StopMoving()
        {
            int countTries = 0;
            Stopwatch stopTimer = new Stopwatch();

            stopTimer.Start();
            while (_me.IsMoving && stopTimer.ElapsedMilliseconds < 1000)
            {
                countTries++;
                WoWMovement.MoveStop();
                Thread.Sleep(100);          // increased from 50 to handle flag update lag better
            }

            if (countTries > 1)
            {
                Dlog("Attempted to stop moving " + countTries);
            }

            if (_me.IsMoving)
            {
                Slog("ERROR: " + countTries + " attempts to stop moving for a full second and failed");
            }
        }

        /*
         * Only issues the Stop moving command if currently moving.  also
         * accounts for any lag which prevents immediate stop
         */
        private void Safe_Dismount()
        {
            int countTries = 0;
            Stopwatch stopTimer = new Stopwatch();

            stopTimer.Start();
            while (_me.Mounted && stopTimer.ElapsedMilliseconds < 1000)
            {
                countTries++;
                Logic.Mount.Dismount();
                Thread.Sleep(100);
            }

            Dlog("Attempted to dismount " + countTries);

            if (_me.Mounted)
            {
                Slog("ERROR:  still mounted despite trying for a full second and failed");
            }
        }

        #endregion

        /*
         * Summary:  returns 'true' if should attempt to heal group members, 'false' if dps only
         * 
         * Will heal only if the BattleGroundHealer config is set or Restoration spec
         * Healing done only if in a battleground or in a group and not group leader
         */
        private bool IsHealer()
        {
            bool bHealSpecification = _cfg.GroupHealer || eType == ShamanType.Resto;
            bool bRaidHealer = _pvp.IsBattleground();
            bool bPartyHealer = !_me.IsGroupLeader && (_me.PartyMembers.Count > 0);
            return bHealSpecification && (bRaidHealer || bPartyHealer);
        }

        private bool IsTargetingMeOrMyStuff(WoWUnit unit)
        {
            return
                (unit != null && unit.CurrentTarget != null)
                && (unit.IsTargetingMe || unit.IsTargetingPet || unit.CurrentTarget.CreatedBy == _me.Guid || unit.CurrentTarget.SummonedByGuid == _me.Guid);
        }

        /*
         * Reports whether we to stop for any Weapon Buffs
         */
        private bool IsWeaponEnhanceNeeded(out bool needMainhand, out bool needOffhand)
        {
            needMainhand = false;
            needOffhand = false;

            if (!IsInGame)
                return false;

            if (!Safe_KnownSpell("Windfury Weapon")
                 && !Safe_KnownSpell("Flametongue Weapon")
                 && !Safe_KnownSpell("Rockbiter Weapon")
                )
            {
                Dlog("No weapon enhancements trained yet -- enhancements not needed");
                return false;
            }


            List<string> weaponEnchants = Lua.LuaGetReturnValue("return GetWeaponEnchantInfo()", "hawker.lua");

            if (Equals(null, weaponEnchants))
                return false;

            needMainhand = weaponEnchants[0] == "" || weaponEnchants[0] == "nil";
            if (IsOffhandWeapon())
                needOffhand = weaponEnchants[3] == "" || weaponEnchants[3] == "nil";


            if (needMainhand)
                Dlog("Mainhand weapon {0} needs enchancement", _me.Mainhand.Name);

            if (needOffhand)
                Dlog("Offhand weapon {0} needs enhancement", _me.Offhand == null ? "(none)" : _me.Offhand.Name);

            return needMainhand || needOffhand;
        }

        /*
         * Checks to see if Off Hand slot currently has a weapon in it.
         * Uses a timer so that LUA call is not made more than once a minute
         */
        private Stopwatch _offhandCheck = new Stopwatch();
        private bool _offhandLastResult = false;

        private bool IsOffhandWeapon()
        {
            if (!IsInGame)
                return false;

            if (_me.Offhand == null)
                _offhandLastResult = false;
            else if (!Safe_KnownSpell("Dual Wield"))
                _offhandLastResult = false;
            else if (_offhandCheck.ElapsedMilliseconds == 0)
            {
                List<string> offhandWeapons = Lua.LuaGetReturnValue("return OffhandHasWeapon()", "hawker.lua");

                if (Equals(null, offhandWeapons))
                    return false;

                string isOffhandWeapon = offhandWeapons[0];

                Dlog("return from OffhandHasWeapon() = '" + isOffhandWeapon + "'");

                if (isOffhandWeapon == null || isOffhandWeapon == "" || isOffhandWeapon == "nil")
                    _offhandLastResult = false;
                else
                    _offhandLastResult = true;

                _offhandCheck.Start();
            }
            else if (_offhandCheck.ElapsedMilliseconds > 60000)
            {
                _offhandCheck.Reset();
            }

            return _offhandLastResult;
        }

        /*
         * CastBuff
         *      sBuff - name of buff as appears in buff/debuff list
         *      sSpell - name of spell that causes buff
         * 
         * Totems in particular have a different name than the buff they cast.
         * The name of the totem is passed as the "spell" and the name of the
         * buff it creates is passed separately
         */
        private bool CastBuff(string sSpell)
        {
            return CastBuff(sSpell, sSpell);
        }

        private bool CastBuff(string sSpell, string sBuff)
        {
            if (!Safe_KnownSpell(sSpell))
            {
                Dlog("attempt to cast unknown spell: " + sSpell);
                return false;
            }

            if (_me.Buffs.ContainsKey(sBuff))
            {
                // Dlog("buff already active: " + sBuff);
                return true;
            }

            return Safe_CastSpell(sSpell);
        }


        private bool HaveValidTarget()
        {
            return Safe_IsValid(_me.CurrentTarget)
                && _me.CurrentTarget != null
                && _me.GotTarget
                && _me.CurrentTarget.IsAlive
                && (_me.CurrentTarget.TaggedByMe || !_me.CurrentTarget.Tagged)
                ;
            //                && !Styx.Logic.Blacklist.Contains( t.Guid );
        }

        /*
         * CurrentTargetInMeleeDistance()
         * 
         * Check to see if CurrentTarget is within melee range.  This allows
         * recognizing when a pulled mob is close enough to melee as well as 
         * as when a pulled mob moves out of melee
         */
        private bool CurrentTargetInMeleeDistance()
        {
            if (_me.CurrentTarget.Distance < 5.0)
                return true;

            return false;
        }

        /*
         * CurrentTargetInRangedDistance()
         * 
         * Check to see if CurrentTarget is within melee range.  This allows
         * recognizing when a pulled mob is close enough to melee as well as 
         * as when a pulled mob moves out of melee
         */
        private bool CurrentTargetInRangedDistance()
        {
            if (Safe_IsValid(_me.CurrentTarget) && _me.CurrentTarget.Distance < 30)
                return true;

            return false;
        }

        /*
         * trys to determine if 'unit' points to a mob that is a Caster.  Currently
         * only see .Class as being able to help determine.  the big question marks
         * are Druids and Shamans for grinding purposes, so even though we try
         * to guess we still make routines able to adapt on pulls, etc. to fact
         * mob may not behave like we guessed
         */
        private bool IsCaster(WoWUnit unit)
        {
            bool isCaster = false;

            switch (unit.Class.ToString().ToLower())
            {

                default:
                    Slog("UKNOWN MOB CLASS:  CONTACT CC DEVELOPER:  Please provide the class name '" + unit.Class + "' and name [" + unit.Name + "]");
                    break;

                case "paladin":
                case "druid":
                case "rogue":
                case "warrior":
                case "death knight":
                    break;

                case "mage":
                case "warlock":
                case "shaman":
                case "priest":
                    isCaster = true;
                    break;
            }

            // following test added because of "Unyielding Sorcerer" in Hellfire
            // .. having a class of Paladin, yet they are clearly ranged casters

            if (!isCaster)
            {
                if (unit.Name.ToLower().Contains("sorcerer"))
                {
                    isCaster = true;
                }
            }

            return isCaster;
        }

        private void AddToBlacklist(ulong guidMob)
        {
            if (Styx.Logic.Blacklist.Contains(guidMob))
                Dlog("already blacklisted mob: " + guidMob);
            else
            {
                Styx.Logic.Blacklist.Add(guidMob, System.TimeSpan.FromHours(24));
                Dlog("blacklisted mob: " + guidMob);
            }
        }

        /*
         * CheckForItem()
         * 
         * Lookup an item by its item # 
         * return null if not found
         */
        private WoWItem CheckForItem(List<uint> listId)
        {
            foreach (WoWItem item in ObjectManager.ItemObjectList.Values)
            {
                if (listId.Contains(item.Entry))
                {
                    return item;
                }
            }
            return null;
        }

        #endregion


        #region REST

        public bool NeedRest
        {
            get
            {
                if (!Equals(null, ObjectManager.Me) && ObjectManager.Me.MaxHealth < 1)
                {
                    Logging.Write("Shamwow not in game.");
                    return false;
                }

                if (ObjectManager.Me.LoadingScreen)
                {
                    Logging.Write("Shamwow loading screen visible.");
                    return false;
                }

                if (IsHealer() != _lastHealerCheck)
                {
                    _needInitialization = true;
                    return true;
                }

                if (IsHealer())
                {
                    if (RaidHeal())
                    {
                        return false;
                    }
                }

                if (_WereTotemsSet)
                {
                    Dlog("Need rest: _WereTotemsSet = true");
                    return true;
                }

                if (!_me.Mounted)
                {
                    if (IsWeaponEnhanceNeeded(out _castMainHandEnchant, out _castOffHandEnchant))
                    {
                        Dlog("Need rest: true, IsWeaponEnhanceNeeded mh:{0} oh:{1}", _castMainHandEnchant, _castOffHandEnchant);
                        return true;
                    }

                    if (ShieldBuffNeeded(true))
                    {
                        Dlog("Need rest: true, ShieldBuffNeeded");
                        return true;
                    }
                }

                if (_me.HealthPercent <= _cfg.RestHealthPercent)
                {
                    Dlog("Need rest: true, CurrentHealth {0:F1}% less than RestHealthPercent {1:F1}%", _me.HealthPercent, _cfg.RestHealthPercent);
                    return true;
                }

                if (_me.ManaPercent <= _cfg.RestManaPercent)
                {
                    Dlog("Need rest: true, CurrentMana {0:F1}% less than RestManaPercent {1:F1}%", _me.ManaPercent, _cfg.RestManaPercent);
                    return true;
                }

                if (!Logic.Mount.UseMount && !_me.Mounted)
                {
                    if (Safe_KnownSpell("Ghost Wolf") && !InGhostwolfForm() && _me.IsOutdoors)
                    {
                        CheckForAdds();
                        if (_distClosestEnemy >= _cfg.DistanceForGhostWolf || (_distClosestEnemy > 25 && _cfg.PullType == ConfigValues.TypeOfPull.Body))
                        {
                            Dlog("Need rest: true, Ghost Wolf: closest enemy is " + _distClosestEnemy.ToString("F2") + " yards");
                            _castGhostWolfForm = true;
                            return true;
                        }
                    }
                }

                return false;
            }
        }

        public void Rest()
        {
            Dlog("Resting at " + _me.HealthPercent + "% health,  " + _me.ManaPercent + "% mana");
            RestLogic();
            Dlog("Done Resting");
        }

        public void RestLogic()
        {
            if (!IsInGame)
                return;

            ReclaimTotemsForMana();

            // try to heal several times (quicker than eating)
            int healAttemptsLeft = 3;
            while (healAttemptsLeft > 0 && _me.HealthPercent < _cfg.RestHealthPercent && _me.ManaPercent > _cfg.RestManaPercent)
            {
                healAttemptsLeft--;
                HealMyself();
                Thread.Sleep(100);
            }

            if (_needInitialization)
            {
                _needInitialization = false;
                _lastHealerCheck = IsHealer();
                Lua.DoString("CancelItemTempEnchantment(1)");
                Lua.DoString("CancelItemTempEnchantment(2)");
            }

            ShamanBuffs(true);

            // now eat/drink if needed
            if (_me.HealthPercent < _cfg.RestHealthPercent)
            {
                Logic.Common.Rest.Feed();
            }

            if (_me.ManaPercent < _cfg.RestManaPercent)
            {
                Logic.Common.Rest.Feed();
            }

            if (_castGhostWolfForm)
            {
                GhostWolf();
                _castGhostWolfForm = false;
            }

            // do this again in case they glyph or spec into longer range
            WoWSpell spell = SpellManager.KnownSpells["Lightning Bolt"];
            _distForRangedPull = spell.MaxRange - 4;
        }

        private bool InGhostwolfForm()
        {
            return _me.Buffs.ContainsKey("Ghost Wolf");
        }

        private bool GhostWolf()
        {
            bool b = false;

            if (!_me.IsOutdoors || _me.IsIndoors)
                ;
            if (!Safe_KnownSpell("Ghost Wolf"))
                ;
            else
            {
                Safe_StopMoving();
                Thread.Sleep(100);
                b = Safe_CastSpell("Ghost Wolf");
            }

            return b;
        }

        #endregion

        #region HANDLE FALLING

        public void HandleFalling() { }

        #endregion

        #region Buffs

        /*
         * Note:  the following are interface functions that need to be implemented by the class.  
         * They are not used presently in the ShamWOW implementation.  Buffs are handled within the 
         * flow of the current Pull() and Combat() event handlers
         */
        public bool NeedPreCombatBuffs { get { return false; } }
        public void PreCombatBuff() { }

        public bool NeedPullBuffs { get { return false; } }
        public void PullBuff() { }

        public bool NeedCombatBuffs { get { return false; } }
        public void CombatBuff() { }


        public void ShamanBuffs(bool atRest)
        {
            // Shield Twisting:  Cast based upon amount of Mana available
            ShieldTwisting(atRest);

            if ((AllowNonHealSpells() || atRest) && IsWeaponEnhanceNeeded(out _castMainHandEnchant, out _castOffHandEnchant))
            {
                // Slog("Main Hand:  " + _me.Mainhand.Name);
                // Slog("Off Hand:  " + _me.Offhand.Name);

                // main hand weapon
                if (!_castMainHandEnchant)
                    ;
                else if (IsHealer() && Safe_KnownSpell("Earthliving Weapon"))
                    Safe_CastSpell("Earthliving Weapon");
                else if (eType == ShamanType.Elemental && Safe_KnownSpell("Flametongue Weapon"))
                    Safe_CastSpell("Flametongue Weapon");
                else if (Safe_KnownSpell("Windfury Weapon"))
                    Safe_CastSpell("Windfury Weapon");
                else if (Safe_KnownSpell("Flametongue Weapon"))
                    Safe_CastSpell("Flametongue Weapon");
                else if (Safe_KnownSpell("Rockbiter Weapon"))
                    Safe_CastSpell("Rockbiter Weapon");

                // off hand weapon
                if (!_castOffHandEnchant || !IsOffhandWeapon())
                    ;
                else if (IsHealer() && Safe_KnownSpell("Earthliving Weapon"))
                    Safe_CastSpell("Earthliving Weapon");
                else if (_cfg.FlametongueOnOffhand && Safe_KnownSpell("Flametongue Weapon") && Safe_KnownSpell("Lava Lash"))
                    Safe_CastSpell("Flametongue Weapon");
                else if (Safe_KnownSpell("Windfury Weapon"))
                    Safe_CastSpell("Windfury Weapon");
                else if (Safe_KnownSpell("Flametongue Weapon"))
                    Safe_CastSpell("Flametongue Weapon");
                else if (Safe_KnownSpell("Rockbiter Weapon"))
                    Safe_CastSpell("Rockbiter Weapon");

                _castMainHandEnchant = false;
                _castOffHandEnchant = false;

                Thread.Sleep(500);
            }
        }
        #endregion


        #region Heal

        /*
         * NeedHeal()
         * 
         * return a true/false indicating whether the Heal() event handler should be called by the
         * HonorBuddy engine.
         */
        public bool NeedHeal
        {
            get
            {
                double threshhold = _cfg.NeedHealHealthPercent + (countEnemy > 1 ? 10 : 0);
                return _me.HealthPercent <= threshhold;
            }
        }

        /*
         * Heal()
         * 
         * Called if a heal is needed.
         */
        public void Heal()
        {

        }

        private bool HealMyself()
        {
            bool healCast = false;
            double healthBase = _me.HealthPercent;
            Stopwatch lagTimer = new Stopwatch();

            if (countEnemy == 1
                && _countMeleeEnemy == 1
                && _me.GotTarget
                && _me.HealthPercent > _cfg.CombatHealthPercent
                && _me.CurrentTarget.HealthPercent < 10.0
                && _me.CurrentTarget.IsAlive
                )
            {
                Slog("^Enemy weak at {0:F0}%, skipping heal", _me.CurrentTarget.HealthPercent);
                return healCast;
            }

            Slog("^Heal @ {0:F0}% hlth-{1:F0}% mana", _me.HealthPercent, _me.ManaPercent);
            Safe_StopMoving();

            // if under stress, provide special handling
            if (!AllowNonHealSpells() && _countMeleeEnemy > 0 && HaveValidTarget())
            {
                Warstomp();
            }

            // if no other heal cast yet, throw a Healing Wave
            healCast = HealingWave();

            // if no other heal successful (maybe low mana) try a Lesser
            if (!healCast)
                healCast = LesserHealingWave();

            if (healCast)
            {
                // DEAL WITH Health% UPDATE LAG ---
                // .. Make sure before we leave here that if a heal was 
                // .. cast, the .HealthPercent value has been updated
                // .. so rest of code can make informed decisions
                lagTimer.Start();
                while (lagTimer.ElapsedMilliseconds < 800 && (healthBase + 9) > _me.HealthPercent)
                {
                    Thread.Sleep(100);
                }
            }

            return healCast;
        }

        private bool AllowNonHealSpells()
        {
            return _me.ManaPercent > _cfg.CombatManaPercent && _me.HealthPercent > _cfg.CombatHealthPercent;
        }


        /*
         * Cleanse()
         * 
         * Called cleanse if needed.
         */
        public void Cleanse()
        {
            if (_totemName[TOTEM_WATER] != "Cleansing Totem")
            {
                if (Safe_KnownSpell("Cure Toxins"))
                {
                    // should be able to check in buffs for .Harmful and if name
                    // contains substring poison
                    // _me.Buffs[].
                    foreach (KeyValuePair<string, WoWAura> buff in _me.Buffs)
                    {
                        if (buff.Value.IsHarmful && buff.Value.CreatorGuid != _me.Guid)
                        {
                            if (buff.Value.Name.Contains("Poison"))
                            {
                                WoWAura a = buff.Value;
                                Slog("   Dbuff: " + a.Name + "(" + a.SpellId + ")"
                                    + (a.IsActive ? " is Active" : "")
                                    + "  apply-type: " + a.ApplyAuraType.ToString()
                                    );
                            }
                        }
                    }
                }
            }
        }

        #endregion

        #region Pull

        /*
         * Pull()
         * 
         * Currently always do a ranged pull from '_distForRangedPull' way
         * If HB has given us a mob to pull that is further away, we will
         * run towards him up to within '_distForRangedPull' 
         * 
         */

        public void Pull()
        {
            Dlog("Entered Pull");
            PullLogic();
            Dlog("Exited Pull");
        }

        public void PullLogic()
        {
            if (IsHealer())
            {
                if (RaidHeal())
                    return;
            }

            if (_me.CurrentTarget == null)
            {
                Slog("HB gave (null) pull target");
                return;
            }

            if (!HaveValidTarget())
            {
                Slog("HB gave invalid pull target: " + _me.CurrentTarget.Name + "[" + _me.CurrentTarget.Level + "]");
                return;
            }

            if (Styx.Logic.Blacklist.Contains(_me.CurrentTargetGuid))
            {
                Slog("Skipping pull of blacklisted mob: " + _me.CurrentTarget.Name + "[" + _me.CurrentTarget.Level + "]");
                _me.ClearTarget();
                Thread.Sleep(250);
                return;
            }

            if (_me.CurrentTarget.Elite)
            {
                Slog(">>> AVOID ELITE: " + _me.CurrentTarget.Name + "[" + _me.CurrentTarget.Level + "] at " + _me.CurrentTarget.Distance.ToString("F1") + " yds");
                AddToBlacklist(_me.CurrentTarget.Guid);
                _me.ClearTarget();
                Thread.Sleep(250);
                return;
            }

            if (_pvp.IsBattleground())
            {
                if (_me.GotTarget && _me.CurrentTarget.Mounted && _me.CurrentTarget.IsHostile)
                {
                    Styx.Logic.Blacklist.Add(_me.CurrentTarget.Guid, System.TimeSpan.FromSeconds(4));
                    _me.ClearTarget();
                    return;
                }
            }

            if (_me.CurrentTarget.Guid == _pullTargGuid)
                return;     // ignore redundant Pull if we get one

            CheckForAdds();

            // reset state values we use to determine what point we are at in 
            //  .. in transition from Pull() to Combat()
            //---------------------------------------------------------------------------
            _pullTargHasBeenInMelee = false;
            _TotemCheckTimer.Reset();    //  reset timer for Totem checking, but don't start (leave at 0 ms)

            _pullTimer.Reset();          //  reset timer for new pull 
            _pullTimer.Start();          //  start timer ticking

            // call correct pull subroutine here
            if (HaveValidTarget())
            {
                if (eType != ShamanType.Enhance)
                    PullElemental();
                else
                {
                    switch (_cfg.PullType)
                    {
                        case ConfigValues.TypeOfPull.Auto:
                            PullAuto();
                            break;
                        case ConfigValues.TypeOfPull.Body:
                            PullBody();
                            break;
                        case ConfigValues.TypeOfPull.Fast:
                            PullFast();
                            break;
                        case ConfigValues.TypeOfPull.Ranged:
                            PullRanged();
                            break;
                    }
                }
            }

            if (!HaveValidTarget())
            {
                Slog("Don't have HaveValidTarget, so clearing target -- " + _me.CurrentTarget.Name + "[" + _me.CurrentTarget.Level + "]");
                _me.ClearTarget();
                return;
            }

            if (!_me.IsAutoAttacking)
            {
                Dlog("** Auto-Attack started in Pull");
                AutoAttack();
            }

            if (_pullTimer.ElapsedMilliseconds > _cfg.PullTimeout && !(_me.CurrentTarget.TaggedByMe || IsTargetingMeOrMyStuff(_me.CurrentTarget)))
            {
                Styx.Logic.Blacklist.Add(_me.CurrentTarget.Guid, System.TimeSpan.FromSeconds(30));
                Slog("Pull TIMED OUT for: " + _me.CurrentTarget.Class + "-" + _me.CurrentTarget.Name + "[" + _me.CurrentTarget.Level + "] after " + _pullTimer.ElapsedMilliseconds + " ms -- blacklisted for 30 secs");
                _me.ClearTarget();
                Thread.Sleep(250);
                return;
            }

            _pullTargGuid = _me.CurrentTarget.Guid;

            Dlog("distance after pull: " + _me.CurrentTarget.Distance.ToString("F2"));
            CheckForPlayers();
        }


        public void PullAuto()
        {
            if (!HaveValidTarget())
                return;

            Dlog(">>> AUTO PULL: " + _me.CurrentTarget.Class + "-" + _me.CurrentTarget.Name + "[" + _me.CurrentTarget.Level + "] at " + _me.CurrentTarget.Distance.ToString("F1") + " yds");
            if (!_pvp.IsBattleground())
            {
                if (IsCaster(_me.CurrentTarget))
                    PullBody();
                else
                    PullRanged();
            }
            else
            {
                if (IsHealer())
                    PullRanged();
                else
                    PullFast();
            }
        }


        public void PullBody()
        {
            Slog(">>> BODY PULL: " + _me.CurrentTarget.Class + "-" + _me.CurrentTarget.Name + "[" + _me.CurrentTarget.Level + "] at " + _me.CurrentTarget.Distance.ToString("F1") + " yds");

            while (HaveValidTarget() && !CurrentTargetInMeleeDistance() && _pullTimer.ElapsedMilliseconds < _cfg.PullTimeout)
            {
                Point newPoint = WoWMovement.CalculatePointFrom(_me.CurrentTarget.Location, (float)_distForMeleePull);
                Navigator.MoveTo(newPoint);      // WoWMovement.ClickToMove(newPoint);
                Thread.Sleep(250);

                if (HaveValidTarget() && _me.CurrentTarget.Distance < 8)
                {
                    if (_me.Mounted)
                        Safe_Dismount();

                    if (!WoWMovement.IsFacing)
                        WoWMovement.Face();

                    ShockOpener(false);
                }
            }
        }


        public void PullFast()
        {
            Slog(">>> FAST PULL: " + _me.CurrentTarget.Class + "-" + _me.CurrentTarget.Name + "[" + _me.CurrentTarget.Level + "] at " + _me.CurrentTarget.Distance.ToString("F1") + " yds");

            while (HaveValidTarget() && !CurrentTargetInMeleeDistance() && _pullTimer.ElapsedMilliseconds < _cfg.PullTimeout)
            {
                Point newPoint = WoWMovement.CalculatePointFrom(_me.CurrentTarget.Location, (float)_distForMeleePull);
                Navigator.MoveTo(newPoint);      // WoWMovement.ClickToMove(newPoint);
                Thread.Sleep(250);

                if (!WoWMovement.IsFacing)
                    WoWMovement.Face();

                if (HaveValidTarget())
                {
                    if (_me.CurrentTarget.Distance < 24)
                    {
                        ShockOpener(true);
                    }

                    if (HaveValidTarget() && _me.CurrentTarget.Distance < 8)
                    {
                        if (_me.Mounted)
                            Safe_Dismount();
                    }

                    if (CurrentTargetInMeleeDistance() && _me.IsMoving)
                    {
                        WoWMovement.MoveStop();
                    }
                }
            }
        }


        public void PullRanged()
        {
            bool bHaveInstantPullAttack = Safe_KnownSpell("Earth Shock");
            bool bHaveWaterShield = Safe_KnownSpell("Water Shield");
            int cntAttacksRemaining = _cfg.MaxNumRangedAttacks;
            double prevDistance = 999.99f;

            //            if (!bHaveWaterShield)
            //            {
            //                bHaveInstantPullAttack = false;
            //            }

            Slog(">>> RANGE PULL: " + _me.CurrentTarget.Name + "[" + _me.CurrentTarget.Level + "] at " + _me.CurrentTarget.Distance.ToString("F1") + " yds");

            //  while (_me.CurrentTarget.Distance >= _distForRangedPull || !(_me.CurrentTarget.Tagged || _me.CurrentTarget.IsTargetingMe))
            while (HaveValidTarget() && !CurrentTargetInMeleeDistance())
            {
                // pursuit loop - chase to within Ranged attack distance then stops...  
                // .. do this here in case mob moves away during attack so we can chase and stay in range
                while (HaveValidTarget() && !CurrentTargetInRangedDistance() && _pullTimer.ElapsedMilliseconds < _cfg.PullTimeout)
                {
                    Dlog("At1 " + _pullTimer.ElapsedMilliseconds + "ms dist from " + _me.CurrentTarget.Name + ": " + _me.Location.Distance(_me.CurrentTarget.Location).ToString("F2")
                        + "  valtrg: " + HaveValidTarget()
                        + "  tagged: " + _me.CurrentTarget.Tagged
                        + "  tagbme: " + _me.CurrentTarget.TaggedByMe
                        + "  tgt-me: " + IsTargetingMeOrMyStuff(_me.CurrentTarget)
                        );

                    Point newPoint = WoWMovement.CalculatePointFrom(_me.CurrentTarget.Location, (float)_distForRangedPull);
                    Navigator.MoveTo(newPoint);      // WoWMovement.ClickToMove(newPoint);
                    Thread.Sleep(250);
                }

                Dlog("At2 " + _pullTimer.ElapsedMilliseconds + "ms dist from " + _me.CurrentTarget.Name + ": " + _me.Location.Distance(_me.CurrentTarget.Location).ToString("F2")
                    + "  valtrg: " + HaveValidTarget()
                    + "  tagged: " + _me.CurrentTarget.Tagged
                    + "  tagbme: " + _me.CurrentTarget.TaggedByMe
                    + "  tgt-me: " + IsTargetingMeOrMyStuff(_me.CurrentTarget)
                    );

                if (!HaveValidTarget() || _pullTimer.ElapsedMilliseconds > _cfg.PullTimeout)
                    break;

                // if we are moving and haven't cast Pull Attack opener yet, then Stop moving
                if (CurrentTargetInRangedDistance())
                {
                    if (_me.Mounted)
                        Safe_Dismount();
                    WoWMovement.Face();

                    Thread.Sleep(100);
                    if (_me.CurrentTarget.Distance >= prevDistance)
                    {
                        Dlog("Range pull Target is standing still or moving away");
                    }

                    // if last attack and have instant, then use it
                    if (bHaveInstantPullAttack && cntAttacksRemaining == 1 && ShockOpener(false))
                    {
                        cntAttacksRemaining--;
                        Thread.Sleep(150);
                    }
                    // otherwise throw some lightning at them
                    else if (cntAttacksRemaining > 0)
                    {
                        Safe_StopMoving();
                        if (LightningBolt())
                        {
                            cntAttacksRemaining--;
                            Thread.Sleep(_cfg.waitWaitAfterRangedPull);  // wait # of milliseconds defined in setting
                        }
                    }

                    prevDistance = _me.CurrentTarget.Distance;
                }
            }

            Dlog("At3 " + _pullTimer.ElapsedMilliseconds + "ms dist from " + _me.CurrentTarget.Name + ": " + _me.Location.Distance(_me.CurrentTarget.Location).ToString("F2")
                + "  valtrg: " + HaveValidTarget()
                + "  tagged: " + _me.CurrentTarget.Tagged
                + "  tagbme: " + _me.CurrentTarget.TaggedByMe
                + "  tgt-me: " + IsTargetingMeOrMyStuff(_me.CurrentTarget)
                );

        }



        public void PullElemental()
        {
            bool bHaveInstantPullAttack = Safe_KnownSpell("Earth Shock");
            bool bHaveWaterShield = Safe_KnownSpell("Water Shield");
            double prevDistance = 999.99f;
            int cntAttacks = 0;

            //            if (!bHaveWaterShield)
            //            {
            //                bHaveInstantPullAttack = false;
            //            }

            Slog(">>> ELEMENTAL PULL: " + _me.CurrentTarget.Name + "[" + _me.CurrentTarget.Level + "] at " + _me.CurrentTarget.Distance.ToString("F1") + " yds");

            Dlog("At1 " + _pullTimer.ElapsedMilliseconds + "ms dist from " + _me.CurrentTarget.Name + ": " + _me.Location.Distance(_me.CurrentTarget.Location).ToString("F2")
                + "  valtrg: " + HaveValidTarget()
                + "  tagged: " + _me.CurrentTarget.Tagged
                + "  tagbme: " + _me.CurrentTarget.TaggedByMe
                + "  tgt-me: " + IsTargetingMeOrMyStuff(_me.CurrentTarget)
                );

            //  while (_me.CurrentTarget.Distance >= _distForRangedPull || !(_me.CurrentTarget.Tagged || _me.CurrentTarget.IsTargetingMe))
            while (HaveValidTarget() && !_me.CurrentTarget.TaggedByMe)
            {
                // pursuit loop - chase to within Ranged attack distance then stops...  
                // .. do this here in case mob moves away during attack so we can chase and stay in range
                while (HaveValidTarget() && !CurrentTargetInRangedDistance() && _pullTimer.ElapsedMilliseconds < _cfg.PullTimeout)
                {
                    Point newPoint = WoWMovement.CalculatePointFrom(_me.CurrentTarget.Location, (float)_distForRangedPull);

                    if (WorldManager.IsInLineOfSight(_me.Location, newPoint))
                        WoWMovement.ClickToMove(newPoint);
                    else
                        Navigator.MoveTo(newPoint);      // WoWMovement.ClickToMove(newPoint);

                    Thread.Sleep(250);
                }

                if (_me.Mounted)
                    Safe_Dismount();

                if (!WoWMovement.IsFacing)
                    WoWMovement.Face();

                Dlog("At2 " + _pullTimer.ElapsedMilliseconds + "ms dist from " + _me.CurrentTarget.Name + ": " + _me.Location.Distance(_me.CurrentTarget.Location).ToString("F2")
                    + "  valtrg: " + HaveValidTarget()
                    + "  tagged: " + _me.CurrentTarget.Tagged
                    + "  tagbme: " + _me.CurrentTarget.TaggedByMe
                    + "  tgt-me: " + IsTargetingMeOrMyStuff(_me.CurrentTarget)
                    );

                if (!HaveValidTarget() || _pullTimer.ElapsedMilliseconds > _cfg.PullTimeout)
                    break;

                // if we are moving and haven't cast Pull Attack opener yet, then Stop moving
                if (CurrentTargetInRangedDistance())
                {
                    Safe_StopMoving();

                    if (_me.CurrentTarget.Distance >= prevDistance)
                    {
                        Dlog("Range pull Target is standing still or moving away");
                    }

                    // if last attack and have instant, then use it
                    if (bHaveInstantPullAttack && 1 == (cntAttacks & 1) && ShockOpener(false))
                    {
                        cntAttacks++;
                        // Thread.Sleep(150);
                    }
                    // otherwise throw some lightning at them
                    else
                    {
                        if (LightningBolt())
                        {
                            cntAttacks++;
                            // Thread.Sleep(150);  // wait # of milliseconds defined in setting
                        }
                    }

                    prevDistance = _me.CurrentTarget.Distance;
                }
            }

            Dlog("At3 " + _pullTimer.ElapsedMilliseconds + "ms dist from " + _me.CurrentTarget.Name + ": " + _me.Location.Distance(_me.CurrentTarget.Location).ToString("F2")
                + "  valtrg: " + HaveValidTarget()
                + "  tagged: " + _me.CurrentTarget.Tagged
                + "  tagbme: " + _me.CurrentTarget.TaggedByMe
                + "  tgt-me: " + IsTargetingMeOrMyStuff(_me.CurrentTarget)
                );
        }


        #endregion

        #region Combat

        /*
         * Combat()
         * 
         */
        public void Combat()
        {
            Dlog("Entered Combat");
            try
            {
                CombatLogic();
            }
            catch (Exception e)
            {
                Dlog("HB EXCEPTION in Combat():  " + e.ToString());
            }
            Dlog("Exiting Combat");
        }

        public void CombatLogic()
        {
            if (IsHealer())
            {
                if (RaidHeal())
                {
                    return;
                }
            }

            if (!combatChecks())
                return;

            if (_me.CurrentTarget.Tagged && !_me.CurrentTarget.TaggedByMe && !IsTargetingMeOrMyStuff(_me.CurrentTarget))
            {
                Dlog("Combat Target is tagged by another player -- let them have it");
                _me.ClearTarget();
                return;
            }

            // check if we agroed a mob unintentionally
            if (_pullTargGuid != _me.CurrentTarget.Guid)
            {
                Safe_StopMoving();
                Slog(">>> ADD: " + _me.CurrentTarget.Class + "-" + _me.CurrentTarget.Name + "[" + _me.CurrentTarget.Level + "] at " + _me.CurrentTarget.Distance.ToString("F1") + " yds");
                _pullTargGuid = _me.CurrentTarget.Guid;
                _pullTargHasBeenInMelee = false;
                _pullTimer.Reset();
                _pullTimer.Start();
            }

            if (_pullTimer.ElapsedMilliseconds > 20000 && _me.CurrentTarget.HealthPercent > 95)
            {
                Slog("Evade bugged mob detected: blacklisting: " + _me.CurrentTarget.Class + "-" + _me.CurrentTarget.Name + "[" + _me.CurrentTarget.Level + "]");
                StopAutoAttack();
                Styx.Logic.Blacklist.Add(_me.CurrentTarget.Guid, System.TimeSpan.FromHours(1));
                _me.ClearTarget();
                Thread.Sleep(500);
                return;
            }

            /*
             * 3 Cases of Mob Movement to Handle
             * 
             * 1. Melee (they'll come to us)
             *      means we are done moving... melee is the objective
             * 2. Ranged (we have to go to them)
             *      hasn't been in melee yet, so move to them
             * 3. Runner (could have started as either 1 or 2)
             *      has been in melee, but now fleeing at low health
             */
            Point myStartingPoint = _me.Location;       // save pt I was before pull movement

            // has not been in melee reach yet, so chase it
            if (!CurrentTargetInMeleeDistance() && !_pullTargHasBeenInMelee && eType == ShamanType.Enhance)
            {
                Stopwatch pursuitTimer = new Stopwatch();
                pursuitTimer.Start();

                // chase until in melee range or for 8 seconds
                Dlog("running to mob " + _me.CurrentTarget.Distance.ToString("F2") + " away");
                while (!CurrentTargetInMeleeDistance() && pursuitTimer.ElapsedMilliseconds < 5000)
                {
                    // double distMove = _me.Location.Distance(_me.CurrentTarget.Location) / 2.0f;
                    Point newPoint = WoWMovement.CalculatePointFrom(_me.CurrentTarget.Location, (float)_distForMeleePull);
                    Navigator.MoveTo(newPoint);      // WoWMovement.ClickToMove(newPoint);
                    Thread.Sleep(250);
                    FlameShock(false);
                }

                // if still not in melee range then give up
                if (!CurrentTargetInMeleeDistance())
                {
                    Styx.Logic.Blacklist.Add(_me.CurrentTarget.Guid, System.TimeSpan.FromSeconds(30));
                    Slog("Combat pursuit timed out for: " + _me.CurrentTarget.Name + "[" + _me.CurrentTarget.Level + "] after " + _pullTimer.ElapsedMilliseconds + " ms -- blacklisted for 30 secs");
                    _me.ClearTarget();
                    Thread.Sleep(250);
                    _pullTimer.Reset();
                    return;
                }
            }
            // logic for non-Enhancement Shaman
            else if (!CurrentTargetInRangedDistance() && !_pullTargHasBeenInMelee)
            {
                Stopwatch pursuitTimer = new Stopwatch();
                pursuitTimer.Start();

                // chase until in ranged distance or for 8 seconds
                Dlog("running to mob " + _me.CurrentTarget.Distance.ToString("F2") + " away");
                while (!CurrentTargetInRangedDistance() && pursuitTimer.ElapsedMilliseconds < 6000)
                {
                    // double distMove = _me.Location.Distance(_me.CurrentTarget.Location) / 2.0f;
                    Point newPoint = WoWMovement.CalculatePointFrom(_me.CurrentTarget.Location, (float)_distForRangedPull);
                    Navigator.MoveTo(newPoint);      // WoWMovement.ClickToMove(newPoint);
                    Thread.Sleep(250);
                    FlameShock(false);
                }

                // if still not in ranged distance then give up
                if (!CurrentTargetInRangedDistance())
                {
                    Styx.Logic.Blacklist.Add(_me.CurrentTarget.Guid, System.TimeSpan.FromSeconds(30));
                    Slog("Combat pursuit timed out for: " + _me.CurrentTarget.Name + "[" + _me.CurrentTarget.Level + "] after " + _pullTimer.ElapsedMilliseconds + " ms -- blacklisted for 30 secs");
                    _me.ClearTarget();
                    Thread.Sleep(250);
                    _pullTimer.Reset();
                    return;
                }
            }

            CheckForAdds();

            // WE MADE IT!!!! Raise a flag that we are definately in melee range
            _pullTargHasBeenInMelee = true;

            Dlog("distance in combat: " + _me.CurrentTarget.Distance.ToString("F2"));

            if (_me.IsMoving)
                Safe_StopMoving();

            if (!WoWMovement.IsFacing)
                WoWMovement.Face();

            if (!_me.IsAutoAttacking && _me.GotTarget && !_me.CurrentTarget.Dead)
            {
                Dlog("** Auto-Attack started in Combat");
                AutoAttack();
            }

            if (NeedHeal)
            {
                if (!AllowNonHealSpells())
                {
                    if (!GiftOfTheNaaru())
                    {
                        Lifeblood();
                    }
                }

                // if we are critical on Mana and low on Health, use a potion to buy some time
                if (!AllowNonHealSpells())
                {
                    UsePotionIfAvailable();
                }
            }

            // ok, reevaluate if still need healing in hopes we can attack
            if (NeedHeal)
            {
                HealMyself();
            }

            InterruptEnemyCast();

            if (eType == ShamanType.Enhance)
                CombatMelee();
            else
                CombatElemental();

            combatChecks();
        }


        #region Combat Styles

        /*
         * CombatMelee()
         * 
         * Rotation: Lightning Bolt, until the mob is near you, then spam Earth Shock while 
         * auto attacking.  Shield Twist between Water Shield and Lightning Shield.  Keep 
         * Windfury Weapon up, use Flametongue if not trained, and Rockbiter if no other choice
         * 
         * Looks redundant, but we use combatChecks() and AllowNonHealSpells() over and over.  They
         * are state checking functions and the conditions they check will change during the 
         * running of this function.  They need to be measured immediately before using an
         * ability.
         */
        private void CombatMelee()
        {
            bool bUnderStress = countEnemy > 1 || _OpposingPlayerGanking || _BigScaryGuyHittingMe;

            // use Shamanistic Rage when our mana is low and mob we are fighting has 
            // .. a lot of health left.  Since it gives mana back for 
            if (_me.ManaPercent < Math.Max(60, _cfg.RestManaPercent))
            {
                if (bUnderStress || (_me.GotTarget && _me.CurrentTarget.HealthPercent > 85))
                {
                    {
                        ShamanisticRage();
                    }
                }
            }
            //            if ( AllowNonHealSpells())
            //                Cleanse();

            if (combatChecks() && bUnderStress)
            {
                FeralSpirit();
            }

            CastCombatSpecials();

            if (combatChecks() && AllowNonHealSpells())
            {
                SetTotemsAsNeeded();
            }

            if (_me.CurrentTarget.Fleeing)
            {
                BestShockForMob(false);
                Dlog("target is stationary or moving away at " + _me.Location.Distance(_me.CurrentTarget.Location).ToString("F2") + " yards, hit with Lightning");

                if (LightningBolt())
                {
                    Thread.Sleep(250);
                    return;
                }
            }

            if (MaelstromCheck())
                return;

            if (Stormstrike())
                return;

            if (BestShockForMob(false))
                return;

            if (LavaLash())
                return;

            ShamanBuffs(false);
        }


        /*
         * CombatElemental()
         * 
         */
        private void CombatElemental()
        {
            // check we are in good state to cast totems, and target isn't about to die or we have multiple adds
            if (combatChecks() && AllowNonHealSpells() && (_me.CurrentTarget.HealthPercent > 10 || countEnemy > 1))
            {
                SetCasterTotemsAsNeeded();
            }

            CastCombatSpecials();

            if (_me.CurrentTarget.Fleeing)
            {
                BestShockForMob(false);
                Dlog("target is stationary or moving away at " + _me.Location.Distance(_me.CurrentTarget.Location).ToString("F2") + " yards, hit with Lightning");

                if (LightningBolt())
                {
                    Thread.Sleep(250);
                    return;
                }
            }

            if (_me.CurrentTarget.IsPlayer && FrostShock())
                return;

            if (countEnemy > 1 && Thunderstorm())
                return;

            if (ElementalMastery())
                return;

            if (countEnemy > 1 && ChainLightning())
                return;

            if (_countMeleeEnemy > 1 && _bFireTotem && FireNova())
                return;

            if (FlameShock(true))
                return;

            if (LavaBurst())
                return;

            if (BestShockForMob(false))
                return;

            if (LightningBolt())
                return;

            ShamanBuffs(false);

        }


        private void CombatBattleground()
        {

            if (NeedHeal)
            {
                if (!AllowNonHealSpells())
                {
                    if (!GiftOfTheNaaru())
                    {
                        Lifeblood();
                    }
                }

                // if we are critical on Mana and low on Health, use a potion to buy some time
                if (!AllowNonHealSpells())
                {
                    UsePotionIfAvailable();
                }
            }

            // ok, reevaluate if still need healing in hopes we can attack
            if (NeedHeal)
            {
                HealMyself();
            }

            InterruptEnemyCast();

            if (_me.ManaPercent < Math.Max(60, _cfg.RestManaPercent))
            {
                if (countEnemy > 1 || _OpposingPlayerGanking || _BigScaryGuyHittingMe)
                {
                    ShamanisticRage();
                }
            }

            //            if ( AllowNonHealSpells())
            //                Cleanse();

            if (combatChecks() && (countEnemy > 1 || _OpposingPlayerGanking || _BigScaryGuyHittingMe))
            {
                FeralSpirit();
            }

            if (combatChecks() && AllowNonHealSpells())
            {
                SetTotemsAsNeeded();
            }

            if (_me.CurrentTarget.Fleeing)
            {
                BestShockForMob(false);
                Dlog("target is stationary or moving away at " + _me.Location.Distance(_me.CurrentTarget.Location).ToString("F2") + " yards, hit with Lightning");

                if (LightningBolt())
                {
                    Thread.Sleep(250);
                    return;
                }
            }

            if (MaelstromCheck())
                return;

            if (Stormstrike())
                return;

            if (BestShockForMob(false))
                return;

            if (LavaLash())
                return;

            if (Berserking())
                return;

            ShamanBuffs(false);
        }


        #endregion

        #region Spells

        private bool combatChecks()
        {
            if (_me.CurrentTarget == null || !_me.GotTarget)
            {
                if (_me.Combat && _me.GotAlivePet && _me.Pet.GotTarget)
                {
                    _me.Pet.CurrentTarget.Target();
                }
                else
                {
                    Dlog("No Current Target (null) -- bailing out of Combat()");
                    return false;
                }
            }

            if (_me.CurrentTarget.Guid == _me.Guid)
            {
                Dlog("Targeting _me -- clearing and bailing out of Combat()");
                _me.ClearTarget();
                return false;
            }

            if (_me.CurrentTarget.CreatedBy == _me.Guid || _me.CurrentTarget.SummonedByGuid == _me.Guid)
            {
                Slog("? HB targeted my: " + _me.CurrentTarget.Name + ", blacklisting ?");
                AddToBlacklist(_me.CurrentTarget.Guid);
                _me.ClearTarget();
                return false;
            }

            if (_me.Dead)
            {
                _deathCount++;
                Slog("Death #" + _deathCount + " fighting " + countEnemy + " mobs, target " + _me.CurrentTarget.Name + "[" + _me.CurrentTarget.Level + (_me.CurrentTarget.Elite ? "-Elite" : "") + "] at X=" + _me.Location.X.ToString("F0") + " Y=" + _me.Location.Y.ToString("F0") + " Z=" + _me.Location.Z.ToString("F0"));
                return false;
            }

            if (_me.CurrentTarget.Dead)        // check for dead target here in case he died while HB is calling us 
            {
                if (_lastDeadMobReported != _me.CurrentTarget.Guid && _me.CurrentTarget.Name != "Unknown")
                {
                    _killCount++;
                    _lastDeadMobReported = _me.CurrentTarget.Guid;
                    Slog("Kill #" + _killCount + " " + _me.CurrentTarget.Name + "[" + _me.CurrentTarget.Level + "] in " + _pullTimer.Elapsed.Seconds + " seconds.");
                }
                return false;
            }

            if (!WoWMovement.IsFacing)
                WoWMovement.Face();

            return true;
        }

        #region ATTACK SPELLS

        private void AutoAttack()
        {
            if (IsInGame)
            {
                Slog("*Auto-Attack");
                Lua.DoString("StartAttack()");
            }
        }

        private void StopAutoAttack()
        {
            if (IsInGame)
            {
                Slog("*Stop Auto-Attack");
                Lua.DoString("StopAttack()");
            }
        }

        private void CastCombatSpecials()
        {
            if (!combatChecks())
                return;

            bool bSeriousBusiness = false;

            if (countEnemy > 1)
                bSeriousBusiness = true;
            else if (_OpposingPlayerGanking && _me.HealthPercent > 70 && _me.CurrentTarget.HealthPercent > 70)
                bSeriousBusiness = true;
            else if (_BigScaryGuyHittingMe && _me.HealthPercent > 70 && _me.CurrentTarget.HealthPercent > 70)
                bSeriousBusiness = true;

            if (!bSeriousBusiness)
                ;
            else if (_me.Buffs.ContainsKey("Bloodlust"))
                ;
            else if (_me.Buffs.ContainsKey("Berserking"))
                ;
            else if (_me.Buffs.ContainsKey("Heroism"))
                ;
            else if (_me.Buffs.ContainsKey("Blood Fury"))
                ;
            else if (Bloodlust())   // all Shaman
                ;
            else if (Berserking())  // trolls
                ;
            else if (BloodFury())   // orcs
                ;
            else if (Heroism())     // draenei
                ;
        }

        private bool LightningBolt()
        {
            if (!combatChecks())
                ;
            else if (!HaveValidTarget() && !AllowNonHealSpells())
                ;
            else if (_me.CurrentTarget.Distance > 30)
                ;
            else
            {
                Safe_StopMoving();
                return Safe_CastSpell("Lightning Bolt");
            }

            return false;
        }

        private bool ChainLightning()
        {
            if (!combatChecks())
                ;
            else if (!Safe_KnownSpell("Chain Lightning"))
                ;
            else if (!HaveValidTarget() || !AllowNonHealSpells())
                ;
            else
            {
                Safe_StopMoving();
                return Safe_CastSpell("Chain Lightning");
            }

            return false;
        }

        private bool ShamanisticRage()
        {
            if (!combatChecks())
                ;
            else if (!Safe_KnownSpell("Shamanistic Rage"))
                ;
            else
            {
                return Safe_CastSpell("Shamanistic Rage");
            }

            return false;
        }

        private bool EarthShock(bool bIgnoreWaterShield)
        {
            // NOTE:  with patch 3.3 of WoW using Shock spells is not as much of a concern
            // ... since they drastically increased the mana regen
            // --- SO, force it to ignore Water Shield for now
            bIgnoreWaterShield = true;

            if (!combatChecks())
                Dlog("EarthShock:  failed combat check");
            else if (!HaveValidTarget() || !AllowNonHealSpells())
                ;
            else if (!Safe_KnownSpell("Earth Shock"))
                ;
            else if (_me.CurrentTarget.Buffs.ContainsKey("Earth Shock"))
                Dlog("EarthShock:  target already has DoT");
            else if (_me.CurrentTarget.Distance > 24)
                Dlog("target is at {0:F2} yards and too far for Earth Shock", _me.CurrentTarget.Distance);
            else if (bIgnoreWaterShield == false && !Safe_KnownSpell("Water Shield"))
                ;
            else
            {
                if (IsStormstrikeNeeded())
                {
                    Stormstrike();
                    Thread.Sleep(250);
                }

                return Safe_CastSpell("Earth Shock");
            }

            return false;
        }

        private bool FlameShock(bool bIgnoreWaterShield)
        {
            // NOTE:  with patch 3.3 of WoW using Shock spells is not as much of a concern
            // ... since they drastically increased the mana regen
            // --- SO, force it to ignore Water Shield for now
            bIgnoreWaterShield = true;

            if (!combatChecks())
                Dlog("FlameShock:  failed combat check");
            else if (!HaveValidTarget() || !AllowNonHealSpells())
                ;
            else if (!Safe_KnownSpell("Flame Shock"))
                ;
            else if (_me.CurrentTarget.Buffs.ContainsKey("Flame Shock"))
                Dlog("FlameShock:  target already has DoT");
            else if (_me.CurrentTarget.Distance > 24)
                Dlog("target is at {0:F2} yards and too far for Flame Shock", _me.CurrentTarget.Distance);
            else if (bIgnoreWaterShield == false && !Safe_KnownSpell("Water Shield"))
                ;
            else
                return Safe_CastSpell("Flame Shock");

            return false;
        }

        private bool FrostShock()
        {
            if (!combatChecks())
                ;
            else if (!HaveValidTarget() && !AllowNonHealSpells())
                ;
            else if (!Safe_KnownSpell("Frost Shock"))
                ;
            else if (_me.CurrentTarget.Buffs.ContainsKey("Frost Shock"))
                ;
            else if (_me.CurrentTarget.Distance > 24)
                ;
            else
                return Safe_CastSpell("Frost Shock");

            return false;
        }

        /*
         * Summary:  determines the best Shock spell opener to
         * use.  This is for use during pull only.  
         */
        private bool ShockOpener(bool bIgnoreWaterShield)
        {
            bool bCast = false;

            if (_me.CurrentTarget.IsPlayer)
                bCast = FrostShock();

            if (!bCast)
                bCast = FlameShock(bIgnoreWaterShield);

            if (!bCast)
                bCast = EarthShock(bIgnoreWaterShield);

            return bCast;
        }

        private bool BestShockForMob(bool bIgnoreWaterShield)
        {
            bool knowFrost = Safe_KnownSpell("Frost Shock");
            bool useFrost = false;

            if (_me.CurrentTarget.Fleeing
                || _me.CurrentTarget.CreatureType == WoWCreatureType.Elemental
                || _cfg.IsFrostMob(_me.CurrentTarget.Entry)
                || _me.CurrentTarget.IsPlayer
                )
            {
                useFrost = true;
            }

            if (useFrost && knowFrost)
                return FrostShock();

            return EarthShock(bIgnoreWaterShield);
        }

        private bool Stormstrike()
        {
            if (!combatChecks())
                ;
            else if (!HaveValidTarget() || !AllowNonHealSpells())
                ;
            else if (!Safe_KnownSpell("Stormstrike"))
                ;
            else if (!CurrentTargetInMeleeDistance())
                ;
            else if (_me.CurrentTarget.Buffs.ContainsKey("Stormstrike"))
                ;
            else
                return Safe_CastSpell("Stormstrike");

            return false;
        }

        private bool IsStormstrikeNeeded()
        {
            if (Safe_KnownSpell("Stormstrike"))
            {
                if (!_me.CurrentTarget.Buffs.ContainsKey("Stormstrike"))
                {
                    WoWSpell spell = SpellManager.KnownSpells["Stormstrike"];
                    if (spell != null)
                    {
                        if (_me.CurrentTarget.Distance < spell.MaxRange)
                        {
                            return true;
                        }
                    }
                }
            }
            return false;
        }

        private bool LavaLash()
        {
            if (!combatChecks())
                ;
            else if (!HaveValidTarget() && !AllowNonHealSpells())
                ;
            else if (!Safe_KnownSpell("Lava Lash"))
                ;
            else if (!CurrentTargetInMeleeDistance())
                ;
            else
                return Safe_CastSpell("Lava Lash");

            return false;
        }

        private bool LavaBurst()
        {
            if (!combatChecks())
                ;
            else if (!HaveValidTarget() && !AllowNonHealSpells())
                ;
            else if (!Safe_KnownSpell("Lava Burst"))
                ;
            else
                return Safe_CastSpell("Lava Burst");

            return false;
        }

        private bool ElementalMastery()
        {
            if (!combatChecks())
                ;
            else if (!HaveValidTarget() && !AllowNonHealSpells())
                ;
            else if (!Safe_KnownSpell("Elemental Mastery"))
                ;
            else
                return Safe_CastSpell("Elemental Mastery");

            return false;
        }

        private bool Thunderstorm()
        {
            if (!combatChecks())
                ;
            else if (!HaveValidTarget() && !AllowNonHealSpells())
                ;
            else if (!Safe_KnownSpell("Thunderstorm"))
                ;
            else
                return Safe_CastSpell("Thunderstorm");

            return false;
        }

        private bool FireNova()
        {
            if (!combatChecks())
                ;
            else if (!HaveValidTarget() && !AllowNonHealSpells())
                ;
            else if (!Safe_KnownSpell("Fire Nova"))
                ;
            else
                return Safe_CastSpell("Fire Nova");

            return false;
        }

        private bool MaelstromCheck()
        {
            if (!IsInGame)
                return false;
            if (!combatChecks())
                ;
            else if (!HaveValidTarget())
                ;
            else
            {
                const string cMaelstromWeapon = "Maelstrom Weapon";
                List<string> myBuffs = Lua.LuaGetReturnValue("return UnitBuff(\"player\",\"" + cMaelstromWeapon + "\")", "hawker.lua");

                if (Equals(null, myBuffs))
                    return false;

                string buffName = myBuffs[0];
                int stackCount = Convert.ToInt32(myBuffs[3]);

                if (buffName != cMaelstromWeapon)
                    ;
                else if (stackCount < 4)
                    ;
                else
                {
                    if (stackCount >= 4 && _me.HealthPercent < _cfg.CombatHealthPercent)
                    {
                        Slog("^Maelstrom Heal @ " + stackCount + " stks");
                        bool goodHeal = HealingWave();
                        if (!goodHeal)
                            goodHeal = LesserHealingWave();
                        return goodHeal;
                    }
                    else if (stackCount == 5)
                    {
                        Slog("^Maelstrom Attack @ " + stackCount + " stks");
                        Stormstrike();  // throw a Stormstrike if debuff not up
                        if (countEnemy == 1)
                            return LightningBolt();
                        else
                            return ChainLightning();
                    }
                }
            }

            return false;
        }

        private bool InterruptEnemyCast()
        {
            if (!combatChecks())
                Dlog("Failed combat checks - Wind Shear not cast");
            else if (!HaveValidTarget())
                Dlog("Don't have a valid target - Wind Shear not cast");
            else if (!AllowNonHealSpells())
                Dlog("Non-healing spells not allowed now - Wind Shear not cast");
            else if (!_me.CurrentTarget.IsCasting)
                Dlog("Target isn't casting a spell - Wind Shear not cast");
            else if (!Safe_KnownSpell("Wind Shear"))
                Dlog("Have not trained spell yet - Wind Shear not cast");
            else
                return Safe_CastSpell("Wind Shear");

            return false;
        }

        private bool FeralSpirit()
        {
            if (!IsInGame)
                return false;

            bool castGood = false;

            if (Safe_KnownSpell("Feral Spirit"))
            {
                castGood = Safe_CastSpell("Feral Spirit");
                if (castGood)
                {
                    Stopwatch castTimeout = new Stopwatch();

                    Log("^Pet Defensive Mode");
                    Lua.DoString("PetDefensiveMode()");     // turn on defensive mode
                    castTimeout.Reset();
                    castTimeout.Start();
                    Thread.Sleep(150);
                    while (castTimeout.ElapsedMilliseconds < 500 && (SpellManager.GlobalCooldown || _me.Casting != 0 || _me.ChanneledCasting != 0))
                    {
                        Thread.Sleep(50);
                    }

                    Log("^Pet Ability - Twin Howl");
                    Lua.DoString("CastPetAction(5)");       // throw a twin howl immediately
                    castTimeout.Reset();
                    castTimeout.Start();
                    Thread.Sleep(150);
                    while (castTimeout.ElapsedMilliseconds < 1500 && (SpellManager.GlobalCooldown || _me.Casting != 0 || _me.ChanneledCasting != 0))
                    {
                        Thread.Sleep(50);
                    }
                }
            }

            return castGood;
        }

        private bool Bloodlust()
        {
            if (!Safe_KnownSpell("Bloodlust"))
                ;
            else if (Safe_CastSpell("Bloodlust"))
            {
                return true;
            }

            return false;
        }

        #endregion

        #region HEALING

        private bool HealingWave()
        {
            return Safe_CastSpell("Healing Wave");
        }

        private bool LesserHealingWave()
        {
            return Safe_CastSpell("Lesser Healing Wave");
        }

        private void UsePotionIfAvailable()
        {
            if (!IsInGame)
                return;

            WoWItem potion = CheckForItem(_potionEID);
            if (potion != null)
            {
                Slog("POTION:  Using '" + potion.Name + "'");
                Lua.DoString("UseItemByName(\"" + potion.Name + "\")");
            }
        }


        #endregion

        private bool ShieldBuffNeeded(bool atRest)
        {
            bool bKnowBuffSpell = Safe_KnownSpell("Water Shield") || Safe_KnownSpell("Lightning Shield");
            bool bNeedBuff = !_me.Buffs.ContainsKey("Water Shield") && !_me.Buffs.ContainsKey("Lightning Shield");

            if (atRest && _me.Buffs.ContainsKey("Water Shield"))
            {
                if (_me.Buffs["Water Shield"].StackCount < 3)
                    bNeedBuff = true;
            }

            if (atRest && _me.Buffs.ContainsKey("Lightning Shield"))
            {
                if (_me.Buffs["Lightning Shield"].StackCount < 3)
                    bNeedBuff = true;
            }

            return bKnowBuffSpell && bNeedBuff;
        }

        /*
         * ShieldTwisting()
         * 
         * Implement a technique known as shield twisting where
         * you alternate between a damage shield and a mana restoration 
         * shield.  basically make sure one or the other is active.
         * 
         * Here is the general approach in priority order:
         * 
         * If Mana is low, then force Mana restoration
         * If Mana is full, then force Damage shield
         * Otherwise alterante between shield types
         * 
         * This is a Level 20 and Higher Technique
         */
        private void ShieldTwisting(bool atRest)
        {
            bool trainedWaterShield = Safe_KnownSpell("Water Shield");
            bool trainedLightningShield = Safe_KnownSpell("Lightning Shield");
            uint uWaterStacks = (!_me.Buffs.ContainsKey("Water Shield") ? 0 : _me.Buffs["Water Shield"].StackCount);
            uint uLightningStacks = (!_me.Buffs.ContainsKey("Lightning Shield") ? 0 : _me.Buffs["Lightning Shield"].StackCount);
            bool useWaterShieldThisTime = !_lastShieldCastWasWater;

            if (!trainedLightningShield && !trainedWaterShield)
                return;

            /*
             * if mana level dictates, then force appropriate type
             * otherwise if active shield keep it the same
             */
            if (_me.ManaPercent <= _cfg.TwistManaPercent || eType != ShamanType.Enhance)
                useWaterShieldThisTime = true;
            else if (_me.ManaPercent > _cfg.TwistDamagePercent)
                useWaterShieldThisTime = false;
            else if (uWaterStacks > 0)
                useWaterShieldThisTime = true;
            else if (uLightningStacks > 0)
                useWaterShieldThisTime = false;

            // default to lightning if we haven't learned water shield yet
            if (!trainedWaterShield)
                useWaterShieldThisTime = false;

            if (!trainedLightningShield)
                useWaterShieldThisTime = true;

            Dlog("atRest: " + atRest + "  traindWater: " + trainedWaterShield + "  traindLtng: " + trainedLightningShield + "  stksWater: " + uWaterStacks + "  stksLtng: " + uLightningStacks + "  h%: " + _me.HealthPercent.ToString("F0") + "  useW: " + _me.ManaPercent.ToString("F0"));

            // if we are resting and don't have at least 3 stacks, then force re-cast
            if (useWaterShieldThisTime)
            {
                if (uWaterStacks == 0 || (atRest && uWaterStacks < 3))
                {
                    Safe_CastSpell("Water Shield");
                }
            }
            else
            {
                if (uLightningStacks == 0 || (atRest && uLightningStacks < 3))
                {
                    Safe_CastSpell("Lightning Shield");
                }
            }

            _lastShieldCastWasWater = useWaterShieldThisTime;
        }


        /*
         * Summary: inspects the objects within ranged to check if they are targeting me
         *          and hostile.  breaks down counts between ranged and melee targets
         *          
         * Returns: total number of hostiles fighting me
         */
        Stopwatch _addsTimer = new Stopwatch();
        List<WoWUnit> _mobList = null;

        private int CheckForAdds()
        {
            Stopwatch timerCFA = new Stopwatch();
            timerCFA.Start();

            // List<WoWObject> longList = ObjectManager.ObjectList;
            // List<WoWUnit> mobList = ObjectManager.GetObjectsOfType<WoWUnit>(false);

            if (_mobList == null || (_addsTimer.ElapsedMilliseconds > 10000 && !_me.Combat))
            {
                _mobList = ObjectManager.GetObjectsOfType<WoWUnit>(false);
                _addsTimer.Reset(); _addsTimer.Start();
            }

            _countMeleeEnemy = 0;
            _countRangedEnemy = 0;
            _countMobs = 0;
            _distClosestEnemy = 9999.99;
            _OpposingPlayerGanking = false;
            _BigScaryGuyHittingMe = false;

            if (_me.PartyMembers.Count > 0 && !Equals(null, _me.PartyMember1.CurrentTarget) && !_mobList.Contains(_me.PartyMember1.CurrentTarget))
            {
                _mobList.Add(_me.PartyMember1.CurrentTarget);
            }

            // Dlog("CheckForAdds() can see:");
            try
            {
                foreach (WoWUnit unit in _mobList)
                {
                    if (unit == null)
                    {
                        Dlog("   UNIT == null ");
                    }
                    else if (unit.Dead)
                        ;
                    else if (unit.IsPlayer)
                    {
                        _distClosestEnemy = Math.Min(_distClosestEnemy, unit.Distance);
                        // Dlog("   PLAYER: (" + (unit.ToPlayer().IsHorde ? "H" : "A") + ") " + unit.Race + " " + unit.Class + " - " + unit.Name + "[" + unit.Level + "]  dist: " + _me.Location.Distance(unit.Location).ToString("F2"));
                    }
                    else if (Global.CurrentProfile.Factions.Contains(unit.Faction))
                    {
                        _distClosestEnemy = Math.Min(_distClosestEnemy, unit.Distance);
                        if (unit.Distance <= Logic.Targeting.PullDistance)
                        {
                            // Dlog("  " + (unit.IsTargetingMe ? "*" : " ") + "MOB: " + unit.Class + " - " + unit.Name + "[" + unit.Level + "]  dist: " + _me.Location.Distance(unit.Location).ToString("F2"));
                            _countMobs++;
                        }
                    }
                    else
                    {
                        if (unit.Distance <= Logic.Targeting.PullDistance)
                        {
                            // Dlog("  " + (unit.IsTargetingMe ? "*" : " ") + "NPC: " + unit.Class + " - " + unit.Name + "[" + unit.Level + "]  dist: " + _me.Location.Distance(unit.Location).ToString("F2"));
                        }
                    }

                    // note:  my own Searing Totem will be in combat and target me for /assist,
                    //  ..  so need to check if unit was created by me
                    if (unit.IsMe)
                        ;
                    else if (unit.CurrentTarget == null)
                        ;
                    else if (!IsTargetingMeOrMyStuff(unit))
                        ;   // Dlog("   -- not targeting me");
                    else if (unit.Dead)
                        ;
                    else if (!unit.Combat)
                        ;   // Dlog("   -- NOT in Combat");
                    else if (!unit.Attackable)
                        ;   // Dlog("   -- NOT Attackable");
                    else if (unit.CreatedBy == _me.Guid)
                        ;   // Dlog("   -- created by ME");
                    else
                    {
                        if (_me.Location.Distance(unit.Location) <= 5.0)
                            _countMeleeEnemy++;
                        else
                            _countRangedEnemy++;

                        if (unit.IsPlayer && !_pvp.IsBattleground())
                        {
                            _OpposingPlayerGanking = true;
                            if (_me.CurrentTarget == null || !_me.CurrentTarget.IsPlayer)
                            {
                                unit.Target();
                            }
                        }

                        if (unit.Elite || ((unit.Level - _me.Level) >= 3))
                            _BigScaryGuyHittingMe = true;
                    }

                    //                    if (unit.Elite && !unit.IsTargetingMe && !Styx.Logic.Blacklist.Contains( unit.Guid ))
                    //                    {
                    //                        Slog(">>> BLACKLIST ELITE: " + unit.Name + "[" + unit.Level + "] at " + unit.Distance.ToString("F1") + " yds");
                    //                        AddToBlacklist(_me.CurrentTarget.Guid);
                    //                    }
                }
            }
            catch (Exception e)
            {
                Slog("HB EXCEPTION in code doing CheckForAdds()");
                Slog("-- " + e.ToString());
            }

            // Dlog("   Total  " + _countMeleeEnemy + "/" + _countRangedEnemy + " melee/ranged in Combat with me");

            if (countEnemy > 1)
                Slog(">>> MULTIPLE TARGETS:  " + _countMeleeEnemy + " melee,  " + _countRangedEnemy + " ranged");
            if (_BigScaryGuyHittingMe)
                Slog(">>> BIG Scary Guy Hitting Me (elite or 3+ levels)");
            if (_OpposingPlayerGanking)
                Slog(">>> Opposing Player is Attacking!!!!");

            Dlog("## CheckForAdds() took {0} ms", timerCFA.ElapsedMilliseconds);
            return countEnemy;
        }

        /*
         * Summary: inspects the objects within ranged to check if they are targeting me
         *          and hostile.  breaks down counts between ranged and melee targets
         *          
         * Returns: total number of players within 100 yds
         // credit to Mord for player identifiction idea
         */
        private int CheckForPlayers()
        {
            if (!_cfg.NearbyPlayerWarnings || _pvp.IsBattleground())
                return 0;

            int cnt = 0;
            List<WoWPlayer> longList = new List<WoWPlayer>();
            longList = ObjectManager.GetObjectsOfType<WoWPlayer>();

            foreach (WoWPlayer p in longList)
            {
                if (!p.IsMe && p.IsAlive && p.Distance < 100)
                {
                    cnt++;
                    if (IsTargetingMeOrMyStuff(p) && _cfg.BeepIfPlayerTargetsMe)
                        System.Console.Beep();

                    Slog("* ("
                        + (p.IsHorde ? "H" : "A") + ") Player "
                        + (IsTargetingMeOrMyStuff(p) ? "TARGETING ME " : "")
                        + p.Distance.ToString("F0") + " yds: "
                        + p.Name + "[" + p.Level + "] "
                        + p.Race + " " + p.Class
                        );
                }
            }

            return cnt;
        }


        #endregion

        #region RACIALS

        private bool Warstomp()
        {
            if (!Safe_KnownSpell("War Stomp"))
                ;
            else if (_countMeleeEnemy < 1)
                ;
            else if (Safe_CastSpell("War Stomp"))
            {
                Slog("War Stomp: BOOM!");
                return true;
            }

            return false;
        }

        private bool Berserking()
        {
            if (!Safe_KnownSpell("Berserking"))
                ;
            else if (Safe_CastSpell("Berserking"))
            {
                Slog("Berserking: just broke out a can of whoop a$@!");
                return true;
            }

            return false;
        }

        private bool BloodFury()
        {
            if (!Safe_KnownSpell("Blood Fury"))
                ;
            else if (Safe_CastSpell("Blood Fury"))
            {
                Slog("Berserking: just broke out a can of whoop a$@!");
                return true;
            }

            return false;
        }

        private bool GiftOfTheNaaru()
        {
            if (!Safe_KnownSpell("Gift of the Naaru"))
                ;
            else if (Safe_CastSpell("Gift of the Naaru"))
            {
                Slog("Gift of the Naaru: it's good to be Draenei!");
                return true;
            }

            return false;
        }

        private bool Heroism()
        {
            if (!Safe_KnownSpell("Heroism"))
                ;
            else if (Safe_CastSpell("Heroism"))
            {
                Slog("Heroism: it's good to be Draenei!");
                return true;
            }

            return false;
        }

        private bool Lifeblood()
        {
            if (!Safe_KnownSpell("Lifeblood"))
                ;
            else if (Safe_CastSpell("Lifeblood"))
            {
                Slog("Lifeblood: the benefit of being a flower picker!");
                return true;
            }

            return false;
        }

        #endregion

        /*
         * TotemExist()  checks to see if a totem of the specified class exists
         * 
         */
        const int TOTEM_FIRE = 1;
        const int TOTEM_EARTH = 2;
        const int TOTEM_WATER = 3;
        const int TOTEM_AIR = 4;

        private string[] _totemName = new string[5];

        private bool TotemExist(int indexTotem)
        {
            if (!IsInGame)
                return false;

            List<string> totemInfo = Lua.LuaGetReturnValue("return GetTotemInfo(" + indexTotem + ")", "hawker.lua");

            if (Equals(null, totemInfo))
                return false;

            string haveTotem = totemInfo[0];
            string totemName = totemInfo[1];
            string startTime = totemInfo[2];
            string duration = totemInfo[3];
            string icon = totemInfo[4];

            if (totemName == null || totemName == "nil" || totemName == "")
            {
                _totemName[indexTotem] = "";
                return false;
            }

            _totemName[indexTotem] = totemName;
            Dlog("   Found Totem(" + indexTotem + "):  " + totemName);
            return true;
        }

        /*
         * summary:  employing general strategy discussed on :
         * 
         *                  http://www.yawb.info/2009/08/25/learning-about-totems-tips-to-aid-your-growing-shamanism/
         *                  
         * regarding the use of totems while leveling.  PLEASE NOTE!  Purposefully using totems only during combat
         * against multiple mobs.  Should be able to handle single targets up to 3 levels higher with no problem
         * through self-heals and windfury enchant
         */
        private void SetTotemsAsNeeded()
        {
            // makes 4 LUA calls to get totems active (1 per family) so
            // .. make sure we don't get called more than once every 2 seconds
            // .. so we aren't spamming LUA calls
            if (_TotemCheckTimer.ElapsedMilliseconds < 8000)
            {
                // if this isn't first time here since reset, then wait for 2 seconds
                if (_TotemCheckTimer.ElapsedMilliseconds > 0)
                {
                    return;
                }

                // otherwise, only 0 if first check after last .Reset
                //  ..  so continue processing
            }

            _TotemCheckTimer.Reset();
            _TotemCheckTimer.Start();

            if (!_pvp.IsBattleground() && countEnemy <= 1 && !_BigScaryGuyHittingMe && !_OpposingPlayerGanking)
                return;

            bool bEarthTotem = TotemExist(TOTEM_EARTH);
            _bFireTotem = TotemExist(TOTEM_FIRE);
            bool bWaterTotem = TotemExist(TOTEM_WATER);
            bool bAirTotem = TotemExist(TOTEM_AIR);
            bool bAnyTotemsUp = bEarthTotem || _bFireTotem || bWaterTotem || bAirTotem;

            Dlog("SetTotemsAsNeeded():  earth: " + bEarthTotem + "  fire: " + _bFireTotem + "  water: " + bWaterTotem + "  air: " + bAirTotem);

            _WereTotemsSet = _WereTotemsSet || bAnyTotemsUp;

            // Totem Set:  Ganker or PVP == Call of the Ancestors
            //////////////////////////////////////////////////////////////////////
            if (!bAnyTotemsUp && (_OpposingPlayerGanking || _pvp.IsBattleground()))
            {
                if (Safe_KnownSpell("Call of the Ancestors"))
                {
                    if (Safe_CastSpell("Call of the Ancestors"))
                    {
                        _WereTotemsSet = true;
                        _bFireTotem = TotemExist(TOTEM_FIRE);           // refresh since global value
                        return;
                    }
                }
            }

            // Totem Set:  Multiple Mobs == Call of the Elements 
            //////////////////////////////////////////////////////////////////////
            if (!bAnyTotemsUp && (countEnemy > 1 || _BigScaryGuyHittingMe || _OpposingPlayerGanking))
            {
                if (Safe_KnownSpell("Call of the Elements"))
                {
                    if (Safe_CastSpell("Call of the Elements"))
                    {
                        _WereTotemsSet = true;
                        _bFireTotem = TotemExist(TOTEM_FIRE);           // refresh since global value
                        return;
                    }
                }
            }

            // Earth Totems First
            //////////////////////////////////////////////////////////////////////
            if (!bEarthTotem && (_countMeleeEnemy > 1 || _BigScaryGuyHittingMe))
            {
                if (Safe_KnownSpell("Stoneclaw Totem"))
                {
                    bEarthTotem = Safe_CastSpell("Stoneclaw Totem");
                }
            }

            if (!bEarthTotem && (countEnemy > 1 || _BigScaryGuyHittingMe))
            {
                if (Safe_KnownSpell("Strength of Earth Totem"))
                {
                    bEarthTotem = CastBuff("Strength of Earth Totem", "Strength of Earth");
                }
            }

            if (!bEarthTotem && (countEnemy > 1 || _BigScaryGuyHittingMe))
            {
                if (Safe_KnownSpell("Stoneskin Totem"))
                {
                    bEarthTotem = CastBuff("Stoneskin Totem", "Stoneskin");
                }
            }

            // Fire Totems
            //////////////////////////////////////////////////////////////////////
            if (!_bFireTotem && (_countMeleeEnemy > 1 || _BigScaryGuyHittingMe))
            {
                if (Safe_KnownSpell("Magma Totem"))
                {
                    _bFireTotem = Safe_CastSpell("Magma Totem");
                }
            }

            if (!_bFireTotem && (countEnemy > 1 || _BigScaryGuyHittingMe))
            {
                if (Safe_KnownSpell("Searing Totem"))
                {
                    // check for totem existence in WoWObject list
                    _bFireTotem = Safe_CastSpell("Searing Totem");
                }
            }

            // Water Totems
            //////////////////////////////////////////////////////////////////////
            if (!bWaterTotem && (countEnemy > 1 || _BigScaryGuyHittingMe))
            {
                if (Safe_KnownSpell("Mana Spring Totem"))
                {
                    bWaterTotem = CastBuff("Mana Spring Totem", "Mana Spring");
                }
            }

            // Air Totems
            //////////////////////////////////////////////////////////////////////
            if (!bAirTotem && ((countEnemy > 1 && _countRangedEnemy > 0) || _BigScaryGuyHittingMe))
            {
                if (Safe_KnownSpell("Grounding Totem"))
                {
                    bAirTotem = Safe_CastSpell("Grounding Totem");
                }
            }

            if (!bAirTotem && (countEnemy > 1 || _BigScaryGuyHittingMe))
            {
                if (Safe_KnownSpell("Windfury Totem"))
                {
                    bAirTotem = CastBuff("Windfury Totem", "Windfury");
                }
            }

            _WereTotemsSet = _WereTotemsSet || bEarthTotem || _bFireTotem || bWaterTotem || bAirTotem;
        }

        private void SetCasterTotemsAsNeeded()
        {
            // makes 4 LUA calls to get totems active (1 per family) so
            // .. make sure we don't get called more than once every 2 seconds
            // .. so we aren't spamming LUA calls
            if (_TotemCheckTimer.ElapsedMilliseconds < 8000)
            {
                // if this isn't first time here since reset, then wait for 2 seconds
                if (_TotemCheckTimer.ElapsedMilliseconds > 0)
                {
                    return;
                }

                // otherwise, only 0 if first check after last .Reset
                //  ..  so continue processing
            }

            _TotemCheckTimer.Reset();
            _TotemCheckTimer.Start();

            bool bEarthTotem = TotemExist(TOTEM_EARTH);
            _bFireTotem = TotemExist(TOTEM_FIRE);
            bool bWaterTotem = TotemExist(TOTEM_WATER);
            bool bAirTotem = TotemExist(TOTEM_AIR);
            bool bAnyTotemsUp = bEarthTotem || _bFireTotem || bWaterTotem || bAirTotem;

            Dlog("SetTotemsAsNeeded():  earth: " + bEarthTotem + "  fire: " + _bFireTotem + "  water: " + bWaterTotem + "  air: " + bAirTotem);

            _WereTotemsSet = _WereTotemsSet || bAnyTotemsUp;

            // Totem Set:  Ganker or PVP == Call of the Ancestors
            //////////////////////////////////////////////////////////////////////
            if (!bAnyTotemsUp && _OpposingPlayerGanking)
            {
                if (Safe_KnownSpell("Call of the Ancestors"))
                {
                    if (Safe_CastSpell("Call of the Ancestors"))
                    {
                        _WereTotemsSet = true;
                        return;
                    }
                }
            }

            // Totem Set:  Multiple Mobs == Call of the Elements 
            //////////////////////////////////////////////////////////////////////
            if (!bAnyTotemsUp)
            {
                if (Safe_KnownSpell("Call of the Elements"))
                {
                    if (Safe_CastSpell("Call of the Elements"))
                    {
                        _WereTotemsSet = true;
                        return;
                    }
                }
            }

            // Earth Totems First
            //////////////////////////////////////////////////////////////////////
            /*
                        if (!bEarthTotem )
                        {
                            if (Safe_KnownSpell("Earthbind Totem"))
                            {
                                bEarthTotem = Safe_CastSpell("Earthbind Totem");
                            }
                        }
            */
            if (!bEarthTotem && (countEnemy > 1 || _BigScaryGuyHittingMe))
            {
                if (Safe_KnownSpell("Stoneskin Totem"))
                {
                    bEarthTotem = CastBuff("Stoneskin Totem", "Stoneskin");
                }
            }

            if (!bEarthTotem)
            {
                if (Safe_KnownSpell("Stoneclaw Totem"))
                {
                    bEarthTotem = CastBuff("Stoneclaw Totem", "Stoneclaw");
                }
            }

            // Fire Totems
            //////////////////////////////////////////////////////////////////////
            if (!_bFireTotem && _countMeleeEnemy > 1)
            {
                if (Safe_KnownSpell("Magma Totem"))
                {
                    _bFireTotem = Safe_CastSpell("Magma Totem");
                }
            }

            if (!_bFireTotem)
            {
                if (Safe_KnownSpell("Totem of Wrath"))
                {
                    _bFireTotem = Safe_CastSpell("Totem of Wrath");
                }
            }

            if (!_bFireTotem)
            {
                if (Safe_KnownSpell("Searing Totem"))
                {
                    // check for totem existence in WoWObject list
                    _bFireTotem = Safe_CastSpell("Searing Totem");
                }
            }

            // Water Totems
            //////////////////////////////////////////////////////////////////////
            if (!bWaterTotem && (countEnemy > 1 || _BigScaryGuyHittingMe))
            {
                if (Safe_KnownSpell("Mana Spring Totem"))
                {
                    bWaterTotem = CastBuff("Mana Spring Totem", "Mana Spring");
                }
            }

            // Air Totems
            //////////////////////////////////////////////////////////////////////
            if (!bAirTotem)
            {
                if (Safe_KnownSpell("Wrath of Air Totem"))
                {
                    bAirTotem = CastBuff("Wrath of Air Totem", "Wrath of Air");
                }
            }

            if (!bAirTotem)
            {
                if (Safe_KnownSpell("Grounding Totem"))
                {
                    bAirTotem = Safe_CastSpell("Grounding Totem");
                }
            }

            _WereTotemsSet = _WereTotemsSet || bEarthTotem || _bFireTotem || bWaterTotem || bAirTotem;
        }

        private void ReclaimTotemsForMana()
        {
            if (_WereTotemsSet)
            {
                if (Safe_KnownSpell("Totemic Recall"))
                    Safe_CastSpell("Totemic Recall");
            }

            _WereTotemsSet = false;
        }

        #endregion



        #region Enchant ID Lists

        /*
         * Following list of enchant id's come from:
         * 
         *      http://www.wowhead.com/?search=Rockbiter+Weapon
         * 
         * NOTE:  YOU MUST OBTAIN FROM THE "UNCATEGORIZED SPELLS" tab
         * for Rockbiter Weapon.  All other Shaman weapon enchants
         * are correctly documented within wowhead.
         */

        private List<short> _rockbiterEnchantId = new List<short>()
        {
              29, 3023, 3022, 3021,     // Rockbiter Weapon (Rank 1)
            3026,    6, 3025, 3024,     // Rockbiter Weapon (Rank 2) 
            3029, 3028, 3027,    1,     // Rockbiter Weapon (Rank 3)
            3032, 3031,  503, 3030      // Rockbiter Weapon (Rank 4)
        };

        private List<short> _windfuryEnchantId = new List<short>()
        {
             283,   // Windfury Weapon (Rank 1)
             284,   // Windfury Weapon (Rank 2)
             525,   // Windfury Weapon (Rank 3)
            1669,   // Windfury Weapon (Rank 4)
            2636,   // Windfury Weapon (Rank 5)
            3785,   // Windfury Weapon (Rank 6)
            3786,   // Windfury Weapon (Rank 7)
            3787    // Windfury Weapon (Rank 8)
        };

        private List<short> _flametongueEnchantId = new List<short>()
        {
               5,   // Flametongue Weapon (Rank 1)
               4,   // Flametongue Weapon (Rank 2)
               3,   // Flametongue Weapon (Rank 3)
             523,   // Flametongue Weapon (Rank 4)
            1665,   // Flametongue Weapon (Rank 5)
            1666,   // Flametongue Weapon (Rank 6)
            2634,   // Flametongue Weapon (Rank 7)
            3779,   // Flametongue Weapon (Rank 8)
            3780,   // Flametongue Weapon (Rank 9)
            3781    // Flametongue Weapon (Rank 10)
        };

        // Potion EntryId's taken from WoWHead
        private List<uint> _potionEID = new List<uint>()
        {
            //=== RESTORATION POTIONS (HEALTH AND MANA)
            40077,  // Crazy Alchemist's Potion 3500 (Alchemist)
            34440,  // Mad Alchemist's Potion 2750   (Alchemist)
            40087,  // Powerful Rejuvenation Potion 2475
            22850,  // Super Rejuvenation Potion 2100
            18253,  // Major Rejuvenation Potion 1760
            9144,   // Wildvine Potion 1500
            2456,   // Minor Rejuvenation Potion 150

            //=== HEALTH POTIONS 
            33447,  // Runic Healing Potion 4500

            43569,  // Endless Healing Potion  2500
            43531,  // Argent Healing Potion  2500
            32947,  // Auchenai Healing Potion  2500
            39671,  // Resurgent Healing Potion 2500
            22829,  // Super Healing Potion 2500
            33934,  // Crystal Healing Potion 2500
            23822,  // Healing Potion Injector 2500
            33092,  // Healing Potion Injector 2500

            31852,  // Major Combat Healing Potion 1750
            31853,  // Major Combat Healing Potion 1750
            31839,  // Major Combat Healing Potion 1750
            31838,  // Major Combat Healing Potion 1750
            13446,  // Major Healing Potion 1750
            28100,  // Volatile Healing Potion 1750 

            18839,  // Combat Healing Potion 900 
            3928,   // Superior Healing Potion 900

            1710,   // Greater Healing Potion  585

            929,    // Healing Potion  360

            4596,   // Discolored Healing Potion 180
            858,    // Lesser Healing Potion 180

            118     // Minor Healing Potion 90
            
        };

        #endregion

        #region CONFIG CLASS
        /*************************************************************************
         * private class that manages defaults and access to configurable values.
         * supports loading values from XML file
         *************************************************************************/
        class ConfigValues
        {
            private bool _debugOutput;
            private int _maxWaitForAggroAfterPull;
            private int _delayAfterRangedPull;
            private double _RestManaPercent;
            private double _RestHealthPercent;
            private double _CombatManaPercent;
            private double _CombatHealthPercent;
            private double _NeedHealHealthPercent;
            private TypeOfPull _pullType;
            private long _pullTimeout;
            private int _maxNumRangedAttacks;
            private double _TwistManaPercent;
            private double _TwistDamagePercent;
            private List<ulong> _listUseFrost;
            private bool _useGhostWolfForm;
            private double _DistanceForGhostWolf;
            private bool _nearbyPlayerWarnings;
            private bool _beepIfPlayerTargetsMe;
            private bool _groupHealer;
            private double _groupNeedHealPercent;
            private bool _flametongueOnOffhand;

            public enum TypeOfPull { Fast, Ranged, Body, Auto }

            public TypeOfPull PullType
            { get { return _pullType; } }
            public long PullTimeout
            { get { return _pullTimeout; } }
            public bool Debug
            { get { return _debugOutput; } }
            public int maxWaitAfterPull
            { get { return _maxWaitForAggroAfterPull; } }
            public int waitWaitAfterRangedPull
            { get { return _delayAfterRangedPull; } }
            public double RestManaPercent
            { get { return _RestManaPercent; } }
            public double RestHealthPercent
            { get { return _RestHealthPercent; } }
            public double CombatManaPercent
            { get { return _CombatManaPercent; } }
            public double CombatHealthPercent
            { get { return _CombatHealthPercent; } }
            public double NeedHealHealthPercent
            { get { return _NeedHealHealthPercent; } }
            public int MaxNumRangedAttacks
            { get { return _maxNumRangedAttacks; } }
            public double TwistManaPercent
            { get { return _TwistManaPercent; } }
            public double TwistDamagePercent
            { get { return _TwistDamagePercent; } }
            public bool IsFrostMob(ulong id)
            {
                return _listUseFrost.Contains(id);
            }
            public bool UseGhostWolfForm
            { get { return _useGhostWolfForm; } }
            public double DistanceForGhostWolf
            { get { return _DistanceForGhostWolf; } }
            public bool NearbyPlayerWarnings
            { get { return _nearbyPlayerWarnings; } }
            public bool BeepIfPlayerTargetsMe
            { get { return _beepIfPlayerTargetsMe; } }
            public bool GroupHealer
            { get { return _groupHealer; } }
            public double GroupNeedHealPercent
            { get { return _groupNeedHealPercent; } }
            public bool FlametongueOnOffhand
            { get { return _flametongueOnOffhand; } }

            public ConfigValues()
            {
                _pullType = TypeOfPull.Auto;
                _pullTimeout = 15000;
                _debugOutput = false;               // true/false:  extremely verbose debug output
                _maxWaitForAggroAfterPull = 500;    // max # milliseconds to wait after any pull for agro
                _delayAfterRangedPull = 250;        // # milliseconds to always wait after ranged pull 
                _RestManaPercent = 40.0;            // min mana % before drinking
                _RestHealthPercent = 60.0;          // min health % before eating
                _CombatManaPercent = 15.0;          // min mana % before preventing non-healing / non-mana regen spells
                _CombatHealthPercent = 35.0;        // min health % before preventing non-healing / non-mana regen spells
                _NeedHealHealthPercent = 50.0;      // min health % before allow self-heal casts
                _maxNumRangedAttacks = 2;
                _TwistManaPercent = 70.0;
                _TwistDamagePercent = 90.0;
                _useGhostWolfForm = true;
                _DistanceForGhostWolf = 40.0;
                _nearbyPlayerWarnings = true;
                _beepIfPlayerTargetsMe = true;
                _groupHealer = true;
                _groupNeedHealPercent = 80.0;
                _flametongueOnOffhand = false;

                _listUseFrost = new List<ulong>();
            }

            public void Load(string sFilename)
            {
                XmlTextReader reader;
                XmlDocument xml;
                XmlNode xvar;
                XmlNodeList xlst;
                XmlAttribute xattr;

                string sPath = Process.GetCurrentProcess().MainModule.FileName;
                sPath = Path.GetDirectoryName(sPath);
                sPath = Path.Combine(sPath, sFilename);
                Logging.WriteDebug("Loading config file: {0}", sPath);

                try
                {
                    reader = new XmlTextReader(sPath);
                }
                catch (Exception e)
                {
                    Logging.WriteDebug("SHAMWOW: " + e.Message);
                    Logging.WriteDebug("Continuing with Default Config Values");
                    return;
                }

                xml = new XmlDocument();

                try
                {
                    xml.Load(reader);
                    if (xml == null)
                        return;

                    /*
                    xvar = xml.SelectSingleNode("//Config/varname");
                    if (xvar != null)
                    {
                        xvar.InnerText;
                    }
                    */
                    xvar = xml.SelectSingleNode("//Config/Debug");
                    if (xvar != null)
                    {
                        _debugOutput = Convert.ToBoolean(xvar.InnerText);
                        Logging.WriteDebug("   cfg:  " + xvar.Name + "=" + _debugOutput);
                    }

                    xvar = xml.SelectSingleNode("//Config/RestMinMana");
                    if (xvar != null)
                    {
                        _RestManaPercent = Convert.ToDouble(xvar.InnerText);
                        Logging.WriteDebug("   cfg:  " + xvar.Name + "=" + _RestManaPercent);
                    }

                    xvar = xml.SelectSingleNode("//Config/RestMinHealth");
                    if (xvar != null)
                    {
                        _RestHealthPercent = Convert.ToDouble(xvar.InnerText);
                        Logging.WriteDebug("   cfg:  " + xvar.Name + "=" + _RestHealthPercent);
                    }

                    xvar = xml.SelectSingleNode("//Config/CombatMana");
                    if (xvar != null)
                    {
                        _CombatManaPercent = Convert.ToDouble(xvar.InnerText);
                        Logging.WriteDebug("   cfg:  " + xvar.Name + "=" + _CombatManaPercent);
                    }

                    xvar = xml.SelectSingleNode("//Config/CombatHealth");
                    if (xvar != null)
                    {
                        _CombatHealthPercent = Convert.ToDouble(xvar.InnerText);
                        Logging.WriteDebug("   cfg:  " + xvar.Name + "=" + _CombatHealthPercent);
                    }

                    xvar = xml.SelectSingleNode("//Config/NeedHeal");
                    if (xvar != null)
                    {
                        _NeedHealHealthPercent = Convert.ToDouble(xvar.InnerText);
                        Logging.WriteDebug("   cfg:  " + xvar.Name + "=" + _NeedHealHealthPercent);
                    }

                    xvar = xml.SelectSingleNode("//Config/TwistMana");
                    if (xvar != null)
                    {
                        _TwistManaPercent = Convert.ToDouble(xvar.InnerText);
                        Logging.WriteDebug("   cfg:  " + xvar.Name + "=" + _TwistManaPercent);
                    }

                    xvar = xml.SelectSingleNode("//Config/TwistDamage");
                    if (xvar != null)
                    {
                        _TwistDamagePercent = Convert.ToDouble(xvar.InnerText);
                        Logging.WriteDebug("   cfg:  " + xvar.Name + "=" + _TwistDamagePercent);
                    }

                    xvar = xml.SelectSingleNode("//Config/MaxAggroWait");
                    if (xvar != null)
                    {
                        _maxWaitForAggroAfterPull = Convert.ToInt32(xvar.InnerText);
                        Logging.WriteDebug("   cfg:  " + xvar.Name + "=" + _maxWaitForAggroAfterPull);
                    }

                    xvar = xml.SelectSingleNode("//Config/DelayAfterRangedPull");
                    if (xvar != null)
                    {
                        _delayAfterRangedPull = Convert.ToInt32(xvar.InnerText);
                        Logging.WriteDebug("   cfg:  " + xvar.Name + "=" + _delayAfterRangedPull);
                    }

                    xvar = xml.SelectSingleNode("//Config/PullTimeout");
                    if (xvar != null)
                    {
                        _pullTimeout = Convert.ToInt32(xvar.InnerText);
                        Logging.WriteDebug("   cfg:  " + xvar.Name + "=" + _pullTimeout);
                    }

                    xvar = xml.SelectSingleNode("//Config/MaxRangePullAttacks");
                    if (xvar != null)
                    {
                        _maxNumRangedAttacks = Convert.ToInt32(xvar.InnerText);
                        Logging.WriteDebug("   cfg:  " + xvar.Name + "=" + _maxNumRangedAttacks);
                    }

                    xvar = xml.SelectSingleNode("//Config/NearbyPlayerWarnings");
                    if (xvar != null)
                    {
                        _nearbyPlayerWarnings = Convert.ToBoolean(xvar.InnerText);
                        Logging.WriteDebug("   cfg:  " + xvar.Name + "=" + _nearbyPlayerWarnings);
                    }

                    xvar = xml.SelectSingleNode("//Config/BeepIfPlayerTargetsMe");
                    if (xvar != null)
                    {
                        _beepIfPlayerTargetsMe = Convert.ToBoolean(xvar.InnerText);
                        Logging.WriteDebug("   cfg:  " + xvar.Name + "=" + _beepIfPlayerTargetsMe);
                    }

                    xvar = xml.SelectSingleNode("//Config/GroupHealer");
                    if (xvar != null)
                    {
                        _groupHealer = Convert.ToBoolean(xvar.InnerText);
                        Logging.WriteDebug("   cfg:  " + xvar.Name + "=" + _groupHealer);
                    }

                    xvar = xml.SelectSingleNode("//Config/GroupNeedHealPercent");
                    if (xvar != null)
                    {
                        _groupNeedHealPercent = Convert.ToDouble(xvar.InnerText);
                        Logging.WriteDebug("   cfg:  " + xvar.Name + "=" + _groupNeedHealPercent);
                    }

                    xvar = xml.SelectSingleNode("//Config/FlametongueOnOffhand");
                    if (xvar != null)
                    {
                        _flametongueOnOffhand = Convert.ToBoolean(xvar.InnerText);
                        Logging.WriteDebug("   cfg:  " + xvar.Name + "=" + _flametongueOnOffhand);
                    }

                    xvar = xml.SelectSingleNode("//Config/UseGhostWolf");
                    if (xvar != null)
                    {
                        _useGhostWolfForm = Convert.ToBoolean(xvar.InnerText);
                        Logging.WriteDebug("   cfg:  " + xvar.Name + "=" + _useGhostWolfForm);
                    }

                    xvar = xml.SelectSingleNode("//Config/DistanceForGhostWolf");
                    if (xvar != null)
                    {
                        _DistanceForGhostWolf = Convert.ToDouble(xvar.InnerText);
                        Logging.WriteDebug("   cfg:  " + xvar.Name + "=" + _DistanceForGhostWolf);
                    }

                    xvar = xml.SelectSingleNode("//Config/PullType");
                    if (xvar != null)
                    {
                        string sValue = xvar.InnerText.ToUpper().Trim().Substring(0, 1);
                        switch (sValue)
                        {
                            default:
                                Logging.WriteDebug("Unknown " + xvar.Name + " '" + sValue + "' given");
                                break;
                            case "A":
                                _pullType = TypeOfPull.Auto;
                                Logging.WriteDebug("   cfg:  " + xvar.Name + "=Auto");
                                break;
                            case "B":
                                _pullType = TypeOfPull.Body;
                                Logging.WriteDebug("   cfg:  " + xvar.Name + "=Body");
                                break;
                            case "F":
                                _pullType = TypeOfPull.Fast;
                                Logging.WriteDebug("   cfg:  " + xvar.Name + "=Fast");
                                break;
                            case "R":
                                _pullType = TypeOfPull.Ranged;
                                Logging.WriteDebug("   cfg:  " + xvar.Name + "=Ranged");
                                break;
                        }
                    }

                    xlst = xml.SelectNodes("//Config/UseFrostMobs/Mob");
                    foreach (XmlNode xmob in xlst)
                    {
                        if (xmob == null)
                            continue;

                        xattr = xmob.Attributes["Entry"];
                        if (xattr != null)
                        {
                            ulong id = Convert.ToUInt32(xattr.InnerText);
                            if (id > 0)
                            {
                                _listUseFrost.Add(id);
                                Logging.WriteDebug("   cfg:  UseFrostOn --> " + id);
                            }
                        }
                    }

                    if (_listUseFrost.Count > 0)
                    {
                        Logging.WriteDebug("   cfg:  UseFrostOn " + _listUseFrost.Count + " mobs total");
                    }

                }
                catch (Exception e)
                {
                    Logging.WriteDebug("SHAMWOW EXCEPTION, SRC=" + e.Source);
                    Logging.WriteDebug("SHAMWOW: " + e.Message);
                }
            }
        }

        #endregion

        #region RAID HEALING FUNCTION

        private bool RaidHeal()
        {
            bool WasHealCast = false;

            if (_me.ManaPercent >= _cfg.RestHealthPercent && _me.HealthPercent >= _cfg.RestHealthPercent)
            {
                WoWPlayer p = _pvp.chooseHealTarget(_cfg.GroupNeedHealPercent);
                if (p != null)
                {
                    Slog("^Heal Target: {0}[{1}] at {2:F0}% dist: {3:F1} in-los: {4}", p.Name, p.Level, p.HealthPercent, p.Distance, p.InLineOfSight);
                    WasHealCast = RaidHeal(p);
                }
            }

            return WasHealCast;
        }

        private bool RaidHeal(WoWPlayer p)
        {
            bool WasHealCast = false;

            if (!IsHealer())
                ;
            else if (_me.ManaPercent < _cfg.RestManaPercent || _me.HealthPercent < _cfg.RestHealthPercent)
                ;
            else if (p == null || p.Dead)
                ;
            else if (p.Distance > 29.0)
                ;
            else
            {
                WoWUnit saveTarget = _me.CurrentTarget;
                p.Target();

                Safe_Dismount();
                Safe_StopMoving();

                // if in danger of dying, fastest heal possible
                if (p.HealthPercent < 25)
                {
                    if (Safe_KnownSpell("Nature's Swiftness"))
                    {
                        if (Safe_KnownSpell("Tidal Force"))
                            Safe_CastSpell("Tidal Force");

                        WasHealCast = Safe_CastSpell("Nature's Swiftness");
                        if (WasHealCast)
                            WasHealCast = Safe_CastSpell("Healing Wave");
                    }
                }
                else if (p.HealthPercent < 50)
                {
                    if (Safe_KnownSpell("Riptide"))
                        WasHealCast = Safe_CastSpell("Riptide");

                    if (Safe_KnownSpell("Chain Heal"))
                        WasHealCast = Safe_CastSpell("Chain Heal");

                    if (Safe_KnownSpell("Earth Shield") && !p.Buffs.ContainsKey("Earth Shield"))
                        Safe_CastSpell("Earth Shield");
                }

                // if no heal has been cast and we have Lesser HW in our book then use it
                if (!WasHealCast)
                {
                    if (Safe_KnownSpell("Lesser Healing Wave"))
                        WasHealCast = Safe_CastSpell("Lesser Healing Wave");
                    else
                        WasHealCast = Safe_CastSpell("Healing Wave");
                }

                if (WasHealCast)
                {
                    Thread.Sleep(150);
                }

                // _me.ClearTarget();
                if (saveTarget != null)
                    saveTarget.Target();
            }

            return WasHealCast;
        }

        #endregion

    }


    /// <summary>
    /// Custom Class PVP Support.  Provides methods useful for adding PVP support to PVE
    /// based Custom Classes in HonorBuddy.  This includes both general PVP considerations
    /// and healing.
    /// </summary>
    public class CC_PVP
    {
        private volatile LocalPlayer _me = ObjectManager.Me;

        List<WoWPlayer> _healTargets = null;

        Stopwatch _refreshTimer = new Stopwatch();

        public static bool _isAlliance = false;
        public static bool _isHorde = false;
        private static SearchParams _searchCriteria = new SearchParams
        {
            Alliance = _isAlliance,
            Horde = _isHorde,
            LineOfSight = true,
            Dead = false,
            Player = true,
            // MaxDistance = 25,
            // ObjectType = 4,
        };

        public CC_PVP()
        {
            _isAlliance = _me.IsAlliance;
            _isHorde = _me.IsHorde;
            _refreshTimer.Reset();
        }

        ~CC_PVP()
        {
        }

        /// <summary>
        /// Checks to see if you are currently in a Battleground
        /// </summary>
        /// <returns>true if in a battleground, false otherwise</returns>
        public bool IsBattleground()
        {
            //            return false;
            return Styx.Logic.Battlegrounds.Battlegroundstatus == Styx.Logic.BattlegroundStatus.Active;
        }

        /// <summary>
        /// Chooses a nearby target for healing.  Selection is based upon
        /// which nearby friendly needs heals.  Includes _me in list so
        /// will handle self-healing to you low
        /// </summary>
        /// <returns>WOWPlayer reference of nearby player needing heals</returns>
        public WoWPlayer chooseHealTarget(double healLessThan)
        {
            // use timer to ensure we aren't constantly rebuilding the list
            // .. player health and distance are very dynamic, but the number of players
            // .. in the vicinity won't change drastically in that time
            //--- NOTE:  timer is initially zero so first call builds list
            if (_refreshTimer.ElapsedMilliseconds > 5000)
            {
                _refreshTimer.Reset();
            }

            // sort the list by healing priority
            if (_refreshTimer.IsRunning)
                _healTargets.Sort(CompareHealPriority);
            else
            {
                _refreshTimer.Start();
                CreateList();
            }

            /*
            for (int b = 0; b < _healTargets.Count; b++)
            {
                Logging.Write("  Found: {0}[{1}] at {2:F0}% dist: {3:F1} in-los: {4}", _healTargets[b].Name, _healTargets[b].Level, _healTargets[b].HealthPercent, _healTargets[b].Distance, _healTargets[b].InLineOfSight );
            }
            
            Logging.Write("  Total of " + _healTargets.Count);
            */

            for (int a = 0; a < _healTargets.Count; a++)
            {
                // stop looking in sorted list if we reach 85% health
                if (_healTargets[a].HealthPercent > healLessThan)
                {
                    break;
                }

                if (_healTargets[a].Dead || _healTargets[a].HealthPercent < 0.1)
                    ;
                else if (_healTargets[a].Distance < 37 && _healTargets[a].InLineOfSight)
                {
                    // Logging.Write("Heal Target: {0}[{1}] at {2:F0}% dist: {3:F1} in-los: {4}", _healTargets[a].Name, _healTargets[a].Level, _healTargets[a].HealthPercent, _healTargets[a].Distance, _healTargets[a].InLineOfSight);
                    return _healTargets[a];
                }
            }

            return null;
        }


        private int CompareHealPriority(WoWUnit x, WoWUnit y)
        {
            if (x == null || y == null)
                return 0;

            double healthDiff = x.HealthPercent - y.HealthPercent;

            if (healthDiff < 0.0)
                return -1;

            if (healthDiff > 0.0)
                return 1;

            return 0;

            /*
             * -- Eventually determine a priority based upon general health, 
             * -- targets survivability, and targets savability (my word).
             * -- this would factor in can they be saved, are they a plater 
             * -- wearer, do they have a self-heal and mana, etc.
             * 
            const double _priorityTiers = 5;

            int xHealthPriority = (int)Math.Ceiling(x.HealthPercent / _priorityTiers);
            int yHealthPriority = (int)Math.Ceiling(y.HealthPercent / _priorityTiers);

            return xHealthPriority - yHealthPriority;
            */
        }

        private void CreateList()
        {
            List<WoWPlayer> plist = _me.RaidMembers.Count > 0 ? _me.RaidMembers : _me.PartyMembers;

            _healTargets = new List<WoWPlayer>();
            foreach (WoWPlayer p in plist)
            {
                if (p.Distance > 50 || p.Dead)
                    continue;

                if (p.Guid == _me.Guid)
                    continue;

                if (p.IsHorde != _me.IsHorde)
                    continue;

                if (p.HealthPercent < 0.1)         // players waiting on spirit rez pass the 
                    continue;                       //  .. the unit.Dead test above for some reason

                //               Logging.Write("Heal target: " + p.Class + "-" + p.Name + "[" + p.Level + "]");
                _healTargets.Add(p);
            }

            if (_healTargets.Count > 1)
            {
                _healTargets.Sort(CompareHealPriority);
            }
        }
    }

    public class CC_TalentGroup
    {
        private volatile LocalPlayer _me = ObjectManager.Me;

        public string[] _tabName = new string[4];
        public int[] _tabPoints = new int[4];
        public int _idxGroup;

        public int totalPoints
        {
            get
            {
                int nPoints = 0;
                for (int iTab = 1; iTab <= 3; iTab++)
                {
                    nPoints += _tabPoints[iTab];
                }

                return nPoints;
            }
        }

        public int Spec()
        {
            int nSpec = 0;
            if (_tabPoints[1] >= (_tabPoints[2] + _tabPoints[3]))
                nSpec = 1;
            else if (_tabPoints[2] >= (_tabPoints[1] + _tabPoints[3]))
                nSpec = 2;
            else if (_tabPoints[3] >= (_tabPoints[1] + _tabPoints[2]))
                nSpec = 3;

            return nSpec;
        }

        public CC_TalentGroup()
        {
        }

        ~CC_TalentGroup()
        {
        }

        public bool Load(int nGroup)
        {
            bool IsInGame = ObjectManager.Wow.Read<bool>((uint)GlobalOffsets.IsInGame);

            if (!IsInGame)
                return false;

            int nTab;

            _idxGroup = nGroup;

            for (nTab = 1; nTab <= 3; nTab++)
            {
                try
                {
                    List<string> tabInfo = Lua.LuaGetReturnValue("return GetTalentTabInfo(" + nTab + ",false,false," + _idxGroup + ")", "hawker.lua");

                    if (Equals(null, tabInfo))
                        return false;

                    foreach (string snippet in tabInfo)
                        Logging.Write(snippet);

                    _tabName[nTab] = tabInfo[0];
                    _tabPoints[nTab] = Convert.ToInt32(tabInfo[2]);
                }
                catch (Exception ex)
                {
                    Logging.WriteException(ex);
                }

            }

            return false;
        }

        public bool IsActiveGroup()
        {
            return GetActiveGroup() == _idxGroup;
        }

        public int GetActiveGroup()
        {
            bool IsInGame = ObjectManager.Wow.Read<bool>((uint)GlobalOffsets.IsInGame);

            if (!IsInGame)
                return 0;

            List<string> activeTalents = Lua.LuaGetReturnValue("return GetActiveTalentGroup(false,false)", "hawker.lua");

            if (!Equals(null, activeTalents))
            {
                int nActiveGroup = Convert.ToInt32(activeTalents[0]);
                return nActiveGroup;
            }
            return 0;
        }

        public void ActivateGroup()
        {
            bool IsInGame = ObjectManager.Wow.Read<bool>((uint)GlobalOffsets.IsInGame);

            if (!IsInGame)
                return;

            Lua.DoString("SetActiveTalentGroup(" + _idxGroup + ")");
        }

        public int GetNumGroups()
        {
            bool IsInGame = ObjectManager.Wow.Read<bool>((uint)GlobalOffsets.IsInGame);

            if (!IsInGame)
                return 0;

            List<string> numberOfGroups = Lua.LuaGetReturnValue("return GetNumTalentGroups(false,false)", "hawker.lua");

            if (!Equals(null, numberOfGroups))
            {
                int cntGroup = Convert.ToInt32(numberOfGroups[0]);
                return cntGroup;
            }
            return 0;
        }
    }

}