﻿namespace Styx.Bot.CustomClasses
{
    using Logic;
    using System;
    using Helpers;
    using Logic.Pathing;
    using System.Threading;
    using System.Diagnostics;
    using Logic.Common.Combat;
    using Object_Dumping_Enumeration;
    using CustomCombat.CombatInterface;
    using Memory_Read_Write_Inject.Lua;
    using Object_Dumping_Enumeration.WoWObjects;
    using System.Collections.Generic;
    using System.IO;
    using System.Runtime.InteropServices;
    using System.Xml.Linq;
    using System.Linq;
    using System.Net;
    using System.Windows.Forms;
    using System.Drawing;
    using Styx.Plugins.PluginClass;
    using System.Reflection;
    using Styx.Logic.Inventory.Frames.Gossip;
    using Styx.Logic.Pathing.NavMesh;

    public class eTrain : HBPlugin
    {
        int trainHowManyLevels = 2;//If your level is divisible by this number it will go to train thus DO NOT SET TO ZERO


        bool PermanentAbort = false;
        Styx.Logic.Pathing.NavMesh.NavMesh PlayerMesh;
        private List<string> startCity;
        int firstRunLevel = 0;
        bool needToTrain = true;
        string playerProfileMesh;
        double pathPrecision;
        bool forceTrain = false;

        public override void Pulse()
        {
            if (safeToStart && !PermanentAbort && !StuckDetector.IsStuck && ((LastTrain < ObjectManager.Me.Level && ObjectManager.Me.Level % trainHowManyLevels == 0) || forceTrain))
            {
                if (firstRunLevel != ObjectManager.Me.Level)
                {
                    needToTrain = true;
                    firstRunLevel = ObjectManager.Me.Level;
                }
                Trainer bestTrainer = MobOrganizer.ClosestTrainer;
                FlightMaster bestFlightMaster = MobOrganizer.ClosestAccessibleFlightMaster;
                if (bestTrainer.StartTrainer)
                {//Start trainer logic (substantially different)
                    Logging.Write("Starting eTrain - start trainer version!");
                    if (bestTrainer == null)
                    {
                        Logging.Write("Could not find a best trainer! Stopping training!");
                        PermanentAbort = true;
                        return;
                    }
                    PlayerMesh = Navigator.CurrentMesh;
                    NavMesh trainerMesh = Styx.Logic.Pathing.NavMesh.NavMesh.LoadFromFile(Path.Combine(Path.GetDirectoryName(Application.ExecutablePath), "Plugins\\" + bestTrainer.City[0] + ".mesh"));
                    NavNode node = PlayerMesh.OverlappingPoint(trainerMesh);
                    if (node == null)
                    {
                        PermanentAbort = true;
                        Logging.Write("Could not find suitable place to switch to training mesh! Stopping training!");
                        return;
                    }
                    Navigator.Clear();
                    while (eTrainNavigator.GoToLocation(node.Location))
                    {//go to tansfer point (eTrain mesh)
                    }
                    Navigator.Clear();
                    Logging.Write("At transfer point to trainer mesh!");
                    var curProfile = Global.CurrentProfile;
                    playerProfileMesh = curProfile.Mesh.Name;
                    curProfile.Mesh.Name = bestTrainer.City[0] + ".mesh";

                    Navigator.CurrentMesh = Styx.Logic.Pathing.NavMesh.NavMesh.LoadFromFile(Path.Combine(Path.GetDirectoryName(Application.ExecutablePath), "Plugins\\" + bestTrainer.City[0] + ".mesh"));
                    Navigator.CurrentMeshName = bestTrainer.City[0] + ".mesh";
                    Logging.Write("Loading " + bestTrainer.City[0] + ".mesh!");
                    pathPrecision = Navigator.PathPrecision;
                    Navigator.PathPrecision = 2.5;
                    Thread.Sleep(1000);
                    Navigator.Clear();
                    while (eTrainNavigator.GoToLocation(bestTrainer.Location))
                    {
                    }
                    Logging.Write("At trainer!");
                    doTrain(bestTrainer);
                    Thread.Sleep(5000);
                    Navigator.Clear();
                    while (eTrainNavigator.GoToLocation(node.Location))
                    {
                    }
                    Logging.Write("Training complete! Releasing HB to continue whatever it was doing!");
                    curProfile.Mesh.Name = playerProfileMesh;
                    Navigator.CurrentMesh = PlayerMesh;
                    Navigator.Clear();
                    LastTrain = ObjectManager.Me.Level;
                    Navigator.PathPrecision = pathPrecision;
                    forceTrain = false;
                    Thread.Sleep(1000);
                }
                else
                {
                    if (needToTrain)
                    {
                        if (bestFlightMaster == null)
                        {
                            Logging.Write("Could not find a best flight master! Stopping training!");
                            PermanentAbort = true;
                            return;
                        }
                        if (bestTrainer == null)
                        {
                            Logging.Write("Could not find a best trainer! Stopping training!");
                            PermanentAbort = true;
                            return;
                        }
                        if (!bestFlightMaster.City.Contains(bestTrainer.City[0]))
                        {
                            if (!eTrainNavigator.IsAtLocation(bestFlightMaster) && needToTrain)
                            {
                                Logging.Write("Walking to flight master " + bestFlightMaster.Name + " in " + bestFlightMaster.City[0] + "!");
                                Navigator.Clear();

                                while (eTrainNavigator.GoToMob(bestFlightMaster))
                                {
                                }
                            }
                            if (eTrainNavigator.IsAtLocation(bestFlightMaster) && needToTrain)
                            {
                                Logging.Write("At flight master!");
                                Navigator.Clear();
                                Thread.Sleep(5000);
                                bestFlightMaster.Target();
                                Thread.Sleep(5000);
                                Logging.Write("Talking to flight master " + bestFlightMaster.Name + " to fly to " + bestTrainer.City[0] + "!");
                                ObjectManager.Me.CurrentTarget.Interact();
                                Thread.Sleep(5000);
                                ObjectManager.Me.CurrentTarget.Interact();
                                Thread.Sleep(5000);
                                FlightPathHelper.GetFlightPathsFromFlightMaster();
                                bestTrainer = MobOrganizer.ClosestTrainer;
                                startCity = FlightPathHelper.CurrentCity;
                                if (startCity == null)
                                {
                                    PermanentAbort = true;
                                }
                                if (FlightPathHelper.HasFlightPath(bestTrainer.City))
                                {
                                    Logging.Write("Flying to " + bestTrainer.City[0] + "!");
                                    while (!FlightPathHelper.FlyToCity(bestTrainer.City))
                                    {
                                        WoWMovement.ClickToMove(ObjectManager.Me.Location);
                                    }

                                    Thread.Sleep(10000);
                                }
                                else
                                {
                                    Logging.Write("Could not find flightpath " + bestTrainer.City[0] + "! Aborting training!");
                                    PermanentAbort = true;
                                    return;
                                }

                                while (ObjectManager.Me.OnTaxi)
                                {
                                   
                                }
                                pathPrecision = Navigator.PathPrecision;
                                Logging.Write("Arrived in " + bestTrainer.City[0] + "!");
                                bestFlightMaster = MobOrganizer.ClosestFlightMaster;//To ensure the next part has a chance to run instantly
                            }
                        }
                        if (bestFlightMaster.City.Contains(bestTrainer.City[0]))
                        {
                            Navigator.PathPrecision = 2.5;
                            if (!eTrainNavigator.IsAtLocation(bestTrainer))
                            {
                                Navigator.Clear();
                                PlayerMesh = Navigator.CurrentMesh;
                                Logging.Write(Path.Combine(Path.GetDirectoryName(Application.ExecutablePath), "Plugins\\" + bestTrainer.City[0] + ".mesh"));

                                var curProfile = Global.CurrentProfile;
                                playerProfileMesh = curProfile.Mesh.Name;
                                curProfile.Mesh.Name = bestTrainer.City[0] + ".mesh";

                                Navigator.CurrentMesh = Styx.Logic.Pathing.NavMesh.NavMesh.LoadFromFile(Path.Combine(Path.GetDirectoryName(Application.ExecutablePath), "Plugins\\" + bestTrainer.City[0] + ".mesh"));
                                Navigator.CurrentMeshName = bestTrainer.City[0] + ".mesh";
                                Logging.Write("Loading " + bestTrainer.City[0] + ".mesh!");
                                Thread.Sleep(1000);
                                if (!eTrainNavigator.IsAtLocation(bestTrainer))
                                {
                                    Logging.Write("Walking to trainer " + bestTrainer.Name + "!");
                                    Navigator.Clear();
                                    Thread.Sleep(1000);

                                    while (!eTrainNavigator.IsAtLocation(bestTrainer))
                                    {
                                        while (eTrainNavigator.GoToMob(bestTrainer))
                                        {
                                        }
                                    }
                                }
                            }
                            if (eTrainNavigator.IsAtLocation(bestTrainer))
                            {
                                Logging.Write("At trainer " + bestTrainer.Name + "!");
                                doTrain(bestTrainer);
                                needToTrain = false;
                            }
                        }
                    }
                    if (!needToTrain)
                    {
                        bestFlightMaster = MobOrganizer.ClosestAccessibleFlightMaster;
                        if (!eTrainNavigator.IsAtLocation(bestFlightMaster))
                        {
                            Navigator.Clear();
                            Thread.Sleep(5000);
                            bestFlightMaster = MobOrganizer.ClosestAccessibleFlightMaster;
                            Logging.Write("Heading back to " + bestFlightMaster.City[0] + " flight master!");
                            while (eTrainNavigator.GoToMob(bestFlightMaster))
                            {
                            }

                        }
                        if (eTrainNavigator.IsAtLocation(bestFlightMaster))
                        {
                            Logging.Write("At flight master!");
                            Thread.Sleep(5000);
                            bestFlightMaster.Target();
                            Thread.Sleep(5000);
                            ObjectManager.Me.CurrentTarget.Interact();
                            Thread.Sleep(5000);
                            Logging.Write("Flying to " + startCity[0] + "!");
                            while (!FlightPathHelper.FlyToCity(startCity))
                            {
                                WoWMovement.ClickToMove(ObjectManager.Me.Location);
                            }
                            Thread.Sleep(5000);
                            var curProfile = Global.CurrentProfile;
                            curProfile.Mesh.Name = playerProfileMesh;
                            Navigator.CurrentMesh = PlayerMesh;
                            Logging.Write("Loading player mesh to continue botting!");
                            Thread.Sleep(5000);
                            Logging.Write("Refreshing spellbook to get new spells!");
                            SpellManager.Refresh();
                            Thread.Sleep(5000);
                            Navigator.Clear();
                            while (ObjectManager.Me.OnTaxi)
                            {
                            }
                            Navigator.PathPrecision = pathPrecision;
                            Thread.Sleep(5000);
                            Logging.Write("Finished training! Releasing HB to continue botting!");
                            LastTrain = ObjectManager.Me.Level;
                            forceTrain = false;
                        }
                    }
                }
            }
        }

        private void doTrain(Trainer bestTrainer)
        {
            Thread.Sleep(5000);
            bestTrainer.Target();
            Thread.Sleep(5000);
            ObjectManager.Me.CurrentTarget.Interact();
            Logging.Write("Talking to trainer " + bestTrainer.Name + "!");
            Thread.Sleep(10000);
            TrainerHelper.ChooseGossipTrain();
            Thread.Sleep(5000);
            Logging.Write("Training!");
            TrainerHelper.TrainAllSkills();
            Thread.Sleep(5000);
        }

        Stopwatch sw = new Stopwatch();

        public bool safeToStart
        {
            get
            {
                if (Global.Honorbuddy != null)
                {
                    if (!sw.IsRunning)
                    {
                        sw.Start();
                    }
                    if (ObjectManager.Me.Combat || !ObjectManager.Me.IsAlive || !Global.Honorbuddy.IsRunning || Global.Honorbuddy.CurrentState.GetType().Name != "StateMoveToHotSpot")
                    {
                        sw.Reset();
                        sw.Start();
                        return false;
                    }
                    if (sw.Elapsed.Seconds < 2)
                    {
                        return false;
                    }
                    return true;
                }
                return false;
            }
        }


        private static string path = Path.Combine(Path.GetDirectoryName(Application.ExecutablePath), "Plugins\\eTrain.data");
        private static int lastTrain = 0;

        public static int LastTrain
        {
            get
            {
                if (lastTrain == 0)
                {
                    if (File.Exists(path))
                    {
                        StreamReader sr = new StreamReader(path);
                        string file = sr.ReadToEnd();
                        sr.Close();
                        int level = 0;
                        foreach (string split in file.Split('\n'))
                        {
                            if (split.Contains(ObjectManager.Me.Name))
                            {
                                level = Convert.ToInt32(split.Split(':')[1]);
                            }
                        }
                        return level;

                    }
                    else
                    {
                        StreamWriter sw = new StreamWriter(path);
                        sw.Write(ObjectManager.Me.Name + ":0");
                        sw.Close();
                        return 0;
                    }
                }
                return lastTrain;
            }

            set
            {

                if (File.Exists(Path.Combine(Path.GetDirectoryName(Application.ExecutablePath), "Plugins\\eTrain.cs")))
                {
                    StreamReader sr = new StreamReader(path);
                    string file = sr.ReadToEnd();
                    sr.Close();
                    string newFile = "";
                    bool first = true;
                    foreach (string split in file.Split('\n'))
                    {
                        if (!first)
                        {
                            newFile += "\n";
                        }
                        first = false;
                        if (split.Contains(ObjectManager.Me.Name))
                        {
                            newFile += ObjectManager.Me.Name + ":" + value;
                        }
                        else
                        {
                            newFile += split;
                        }
                    }
                    File.Delete(path);
                    StreamWriter sw = new StreamWriter(path);
                    sw.Write(newFile);
                    sw.Close();
                }
                else
                {
                    StreamWriter sw = new StreamWriter(path);
                    sw.Write("\n" + ObjectManager.Me.Name + ":" + value.ToString());
                    sw.Close();
                }
                lastTrain = value;                
            }
        }

        public override string Name { get { return "eTrain"; } }

        public override string Author { get { return "erenion"; } }

        public override Version Version { get { return new Version(1, 0); } }

        public override bool WantButton { get { return true; } }

        public override void OnButtonPress()
        {
            needToTrain = true;
            forceTrain = true;
        }

        public override string ButtonText
        {
            get
            {
                return "Force Train";
            }
        }

    }

    public abstract class Mob
    {
        public WoWPoint Location;
        public string Name;
        public bool Alliance, Kalimdor;
        public List<string> City;
        public int Entry;
        public Mob(WoWPoint location, string name, bool alliance, bool kalimdor, List<string> city, int entry)
        {
            Location = location;
            Name = name;
            Alliance = alliance;
            Kalimdor = kalimdor;
            City = city;
            Entry = entry;
        }

        public double Distance
        {
            get
            {
                return ObjectManager.Me.Location.Distance(Location);
            }
        }
        public bool Accessible
        {
            get
            {
                if (Location.GetPointsAtDistanceOf(10, Navigator.CurrentMesh.FastGetNavNet()).Count > 0)
                {
                    return true;
                }
                return false;
            }
        }

        public bool Target()
        {
            ObjectManager.Update();
            Thread.Sleep(5000);
            foreach (WoWUnit wu in ObjectManager.GetObjectsOfType<WoWUnit>())
            {
                if (wu.Entry == Entry)
                {
                    wu.Target();
                }
            }
            Thread.Sleep(1000);
            if (ObjectManager.Me.CurrentTarget.Entry == Entry)
            {
                return true;
            }
            return false;
        }
    }

    public class FlightMaster : Mob
    {
        public FlightMaster(WoWPoint location, string name, bool alliance, bool kalimdor, List<string> city, int entry)
            : base(location, name, alliance, kalimdor, city, entry)
        {
        }
        public FlightMaster(WoWPoint location, string name, bool alliance, bool kalimdor, string city, int entry)
            : this(location, name, alliance, kalimdor, new List<string> {city}, entry)
        {
        }
        public FlightMaster(double x, double y, double z, string name, bool alliance, bool kalimdor, string city, int entry)
            : this(new WoWPoint(x, y, z), name, alliance, kalimdor, city, entry)
        {
        }
        public FlightMaster(double x, double y, double z, string name, bool alliance, bool kalimdor, List<string> city, int entry)
            : this(new WoWPoint(x, y, z), name, alliance, kalimdor, city, entry)
        {
        }


        //public bool IsAreaPathingAvailable(WoWPoint point)
        //{
        //    for (int i = 1; i <= 4; i++)
        //    {
        //        if (point.GetPointsAtDistanceOf(i * i, _uniqueNodes).Count >= i)
        //            return true;
        //    }

        //    return false;
        //}

        public bool HasFlightPath
        {
            get
            {
                if (FlightPathHelper.HasFlightPath(City))
                {
                    return true;
                }
                return false;
            }
        }
    }

    public class Trainer : Mob
    {
        public WoWClass Class;
        public bool StartTrainer;

                    

        public Trainer(WoWPoint location, string name, bool alliance, bool kalimdor, WoWClass wowclass,List<string> city, bool startTrainer, int entry)
            : base(location, name, alliance, kalimdor, city, entry)
        {
            Class = wowclass;
            StartTrainer = startTrainer;
        }

        public Trainer(WoWPoint location, string name, bool alliance, bool kalimdor, WoWClass wowclass, string city, bool startTrainer, int entry)
            : this(location, name, alliance, kalimdor, wowclass, new List<string> {city}, startTrainer, entry)
        {

        }
        public Trainer(double x, double y, double z, string name, bool alliance, bool kalimdor, WoWClass wowclass, string city, bool startTrainer, int entry)
            : this(new WoWPoint(x, y, z), name, alliance, kalimdor, wowclass, city, startTrainer, entry)
        {

        }

        public Trainer(double x, double y, double z, string name, bool alliance, bool kalimdor, WoWClass wowclass, List<string> city, bool startTrainer, int entry)
            : this(new WoWPoint(x, y, z), name, alliance, kalimdor, wowclass, city, startTrainer, entry)
        {

        }
    }

    public static class MobOrganizer
    {
        #region Dictionaries and Lists

        private static List<FlightMaster> _flightMasterAllianceKalimdor = new List<FlightMaster>();
        private static List<FlightMaster> _flightMasterAllianceKingdoms = new List<FlightMaster>();

        private static List<FlightMaster> _flightMasterHordeKalimdor = new List<FlightMaster>();
        private static List<FlightMaster> _flightMasterHordeKingdoms = new List<FlightMaster>();

        private static List<Trainer> trainerAllianceKalimdorDeathKnight = new List<Trainer>();
        private static List<Trainer> trainerAllianceKalimdorDruid = new List<Trainer>();
        private static List<Trainer> trainerAllianceKalimdorHunter = new List<Trainer>();
        private static List<Trainer> trainerAllianceKalimdorMage = new List<Trainer>();
        private static List<Trainer> trainerAllianceKalimdorPaladin = new List<Trainer>();
        private static List<Trainer> trainerAllianceKalimdorPriest = new List<Trainer>();
        private static List<Trainer> trainerAllianceKalimdorRogue = new List<Trainer>();
        private static List<Trainer> trainerAllianceKalimdorShaman = new List<Trainer>();
        private static List<Trainer> trainerAllianceKalimdorWarlock = new List<Trainer>();
        private static List<Trainer> trainerAllianceKalimdorWarrior = new List<Trainer>();

        private static List<Trainer> trainerAllianceKingdomsDeathKnight = new List<Trainer>();
        private static List<Trainer> trainerAllianceKingdomsDruid = new List<Trainer>();
        private static List<Trainer> trainerAllianceKingdomsHunter = new List<Trainer>();
        private static List<Trainer> trainerAllianceKingdomsMage = new List<Trainer>();
        private static List<Trainer> trainerAllianceKingdomsPaladin = new List<Trainer>();
        private static List<Trainer> trainerAllianceKingdomsPriest = new List<Trainer>();
        private static List<Trainer> trainerAllianceKingdomsRogue = new List<Trainer>();
        private static List<Trainer> trainerAllianceKingdomsShaman = new List<Trainer>();
        private static List<Trainer> trainerAllianceKingdomsWarlock = new List<Trainer>();
        private static List<Trainer> trainerAllianceKingdomsWarrior = new List<Trainer>();

        private static List<Trainer> trainerHordeKalimdorDeathKnight = new List<Trainer>();
        private static List<Trainer> trainerHordeKalimdorDruid = new List<Trainer>();
        private static List<Trainer> trainerHordeKalimdorHunter = new List<Trainer>();
        private static List<Trainer> trainerHordeKalimdorMage = new List<Trainer>();
        private static List<Trainer> trainerHordeKalimdorPaladin = new List<Trainer>();
        private static List<Trainer> trainerHordeKalimdorPriest = new List<Trainer>();
        private static List<Trainer> trainerHordeKalimdorRogue = new List<Trainer>();
        private static List<Trainer> trainerHordeKalimdorShaman = new List<Trainer>();
        private static List<Trainer> trainerHordeKalimdorWarlock = new List<Trainer>();
        private static List<Trainer> trainerHordeKalimdorWarrior = new List<Trainer>();

        private static List<Trainer> trainerHordeKingdomsDeathKnight = new List<Trainer>();
        private static List<Trainer> trainerHordeKingdomsDruid = new List<Trainer>();
        private static List<Trainer> trainerHordeKingdomsHunter = new List<Trainer>();
        private static List<Trainer> trainerHordeKingdomsMage = new List<Trainer>();
        private static List<Trainer> trainerHordeKingdomsPaladin = new List<Trainer>();
        private static List<Trainer> trainerHordeKingdomsPriest = new List<Trainer>();
        private static List<Trainer> trainerHordeKingdomsRogue = new List<Trainer>();
        private static List<Trainer> trainerHordeKingdomsShaman = new List<Trainer>();
        private static List<Trainer> trainerHordeKingdomsWarlock = new List<Trainer>();
        private static List<Trainer> trainerHordeKingdomsWarrior = new List<Trainer>();

        private static Dictionary<WoWClass, List<Trainer>> _trainerAllianceKalimdor = new Dictionary<WoWClass, List<Trainer>>()
        {
            {WoWClass.DeathKnight, trainerAllianceKalimdorDeathKnight},
            {WoWClass.Druid, trainerAllianceKalimdorDruid},
            {WoWClass.Hunter, trainerAllianceKalimdorHunter},
            {WoWClass.Mage, trainerAllianceKalimdorMage},
            {WoWClass.Paladin, trainerAllianceKalimdorPaladin},
            {WoWClass.Priest, trainerAllianceKalimdorPriest},
            {WoWClass.Rogue, trainerAllianceKalimdorRogue},
            {WoWClass.Shaman, trainerAllianceKalimdorShaman},
            {WoWClass.Warlock, trainerAllianceKalimdorWarlock},
            {WoWClass.Warrior, trainerAllianceKalimdorWarrior}
        };
        private static Dictionary<WoWClass, List<Trainer>> _trainerAllianceKingdoms = new Dictionary<WoWClass, List<Trainer>>()
        {
            {WoWClass.DeathKnight, trainerAllianceKingdomsDeathKnight},
            {WoWClass.Druid, trainerAllianceKingdomsDruid},
            {WoWClass.Hunter, trainerAllianceKingdomsHunter},
            {WoWClass.Mage, trainerAllianceKingdomsMage},
            {WoWClass.Paladin, trainerAllianceKingdomsPaladin},
            {WoWClass.Priest, trainerAllianceKingdomsPriest},
            {WoWClass.Rogue, trainerAllianceKingdomsRogue},
            {WoWClass.Shaman, trainerAllianceKingdomsShaman},
            {WoWClass.Warlock, trainerAllianceKingdomsWarlock},
            {WoWClass.Warrior, trainerAllianceKingdomsWarrior}
        };

        private static Dictionary<WoWClass, List<Trainer>> _trainerHordeKingdoms = new Dictionary<WoWClass, List<Trainer>>()
        {
            {WoWClass.DeathKnight, trainerHordeKalimdorDeathKnight},
            {WoWClass.Druid, trainerHordeKalimdorDruid},
            {WoWClass.Hunter, trainerHordeKalimdorHunter},
            {WoWClass.Mage, trainerHordeKalimdorMage},
            {WoWClass.Paladin, trainerHordeKalimdorPaladin},
            {WoWClass.Priest, trainerHordeKalimdorPriest},
            {WoWClass.Rogue, trainerHordeKalimdorRogue},
            {WoWClass.Shaman, trainerHordeKalimdorShaman},
            {WoWClass.Warlock, trainerHordeKalimdorWarlock},
            {WoWClass.Warrior, trainerHordeKalimdorWarrior}
        };

        private static Dictionary<WoWClass, List<Trainer>> _trainerHordeKalimdor = new Dictionary<WoWClass, List<Trainer>>()
        {
            {WoWClass.DeathKnight, trainerHordeKingdomsDeathKnight},
            {WoWClass.Druid, trainerHordeKingdomsDruid},
            {WoWClass.Hunter, trainerHordeKingdomsHunter},
            {WoWClass.Mage, trainerHordeKingdomsMage},
            {WoWClass.Paladin, trainerHordeKingdomsPaladin},
            {WoWClass.Priest, trainerHordeKingdomsPriest},
            {WoWClass.Rogue, trainerHordeKingdomsRogue},
            {WoWClass.Shaman, trainerHordeKingdomsShaman},
            {WoWClass.Warlock, trainerHordeKingdomsWarlock},
            {WoWClass.Warrior, trainerHordeKingdomsWarrior}
        };

        #endregion

        static MobOrganizer()
        {
            List<string> cityIronforge = new List<string> {"Ironforge, Dun Morogh","Eisenschmiede, Dun Morogh"};
            List<string> cityOrgrimmar = new List<string> {"Orgrimmar, Durotar","Orgrimmar, Durotar"};
            List<string> citySilvermoon = new List<string> {"Silvermoon City","Silbermond, Immersangald"};
            List<string> cityStormwind = new List<string> { "Stormwind, Elwynn","Sturmwind, Wald von Elwynn"};
            List<string> cityUndercity = new List<string> { "Undercity, Tirisfal","Unterstadt, Tirisfal"};
            List<string> cityThunderBuff =  new List<string> {"Thunder Bluff, Mulgore","Donnerfels, Mulgore"};
            List<string> cityDarnassus = new List<string> { "Rut'theran Village, Teldrassil"};
            
            List<string> zoneMulgore = new List<string> { "Mulgore" };
            List<string> zoneDurotar = new List<string> { "Durotar" };
            List<string> zoneTirisfall = new List<string> { "Tirisfal Glades" };
            List<string> zoneElwynn = new List<string> {"Elwynn Forest"};
            List<string> zoneDunMorogh = new List<string> { "Dun Morogh" };
            List<string> zoneTeldrassil = new List<string> { "Teldrassil" };

            //Flight Masters

            //Alliance Kingdoms Flight Masters
            AddMob(new FlightMaster(new WoWPoint(-1240.253, -2512.252, 21.8987), "Cedrik Prose", true, false, "Refuge Pointe, Arathi", 2835));
            AddMob(new FlightMaster(new WoWPoint(-4821.125, -1152.396, 502.2118), "Gryth Thurden", true, false, cityIronforge, 1573));
            AddMob(new FlightMaster(new WoWPoint(-3793.204, -782.0516, 9.014603), "Shellei Brondir", true, false, "Menethil Harbor, Wetlands", 1571));
            AddMob(new FlightMaster(new WoWPoint(-10628.32, 1037.265, 34.10924), "Thor", true, false, "Sentinel Hill, Westfall", 523));
            AddMob(new FlightMaster(new WoWPoint(282.0963, -2001.276, 194.1264), "Guthrum Thunderfist", true, false, "Aerie Peak, The Hinterlands", 8018));
            AddMob(new FlightMaster(new WoWPoint(-8835.764, 490.0841, 109.6154), "Dungar Longdrink", true, false, cityStormwind, 352));
            AddMob(new FlightMaster(new WoWPoint(928.273, -1429.078, 64.75104), "Bibilfaz Featherwhistle", true, false, "Chillwind Camp, Western Plaguelands", 12596));

            //Alliance Kalimdor flight Masters
            AddMob(new FlightMaster(6343.199, 561.6509, 15.79912, "Caylais Moonfeather", true, true, "Auberdine", 3841));
            AddMob(new FlightMaster(8640.583, 841.1181, 23.26371, "Vesprystus", true, true, cityDarnassus, 3838));

            //Horde Kalimdor Flight Masters
            //Orgrimmar - Main City trainers etc..
            AddMob(new FlightMaster(new WoWPoint(1676.252, -4313.452, 61.79523), "Doras", false, true, cityOrgrimmar, 3310));
            //Crossroads
            AddMob(new FlightMaster(new WoWPoint(-437.1371, -2596.005, 95.78777), "Devrak", false, true, "Crossroads, The Barrens", 3615));
            //Ratchet
            AddMob(new FlightMaster(new WoWPoint(-898.2459, -3769.652, 11.71038), "Bragok", false, true, "Ratchet, The Barrens", 16227));
            //Camp Taurajo
            AddMob(new FlightMaster(new WoWPoint(-2384.084, -1880.944, 95.85024), "Omusa Thunderhorn", false, true, "Camp Taurajo, The Barrens", 10378));
            //Freewind Post
            AddMob(new FlightMaster(new WoWPoint(-5407.116, -2419.612, 89.62693), "Nyse", false, true, "Freewind Post, Thousand Needles", 4317));
            //Gadgetzan
            AddMob(new FlightMaster(new WoWPoint(-7045.241, -3779.396, 10.20019), "Bulkrek Ragefist", false, true, "Gadgetzan, Tanaris", 7824));
            //Marshal's Refuge
            AddMob(new FlightMaster(new WoWPoint(-6110.542, -1140.35, -186.9493), "Gryfe", false, true, "Marshal's Refuge, Un'Goro Crater", 10583));
            //Cenarion Hold
            AddMob(new FlightMaster(new WoWPoint(-6810.202, 841.7036, 49.66529), "Runk Windtamer", false, true, "Cenarion Hold, Silithus", 15178));
            //Camp Mojache
            AddMob(new FlightMaster(new WoWPoint(-4421.943, 198.1458, 25.06311), "Shyn", false, true, "Camp Mojache, Feralas", 8020));
            //Sun Rock Retreat
            AddMob(new FlightMaster(new WoWPoint(968.0775, 1042.289, 104.3675), "Tharm", false, true, "Sun Rock Retreat, Stonetalon Mountains", 4312));
            //Splintertree Post
            AddMob(new FlightMaster(new WoWPoint(2305.636, -2520.149, 103.8097), "Vhulgra", false, true, "Splintertree Post, Ashenvale", 12616));
            //Shadowprey Village
            AddMob(new FlightMaster(new WoWPoint(-1770.37, 3262.193, 5.108521), "Thalon", false, true, "Shadowprey Village, Desolace", 6726));
            //Thunder Bluff
            AddMob(new FlightMaster(new WoWPoint(-1196.75, 26.07769, 176.9492), "Tal", false, true, cityThunderBuff, 2995));


            //Horde Kingdoms Flight Masters
            //Silvermoon
            AddMob(new FlightMaster(new WoWPoint(9376.08, -7165.447, 8.965662), "Skymistress Gloaming", false, false, citySilvermoon, 16192));
            //GhostLands
            AddMob(new FlightMaster(new WoWPoint(7595.163, -6782.237, 86.76174), "Skymaster Sunwing", false, false, "Tranquillen, Ghostlands", 16189));
            //UC
            AddMob(new FlightMaster(1567.125, 266.3454, -43.10262, "Michael Garrett", false, false, cityUndercity, 4551));

            //Trainers//

            //Alliance Kingdoms Trainers
            //Ironforge
            AddMob(new Trainer(new WoWPoint(-5035.671, -1234.642, 507.7519), "Bilban Tosslespanner", true, false, WoWClass.Warrior, cityIronforge, false, 5114));
            AddMob(new Trainer(new WoWPoint(-5010.387, -1274.048, 507.752), "Olmin Burningbeard", true, false, WoWClass.Hunter, cityIronforge, false, 5116));
            AddMob(new Trainer(new WoWPoint(-4650.119, -1120.803, 508.5508), "Fenthwick", true, false, WoWClass.Rogue, cityIronforge, false, 5167));
            AddMob(new Trainer(new WoWPoint(-4599.085, -1111.665, 504.9387), "Briarthorn", true, false, WoWClass.Warlock, cityIronforge, false, 5172));
            AddMob(new Trainer(new WoWPoint(-4720.412, -1149.962, 502.4478), "Farseer Javad", true, false, WoWClass.Shaman, cityIronforge, false, 23127));
            AddMob(new Trainer(new WoWPoint(-4604.943, -921.4888, 501.0735), "Juli Stormkettle", true, false, WoWClass.Mage, cityIronforge, false, 5145));
            AddMob(new Trainer(new WoWPoint(-4617.629, -906.6656, 501.0732), "Braenna Flintcrag", true, false, WoWClass.Priest, cityIronforge, false, 5142));
            AddMob(new Trainer(new WoWPoint(-4592.855, -907.6873, 502.7668), "Beldruk Doombrow", true, false, WoWClass.Paladin, cityIronforge, false, 5148));
            
            //Stormwind
            AddMob(new Trainer(-8971.052, 1029.896, 101.4039, "Ursula Deline", true, false, WoWClass.Warlock, cityStormwind, false, 5495));
            AddMob(new Trainer(-8741.677, 1095.502, 93.71278, "Theridran", true, false, WoWClass.Druid, cityStormwind, false, 5505));
            AddMob(new Trainer(-8519.56, 862.8282, 109.828, "Brother Joshua", true, false, WoWClass.Priest, cityStormwind, false, 5489));
            AddMob(new Trainer(-8573.129, 861.0734, 106.5193, "Arthur the Faithful", true, false, WoWClass.Paladin, cityStormwind, false, 5491));
            AddMob(new Trainer(-8415.757, 552.6982, 95.53172, "Einris Brightspear", true, false, WoWClass.Hunter, cityStormwind, false, 5515));
            AddMob(new Trainer(-8752.302, 377.5724, 101.0564, "Osborne the Night Man", true, false, WoWClass.Rogue, cityStormwind, false, 918));
            AddMob(new Trainer(-8689.32, 323.2368, 109.4382, "Wu Shen", true, false, WoWClass.Warrior, cityStormwind, false, 5479));
            AddMob(new Trainer(-9031.629, 549.8004, 73.38878, "Farseer Umbrua", true, false, WoWClass.Shaman, cityStormwind, false, 20407));


            //Alliance Kalimdor DTrainers
            //Darnassus 
            AddMob(new Trainer(10186.25, 2570.38, 1325.966, "Denatharion", true, true, WoWClass.Druid, cityDarnassus, false, 4218));
            AddMob(new Trainer(10178.04, 2511.011, 1342.874, "Jocaste", true, true, WoWClass.Hunter, cityDarnassus, false, 4146));
            AddMob(new Trainer(9654.427, 2537.32, 1331.52, "Jandria", true, true, WoWClass.Priest, cityDarnassus, false, 4091));
            AddMob(new Trainer(9940.359, 2284.55, 1341.395, "Sildanair", true, true, WoWClass.Warrior, cityDarnassus, false, 4089));
            AddMob(new Trainer(10083.71, 2546.869, 1295.041, "Syurna", true, true, WoWClass.Rogue, cityDarnassus, false, 4163));


            //Horde Kalimdor Trainers
            //Orgrimmar
            //Mage
            AddMob(new Trainer(new WoWPoint(1472.481, -4224.597, 43.18615), "Enyo", false, true, WoWClass.Mage, cityOrgrimmar, false, 5883));
            //Priest
            AddMob(new Trainer(new WoWPoint(1452.434, -4179.823, 44.27696), "Ur'kyo", false, true, WoWClass.Priest, cityOrgrimmar, false, 6018));
            //Rogue
            AddMob(new Trainer(new WoWPoint(1762.875, -4296.378, 7.675112), "Ormok", false, true, WoWClass.Rogue, cityOrgrimmar, false, 3328));
            //Warlock
            AddMob(new Trainer(new WoWPoint(1844.208, -4353.609, -14.65441), "Grol'dar", false, true, WoWClass.Warlock, cityOrgrimmar, false, 3324));
            //Shaman
            AddMob(new Trainer(new WoWPoint(1933.645, -4224.959, 42.32225), "Kardris Dreamseeker", false, true, WoWClass.Shaman, cityOrgrimmar, false, 3344));
            //Paladin
            AddMob(new Trainer(new WoWPoint(1939.694, -4133.328, 41.14505), "Master Pyreanor", false, true, WoWClass.Paladin, cityOrgrimmar, false, 23128));
            //Warrior
            AddMob(new Trainer(new WoWPoint(1980.99, -4801.59, 56.02195), "Grezz Ragefist", false, true, WoWClass.Warrior, cityOrgrimmar, false, 3353));
            //Hunter
            AddMob(new Trainer(new WoWPoint(2100.582, -4606.962, 58.92976), "Ormak Grimshot", false, true, WoWClass.Hunter, cityOrgrimmar, false, 3352));

            //Thunder Bluff
            AddMob(new Trainer(-996.9247, 278.4637, 137.5904, "Siln Skychaser", false, true, WoWClass.Shaman, cityThunderBuff, false, 3030));
            AddMob(new Trainer(-1007.059, 260.3391, 112.0315, "Malakai Cross", false, true, WoWClass.Priest, cityThunderBuff, false, 3045));
            AddMob(new Trainer(-951.1048, 279.0799, 110.9124, "Archmage Shymm", false, true, WoWClass.Mage, cityThunderBuff, false, 3047));
            AddMob(new Trainer(-1454.478, -100.4677, 159.0185, "Urek Thunderhorn", false, true, WoWClass.Hunter, cityThunderBuff, false, 3040));
            AddMob(new Trainer(-1444.953, -84.2832, 159.0186, "Ker Ragetotem", false, true, WoWClass.Warrior, cityThunderBuff, false, 3043));
            AddMob(new Trainer(-1071.278, -284.7743, 159.0304, "Kym Wildmane", false, true, WoWClass.Druid, cityThunderBuff, false, 3036));


            //Horde Kingdoms Trainers
            //Silvermoon
            //Paladin
            AddMob(new Trainer(new WoWPoint(9850.974, -7517.683, 19.73546), "Champion Bachi", false, false, WoWClass.Paladin, citySilvermoon, false, 16681));
            //Mage
            AddMob(new Trainer(new WoWPoint(9994.692, -7117.563, 47.7054), "Inethven", false, false, WoWClass.Mage, citySilvermoon, false, 16653));
            //Priest
            AddMob(new Trainer(new WoWPoint(9938.599, -7043.926, 47.71564), "Aldrae", false, false, WoWClass.Priest, citySilvermoon, false, 16658));
            //Rogue
            AddMob(new Trainer(new WoWPoint(9745.938, -7363.866, 24.33798), "Nerisen", false, false, WoWClass.Rogue, citySilvermoon, false, 16686));
            //Warlock
            AddMob(new Trainer(new WoWPoint(9788.513, -7285.699, 14.66816), "Zanien", false, false, WoWClass.Warlock, citySilvermoon, false, 16648));
            //Druid
            AddMob(new Trainer(new WoWPoint(9703.846, 7267.49, 16.13348), "Harene Plainwalker", false, true, WoWClass.Druid, citySilvermoon, false, 16655));
            //Hunter
            AddMob(new Trainer(new WoWPoint(9943.685, -7398.708, 12.38152), "Tana", false, false, WoWClass.Hunter, citySilvermoon, false, 16672));
        

            //Undercity
            AddMob(new Trainer(1788.188, 57.51563, -61.48969, "Kaelystia Hatebringer", false, false, WoWClass.Mage, cityUndercity, false, 4566));
            AddMob(new Trainer(1784.448, 401.7989, -57.21454, "Father Lankester", false, false, WoWClass.Priest, cityUndercity, false, 4607));
            AddMob(new Trainer(1407.301, 58.85395, -62.27849, "Gregory Charles", false, false, WoWClass.Rogue, cityUndercity, false, 4584));
            AddMob(new Trainer(1775.977, 46.12652, -61.48952, "Kaal Soulreaper", false, false, WoWClass.Warlock, cityUndercity, false, 4563));
            AddMob(new Trainer(1298.995, 316.802, -58.53247, "Champion Cyssa Dawnrose", false, false, WoWClass.Paladin, cityUndercity, false, 20406));
            AddMob(new Trainer(1775.772, 409.6071, -57.19757, "Angela Curthas", false, false, WoWClass.Warrior, cityUndercity, false, 4594));

            
            //Start Trainers
            //Teldrassil
            AddMob(new Trainer(10458.5, 827.8685, 1380.939, "Ayanna Everstride", true, true, WoWClass.Hunter, zoneTeldrassil, true, 3596));
            AddMob(new Trainer(10464.02, 829.5384, 1380.939, "Mardant Strongoak", true, true, WoWClass.Druid, zoneTeldrassil, true, 3597));
            AddMob(new Trainer(10519.15, 778.0143, 1329.6, "Frahun Shadewhisper", true, true, WoWClass.Rogue, zoneTeldrassil, true, 3594));
            AddMob(new Trainer(10526.61, 778.0858, 1329.599, "Alyissia", true, true, WoWClass.Warrior, zoneTeldrassil, true, 3593));
            AddMob(new Trainer(10458.76, 801.6235, 1346.754, "Shanda", true, true, WoWClass.Priest, zoneTeldrassil, true, 3595));

            AddMob(new Trainer(9741.909, 965.9996, 1293.694, "Kal", true, true, WoWClass.Druid, zoneTeldrassil, true, 3602));
            AddMob(new Trainer(9822.23, 952.0068, 1308.774, "Kyra Windblade", true, true, WoWClass.Warrior, zoneTeldrassil, true, 3598));
            AddMob(new Trainer(9790.311, 943.8697, 1308.778, "Jannok Breezesong", true, true, WoWClass.Rogue, zoneTeldrassil, true, 3599));
            AddMob(new Trainer(9905.444, 985.4329, 1313.832, "Laurna Morninglight", true, true, WoWClass.Priest, zoneTeldrassil, true, 3600));
            AddMob(new Trainer(9812.325, 928.806, 1308.109, "Dazalar", true, true, WoWClass.Hunter, zoneTeldrassil, true, 3601));


            //Elwynn
            AddMob(new Trainer(-8926.743, -195.5889, 80.58858, "Drusilla La Salle", true, false, WoWClass.Warlock, zoneElwynn, true, 459));
            AddMob(new Trainer(-8863.468, -210.9055, 80.57207, "Jorik Kerridan", true, false, WoWClass.Rogue, zoneElwynn, true, 915));
            AddMob(new Trainer(-8918.364, -208.4109, 82.12556, "Llane Beshere", true, false, WoWClass.Warrior, zoneElwynn, true, 911));
            AddMob(new Trainer(-8914.567, -215.0163, 82.11676, "Brother Sammuel", true, false, WoWClass.Paladin, zoneElwynn, true, 925));
            AddMob(new Trainer(-8853.587, -193.336, 81.93311, "Priestess Anetta", true, false, WoWClass.Priest, zoneElwynn, true, 375));
            AddMob(new Trainer(-8851.57, -188.234, 89.31459, "Khelden Bremen", true, false, WoWClass.Mage, zoneElwynn, true, 198));

            AddMob(new Trainer(-9461.849, 109.3533, 57.69606, "Lyria Du Lac", true, false, WoWClass.Warrior, zoneElwynn, true, 913));
            AddMob(new Trainer(-9468.138, 108.9756, 57.47882, "Brother Wilhelm", true, false, WoWClass.Paladin, zoneElwynn, true, 927));
            AddMob(new Trainer(-9471.675, 34.45095, 63.82258, "Zaldimar Wefhellt", true, false, WoWClass.Mage, zoneElwynn, true, 328));
            AddMob(new Trainer(-9460.753, 33.13379, 63.8224, "Priestess Josetta", true, false, WoWClass.Priest, zoneElwynn, true, 377));
            AddMob(new Trainer(-9465.792, 12.6454, 63.8225, "Keryn Sylvius", true, false, WoWClass.Rogue, zoneElwynn, true, 917));
            AddMob(new Trainer(-9472.802, -5.326606, 49.79438, "Maximillian Crowe", true, false, WoWClass.Warlock, zoneElwynn, true, 906));

            //Dun Morogh
            AddMob(new Trainer(-6120.679, 382.0895, 395.5426, "Bromos Grummner", true, false, WoWClass.Paladin, zoneDunMorogh, true, 926));
            AddMob(new Trainer(-6091.788, 365.1413, 395.5395, "Thorgas Grimson", true, false, WoWClass.Hunter, zoneDunMorogh, true, 895));
            AddMob(new Trainer(-6056.739, 393.548, 392.7595, "Branstock Khalder", true, false, WoWClass.Priest, zoneDunMorogh, true, 837));
            AddMob(new Trainer(-6056.094, 388.1749, 392.7612, "Marryk Nurribit", true, false, WoWClass.Mage, zoneDunMorogh, true, 944));
            AddMob(new Trainer(-6048.788, 391.0775, 398.9584, "Alamar Grimm", true, false, WoWClass.Warlock, zoneDunMorogh, true, 460));
            AddMob(new Trainer(-6093.748, 404.9183, 395.5373, "Solm Hargrin", true, false, WoWClass.Rogue, zoneDunMorogh, true, 916));
            AddMob(new Trainer(-6084.768, 382.1413, 395.5423, "Thran Khorman", true, false, WoWClass.Warrior, zoneDunMorogh, true, 912));

            AddMob(new Trainer(-5618.542, -454.0711, 407.6595, "Grif Wildheart", true, false, WoWClass.Hunter, zoneDunMorogh, true, 1231));
            AddMob(new Trainer(-5590.557, -529.6567, 399.6517, "Maxan Anvol", true, false, WoWClass.Priest, zoneDunMorogh, true, 1226));
            AddMob(new Trainer(-5605.729, -530.3845, 399.6549, "Granis Swiftaxe", true, false, WoWClass.Warrior, zoneDunMorogh, true, 1229));
            AddMob(new Trainer(-5604.44, -540.3233, 399.0968, "Hogral Bakkan", true, false, WoWClass.Rogue, zoneDunMorogh, true, 1234));
            AddMob(new Trainer(-5586.762, -542.1635, 403.5407, "Azar Stronghammer", true, false, WoWClass.Paladin, zoneDunMorogh, true, 1232));
            AddMob(new Trainer(-5586.939, -537.1726, 403.5408, "Magis Sparkmantle", true, false, WoWClass.Mage, zoneDunMorogh, true, 1228));
            AddMob(new Trainer(-5640.001, -528.8012, 404.2961, "Gimrizz Shadowcog", true, false, WoWClass.Warlock, zoneDunMorogh, true, 5612));

            
            //Mulgore
            AddMob(new Trainer(-2880.429, -213.0204, 54.82077, "Harutt Thunderhorn", false, true, WoWClass.Warrior, zoneMulgore, true, 3059));
            AddMob(new Trainer(-2865.395, -225.7306, 54.82082, "Lanka Farshot", false, true, WoWClass.Hunter, zoneMulgore, true, 3061));
            AddMob(new Trainer(-2873.878, -264.7088, 53.91697, "Meela Dawnstrider", false, true, WoWClass.Shaman, zoneMulgore, true, 3062));
            AddMob(new Trainer(-2873.566, -268.591, 53.91655, "Gart Mistrunner", false, true, WoWClass.Druid, zoneMulgore, true, 3060));

            AddMob(new Trainer(-2180.222, -408.8162, -4.601576, "Yaw Sharpmane", false, true, WoWClass.Hunter, zoneMulgore, true, 3065));
            AddMob(new Trainer(-2298.96, -437.7421, -5.438316, "Narm Skychaser", false, true, WoWClass.Shaman, zoneMulgore, true, 3066));
            AddMob(new Trainer(-2315.745, -442.6335, -5.438303, "Gennia Runetotem", false, true, WoWClass.Druid, zoneMulgore, true, 3064));
            AddMob(new Trainer(-2347.98, -495.9203, -9.04735, "Krang Stonehoof", false, true, WoWClass.Warrior, zoneMulgore, true, 3063));


            //Durotar
            AddMob(new Trainer(-606.8743, -4111.869, 42.94431, "Nartok", false, true, WoWClass.Warlock, zoneDurotar, true, 3156));
            AddMob(new Trainer(-588.7035, -4144.938, 41.02016, "Rwag", false, true, WoWClass.Rogue, zoneDurotar, true, 3155));
            AddMob(new Trainer(-617.395, -4202.396, 38.13412, "Ken'jai", false, true, WoWClass.Priest, zoneDurotar, true, 3707));
            AddMob(new Trainer(-623.9393, -4203.878, 38.13415, "Shikrik", false, true, WoWClass.Shaman, zoneDurotar, true, 3157));
            AddMob(new Trainer(-625.296, -4210.167, 38.13416, "Mai'ah", false, true, WoWClass.Mage, zoneDurotar, true, 5884));
            AddMob(new Trainer(-635.4618, -4227.521, 38.1341, "Jen'shan", false, true, WoWClass.Hunter, zoneDurotar, true, 3154));
            AddMob(new Trainer(-639.3438, -4230.194, 38.13401, "Frang", false, true, WoWClass.Warrior, zoneDurotar, true, 3153));

            AddMob(new Trainer(-839.2869, -4939.834, 20.99011, "Un'Thuwa", false, true, WoWClass.Mage, zoneDurotar, true, 5880));

            AddMob(new Trainer(356.192, -4837.954, 11.08908, "Dhugru Gorelust", false, true, WoWClass.Warlock, zoneDurotar, true, 3172));
            AddMob(new Trainer(268.1302, -4710.937, 17.48874, "Kaplak", false, true, WoWClass.Rogue, zoneDurotar, true, 3170));
            AddMob(new Trainer(275.3407, -4703.999, 11.62535, "Thotar", false, true, WoWClass.Hunter, zoneDurotar, true, 3171));
            AddMob(new Trainer(294.8838, -4831.495, 10.52535, "Tai'jin", false, true, WoWClass.Priest, zoneDurotar, true, 3706));
            AddMob(new Trainer(307.1142, -4839.906, 10.52421, "Swart", false, true, WoWClass.Shaman, zoneDurotar, true, 3173));
            AddMob(new Trainer(311.3524, -4827.792, 9.579612, "Tarshaw Jaggedscar", false, true, WoWClass.Warrior, zoneDurotar, true, 3169));


            //Tirisfal Glades
            AddMob(new Trainer(1848.324, 1627.631, 96.93351, "Dark Cleric Duesten", false, false, WoWClass.Priest, zoneTirisfall, true, 2123));
            AddMob(new Trainer(1847.386, 1635.52, 96.93359, "Isabella", false, false, WoWClass.Mage, zoneTirisfall, true, 2124));
            AddMob(new Trainer(1839.03, 1636.539, 96.93361, "Maximillion", false, false, WoWClass.Warlock, zoneTirisfall, true, 2126));
            AddMob(new Trainer(1859.652, 1563.301, 94.30679, "David Trias", false, false, WoWClass.Rogue, zoneTirisfall, true, 2122));
            AddMob(new Trainer(1860.867, 1557.807, 94.78255, "Dannal Stern", false, false, WoWClass.Warlock, zoneTirisfall, true, 2119));

            AddMob(new Trainer(2256.805, 233.2188, 41.11486, "Cain Firesong", false, false, WoWClass.Mage, zoneTirisfall, true, 2128));
            AddMob(new Trainer(2259.046, 250.3166, 41.11485, "Rupert Boch", false, false, WoWClass.Warlock, zoneTirisfall, true, 2127));
            AddMob(new Trainer(2265.201, 251.0545, 41.11485, "Dark Cleric Beryl", false, false, WoWClass.Priest, zoneTirisfall, true, 2129));
            AddMob(new Trainer(2271.042, 242.9965, 41.11489, "Marion Call", false, false, WoWClass.Rogue, zoneTirisfall, true, 2130));
            AddMob(new Trainer(2254.762, 238.445, 33.63386, "Austil de Mon", false, false, WoWClass.Warrior, zoneTirisfall, true, 2131));



        }

        public static string GetContinent()
        {
            return Lua.LuaGetReturnValue("return GetCurrentMapContinent()", "train.lua")[0];
        }

        private static void AddMob(Trainer trainer)
        {
            if (trainer.Alliance)
            {
                if (trainer.Kalimdor)
                {
                    _trainerAllianceKalimdor[trainer.Class].Add(trainer);
                }
                else
                {
                    _trainerAllianceKingdoms[trainer.Class].Add(trainer);
                }
            }
            else
            {
                if (trainer.Kalimdor)
                {
                    _trainerHordeKalimdor[trainer.Class].Add(trainer);
                }
                else
                {
                    _trainerHordeKingdoms[trainer.Class].Add(trainer);
                }
            }
        }

        private static void AddMob(FlightMaster flightMaster)
        {
            if (flightMaster.Alliance)
            {
                if (flightMaster.Kalimdor)
                {
                    _flightMasterAllianceKalimdor.Add(flightMaster);
                }
                else
                {
                    _flightMasterAllianceKingdoms.Add(flightMaster);
                }
            }
            else
            {
                if (flightMaster.Kalimdor)
                {
                    _flightMasterHordeKalimdor.Add(flightMaster);
                }
                else
                {
                    _flightMasterHordeKingdoms.Add(flightMaster);
                }
            }
        }

        private static List<Trainer> TrainerList
        {
            get
            {
                if (ObjectManager.Me.IsAlliance)
                {                 
                    if (GetContinent() == "1")
                    {
                        return _trainerAllianceKalimdor[ObjectManager.Me.Class];
                    }
                    else
                    {
                        return _trainerAllianceKingdoms[ObjectManager.Me.Class];
                    }
                }
                else
                {
                    if (GetContinent() == "1")
                    {
                        return _trainerHordeKalimdor[ObjectManager.Me.Class];
                    }
                    else
                    {
                        return _trainerHordeKingdoms[ObjectManager.Me.Class];
                    }
                }
            }
        }

        private static List<FlightMaster> FlightMasterList
        {
            get
            {
                if (ObjectManager.Me.IsAlliance)
                {
                    if (MobOrganizer.GetContinent() == "1")
                    {
                        return _flightMasterAllianceKalimdor;
                    }
                    else
                    {
                        return _flightMasterAllianceKingdoms;
                    }
                }
                else
                {
                    if (MobOrganizer.GetContinent() == "1")
                    {
                        return _flightMasterHordeKalimdor;
                    }
                    else
                    {
                        return _flightMasterHordeKingdoms;
                    }
                }
            }
        }

        public static Trainer ClosestTrainer
        {
            get
            {
                double distance = 2100000000;
                List<Trainer> trainers = TrainerList;
                Trainer bestTrainer = null;
                foreach (Trainer trainer in trainers)
                {
                    double trainerDistance = trainer.Distance;
                    if (trainerDistance < distance && FlightPathHelper.HasFlightPath(trainer.City))
                    {
                        if (!trainer.StartTrainer || ObjectManager.Me.Level < 12)
                        {
                            bestTrainer = trainer;
                            distance = trainerDistance;
                        }
                        
                    }
                }
                return bestTrainer; 
            }
        }

        public static FlightMaster ClosestAccessibleFlightMaster
        {
            get
            {
                double distance = 2100000000;
                List<FlightMaster> flightMasters = FlightMasterList;
                FlightMaster bestFlightMaster = null;
                foreach (FlightMaster flightMaster in flightMasters)
                {
                    double flightMasterDistance = flightMaster.Distance;
                    if (flightMasterDistance < distance)
                    {
                        if (flightMaster.Accessible)
                        {
                            bestFlightMaster = flightMaster;
                            distance = flightMasterDistance;
                        }
                    }
                }
                return bestFlightMaster;
            }
        }

        public static FlightMaster ClosestFlightMaster
        {
            get
            {
                double distance = 2100000000;
                List<FlightMaster> flightMasters = FlightMasterList;
                FlightMaster bestFlightMaster = null;
                foreach (FlightMaster flightMaster in flightMasters)
                {
                    double flightMasterDistance = flightMaster.Distance;
                    if (flightMasterDistance < distance)
                    {
                        bestFlightMaster = flightMaster;
                        distance = flightMasterDistance;  
                    }
                }
                return bestFlightMaster;
            }
        }

    }

    public static class eTrainNavigator
    {
        static Stopwatch sw = new Stopwatch();
        static float x, y, z;
        public static bool GoToMob(Mob mob)
        {
            if (x != ObjectManager.Me.Location.X || y != ObjectManager.Me.Location.Y || z != ObjectManager.Me.Location.Z)
            {
                sw.Reset();
                sw.Start();
            }
            x = ObjectManager.Me.Location.X;
            y = ObjectManager.Me.Location.Y;
            z = ObjectManager.Me.Location.Z;
            if (sw.Elapsed.Seconds > 5)
            {
                Navigator.Clear();
                Logging.Write("Why did I stop moving? Thats not fun!");
                Thread.Sleep(1000);
                sw.Reset();
                sw.Start();
            }
            if (ObjectManager.Me.Combat || !Global.Honorbuddy.IsRunning || Global.Honorbuddy.CurrentState.GetType().Name != "StateMoveToHotSpot")
            {
                Navigator.Clear();
                return false;
            }
            if (mob.Distance > 5)
            {
                Navigator.MoveTo(mob.Location);
                Thread.Sleep(500);
                return true;
            }
            return false;
        }

        public static bool GoToLocation(WoWPoint wp)
        {
            if (x != ObjectManager.Me.Location.X || y != ObjectManager.Me.Location.Y || z != ObjectManager.Me.Location.Z)
            {
                sw.Reset();
                sw.Start();
            }
            x = ObjectManager.Me.Location.X;
            y = ObjectManager.Me.Location.Y;
            z = ObjectManager.Me.Location.Z;
            if (sw.Elapsed.Seconds > 5)
            {
                Navigator.Clear();
                Logging.Write("Why did I stop moving? Thats not fun!");
                Thread.Sleep(1000);
                sw.Reset();
                sw.Start();
            }
            if (ObjectManager.Me.Combat || !Global.Honorbuddy.IsRunning || Global.Honorbuddy.CurrentState.GetType().Name != "StateMoveToHotSpot")
            {
                Navigator.Clear();
                return false;
            }
            if (wp.Distance(ObjectManager.Me.Location) > 5)
            {
                Navigator.MoveTo(wp);
                return true;
            }
            return false;
        }

        public static bool IsAtLocation(Mob mob)
        {
            if (ObjectManager.Me.Location.Distance(mob.Location) < 5)
            {
                return true;        
            }
            return false;
        }

        public static bool IsAtLocation(WoWPoint wp)
        {
            if (wp.Distance(ObjectManager.Me.Location) < 8)
            {
                return true;
            }
            return false;
        }

        public static WoWUnit findMob(Mob mob)
        {
            ObjectManager.Update();
            List<WoWUnit> closeMobs = ObjectManager.GetObjectsOfType<WoWUnit>();
            foreach (WoWUnit closeMob in closeMobs)
            {
                if (mob.Entry == closeMob.Entry)
                {
                    return closeMob;
                }
            }
            return null;
        }
    }

    public static class FlightPathHelper
    {
        private static List<string> flightCitiesAllianceKalimdor = new List<string>();
        private static List<string> flightCitiesHordeKalimdor = new List<string>();
        private static List<string> flightCitiesAllianceKingdoms = new List<string>();
        private static List<string> flightCitiesHordeKingdoms = new List<string>();
        public static bool HasFlightPath(List<string> city)
        {
            bool has;
            if (FlightPathList.Count > 0)
            {
                has = false;
            }
            else
            {
                has = true;
            }
            foreach (string fp in FlightPathList)
            {
                foreach (string theCity in city)
                {
                    if (theCity.ToLower() == fp.ToLower())
                    {
                        has = true;
                    }
                }
            }
            return has;
        }

        public static List<string> FlightPathList
        {
            get
            {
                if (ObjectManager.Me.IsAlliance)
                {
                    if (MobOrganizer.GetContinent() == "1")
                    {
                        return flightCitiesAllianceKalimdor;
                    }
                    else
                    {
                        return flightCitiesAllianceKingdoms;
                    }
                }
                else
                {
                    if (MobOrganizer.GetContinent() == "1")
                    {
                        return flightCitiesHordeKalimdor;
                    }
                    else
                    {
                        return flightCitiesHordeKingdoms;
                    }
                }
            }
        }
        public static void GetFlightPathsFromFlightMaster()
        {
            FlightPathList.Clear();
            int numFlightPaths = Convert.ToInt32(Lua.LuaGetReturnValue("return NumTaxiNodes()", "train.lua")[0]);
            for (int i = 1; i <= numFlightPaths; i++)
            {
                FlightPathList.Add(Lua.LuaGetReturnValue("return TaxiNodeName(" + i + ")", "train.lua")[0]);
            }
        }

        public static bool FlyToCity(List<string> city)
        {
            int numFlightPaths = Convert.ToInt32(Lua.LuaGetReturnValue("return NumTaxiNodes()", "train.lua")[0]);
            for (int i = 1; i <= numFlightPaths; i++)
            {
                foreach (string theCity in city)
                {
                    if (theCity.ToLower() == Lua.LuaGetReturnValue("return TaxiNodeName(" + i + ")", "train.lua")[0].ToLower())
                    {
                        Lua.DoString("TakeTaxiNode(" + i + ")");
                    }
                }
            }
            Thread.Sleep(5000);
            if (ObjectManager.Me.OnTaxi)
            {
                return true;
            }
            return false;
        }

        public static List<string> CurrentCity
        {
            get
            {
                for (int i = 1; i <= Convert.ToInt32(Lua.LuaGetReturnValue("return NumTaxiNodes()", "train.lua")[0]); i++)
                {
                    string currentCity = Lua.LuaGetReturnValue("return TaxiNodeName(" + i + ")", "train.lua")[0];
                    if (Lua.LuaGetReturnValue("return TaxiGetDestX("+i+",1)","train.lua")[0] == "0" && Lua.LuaGetReturnValue("return TaxiGetDestY("+i+",1)","train.lua")[0] == "0")
                    {
                        
                        Logging.Write("I am currently at " + currentCity + "! Now we hope I fly back here...");
                        return new List<string> { currentCity };
                    }
                }
                Logging.Write("Something went horribly wrong! Cannot find current city! Stopping training!");
                return null;
            }
        }
    }

    public static class TrainerHelper
    {
        public static bool ChooseGossipTrain()
        {
            GossipFrame frame = new GossipFrame();
            if (frame == null)
            {
                var entries = frame.GossipOptionEntries;
                if (entries == null)
                {
                    foreach (var entry in entries)
                    {
                        if (entry.Type == GossipFrame.GossipEntry.GossipEntryType.Trainer)
                        {
                            frame.SelectGossipOption(entry.Index);
                            return true;
                        }
                    }
                }
            }
            return false;
        }

        public static void TrainAllSkills()
        {
            int numTrainSkills = Convert.ToInt32(Lua.LuaGetReturnValue("return GetNumTrainerServices()", "train.lua")[0]);
            Debug.Assert(numTrainSkills != null, "eTrain error... Report to erenion: TrainAllSkills() numTrainSkills was null!");
            for (int i = 1; i <= numTrainSkills; i++)
            {
                Thread.Sleep(750);
                Lua.DoString("BuyTrainerService(" + i + ")");
            }
        }
    }

    public static class CompareMeshes
    {
        public static NavNode OverlappingPoint(this NavMesh currentMesh, NavMesh meshToSwitchTo)
        {//Returns null if there are no overlapping nodes within 500 yards
            int distanceAway = 0;
            int distanceToCancel = 499;
            List<NavNode> mesh1Sorted = new List<NavNode>();
            List<NavNode> mesh2Sorted = new List<NavNode>();
            NavNode overlapping = null;
            while (overlapping == null)
            {
                if (distanceAway > distanceToCancel)
                {
                    break;
                }
                distanceAway += 100;
                mesh1Sorted.Clear();
                mesh2Sorted.Clear();
                mesh1Sorted = PointsWithinDistance(currentMesh, distanceAway);
                mesh2Sorted = PointsWithinDistance(meshToSwitchTo, distanceAway);
                if (mesh2Sorted.Count <= 20)
                {
                    distanceToCancel += 100;
                }
                foreach (NavNode node in mesh1Sorted)
                {
                    bool breakOut = false;
                    foreach (NavNode node2 in mesh2Sorted)
                    {
                        if (node.Location.Distance(node2.Location) < 10)
                        {
                            overlapping = node;
                            breakOut = true;
                            break;
                        }
                    }
                    if (breakOut)
                    {
                        break;
                    }
                }
            }
            return overlapping;
        }

        private static List<NavNode> PointsWithinDistance(NavMesh meshToSort, int distance)
        {
            return ObjectManager.Me.Location.GetPointsAtDistanceOf(distance, meshToSort.FastGetNavNet());
        }
    }

}