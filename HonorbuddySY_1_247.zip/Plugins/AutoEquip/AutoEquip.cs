﻿#if DEBUG
#undef DEBUG
#endif

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using Styx;
using Styx.Logic.Inventory;
using Styx.Memory_Read_Write_Inject.Lua;
using Styx.Object_Dumping_Enumeration;
using Styx.Object_Dumping_Enumeration.WoWObjects;
using Styx.Plugins.PluginClass;

namespace HBAutoEquip
{
	public class AutoEquip : HBPlugin
	{
		public AutoEquip()
		{
			AutoEquipSettings.InitializeSettings();
			// If this is because of a recompile, we will be able to find the default set right now. Else we will do it again in the first pulse. :)
			AutoEquipSettings.LoadDefaultSet();
		}

		public override string Name { get { return "AutoEquip"; } }

		public override string Author { get { return "MaiN"; } }

		private readonly Version _ver = new Version(1, 2);
		public override Version Version { get { return _ver; } }

		public override string ButtonText { get { return "Select Weight Set"; } }

		public override bool WantButton { get { return true; } }

		public override void OnButtonPress()
		{
			FormWeightSelector form = new FormWeightSelector();
			form.ShowDialog();
		}

		private readonly Dictionary<InventorySlot, WoWItem> _equippedItems = new Dictionary<InventorySlot, WoWItem>();
		private readonly HashSet<WoWItem> _ignoreItems = new HashSet<WoWItem>();
		private readonly Dictionary<WoWItem, int> _equippableItemEquipTries = new Dictionary<WoWItem, int>();
		private int _lastLevel;
		private byte _pulseLimiter;
		private bool _hasInitialized;
		public override void Pulse()
		{
			if (!_hasInitialized)
			{
#if DEBUG
				AutoEquipSettings.Log("Initializing default set");
#endif
				if (AutoEquipSettings.ChosenWeightSet == null)
					AutoEquipSettings.LoadDefaultSet();
#if DEBUG
				AutoEquipSettings.Log("Initialized default set");
#endif
				_hasInitialized = true;
				return;
			}
			if (_pulseLimiter++ % 31 != 0)
				return;

			_pulseLimiter = 1;

#if DEBUG
			AutoEquipSettings.Log("Pulse");
#endif

			if (AutoEquipSettings.ChosenWeightSet == null)
			{
				AutoEquipSettings.Log("You have not yet selected a weight set!{0}Please open the form and select a weight set to use AutoEquip.", Environment.NewLine);
				return;
			}

			if (Global.Honorbuddy == null || !Global.Honorbuddy.IsRunning)
				return;

			if (ObjectManager.Me.Combat || ObjectManager.Me.Dead || ObjectManager.Me.IsGhost)
				return;


			var myLevel = ObjectManager.Me.Level;
			if (myLevel != _lastLevel)
			{
				_lastLevel = myLevel;
				_ignoreItems.Clear();
				_equippedItems.Clear();
			}

			RefreshEquippedItems();

#if DEBUG
			int tickCount = Environment.TickCount;
#endif

			var equipQualities = AutoEquipSettings.EquipQualities;
			var items = ObjectManager.GetObjectsOfType<WoWItem>(true, false);
			var equippableNewItems = new List<WoWItem>();
			foreach (var item in items)
			{
				if (_ignoreItems.Contains(item))
					continue;

				if (_equippedItems.ContainsValue(item)
					|| AutoEquipSettings.IsItemIgnored(item)
					|| AutoEquipSettings.IgnoreTypes.Contains(item.ItemInfo.InventoryType)
					|| !equipQualities.Contains(item.ItemInfo.Quality)
					|| !ObjectManager.Me.CanEquipItem(item)
					|| Lua.LuaGetReturnValue(string.Format("for bag=0,4 do if GetBagName(bag) then for slot=1,GetContainerNumSlots(bag) do if GetContainerItemID(bag, slot) == {0} then local _, count = GetContainerItemInfo(bag, slot) if count == {1} then return \"true\" end end end end end return \"false\"", item.Entry, item.StackCount), "_main.Lua")[0] != "true")
				{
					_ignoreItems.Add(item);
					continue;
				}

				if (!TestEquippableItem(item))
					continue;

				equippableNewItems.Add(item);
			}

#if DEBUG
			int took = Environment.TickCount - tickCount;
			AutoEquipSettings.Log("Linq took {0} ms {1} for each", took, (float)took / items.Count);
#endif
			if (equippableNewItems.Count == 0)
				return;

			if (AutoEquipSettings.AutoEquipItems)
			{
#if DEBUG
				tickCount = Environment.TickCount;
#endif

				CheckForItems(equippableNewItems);

#if DEBUG
				took = Environment.TickCount - tickCount;
				AutoEquipSettings.Log("Checked for items in {0} ms", took);
#endif
			}
			if (AutoEquipSettings.AutoEquipBags)
			{
#if DEBUG
				tickCount = Environment.TickCount;
#endif

				CheckForBag(equippableNewItems);

#if DEBUG
				took = Environment.TickCount - tickCount;
				AutoEquipSettings.Log("Checked for bags in {0} ms", took);
#endif
			}
		}

		private bool TestEquippableItem(WoWItem item)
		{
			if (_equippableItemEquipTries.ContainsKey(item))
			{
				if (_equippableItemEquipTries[item] > 3)
				{
					return false;
				}

				_equippableItemEquipTries[item]++;
			}
			else
			{
				_equippableItemEquipTries.Add(item, 1);
			}

			return true;
		}

		private static void EquipItemIntoSlot(WoWItem item, InventorySlot slot)
		{
			Lua.DoString(string.Format("EquipItemByName(\"{0}\", {1})", item.Name, (int)slot), "_main.lua");
			Thread.Sleep(20);

			var bond = item.ItemInfo.Bond;
			if (bond != ItemBond.BindOnEquip && bond != ItemBond.BindOnUse)
				return;

			Lua.DoString("EquipPendingItem(0)");
			Thread.Sleep(200);
		}

		private void CheckForItems(IEnumerable<WoWItem> equippableItems)
		{
			var categorizedItems = equippableItems.ToLookup(item => item.ItemInfo.InventoryType);
			foreach (var grouping in categorizedItems)
			{
				float bestEquipItemScore;
				var bestEquipItem = FindBestEquipItem(grouping, out bestEquipItemScore);
				if (bestEquipItem == null)
					continue;

#if DEBUG
				AutoEquipSettings.Log("Best item of group \"{0}\" is {1}", grouping.Key, bestEquipItem.Name);
#endif

				List<InventorySlot> equipSlots = DecideEquipmentSlots(bestEquipItem);
				float lowestItemScore;
				InventorySlot bestSlot = FindBestEquipmentSlot(equipSlots, out lowestItemScore);
				if (bestSlot == InventorySlot.End)
				{
#if DEBUG
					AutoEquipSettings.Log("I'm not equipping item {0} of inventory type {1} as there are no slots to equip it into", bestEquipItem.Name, bestEquipItem.ItemInfo.InventoryType);
#endif
					continue;
				}

				if (bestEquipItemScore > lowestItemScore)
				{
					if (lowestItemScore == float.MinValue)
						AutoEquipSettings.Log("Equipping item \"{0}\" into empty slot {1}", bestEquipItem.Name, bestSlot);
					else
						AutoEquipSettings.Log("Equipping item \"{0}\" instead of \"{1}\" - it scored {2} while the old scored {3}", bestEquipItem.Name, _equippedItems[bestSlot].Name, bestEquipItemScore, lowestItemScore);

					EquipItemIntoSlot(bestEquipItem, bestSlot);
				}
			}
		}

		private InventorySlot FindBestEquipmentSlot(IEnumerable<InventorySlot> equipSlots, out float lowestItemScore)
		{
			InventorySlot bestSlot = InventorySlot.End;
			float lowestEquippedItemScore = float.MaxValue;
			foreach (var inventorySlot in equipSlots)
			{
				if (AutoEquipSettings.ProtectedSlots.Contains(inventorySlot))
				{
#if DEBUG
					AutoEquipSettings.Log("I'm not equipping into equipment slot {0} as it is protected", inventorySlot);
#endif
					continue;
				}

				if (!_equippedItems.ContainsKey(inventorySlot))
				{
					AutoEquipSettings.Log("InventorySlot {0} is unknown! Please report this to MaiN.", inventorySlot);
					continue;
				}

				var equippedItem = _equippedItems[inventorySlot];
				if (equippedItem == null)
				{
					lowestItemScore = float.MinValue;
					return inventorySlot;
				}

				if (!AutoEquipSettings.ReplaceHeirlooms && equippedItem.Quality == WoWItemQuality.Heirloom)
				{
#if DEBUG
					AutoEquipSettings.Log("I'm not equipping anything into {0} as I can't replace heirloom items!", inventorySlot);
#endif
					continue;
				}

				float itemScore = AutoEquipSettings.ChosenWeightSet.EvaluateItem(equippedItem);
				if (itemScore < lowestEquippedItemScore)
				{
					bestSlot = inventorySlot;
					lowestEquippedItemScore = itemScore;
				}
			}

			lowestItemScore = lowestEquippedItemScore;
			return bestSlot;
		}

		private List<InventorySlot> DecideEquipmentSlots(WoWItem item)
		{
			var slots = InventoryManager.GetInventorySlotsByEquipSlot(item.ItemInfo.InventoryType);
			if (slots.Contains(InventorySlot.SecondaryHandSlot))
			{
				var mainHand = _equippedItems[InventorySlot.MainHandSlot];
				if (mainHand != null)
				{
					var type = mainHand.ItemInfo.InventoryType;
					if (type == InventoryType.TwoHandWeapon)
					{
#if DEBUG
						AutoEquipSettings.Log("I have two handed weapon equipped therefore I can't equip {0} into secondary hand slot!", item.Name);
#endif
						// This item takes up two slots - we have to ensure that the specific item will be checked against the main-hand.
						slots.Clear();
						slots.Add(InventorySlot.MainHandSlot);
					}
				}
			}

			return slots;
		}

		private WoWItem FindBestEquipItem(IEnumerable<WoWItem> items, out float bestScore)
		{
			WoWItem bestEquipItem = null;
			float bestEquipItemScore = float.MinValue;
			foreach (WoWItem item in items)
			{
				var itemScore = AutoEquipSettings.ChosenWeightSet.EvaluateItem(item);
				if (itemScore <= bestEquipItemScore)
					continue;

				bestEquipItemScore = itemScore;
				bestEquipItem = item;
			}

			bestScore = bestEquipItemScore == float.MinValue ? 0f : bestEquipItemScore;
			return bestEquipItem;
		}

		private void CheckForBag(IList<WoWItem> items)
		{
			var bestBag = FindBestBag(items);
			if (bestBag == null)
				return;
            
			for (int b = 0; b < 4; b++)
			{
				if (WoWContainer.GetBagAtIndex(b) != null)
					continue;

				InventorySlot bagSlot = (InventorySlot)((int)InventorySlot.Bag0Slot + b);
				AutoEquipSettings.Log("Equipping bag {0} into {1}", bestBag.Name, bagSlot);
				EquipItemIntoSlot(bestBag, bagSlot);
				break;
			}
		}

		public WoWItem FindBestBag(IList<WoWItem> items)
		{
			WoWItem bestBag = null;
			int mostSlots = int.MinValue;
			for (int i = 0; i < items.Count; i++)
			{
				var item = items[i];
#if DEBUG
				AutoEquipSettings.Log("Checking item {0} to see if it's a bag", item.Name);
#endif

				var itemInfo = item.GetItemInfo();
				var itemInternalInfo = itemInfo.InternalInfo;

				var itemSlots = itemInternalInfo.BagSlots;

				if (itemSlots <= 0 || itemInternalInfo.BagFamily != 0 || itemInfo.InventoryType != InventoryType.Bag)
				{
#if DEBUG
					AutoEquipSettings.Log("Item {0} is not a general type bag!", item.Name);
#endif
					continue;
				}

#if DEBUG
				AutoEquipSettings.Log("Item {0} is a bag with {1} slots!", item.Name, itemSlots);
#endif

				if (itemSlots <= mostSlots)
					continue;

				bestBag = item;
				mostSlots = itemSlots;
			}

			return bestBag;
		}

		private void RefreshEquippedItems()
		{
			var inventory = ObjectManager.Me.Inventory;
			var items = inventory.Items;

			_equippedItems.Clear();
			for (int i = 0; i < 23; i++) // The inventory includes the backpack. We ONLY want equipped items.
				_equippedItems.Add((InventorySlot)(i + 1), items[i]);
		}
	}
}