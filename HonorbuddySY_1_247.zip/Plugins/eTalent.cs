﻿namespace Styx.Bot.CustomClasses
{
    using Logic;
    using System;
    using Helpers;
    using Logic.Pathing;
    using System.Threading;
    using System.Diagnostics;
    using Logic.Common.Combat;
    using Object_Dumping_Enumeration;
    using CustomCombat.CombatInterface;
    using Memory_Read_Write_Inject.Lua;
    using Object_Dumping_Enumeration.WoWObjects;
    using System.Collections.Generic;
    using System.IO;
    using System.Runtime.InteropServices;
    using System.Xml.Linq;
    using System.Linq;
    using System.Net;
    using System.Windows.Forms;
    using System.Drawing;
    using Styx.Plugins.PluginClass;


    public class eTalent : HBPlugin
    {
        //How the talent system works: the number is the "talent number" 
        //(for example the first talent would have a talent number of 1)
        //Then the numbers in quotes specify what talent to train
        //The first number in the quote is the page number that the talent appears on
        //The second number is the talent number on that page (read it like a book
        //from left to right - when you reach the end of a row go down a row
        //For example 1,"3,1" would use your first talent point on page 3 skill 1

        #region Config
        static Dictionary<int, string> DeathKnightTalents = new Dictionary<int, string>() //Made by LiquidAtoR
        {//Blood DK Talents (54/7/10)
            { 1,"1,3" }, //Blade Barrier
            { 2,"1,3" },
            { 3,"1,3" },
            { 4,"1,3" },
            { 5,"1,3" },
            { 6,"1,4" }, //Bladed Armor
            { 7,"1,4" },
            { 8,"1,4" },
            { 9,"1,4" },
            { 10,"1,4"},
            { 11,"1,6"}, //Two-Handed Weapon Specialization (lvl 20)
            { 12,"1,6"},
            { 13,"1,7"}, //Rune Tap
            { 14,"1,8"}, //Dark Conviction
            { 15,"1,8"},
            { 16,"1,8"},
            { 17,"1,8"},
            { 18,"1,8"},
            { 19,"1,9"}, //Death Rune Mastery
            { 20,"1,9"},
            { 21,"1,9"}, // (lvl 30)
            { 22,"1,13"}, //Bloody Strikes
            { 23,"1,13"},
            { 24,"1,13"},
            { 25,"1,14"}, //Veteran of the Third War
            { 26,"1,14"},
            { 27,"1,14"},
            { 28,"1,15"}, //Mark of Blood
            { 29,"1,16"}, //Bloody Vengeance
            { 30,"1,16"},
            { 31,"1,16"}, // (lvl 40)
            { 32,"1,17"}, //Abomination's Might
            { 33,"1,17"},
            { 34,"1,18"}, //Bloodworms
            { 35,"1,18"},
            { 36,"1,18"},
            { 37,"1,21"}, //Improved Death Strike
            { 38,"1,21"},
            { 39,"1,22"}, //Sudden Doom
            { 40,"1,22"},
            { 41,"1,22"}, // (lvl 50)
            { 42,"1,23"}, //Vampiric Blood
            { 43,"1,24"}, //Will of the Necropolis
            { 44,"1,24"},
            { 45,"1,24"},
            { 46,"1,25"}, //Heart Strike
            { 47,"1,26"}, //Might of Mograine
            { 48,"1,26"},
            { 49,"1,26"},
            { 50,"1,27"}, //Blood Gorged
            { 51,"1,27"}, // (lvl 60)
            { 52,"1,27"},
            { 53,"1,27"},
            { 54,"1,27"},
            { 55,"3,3"}, //Anticipation
            { 56,"3,3"},
            { 57,"3,3"},
            { 58,"3,3"},
            { 59,"3,3"},
            { 60,"3,4"}, //Epidemic
            { 61,"3,4"}, // (lvl 70)
            { 62,"3,5"}, //Morbidity
            { 63,"3,5"},
            { 64,"3,5"},
            { 65,"2,2"}, //Runic Power Mastery
            { 66,"2,2"},
            { 67,"2,3"}, //Toughness
            { 68,"2,3"},
            { 69,"2,3"},
            { 70,"2,3"},
            { 71,"2,3"} // (lvl 80)
        };

        static Dictionary<int, string> DruidTalents = new Dictionary<int, string>() //Made by LiquidAtoR
        {//Feral Druid Talents (0/55/16)
            { 1,"2,1" }, //Ferocity
            { 2,"2,1" },
            { 3,"2,1" },
            { 4,"2,1" },
            { 5,"2,1" },
            { 6,"2,4" }, //Savage Fury
            { 7,"2,4" },
            { 8,"2,3" }, //Feral Instinct
            { 9,"2,3" },
            { 10,"2,3"},
            { 11,"2,8"}, //Sharpened Claws
            { 12,"2,8"},
            { 13,"2,8"},
            { 14,"2,6"}, //Feral Swiftness
            { 15,"2,6"},
            { 16,"2,10"}, // Predatory Strikes
            { 17,"2,10"},
            { 18,"2,10"},
            { 19,"2,12"}, //Primal Precision
            { 20,"2,12"},
            { 21,"2,11"}, //Primal Fury
            { 22,"2,11"},
            { 23,"2,9"}, //Shredding Attacks
            { 24,"2,9"},
            { 25,"2,14"}, //Feral Charge
            { 26,"2,17"}, //Heart of the Wild
            { 27,"2,17"},
            { 28,"2,17"},
            { 29,"2,17"},
            { 30,"2,17"},
            { 31,"2,19"}, //Leader of the Pack
            { 32,"2,20"}, //Improved Leader of the Pack
            { 33,"2,20"},
            { 34,"2,18"}, // Survival of the Fittest (2/3)
            { 35,"2,18"},
            { 36,"2,23"}, //Predatory Instincts
            { 37,"2,23"},
            { 38,"2,23"},
            { 39,"2,18"}, //Survival of the Fittest (3/3)
            { 40,"2,15"}, //Nurturing Instinct (1/2)
            { 41,"2,26"}, //Mangle
            { 42,"2,25"}, //King of the Jungle
            { 43,"2,25"},
            { 44,"2,25"},
            { 45,"2,27"}, //Improved Mangle (1/3)
            { 46,"2,28"}, //Rend and Tear
            { 47,"2,28"},
            { 48,"2,28"},
            { 49,"2,28"},
            { 50,"2,28"},
            { 51,"2,30"}, //Berserk
            { 52,"2,27"}, //Improved Mangle (3/3)
            { 53,"2,27"},
            { 54,"2,29"}, //Primal Gore
            { 55,"3,1"}, //Improved Mark of the Wild
            { 56,"3,1"},
            { 57,"3,3"}, //Furor (3/5)
            { 58,"3,3"},
            { 59,"3,3"},
            { 60,"3,4"}, //Naturalist
            { 61,"3,4"},
            { 62,"3,4"},
            { 63,"3,4"},
            { 64,"3,4"},
            { 65,"3,8"}, //Omen of Clarity
            { 66,"3,6"}, //Natural Shapeshifter
            { 67,"3,6"},
            { 68,"3,6"},
            { 69,"3,9"}, //Master Shapeshifter
            { 70,"3,9"},
            { 71,"2,15"} //Nurturing Instinct (2/2)
        };

        static Dictionary<int, string> HunterTalents = new Dictionary<int, string>() //Made by LiquidAtoR
        {//Beast Master Talents (53/18/0)
            { 1,"1,1" }, //Improved Aspect of the Hawk
            { 2,"1,1" },
            { 3,"1,1" },
            { 4,"1,1" },
            { 5,"1,1" },
            { 6,"1,5" }, //Thick Hide
            { 7,"1,5" },
            { 8,"1,5" },
            { 9,"1,3" }, //Focused Fire
            { 10,"1,3"},
            { 11,"1,8"}, //Aspect Mastery
            { 12,"1,9"}, //Unleashed Fury (4/5)
            { 13,"1,9"}, 
            { 14,"1,9"},
            { 15,"1,9"},
            { 16,"1,11"}, //Ferocity
            { 17,"1,11"},
            { 18,"1,11"},
            { 19,"1,11"},
            { 20,"1,11"},
            { 21,"1,13"}, //Intimidation
            { 22,"1,12"}, //Spirit Bond
            { 23,"1,12"},
            { 24,"1,14"}, //Bestial Discipline
            { 25,"1,14"},
            { 26,"1,16"}, //Frenzy
            { 27,"1,16"},
            { 28,"1,16"},
            { 29,"1,16"},
            { 30,"1,16"},
            { 31,"1,18"}, //Bestial Wrath
            { 32,"1,17"}, //Ferocious Inspiration
            { 33,"1,17"},
            { 34,"1,17"},
            { 35,"1,10"}, //Improved Mend Pet (1/2)
            { 36,"1,21"}, //Serpent's Swiftness
            { 37,"1,21"},
            { 38,"1,21"},
            { 39,"1,21"},
            { 40,"1,21"},
            { 41,"1,23"}, //The Beast Within
            { 42,"1,22"}, //Longevity
            { 43,"1,22"},
            { 44,"1,22"},
            { 45,"1,24"}, //Cobra Strikes (1/3)
            { 46,"1,25"}, //Kindred Spirits
            { 47,"1,25"},
            { 48,"1,25"},
            { 49,"1,25"},
            { 50,"1,25"},
            { 51,"1,26"}, //Beast Mastery
            { 52,"2,3"}, //Lethal Shots
            { 53,"2,3"},
            { 54,"2,3"},
            { 55,"2,3"},
            { 56,"2,3"},
            { 57,"2,5"}, //Improved Hunter's Mark
            { 58,"2,5"},
            { 59,"2,5"},
            { 60,"2,4"}, //Careful Aim
            { 61,"2,4"},
            { 62,"2,4"},
            { 63,"2,7"}, //Go for the Throat
            { 64,"2,7"},
            { 65,"2,6"}, //Mortal Shots
            { 66,"2,6"},
            { 67,"2,6"},
            { 68,"2,6"},
            { 69,"2,6"},
            { 70,"1,10"}, //Improved Mend Pet (2/2)
            { 71,"1,9"} //Unleashed Fury (5/5)
        };

        static Dictionary<int, string> CunningPetTalents = new Dictionary<int, string>()//Made by LiquidAtoR
        {//Cunning
            { 1,"4" }, //LVL 20 Great Stamina
            { 2,"4" }, //LVL 24
            { 3,"4" }, //LVL 28
            { 4,"6" }, //LVL 32 Boar's Speed
            { 5,"9" }, //LVL 36 Spiked Collar
            { 6,"9" }, //LVL 40
            { 7,"9" }, //LVL 44 
            { 8,"10" }, //LVL 48 Culling the Herd (2/3)
            { 9,"10" }, //LVL 52 
            { 10,"15"}, //LVL 56 Feeding Frenzy
            { 11,"15"}, //LVL 60 
            { 12,"10"}, //LVL 60(BM)/64 Culling the Herd (3/3)
            { 13,"16"}, //LVL 60(BM)/68 Wolverine Bite
            { 14,"17"}, //LVL 60(BM)/72 Roar of Recovery
            { 15,"11"}, //LVL 60(BM)/76 Lionhearted (1/2)
            { 16,"20"}, //LVL 64(BM)/80 Wild Hunt (1/2)
            { 17,"19"}, //LVL 68(BM) Grace of the Mantis
            { 18,"19"}, //LVL 72(BM)
            { 19,"21"}, //LVL 76(BM) Roar of Sacrifice
            { 20,"14"} //LVL 80(BM) Cornered
        };

        static Dictionary<int, string> FerocityPetTalents = new Dictionary<int, string>() //Made by LiquidAtoR
        {//Ferocity
            { 1,"4" }, //LVL 20 Great Stamina
            { 2,"4" }, //LVL 24
            { 3,"4" }, //LVL 28
            { 4,"8" }, //LVL 32 Spiked Collar
            { 5,"8" }, //LVL 36
            { 6,"8" }, //LVL 40 
            { 7,"5" }, //LVL 44 Natural Armor
            { 8,"5" }, //LVL 48
            { 9,"12" }, //LVL 52 Charge/Swoop
            { 10,"14"}, //LVL 56 Spider's Bite
            { 11,"14"}, //LVL 60
            { 12,"14"}, //LVL 60(BM)/64
            { 13,"18"}, //LVL 60(BM)/68 Call of the Wild
            { 14,"7"}, //LVL 60(BM)/72 Bloodthirsty
            { 15,"7"}, //LVL 60(BM)/76
            { 16,"20"}, //LVL 64(BM)/80 Wild Hunt (2/2)
            { 17,"13"}, //LVL 68 Heart of the Phoenix
            { 18,"20"}, //LVL 72 Wild Hunt (2/2)
            { 19,"19"}, //LVL 76 Shark Attack
            { 20,"19"} //LVL 80
        };

        static Dictionary<int, string> TenacityPetTalents = new Dictionary<int, string>() //Made by LiquidAtoR
        {//Tenacity (Bear Pet)
            { 1,"4" }, //LVL 20 Great Stamina
            { 2,"4" }, //LVL 24
            { 3,"4" }, //LVL 28
            { 4,"8" }, //LVL 32 Blood of the Rhino
            { 5,"8" }, //LVL 36
            { 6,"5" }, //LVL 40 Natural Armor (1/2)
            { 7,"11" }, //LVL 44 Guard Dog (1/2)
            { 8,"5" }, //LVL 48 Natural Armor (2/2)
            { 9,"8" }, //LVL 52 Pet barding (1/2)
            { 10,"13"}, //LVL 56 Thunderstomp
            { 11,"14"}, //LVL 60 Grace of the Mantis
            { 12,"14"}, //LVL 60(BM)/64
            { 13,"18"}, //LVL 60(BM)/68 Roar of Sacrifice
            { 14,"16"}, //LVL 60(BM)/72 Last Stand
            { 15,"8"}, //LVL 60(BM)/76 Pet Barding (2/2)
            { 16,"21"}, //LVL 64(BM)/80 Wild Hunt (1/2)
            { 17,"11"}, //LVL 68(BM) Guard Dog (2/2)
            { 18,"17"}, //LVL 72(BM) Taunt
            { 19,"21"}, //LVL 76(BM) Wild Hunt (2/2)
            { 20,"6"} //LVL 80(BM) Spiked Collar (1/3)
        };


        static Dictionary<int, string> MageTalents = new Dictionary<int, string>()
        {//Frost Mage by Nuok
            { 1,"3,1" }, //Frostbite
            { 2,"3,1" },
            { 3,"3,1" },
            { 4,"3,2" }, //Imp Frostbolt
            { 5,"3,2" },
            { 6,"3,6" }, //Precision
            { 7,"3,6" },
            { 8,"3,6" },
            { 9,"3,2" }, //Imp Frostbolt
            { 10,"3,2"}, 
            { 11,"3,9"}, //Icy Veins
            { 12,"3,8"}, //Piercing Ice
            { 13,"3,8"},
            { 14,"3,8"},
            { 15,"3,2"}, //Imp Frostbolt
            { 16,"3,12"}, //Frost Channeling
            { 17,"3,12"},
            { 18,"3,12"},
            { 19,"3,4"}, //Icy Shards
            { 20,"3,4"},
            { 21,"3,4"},
            { 22,"3,14"}, //Cold Snap
            { 23,"3,13"}, //Shatter
            { 24,"3,13"},
            { 25,"3,13"},
            { 26,"3,18"}, //Winter's Chill
            { 27,"3,18"},
            { 28,"3,18"},
            { 29,"3,17"}, //Cold as Ice
            { 30,"3,17"},
            { 31,"3,20"}, //Ice Barrier
            { 32,"3,21"}, //Artic Winds
            { 33,"3,21"},
            { 34,"3,21"},
            { 35,"3,21"},
            { 36,"3,23"}, //Fingers of Frost
            { 37,"3,23"},
            { 38,"3,22"}, //Empowered Frostbolt
            { 39,"3,22"},
            { 40,"3,21"}, //Artic Winds
            { 41,"3,25"}, //Water ele
            { 42,"3,26"}, //Enduring Winter
            { 43,"3,26"},
            { 44,"3,26"},
            { 45,"3,24"}, //Brain Freeze
            { 46,"3,27"}, //Chilled to the bone
            { 47,"3,27"},
            { 48,"3,27"},
            { 49,"3,27"},
            { 50,"3,27"},
            { 51,"3,28"}, //Deep Freeze
            { 53,"1,1"}, //Arcane Subtlety
            { 54,"1,1"},
            { 55,"1,2"}, //Arcane Focus
            { 56,"1,2"},
            { 57,"1,2"},
            { 58,"1,6"}, //Arcane Concentration
            { 59,"1,6"},
            { 60,"1,6"}, 
            { 61,"1,6"},
            { 62,"1,6"},
            { 63,"1,9"}, //Student of the mind
            { 64,"1,9"},
            { 65,"1,9"},
            { 66,"1,8"}, //Spell Impact
            { 67,"1,8"},
            { 68,"1,14"}, //Torment of the Weak 
            { 69,"1,14"},
            { 70,"1,14"},
            { 71,"1,10"} //Focus Magic

        };

        static Dictionary<int, string> PaladinTalents = new Dictionary<int, string>()//Created by happel
        {//Retribution Paladin Talents
            { 1,"3,2" }, 	// Benediction
            { 2,"3,2" },
            { 3,"3,2" },
            { 4,"3,2" },
            { 5,"3,2" },
            { 6,"3,3" }, 	// Imp. Judgement
            { 7,"3,3" },
            { 8,"3,5" },	// Imp Blessing of Might
            { 9,"3,5" },
            { 10,"3,4"},	// Heart of the Crusader
            { 11,"3,8"},	// Seal of Command
            { 12,"3,6"},	// Vindication
            { 13,"3,6"},
            { 14,"3,8"},	// Pursuit of Justice
            { 15,"3,8"},
            { 16,"3,10"},	// Eye for an Eye
            { 17,"3,10"},
            { 18,"3,11"},	// Sanctity of Battle
            { 19,"3,11"},
            { 20,"3,11"},
            { 21,"3,13"},	// Two-Handed Weapon Specialization
            { 22,"3,13"},
            { 23,"3,13"},
            { 24,"3,14"},	// Sanctified Retribution
            { 25,"3,4"},	// Heart of the Crusader
            { 26,"3,4"},
            { 27,"3,4"},
            { 28,"3,7"},	// Conviction
            { 29,"3,7"},
            { 30,"3,7"},
            { 31,"3,19"},	//Judgements of the Wise
            { 32,"3,19"},
            { 33,"3,19"},
            { 34,"3,18"},	// Repentance
            { 35,"3,17"},	// The Art of War
            { 36,"3,17"}, 
            { 37,"3,20"},	// Fanaticism
            { 38,"3,20"},
            { 39,"3,20"},
            { 40,"3,7"},	// Conviction
            { 41,"3,23"},	// Crusader Strike
            { 42,"3,22"},	// Swift Retribution
            { 43,"3,22"},
            { 44,"3,22"},
            { 45,"3,15"},	// Vengeance
            { 46,"3,15"},
            { 47,"3,15"},
            { 48,"3,25"},	// Righteous Vengeance
            { 49,"3,25"},
            { 50,"3,25"},
            { 51,"3,26"},	// Divine Storm
            { 52,"2,2"},  	// Divine Strength
            { 53,"2,2"},   
            { 54,"2,2"},
            { 55,"2,2"},
            { 56,"2,2"},
            { 57,"3,24"}, 	// Sheath of Light
            { 58,"3,24"},
            { 59,"3,24"},
            { 60,"3,2"},	// Sanctified Wrath
            { 61,"3,2"},
            { 62,"3,12"},	// Crusade
            { 63,"3,12"},
            { 64,"3,12"},
            { 65,"3,16"},	// Divine Purpose
            { 66,"3,16"},
            { 67,"2,1"},	// Divinity
            { 68,"2,1"},
            { 69,"2,1"},
            { 70,"2,1"},
            { 71,"2,1"}
                
        };


        static Dictionary<int, string> PriestTalents = new Dictionary<int, string>() //Made by erenion
        {//Shadow Priest Talents
            { 1,"3,1" },
            { 2,"3,1" },
            { 3,"3,1" },
            { 4,"3,2" },
            { 5,"3,2" },
            { 6,"3,6" },
            { 7,"3,6" },
            { 8,"3,6" },
            { 9,"3,3" },
            { 10,"3,3"},
            { 11,"3,9"},
            { 12,"3,8"},
            { 13,"3,8"},
            { 14,"3,8"},
            { 15,"3,8"},
            { 16,"3,12"},
            { 17,"3,12"},
            { 18,"3,12"},
            { 19,"3,8"},
            { 20,"3,3"},
            { 21,"3,14"},
            { 22,"3,15"},
            { 23,"3,15"},
            { 24,"3,16"},
            { 25,"3,16"},
            { 26,"3,16"},
            { 27,"3,17"},
            { 28,"3,17"},
            { 29,"3,18"},
            { 30,"3,18"},
            { 31,"3,19"},
            { 32,"3,20"},
            { 33,"3,20"},
            { 34,"3,20"},
            { 35,"3,20"},
            { 36,"3,21"},
            { 37,"3,21"},
            { 38,"3,22"},
            { 39,"3,22"},
            { 40,"3,22"},
            { 41,"3,24"},
            { 42,"3,20"},
            { 43,"3,18"},
            { 44,"3,3"},
            { 45,"3,3"},
            { 46,"3,26"},
            { 47,"3,26"},
            { 48,"3,26"},
            { 49,"3,26"},
            { 50,"3,26"},
            { 51,"3,27"},
            { 52,"3,23"},
            { 53,"3,11"},
            { 54,"3,11"},
            { 55,"3,7"},
            { 56,"3,7"},
            { 57,"3,13"},
            { 58,"1,2"},
            { 59,"1,2"},
            { 60,"1,2"},
            { 61,"1,2"},
            { 62,"1,2"},
            { 63,"1,4"},
            { 64,"1,4"},
            { 65,"1,4"},
            { 66,"1,5"},
            { 67,"1,5"},
            { 68,"1,7"},
            { 69,"1,7"},
            { 70,"1,7"},
            { 71,"3,25"}
                
        };

        static Dictionary<int, string> RogueTalents = new Dictionary<int, string>() //Made by xxAhzz
        {// Combat Rogue based on http://www.gotwarcraft.com/guides/leveling/class/rogue.php
            { 1,"2,2" },// Improved Sinister Strike
            { 2,"2,2" },
            { 3,"2,3" },// Dual Wield Specialization
            { 4,"2,3" },
            { 5,"2,3" },
            { 6,"2,3" },
            { 7,"2,3" },
            { 8,"2,4" },// Improved Slice and Dice
            { 9,"2,4" },
            { 10,"2,6"},// Precision
            { 11,"2,6"},
            { 12,"2,6"},
            { 13,"2,6"},
            { 14,"2,6"},
            { 15,"2,7"},// Endurance
            { 16,"2,12"},// Lightning Reflexes
            { 17,"2,12"},
            { 18,"2,12"},
            { 19,"2,13"},// Aggression
            { 20,"2,13"},
            { 21,"2,13"},
            { 22,"2,13"},
            { 23,"2,13"},
            { 24,"2,15"},// Blade Fury
            { 25,"2,16"},// Hack and Slash
            { 26,"2,16"},
            { 27,"2,16"},
            { 28,"2,16"},
            { 29,"2,16"},
            { 30,"2,17"},// Weapon Expertise
            { 31,"2,17"},
            { 32,"2,18"},// Blade Twisting
            { 33,"2,18"},
            { 34,"2,19"},// Vitality
            { 35,"2,19"},
            { 36,"2,19"},
            { 37,"2,20"},// Adrenaline Rush
            { 38,"2,23"},// Combat Potency
            { 39,"2,23"},
            { 40,"2,23"},
            { 41,"2,23"},
            { 42,"2,23"},
            { 43,"2,25"},// Surprise Attacks
            { 44,"2,26"},// Savage Combat
            { 45,"2,26"},
            { 46,"2,27"},// Prey on the Weak
            { 47,"2,27"},
            { 48,"2,27"},
            { 49,"2,27"},
            { 50,"2,27"},
            { 51,"2,28"},// Killing Spree
            { 52,"1,3"},// Malice
            { 53,"1,3"},
            { 54,"1,3"},
            { 55,"1,3"},
            { 56,"1,3"},
            { 57,"1,4"},// Ruthlessness
            { 58,"1,4"},
            { 59,"1,4"},
            { 60,"1,5"},// Blood Spatter
            { 61,"1,5"},
            { 62,"1,9"},// Lethality
            { 63,"1,9"},
            { 64,"1,9"},
            { 65,"1,9"},
            { 66,"1,9"},
            { 67,"3,1"},// Relentless Strikes
            { 68,"3,1"},
            { 69,"3,1"},
            { 70,"3,1"},
            { 71,"3,1"}
        };

        static Dictionary<int, string> ShamanTalents = new Dictionary<int, string>() //Created by ashram666
        {//Enhancement Shaman Talents
            { 1,"2,3" },
            { 2,"2,3" },
            { 3,"2,3" },
            { 4,"2,3" },
            { 5,"2,3" },
            { 6,"2,5" },
            { 7,"2,5" },
            { 8,"2,5" },
            { 9,"2,5" },
            { 10,"2,5"},
            { 11,"2,6"},
            { 12,"2,6"},
            { 13,"2,9"},
            { 14,"2,8"},
            { 15,"2,8"},
            { 16,"2,11"},
            { 17,"2,11"},
            { 18,"2,11"},
            { 19,"2,11"},
            { 20,"2,11"},
            { 21,"2,8"},
            { 22,"2,14"},
            { 23,"2,15"},
            { 24,"2,15"},
            { 25,"2,15"},
            { 26,"2,16"},
            { 27,"2,16"},
            { 28,"2,16"},
            { 29,"2,17"},
            { 30,"2,17"},
            { 31,"2,21"},
            { 32,"2,20"},
            { 33,"2,19"},
            { 34,"2,19"},
            { 35,"2,19"},
            { 36,"2,23"},
            { 37,"2,24"},
            { 38,"2,24"},
            { 39,"2,22"},
            { 40,"2,22"},
            { 41,"2,26"},
            { 42,"2,22"},
            { 43,"2,25"},
            { 44,"2,25"},
            { 45,"2,25"},
            { 46,"2,28"},
            { 47,"2,28"},
            { 48,"2,28"},
            { 49,"2,28"},
            { 50,"2,28"},
            { 51,"2,29"},
            { 52,"1,2"},
            { 53,"1,2"},
            { 54,"1,2"},
            { 55,"1,2"},
            { 56,"1,2"},
            { 57,"1,4"},
            { 58,"1,4"},
            { 59,"1,5"},
            { 60,"1,5"},
            { 61,"1,5"},
            { 62,"1,8"},
            { 63,"1,8"},
            { 64,"1,8"},
            { 65,"1,8"},
            { 66,"1,8"},
            { 67,"1,7"},
            { 68,"1,6"},
            { 69,"1,6"},
            { 70,"1,6"},
            { 71,"1,6"}
        };

        static Dictionary<int, string> WarlockTalents = new Dictionary<int, string>() //Made by LiquidAtoR
        {//DemoLock Talents (0/51/20)
            { 1,"2,3" }, //Demonic Embrace
            { 2,"2,3" },
            { 3,"2,3" },
            { 4,"2,4" }, //Fel Synergy
            { 5,"2,4" },
            { 6,"2,7" }, //Fel Vitality
            { 7,"2,7" },
            { 8,"2,7" },
            { 9,"2,1" }, //Improved Healthstone
            { 10,"2,1"},
            { 11,"2,9"}, //Soul Link
            { 12,"2,11"}, //Demonic Aegis
            { 13,"2,11"},
            { 14,"2,11"},
            { 15,"2,10"}, //Fel Domination
            { 16,"2,12"}, //Unholy Power
            { 17,"2,12"},
            { 18,"2,12"},
            { 19,"2,12"},
            { 20,"2,12"},
            { 21,"2,14"}, //Mana Feed
            { 22,"2,5"}, //Improved Health Funnel
            { 23,"2,5"},
            { 24,"2,15"}, //Master Conjurer
            { 25,"2,15"},
            { 26,"2,16"}, //Master Demonologist
            { 27,"2,16"},
            { 28,"2,16"},
            { 29,"2,16"},
            { 30,"2,16"},
            { 31,"2,19"}, //Demonic Empowerment
            { 32,"2,17"}, //Molten Core
            { 33,"2,17"},
            { 34,"2,17"},
            { 35,"2,20"}, //Demonic Knowledge (1/3)
            { 36,"2,21"}, //Demonic Tactics
            { 37,"2,21"},
            { 38,"2,21"},
            { 39,"2,21"},
            { 40,"2,21"},
            { 41,"2,24"}, //Summon Felguard
            { 42,"2,20"}, //Demonic knowledge (3/3)
            { 43,"2,20"},
            { 44,"2,18"}, //Demonic Resilience (2/3)
            { 45,"2,18"},
            { 46,"2,26"}, //Demonic Pact
            { 47,"2,26"},
            { 48,"2,26"},
            { 49,"2,26"},
            { 50,"2,26"},
            { 51,"2,27"}, //Metamorphosis
            { 52,"3,2"}, //Bane
            { 53,"3,2"},
            { 54,"3,2"},
            { 55,"3,2"},
            { 56,"3,2"},
            { 57,"3,3"}, //Aftermath
            { 58,"3,3"},
            { 59,"3,4"}, //Molten Skin
            { 60,"3,4"},
            { 61,"3,4"},
            { 62,"3,8"}, //Ruin
            { 63,"3,8"},
            { 64,"3,8"},
            { 65,"3,8"},
            { 66,"3,8"},
            { 67,"3,9"}, //Intensity
            { 68,"3,9"},
            { 69,"3,10"}, //Destructive Reach
            { 70,"3,10"},
            { 71,"3,7"} //Shadowburn
        };

        static Dictionary<int, string> WarriorTalents = new Dictionary<int, string>()
        {//Fury Warrior by Nuok
            { 1,"2,1" }, //Armored to the Teeth
            { 2,"2,1" },
            { 3,"2,1" },
            { 4,"2,3" }, //Curelty
            { 5,"2,3" },
            { 6,"2,3" }, 
            { 7,"2,3" },
            { 8,"2,3" },
            { 9,"2,2" }, //Booming Voice
            { 10,"2,2"},
            { 11,"2,8"}, //Blood Craze
            { 12,"2,8"},
            { 13,"2,8"},
            { 14,"2,9"}, //Commanding Presence
            { 15,"2,9"},
            { 16,"2,10"}, //Dual Wield Specialization
            { 17,"2,10"},
            { 18,"2,10"},
            { 19,"2,10"},
            { 20,"2,10"},
            { 21,"2,13"},  //Percision
            { 22,"2,13"},
            { 23,"2,13"},
            { 24,"2,14"},  //Death Wish
            { 25,"2,9"},  //Commanding Presence
            { 26,"2,17"},  //Flurry
            { 27,"2,17"},
            { 28,"2,17"},
            { 29,"2,17"},
            { 30,"2,17"},
            { 31,"2,19"},  //Bloodthirst
            { 32,"2,20"},  //Improved Whirlwind
            { 33,"2,20"},
            { 34,"2,12"},  //Enrage
            { 35,"2,12"}, 
            { 36,"2,22"}, //Improved Berserker Stance
            { 37,"2,22"},
            { 38,"2,22"},
            { 39,"2,22"},
            { 40,"2,22"}, 
            { 41,"2,24"}, //Rampage
            { 42,"2,12"}, //Enrage
            { 43,"2,12"}, 
            { 44,"2,12"}, 
            { 45,"2,18"}, //Inensify Rage
            { 46,"2,26"}, //Unending Fury
            { 47,"2,26"},
            { 48,"2,26"},
            { 49,"2,26"},
            { 50,"2,26"}, 
            { 51,"2,27"}, //Titan's Grip
            { 52,"1,1"}, //Imp Heroic Strike
            { 53,"1,1"},
            { 54,"1,1"},
            { 55,"1,3"}, //Imp Rend
            { 56,"1,3"},
            { 57,"1,4"}, //Imp Charge 
            { 58,"1,4"},
            { 59,"1,2"}, //Deflection 
            { 60,"1,2"},
            { 61,"1,2"},
            { 62,"1,9"}, //Impale 
            { 63,"1,9"},
            { 64,"1,10"}, //Deep Wounds
            { 65,"1,10"}, 
            { 66,"1,10"},
            { 67,"1,11"}, //Two-Handed Wep Spec
            { 68,"1,11"},
            { 69,"1,11"},
            { 70,"2,18"}, //Intensify Rage
            { 71,"2,18"}

        };

        #endregion

        //Do not edit below this line

        Dictionary<WoWClass, Dictionary<int, string>> Talents = new Dictionary<WoWClass, Dictionary<int, string>>()
        {
            {WoWClass.DeathKnight, DeathKnightTalents},
            {WoWClass.Druid, DruidTalents},
            {WoWClass.Hunter, HunterTalents},
            {WoWClass.Mage, MageTalents},
            {WoWClass.Paladin, PaladinTalents},
            {WoWClass.Priest, PriestTalents},
            {WoWClass.Rogue, RogueTalents},
            {WoWClass.Shaman, ShamanTalents},
            {WoWClass.Warlock, WarlockTalents},
            {WoWClass.Warrior, WarriorTalents}
        };

        Dictionary<string, Dictionary<int, string>> TalentsPet = new Dictionary<string, Dictionary<int, string>>()
        {
            {"Tenacity",TenacityPetTalents},
            {"Ferocity",FerocityPetTalents},
            {"Cunning",CunningPetTalents}
        };

        private static Stopwatch sw = new Stopwatch();

        public override void Pulse()
        {
            if (!sw.IsRunning)
            {
                sw.Start();
                doTalents();
            }
            else if (sw.Elapsed.TotalMinutes > 5 && !ObjectManager.Me.Combat)
            {
                sw.Reset();
                sw.Start();
                doTalents();
            }
        }

        public void doTalents()
        {
            int numTalent = Convert.ToInt32(Lua.LuaGetReturnValue("return GetUnspentTalentPoints(false, false, nil)", "talent.lua")[0]);
            if (numTalent > 0)
            {
                Logging.LogMessage("Running talents!");
                int lastTalent = ObjectManager.Me.Level - 9;//total # of talents
                int firstTalent = lastTalent - numTalent + 1;
                for (int talent = firstTalent; talent <= lastTalent; talent++)
                {
                    Thread.Sleep(2000);
                    Logging.LogMessage("Placing talent number " + talent);
                    string[] talentInfo = Talents[ObjectManager.Me.Class][talent].Split(',');
                    Lua.DoString("LearnTalent(" + talentInfo[0] + ", " + talentInfo[1] + ", false, nil)");
                }
            }
            string talentTreePet = Lua.LuaGetReturnValue("return GetPetTalentTree()", "talent.lua")[0];  
            if (talentTreePet != "nil" && talentTreePet != "")
            {
                Logging.LogMessage(talentTreePet + " is the pet talent tree!");
                int numTalentPet = Convert.ToInt32(Lua.LuaGetReturnValue("return GetUnspentTalentPoints(false, true, nil)", "talent.lua")[0]);
                if (numTalentPet > 0)
                {
                    Logging.LogMessage("Running pet talents!");
                    int numTalentsUsedPet = Convert.ToInt32(Lua.LuaGetReturnValue("return select(3, GetTalentTabInfo(1,false,true,nil))", "talent.lua")[0]);
                    int firstTalentPet = numTalentsUsedPet + 1;
                    int lastTalentPet = numTalentPet + numTalentsUsedPet;
                    for (int talent = firstTalentPet; talent <= lastTalentPet; talent++)
                    {
                        Thread.Sleep(2000);
                        Logging.LogMessage("Placing pet talent number " + talent);
                        string talentInfo = TalentsPet[talentTreePet][talent];
                        Lua.DoString("LearnTalent(1, " + talentInfo + ", true, nil)");
                        Logging.LogMessage("Talent info " + talentInfo);
                    }
                }
            }
        }

        public override string Name { get { return "eTalent"; } }

        public override string Author { get { return "erenion"; } }

        public override Version Version { get { return new Version(1, 3); } }

        public override bool WantButton { get { return false; } }

    }
}
