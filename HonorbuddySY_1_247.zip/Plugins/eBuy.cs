﻿namespace Styx.Bot.CustomClasses
{
    using Logic;
    using System;
    using Helpers;
    using Logic.Pathing;
    using System.Threading;
    using System.Diagnostics;
    using Logic.Common.Combat;
    using Object_Dumping_Enumeration;
    using CustomCombat.CombatInterface;
    using Memory_Read_Write_Inject.Lua;
    using Object_Dumping_Enumeration.WoWObjects;
    using System.Collections.Generic;
    using System.IO;
    using System.Runtime.InteropServices;
    using System.Xml.Linq;
    using System.Linq;
    using System.Net;
    using System.Windows.Forms;
    using System.Drawing;
    using Styx.Plugins.PluginClass;


    public class eBuy : HBPlugin
    {

        List<ItemToBuy> items = new List<ItemToBuy>()
        {
            //example: new ItemToBuy("Vendor Name",xLocation,yLocation,zLocation,"itemName",stacktobuyat,numbertohave,item#invendor,stacksizesold),
            //For example:
            //new ItemToBuy("Vikki Lonsav",-1272.656,-2533.512,21.38472,"Solid Shot",1000,1200,12, 200),
        };


        Stopwatch sw = new Stopwatch();
        public override void Pulse()
        {
            if ((!sw.IsRunning && Global.Honorbuddy.IsRunning) || Global.Honorbuddy.CurrentState.GetType().Name != "StateMoveToHotSpot")
            {
                sw.Reset();
                sw.Start();
            }
            if (!ObjectManager.Me.Combat && Global.Honorbuddy.IsRunning && sw.Elapsed.TotalSeconds > 5 && Global.Honorbuddy.CurrentState.GetType().Name == "StateMoveToHotSpot")
            {
                sw.Reset(); 
                sw.Start();
                foreach (ItemToBuy item in items)
                {
                    if ((eBuyHelper.numberOfItems(item) < item.minAmount || (Global.Honorbuddy.CurrentState.GetType().Name == "StateAtVendor" && eBuyHelper.numberOfItems(item) > item.maxAmount)) && eBuyHelper.lastBuyTime(item) > new TimeSpan(0, 5, 0))
                    {
                        if (item.location.GetPointsAtDistanceOf(10, Navigator.CurrentMesh.FastGetNavNet()).Count > 0)
                        {
                            eBuyHelper.moveAndBuy(item);
                        }
                        else
                        {
                            Logging.Write("eBuy: Your mesh cannot move to " + item.vendor + " to buy " + item.itemName + "!");
                        }
                    }
                }
            }
        }

        public override string Name { get { return "eBuy"; } }

        public override string Author { get { return "erenion"; } }


        public override Version Version { get { return new Version(1, 0); } }

        public override bool WantButton { get { return false; } }

    }

    public static class eBuyHelper
    {
        private static Dictionary<ItemToBuy, DateTime> lastBuy = new Dictionary<ItemToBuy, DateTime>();
        public static int numberOfItems(ItemToBuy theitem)
        {
            int number = 0;
            foreach (WoWItem item in ObjectManager.GetObjectsOfType<WoWItem>())
            {
                if (theitem.itemName == item.Name)
                {
                    number += item.StackCount;
                }
            }
            return number;
        }
        public static void buyItem(ItemToBuy item)
        {
            if (lastBuy.ContainsKey(item))
            {
                lastBuy.Remove(item);
            }
            foreach (WoWUnit wu in ObjectManager.GetObjectsOfType<WoWUnit>())
            {
                if (wu.Name == item.vendor)
                {
                    wu.Target();
                    Thread.Sleep(1000);
                    wu.Interact();
                    Thread.Sleep(1000);
                    int startNumber = numberOfItems(item);
                    int numToBuy = item.maxAmount - startNumber;
                    int stacksToBuy = numToBuy / item.stacksize;
                    while (numberOfItems(item) < item.maxAmount && !ObjectManager.Me.Combat && ObjectManager.Me.IsAlive)
                    {
                        if (stacksToBuy < 1)
                        {
                            break;
                        }
                        Lua.DoString("BuyMerchantItem(\"" + item.index + "\",1)");
                        Thread.Sleep(500);
                        stacksToBuy--;
                    }
                    
                }
                if (ObjectManager.Me.Combat)
                {
                    Logging.Write("Combat started! Aborting buying " + item.itemName + "!");
                    return;
                }
            }
            if (ObjectManager.Me.Combat)
            {
                Logging.Write("Combat started! Aborting buying " + item.itemName + "!");
                return;
            }
            lastBuy.Add(item, DateTime.Now);
        }

        public static TimeSpan lastBuyTime(ItemToBuy item)
        {
            if (lastBuy.ContainsKey(item))
            {
                return DateTime.Now - lastBuy[item];
            }
            else
            {
                return new TimeSpan(9,9,9);
            }
        }

        public static double distanceToVendor(ItemToBuy item)
        {
            foreach (WoWUnit wu in ObjectManager.GetObjectsOfType<WoWUnit>())
            {
                if (wu.Name == item.vendor)
                {
                    return wu.Distance;
                }
            }
            return 9999999;
        }

        public static WoWPoint vendorLocation(ItemToBuy item)
        {
            foreach (WoWUnit wu in ObjectManager.GetObjectsOfType<WoWUnit>())
            {
                if (wu.Name == item.vendor)
                {
                    return wu.Location;
                }
            }
            return new WoWPoint(0, 0, 0);
        }

        public static void moveAndBuy(ItemToBuy item)
        {
            Navigator.Clear();
            WoWMovement.MoveStop();
            Logging.Write("Moving to buy " + item.itemName + "!");
            Stopwatch sw = new Stopwatch();
            float x = 0, y = 0, z = 0;
            while (!ObjectManager.Me.Combat && ObjectManager.Me.Location.Distance(item.location) > 20 && ObjectManager.Me.IsAlive)
            {
                if (x != ObjectManager.Me.Location.X || y != ObjectManager.Me.Location.Y || z != ObjectManager.Me.Location.Z)
                {
                    sw.Reset();
                    sw.Start();
                }
                x = ObjectManager.Me.Location.X;
                y = ObjectManager.Me.Location.Y;
                z = ObjectManager.Me.Location.Z;
                if (sw.Elapsed.Seconds > 5)
                {
                    Navigator.Clear();
                    Logging.Write("Why did I stop moving? Thats not fun!");
                    Thread.Sleep(1000);
                    sw.Reset();
                    sw.Start();
                }
                navigateToPoint(item.location);
            }
            if (ObjectManager.Me.Combat)
            {
                Logging.Write("Combat started! Aborting buying " + item.itemName + "!");
                return;
            }
            Navigator.Clear();
            WoWMovement.MoveStop();
            WoWPoint vendorLoc = vendorLocation(item);
            Logging.Write("Moving to vendor " + item.itemName + "!");
            while (!ObjectManager.Me.Combat && ObjectManager.Me.Location.Distance(vendorLoc) > 5 && ObjectManager.Me.IsAlive)
            {
                navigateToPoint(vendorLoc);
            }
            if (ObjectManager.Me.Combat)
            {
                Logging.Write("Combat started! Aborting buying " + item.itemName + "!");
                return;
            }
            Logging.Write("Buying " + item.itemName + "!");
            buyItem(item);
            Navigator.Clear();
            WoWMovement.MoveStop();
        }

        public static void navigateToPoint(WoWPoint wp)
        {
            Navigator.MoveTo(wp);
        }
    }

    public class ItemToBuy
    {
        public string vendor, itemName;
        public WoWPoint location;
        public int minAmount, maxAmount, index, stacksize;
        
        public ItemToBuy()
        {
        }

        public ItemToBuy(string vendor, WoWPoint location, string itemName, int minAmount, int maxAmount, int index, int stacksize)
        {
            this.vendor = vendor;
            this.itemName = itemName;
            this.location = location;
            this.minAmount = minAmount;
            this.maxAmount = maxAmount;
            this.index = index;
            this.stacksize = stacksize;
        }
        public ItemToBuy(string vendor, double x, double y, double z, string itemName, int minAmount, int maxAmount, int index, int stacksize)
        {
            this.vendor = vendor;
            this.itemName = itemName;
            location = new WoWPoint(x, y, z);
            this.minAmount = minAmount;
            this.maxAmount = maxAmount;
            this.index = index;
            this.stacksize = stacksize;
        }
    }
}
