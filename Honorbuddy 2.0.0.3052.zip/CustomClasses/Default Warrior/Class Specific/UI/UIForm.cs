﻿using System;
using System.Windows.Forms;
using Settings = Hera.Config.Settings;

namespace Hera.UI
{
    public partial class UIForm : Form
    {
        public UIForm()
        {
            InitializeComponent();
        }

        private void UIForm_Load(object sender, EventArgs e)
        {
            // Load the settings from the XML file
            Settings.Load();
            this.Text = String.Format("{0} by {1}", FpswareWarrior.CCName.ToUpper(), FpswareWarrior.AuthorName);
            lblCCName.Text = FpswareWarrior.CCName.ToUpper();

            // Populate the controls on the UI with the values from the settings
            
            // Common - Rest and Healing
            EatBar.Value = Settings.RestHealth;
            HealthPotionBar.Value = Settings.HealthPotion;

            // Combat
            Rend.SelectedItem = Settings.Rend;
            ThunderClap.SelectedItem = Settings.ThunderClap;
            Shout.SelectedItem = Settings.Shout;
            DeathWish.SelectedItem = Settings.DeathWish;
            BerserkerRage.SelectedItem = Settings.BerserkerRage;
            Execute.SelectedItem = Settings.Execute;
            DeadlyCalm.SelectedItem = Settings.DeadlyCalm;
            Cleave.SelectedItem = Settings.Cleave;
            Whirlwind.SelectedItem = Settings.Whirlwind;

            // Advanced
            RAFTarget.SelectedItem = Settings.RAFTarget;
            Debug.SelectedItem = Settings.Debug;



            
        }

        private void SaveSettings_Click(object sender, EventArgs e)
        {
            // Save the settings to the XML file
            Settings.Save();

            // DirtyData tells the CC the data has possibly changed and it needs to reload it
            Settings.DirtyData = true;
            Close();
        }



        /// <summary>
        /// Changed the enabled/disabled status of a combobox dependant on the associated spell being known
        /// </summary>
        /// <param name="uiControl"></param>
        /// <param name="spellName">Spell name to check</param>
        /// <param name="valueIfDisabled">Default selected item if the setting is disabled</param>
        /// <returns>TRUE is the spell is know and the control is usable. FALSE if the spell is not known and the control is disabled.</returns>
        public bool SettingControlCheck(ComboBox uiControl,string spellName,string valueIfDisabled)
        {
            bool result = SpellsMan.Spell.IsKnown(spellName);

            if (result) return true;
            uiControl.Enabled = result;
            //uiControl.Items.Add("... Unknown spell setting disabled");
            uiControl.SelectedItem = valueIfDisabled;
            
            return false;
        }


        // Neat little function to use a Progress bar like a slider control by simply clicking on it or dragging
        // REALLY NEAT! Took 3 seconds to come up with the idea and 30 minutes to figure out how to get it to work
        public int MouPosValue(double mousePosition, double progressBarWidth)
        {
            if (mousePosition < 0) mousePosition = 0;
            if (mousePosition > progressBarWidth) mousePosition = progressBarWidth;

            double ratio = mousePosition / progressBarWidth;
            double value = ratio * 100;

            if (value > 100) value = 100;
            if (value < 0) value = 0;

            return (int)Math.Ceiling(value);
        }

        private void DrinkBar_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                EatBar.Value = MouPosValue(e.Location.X, EatBar.Width);
                Settings.RestHealth = EatBar.Value;
            }
        }

        private void ManaPotionBar_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                HealthPotionBar.Value = MouPosValue(e.Location.X, EatBar.Width);
                Settings.HealthPotion = HealthPotionBar.Value;
            }
        }

        private void Debug_SelectedIndexChanged(object sender, EventArgs e)
        {
            Settings.Debug = Debug.SelectedItem.ToString();
        }

        private void RAFTarget_SelectedIndexChanged(object sender, EventArgs e)
        {
            Settings.RAFTarget = RAFTarget.SelectedItem.ToString();
        }

        private void Rend_SelectedIndexChanged(object sender, EventArgs e)
        {
            Settings.Rend = Rend.SelectedItem.ToString();
        }

        private void ThunderClap_SelectedIndexChanged(object sender, EventArgs e)
        {
            Settings.ThunderClap = ThunderClap.SelectedItem.ToString();
        }

        private void DeathWish_SelectedIndexChanged(object sender, EventArgs e)
        {
            Settings.DeathWish = DeathWish.SelectedItem.ToString();
        }

        private void BerserkerRage_SelectedIndexChanged(object sender, EventArgs e)
        {
            Settings.BerserkerRage = BerserkerRage.SelectedItem.ToString();
        }

        private void Shout_SelectedIndexChanged(object sender, EventArgs e)
        {
            Settings.Shout = Shout.SelectedItem.ToString();
        }

        private void Execute_SelectedIndexChanged(object sender, EventArgs e)
        {
            Settings.Execute = Execute.SelectedItem.ToString();
        }

        private void DeadlyCalm_SelectedIndexChanged(object sender, EventArgs e)
        {
            Settings.DeadlyCalm = DeadlyCalm.SelectedItem.ToString();
        }

        private void Cleave_SelectedIndexChanged(object sender, EventArgs e)
        {
            Settings.Cleave = Cleave.SelectedItem.ToString();
        }

        private void Whirlwind_SelectedIndexChanged(object sender, EventArgs e)
        {
            Settings.Whirlwind = Whirlwind.SelectedItem.ToString();
        }


    }
}
