﻿namespace Hera.UI
{
    partial class UIForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.BottomPanel = new System.Windows.Forms.Panel();
            this.label20 = new System.Windows.Forms.Label();
            this.lblCCName = new System.Windows.Forms.Label();
            this.SaveSettings = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.BerserkerRage = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.DeathWish = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.Rend = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.Shout = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.ThunderClap = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.HealthPotionBar = new System.Windows.Forms.ProgressBar();
            this.EatBar = new System.Windows.Forms.ProgressBar();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.RAFTarget = new System.Windows.Forms.ComboBox();
            this.label24 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.Debug = new System.Windows.Forms.ComboBox();
            this.label27 = new System.Windows.Forms.Label();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.label5 = new System.Windows.Forms.Label();
            this.Execute = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.Whirlwind = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.DeadlyCalm = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.Cleave = new System.Windows.Forms.ComboBox();
            this.BottomPanel.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.SuspendLayout();
            // 
            // BottomPanel
            // 
            this.BottomPanel.BackColor = System.Drawing.Color.White;
            this.BottomPanel.Controls.Add(this.label20);
            this.BottomPanel.Controls.Add(this.lblCCName);
            this.BottomPanel.Controls.Add(this.SaveSettings);
            this.BottomPanel.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.BottomPanel.Location = new System.Drawing.Point(0, 526);
            this.BottomPanel.Name = "BottomPanel";
            this.BottomPanel.Size = new System.Drawing.Size(639, 47);
            this.BottomPanel.TabIndex = 0;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.DimGray;
            this.label20.Location = new System.Drawing.Point(5, 32);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(61, 13);
            this.label20.TabIndex = 54;
            this.label20.Text = "by Fpsware";
            // 
            // lblCCName
            // 
            this.lblCCName.AutoSize = true;
            this.lblCCName.BackColor = System.Drawing.Color.Transparent;
            this.lblCCName.Font = new System.Drawing.Font("Impact", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCCName.ForeColor = System.Drawing.Color.Gray;
            this.lblCCName.Location = new System.Drawing.Point(1, -1);
            this.lblCCName.Name = "lblCCName";
            this.lblCCName.Size = new System.Drawing.Size(81, 39);
            this.lblCCName.TabIndex = 53;
            this.lblCCName.Text = "HERA";
            // 
            // SaveSettings
            // 
            this.SaveSettings.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.SaveSettings.Location = new System.Drawing.Point(507, 12);
            this.SaveSettings.Name = "SaveSettings";
            this.SaveSettings.Size = new System.Drawing.Size(120, 23);
            this.SaveSettings.TabIndex = 0;
            this.SaveSettings.Text = "Save && Close";
            this.SaveSettings.UseVisualStyleBackColor = true;
            this.SaveSettings.Click += new System.EventHandler(this.SaveSettings_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(639, 526);
            this.tabControl1.TabIndex = 1;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Controls.Add(this.groupBox4);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(631, 500);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Common";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.Cleave);
            this.groupBox1.Controls.Add(this.BerserkerRage);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.DeadlyCalm);
            this.groupBox1.Controls.Add(this.DeathWish);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.Rend);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.Whirlwind);
            this.groupBox1.Controls.Add(this.Shout);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.Execute);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.ThunderClap);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Location = new System.Drawing.Point(8, 121);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(305, 373);
            this.groupBox1.TabIndex = 38;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Combat";
            // 
            // BerserkerRage
            // 
            this.BerserkerRage.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.BerserkerRage.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.BerserkerRage.FormattingEnabled = true;
            this.BerserkerRage.Items.AddRange(new object[] {
            "... always",
            "... never",
            "... only on adds"});
            this.BerserkerRage.Location = new System.Drawing.Point(119, 100);
            this.BerserkerRage.Name = "BerserkerRage";
            this.BerserkerRage.Size = new System.Drawing.Size(180, 21);
            this.BerserkerRage.Sorted = true;
            this.BerserkerRage.TabIndex = 69;
            this.BerserkerRage.SelectedIndexChanged += new System.EventHandler(this.BerserkerRage_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(32, 103);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(81, 13);
            this.label1.TabIndex = 70;
            this.label1.Text = "Berserker Rage";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // DeathWish
            // 
            this.DeathWish.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.DeathWish.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.DeathWish.FormattingEnabled = true;
            this.DeathWish.Items.AddRange(new object[] {
            "... always",
            "... never",
            "... only on adds"});
            this.DeathWish.Location = new System.Drawing.Point(119, 73);
            this.DeathWish.Name = "DeathWish";
            this.DeathWish.Size = new System.Drawing.Size(180, 21);
            this.DeathWish.Sorted = true;
            this.DeathWish.TabIndex = 67;
            this.DeathWish.SelectedIndexChanged += new System.EventHandler(this.DeathWish_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(50, 76);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 13);
            this.label2.TabIndex = 68;
            this.label2.Text = "Death Wish";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Rend
            // 
            this.Rend.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Rend.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Rend.FormattingEnabled = true;
            this.Rend.Items.AddRange(new object[] {
            "... always",
            "... never"});
            this.Rend.Location = new System.Drawing.Point(119, 19);
            this.Rend.Name = "Rend";
            this.Rend.Size = new System.Drawing.Size(180, 21);
            this.Rend.Sorted = true;
            this.Rend.TabIndex = 67;
            this.Rend.SelectedIndexChanged += new System.EventHandler(this.Rend_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(80, 22);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(33, 13);
            this.label3.TabIndex = 68;
            this.label3.Text = "Rend";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Shout
            // 
            this.Shout.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Shout.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Shout.FormattingEnabled = true;
            this.Shout.Items.AddRange(new object[] {
            "Battle Shout",
            "Commanding Shout"});
            this.Shout.Location = new System.Drawing.Point(119, 127);
            this.Shout.Name = "Shout";
            this.Shout.Size = new System.Drawing.Size(180, 21);
            this.Shout.Sorted = true;
            this.Shout.TabIndex = 67;
            this.Shout.SelectedIndexChanged += new System.EventHandler(this.Shout_SelectedIndexChanged);
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(78, 130);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(35, 13);
            this.label4.TabIndex = 68;
            this.label4.Text = "Shout";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // ThunderClap
            // 
            this.ThunderClap.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.ThunderClap.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ThunderClap.FormattingEnabled = true;
            this.ThunderClap.Items.AddRange(new object[] {
            "... always",
            "... never",
            "... only on adds"});
            this.ThunderClap.Location = new System.Drawing.Point(119, 46);
            this.ThunderClap.Name = "ThunderClap";
            this.ThunderClap.Size = new System.Drawing.Size(180, 21);
            this.ThunderClap.Sorted = true;
            this.ThunderClap.TabIndex = 67;
            this.ThunderClap.SelectedIndexChanged += new System.EventHandler(this.ThunderClap_SelectedIndexChanged);
            // 
            // label6
            // 
            this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(42, 49);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(71, 13);
            this.label6.TabIndex = 68;
            this.label6.Text = "Thunder Clap";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.HealthPotionBar);
            this.groupBox4.Controls.Add(this.EatBar);
            this.groupBox4.Controls.Add(this.label19);
            this.groupBox4.Controls.Add(this.label18);
            this.groupBox4.Location = new System.Drawing.Point(8, 6);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(304, 109);
            this.groupBox4.TabIndex = 35;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Rest";
            // 
            // HealthPotionBar
            // 
            this.HealthPotionBar.Cursor = System.Windows.Forms.Cursors.Default;
            this.HealthPotionBar.Location = new System.Drawing.Point(119, 46);
            this.HealthPotionBar.Name = "HealthPotionBar";
            this.HealthPotionBar.Size = new System.Drawing.Size(180, 21);
            this.HealthPotionBar.TabIndex = 71;
            this.toolTip1.SetToolTip(this.HealthPotionBar, "Use a mana potion when your mana is below (%)");
            this.HealthPotionBar.Value = 10;
            this.HealthPotionBar.MouseClick += new System.Windows.Forms.MouseEventHandler(this.ManaPotionBar_MouseClick);
            this.HealthPotionBar.MouseMove += new System.Windows.Forms.MouseEventHandler(this.ManaPotionBar_MouseClick);
            // 
            // EatBar
            // 
            this.EatBar.Cursor = System.Windows.Forms.Cursors.Default;
            this.EatBar.Location = new System.Drawing.Point(119, 19);
            this.EatBar.Name = "EatBar";
            this.EatBar.Size = new System.Drawing.Size(180, 21);
            this.EatBar.TabIndex = 71;
            this.toolTip1.SetToolTip(this.EatBar, "Drink when your mana is below (%)");
            this.EatBar.Value = 25;
            this.EatBar.MouseClick += new System.Windows.Forms.MouseEventHandler(this.DrinkBar_MouseClick);
            this.EatBar.MouseMove += new System.Windows.Forms.MouseEventHandler(this.DrinkBar_MouseClick);
            // 
            // label19
            // 
            this.label19.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(25, 50);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(88, 13);
            this.label19.TabIndex = 68;
            this.label19.Text = "Health Potion (%)";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label18
            // 
            this.label18.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(33, 23);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(80, 13);
            this.label18.TabIndex = 68;
            this.label18.Text = "Rest Health (%)";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.groupBox7);
            this.tabPage2.Controls.Add(this.groupBox5);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(631, 500);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Advanced";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.RAFTarget);
            this.groupBox7.Controls.Add(this.label24);
            this.groupBox7.Location = new System.Drawing.Point(8, 90);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(305, 84);
            this.groupBox7.TabIndex = 35;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "RAF Party";
            // 
            // RAFTarget
            // 
            this.RAFTarget.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.RAFTarget.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.RAFTarget.FormattingEnabled = true;
            this.RAFTarget.Items.AddRange(new object[] {
            "... always",
            "... never"});
            this.RAFTarget.Location = new System.Drawing.Point(119, 19);
            this.RAFTarget.Name = "RAFTarget";
            this.RAFTarget.Size = new System.Drawing.Size(180, 21);
            this.RAFTarget.Sorted = true;
            this.RAFTarget.TabIndex = 67;
            this.RAFTarget.SelectedIndexChanged += new System.EventHandler(this.RAFTarget_SelectedIndexChanged);
            // 
            // label24
            // 
            this.label24.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(20, 22);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(93, 13);
            this.label24.TabIndex = 68;
            this.label24.Text = "Use leaders target";
            this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // groupBox5
            // 
            this.groupBox5.BackColor = System.Drawing.Color.Transparent;
            this.groupBox5.Controls.Add(this.Debug);
            this.groupBox5.Controls.Add(this.label27);
            this.groupBox5.Location = new System.Drawing.Point(8, 6);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(305, 78);
            this.groupBox5.TabIndex = 35;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Debugging";
            // 
            // Debug
            // 
            this.Debug.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Debug.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Debug.FormattingEnabled = true;
            this.Debug.Items.AddRange(new object[] {
            "... do not show debug",
            "... show debug level 1",
            "... show debug level 2",
            "... show debug level 3"});
            this.Debug.Location = new System.Drawing.Point(119, 19);
            this.Debug.Name = "Debug";
            this.Debug.Size = new System.Drawing.Size(180, 21);
            this.Debug.Sorted = true;
            this.Debug.TabIndex = 67;
            this.Debug.SelectedIndexChanged += new System.EventHandler(this.Debug_SelectedIndexChanged);
            // 
            // label27
            // 
            this.label27.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(68, 22);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(45, 13);
            this.label27.TabIndex = 68;
            this.label27.Text = "Logging";
            this.label27.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // toolTip1
            // 
            this.toolTip1.AutomaticDelay = 400;
            this.toolTip1.AutoPopDelay = 6000;
            this.toolTip1.InitialDelay = 400;
            this.toolTip1.IsBalloon = true;
            this.toolTip1.ReshowDelay = 80;
            this.toolTip1.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            this.toolTip1.ToolTipTitle = "Karis Settings";
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(67, 157);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(46, 13);
            this.label5.TabIndex = 68;
            this.label5.Text = "Execute";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Execute
            // 
            this.Execute.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Execute.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Execute.FormattingEnabled = true;
            this.Execute.Items.AddRange(new object[] {
            "... always",
            "... never"});
            this.Execute.Location = new System.Drawing.Point(119, 154);
            this.Execute.Name = "Execute";
            this.Execute.Size = new System.Drawing.Size(180, 21);
            this.Execute.Sorted = true;
            this.Execute.TabIndex = 67;
            this.Execute.SelectedIndexChanged += new System.EventHandler(this.Execute_SelectedIndexChanged);
            // 
            // label7
            // 
            this.label7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(60, 238);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(53, 13);
            this.label7.TabIndex = 68;
            this.label7.Text = "Whirlwind";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Whirlwind
            // 
            this.Whirlwind.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Whirlwind.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Whirlwind.FormattingEnabled = true;
            this.Whirlwind.Items.AddRange(new object[] {
            "... always",
            "... never",
            "... only on adds"});
            this.Whirlwind.Location = new System.Drawing.Point(119, 235);
            this.Whirlwind.Name = "Whirlwind";
            this.Whirlwind.Size = new System.Drawing.Size(180, 21);
            this.Whirlwind.Sorted = true;
            this.Whirlwind.TabIndex = 67;
            this.Whirlwind.SelectedIndexChanged += new System.EventHandler(this.Whirlwind_SelectedIndexChanged);
            // 
            // label8
            // 
            this.label8.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(47, 184);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(66, 13);
            this.label8.TabIndex = 68;
            this.label8.Text = "Deadly Calm";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // DeadlyCalm
            // 
            this.DeadlyCalm.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.DeadlyCalm.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.DeadlyCalm.FormattingEnabled = true;
            this.DeadlyCalm.Items.AddRange(new object[] {
            "... always",
            "... never",
            "... only on adds"});
            this.DeadlyCalm.Location = new System.Drawing.Point(119, 181);
            this.DeadlyCalm.Name = "DeadlyCalm";
            this.DeadlyCalm.Size = new System.Drawing.Size(180, 21);
            this.DeadlyCalm.Sorted = true;
            this.DeadlyCalm.TabIndex = 67;
            this.DeadlyCalm.SelectedIndexChanged += new System.EventHandler(this.DeadlyCalm_SelectedIndexChanged);
            // 
            // label9
            // 
            this.label9.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(73, 211);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(40, 13);
            this.label9.TabIndex = 70;
            this.label9.Text = "Cleave";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Cleave
            // 
            this.Cleave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Cleave.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Cleave.FormattingEnabled = true;
            this.Cleave.Items.AddRange(new object[] {
            "... always",
            "... never",
            "... only on adds"});
            this.Cleave.Location = new System.Drawing.Point(119, 208);
            this.Cleave.Name = "Cleave";
            this.Cleave.Size = new System.Drawing.Size(180, 21);
            this.Cleave.Sorted = true;
            this.Cleave.TabIndex = 69;
            this.Cleave.SelectedIndexChanged += new System.EventHandler(this.Cleave_SelectedIndexChanged);
            // 
            // UIForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(639, 573);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.BottomPanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "UIForm";
            this.Text = "My CC UI";
            this.Load += new System.EventHandler(this.UIForm_Load);
            this.BottomPanel.ResumeLayout(false);
            this.BottomPanel.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel BottomPanel;
        private System.Windows.Forms.Button SaveSettings;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Label lblCCName;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.ProgressBar HealthPotionBar;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.ProgressBar EatBar;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.ComboBox Debug;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.ComboBox RAFTarget;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox BerserkerRage;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox DeathWish;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox Rend;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox Shout;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox ThunderClap;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox Cleave;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox DeadlyCalm;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox Whirlwind;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox Execute;
        private System.Windows.Forms.Label label5;
    }
}