﻿using System;
using System.Drawing;
using System.Threading;
using Styx.Helpers;
using Styx.Logic.Pathing;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;

namespace Hera.Helpers
{
    public static class Movement
    {
        private static LocalPlayer Me { get { return ObjectManager.Me; } }

        /// <summary>
        /// Stop moving. Like da!
        /// </summary>
        public static void StopMoving() { while (Me.IsMoving) { WoWMovement.MoveStop(); Thread.Sleep(50); } }

        /// <summary>
        /// Move to within X yards of the target
        /// </summary>
        /// <param name="distanceFromTarget">Distance to move to the target</param>
        public static void MoveTo(float distanceFromTarget)
        {
            // Let HB do the math and find a WoWPoint X yards away from the target
            WoWPoint moveToHere = WoWMathHelper.CalculatePointFrom(Me.Location, Me.CurrentTarget.Location, distanceFromTarget);

            // Use HB navigation to move to a WoWPoint. WoWPoint has been calculated in the above code
            Navigator.MoveTo(moveToHere);
        }

        /// <summary>
        /// TRUE if we need to perform a distance check
        /// </summary>
        public static bool NeedToCheck
        {
            get
            {
                // If distance is less than ClassHelper.MinimumDistance and the target is NOT running away and we are moving then we should stop moving
                if (Target.IsDistanceLessThan(ClassHelper.MinimumDistance) && !Target.IsFleeing && Me.IsMoving) WoWMovement.MoveStop();

                // TRUE if we are out of range. TRUE means we need to move closer
                bool result = Target.IsDistanceMoreThan(ClassHelper.MaximumDistance);

                return result;
            }
        }

        /// <summary>
        /// Move to melee distance if we need to
        /// </summary>
        public static void DistanceCheck()
        {
            // No target, nothing to do
            if (!Me.GotTarget) return;

            // If we're too close stop moving
            if (Target.IsDistanceLessThan(ClassHelper.MinimumDistance)) StopMoving();

            // If we're more than X yards away from the current target then move to X yards from the target
            DistanceCheck(ClassHelper.MaximumDistance, ClassHelper.MinimumDistance);
        }

        /// <summary>
        /// Move to range and stop moving if we are too close
        /// </summary>
        /// <param name="maxDistance">Maximum distance away from the target you want to be. This should be max spell range or melee range</param>
        /// <param name="moveToDistance">If your distance is greater than maxDistance you will move to this distance from the target</param>
        public static void DistanceCheck(double maxDistance, double moveToDistance)
        {
            // No target, nothing to do
            if (!Me.GotTarget) return;

            // If target (NPC) is running away move as close a possible to the target
            if (Me.GotTarget && Me.CurrentTarget.Fleeing)
            {
                Utils.Log("Runner!");
                moveToDistance = 0.5;
            }

            // We're too far from the target so move closer
            if (Me.CurrentTarget.Fleeing && Target.Distance > moveToDistance || Target.Distance > maxDistance)
            {
                Utils.Log(String.Format("Moving closer to {0}", Me.CurrentTarget.Name), Color.FromName("DarkGreen"));
                MoveTo((float) moveToDistance);
            }
          
            // We're too close to the target we need to stop moving
            if (Target.Distance <= moveToDistance)
            {
                Utils.Log("We too close, stop moving.", Color.FromName("DarkGreen"));
                WoWMovement.MoveStop();
                return;
            }

            // We don't need to do anything so just exit
            if (Target.Distance > moveToDistance || !Me.IsMoving || Me.CurrentTarget.Fleeing)
                return;

            

            // When all else fails just stop moving
            WoWMovement.MoveStop();

        }


    }
}
