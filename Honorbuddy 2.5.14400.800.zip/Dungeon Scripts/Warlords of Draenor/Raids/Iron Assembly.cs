﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Documents;
using System.Windows.Forms.VisualStyles;
using Bots.DungeonBuddy.Attributes;
using Bots.DungeonBuddy.Helpers;
using Buddy.Coroutines;
using Styx;
using Styx.Common.Helpers;
using Styx.CommonBot;
using Styx.CommonBot.Coroutines;
using Styx.Helpers;
using Styx.Pathing;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using Vector2 = Tripper.Tools.Math.Vector2;

// ReSharper disable CheckNamespace
namespace Bots.DungeonBuddy.Raids.WarlordsOfDraenor
// ReSharper restore CheckNamespace
{
	// ToDo: Finish scripting this
	//public class IronAssembly : BlackrockFoundry
	//{
	//	#region Overrides of Dungeon
	
	//	public override uint DungeonId
	//	{
	//		get { return 848; }
	//	}

	//	public override WoWPoint Entrance
	//	{
	//		get { return new WoWPoint(1491.402, 3071.209, 110.1424); }
	//	}

	//	public override WoWPoint ExitLocation
	//	{
	//		get { return new WoWPoint(1491.654, 2952.643, 35.23913); }
	//	}

	//	public override void RemoveTargetsFilter(List<WoWObject> units)
	//	{
	//		units.RemoveAll(
	//			ret =>
	//			{
	//				var unit = ret as WoWUnit;
	//				if (unit == null)
	//					return false;

	//				return false;
	//			});
	//	}

	//	public override void IncludeTargetsFilter(List<WoWObject> incomingunits, HashSet<WoWObject> outgoingunits)
	//	{
	//		foreach (var obj in incomingunits)
	//		{
	//			var unit = obj as WoWUnit;
	//			if (unit != null)
	//			{

	//			}
	//		}
	//	}

	//	public override void WeighTargetsFilter(List<Targeting.TargetPriority> units)
	//	{
	//		var isMelee = Me.IsMelee();
	//		var israngedDps = !isMelee && Me.IsDps();
	//		foreach (var priority in units)
	//		{
	//			var unit = priority.Object as WoWUnit;
	//			if (unit != null)
	//			{
	//				switch (unit.Entry)
	//				{
						
	//				}
	//			}
	//		}
	//	}

	//	#endregion

	//	#region Root

	//	#endregion

	//	#region Beastlord Darmac

	//	private const uint MobId_BeastlordDarmac = 76865;
	//	[EncounterHandler((int)MobId_BeastlordDarmac, "Beastlord Darmac")]
	//	public Func<WoWUnit, Task<bool>> BeastlordDarmacEncounter()
	//	{
	//		return async boss =>
	//		{
	//			return false;
	//		};
	//	}

	//	#endregion


	//	#region Operator Thogar

	//	private const uint MobId_OperatorThogar = 76906;
	//	[EncounterHandler((int)MobId_OperatorThogar, "Operator Thogar")]
	//	public Func<WoWUnit, Task<bool>> OperatorThogarEncounter()
	//	{
	//		return async boss =>
	//		{
	//			return false;
	//		};
	//	}

	//	#endregion

	//	#region Enforcer Sorka

	//	private const uint MobId_EnforcerSorka = 77231;
	//	[EncounterHandler((int)MobId_EnforcerSorka, "Enforcer Sorka")]
	//	public Func<WoWUnit, Task<bool>> EnforcerSorkaEncounter()
	//	{
	//		return async boss =>
	//		{
	//			return false;
	//		};
	//	}

	//	#endregion


	//	#region Admiral Gar'an

	//	private const uint MobId_AdmiralGaran = 77557;
	//	[EncounterHandler((int)MobId_AdmiralGaran, "Admiral Gar'an")]
	//	public Func<WoWUnit, Task<bool>> AdmiralGaranEncounter()
	//	{
	//		return async boss =>
	//		{
	//			return false;
	//		};
	//	}

	//	#endregion


	//	#region Marak the Blooded

	//	private const uint MobId_MaraktheBlooded = 77477;
	//	[EncounterHandler((int)MobId_MaraktheBlooded, "Marak the Blooded")]
	//	public Func<WoWUnit, Task<bool>> MaraktheBloodedEncounter()
	//	{
	//		return async boss =>
	//		{
	//			return false;
	//		};
	//	}

	//	#endregion

	//}
}