﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Bots.DungeonBuddy.Attributes;
using Bots.DungeonBuddy.Helpers;
using Buddy.Coroutines;
using Styx;
using Styx.CommonBot;
using Styx.Helpers;
using Styx.Pathing;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using Tripper.Tools.Math;

// ReSharper disable CheckNamespace

namespace Bots.DungeonBuddy.Raids.WarlordsOfDraenor
// ReSharper restore CheckNamespace
{
	public abstract class BlackrockFoundry : WoDLfr
	{
		protected const uint GameObjectIdLowerElevator = 231013;
		protected const uint GameObjectIdUpperElevator = 231014;

		private readonly WoWPoint _lowerElevatorBottomBoardLoc =
			WoWMathHelper.GetRandomPointInCircle(new WoWPoint(242.115, 3499.764, 141.3863), 2);

		private readonly WoWPoint _lowerElevatorBottomExitLoc =
			WoWMathHelper.GetRandomPointInCircle(new WoWPoint(254.3308, 3499.717, 140.8705), 1);

		private readonly float _lowerElevatorBottomZ = 139.6442f;

		private readonly WoWPoint _lowerElevatorTopBoardLoc =
			WoWMathHelper.GetRandomPointInCircle(new WoWPoint(252.8751, 3499.738, 306.7645), 2);

		// randomize points in order to avoid stacking of bots.
		private readonly WoWPoint _lowerElevatorTopExitLoc =
			WoWMathHelper.GetRandomPointInCircle(new WoWPoint(254.2236, 3488.808, 307.7599), 1);

		private readonly float _lowerElevatorTopZ = 305.5395f;

		private readonly WoWPoint _upperElevatorBottomBoardLoc =
			WoWMathHelper.GetRandomPointInCircle(new WoWPoint(242.115, 3499.764, 141.3863), 2);

		private readonly WoWPoint _upperElevatorBottomExitLoc =
			WoWMathHelper.GetRandomPointInCircle(new WoWPoint(254.3308, 3499.717, 140.8705), 1);

		private readonly float _upperElevatorBottomZ = 139.6442f;

		private readonly WoWPoint _upperElevatorTopBoardLoc =
			WoWMathHelper.GetRandomPointInCircle(new WoWPoint(252.8751, 3499.738, 306.7645), 2);

		private readonly WoWPoint _upperElevatorTopExitLoc =
			WoWMathHelper.GetRandomPointInCircle(new WoWPoint(254.2236, 3488.808, 307.7599), 1);

		private readonly float _upperElevatorTopZ = 305.5395f;
		private WoWPoint _elevatorBoardPoint;
		private WoWPoint _elevatorWaitPoint;

		private BoundingBox3 _lowerElevatorShaftBounds = new BoundingBox3(new Vector3(260.2494f, 3505.748f, 135),
			new Vector3(246.0173f, 3492.971f, 310));

		private BoundingBox3 _lowerSectionBounds = new BoundingBox3(new Vector3(549, 3850, 63),
			new Vector3(-40, 3337, 228));

		private BoundingBox3 _upperElevatorShaftBounds = new BoundingBox3(new Vector3(453.0705f, 3502.771f, 741.7635f),
			new Vector3(435.616f, 3485.722f, 306.5034f));

		private BoundingBox3 _upperSectionBoundBox = new BoundingBox3(new Vector3(865, 3665, 410),
			new Vector3(385, 3290, 1000));

		//public async Task<bool> ElevatorLogic(WoWPoint destination)
		//{
		//	var myloc = StyxWoW.Me.Location;

		//	var myFloorLevel = GetFloorLevel(myloc);
		//	var destinationFloorLevel = GetFloorLevel(destination);

		//	WoWPoint elevatorBoardLoc, elevatorExitLoc;
		//	float elevatorRestingZ;
		//	WoWGameObject elevator;

		//	var handleElevator =
		//		!GetElevatorMoveInfo(myloc, destination, out elevatorBoardLoc, out elevatorExitLoc, out elevatorRestingZ,
		//			out elevator);

		//	if (!handleElevator)
		//		return false;

		//	var elevatorIsResting = elevator != null && Math.Abs(elevator.Z - elevatorRestingZ) <= 0.5f;

		//	if (elevator != null && Me.Transport == elevator)
		//	{
		//		if (elevatorIsResting && myFloorLevel == destinationFloorLevel)
		//		{
		//			Logger.Write("[Elevator Manager] Exiting Elevator");
		//			Navigator.PlayerMover.MoveTowards(elevatorExitLoc);
		//		}
		//	}
		//	else
		//	{
		//		// move to the elevator exit location
		//		if ((elevator == null || myloc.DistanceSqr(elevatorBoardLoc) > 20*20
		//		     || (!elevatorIsResting && myloc.DistanceSqr(elevatorExitLoc) > 4*4)
		//		     && !Navigator.AtLocation(elevatorBoardLoc)))
		//		{
		//			Logger.Write("[Elevator Manager] Moving To Elevator");
		//			var moveResult = Navigator.MoveTo(elevatorExitLoc);
		//			return moveResult != MoveResult.Failed && moveResult != MoveResult.PathGenerationFailed;
		//		}

		//		// Get onboard of the elevator.
		//		if (elevatorIsResting && myloc.DistanceSqr(elevatorBoardLoc) > 1.5*1.5)
		//		{
		//			Logger.Write("[Elevator Manager] Boarding Elevator");
		//			// avoid getting stuck on lever
		//			Navigator.PlayerMover.MoveTowards(elevatorBoardLoc);
		//		}
		//		else if (elevatorIsResting && myloc.DistanceSqr(elevatorBoardLoc) <= 1.5*1.5 && !Me.TransportGuid.IsValid)
		//		{
		//			Logger.Write("[Elevator Manager] Jumping");
		//			try
		//			{
		//				WoWMovement.Move(WoWMovement.MovementDirection.JumpAscend);
		//				await Coroutine.Sleep(110);
		//			}
		//			finally
		//			{
		//				WoWMovement.MoveStop(WoWMovement.MovementDirection.JumpAscend);
		//			}
		//		}
		//	}
		//	return true;
		//}

		//private bool GetElevatorMoveInfo(WoWPoint myLoc, WoWPoint destination,
		//	out WoWPoint elevatorBoardLoc, out WoWPoint elevatorExitLoc, out float elevatorRestingZ,
		//	out WoWGameObject elevator)
		//{
		//	var myFloorLevel = GetFloorLevel(myLoc);
		//	var destinationFloorLevel = GetFloorLevel(destination);

		//	if (myFloorLevel == destinationFloorLevel)
		//	{
		//		if (_upperElevatorShaftBounds.Contains(destination))
		//			destinationFloorLevel = myFloorLevel == FloorLevel.Upper ? FloorLevel.Main : FloorLevel.Upper;
		//		else if (_lowerElevatorShaftBounds.Contains(destination))
		//			destinationFloorLevel = myFloorLevel == FloorLevel.Lower ? FloorLevel.Main : FloorLevel.Lower;
		//		else
		//		{
		//			// When player and destination floor levels are the same, we only want to handle elevator logic if destination is inside 
		//			// an elevator shaft or player is riding on an elevator.
		//			var transport = Me.Transport;
		//			if (transport == null ||
		//			    (transport.Entry != GameObjectIdLowerElevator && transport.Entry != GameObjectIdUpperElevator))
		//			{
		//				elevatorBoardLoc = elevatorExitLoc = WoWPoint.Zero;
		//				elevatorRestingZ = 0;
		//				elevator = null;
		//				return false;
		//			}

		//			elevator = (WoWGameObject) transport;
		//			if (elevator.Entry == GameObjectIdLowerElevator)
		//			{
		//				if (Math.Abs(myLoc.Z - _lowerElevatorTopZ) > Math.Abs(myLoc.Z - _lowerElevatorBottomZ))
		//				{
		//					elevatorExitLoc = _lowerElevatorBottomExitLoc;
		//					elevatorRestingZ = _lowerElevatorBottomZ;
		//				}
		//				else
		//				{
		//					elevatorExitLoc = _lowerElevatorTopExitLoc;
		//					elevatorRestingZ = _lowerElevatorTopZ;
		//				}
		//			}
		//			else
		//			{
		//				if (Math.Abs(myLoc.Z - _upperElevatorTopZ) > Math.Abs(myLoc.Z - _upperElevatorBottomZ))
		//				{
		//					elevatorExitLoc = _upperElevatorBottomExitLoc;
		//					elevatorRestingZ = _upperElevatorBottomZ;
		//				}
		//				else
		//				{
		//					elevatorExitLoc = _upperElevatorTopExitLoc;
		//					elevatorRestingZ = _upperElevatorTopZ;
		//				}
		//			}
		//			// We don't care about elevatorBoardLoc while riding on the elevator. 
		//			elevatorBoardLoc = WoWPoint.Zero;
		//			return true;
		//		}
		//	}

		//	// MyFloorLevel takes precedents over destinationFloorLevel because, for example, if player 
		//	// is at lower level and moving to upper level then the lower elevator needs to be used first.
		//	var level = myFloorLevel != FloorLevel.Main ? myFloorLevel : destinationFloorLevel;
		//	var elevatorId = level == FloorLevel.Lower ? GameObjectIdLowerElevator : GameObjectIdUpperElevator;

		//	elevator = ObjectManager.GetObjectsOfType<WoWGameObject>().FirstOrDefault(g => g.Entry == elevatorId);

		//	switch (myFloorLevel)
		//	{
		//		case FloorLevel.Main:
		//			if (destinationFloorLevel == FloorLevel.Lower)
		//			{
		//				elevatorBoardLoc = _lowerElevatorTopBoardLoc;
		//				elevatorExitLoc = _lowerElevatorBottomExitLoc;
		//				elevatorRestingZ = _lowerElevatorTopZ;
		//			}
		//			else
		//			{
		//				elevatorBoardLoc = _upperElevatorBottomBoardLoc;
		//				elevatorExitLoc = _upperElevatorTopExitLoc;
		//				elevatorRestingZ = _upperElevatorBottomZ;
		//			}
		//			break;
		//		case FloorLevel.Lower:
		//			elevatorBoardLoc = _lowerElevatorBottomBoardLoc;
		//			elevatorExitLoc = _lowerElevatorTopExitLoc;
		//			elevatorRestingZ = _lowerElevatorBottomZ;
		//			break;
		//		case FloorLevel.Upper:
		//			elevatorBoardLoc = _upperElevatorTopBoardLoc;
		//			elevatorExitLoc = _upperElevatorBottomExitLoc;
		//			elevatorRestingZ = _upperElevatorTopZ;
		//			break;
		//		default:
		//			throw new ArgumentException(string.Format("Unknown floor level: {0}", myFloorLevel));
		//	}
		//	return true;
		//}

		//private FloorLevel GetFloorLevel(WoWPoint loc)
		//{
		//	if (_lowerSectionBounds.Contains(loc))
		//		return FloorLevel.Lower;

		//	if (_upperSectionBoundBox.Contains(loc))
		//		return FloorLevel.Upper;
		//	return FloorLevel.Main;
		//}

		//private enum FloorLevel
		//{
		//	Main,
		//	Lower,
		//	Upper
		//}

		#region Root

		private const uint MobId_SpinningBlade = 88008;
		private const uint AreaTriggerId_AcidbackPuddle = 6689;

		[EncounterHandler(0, "Blackrock Foundry Root Handler")]
		public Func<WoWUnit, Task<bool>> BlackrockFoundryRootHandler()
		{
			AddAvoidObject(5, MobId_SpinningBlade);
			AddAvoidObject(3, o => o.Entry == AreaTriggerId_AcidbackPuddle, ignoreIfBlocking: true);

			return async boss => false;
		}

		#endregion

	}

	public class Slagworks : BlackrockFoundry
	{
		#region Overrides of Dungeon

		public override uint DungeonId
		{
			get { return 847; }
		}

		public override WoWPoint Entrance
		{
			get { return new WoWPoint(1491.402, 3071.209, 110.1424); }
		}

		public override WoWPoint ExitLocation
		{
			get { return new WoWPoint(1491.654, 2952.643, 35.23913); }
		}

		public override void RemoveTargetsFilter(List<WoWObject> units)
		{
			var isMelee = StyxWoW.Me.IsMelee();
			units.RemoveAll(
				ret =>
				{
					var unit = ret as WoWUnit;
					if (unit == null)
						return false;

					if (unit.Entry == MobId_Oregorger && isMelee && unit.HasAura("Rolling Fury") )
						return true;

					return false;
				});
		}

		public override void IncludeTargetsFilter(List<WoWObject> incomingunits, HashSet<WoWObject> outgoingunits)
		{
			foreach (var obj in incomingunits)
			{
				var unit = obj as WoWUnit;
				if (unit != null)
				{
					if (unit.Entry == MobId_OreCrate && unit.HasAura("Crate Glow") && unit.Attackable)
						outgoingunits.Add(unit);
				}
			}
		}

		public override void WeighTargetsFilter(List<Targeting.TargetPriority> units)
		{
			var isMelee = Me.IsMelee();
			var israngedDps = !isMelee && Me.IsDps();
			foreach (var priority in units)
			{
				var unit = priority.Object as WoWUnit;
				if (unit != null)
				{
					switch (unit.Entry)
					{
						case MobId_OreCrate:
							priority.Score += 5500;
							break;

						case MobId_Oregorger:
							if (unit.HasAura("Rolling Fury"))
								priority.Score -= 5000;
							break;
					}
				}
			}
		}

		#endregion

		#region Root

		#endregion

		#region Gruul

		private const uint MobId_Gruul = 76877;
		private const uint MobId_CaveIn = 86596;

		private const int SpellId_InfernoSlice = 155080;
		private const int SpellId_OverheadSmash = 155301;

		[EncounterHandler((int) MobId_Gruul, "Gruul")]
		public Func<WoWUnit, Task<bool>> GruulEncounter()
		{
			const float overheadSmashLineWidth = 10;
			WoWUnit boss = null;

			// Don't stand in front of Gruul because of frontal cone attack, Inferno Slice. 
			AddAvoidObject(25, o => o.Entry == MobId_Gruul && o.ToUnit().Combat, o => o.Location.RayCast(o.Rotation, 20));

			var hasPetrify = new PerFrameCachedValue<bool>(() => Me.HasAura("Petrify"));

			// Petrify snares all nearby group members within 8yds, turning them to stone.
			// Run away from group if has the debuf and move from group members that have it
			AddAvoidObject(8, o =>
			{
				var player = o as WoWPlayer;
				return player != null && !player.IsMe && (player.HasAura("Petrify") || hasPetrify);
			});

			// Overhead Smash does damage in a line.
			AddAvoidLine(ctx => ScriptHelpers.IsViable(boss) && boss.CastingSpellId == SpellId_OverheadSmash,
				() => overheadSmashLineWidth,
				() => boss.Location.RayCast(boss.Rotation, 10),
				() => boss.Location.RayCast(boss.Rotation, 80));

			AddAvoidObject(8, o => o.Entry == MobId_CaveIn && o.ToUnit().HasAura("Cave In"));

			return async npc =>
			{
				boss = npc;
				return false;
			};
		}

		#endregion

		#region Oregorger

		private const int MissileSpellId_ExplosiveShard = 156390;

		private const uint MobId_Oregorger = 77182;

		private const uint AreaTriggerId_RetchedBlackrock = 6349;
		private const uint MobId_OreCrate = 77252;
		private const int SpellId_BlackrockBarrage = 173461;

		[EncounterHandler((int) MobId_Oregorger, "Oregorger")]
		public Func<WoWUnit, Task<bool>> OregorgerEncounter()
		{
			const float rollLineWidth = 12;

			WoWUnit boss = null;
			// Explosive Shade stuns and does damage on impact.
			AddAvoidLocation(ctx => true, 7, o => ((WoWMissile) o).ImpactPosition,
				() => WoWMissile.InFlightMissiles.Where(m => m.SpellId == MissileSpellId_ExplosiveShard));

			AddAvoidObject(7, o => o.Entry == AreaTriggerId_RetchedBlackrock,ignoreIfBlocking: true);

			// Overhead Smash does damage in a line.
			AddAvoidLine(ctx => ScriptHelpers.IsViable(boss) && boss.HasAura("Rolling Fury"),
				() => rollLineWidth,
				() => boss.Location,
				() => boss.Location.RayCast(boss.Rotation, 60));


			return async npc => { return await ScriptHelpers.InterruptCast(npc, SpellId_BlackrockBarrage); };
		}

		#endregion

		#region The Blast Furnace

		private const uint AreaTriggerId_SlagPool = 6269;
		private const uint MobId_HeatRegulator = 76808;
		private const uint AreaTriggerId_Melt = 6221;
		private const uint MobId_ForemanFeldspar = 76809;

		[EncounterHandler((int) MobId_ForemanFeldspar, "ForemanFeldspar")]
		public Func<WoWUnit, Task<bool>> ForemanFeldsparEncounter()
		{
			AddAvoidObject(5, AreaTriggerId_Melt);
			AddAvoidObject(23, AreaTriggerId_SlagPool);


			var hasVolatileFire = new PerFrameCachedValue<bool>(() => Me.HasAura("Volatile Fire"));
			AddAvoidObject(8, o =>
			{
				var player = o as WoWPlayer;
				return player != null && !player.IsMe && (player.HasAura("Volatile Fire") || hasVolatileFire);
			});

			return async boss => { return false; };
		}

		private const uint MobId_HeartoftheMountain = 76806;

		[EncounterHandler((int) MobId_HeartoftheMountain, "Heart of the Mountain")]
		public Func<WoWUnit, Task<bool>> HeartoftheMountainEncounter()
		{
			return async boss => { return false; };
		}

		#endregion
	}
}