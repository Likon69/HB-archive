﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Documents;
using System.Windows.Forms.VisualStyles;
using Bots.DungeonBuddy.Attributes;
using Bots.DungeonBuddy.Helpers;
using Buddy.Coroutines;
using Styx;
using Styx.Common.Helpers;
using Styx.CommonBot;
using Styx.CommonBot.Coroutines;
using Styx.Helpers;
using Styx.Pathing;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using Vector2 = Tripper.Tools.Math.Vector2;

// ReSharper disable CheckNamespace
namespace Bots.DungeonBuddy.Raids.WarlordsOfDraenor
// ReSharper restore CheckNamespace
{
	// ToDo: Finish scripting this
	//public class BlackhandsCrucible : BlackrockFoundry
	//{
	//	#region Overrides of Dungeon
	
	//	public override uint DungeonId
	//	{
	//		get { return 823; }
	//	}

	//	public override WoWPoint Entrance
	//	{
	//		get { return new WoWPoint(1491.402, 3071.209, 110.1424); }
	//	}

	//	public override WoWPoint ExitLocation
	//	{
	//		get { return new WoWPoint(1491.654, 2952.643, 35.23913); }
	//	}

	//	public override void RemoveTargetsFilter(List<WoWObject> units)
	//	{
	//		units.RemoveAll(
	//			ret =>
	//			{
	//				var unit = ret as WoWUnit;
	//				if (unit == null)
	//					return false;

	//				return false;
	//			});
	//	}

	//	public override void IncludeTargetsFilter(List<WoWObject> incomingunits, HashSet<WoWObject> outgoingunits)
	//	{
	//		foreach (var obj in incomingunits)
	//		{
	//			var unit = obj as WoWUnit;
	//			if (unit != null)
	//			{

	//			}
	//		}
	//	}

	//	public override void WeighTargetsFilter(List<Targeting.TargetPriority> units)
	//	{
	//		var isMelee = Me.IsMelee();
	//		var israngedDps = !isMelee && Me.IsDps();
	//		foreach (var priority in units)
	//		{
	//			var unit = priority.Object as WoWUnit;
	//			if (unit != null)
	//			{
	//				switch (unit.Entry)
	//				{
						
	//				}
	//			}
	//		}
	//	}

	//	#endregion

	//	#region Root

	//	#endregion


	//	#region Blackhand

	//	private const uint MobId_Blackhand = 77325;
	//	[EncounterHandler((int)MobId_Blackhand, "Blackhand")]
	//	public Func<WoWUnit, Task<bool>> BlackhandEncounter()
	//	{
	//		return async boss =>
	//		{
	//			return false;
	//		};
	//	}
	//	#endregion
	//}
}