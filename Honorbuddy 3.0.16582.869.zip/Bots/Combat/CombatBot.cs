﻿using System.Collections.Generic;
using CommonBehaviors.Actions;
using Levelbot;
using Styx.CommonBot;
using Styx.CommonBot.Routines;
using Styx.Helpers;
using Styx.WoWInternals.WoWObjects;
using Styx.TreeSharp;

namespace Styx.Bot.CustomBots
{
    public class CombatBot : BotBase
    {
        #region Overrides of BotBase

        public override bool RequiresProfile => false;

        public override string Name => "Combat Bot";

        private Composite _root;

        private readonly HandleCombatCoroutineTask _handleCombatCoroutineTask = new HandleCombatCoroutineTask();
        public override Composite Root
        {
            get
            {
                return _root ?? (_root = new ActionRunCoroutine(ctxx => _handleCombatCoroutineTask));
            }
        }

        public override void Initialize()
        {
            BotEvents.Player.OnMapChanged += Player_OnMapChanged;
        }

        private void Player_OnMapChanged(BotEvents.Player.MapChangedEventArgs args)
        {
            _root = null;
        }
        
        public override PulseFlags PulseFlags => PulseFlags.All & ~(PulseFlags.Looting | PulseFlags.CharacterManager);

        private bool _oldLogoutForInactivity;
        public override void Start()
        {
            Targeting.Instance.IncludeTargetsFilter += IncludeTargetsFilter;
            _oldLogoutForInactivity = GlobalSettings.Instance.LogoutForInactivity;
            GlobalSettings.Instance.LogoutForInactivity = false;
            RoutineManager.SetCapabilityState(CapabilityFlags.Movement, CapabilityState.Disallowed, "Combat bot starting");
            RoutineManager.SetCapabilityState(CapabilityFlags.MoveBehind, CapabilityState.Disallowed, "Combat bot starting");
            RoutineManager.SetCapabilityState(CapabilityFlags.Kiting, CapabilityState.Disallowed, "Combat bot starting");
            RoutineManager.SetCapabilityState(CapabilityFlags.MultiMobPull, CapabilityState.Disallowed, "Combat bot starting");
        }

        public override void Stop()
        {
            Targeting.Instance.IncludeTargetsFilter -= IncludeTargetsFilter;
            GlobalSettings.Instance.LogoutForInactivity = _oldLogoutForInactivity;
        }

        #endregion

        #region Targeting Filter

        private static void IncludeTargetsFilter(List<WoWObject> incomingUnits, HashSet<WoWObject> outgoingUnits)
        {
            if (StyxWoW.Me.GotTarget && StyxWoW.Me.CurrentTarget.Attackable)
            {
                outgoingUnits.Add(StyxWoW.Me.CurrentTarget);
            }
        }

        #endregion
    }
}
