﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Numerics;
using System.Threading.Tasks;
using System.Windows.Markup;
using Bots.DungeonBuddy.Attributes;
using Bots.DungeonBuddy.Enums;
using Bots.DungeonBuddy.Helpers;
using Buddy.Coroutines;
using Styx;
using Styx.Common;
using Styx.Common.Helpers;
using Styx.CommonBot;
using Styx.CommonBot.Coroutines;
using Styx.CommonBot.POI;
using Styx.CommonBot.Routines;
using Styx.Helpers;
using Styx.Pathing;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using Styx.WoWInternals.WoWObjects.AreaTriggerShapes;

// ReSharper disable CheckNamespace

namespace Bots.DungeonBuddy.DungeonScripts.Legion
// ReSharper restore CheckNamespace
{
    #region Normal Difficulty

    public class HallsOfValor : Dungeon
    {
        #region Overrides of Dungeon

        public override uint DungeonId => 1193;

        public override Vector3 Entrance
        {
            get
            {
                throw new NotImplementedException();
            }
        }

        public override Vector3 ExitLocation => new Vector3(3817.4f, 529.1859f, 605.2512f);

        public override void RemoveTargetsFilter(List<WoWObject> units)
        {
            units.RemoveAll(
                ret =>
                {
                    var unit = ret as WoWUnit;
                    if (unit == null)
                        return false;

                    return false;
                });
        }

        public override void IncludeTargetsFilter(List<WoWObject> incomingunits, HashSet<WoWObject> outgoingunits)
        {
            foreach (var obj in incomingunits)
            {
                var unit = obj as WoWUnit;
                if (unit != null)
                {
                }
            }
        }

        public override void WeighTargetsFilter(List<Targeting.TargetPriority> units)
        {

            foreach (var priority in units)
            {
                var unit = priority.Object as WoWUnit;
                if (unit != null)
                {
                    switch (unit.Entry)
                    {

                    }
                }
            }
        }

        #endregion

        #region Root

        private static LocalPlayer Me => StyxWoW.Me;


        [EncounterHandler(0, "Root Handler")]
        public Func<WoWUnit, Task<bool>> RootBehavior()
        {
            return async npc =>
            {
                return false;
            };
        }

        #endregion

        #region Vigilant Kaathar


        [EncounterHandler(75839, "Vigilant Kaathar", Mode = CallBehaviorMode.Proximity)]
        public Func<WoWUnit, Task<bool>> VigilantKaatharEncounter()
        {
            
            return async boss =>
            {
                return false;
            };
        }

        #endregion

    }

    #endregion

    #region Heroic Difficulty

    public class HallsOfValorHeroic : HallsOfValor
    {
        #region Overrides of Dungeon

        public override uint DungeonId => 1194;

        #endregion
    }

    #endregion
}