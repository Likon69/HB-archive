﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using Styx;
using Styx.CommonBot;
using Styx.Pathing;
using Styx.TreeSharp;
using Styx.WoWInternals.WoWObjects;

using Bots.DungeonBuddy;
using Bots.DungeonBuddy.Profiles;
using Bots.DungeonBuddy.Attributes;
using Bots.DungeonBuddy.Helpers;

namespace Bots.DungeonBuddy.Dungeon_Scripts.Classic
{
    public class LowerBlackrockSpire : Dungeon
    {
        #region Overrides of Dungeon
        public override uint DungeonId
        {
            get { return 32; }
        }

        public override Vector3 Entrance { get { return new Vector3(-7520.996f, -1334.206f, 291.4613f); } }
        public override Vector3 ExitLocation { get { return new Vector3(64.18652f, -325.1208f, 54.05509f); } }

        private LocalPlayer Me
        {
            get { return StyxWoW.Me; }
        }

        #endregion

        [EncounterHandler(10299, "Acride", Mode = CallBehaviorMode.Proximity, BossRange = 15)]
        public Composite QuestPickupHandler()
        {
            WoWUnit unit = null;
            return new PrioritySelector(
                ctx => unit = ctx as WoWUnit,
                new Decorator(
                    ctx => Targeting.Instance.IsEmpty() && unit.QuestGiverStatus == QuestGiverStatus.Available,
                    ScriptHelpers.CreatePickupQuest(ctx => unit)),
                new Decorator(
                    ctx => Targeting.Instance.IsEmpty() && unit.QuestGiverStatus == QuestGiverStatus.TurnIn,
                    ScriptHelpers.CreateTurninQuest(ctx => unit)));
        }

        [EncounterHandler(9236, "Shadow Hunter Vosh'gajin")]
        public Composite ShadowHunterVoshgajinBehavior()
        {
            WoWUnit boss = null;
            const int curseOfBloodId = 16098;
            return new PrioritySelector(ctx => boss = ctx as WoWUnit,
                ScriptHelpers.CreateDispelGroup("Hex", ScriptHelpers.PartyDispelType.Magic),
                ScriptHelpers.CreateInterruptCast(ctx => boss, curseOfBloodId));
        }

        private const uint MobId_WarMasterVoone = 9237;

        [EncounterHandler(9237, "War Master Voone")]
        public Composite WarMasterVooneBehavior()
        {
            AddAvoidUnitCone(() => !Me.IsTank(), 0, 8, 180, u => u.Entry == MobId_WarMasterVoone && !u.IsMoving && u.CurrentTarget != Me && u.Combat);

            WoWUnit boss = null;
            return new PrioritySelector(ctx => boss = ctx as WoWUnit,
                ScriptHelpers.CreateTankFaceAwayGroupUnit(ctx => boss, 8));
        }

        private const uint MobId_MotherSmolderweb = 10596;


        [EncounterHandler(10596, "Mother Smolderweb")]
        public Composite MotherSmolderwebBehavior()
        {
            AddAvoidUnitCone(() => !Me.IsTank(), 0, 8, 180, u => u.Entry == MobId_MotherSmolderweb && !u.IsMoving && u.CurrentTarget != Me && u.Combat);

            WoWUnit boss = null;
            return new PrioritySelector(ctx => boss = ctx as WoWUnit,
                ScriptHelpers.CreateDispelGroup("Mother's Milk", ScriptHelpers.PartyDispelType.Poison),
                ScriptHelpers.CreateTankFaceAwayGroupUnit(ctx => boss, 8));
        }

        [EncounterHandler(9736, "Quartermaster Zigris")]
        public Composite QuartermasterZigrisBehavior()
        {
            WoWUnit boss = null;
            // todo: get Missile INfo for stun bomb.
            return new PrioritySelector(ctx => boss = ctx as WoWUnit);
        }

        private const uint MobId_OverlordWyrmthalak = 9568;

        [EncounterHandler(9568, "Overlord Wyrmthalak")]
        public Composite OverlordWyrmthalakBehavior()
        {
            AddAvoidUnitCone(() => !Me.IsTank(), 0, 8, 180, u => u.Entry == MobId_OverlordWyrmthalak && !u.IsMoving && u.CurrentTarget != Me && u.Combat);

            WoWUnit boss = null;
            return new PrioritySelector(ctx => boss = ctx as WoWUnit,
                ScriptHelpers.CreateTankFaceAwayGroupUnit(ctx => boss, 8));
        }
    }
}
