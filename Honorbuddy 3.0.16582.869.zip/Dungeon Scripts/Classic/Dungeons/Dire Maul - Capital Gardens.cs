﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using CommonBehaviors.Actions;
using Styx;
using Styx.Common;
using Styx.CommonBot;
using Styx.Helpers;
using Styx.CommonBot.POI;
using Styx.Pathing;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using Styx.TreeSharp;
using Action = Styx.TreeSharp.Action;
using Bots.DungeonBuddy.Attributes;
using Bots.DungeonBuddy.Helpers;
using Styx.CommonBot.Coroutines;

namespace Bots.DungeonBuddy.Dungeon_Scripts.Classic
{
    public class DireMaulCapitalGardens : Dungeon
    {
        #region Overrides of Dungeon

        private const uint EldrethDarter = 14398;
        private readonly Vector3 _immoltharExitLoc = new Vector3(-40.97228f, 760.8812f, -30.83465f);
        private readonly Vector3 _immoltharLoc = new Vector3(-38.08067f, 812.4398f, -29.53583f);

        public override uint DungeonId
        {
            get { return 36; }
        }

        public override Vector3 Entrance
        {
            get { return new Vector3(-3817.948f, 1250.378f, 160.2729f); }
        }

        public override Vector3 ExitLocation
        {
            get { return new Vector3(-51.30532f, 160.3396f, -3.458581f); }
        }
        public override void IncludeTargetsFilter(List<WoWObject> incomingunits, HashSet<WoWObject> outgoingunits)
        {
            foreach (var unit in incomingunits.Select(obj => obj.ToUnit()))
            {
                // kill these before engaging 1st boss because they will aid him.
                if (unit.Entry == IronbarkProtectorId && !Me.Combat && Me.IsTank() && ScriptHelpers.IsBossAlive("Tendris Warpwood"))
                {
                    outgoingunits.Add(unit);
                }
                else if ((unit.Entry == ArcaneAberrationId || unit.Entry == ManaRemnantId) && Me.IsTank() && !Me.Combat && unit.DistanceSqr < 40 * 40)
                {
                    PathInformation pathInfo = Navigator.LookupPathInfo(unit);
                    if (pathInfo.Navigability == PathNavigability.Navigable && pathInfo.Distance < 40)
                        outgoingunits.Add(unit);
                }
            }
        }

        public override void WeighTargetsFilter(List<Targeting.TargetPriority> units)
        {
            foreach (var p in units)
            {
                WoWUnit unit = p.Object.ToUnit();
                switch (unit.Entry)
                {
                    case IronbarkProtectorId:
                        p.Score += 100;
                        break;
                }
            }
        }

        public override void RemoveTargetsFilter(List<WoWObject> units)
        {
            units.RemoveAll(
                u =>
                {
                    var unit = u.ToUnit();
                    if (unit.Entry == EldrethDarter && !unit.Combat)
                        return true;
                    return false;
                });
        }

        public override void OnEnter()
        {
            _generator1IsDisabled = _generator2IsDisabled = _generator3IsDisabled = _generator4IsDisabled = _generator5IsDisabled = false;
        }

        public override async Task<bool> HandleMovement(MoveToParameters moveToParameters)
        {
            var location = moveToParameters.Location;
            var immolatharDistSqr = StyxWoW.Me.Location.DistanceSquared((Vector3)_immoltharLoc);
            // entering the center area
            if (location.DistanceSquared(_immoltharLoc) <= 40 * 40)
            {
                if (immolatharDistSqr < 60 * 60)
                {
                    Navigator.PlayerMover.MoveTowards(location);
                    return true;
                }
                return (await CommonCoroutines.MoveTo(_immoltharExitLoc)).IsSuccessful();
            }
            // exiting the center area.
            else if (immolatharDistSqr < 60 * 60 && location.DistanceSquared(_immoltharLoc) >= 50 * 50)
            {
                if (immolatharDistSqr < 50 * 50)
                {
                    if (StyxWoW.Me.Location.DistanceSquared((Vector3)_immoltharExitLoc) <= 8 * 8)
                        WoWMovement.Move(WoWMovement.MovementDirection.JumpAscend);
                    Navigator.PlayerMover.MoveTowards(_immoltharExitLoc);
                    return true;
                }
                else if (StyxWoW.Me.MovementInfo.IsAscending)
                    WoWMovement.MoveStop(WoWMovement.MovementDirection.JumpAscend);
            }

            return false;
        }

        #endregion

        private LocalPlayer Me
        {
            get { return StyxWoW.Me; }
        }

        [EncounterHandler(44991, "Estulan", Mode = CallBehaviorMode.Proximity, BossRange = 45)]
        [EncounterHandler(44999, "Shen'dralar Watcher", Mode = CallBehaviorMode.Proximity, BossRange = 45)]
        [EncounterHandler(14358, "Shen'dralar Ancient", Mode = CallBehaviorMode.Proximity, BossRange = 45)]
        public Composite QuestPickupHandler()
        {
            WoWUnit unit = null;
            return new PrioritySelector(
                ctx => unit = ctx as WoWUnit,
                new Decorator(
                    ctx =>
                    {
                        if (Me.Combat || unit.QuestGiverStatus != QuestGiverStatus.Available)
                            return false;

                        if (ScriptHelpers.WillPullAggroAtLocation(unit.Location))
                            return false;

                        PathInformation pathInf = Navigator.LookupPathInfo(unit, unit.InteractRange);
                        return pathInf.Navigability == PathNavigability.Navigable &&
                               pathInf.Distance < 40;
                    },
                    ScriptHelpers.CreatePickupQuest(ctx => unit)),

                new Decorator(
                    ctx =>
                    {
                        if (Me.Combat || unit.QuestGiverStatus != QuestGiverStatus.TurnIn)
                            return false;

                        if (ScriptHelpers.WillPullAggroAtLocation(unit.Location))
                            return false;

                        PathInformation pathInf = Navigator.LookupPathInfo(unit, unit.InteractRange);
                        return pathInf.Navigability == PathNavigability.Navigable &&
                               pathInf.Distance < 40;
                    },
                    ScriptHelpers.CreateTurninQuest(ctx => unit)));
        }

        #region Force Field

        private const uint ForceFieldId = 179503;
        private const int ArcaneAberrationId = 11480;
        private const int ManaRemnantId = 11483;

        private readonly Dictionary<string, Vector3> _generatorLocations = new Dictionary<string, Vector3>
        {
            {"Crystal Generator 1", new Vector3(3.172923f, 274.9728f, -8.346642f)},
            {"Crystal Generator 2", new Vector3(-81.00807f, 442.6851f, 28.60135f)},
            {"Crystal Generator 3", new Vector3(113.8273f, 435.8742f, 28.60132f)},
            {"Crystal Generator 4", new Vector3(66.86565f, 739.7091f, -24.58033f)},
            {"Crystal Generator 5", new Vector3(-141.7635f, 729.8258f, -24.57926f)},
        };

        private bool _generator1IsDisabled, _generator2IsDisabled, _generator3IsDisabled, _generator4IsDisabled, _generator5IsDisabled;

        // walk around the force field to take out 2 remaining crystal generators
        [ObjectHandler(179503, "Force Field", 2000)]
        public Composite ForceField()
        {
            return
                new PrioritySelector(
                    new Decorator(
                        ctx =>
                        !StyxWoW.Me.Combat && StyxWoW.Me.IsTank() && ((WoWGameObject)ctx).State != WoWGameObjectState.Active &&
                        Targeting.Instance.FirstUnit == null,
                        new PrioritySelector(
                            ctx =>
                            { // update the crystal genorator status.
                                foreach (var obj in ObjectManager.GetObjectsOfType<WoWGameObject>())
                                {
                                    switch (obj.Entry)
                                    {
                                        case 177259: // Crystal Generator 1
                                            _generator1IsDisabled = obj.State == WoWGameObjectState.Active;
                                            break;
                                        case 177257: // Crystal Generator 2
                                            _generator2IsDisabled = obj.State == WoWGameObjectState.Active;
                                            break;
                                        case 177258: // Crystal Generator 3
                                            _generator3IsDisabled = obj.State == WoWGameObjectState.Active;
                                            break;
                                        case 179504: // Crystal Generator 4
                                            _generator4IsDisabled = obj.State == WoWGameObjectState.Active;
                                            break;
                                        case 179505: // Crystal Generator 5
                                            _generator5IsDisabled = obj.State == WoWGameObjectState.Active;
                                            break;
                                    }
                                }
                                return ctx;
                            },
                            new Decorator(
                                ctx => BotPoi.Current.Type == PoiType.None && Me.IsTank(),
                                new PrioritySelector(
                                    new Decorator(
                                        ctx => !_generator1IsDisabled,
                                        new Sequence(
                                            new ActionSetActivity("Moving towards Crystal Generator 1"),
                                            new Action(ctx => ScriptHelpers.SetLeaderMoveToPoiPS(_generatorLocations["Crystal Generator 1"])))),
                                    new Decorator(
                                        ctx => !_generator3IsDisabled && !ScriptHelpers.IsBossAlive("Tendris Warpwood"),
                                        new Sequence(
                                            new ActionSetActivity("Moving towards Crystal Generator 3"),
                                            new Action(ctx => ScriptHelpers.SetLeaderMoveToPoiPS(_generatorLocations["Crystal Generator 3"])))),
                                    new Decorator(
                                        ctx => !_generator2IsDisabled && !ScriptHelpers.IsBossAlive("Tendris Warpwood"),
                                        new Sequence(
                                            new ActionSetActivity("Moving towards Crystal Generator 2"),
                                            new Action(ctx => ScriptHelpers.SetLeaderMoveToPoiPS(_generatorLocations["Crystal Generator 2"])))),
                                    new Decorator(
                                        ctx => !_generator4IsDisabled && !ScriptHelpers.IsBossAlive("Magister Kalendris"),
                                        new Sequence(
                                            new ActionSetActivity("Moving towards Crystal Generator 4"),
                                            new Action(ctx => ScriptHelpers.SetLeaderMoveToPoiPS(_generatorLocations["Crystal Generator 4"])))),
                                    new Decorator(
                                        ctx => !_generator5IsDisabled && !ScriptHelpers.IsBossAlive("Magister Kalendris"),
                                        new PrioritySelector(
                                          new Sequence(
                                            new ActionSetActivity("Moving towards Crystal Generator 5"),
                                            new Action(ctx => ScriptHelpers.SetLeaderMoveToPoiPS(_generatorLocations["Crystal Generator 5"]))))))))));
        }

        #endregion

        #region Tendris Warpwood

        private const uint TendrisWarpwoodId = 11489;
        private const uint IronbarkProtectorId = 11459;


        [EncounterHandler(11489, "Tendris Warpwood")]
        public Composite TendrisWarpwoodEncounter()
        {
            const uint tendrisWarpwoodId = 11489;
            WoWUnit boss = null;
            // range should stay way from boss to avoid getting trampled.
            AddAvoidObject(() => Me.IsRange() && !Me.HasAura("Entangle"), 10, o => o.Entry == tendrisWarpwoodId && o.ToUnit().Combat && o.ToUnit().CurrentTargetGuid != Me.Guid);
            return new PrioritySelector(ctx => boss = ctx as WoWUnit, ScriptHelpers.CreateDispelGroup("Grasping Vines", ScriptHelpers.PartyDispelType.Magic));
        }

        #endregion

        #region Illyanna Ravenoak

        [EncounterHandler(11488, "Illyanna Ravenoak")]
        public Composite IllyannaRavenoakEncounter()
        {
            WoWUnit boss = null;
            return new PrioritySelector(
                ctx => boss = ctx as WoWUnit,
                ScriptHelpers.CreateDispelGroup("Concussive Shot", ScriptHelpers.PartyDispelType.Magic),
                ScriptHelpers.CreateDispelGroup("Immolation Trap", ScriptHelpers.PartyDispelType.Magic));
        }

        #endregion

        #region Magister Kalendris

        [EncounterHandler(11487, "Magister Kalendris")]
        public Composite MagisterKalendrisEncounter()
        {
            WoWUnit boss = null;
            return new PrioritySelector(
                ctx => boss = ctx as WoWUnit,
                ScriptHelpers.CreateDispelGroup("Shadow Word: Pain", ScriptHelpers.PartyDispelType.Magic),
                ScriptHelpers.CreateDispelGroup("Dominate Mind", ScriptHelpers.PartyDispelType.Magic));
        }

        #endregion

        #region Magister Immol'thar

        [EncounterHandler(11496, "Immol'thar")]
        public Composite ImmoltharEncounter()
        {
            WoWUnit boss = null;
            return new PrioritySelector(ctx => boss = ctx as WoWUnit, ScriptHelpers.CreateDispelGroup("Infected Bite", ScriptHelpers.PartyDispelType.Disease));
        }

        #endregion

        #region Magister Prince Tortheldrin

        private const uint PrinceTortheldrinId = 11486;

        [EncounterHandler(11486, "Prince Tortheldrin")]
        public Composite PrinceTortheldrinEncounter()
        {
            AddAvoidObject(() => !Me.IsTank(), 8, o => o.Entry == PrinceTortheldrinId && o.ToUnit().HasAura("Whirlwind"));
            WoWUnit boss = null;
            return new PrioritySelector(ctx => boss = ctx as WoWUnit);
        }

        #endregion
    }
}