﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using CommonBehaviors.Actions;
using Styx;
using Styx.CommonBot;
using Styx.Pathing;
using Styx.TreeSharp;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using Bots.DungeonBuddy;
using Bots.DungeonBuddy.Profiles;
using Bots.DungeonBuddy.Attributes;
using Bots.DungeonBuddy.Helpers;

namespace Bots.DungeonBuddy.Dungeon_Scripts.Classic
{
    public class MaraudonEarthSongFalls : Dungeon
    {
        #region Overrides of Dungeon

        public override uint DungeonId
        {
            get { return 273; }
        }

        public override Vector3 Entrance
        {
            get { return new Vector3(-1381.243f, 2918.000f, 73.42503f); }
        }

        public override Vector3 ExitLocation
        {
            get { return new Vector3(1008.538f, -461.3261f, -43.5484f); }
        }

        public override void WeighTargetsFilter(List<Targeting.TargetPriority> units)
        {
            foreach (var t in units)
            {
                var prioObject = t.Object;

                //Shardlings
                if (prioObject.Entry == 11783)
                {
                    t.Score += 400;
                }
            }
        }

        #endregion

        private const int PrincessTheradrasQuestId = 27692;
        private const uint LandslideId = 12203;
        private const uint PrincessTheradrasId = 12201;

        private LocalPlayer Me
        {
            get { return StyxWoW.Me; }
        }

        [EncounterHandler(0, "Root")]
        public Composite RootHandler()
        {
            PlayerQuest quest = null;
            return
                new PrioritySelector(
                    new Decorator(
                        ctx => (quest = Me.QuestLog.GetQuestById(PrincessTheradrasQuestId)) != null && quest.IsCompleted,
                        ScriptHelpers.CreateCompletePopupQuest(PrincessTheradrasQuestId)));
        }

        [EncounterHandler(12203, "Landslide")]
        public Composite LandslideFight()
        {
            const uint landslideId = 12203;
            var tankLoc = new Vector3(360.0094f, -180.9783f, -59.89912f);
            WoWUnit boss = null;
            // ranged should stay away from boss to not get hit by the 'Trample' and AOE stun ability.
            AddAvoidObject(
                () => Me.IsRange() && !Me.IsCasting && ScriptHelpers.Tank != null && ScriptHelpers.Tank.IsAlive,
                10,
                o => o.Entry == landslideId && o.ToUnit().Combat && o.ToUnit().CurrentTargetGuid != Me.Guid);

            return new PrioritySelector(
                ctx => boss = ctx as WoWUnit, new Decorator(ctx => Me.IsTank() && boss.CurrentTargetGuid == Me.Guid, ScriptHelpers.CreateTankUnitAtLocation(ctx => tankLoc, 10)));
        }

        [EncounterHandler(12201, "Princess Theradras")]
        public Composite PrincessTheradrasFight()
        {
            var tankLoc = new Vector3(15.12897f, 63.57555f, -126.2918f);
            WoWUnit boss = null;

            return new PrioritySelector(
                ctx => boss = ctx as WoWUnit, new Decorator(ctx => Me.IsTank() && boss.CurrentTargetGuid == Me.Guid, ScriptHelpers.CreateTankUnitAtLocation(ctx => tankLoc, 10)));
        }
    }
}