﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Threading.Tasks;
using Buddy.Coroutines;
using CommonBehaviors.Actions;
using Styx;
using Styx.Common;
using Styx.Common.Helpers;
using Styx.CommonBot;
using Styx.CommonBot.Coroutines;
using Styx.Helpers;
using Styx.Pathing;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using Styx.TreeSharp;
using Action = Styx.TreeSharp.Action;
using Bots.DungeonBuddy.Attributes;
using Bots.DungeonBuddy.Helpers;

namespace Bots.DungeonBuddy.Dungeon_Scripts.Classic
{
    internal class BlackfathomDeeps : Dungeon
    {
        #region Overrides of Dungeon

        private Vector3 _poolExitLoc = new Vector3(-364.091f, 17.35647f, -58.10578f);
        private Vector3 _poolLoc = new Vector3(-313.4475f, 70.60279f, -53.60029f);

        public override uint DungeonId
        {
            get { return 10; }
        }

        public override Vector3 Entrance
        {
            get { return new Vector3(4247.842f, 750.5999f, -22.39564f); }
        }

        public override Vector3 ExitLocation
        {
            get { return new Vector3(-150.17f, 113.01f, -40.54f); }
        }

        public override bool SnapToWaterSurfaceWhileSwimming => false;

        public override void IncludeTargetsFilter(List<WoWObject> incomingunits, HashSet<WoWObject> outgoingunits)
        {
            foreach (var unit in incomingunits.OfType<WoWUnit>())
            {
                if (unit.Entry == MobId_RestorativeWaters)
                    outgoingunits.Add(unit);

                // this boss doesn't get included automatically due to not being navigatable.
                if (unit.Entry == MobId_GuardianoftheDeep && Me.IsTank() && unit.DistanceSqr < 20*20)
                    outgoingunits.Add(unit);
            }
        }

        public override void RemoveTargetsFilter(List<WoWObject> units)
        {
            var tank = ScriptHelpers.Tank;

            units.RemoveAll(
                ret =>
                {
                    var unit = ret.ToUnit();
                    if (unit == null)
                        return false;

                    if (!unit.Combat && unit.Entry != MobId_GuardianoftheDeep && (Me.IsSwimming || !Me.IsSwimming && unit.Z < -58))
                        return true;
                    if (unit.Entry == SkitteringCrustaceanId && !unit.Combat)
                        return true;

                    // ignore any deep terrors with no tank nearby. 
                    if (tank != null && Me.IsDps && _mobIds_DeepTerror_Trash.Contains(unit.Entry)
                        && tank.Location.DistanceSquared((Vector3)unit.Location) > 20 * 20)
                    {
                        return true;
                    }
                    return false;
                });
        }

        public override void WeighHealTargetsFilter(List<Targeting.TargetPriority> objPriorities)
        {
            foreach (var priority in objPriorities)
            {
                var unit = priority.Object as WoWUnit;
                if (unit == null)
                    continue;
                if (unit.Entry == MobId_RestorativeWaters || unit.Entry == MobId_DeepTerror)
                    priority.Score += 4500;
            }
        }

        public override async Task<bool> HandleMovement(MoveToParameters moveToParameters)
        {
            var guardianOfTheDeep =
                ObjectManager.GetObjectsOfType<WoWUnit>().FirstOrDefault(u => u.Entry == MobId_GuardianoftheDeep);

            if (guardianOfTheDeep != null &&
                moveToParameters.Location.DistanceSquared(guardianOfTheDeep.Location) < 5 * 5)
            {
                moveToParameters.DistanceTolerance = 20;
                return (await CommonCoroutines.MoveTo(moveToParameters, guardianOfTheDeep.SafeName)).IsSuccessful();
            }

            return false;
        }

        #endregion

        private const uint SkitteringCrustaceanId = 4821;

        private LocalPlayer Me
        {
            get { return StyxWoW.Me; }
        }

        #region Root

        private const int NightmareOfTheDeeps = 26888;
        private const uint MobId_GuardianoftheDeep = 74508;
        private const uint JeneuSancreaId = 12736;

        private const uint AreaTriggerId_CrushingSingularity = 5632;

        [EncounterHandler(44375, "Zeya", Mode = CallBehaviorMode.Proximity, BossRange = 40)]
        [EncounterHandler(12736, "Je'neu Sancrea", Mode = CallBehaviorMode.Proximity, BossRange = 40)]
        [EncounterHandler(44387, "Flaming Eradicator", Mode = CallBehaviorMode.Proximity, BossRange = 40)]
        public Composite QuestGiversBehavior()
        {
            WoWUnit unit = null;
            return new PrioritySelector(
                ctx => unit = ctx as WoWUnit,
                new Decorator(
                    ctx => !Me.Combat && unit.QuestGiverStatus == QuestGiverStatus.Available,
                    new PrioritySelector(
                        new Decorator(
                            ctx =>
                            unit.Entry == JeneuSancreaId && Me.QuestLog.GetQuestById(NightmareOfTheDeeps) == null &&
                            Me.QuestLog.GetCompletedQuests().All(id => id != NightmareOfTheDeeps),
                            ScriptHelpers.CreatePickupQuest(ctx => unit, NightmareOfTheDeeps)),
                        new Decorator(ctx => unit.Entry != JeneuSancreaId, ScriptHelpers.CreatePickupQuest(ctx => unit)))),
                new Decorator(ctx => !Me.Combat && unit.QuestGiverStatus == QuestGiverStatus.TurnIn, ScriptHelpers.CreateTurninQuest(ctx => unit)));
        }

        private static JumpLink[] s_entranceJumpLinks = 
        {
            new JumpLink(new Vector3(-360.3055f, 35.85441f, -53.31745f), new Vector3(-353.9965f, 35.93509f, -53.12798f) ), 
            new JumpLink(new Vector3(-337.2195f, 43.70443f, -53.12798f), new Vector3(-335.3502f, 48.55634f, -53.12798f) ), 
            new JumpLink(new Vector3(-329.4847f, 49.89294f, -53.12798f), new Vector3(-322.8451f, 49.93631f, -53.127988f) ), 
            new JumpLink(new Vector3(-314.6612f, 62.4528f, -53.12927f), new Vector3(-314.3893f, 67.99188f, -53.66935f) ),
        };


        [EncounterHandler(0)]
        public Func<WoWUnit, Task<bool>> RootLogic()
        {
            var tankWaitSpotByPool = new Vector3(-299.8438f, 90.33894f, -51.45882f);
            AddAvoidObject(15, o => o.Entry == AreaTriggerId_CrushingSingularity, ignoreIfBlocking: true);

            return async boss =>
            {
                var breathInfo = StyxWoW.Me.GetMirrorTimerInfo(MirrorTimerType.Breath);

                if (breathInfo.IsVisible && breathInfo.CurrentTime < 15000 &&
                    !StyxWoW.Me.MovementInfo.IsAscending)
                {
                    WoWMovement.Move(WoWMovement.MovementDirection.JumpAscend);
                    return true;
                }

                if (!breathInfo.IsVisible && (StyxWoW.Me.MovementInfo.IsAscending || StyxWoW.Me.MovementInfo.JumpingOrShortFalling))
                {
                    WoWMovement.MoveStop(WoWMovement.MovementDirection.JumpAscend);
                    return true;
                }

                var activeJumplink =
                    s_entranceJumpLinks.FirstOrDefault(j => j.Start.DistanceSquared(Me.Location) < 3 * 3);

                if (activeJumplink != null)
                {
                    await HandleJump(activeJumplink);
                    return true;
                }

                if (StyxWoW.Me.IsTank() && StyxWoW.Me.PartyMembers.Any(p => p.IsSwimming || p.Y < 65f) &&
                    StyxWoW.Me.Location.DistanceSquared((Vector3)tankWaitSpotByPool) < 10 * 10 &&
                    StyxWoW.Me.PartyMembers.All(p => p.IsAlive && !p.Combat))
                {
                    await CommonCoroutines.StopMoving();
                    return true;
                }
                return false;
            };
        }

        private float GetLiquidHeight(Vector3 location)
        {
            if (location.Y < 113 && location.X > -378)
                return -58;

            if (location.Y > 80)
                return -56;

            return -31.7f;
        }

        private async Task HandleJump(JumpLink jumpLink)
        {
            if (Me.Location.Distance2DSquared(jumpLink.Start) >= 0.5 * 0.5)
            {
                Navigator.PlayerMover.MoveTowards(jumpLink.Start);
                await Coroutine.Wait(2000, () => Me.Location.Distance2DSquared(jumpLink.Start) < 0.5 * 0.5);
            }
            Navigator.PlayerMover.MoveTowards(jumpLink.End);
            await Coroutine.Yield();
            WoWMovement.Move(WoWMovement.MovementDirection.JumpAscend, TimeSpan.FromMilliseconds(100));
            await Coroutine.Yield();
            await Coroutine.Wait(3000, () => !Me.IsFalling);
            Navigator.Clear();
            //WoWMovement.Move(WoWMovement.MovementDirection.JumpAscend);
        }

        private const uint MobId_LadySarevess = 4831;

        [EncounterHandler(4831, "Lady Sarevess")]
        public Composite LadySarevessBehavior()
        {
            const int forkedLightningId = 8435;
            AddAvoidUnitCone(() => !Me.IsTank(), 0, 40, 180, u => u.Entry == MobId_LadySarevess && u.CurrentTarget != Me && u.Combat);
            WoWUnit boss = null;
            return new PrioritySelector(
                ctx => boss = ctx as WoWUnit,
                ScriptHelpers.CreateInterruptCast(ctx => boss, forkedLightningId),
                ScriptHelpers.CreateDispelGroup("Slow", ScriptHelpers.PartyDispelType.Magic));
        }

        [ObjectHandler(224720, "Fire of Aku'mai", 50)]
        public async Task<bool> FireOfAkumaiHandler(WoWGameObject fire)
        {
            if (!Me.IsTank() || !Targeting.Instance.IsEmpty() || Me.Z < -30)
                return false;

            if (IsAkumaiDoorOpen(true))
                return false;

            if (fire.State != WoWGameObjectState.Ready)
                return false;

            if (!fire.WithinInteractRange)
            {
                return (await CommonCoroutines.MoveTo(fire.Location, "Fire of Aku'mai")).IsSuccessful();
            }

            await CommonCoroutines.StopMoving("Reached Fire of Aku'mai");

            fire.Interact();

            if (!await Coroutine.Wait(3000, () => IsAkumaiDoorOpen(false)))
            {
                Logging.WriteDiagnostic("Aku'mai door did not open after interaction with Fire of Aku'mai");
                return true;
            }

            // Door is open, continue onwards
            return false;
        }

        private TimeCachedValue<bool> _akumaiDoorOpen;
        private bool IsAkumaiDoorOpen(bool cached)
        {
            if (_akumaiDoorOpen == null)
            {
                _akumaiDoorOpen = new TimeCachedValue<bool>(TimeSpan.FromSeconds(2), () =>
                {
                    WoWGameObject portalToAkumai =
                        ObjectManager.GetObjectsOfTypeFast<WoWGameObject>().FirstOrDefault(g => g.Entry == 21117);
                    if (portalToAkumai == null) // Just regard it as open until we're close
                        return true;

                    WoWDoor door = (WoWDoor)portalToAkumai.SubObj;
                    return door.IsOpen;
                });
            }

            return cached ? _akumaiDoorOpen.Value : _akumaiDoorOpen.Refreshed();
        }

        #endregion

        #region Thruk

        private const int SpellId_FilletOfFlesh = 149913;

        private const uint MobId_Thruk = 74505;
        [EncounterHandler((int)MobId_Thruk, "Thruk")]
        public Func<WoWUnit, Task<bool>> ThrukEncounter()
        {
            AddAvoidObject(10, o => o.Entry == MobId_Thruk && o.ToUnit().CastingSpellId == SpellId_FilletOfFlesh);
            return async boss => false;
        }

        #endregion

        #region Executioner Gore

        private const int SpellId_ExecutionersStrike = 149943;
        private const uint MobId_ExecutionerGore = 74518;
        private const uint AreaTriggerId_ExecutionersStrike = 5982;

        [EncounterHandler((int)MobId_ExecutionerGore, "Executioner Gore")]
        public Func<WoWUnit, Task<bool>> ExecutionerGoreEncounter()
        {
            AddAvoidObject(5, AreaTriggerId_ExecutionersStrike);

            AddAvoidObject(5, o => o.Entry == MobId_ExecutionerGore && o.ToUnit().CastingSpellId == SpellId_ExecutionersStrike, o => o.Location.RayCast(o.Rotation, 4));
            AddAvoidObject(6, o => o.Entry == MobId_ExecutionerGore && o.ToUnit().CastingSpellId == SpellId_ExecutionersStrike, o => o.Location.RayCast(o.Rotation, 9));
            AddAvoidObject(7, o => o.Entry == MobId_ExecutionerGore && o.ToUnit().CastingSpellId == SpellId_ExecutionersStrike, o => o.Location.RayCast(o.Rotation, 15));
            AddAvoidObject(8, o => o.Entry == MobId_ExecutionerGore && o.ToUnit().CastingSpellId == SpellId_ExecutionersStrike, o => o.Location.RayCast(o.Rotation, 22));
            AddAvoidObject(9, o => o.Entry == MobId_ExecutionerGore && o.ToUnit().CastingSpellId == SpellId_ExecutionersStrike, o => o.Location.RayCast(o.Rotation, 30));

            // Devouring Blackness is not interruptable like the dungeon journal shows.
            return async boss => false;
        }

        #endregion Executioner Gore


        #region Twilight Lord Bathiel

        private const uint MobId_RestorativeWaters = 74569;
        private const uint MobId_TwilightLordBathiel = 74728;
        private const int MissileSpellId_PiercingRain = 152884;

        [EncounterHandler((int)MobId_TwilightLordBathiel, "Twilight Lord Bathiel")]
        public Func<WoWUnit, Task<bool>> TwilightLordBathielEncounter()
        {
            AddAvoidLocation(
                () => true,
                4,
                m => ((WoWMissile)m).ImpactPosition,
                () => WoWMissile.InFlightMissiles.Where(m => m.SpellId == MissileSpellId_PiercingRain));

            return async boss => false;
        }

        #endregion

        #region Aku'mai the Devourer

        private const int SpellId_Crush = 150660;
        private const uint MobId_DeepTerror = 75172;

        private HashSet<uint> _mobIds_DeepTerror_Trash = new HashSet<uint> { 75172, 74747, 75780, 75086, };

        private const uint MobId_AkumaitheDevourer = 75155;
        private const int MissileSpellId_FallingDebris = 152966;

        [EncounterHandler((int)MobId_AkumaitheDevourer, "Aku'mai the Devourer")]
        public Func<WoWUnit, Task<bool>> AkumaitheDevourerEncounter()
        {
            AddAvoidObject(5, o => o.Entry == MobId_DeepTerror && o.ToUnit().CastingSpellId == SpellId_Crush, o => o.Location.RayCast(o.Rotation, 4));
            AddAvoidObject(6, o => o.Entry == MobId_DeepTerror && o.ToUnit().CastingSpellId == SpellId_Crush, o => o.Location.RayCast(o.Rotation, 9));
            AddAvoidObject(7, o => o.Entry == MobId_DeepTerror && o.ToUnit().CastingSpellId == SpellId_Crush, o => o.Location.RayCast(o.Rotation, 15));
            AddAvoidObject(8, o => o.Entry == MobId_DeepTerror && o.ToUnit().CastingSpellId == SpellId_Crush, o => o.Location.RayCast(o.Rotation, 20));

            AddAvoidLocation(
                () => true,
                4,
                m => ((WoWMissile)m).ImpactPosition,
                () => WoWMissile.InFlightMissiles.Where(m => m.SpellId == MissileSpellId_FallingDebris));

            return async boss => false;
        }

        #endregion

        private class JumpLink
        {
            public JumpLink(Vector3 start, Vector3 end)
            {
                Start = start;
                End = end;
            }

            public Vector3 Start { get; private set; }
            public Vector3 End { get; private set; }
        }
    }
}