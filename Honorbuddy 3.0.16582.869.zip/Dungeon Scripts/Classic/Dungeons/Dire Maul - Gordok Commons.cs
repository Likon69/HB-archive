﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;
using CommonBehaviors.Actions;
using Styx;
using Styx.CommonBot;
using Styx.Pathing;
using Styx.WoWInternals.WoWObjects;
using Styx.TreeSharp;

using Bots.DungeonBuddy.Attributes;
using Bots.DungeonBuddy.Helpers;
using Styx.Common;
using Styx.Helpers;

namespace Bots.DungeonBuddy.Dungeon_Scripts.Classic
{
    public class DireMaulGordokCommons : Dungeon
    {
        #region Overrides of Dungeon

        public override uint DungeonId
        {
            get { return 38; }
        }

        public override Vector3 Entrance
        {
            get { return new Vector3(-3520.225f, 1094.745f, 161.0336f); }
        }

        public override Vector3 ExitLocation
        {
            get { return new Vector3(255.0915f, -12.56872f, -2.564304f); }
        }

        public override void WeighTargetsFilter(List<Targeting.TargetPriority> units)
        {
            foreach (var p in units)
            {
                var unit = p.Object.ToUnit();
                if ((unit.Entry == CaptainKromcrushId || unit.Entry == GordokMageLordId) && Me.IsDps)
                    p.Score += 1000;
            }
        }

        public override void RemoveTargetsFilter(List<WoWObject> units)
        {
            units.RemoveAll(
                o =>
                {
                    WoWUnit unit = o.ToUnit();
                    if (unit != null)
                    {
                        if (unit.Entry == CaptainKromcrushId && unit.HasAura("Retaliation") && Me.IsMelee())
                            return true;
                    }
                    return false;
                });
        }

        public override void IncludeTargetsFilter(List<WoWObject> incomingunits, HashSet<WoWObject> outgoingunits)
        {
            foreach (var unit in outgoingunits.Select(u => u.ToUnit()))
            {
                if (unit.Entry == WanderingEyeofKilroggId && (Me.IsTank() || unit.Combat))
                {
                    outgoingunits.Add(unit);
                }
            }
        }

        private static readonly Vector3 s_leftEntranceTrashLoc = new Vector3(298.3713f, 38.06606f, -3.957795f);
        private static readonly Vector3 s_rightEntranceTrashLoc = new Vector3(354.2512f, -108.8843f, -3.886184f);
        private static readonly Vector3 s_rightArchTrashLoc = new Vector3(445.1893f, 143.155f, -0.07393706f);
        private static readonly Vector3 s_centerArchTrashLoc = new Vector3(445.1893f, 143.155f, -0.07393706f);
        private static readonly Vector3 s_leftArchTrashLoc = new Vector3(445.1893f, 143.155f, -0.07393706f);
        private static readonly Vector3 s_moldarTrashLoc = new Vector3(358.8067f, 4.972275f, -24.7655f);

        private static readonly TimeCachedValue<bool> s_shouldAvoidRightEntranceSide = new TimeCachedValue<bool>(
            TimeSpan.FromSeconds(5),
            () => ScriptHelpers.GetUnfriendlyNpsAtLocation(
                s_rightEntranceTrashLoc,
                20,
                unit => unit.IsHostile && Math.Abs(unit.Z - s_rightEntranceTrashLoc.Z) < 8).Any());

        private static readonly TimeCachedValue<bool> s_shouldAvoidLeftEntranceSide = new TimeCachedValue<bool>(
            TimeSpan.FromSeconds(5),
            () => ScriptHelpers.GetUnfriendlyNpsAtLocation(
                s_leftEntranceTrashLoc,
                20,
                unit => unit.IsHostile && Math.Abs(unit.Z - s_rightEntranceTrashLoc.Z) < 8).Any());

        private static readonly TimeCachedValue<bool> s_shouldAvoidRightArch = new TimeCachedValue<bool>(
            TimeSpan.FromSeconds(5),
            () => ScriptHelpers.GetUnfriendlyNpsAtLocation(
                s_leftEntranceTrashLoc,
                10,
                unit => unit.IsHostile && Math.Abs(unit.Z - s_rightArchTrashLoc.Z) < 8).Any());

        private static readonly TimeCachedValue<bool> s_shouldAvoidCenterArch = new TimeCachedValue<bool>(
            TimeSpan.FromSeconds(5),
            () => ScriptHelpers.GetUnfriendlyNpsAtLocation(
                s_leftEntranceTrashLoc,
                10,
                unit => unit.IsHostile && Math.Abs(unit.Z - s_centerArchTrashLoc.Z) < 8).Any());

        private static readonly TimeCachedValue<bool> s_shouldAvoidLeftArch = new TimeCachedValue<bool>(
            TimeSpan.FromSeconds(5),
            () => ScriptHelpers.GetUnfriendlyNpsAtLocation(
                s_leftEntranceTrashLoc,
                10,
                unit => unit.IsHostile && Math.Abs(unit.Z - s_leftArchTrashLoc.Z) < 8).Any());

        private static readonly TimeCachedValue<bool> s_shouldAvoidMoldarTrash = new TimeCachedValue<bool>(
            TimeSpan.FromSeconds(5),
            () => ScriptHelpers.GetUnfriendlyNpsAtLocation(
                s_leftEntranceTrashLoc,
                10,
                unit => unit.IsHostile && Math.Abs(unit.Z - s_leftArchTrashLoc.Z) < 8).Any());

        #endregion

        private LocalPlayer Me
        {
            get { return StyxWoW.Me; }
        }

        #region Root

        private const uint GordokMageLordId = 11444;
        private const uint GordokReaverId = 11450;
        private const uint WanderingEyeofKilroggId = 14386;
        [EncounterHandler(45052, "Stonemaul Ogre", Mode = CallBehaviorMode.Proximity, BossRange = 30)]
        public Composite QuestPickupHandler()
        {
            WoWUnit unit = null;
            return new PrioritySelector(
                ctx => unit = ctx as WoWUnit,
                new Decorator(
                    ctx => !Me.Combat && !ScriptHelpers.WillPullAggroAtLocation(unit.Location) && unit.QuestGiverStatus == QuestGiverStatus.Available,
                    ScriptHelpers.CreatePickupQuest(ctx => unit)),
                new Decorator(
                    ctx => !Me.Combat && !ScriptHelpers.WillPullAggroAtLocation(unit.Location) && unit.QuestGiverStatus == QuestGiverStatus.TurnIn,
                    ScriptHelpers.CreateTurninQuest(ctx => unit)));
        }

        [EncounterHandler(0, "Root Handler")]
        public Func<WoWUnit, Task<bool>> RootHandler()
        {
            // Right Entrance Trash group
            AddAvoidLocation(() => Me.IsFollower() && s_shouldAvoidRightEntranceSide, 30, () => s_rightEntranceTrashLoc);

            // Left Entrance Trash group
            AddAvoidLocation(() => Me.IsFollower() && s_shouldAvoidLeftEntranceSide, 30, () => s_leftEntranceTrashLoc);

            // Right Arch Trash group
            AddAvoidLocation(() => Me.IsFollower() && s_shouldAvoidRightArch, 15, () => s_rightArchTrashLoc);

            // Center Arch Trash group
            AddAvoidLocation(() => Me.IsFollower() && s_shouldAvoidCenterArch, 15, () => s_centerArchTrashLoc);

            // Left Arch Trash group
            AddAvoidLocation(() => Me.IsFollower() && s_shouldAvoidLeftArch, 15, () => s_leftArchTrashLoc);

            // Moldar Trash group
            //AddAvoidLocation(() => Me.IsFollower() && s_shouldAvoidMoldarTrash, 30, () => s_moldarTrashLoc);

            return async boss => false;
        }

        #endregion

        private const uint MobId_StomperKreeg = 14322;

        [EncounterHandler(MobId_StomperKreeg, "Stomper Kreeg")]
        public Composite StomperKreegFight()
        {
            AddAvoidUnitCone(() => !Me.IsTank(), 0, 15, 180, u => u.Entry == MobId_StomperKreeg && u.Combat && u.CurrentTarget != Me && u.Combat);

            WoWUnit boss = null;

            AddAvoidObject(() => !Me.IsTank(), 8, o => o.Entry == MobId_StomperKreeg && o.ToUnit().HasAura("Whirlwind"));

            return new PrioritySelector(
                ctx => boss = ctx as WoWUnit,
                ScriptHelpers.CreateTankFaceAwayGroupUnit(ctx => boss, 15));
        }

        [EncounterHandler(14323, "Guard Slip'kik", Mode = CallBehaviorMode.Proximity, BossRange = 120)]
        public Composite GuardSlipkikEncounter()
        {
            WoWUnit boss = null;
            var pullToLoc = new Vector3(535.7172f, 542.0845f, -25.40273f);
            var trap = new Vector3(559.7982f, 547.8613f, -25.40069f);
            return new PrioritySelector(
                ctx => boss = ctx as WoWUnit,
                new Decorator(
                    ctx => Me.IsTank(),
                    ScriptHelpers.CreatePullNpcToLocation(ctx => !boss.Combat, ctx => boss.Location.Distance(trap) <= 15, ctx => boss, ctx => pullToLoc, ctx => pullToLoc, 4)),
                new Decorator(ctx => Targeting.Instance.TargetList.All(t => t.CurrentTargetGuid == Me.Guid), ScriptHelpers.CreateTankUnitAtLocation(ctx => pullToLoc, 5)));
        }

        #region Captain Kromcrush

        private const uint CaptainKromcrushId = 14325;

        [EncounterHandler(CaptainKromcrushId, "Captain Kromcrush")]
        public Composite CaptainKromcrushFight()
        {
            WoWUnit boss = null;
            // range need to stay away to avoid getting feared.
            AddAvoidObject(() => Me.IsRange() && !Me.IsCasting, 8, o => o.Entry == CaptainKromcrushId && o.ToUnit().CurrentTargetGuid != Me.Guid && o.ToUnit().IsAlive && !o.ToUnit().IsMoving);
            // avoid gatting cleaved.
            AddAvoidUnitCone(() => !Me.IsTank() && !Me.IsCasting, 0, 8, 180, u => u.Entry == CaptainKromcrushId && u.Combat && !u.IsMoving && u.CurrentTarget != Me && u.Combat);

            var tankLoc = new Vector3(584.6393f, 481.2674f, 29.4628f);
            return new PrioritySelector(
                ctx => boss = ctx as WoWUnit,
                new Decorator(
                    ctx => Me.IsTank() && Targeting.Instance.TargetList.All(t => t.CurrentTargetGuid == Me.Guid), ScriptHelpers.CreateTankUnitAtLocation(ctx => tankLoc, 7)),
                new Decorator(ctx => Me.IsTank() && Targeting.Instance.IsEmpty(), new ActionAlwaysSucceed()));
        }

        private const uint MobId_GordokReaver = 11450;

        [EncounterHandler(11450, "Gordok Reaver")]
        public Composite GordokReaverFight()
        {
            // avoid gatting cleaved.
            AddAvoidUnitCone(() => !Me.IsTank() && !Me.IsCasting, 0, 8, 180, u => u.Entry == MobId_GordokReaver && u.Combat && !u.IsMoving && u.CurrentTarget != Me);

            WoWUnit unit = null;
            return new PrioritySelector();
        }

        #endregion

        #region KingGordok

        [EncounterHandler(11501, "King Gordok")]
        public Composite KingGordokFight()
        {
            const uint kingGordokId = 11501;

            WoWUnit boss = null;
            // range need to stay away to avoid getting stunned.
            AddAvoidObject(() => Me.IsRange(), 5, o => o.Entry == kingGordokId && o.ToUnit().CurrentTargetGuid != Me.Guid);
            return new PrioritySelector(ctx => boss = ctx as WoWUnit, ScriptHelpers.CreateDispelEnemy("Bloodlust", ScriptHelpers.EnemyDispelType.Magic, ctx => boss));
        }


        [EncounterHandler(14324, "ChorushTheObserver")]
        public Composite ChorushTheObserverFight()
        {
            WoWUnit unit = null;
            const int healingWaveId = 15982;
            const int healId = 38209;
            return new PrioritySelector(ctx => unit = ctx as WoWUnit, ScriptHelpers.CreateInterruptCast(ctx => unit, healingWaveId, healId));
        }

        #endregion
    }
}