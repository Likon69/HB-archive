using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Threading.Tasks;
using CommonBehaviors.Actions;
using Styx;
using Styx.Common.Helpers;
using Styx.CommonBot;
using Styx.Pathing;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using Styx.TreeSharp;

using Bots.DungeonBuddy.Profiles;
using Bots.DungeonBuddy.Attributes;
using Bots.DungeonBuddy.Helpers;
using Styx.Common;
using Styx.CommonBot.Coroutines;
using Styx.Helpers;
using Action = Styx.TreeSharp.Action;

namespace Bots.DungeonBuddy.Dungeon_Scripts.Wrath_of_the_Lich_King
{
    public class AhnkahetTheOldKingdom : Dungeon
    {
        #region Overrides of Dungeon

        public override uint DungeonId { get { return 218; } }

        public override Vector3 Entrance
        {
            get { return new Vector3(3640.21f, 2028.928f, 2.59325f); }
        }

        public override Vector3 ExitLocation
        {
            get { return new Vector3(333.0131f, -1109.873f, 69.77443f); }
        }

        public override void RemoveTargetsFilter(List<WoWObject> units)
        {
            units.RemoveAll(
                ret => { return false; });
        }

        public override void IncludeTargetsFilter(List<WoWObject> incomingunits, HashSet<WoWObject> outgoingunits)
        {
            foreach (var obj in incomingunits)
            {
                var unit = obj as WoWUnit;
                if (unit != null)
                {
                    if (unit.Entry == TwilightVolunteerId && unit.CanSelect && unit.Attackable)
                    {
                        var boss = ObjectManager.GetObjectsOfType<WoWUnit>().FirstOrDefault(u => u.Entry == JedogaShadowseekerId);
                        if (boss != null && (!boss.Attackable || !boss.CanSelect))
                            outgoingunits.Add(unit);
                    }
                    if (StyxWoW.Me.HasAura("Insanity") && unit.CanSelect && unit.Attackable)
                    {
                        outgoingunits.Add(unit);
                    }
                }
            }
        }

        public override void WeighTargetsFilter(List<Targeting.TargetPriority> units)
        {
            foreach (var priority in units)
            {
                var unit = priority.Object as WoWUnit;
                if (unit != null)
                {
                    if (unit.Entry == AhnkaharGuardianId)
                        priority.Score += 500;

                    if (unit.Entry == SpellFlingerId && StyxWoW.Me.IsRange())
                        priority.Score += 500;
                }
            }
        }

        private static Vector2[] s_endgeNear2ndBoss = new Vector2[]
        {
            new Vector2(549.823f, -816.8023f),
            new Vector2(550.8982f, -814.6368f),
            new Vector2(558.636f, -820.1128f),
            new Vector2(565.6065f, -833.3146f),
            new Vector2(565.0404f, -853.7917f),
            new Vector2(562.8259f, -854.9758f),
            new Vector2(562.4608f, -831.3884f),
        };

        public override async Task<bool> HandleMovement(MoveToParameters moveToParameters)
        {
            // Move off this silly little ledge in case we end up here.
            if (WoWMathHelper.IsPointInPoly(StyxWoW.Me.Location, s_endgeNear2ndBoss))
            {
                Navigator.PlayerMover.MoveTowards(new Vector3(568.0109f, -827.9291f, -3.272495f));
                return true;
            }

            var jedoga = ObjectManager.GetObjectsOfType<WoWUnit>().FirstOrDefault(u => u.Entry == JedogaShadowseekerId);
            if (jedoga != null && jedoga.Location.DistanceSquared(moveToParameters.Location) < 3*3)
            {
                moveToParameters.DistanceTolerance = 20;
                return (await CommonCoroutines.MoveTo(moveToParameters, jedoga.SafeName)).IsSuccessful();
            }

            return false;
        }

        #endregion

        #region Root

        private const uint TwilightVolunteerId = 30385;
        private const uint AhnkaharGuardianId = 30176;
        private const uint SpellFlingerId = 30278;
        private const uint PlagueWalkerId = 30283;
        private LocalPlayer Me
        {
            get { return StyxWoW.Me; }
        }


        [EncounterHandler(55658, "Seer Ixit", Mode = CallBehaviorMode.Proximity, BossRange = 35)]
        public Composite QuestPickupHandler()
        {
            WoWUnit unit = null;
            return new PrioritySelector(
                ctx => unit = ctx as WoWUnit,
                new Decorator(
                    ctx => !Me.Combat && !ScriptHelpers.WillPullAggroAtLocation(unit.Location) && unit.QuestGiverStatus == QuestGiverStatus.Available,
                    ScriptHelpers.CreatePickupQuest(ctx => unit)),
                new Decorator(
                    ctx => !Me.Combat && !ScriptHelpers.WillPullAggroAtLocation(unit.Location) && unit.QuestGiverStatus == QuestGiverStatus.TurnIn,
                    ScriptHelpers.CreateTurninQuest(ctx => unit)));
        }


        [EncounterHandler(0, "Root")]
        public Composite RootEncounter()
        {
            // handle a tough trash pul.
            var trashToNadoxTankLoc = new Vector3(598.4812f, -1022.298f, 38.35839f);
            var trashToNadoxWaitLoc = new Vector3(615.3074f, -1021.679f, 32.71127f);
            var trashToNadoxLoc = new Vector3(638.6355f, -1004.077f, 22.94104f);
            const int pupilNoMoreQuestId = 29825;
            const int reclaimingAhnKahetQuestId = 29826;
            const uint ahnkaharSwarmerId = 30338;

            WoWUnit[] trash = null;

            return new PrioritySelector(
                    new Decorator(ctx => Me.QuestLog.ContainsQuest(pupilNoMoreQuestId) && Me.QuestLog.GetQuestById(pupilNoMoreQuestId).IsCompleted,
                        ScriptHelpers.CreateCompletePopupQuest(pupilNoMoreQuestId)),

                    new Decorator(ctx => Me.QuestLog.ContainsQuest(reclaimingAhnKahetQuestId) && Me.QuestLog.GetQuestById(reclaimingAhnKahetQuestId).IsCompleted,
                        ScriptHelpers.CreateCompletePopupQuest(reclaimingAhnKahetQuestId)),

                    new Decorator(
                        ctx =>
                        StyxWoW.Me.Location.DistanceSquared(trashToNadoxTankLoc) <= 25 * 25 &&
                        ScriptHelpers.GetUnfriendlyNpsAtLocation(trashToNadoxLoc, 70, u => u.Entry == PlagueWalkerId).Any(),
                        new PrioritySelector(
                            ctx => trash = ScriptHelpers.GetUnfriendlyNpsAtLocation(trashToNadoxLoc, 55, u => u.Entry != ahnkaharSwarmerId).ToArray(),
                            ScriptHelpers.CreatePullNpcToLocation(
                                ctx => trash.Length > 4,
                                ctx => trash.Any(t => t.Location.DistanceSquared(trashToNadoxLoc) <= 7 * 7),
                                ctx => trash[0],
                                ctx => trashToNadoxTankLoc,
                                ctx => StyxWoW.Me.IsTank() ? trashToNadoxWaitLoc : trashToNadoxTankLoc,
                                10))));
        }

        #endregion


        [EncounterHandler(29309, "Elder Nadox")]
        public Composite ElderNadoxEncounter()
        {
            return new PrioritySelector(
                );
        }

        #region Prince Taldaram

        private WaitTimer _princeTaldaramCombatTimer = new WaitTimer(TimeSpan.FromSeconds(6));

        [EncounterHandler(29308, "Prince Taldaram", Mode = CallBehaviorMode.CurrentBoss)]
        public Composite PrinceTaldaramPreEncounter()
        {
            WoWUnit boss = null;
            WoWGameObject device = null;

            return new PrioritySelector(
                ctx =>
                {
                    device =
                        ObjectManager.GetObjectsOfType<WoWGameObject>()
                            .Where(o => (o.Entry == 193093 || o.Entry == 193094) && o.State == WoWGameObjectState.Ready)
                            .OrderBy(o => o.DistanceSqr)
                            .FirstOrDefault
                            ();
                    return boss = ctx as WoWUnit;
                },
                // handle vanish
                new Decorator(ctx => !_princeTaldaramCombatTimer.IsFinished && boss == null && StyxWoW.Me.IsTank(), new ActionAlwaysSucceed()),
                new Decorator(
                    ctx => device != null,
                    new PrioritySelector(
                        new Decorator(
                            ctx => device.DistanceSqr > 5 * 5,
                            new Action(ctx => ScriptHelpers.SetLeaderMoveToPoiPS(device.Location))),
                        new Decorator(
                            ctx => device.DistanceSqr <= 5 * 5 && !StyxWoW.Me.Combat,
                            ScriptHelpers.CreateInteractWithObject(ctx => device))
                        ))
                );
        }

        [EncounterHandler(29308, "Prince Taldaram")]
        public Composite PrinceTaldaramEncounter()
        {
            WoWUnit boss = null;

            return new PrioritySelector(
                ctx => boss = ctx as WoWUnit,
                new Action(
                    ctx =>
                    {
                        _princeTaldaramCombatTimer.Reset();
                        return RunStatus.Failure;
                    }));
        }

        #endregion

        private const uint JedogaShadowseekerId = 29310;

        [EncounterHandler(29310, "Jedoga Shadowseeker", Mode = CallBehaviorMode.Proximity)]
        public Composite JedogaShadowseekerEncounter()
        {
            var thunderStruckIds = new uint[] { 56926, 60029 };
            AddAvoidObject(() => !Me.IsCasting, 5, thunderStruckIds);

            WoWUnit boss = null;
            return new PrioritySelector(
                ctx => boss = ctx as WoWUnit,
                ScriptHelpers.CreateClearArea(() => boss.Location, 30, u => u != boss)
                );
        }



        [EncounterHandler(29311, "Herald Volazj", Mode = CallBehaviorMode.Proximity, BossRange = 100)]
        public Composite HeraldVolazjEncounter()
        {
            WoWUnit boss = null;
            var trashLoc = new Vector3(539.0362f, -521.6564f, 26.35604f);

            return new PrioritySelector(
                ctx => boss = ctx as WoWUnit,
                ScriptHelpers.CreateClearArea(() => trashLoc, 100, u => u != boss)
                );
        }
    }
}