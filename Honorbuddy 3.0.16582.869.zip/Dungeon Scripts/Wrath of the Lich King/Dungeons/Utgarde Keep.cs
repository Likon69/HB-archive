
using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Threading.Tasks;
using Bots.DungeonBuddy.Profiles.Handlers;
using Styx;
using Styx.Common.Helpers;
using Styx.CommonBot;
using Styx.Helpers;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using Bots.DungeonBuddy.Attributes;
using Bots.DungeonBuddy.Helpers;
using Styx.Common;
using Styx.Pathing;

namespace Bots.DungeonBuddy.Dungeon_Scripts.Wrath_of_the_Lich_King
{
    public class UtgardeKeep : Dungeon
    {
        #region Overrides of Dungeon

        public override uint DungeonId { get { return 202; } }

        public override Vector3 Entrance { get { return new Vector3(1235.027f, -4860.007f, 41.24839f); } }

        public override Vector3 ExitLocation { get { return new Vector3(144.4507f, -88.97738f, 12.55168f); } }

        private readonly Vector3 _ignoreDragonflayerPackLoc = new Vector3(331.5634f, 0.776747f, 22.7549f);

        public override void RemoveTargetsFilter(List<WoWObject> units)
        {
            units.RemoveAll(
                ret =>
                {
                    // fix for HB trying to run through a flaming wall of fire to get to this pack
                    if ((ret.Entry == 24078 || ret.Entry == 24079 || ret.Entry == 24080) && !ret.ToUnit().Combat && ret.Location.DistanceSquared(_ignoreDragonflayerPackLoc) <= 20 * 20)
                        return true;
                    return false;
                });
        }

        public override void IncludeTargetsFilter(List<WoWObject> incomingunits, HashSet<WoWObject> outgoingunits)
        {
            foreach (var obj in incomingunits)
            {
                var unit = obj as WoWUnit;
                if (unit != null)
                {
                    if (unit.Entry == FrostTombId) // Frost Tomb
                        outgoingunits.Add(unit);
                }
            }
        }

        public override void WeighTargetsFilter(List<Targeting.TargetPriority> units)
        {
            foreach (var priority in units)
            {
                var unit = priority.Object as WoWUnit;
                if (unit != null)
                {
                    if (unit.Entry == FrostTombId && Me.IsDps)
                        priority.Score += 1000;

                    if ((unit.Entry == KarvaldTheConstructorGhostId || unit.Entry == DalronnTheControllerId) && Me.IsDps)
                        priority.Score -= 500;

                    if (unit.Entry == DrakeId && (!Me.IsTank() || !Me.GroupInfo.IsInParty))
                        priority.Score += 1000;
                }
            }
        }

        public override void IncludeLootTargetsFilter(List<WoWObject> incomingunits, HashSet<WoWObject> outgoingunits)
        {
            var armamentQuestId = Me.IsAlliance ? DisarmamentAllianceQuestId : DisarmamentHordeQuestId;
            if (!ScriptHelpers.HasQuest(armamentQuestId) || ScriptHelpers.IsQuestInLogComplete(armamentQuestId))
                return;

            foreach (var obj in incomingunits)
            {
                var gObj = obj as WoWGameObject;
                if (gObj != null)
                {
                    // weapon racks for the quest 'Disarmament'
                    if (gObj.Entry == VrykulWeaponsId
                        && gObj.DistanceSqr < 30 * 30
                        && !gObj.InUse && gObj.CanUse()
                        && !ScriptHelpers.WillPullAggroAtLocation(gObj.Location))
                    {
                        PathInformation pathInf = Navigator.LookupPathInfo(gObj, gObj.InteractRange);
                        if (pathInf.Navigability != PathNavigability.Navigable ||
                            pathInf.Distance >= 30)
                            continue;
                        outgoingunits.Add(gObj);
                    }
                }
            }
        }

        public override void OnEnter()
        {
            BossManager.OnBossKill += BossManager_OnBossKill;
        }

        public override void OnExit()
        {
            BossManager.OnBossKill -= BossManager_OnBossKill;
        }

        #endregion

        #region Quest

        private static readonly uint[] s_entranceQuestIds =
        {
			// Alliance
			29764, // Disarmament
			29803, // Ears of the Lich King
			29763, // Stealing Their Thunder
			// Horde
			30112, // A Score to Settle
			13206, // Disarmament
			11262, // Ingvar Must Die!
		};

        private const uint DisarmamentHordeQuestId = 30112;
        private const uint DisarmamentAllianceQuestId = 29764;

        private const uint VrykulWeaponsId = 193059;

        [EncounterHandler(24137, "Dark Ranger Marrah", Mode = CallBehaviorMode.Proximity, BossRange = 30)]
        [EncounterHandler(24111, "Defender Mordun", Mode = CallBehaviorMode.Proximity, BossRange = 30)]
        public async Task<bool> QuestPickupTurninHandler(WoWUnit npc)
        {
            if (Me.Combat || npc.ZDiff > 15 || ScriptHelpers.WillPullAggroAtLocation(npc.Location))
                return false;
            // pickup or turnin quests if any are available.
            return npc.HasQuestAvailable(true)
                ? await ScriptHelpers.PickupQuest(npc)
                : npc.HasQuestTurnin() && await ScriptHelpers.TurninQuest(npc);
        }



        #endregion

        #region Root

        private const uint KarvaldTheConstructorGhostId = 27389;
        private const uint DalronnTheControllerId = 27390;
        private const uint DrakeId = 24083;
        private const uint FrostTombId = 23965;
        private const uint GameObjectId_ThirdForgeFire = 186691;
        private TimeCachedValue<bool> _applyShortcutDoorBlackspot;
        private readonly Vector3 _shortcutLoc = new Vector3(324.4288f, -10.87024f, 24.67791f);
        private LocalPlayer Me
        {
            get { return StyxWoW.Me; }
        }


        private readonly WaitTimer _waitForBossToRespawn = new WaitTimer(TimeSpan.FromSeconds(20));
        public override bool IsComplete
        {
            get
            {
                return !ScriptHelpers.IsBossAlive("Ingvar the Plunderer") && _waitForBossToRespawn.IsFinished && !Me.Combat;
            }
        }

        private void BossManager_OnBossKill(Boss boss)
        {
            if (boss.Entry == IngvarThePlundererId)
            {
                _waitForBossToRespawn.Reset();
                Logger.Write("We killed Ingvar once, lets do it again.");
            }
        }

        // ToDo DynamicBlackspot: Use an avoid polygon for this
        private static bool ShouldApplyBlackspotAtDoorByShortcut()
        {
            var door = ObjectManager.GetObjectsOfType<WoWGameObject>()
                .FirstOrDefault(g => g.Entry == GameObjectId_ThirdForgeFire);
            return door != null && ((WoWDoor)door.SubObj).IsClosed;
        }

        #endregion

        #region Ingvar the Plunderer

        private const uint IngvarThePlundererId = 23954;
        // Note: WoWObject.Entry is cached so be aware.
        private const uint IngvarThePlundererUndeadId = 23980;
        private const uint DarkSmashSpellId = 42723;
        private const uint IngvarThrowTargetId = 23996;

        private class PillarInfo
        {
            public PillarInfo(Vector3 location, float radius)
            {
                Location = location;
                Radius = radius;
            }
            internal Vector3 Location { get; private set; }
            internal float Radius { get; private set; }
        }

        private static readonly PillarInfo[] s_ingvarPillars =
        {
            new PillarInfo(new Vector3(245.0084f, -314.9051f, 180.4893f), 3.104043f ),
            new PillarInfo(new Vector3(225.6272f, -325.0349f, 180.4895f), 3.120694f ),
            new PillarInfo(new Vector3(213.4978f, -316.1436f, 180.4903f), 4.318369f ),
            new PillarInfo(new Vector3(244.8809f, -300.0176f, 180.4905f), 4.271772f )
        };

        [LocationHandler(228.7146, -306.7076, 180.4915, 60, "Ingvar the Plunderer Area")]
        public Func<Vector3, Task<bool>> IngvarThePlundererAreaHandler()
        {
            AddAvoidObject(() => true, 8, IngvarThrowTargetId);
            WoWUnit boss = null;
            var losTimer = new WaitTimer(TimeSpan.FromSeconds(6));
            Func<bool> losCondition = () =>
            {
                if (!ScriptHelpers.IsViable(boss))
                    return false;
                if (boss.HasAura("Ingvar Feign Death") || boss.HasAura("Scourge Resurrection"))
                {
                    losTimer.Reset();
                    return true;
                }
                return !losTimer.IsFinished;
            };

            // followers shouldn't stand in front of boss because of his cleave
            AddAvoidUnitCone(() => !Me.IsTank(), 0, 8, 150, u => u.Entry == IngvarThePlundererId && !u.IsMoving && u.Combat && u.CurrentTarget != Me && u.Combat);

            return async loc =>
            {
                boss = ObjectManager.GetObjectsOfType<WoWUnit>()
                   .FirstOrDefault(u => u.Entry == IngvarThePlundererId
                       || u.Entry == IngvarThePlundererUndeadId);

                if (boss == null)
                    return false;
                var myLoc = Me.Location;
                // LOS Dreadful Roar ability
                if (losCondition())
                {
                    var nearestPillar = s_ingvarPillars.OrderBy(p => p.Location.DistanceSquared(myLoc)).First();
                    if (await ScriptHelpers.MoveOutOfLos(
                            losCondition,
                            boss.Location,
                            nearestPillar.Location,
                            nearestPillar.Radius))
                    {
                        return true;
                    }
                    // return false if healer to allow CR to use abilities while movement is disabled.
                    // Movement should be disabled by the ScriptHelpers.LosLocation coroutine
                    // when its not moving.
                    return !Me.IsHealer;
                }

                // tank should face boss away from group to because of cleave
                if (await ScriptHelpers.TankFaceUnitAwayFromGroup(8))
                    return true;

                // port to entrance if we have quest to turnin
                return IsComplete && !Me.Combat
                    && s_entranceQuestIds.Any(ScriptHelpers.IsQuestInLogComplete)
                    && LootTargeting.Instance.IsEmpty()
                    && await ScriptHelpers.PortOutsideAndBackIn();
            };
        }

        #endregion
    }
}