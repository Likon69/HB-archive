﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Threading.Tasks;
using Bots.DungeonBuddy.Enums;
using Bots.DungeonBuddy.Profiles.Handlers;
using Buddy.Coroutines;
using CommonBehaviors.Actions;
using Styx;
using Styx.CommonBot;
using Styx.CommonBot.Frames;
using Styx.Pathing;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using Styx.TreeSharp;
using Action = Styx.TreeSharp.Action;

using Bots.DungeonBuddy.Attributes;
using Bots.DungeonBuddy.Helpers;
using Styx.Common;

namespace Bots.DungeonBuddy.Dungeon_Scripts.Burning_Crusade
{
    public class HellfireRamparts : Dungeon
    {
        #region Overrides of Dungeon

        /// <summary>
        ///   The mapid of this dungeon.
        /// </summary>
        /// <value> The map identifier. </value>
        public override uint DungeonId
        {
            get { return 136; }
        }

        public override Vector3 Entrance
        {
            get { return new Vector3(-365.0169f, 3093.254f, -14.35639f); }
        }

        public override Vector3 ExitLocation
        {
            get { return new Vector3(-1361.804f, 1629.332f, 68.38041f); }
        }

        public override void RemoveTargetsFilter(List<WoWObject> units)
        {
            // remove Nazan from targeting if he is flying and bot is a melee.
            units.RemoveAll(u => u.Entry == NazanId && Me.IsMelee() && u.Z > 90);
        }

        public override void WeighTargetsFilter(List<Targeting.TargetPriority> units)
        {
            foreach (var p in units)
            {
                var unit = p.Object as WoWUnit;
                if (unit == null) continue;
                if ((unit.Entry == FiendishHoundId || unit.Entry == HellfireWatcherId) && Me.IsDps)
                {
                    p.Score += 1000;
                }
            }
        }

        public override void IncludeLootTargetsFilter(List<WoWObject> incomingunits, HashSet<WoWObject> outgoingunits)
        {
            foreach (var obj in incomingunits)
            {
                var gObj = obj as WoWGameObject;
                if (gObj != null)
                {
                    // chest at last (optional) boss.
                    if (gObj.Entry == ReinforcedFelIronChestId
                        && DungeonBuddySettings.Instance.LootMode != LootMode.Off
                        && gObj.CanUse())
                    {
                        outgoingunits.Add(gObj);
                    }

                    // loot crates for the quest 'Hitting Them Where It Hurts'
                    if (_hellfireSuppliesIds.Contains(gObj.Entry)
                        && !ScriptHelpers.WillPullAggroAtLocation(gObj.Location)
                        && gObj.DistanceSqr < 30 * 30
                        && !gObj.InUse && gObj.CanUse())
                    {
                        PathInformation path = Navigator.LookupPathInfo(gObj, gObj.InteractRange);
                        if (path.Navigability != PathNavigability.Navigable || path.Distance >= 30f)
                            continue;
                        outgoingunits.Add(gObj);
                    }
                    continue;
                }
                var unit = obj as WoWUnit;
                if (unit != null)
                {
                    // make sure quest object gets looted regardless of loot settings.
                    if (unit.Entry == OmorTheUnscarredId && unit.IsDead && unit.CanLoot
                        && unit.DistanceSqr < 50 * 50
                        && s_demonsInTheCitadelQuestIds.Any(id => ScriptHelpers.HasQuest(id) && !ScriptHelpers.IsQuestInLogComplete(id)))
                    {
                        outgoingunits.Add(unit);
                    }

                    if ((unit.Entry == VazrudenTheHeraldId || unit.Entry == VazrudenTheHeraldId)
                        && unit.IsDead && unit.CanLoot && unit.DistanceSqr < 50 * 50
                        && s_warOnTheRampartsQuestIds.Any(id => ScriptHelpers.HasQuest(id) && !ScriptHelpers.IsQuestInLogComplete(id)))
                    {
                        outgoingunits.Add(unit);
                    }
                }
            }
        }

        #endregion

        #region Root

        private const uint FiendishHoundId = 17540;
        private const uint HellfireWatcherId = 17309;

        private LocalPlayer Me
        {
            get { return StyxWoW.Me; }
        }

        [EncounterHandler(0, "Root")]
        public async Task<bool> RootLogic(WoWUnit supplies)
        {
            // port outside and back in to hand in quests once dungeon is complete.
            // QuestPickupTurninHandler will handle the turnin
            return IsComplete && !Me.Combat
                    && s_questsAtEntrance.Any(ScriptHelpers.IsQuestInLogComplete)
                    && LootTargeting.Instance.IsEmpty()
                    && Me.Location.DistanceSquared(_lastBossLocation) < 50 * 50
                    && await ScriptHelpers.PortOutsideAndBackIn();
        }

        [EncounterHandler(54606, "Stone Guard Stok'ton", Mode = CallBehaviorMode.Proximity, BossRange = 30)]
        [EncounterHandler(54603, "Advance Scout Chadwick", Mode = CallBehaviorMode.Proximity, BossRange = 30)]
        public async Task<bool> QuestPickupTurninHandler(WoWUnit npc)
        {
            if (Me.Combat || ScriptHelpers.WillPullAggroAtLocation(npc.Location) || npc.ZDiff > 10)
                return false;
            // pickup or turnin quests if any are available.
            return npc.HasQuestAvailable(true)
                ? await ScriptHelpers.PickupQuest(npc)
                : npc.HasQuestTurnin() && await ScriptHelpers.TurninQuest(npc);
        }

        private static readonly uint[] s_hittingThemWhereItHurtsQuestIds = { 29593, 29594 };
        private static readonly uint[] s_demonsInTheCitadelQuestIds = { 29529, 29530 };
        private static readonly uint[] s_warOnTheRampartsQuestIds = { 29527, 29528 };

        private static readonly List<uint> s_questsAtEntrance =
            new List<uint>(
                s_hittingThemWhereItHurtsQuestIds
                    .Concat(s_demonsInTheCitadelQuestIds)
                    .Concat(s_warOnTheRampartsQuestIds));


        private readonly uint[] _hellfireSuppliesIds = { 209347, 209348 };

        #endregion


        #region Nazan

        private const uint NazanId = 17536;
        private const uint VazrudenTheHeraldId = 17307;

        private readonly Vector3 _lastBossLocation = new Vector3(-1405.533f, 1735.979f, 81.2851f);

        [EncounterHandler(17536, "Nazan")]
        public Func<WoWUnit, Task<bool>> NazanEncounter()
        {
            const uint liquidFireId = 181890;

            AddAvoidObject(() => !Me.IsCasting, 3f, liquidFireId);

            // avoid standing in front of dragon because of flame breath if not tanking
            AddAvoidUnitCone(() => !Me.IsTank, 0, 30, 180, u => u.Entry == NazanId && u.Combat);

            return async npc =>
            {
                // face dragon away from group to get them hit by flame breath.
                if (await ScriptHelpers.TankFaceUnitAwayFromGroup(15))
                    return true;

                return false;
            };
        }

        private const uint ReinforcedFelIronChestId = 185168;

        #endregion

        #region Omor the Unscarred

        private const uint OmorTheUnscarredId = 17536;

        [EncounterHandler(17536, "Omor the Unscarred")]
        public Func<WoWUnit, Task<bool>> OmorTheUnscarredEncounter()
        {
            AddAvoidObject(() => !Me.IsTank() && Me.HasAura("Bane of Treachery"), 15, o => o is WoWPlayer && !o.IsMe);
            return async boss => false;
        }

        #endregion

        #region Watchkeeper Gargolmar

        private const uint WatchkeeperGargolmarId = 17306;

        [EncounterHandler(17306, "Watchkeeper Gargolmar")]
        public async Task<bool> WatchkeeperGargolmarEncounter(WoWUnit boss)
        {
            return await ScriptHelpers.DispelEnemy("Renew", ScriptHelpers.EnemyDispelType.Magic, boss);
        }

        [EncounterHandler(17309, "Hellfire Watcher")]
        public Func<WoWUnit, Task<bool>> HellfireWatcherEncounter()
        {
            var healIds = new[] { 12039, 30643 };

            return async npc => await ScriptHelpers.DispelEnemy("Renew", ScriptHelpers.EnemyDispelType.Magic, npc)
                             || await ScriptHelpers.InterruptCast(npc, healIds);
        }

        #endregion
    }
}