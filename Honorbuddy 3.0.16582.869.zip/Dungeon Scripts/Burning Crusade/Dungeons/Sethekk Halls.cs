using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using Styx;
using Styx.CommonBot;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using Styx.TreeSharp;
using Bots.DungeonBuddy.Attributes;
using Bots.DungeonBuddy.Helpers;
using Styx.Common;

namespace Bots.DungeonBuddy.Dungeon_Scripts.Burning_Crusade
{
    public class SethekkHalls : Dungeon
    {
        #region Overrides of Dungeon

        private bool _shortcutBlocked;

        public override uint DungeonId
        {
            get { return 150; }
        }

        public override Vector3 Entrance
        {
            get
            {
                if (_shortcutBlocked) _shortcutBlocked = false;
                return new Vector3(-3361.518f, 4655.588f, -101.0466f);
            }
        }

        public override Vector3 ExitLocation
        {
            get { return new Vector3(-9.0f, -0.7f, .001f); }
        }

        public override void IncludeTargetsFilter(List<WoWObject> incomingunits, HashSet<WoWObject> outgoingunits)
        {
            foreach (var unit in incomingunits)
            {
                if (unit.Entry == CharmingTotemId) //  Charming Totem
                    outgoingunits.Add(unit);
            }
        }

        public override void WeighTargetsFilter(List<Targeting.TargetPriority> units)
        {
            foreach (var priority in units)
            {
                var unit = priority.Object as WoWUnit;
                if (unit != null)
                {
                    if (unit.Entry == CharmingTotemId) //  Charming Totem
                        priority.Score += 400;

                    if (unit.Entry == TimeLostControllersId && StyxWoW.Me.IsDps)
                        priority.Score += 210;

                    if (unit.Entry == SethekkProphetId && StyxWoW.Me.IsDps)
                        priority.Score += 200;

                    if (unit.Entry == TimeLostScryerId && StyxWoW.Me.IsDps)
                        priority.Score += 190;
                }
            }
        }

        public override void RemoveTargetsFilter(List<WoWObject> units)
        {
            units.RemoveAll(unit => unit is WoWPlayer);
        }

        #endregion

        #region Root

        private const uint CharmingTotemId = 20343;
        private const uint TimeLostControllersId = 18327;
        private const uint SethekkProphetId = 18325;
        private const uint TimeLostScryerId = 18319;
        private const uint SethekkSpiritId = 18703;
        private const uint BrotherAgainstBrotherQuestId = 29605;

        private WoWUnit _ikiss;
        private WoWUnit _syth;

        private static LocalPlayer Me => StyxWoW.Me;

        [EncounterHandler(54840, "Isfar", Mode = CallBehaviorMode.Proximity, BossRange = 30)]
        [EncounterHandler(54847, "Dealer Vijaad", Mode = CallBehaviorMode.Proximity, BossRange = 30)]
        public Composite WatcherJhangQuestHandler()
        {
            WoWUnit unit = null;
            return new PrioritySelector(
                ctx => unit = ctx as WoWUnit,
                new Decorator(
                    ctx => !Me.Combat && !ScriptHelpers.WillPullAggroAtLocation(unit.Location),
                    new PrioritySelector(
                        new Decorator(
                            ctx => unit.HasQuestAvailable(true),
                            ScriptHelpers.CreatePickupQuest(ctx => unit)),
                        new Decorator(
                            ctx => unit.HasQuestTurnin(),
                            ScriptHelpers.CreateTurninQuest(ctx => unit))))
                );
        }

        [EncounterHandler(0, "Root")]
        public Composite RootHandler()
        {
            AddAvoidObject(() => !Me.IsCasting, obj => Me.IsRange() && Me.IsMoving ? 8 : 6, SethekkSpiritId);

            return new PrioritySelector();
        }

        [EncounterHandler(18956, "Lakka", Mode = CallBehaviorMode.Proximity, BossRange = 30)]
        public Composite LakkaEncounter()
        {
            return new Decorator<WoWUnit>(unit =>
                            ScriptHelpers.HasQuest(BrotherAgainstBrotherQuestId)
                            && !ScriptHelpers.IsQuestInLogComplete(BrotherAgainstBrotherQuestId)
                            && !Me.Combat
                            && !ScriptHelpers.WillPullAggroAtLocation(unit.Location),
                        // talk to Lakka
                        ScriptHelpers.CreateTalkToNpc(ctx => ctx as WoWUnit));
        }

#warning FIXME
        // #TODO DynamicBlackspot: The shortcut from last boss to entrance needs to be handled by the dungeon script's HandleMovement overide.
        private const uint ShortcutGateId = 183398;
        private readonly Vector3 _shortcutBlackspotLoc = new Vector3(44.46614f, 185.8761f, -10);

        private bool IsShortcutGateOpen
        {
            get
            {
                return ObjectManager.GetObjectsOfType<WoWGameObject>().Any(g => g.Entry == ShortcutGateId && ((WoWDoor)g.SubObj).IsOpen);
            }
        }

        #endregion

        #region Darkweaver Syth

        [EncounterHandler(18472, "Darkweaver Syth")]
        public Composite DarkweaverSythEncounter()
        {
            return new PrioritySelector(
                ctx => _syth = ctx as WoWUnit,
                ScriptHelpers.CreateSpreadOutLogic(ctx => true, ctx => _syth.Location, 15, 30));
        }

        #endregion


        #region Talon King Ikiss

        [EncounterHandler(18473, "Talon King Ikiss")]
        public Composite TalonKingIkissEncounter()
        {
            var pilarLocations = new List<Vector3>
                                {
                                    new Vector3(22.67584f, 309.4335f, 26.59805f),
                                    new Vector3(67.06754f, 308.9184f, 26.62627f),
                                    new Vector3(67.86166f, 262.8065f, 26.36894f),
                                    new Vector3(22.76415f, 264.541f, 26.66963f)
                                };

            return new PrioritySelector(
                ctx => _ikiss = ctx as WoWUnit,
                ScriptHelpers.CreateLosLocation(
                    ctx => _ikiss.CastingSpellId == 38197 || _ikiss.CastingSpellId == 40425,
                    ctx => _ikiss.Location,
                    ctx => pilarLocations.OrderBy(loc => StyxWoW.Me.Location.DistanceSquared(loc)).FirstOrDefault(),
                    ctx => 10));
        }

        #endregion
    }
}