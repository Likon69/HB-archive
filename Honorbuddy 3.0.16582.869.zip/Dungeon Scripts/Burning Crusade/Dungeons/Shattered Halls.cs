using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using Styx;
using Styx.CommonBot;
using Styx.Pathing;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using Styx.TreeSharp;
using Bots.DungeonBuddy.Attributes;
using Bots.DungeonBuddy.Helpers;
using Styx.Common;

namespace Bots.DungeonBuddy.Dungeon_Scripts.Burning_Crusade
{
    public class ShatteredHalls : Dungeon
    {
        #region Overrides of Dungeon

        public override uint DungeonId
        {
            get { return 138; }
        }

        public override Vector3 Entrance
        {
            get { return new Vector3(-310.2105f, 3087.014f, -3.916756f); }
        }

        public override Vector3 ExitLocation
        {
            get { return new Vector3(-42.05605f, -26.77249f, -13.51534f); }
        }

        public override void RemoveTargetsFilter(List<WoWObject> units)
        {
            units.RemoveAll(
                u =>
                { // remove low level units.
                    var unit = u as WoWUnit;
                    if (unit != null)
                    {
                        if (unit is WoWPlayer)
                            return true;

                        if ((unit.Entry == 17356 || unit.Entry == 17357) && !unit.Combat) // Creeping Ozzling
                            return true;

                        if (StyxWoW.Me.IsTank() && ScriptHelpers.IsBossAlive("Warchief Kargath Bladefist") &&
                            (unit.Entry == 17621 || unit.Entry == 17623 || unit.Entry == 17622))
                            // Heathen Guard, Reaver Guard, Sharpshooter Guard
                            return true;
                    }
                    return false;
                });
        }

        public override void WeighTargetsFilter(List<Targeting.TargetPriority> units)
        {
            foreach (var priority in units)
            {
                var unit = priority.Object as WoWUnit;
                if (unit != null)
                {
                    if (StyxWoW.Me.IsDps)
                    {
                        if (unit.Entry == 17621 || unit.Entry == 17623 || unit.Entry == 17622) // Heathen Guard, Reaver Guard, Sharpshooter Guard
                            priority.Score += 400;
                    }
                }
            }
        }

        #endregion

        private WoWUnit _warchiefKargathBladefist;

        private LocalPlayer Me
        {
            get { return StyxWoW.Me; }
        }

        [EncounterHandler(0, "Root")]
        public Composite RootBehavior()
        {
            const uint blazeId = 181915;
            AddAvoidObject(() => !Me.IsCasting, 5, blazeId);

            return new PrioritySelector();
        }

        [EncounterHandler(16808, "Warchief Kargath Bladefist")]
        public Composite WarchiefKargathBladefistEncounter()
        {
            var platformCenterLocation = new Vector3(231.25f, -83.64489f, 4.940088f);
            return new PrioritySelector(
                ctx => _warchiefKargathBladefist = ctx as WoWUnit,
                ScriptHelpers.CreateSpreadOutLogic(ctx => Targeting.Instance.FirstUnit == _warchiefKargathBladefist, ctx => platformCenterLocation, 15, 25),
                ScriptHelpers.CreateTankUnitAtLocation(ctx => platformCenterLocation, 5));
        }

        #region Grand Warlock Nethekurse

        private const uint GrandWarlockNethekurseId = 16807;

        [EncounterHandler(17356, "Creeping Ozze")]
        [EncounterHandler(17357, "Creeping Ozzling")]
        public Composite CreepingOzzlingEncounter()
        {
            var tankLoc = new Vector3(180.5946f, 227.8267f, -18.55346f);
            return
                new PrioritySelector(
                    new Decorator(
                        ctx =>
                        StyxWoW.Me.IsTank() && Me.PartyMembers.All(p => p.HealthPercent > 50) && !StyxWoW.Me.IsActuallyInCombat &&
                        StyxWoW.Me.Location.DistanceSquared(tankLoc) > 5,
                        new Action(ctx => Navigator.MoveTo(tankLoc))));
        }

        [ObjectHandler(182539, "Grand Warlock Chamber Door")]
        public Composite GrandWarlockChamberDoorHandler()
        {
            var roomBeforeFirstBossLoc = new Vector3(123.3501f, 264.7724f, -13.23036f);
            var dropDownLoc = new Vector3(121.9095f, 236.8019f, -46.10165f);
            var topOfJumpLoc = new Vector3(123.0873f, 250.3539f, -15.3936f);
            return
                new PrioritySelector(
                    new Decorator(
                        ctx =>
                        ((WoWGameObject)ctx).State == WoWGameObjectState.Ready && !StyxWoW.Me.Combat && StyxWoW.Me.Location.DistanceSquared(roomBeforeFirstBossLoc) <= 20 * 20 &&
                        StyxWoW.Me.Z > -25,
                        new PrioritySelector(
                            new Decorator(
                                ctx => StyxWoW.Me.IsTank() || (StyxWoW.Me.IsFollower() && ScriptHelpers.Tank != null && ScriptHelpers.Tank.Z < -25),
                                new PrioritySelector(
                                    new Decorator(ctx => StyxWoW.Me.Location.DistanceSquared(topOfJumpLoc) > 4 * 4, new Action(ctx => Navigator.MoveTo(topOfJumpLoc))),
                                    new Action(ctx => WoWMovement.ClickToMove(dropDownLoc)))))));
        }

        private const uint MobId_GrandWarlockNethekurse = 16807;

        [EncounterHandler(16807, "Grand Warlock Nethekurse")]
        public Composite GrandWarlockNethekurseEncounter()
        {
            WoWUnit boss = null;
            const uint lesserShadowFissureId = 17471;
            AddAvoidObject(() => !Me.IsCasting, 8, lesserShadowFissureId);
            AddAvoidUnitCone(() => !Me.IsTank(), 0, 8, 180, u => u.Entry == MobId_GrandWarlockNethekurse && !u.IsMoving && u.CurrentTarget != Me && u.Combat);

            return new PrioritySelector(
                ctx => boss = ctx as WoWUnit,
                ScriptHelpers.CreateTankFaceAwayGroupUnit(8));
        }

        #endregion
    }
}