﻿

using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Runtime.InteropServices;
using CommonBehaviors.Actions;
using Styx;
using Styx.Common;
using Styx.Common.Helpers;
using Styx.CommonBot;
using Styx.CommonBot.Coroutines;
using Styx.CommonBot.Frames;
using Styx.CommonBot.POI;
using Styx.CommonBot.Routines;
using Styx.Helpers;
using Styx.Patchables;
using Styx.Pathing;
using Styx.TreeSharp;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using Action = Styx.TreeSharp.Action;

using Bots.DungeonBuddy.Profiles;
using Bots.DungeonBuddy.Attributes;
using Bots.DungeonBuddy.Helpers;


namespace Bots.DungeonBuddy.Dungeon_Scripts.Mists_of_Pandaria
{
    public class GreenstoneVillage : Dungeon
    {
        #region Overrides of Dungeon

        public override uint DungeonId
        {
            get { return 492; }
        }

        public override void OnEnter() { }

        public override void RemoveTargetsFilter(List<WoWObject> units)
        {
            units.RemoveAll(
                ret =>
                {
                    var unit = ret.ToUnit();
                    if (unit != null) { }
                    return false;
                });
        }

        public override void IncludeTargetsFilter(List<WoWObject> incomingunits, HashSet<WoWObject> outgoingunits)
        {
            foreach (var obj in incomingunits)
            {
                var unit = obj as WoWUnit;
                if (unit != null) { }
            }
        }

        public override void WeighTargetsFilter(List<Targeting.TargetPriority> units)
        {
            foreach (var priority in units)
            {
                var unit = priority.Object as WoWUnit;
                if (unit != null) { }
            }
        }

        #endregion

        private readonly CircularQueue<Vector3> _stageThreeBarrelPickupPath = new CircularQueue<Vector3>
        {
            new Vector3(1999.786f, -1809.391f, 196.2217f),
            new Vector3(2103.951f, -1891.53f, 215.4706f),
            new Vector3(2108.24f, -2015.222f, 223.0112f),
            new Vector3(1879.935f, -2026.1f, 211.0177f)
        };

        private static LocalPlayer Me
        {
            get { return StyxWoW.Me; }
        }

        [EncounterHandler(0)]
        public Composite RootEncounter()
        {
            return new PrioritySelector();
        }

        [ScenarioStage(1, "Rescue the Villages")]
        public Composite CreateStageOneBehavior()
        {
            ScenarioStage stage = null;
            var laAndLiupoLoc = new Vector3(1956.958f, -1974.793f, 210.9048f);
            var portlyShungLoc = new Vector3(1948.438f, -1946.309f, 207.2751f);
            var mayorLinLoc = new Vector3(1985.447f, -1918.776f, 203.9203f);
            var swanLoc = new Vector3(2023.34f, -1913.529f, 207.2751f);
            var scribeRinjiLoc = new Vector3(2015.751f, -1882.88f, 207.6642f);
            var meilaLoc = new Vector3(2050.594f, -1975.653f, 215.5079f);

            return new Decorator(
                ctx => Targeting.Instance.IsEmpty(),
                new PrioritySelector(
					ctx => stage = ScenarioInfo.Current.CurrentStage,
					new Decorator(ctx => !stage.GetCriteria(1).IsComplete && BotPoi.Current.Type == PoiType.None, new Action(ctx => ScriptHelpers.SetLeaderMoveToPoiPS(laAndLiupoLoc))),
					new Decorator(ctx => !stage.GetCriteria(4).IsComplete && BotPoi.Current.Type == PoiType.None, new Action(ctx => ScriptHelpers.SetLeaderMoveToPoiPS(portlyShungLoc))),
					new Decorator(ctx => !stage.GetCriteria(2).IsComplete && BotPoi.Current.Type == PoiType.None, new Action(ctx => ScriptHelpers.SetLeaderMoveToPoiPS(mayorLinLoc))),
					new Decorator(ctx => !stage.GetCriteria(6).IsComplete && BotPoi.Current.Type == PoiType.None, new Action(ctx => ScriptHelpers.SetLeaderMoveToPoiPS(swanLoc))),
					new Decorator(ctx => !stage.GetCriteria(5).IsComplete && BotPoi.Current.Type == PoiType.None, new Action(ctx => ScriptHelpers.SetLeaderMoveToPoiPS(scribeRinjiLoc))),
					new Decorator(ctx => !stage.GetCriteria(3).IsComplete && BotPoi.Current.Type == PoiType.None, new Action(ctx => ScriptHelpers.SetLeaderMoveToPoiPS(meilaLoc)))));
        }

        [ScenarioStage(2)]
        public Composite CreateStageTwoBehavior()
        {
            var tzuLoc = new Vector3(1937.594f, -1865.617f, 203.3163f);
            return new Decorator(ctx => Targeting.Instance.IsEmpty(), new Action(ctx => ScriptHelpers.SetLeaderMoveToPoiPS(tzuLoc)));
        }

        [ScenarioStage(3)]
        public Composite CreateStageThreeBehavior()
        {
            WoWUnit barrel = null;
            const uint burgledBarrelId = 62682;
            var barrelTurninLoc = new Vector3(1942.195f, -1870.816f, 203.68f);
            return
                new PrioritySelector(
                    ctx =>
                    barrel = (from obj in ObjectManager.GetObjectsOfType<WoWUnit>()
                              where obj.Entry == burgledBarrelId && Me.RaidMembers.All(r => r.TransportGuid != obj.Guid)
                              let myLoc = Me.Location
                              let objLoc = obj.Location
                              where !Me.PartyMembers.Any(p => !p.IsMe && p.IsSafelyFacing(obj, 45) && p.Location.DistanceSquared((Vector3)objLoc) < myLoc.DistanceSquared((Vector3)objLoc))
#warning FIXME Dungeonbuddy - Greenstone Village: CanNavigateFully to burged barrels
                              // TODO: Dungeonbuddy - Greenstone Village: CanNavigateFully to burged barrels
                              //							  && Navigator.CanNavigateFully(myLoc, objLoc)
                              orderby obj.Distance
                              select obj).FirstOrDefault(),

                    new Decorator(
                        ctx => Me.TransportGuid.IsValid && Me.Transport.Entry == burgledBarrelId,
                        new Action(ctx => Navigator.GetRunStatusFromMoveResult(Navigator.MoveTo(barrelTurninLoc)))),
                    new Decorator(
                        ctx => !Me.TransportGuid.IsValid || Me.Transport.Entry != burgledBarrelId,
                        new PrioritySelector(
                            new Decorator(
                                ctx => barrel != null && Targeting.Instance.IsEmpty(),
                                new PrioritySelector(
                                    new Decorator(ctx => barrel.Distance >= 40, new Action(ctx => ScriptHelpers.SetLeaderMoveToPoiPS(barrel.Location))),
                                    new Decorator(
                                        ctx => barrel.Distance < 40 && !ScriptHelpers.WillPullAggroAtLocation(barrel.Location),
                                        new PrioritySelector(
                                            new Decorator(
                                                ctx => !barrel.WithinInteractRange, new Action(ctx => Navigator.GetRunStatusFromMoveResult(Navigator.MoveTo(barrel.Location)))),
                                            new Decorator(
                                                ctx => barrel.WithinInteractRange,
                                                new PrioritySelector(
                                                    new Decorator(ctx => Me.Shapeshift != ShapeshiftForm.Normal, new AlwaysFailAction<object>(ctx => Lua.DoString("CancelShapeshiftForm()"))),
                                                    new Decorator(ctx => Me.Mounted, new ActionRunCoroutine(ctx => CommonCoroutines.Dismount())),
                                                    new Action(ctx => barrel.Interact()))))))),
                            new Decorator(
                                ctx => barrel == null && Me.IsTank() && Targeting.Instance.IsEmpty(),
                                new PrioritySelector(
                                    new Decorator(
                                        ctx => _stageThreeBarrelPickupPath.Peek().DistanceSquared(Me.Location) < 6 * 6, new Action(ctx => _stageThreeBarrelPickupPath.Dequeue())),
                                    new Action(ctx => Navigator.GetRunStatusFromMoveResult(Navigator.MoveTo(_stageThreeBarrelPickupPath.Peek()))))))));
        }

        [ScenarioStage(4)]
        public Composite CreateStageFourBehavior()
        {
            var stageLoc = new Vector3(2192.587f, -1897.972f, 219.044f);
            const uint kiriJadeEyesId = 62990;
            const uint stonecutterLonId = 62989;
            const uint barrelChestHuoId = 62988;
            WoWUnit rescueTarget = null;

            return new PrioritySelector(
                ctx =>
                {
                    ScenarioStage stage = ScenarioInfo.Current.CurrentStage;
                    rescueTarget = (from unit in ObjectManager.GetObjectsOfType<WoWUnit>()
                                    where
										(unit.Entry == kiriJadeEyesId && !stage.GetCriteria(1).IsComplete || unit.Entry == barrelChestHuoId && !stage.GetCriteria(2).IsComplete ||
										 unit.Entry == stonecutterLonId && !stage.GetCriteria(3).IsComplete) && unit.Distance < 40
                                    orderby unit.DistanceSqr
                                    select unit).FirstOrDefault();
                    return ctx;
                },
                new Decorator(
                    ctx => rescueTarget != null && !Me.Combat && !ScriptHelpers.WillPullAggroAtLocation(rescueTarget.Location),
                    new PrioritySelector(
                        new Decorator(
                            ctx => !rescueTarget.WithinInteractRange, new Action(ctx => Navigator.GetRunStatusFromMoveResult(Navigator.MoveTo(rescueTarget.Location)))),
                        new Decorator(
                            ctx => rescueTarget.WithinInteractRange,
                            new PrioritySelector(
                                new Decorator(ctx => Me.Mounted, new ActionRunCoroutine(ctx => CommonCoroutines.Dismount())),
                                 new Decorator(ctx => Me.Shapeshift != ShapeshiftForm.Normal, new AlwaysFailAction<object>(ctx => Lua.DoString("CancelShapeshiftForm()"))),
                                 new Action(ctx => rescueTarget.Interact()))))),
                new Decorator(
                    ctx => Targeting.Instance.TargetList.Any(u => u.Distance < 10),
                    new Action(
                        ctx =>
                        {
                            Lua.DoString("ExtraActionButton1:Click()");
                            return RunStatus.Failure;
                        })),
                ScriptHelpers.CreateClearArea(() => stageLoc, 70),
                new Decorator(ctx => Me.IsTank() && Me.Location.Distance(stageLoc) > 20 && Targeting.Instance.IsEmpty(), new Action(ctx => ScriptHelpers.SetLeaderMoveToPoiPS(stageLoc))));
        }

        [ScenarioStage(5)]
        public Composite CreateStageFiveBehavior()
        {
            var lastBossLoc = new Vector3(2228.099f, -1883.991f, 223.0198f);
            return new Decorator(
                ctx => Targeting.Instance.IsEmpty(),
                new PrioritySelector(
                    new Decorator(
                        ctx => Me.IsTank() && Me.Location.Distance(lastBossLoc) < 10 && Targeting.Instance.IsEmpty(),
                        new PrioritySelector(new Decorator(ctx => !Me.Combat, RoutineManager.Current.RestBehavior), new ActionAlwaysSucceed())),
                    new Decorator(ctx => Targeting.Instance.IsEmpty(), new Action(ctx => ScriptHelpers.SetLeaderMoveToPoiPS(lastBossLoc)))));
        }

        [EncounterHandler(66772, "Beast of Jade")]
        public Composite BeastofJadeEncounter()
        {
            WoWUnit boss = null;
            const int jadeStatueId = 119364;
            return new PrioritySelector(ctx => boss = ctx as WoWUnit, ScriptHelpers.CreateInterruptCast(ctx => boss, jadeStatueId));
        }

        [EncounterHandler(61156, "Vengeful Hui")]
        public Composite VengefulHuiEncounter()
        {
            WoWUnit unit = null;
            return new PrioritySelector(
                ctx => unit = ctx as WoWUnit,
                new Decorator(
                    ctx => Targeting.Instance.TargetList.Any(u => u.Distance < 10),
                    new Action(
                        ctx =>
                        {
                            Lua.DoString("ExtraActionButton1:Click()");
                            return RunStatus.Failure;
                        })));
        }
    }
}