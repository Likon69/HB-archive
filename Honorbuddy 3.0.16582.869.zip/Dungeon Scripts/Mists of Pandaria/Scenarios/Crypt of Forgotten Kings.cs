﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Threading.Tasks;
using Styx;
using Styx.CommonBot;
using Styx.TreeSharp;
using Styx.WoWInternals.WoWObjects;
using Action = Styx.TreeSharp.Action;

using Bots.DungeonBuddy.Profiles;
using Bots.DungeonBuddy.Attributes;
using Bots.DungeonBuddy.Helpers;
using Styx.Common;


namespace Bots.DungeonBuddy.Dungeon_Scripts.Mists_of_Pandaria
{
    #region Normal Difficulty

    public class CryptOfForgottenKings : Dungeon
    {
        #region Overrides of Dungeon

        public override uint DungeonId
        {
            get { return 504; }
        }

        public override void RemoveTargetsFilter(List<WoWObject> units)
        {
            units.RemoveAll(
                ret =>
                {
                    var unit = ret.ToUnit();
                    if (unit != null)
                    {
                        if (unit.Entry == CryptGuardianFuryId && (unit.CastingSpellId == BladestormId || unit.HasAura(BladestormId)) && Me.IsMelee())
                            return true;
                        if (unit.Entry == AbominationOfAngerId && unit.ChanneledCastingSpellId == DeathforceId && Me.IsMelee())
                            return true;
                    }
                    return false;
                });
        }

        public override void IncludeTargetsFilter(List<WoWObject> incomingunits, HashSet<WoWObject> outgoingunits)
        {
            foreach (var obj in incomingunits)
            {
                var unit = obj as WoWUnit;
                if (unit != null)
                {
                    if (unit.Entry == JinIronfistId && Me.IsTank() && unit.Distance < 40)
                        outgoingunits.Add(unit);

                    // if (unit.Entry == ShadowsofAngerId && unit.Distance <= 40)
                    //      outgoingunits.Add(unit);
                }
            }
        }

        public override void WeighTargetsFilter(List<Targeting.TargetPriority> units)
        {
            foreach (var priority in units)
            {
                var unit = priority.Object as WoWUnit;
                if (unit != null)
                {
                    if (unit.Entry == ShadowsofAngerId)
                        priority.Score += 1000;
                }
            }
        }

        #endregion

        #region Root

        private const uint CryptGuardianFuryId = 61783;
        private const uint AbominationOfAngerId = 61707;
        private const int DeathforceId = 120215;
        private const int BladestormId = 128969;
        private const uint ShadowsofAngerId = 62009;

        private const uint JinIronfistId = 61814;

        private static LocalPlayer Me
        {
            get { return StyxWoW.Me; }
        }

        private readonly Vector3[] _trapBlackspots = { new Vector3(593.493f, 2323.363f, 67.38953f) };

        [EncounterHandler(0)]
        public Func<WoWUnit, Task<bool>> RootEncounter()
        {
            const uint lightningTrapId = 211842;
            const uint fireTrapId = 211841;
            const uint stasisTrapId = 211709;
            const uint statisTrap2Id = 211843;
            const uint activationTrapId = 211995;

            var traps = new[] { fireTrapId, lightningTrapId, stasisTrapId, activationTrapId, statisTrap2Id };

            AddAvoidObject(
                () => true,
                4,
                u =>
                    u is WoWGameObject && traps.Contains(u.Entry) && u.ZDiff < 10 && u.Distance2D < 10 &&
                    !_trapBlackspots.Any(l => l.DistanceSquared(u.Location) < 9));

            return async npc =>
            {
                if (ScenarioInfo.Current.CurrentStageNumber > 1 && ScriptHelpers.IsBossAlive("Jin Ironfist"))
                    ScriptHelpers.MarkBossAsDead("Jin Ironfist");

                return false;
            };
        }


        #endregion

        #region Stage One
        [EncounterHandler(61814, "Jin Ironfist")]
        public async Task<bool> JinIronfistEncounter(WoWUnit boss)
        {
            return await ScriptHelpers.DispelEnemy("Enrage", ScriptHelpers.EnemyDispelType.Enrage, boss);
        }

        #endregion

        #region Stage Two

        private readonly Vector3 _stageTwoLoc = new Vector3(698.6362f, 2467.242f, 73.90067f);

        [ScenarioStage(2, "Stage 2")]
        public async Task<bool> StageTwoLogic(ScenarioStage stage)
        {
            if (Me.Location.DistanceSquared(_stageTwoLoc) > 50 * 50)
                ScriptHelpers.SetLeaderMoveToPoi(_stageTwoLoc);
            else
                await ScriptHelpers.ClearArea(_stageTwoLoc, 50);
            return false;
        }

        #endregion

        #region Stage 3

        private readonly Vector3 _stageThreeLoc = new Vector3(687.541f, 2355.474f, 45.03357f);
        [ScenarioStage(3, "Stage 3")]
        public async Task<bool> StageThreeLogic(ScenarioStage stage)
        {
            ScriptHelpers.SetLeaderMoveToPoi(_stageThreeLoc);
            return false;
        }

        private HashSet<uint> MobIds_CryptGuardians = new HashSet<uint> {61766, 61783};

        [EncounterHandler(61766, "Crypt Guardian")]
        [EncounterHandler(61783, "Crypt Guardian")]
        public Func<WoWUnit, Task<bool>> CryptGuardianEncounter()
        {
            const int guardianStrikeId = 119843;

            AddAvoidObject(
                () => true,
                12,
                u => u.Entry == CryptGuardianFuryId && (u.ToUnit().CastingSpellId == BladestormId || u.ToUnit().HasAura(BladestormId)));

            AddAvoidUnitCone(0, 9, 180, u => MobIds_CryptGuardians.Contains(u.Entry) && u.CastingSpellId == guardianStrikeId);

            return async npc => false;
        }

        #endregion

        #region Final Stage;

        private readonly Vector3 _finalStageLoc = new Vector3(749.9462f, 2353.526f, 52.72215f);

        [ScenarioStage(4, "Final Stage")]
        public async Task<bool> FinalStageLogic(ScenarioStage stage)
        {
            ScriptHelpers.SetLeaderMoveToPoi(_finalStageLoc);
            return false;
        }

        private const uint Mobid_AbominationofAnger = 61707;

        [EncounterHandler(61707, "Abomination of Anger")]
        public Func<WoWUnit, Task<bool>> AbominationofAngerEncounter()
        {
            const uint cloudOfAngerId = 62055;
            const int breathOfHate = 120929;

            AddAvoidObject(() => true, 6, cloudOfAngerId);
            AddAvoidObject(
                () => true,
                18,
                u => u.Entry == AbominationOfAngerId && u.ToUnit().HasAura("Deathforce"));

            AddAvoidUnitCone(0, 15, 150, u => u.Entry == Mobid_AbominationofAnger && u.CastingSpellId == breathOfHate);

            return async boss => false;
        }

        #endregion
    }

    #endregion

    #region Heroic Difficulty

    public class CryptOfForgottenKingsHeroic : CryptOfForgottenKings
    {
        #region Overrides of Dungeon

        public override uint DungeonId
        {
            get { return 648; }
        }

        #endregion
    }

    #endregion
}