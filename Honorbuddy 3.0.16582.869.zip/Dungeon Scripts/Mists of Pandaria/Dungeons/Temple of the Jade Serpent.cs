﻿
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Bots.DungeonBuddy.Profiles.Handlers;
using CommonBehaviors.Actions;
using Styx;
using Styx.Common;
using Styx.CommonBot;
using Styx.CommonBot.Coroutines;
using Styx.CommonBot.POI;
using Styx.Helpers;
using Styx.Pathing;
using Styx.TreeSharp;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using System.Linq;
using System.Numerics;
using Styx.WoWInternals.World;
using Action = Styx.TreeSharp.Action;
using Bots.DungeonBuddy.Profiles;
using Bots.DungeonBuddy.Attributes;
using Bots.DungeonBuddy.Helpers;

namespace Bots.DungeonBuddy.Dungeon_Scripts.Mists_of_Pandaria
{
    #region Normal Difficulty

    public class Temple_of_the_Jade_Serpent : Dungeon
    {
        #region Overrides of Dungeon

        public override uint DungeonId
        {
            get { return 464; }
        }

        public override Vector3 Entrance
        {
            get { return new Vector3(957.2355f, -2476.059f, 180.9084f); }
        }

        public override Vector3 ExitLocation
        {
            get { return new Vector3(955.8338f, -2480.424f, 180.4973f); }
        }

        public override void RemoveTargetsFilter(List<WoWObject> units)
        {
            units.RemoveAll(
                ret =>
                {
                    var unit = ret as WoWUnit;
                    if (unit.Entry == WiseMariId && unit.HasAura("Water Bubble") && !Me.IsHealer)
                        return true;

                    if ((unit.Entry == LesserSha || unit.Entry == MinionOfDoubt))
                    {
                        // check if these are on otherside of a door.
                        return !unit.InLineOfSpellSight;
                    }
                    return false;
                });
        }

        public override void IncludeTargetsFilter(List<WoWObject> incomingunits, HashSet<WoWObject> outgoingunits)
        {
            foreach (var obj in incomingunits)
            {
                var unit = obj as WoWUnit;
                if (unit != null)
                {
                    if (unit.Entry == FragmentOfDoubt && unit.CanSelect && unit.Attackable)
                        outgoingunits.Add(unit);
                }
            }
        }

        public override void WeighTargetsFilter(List<Targeting.TargetPriority> units)
        {
            foreach (var priority in units)
            {
                var unit = priority.Object as WoWUnit;
                if (unit != null)
                {
                    if ((unit.Entry == StrifeId || unit.Entry == PerilId) && unit.HasAura("Intensity") && unit.Auras["Intensity"].StackCount >= 9)
                        priority.Score -= 5000;

                    if (unit.Entry == HauntingShaId)
                        priority.Score += 2000;

                    if (unit.Entry == FragmentOfDoubt)
                        priority.Score += 2000;
                }
            }
        }

        private readonly Vector3 _liuFlameheartGroundLocation = new Vector3(930.1583f, -2561.312f, 180.0695f);

        public override async Task<bool> HandleMovement(MoveToParameters moveToParameters)
        {
            var luiFlameheart =
                ObjectManager.GetObjectsOfType<WoWUnit>().FirstOrDefault(u => u.Entry == MobId_LiuFlameheart);

            if (luiFlameheart != null && moveToParameters.Location.DistanceSquared(luiFlameheart.Location) < 3 * 3 &&
                luiFlameheart.Z > 185f)
            {
                return
                    (await CommonCoroutines.MoveTo(_liuFlameheartGroundLocation, luiFlameheart.SubName)).IsSuccessful();
            }

            return false;
        }

        #endregion

        private const uint ShaResidueId = 106653;
        private const uint WiseMariId = 56448;
        private const uint WiseMariFireHoseTargetId = 56574;
        private const uint StrifeId = 59051;
        private const uint PerilId = 59726;
        private const uint HauntingShaId = 59555;
        private const int ShadowsOfDoubt = 110099;
        private const uint DragonWave = 56789;
        private const uint JadeFire = 56893;
        private const uint FragmentOfDoubt = 56792;
        private const uint LesserSha = 58319;
        private const uint MinionOfDoubt = 57109;

        private static readonly Vector3[] s_wiseMariSafeSpots = new[]
                                                               { // inner area
																   new Vector3(1051.405f, -2553.585f, 174.6977f), new Vector3(1052.822f, -2554.836f, 174.6978f),
                                                                   new Vector3(1054.469f, -2557.322f, 174.6978f), new Vector3(1055.248f, -2560.337f, 174.6978f),
                                                                   new Vector3(1054.762f, -2562.604f, 174.6978f), new Vector3(1053.547f, -2565.319f, 174.6978f),
                                                                   new Vector3(1048.494f, -2568.502f, 174.6978f), new Vector3(1045.432f, -2568.629f, 174.6977f),
                                                                   new Vector3(1042.862f, -2567.668f, 174.6977f), new Vector3(1040.639f, -2565.951f, 174.6978f),
                                                                   new Vector3(1038.646f, -2560.687f, 174.6978f), new Vector3(1039.012f, -2557.942f, 174.6978f),
                                                                   new Vector3(1040.285f, -2555.325f, 174.6978f), new Vector3(1042.682f, -2553.407f, 174.6978f),
                                                                   new Vector3(1045.162f, -2552.474f, 174.6978f), new Vector3(1047.432f, -2552.278f, 174.6977f),
																   // outer area
																   new Vector3(1047.545f, -2546.342f, 174.6978f), new Vector3(1043.129f, -2546.999f, 174.6978f),
                                                                   new Vector3(1039.361f, -2548.945f, 174.6978f), new Vector3(1035.902f, -2551.642f, 174.6978f),
                                                                   new Vector3(1033.8f, -2555.948f, 174.6978f), new Vector3(1033.109f, -2560.566f, 174.6978f),
                                                                   new Vector3(1029.522f, -2554.528f, 174.6978f), new Vector3(1026.834f, -2572.702f, 174.6978f),
                                                                   new Vector3(1029.761f, -2576.143f, 174.6978f), new Vector3(1031.975f, -2579.165f, 174.6978f),
                                                                   new Vector3(1035.268f, -2579.458f, 174.6978f), new Vector3(1039.015f, -2575.475f, 174.6978f),
                                                                   new Vector3(1036.832f, -2569.53f, 174.6978f), new Vector3(1040.178f, -2572.773f, 174.6978f),
                                                                   new Vector3(1044.089f, -2573.994f, 174.6977f), new Vector3(1048.111f, -2573.905f, 174.6978f),
                                                                   new Vector3(1050.307f, -2573.528f, 174.6978f), new Vector3(1045.066f, -2577.509f, 174.6978f),
                                                                   new Vector3(1040.632f, -2579.016f, 174.6977f), new Vector3(1042.359f, -2576.134f, 174.6977f),
                                                                   new Vector3(1053.788f, -2582.024f, 174.6978f), new Vector3(1048.276f, -2583.024f, 174.6978f),
                                                                   new Vector3(1046.994f, -2589.204f, 174.6979f), new Vector3(1043.431f, -2589.852f, 174.6978f),
                                                                   new Vector3(1040.591f, -2593.741f, 174.703f), new Vector3(1040.438f, -2585.912f, 174.6977f),
                                                                   new Vector3(1044.145f, -2585.725f, 174.6978f), new Vector3(1033.802f, -2584.221f, 174.6978f),
                                                                   new Vector3(1034.886f, -2589.313f, 174.6982f), new Vector3(1033.678f, -2592.558f, 174.702f),
                                                                   new Vector3(1038.613f, -2592.392f, 174.701f), new Vector3(1057.845f, -2569.239f, 174.6978f),
                                                                   new Vector3(1059.668f, -2564.843f, 174.6978f), new Vector3(1061.083f, -2560.323f, 174.6978f),
                                                                   new Vector3(1059.867f, -2555.553f, 174.6978f), new Vector3(1057.377f, -2551.288f, 174.6978f),
                                                                   new Vector3(1054.945f, -2548.756f, 174.6978f), new Vector3(1064.203f, -2566.805f, 174.6984f),
                                                                   new Vector3(1066.948f, -2565.171f, 174.6978f)
                                                               };

        private readonly CircularQueue<Vector3> _wiseMariCirclePath = new CircularQueue<Vector3>
                                                                       {
                                                                           new Vector3(1051.295f, -2553.112f, 174.6977f),
                                                                           new Vector3(1054.035f, -2556.29f, 174.6978f),
                                                                           new Vector3(1055.2f, -2562.44f, 174.6978f),
                                                                           new Vector3(1053.14f, -2566.464f, 174.6978f),
                                                                           new Vector3(1048.866f, -2568.538f, 174.6978f),
                                                                           new Vector3(1046.027f, -2569.12f, 174.6977f),
                                                                           new Vector3(1042.23f, -2567.977f, 174.6977f),
                                                                           new Vector3(1040.654f, -2566.208f, 174.6978f),
                                                                           new Vector3(1038.396f, -2560.746f, 174.6978f),
                                                                           new Vector3(1039.406f, -2556.696f, 174.6978f),
                                                                           new Vector3(1042.437f, -2553.605f, 174.6978f),
                                                                           new Vector3(1047.244f, -2551.961f, 174.6977f),
                                                                       };


        private readonly Vector3[] _wiseMariCorruptLivingTankSpots = new[] { new Vector3(1049.255f, -2585.932f, 174.6978f), new Vector3(1032.726f, -2583.954f, 174.6978f) };
        private WoWUnit _liuFlameheart;

        private WoWUnit _wiseMari;

        private static LocalPlayer Me
        {
            get { return StyxWoW.Me; }
        }

        [EncounterHandler(0)]
        public async Task<bool> Root(WoWUnit unit)
        {
            return false;
        }

        [EncounterHandler(60578, "Priestess Summerpetal", Mode = CallBehaviorMode.Proximity, BossRange = 35)]
        [EncounterHandler(64399, "Master Windstrong", Mode = CallBehaviorMode.Proximity, BossRange = 35)]
        public Composite QuestPickupHandler()
        {
            WoWUnit unit = null;
            return new PrioritySelector(
                ctx => unit = ctx as WoWUnit,
                new Decorator(
                    ctx => !Me.Combat && !ScriptHelpers.WillPullAggroAtLocation(unit.Location) && unit.QuestGiverStatus == QuestGiverStatus.Available,
                    ScriptHelpers.CreatePickupQuest(ctx => unit)),
                new Decorator(
                    ctx => !Me.Combat && !ScriptHelpers.WillPullAggroAtLocation(unit.Location) && unit.QuestGiverStatus == QuestGiverStatus.TurnIn,
                    ScriptHelpers.CreateTurninQuest(ctx => unit)));
        }

        [EncounterHandler(0, "Root")]
        public Composite RootHandler()
        {
            // Corrupt Living Water npc drop this after they die.
            AddAvoidObject(() => true, 5, o => o.Entry == ShaResidueId, null, true);
            // dropped by minion of doubt
            AddAvoidObject(() => true, 3, o => o.Entry == ShadowsOfDoubt, null, true);

            return new PrioritySelector();
        }

        #region Liu Flameheart

        private const uint MobId_LiuFlameheart = 56732;

        [EncounterHandler(56732, "Liu Flameheart", Mode = CallBehaviorMode.CurrentBoss)]
        public Func<WoWUnit, Task<bool>> LiuFlameheartPreEncounter()
        {
            var roomCenterLoc = new Vector3(929.55f, -2560.471f, 180.0693f);
            return async boss =>
            {
                if (boss == null || !boss.CanSelect || !boss.Attackable)
                {
                    await ScriptHelpers.ClearArea(roomCenterLoc, 70);
                }
                return false;
            };
        }

        [EncounterHandler(56732, "Liu Flameheart")]
        public Composite LiuFlameheartEncounter()
        {
            const uint JadeSerpentWaveId = 119508;
            var tankLoc = new Vector3(929.6893f, -2560.766f, 180.0695f);

            AddAvoidObject(() => true, 3.5f, JadeFire);
            AddAvoidObject(() => true, 2, o => o is WoWAreaTrigger && ((WoWAreaTrigger)o).SpellId == JadeSerpentWaveId, null, true);
            AddAvoidObject(
                () => true,
                5,
                o => o.Entry == DragonWave,
                o =>
                {
                    var loc = o.Location;
                    if (_liuFlameheart != null && _liuFlameheart.IsValid)
                    {
                        return Me.Location.GetNearestPointOnSegment(loc, _liuFlameheart.Location.RayCast(WoWMathHelper.NormalizeRadian(o.ToUnit().Rotation), 80));
                    }
                    return loc;
                });
            return new PrioritySelector(
                ctx => _liuFlameheart = ctx as WoWUnit,
                new Decorator(
                    ctx => Me.IsTank() && Me.CurrentTargetGuid == _liuFlameheart.Guid && _liuFlameheart.CurrentTargetGuid == Me.Guid,
                    ScriptHelpers.CreateTankUnitAtLocation(ctx => tankLoc, 8)));
        }

        #endregion

        #region Sha of Doubt

        [EncounterHandler(56439, "Sha of Doubt", Mode = CallBehaviorMode.Proximity)]
        public Func<WoWUnit, Task<bool>> ShaOfDoubtEncounter()
        {
            // run away from other party members if I have touch of nothingness.
            AddAvoidObject(() => StyxWoW.Me.HasAura("Touch of Nothingness"), 8, u => u is WoWPlayer && !u.IsMe);
            // run from nearby players.
            AddAvoidObject(
                () => StyxWoW.Me.HasAura("Touch of Nothingness"),
                () => ScriptHelpers.Healer.Location,
                35,
                10,
                u => u.Entry == FragmentOfDoubt && ((WoWUnit)u).CurrentTargetGuid == StyxWoW.Me.Guid);

            var leftDoorEdge = new Vector3(921.5688f, -2627.169f, 185.1258f);
            var rightDoorEdge = new Vector3(897.0929f, -2619.158f, 185.1258f);

            var pointInsideRoom = WoWMathHelper.GetRandomPointInCircle(new Vector3(904.97f, -2634.368f, 185.1812f), 5);
            bool runInsideRoom = false;
            return async boss =>
            {
                if (await ScriptHelpers.DispelGroup("Touch of Nothingness", ScriptHelpers.PartyDispelType.Magic))
                    return true;

                var leader = ScriptHelpers.Leader;
                if (!runInsideRoom && leader != null && !leader.IsMe &&
                    leader.Location.IsPointLeftOfLine(leftDoorEdge, rightDoorEdge)
                    && !Me.Location.IsPointLeftOfLine(leftDoorEdge, rightDoorEdge) &&
                    BotPoi.Current.Type == PoiType.None)
                {
                    runInsideRoom = true;
                }

                // Get inside room to avoid getting locked outside and keep running until we arrive at our ranomized point inside door
                if (runInsideRoom && !Navigator.AtLocation(pointInsideRoom) && (await CommonCoroutines.MoveTo(pointInsideRoom)).IsSuccessful())
                    return true;

                runInsideRoom = false;

                if (!Me.HasAura("Touch of Nothingness") && Me.IsRange() && leader != null && leader.DistanceSqr > 6 * 6 && boss.Combat)
                {
                    return (await CommonCoroutines.MoveTo(leader.Location, "stacking on tank")).IsSuccessful();
                }
                return false;
            };
        }

        #endregion

        #region Wise Mari

        [EncounterHandler(56448, "Wise Mari")]
        public Composite WiseMariEncounter()
        {
            List<Vector3> shaResidueLocs = null;
            Vector3 safeLoc = Vector3.Zero;
            float relativeSpoutAngle = 0;
            bool cycledToNearestCircularPoint = false;

            AddAvoidObject(() => true, 7f, u => u.Entry == WiseMariId && ((WoWUnit)u).HasAura("Water Bubble"));

            return new PrioritySelector(
                ctx => _wiseMari = ctx as WoWUnit,
                // Phase 1
                new Decorator<WoWUnit>(
                    boss => boss.HasAura("Water Bubble"),
                    new PrioritySelector(
                        ctx =>
                        {
                            if (cycledToNearestCircularPoint)
                                cycledToNearestCircularPoint = false;
                            shaResidueLocs = ObjectManager.GetObjectsOfType<WoWDynamicObject>().Where(u => u.Entry == ShaResidueId).Select(u => u.Location).ToList();
                            return ctx;
                        },
                        // tank the corrupt Living waters in the back
                        new Decorator(
                            ctx => Me.IsTank() && (Targeting.Instance.IsEmpty() || Targeting.Instance.TargetList.All(u => u.CurrentTargetGuid == Me.Guid)),
                            new PrioritySelector(
                                ctx =>
                                safeLoc =
                                _wiseMariCorruptLivingTankSpots.OrderBy(l => l.DistanceSquared(Me.Location)).FirstOrDefault(l => !shaResidueLocs.Any(s => s.DistanceSquared(l) < 6 * 6)),
                                new Decorator(ctx => Me.Location.DistanceSquared((Vector3)safeLoc) > 4 * 4, new Action(ctx => Navigator.MoveTo(safeLoc))),
                                new Decorator(
                                    ctx => Me.Location.DistanceSquared((Vector3)safeLoc) <= 4 * 4 && Me.CurrentTargetGuid.IsValid && !Me.CurrentTarget.IsWithinMeleeRange,
                                    new PrioritySelector(
                                        new Decorator(ctx => !Me.IsSafelyFacing(Me.CurrentTarget), new Action(ctx => Me.CurrentTarget.Face())), new ActionAlwaysSucceed())))),
                        // don't stand in the pools.
                        new Decorator(
                            ctx =>
                            Me.HasAura("Corrupted Waters") &&
                            (!Me.IsTank() || (Me.IsTank() && (Targeting.Instance.IsEmpty() || Targeting.Instance.TargetList.All(u => u.CurrentTargetGuid == Me.Guid)))),
                            new PrioritySelector(
                                ctx =>
                                safeLoc =
                                s_wiseMariSafeSpots.OrderBy(l => l.DistanceSquared(Me.IsMelee() && Me.CurrentTargetGuid.IsValid ? Me.CurrentTarget.Location : Me.Location))
                                                 .FirstOrDefault(l => !shaResidueLocs.Any(s => s.DistanceSquared(l) < 6 * 6)),
                                new Decorator(ctx => !Navigator.AtLocation(safeLoc), new Action(ctx => Navigator.MoveTo(safeLoc))),
                                new Decorator(ctx => Navigator.AtLocation(safeLoc), new Action(ctx => Navigator.PlayerMover.MoveTowards(safeLoc))))))),
                // Phase 2
                new Decorator<WoWUnit>(
                    boss => !boss.HasAura("Water Bubble") && _wiseMari.HealthPercent > 1,
                    new PrioritySelector(
                        ctx =>
                        {
                            if (!cycledToNearestCircularPoint)
                            {
                                var myLoc = Me.Location;
                                var nearestLoc = _wiseMariCirclePath.OrderBy(l => l.DistanceSquared(myLoc)).FirstOrDefault();
                                _wiseMariCirclePath.CycleTo(nearestLoc);
                                cycledToNearestCircularPoint = true;
                            }
                            relativeSpoutAngle = GetRelativeSpoutAngle(_wiseMari);
                            return ctx;
                        },
                        // move closer
                        new Decorator(
                            ctx => _wiseMari.DistanceSqr > 13 * 13, new Action(ctx => Navigator.MoveTo(WoWMathHelper.CalculatePointFrom(Me.Location, _wiseMari.Location, 8)))),
                        new Decorator(
                            ctx => (relativeSpoutAngle > 0 && relativeSpoutAngle < 90 || Me.Z < 174.5) && Me.Z > 174,
                            new Sequence(
                                new Action(
                                    ctx =>
                                    {
                                        var point = _wiseMariCirclePath.Peek();
                                        Navigator.PlayerMover.MoveTowards(point);
                                        if (Me.Location.Distance(point) < 3)
                                            _wiseMariCirclePath.Dequeue();
                                        var ang = GetRelativeSpoutAngle(_wiseMari);
                                        // keep moving if standing in water.
                                        if ((ang < 200 || Me.Z < 174.5) && _wiseMari.IsAlive)
                                            return RunStatus.Running;
                                        WoWMovement.MoveStop();
                                        return RunStatus.Success;
                                    }),
                                new WaitContinue(3, ctx => Me.IsMoving, new ActionAlwaysSucceed()),
                                new DecoratorContinue(ctx => !Me.IsMoving, new Action(ctx => _wiseMari.Face())))))),
                // Tank does nothing if there are not targets in target list.
                new Decorator(ctx => StyxWoW.Me.IsTank() && Targeting.Instance.IsEmpty(), new ActionAlwaysSucceed()));
        }

        private float GetRelativeSpoutAngle(WoWUnit wiseMari)
        {
            var firehoseTarget = ObjectManager.GetObjectsOfType<WoWUnit>().FirstOrDefault(u => u.Entry == WiseMariFireHoseTargetId);
            var ang = 0f;
            if (firehoseTarget != null)
            {
                var mariToTarget = firehoseTarget.Location - wiseMari.Location;
                var mariAng = (float)Math.Atan2(mariToTarget.Y, mariToTarget.X);
                var mariToMe = Me.Location - wiseMari.Location;
                var angToMe = (float)Math.Atan2(mariToMe.Y, mariToMe.X);
                ang = WoWMathHelper.RadiansToDegrees(mariAng - angToMe);
                if (ang < 0)
                    ang = 360 + ang;
            }
            return ang;
        }

        #endregion

        #region Lorewalker Stonestep

        [EncounterHandler(56843, "Lorewalker Stonestep", Mode = CallBehaviorMode.Proximity)]
        public Composite LorewalkerStonestepEncounter()
        {
            var loc = new Vector3(844.3649f, -2460.1f, 174.961f);

            WoWUnit boss = null;
            return new PrioritySelector(
                ctx => boss = ctx as WoWUnit,
                new Decorator(
                    ctx => boss.HasAura("Meditation") && ScriptHelpers.IsBossAlive("Lorewalker Stonestep"),
                    new Action(ctx => ScriptHelpers.MarkBossAsDead("Lorewalker Stonestep"))),
                new Decorator(ctx => Me.IsTank() && Targeting.Instance.IsEmpty() && !boss.HasAura("Meditation") && Me.Location.Distance(loc) <= 15, new ActionAlwaysSucceed()));
        }

        #endregion
    }

    #endregion


    #region Heroic Difficulty

    public class Temple_of_the_Jade_Serpent_Heroic : Temple_of_the_Jade_Serpent
    {
        #region Overrides of Dungeon

        public override uint DungeonId
        {
            get { return 468; }
        }

        #endregion
    }

    #endregion
}