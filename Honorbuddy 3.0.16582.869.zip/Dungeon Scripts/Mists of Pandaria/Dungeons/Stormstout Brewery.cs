﻿


using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Threading.Tasks;
using Buddy.Coroutines;
using CommonBehaviors.Actions;
using Styx;
using Styx.Common.Helpers;
using Styx.CommonBot;
using Styx.CommonBot.Coroutines;
using Styx.CommonBot.Frames;
using Styx.CommonBot.POI;
using Styx.Helpers;
using Styx.Patchables;
using Styx.Pathing;
using Styx.TreeSharp;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using Action = Styx.TreeSharp.Action;
using Bots.DungeonBuddy.Profiles;
using Bots.DungeonBuddy.Attributes;
using Bots.DungeonBuddy.Helpers;
using Styx.Common;

namespace Bots.DungeonBuddy.Dungeon_Scripts.Mists_of_Pandaria
{
    #region Normal Difficulty

    public class Stormstout_Brewery : Dungeon
    {
        #region Overrides of Dungeon

        private readonly WaitTimer _ignoreHoblitesTimer = new WaitTimer(TimeSpan.FromSeconds(20));
        private readonly WaitTimer _killHoblitesTimer = new WaitTimer(TimeSpan.FromSeconds(10));

        public override uint DungeonId
        {
            get { return 465; }
        }

        public override Vector3 Entrance
        {
            get { return new Vector3(-718.4064f, 1262.169f, 136.4682f); }
        }

        public override Vector3 ExitLocation
        {
            get { return new Vector3(-730.7267f, 1261.082f, 116.6705f); }
        }

        public override void RemoveTargetsFilter(List<WoWObject> units)
        {
            units.RemoveAll(
                ret =>
                {
                    var unit = ret.ToUnit();
                    if (unit != null)
                    {
                        if (s_partyAnimals.Contains(unit.Entry))
                        {
                            // There's one with a Sleep buff that causes problems with pulling.
                            // Only a few with the buff so fine to ignore all with it.
                            if (!KillPartyAnimals || (unit.Combat && !unit.CurrentTargetGuid.IsValid) || unit.HasAura("Sleep"))
                            {
                                return true;
                            }
                        }

                        if (_hoplites.Contains(unit.Entry) && StyxWoW.Me.Location.DistanceSquared(_hoptallusLoc) > 10 * 10 && !_hoptallusEngaged)
                        {
                            if (_ignoreHoblitesTimer.IsFinished)
                            {
                                _ignoreHoblitesTimer.Reset();
                                _killHoblitesTimer.Reset();
                                Logger.Write("Moving forward for 10 seconds");
                            }
                            if (!_killHoblitesTimer.IsFinished && StyxWoW.Me.IsTank())
                            {
                                return true;
                            }
                        }
                        if (unit.Entry == HoptallusId && StyxWoW.Me.IsMelee() && unit.CastingSpellId == FurlwindSpellId)
                            return true;

                        if (_yeastyBrewAlementalIds.Contains(unit.Entry) && ShouldStayInYanZhusMeleeRange)
                            return true;
                    }
                    return false;
                });
        }


        public override void IncludeTargetsFilter(List<WoWObject> incomingunits, HashSet<WoWObject> outgoingunits)
        {
            var hasAggro = ObjectManager.GetObjectsOfType<WoWUnit>().Any(u => u.Combat && u.IsTargetingMyRaidMember);
            foreach (var obj in incomingunits)
            {
                var unit = obj as WoWUnit;
                if (unit != null)
                {
                    if (s_partyAnimals.Contains(unit.Entry) && !hasAggro && unit.DistanceSqr <= 40 * 40 && KillPartyAnimals && Me.IsTank())
                    {
                        PathInformation pathInf = Navigator.LookupPathInfo(unit);
                        if (pathInf.Navigability == PathNavigability.Navigable && pathInf.Distance < 40)
                            outgoingunits.Add(unit);
                    }
                }
            }
        }

        public override void WeighTargetsFilter(List<Targeting.TargetPriority> units)
        {
            foreach (var priority in units)
            {
                var unit = priority.Object as WoWUnit;
                if (unit != null)
                {
                    if (unit.Entry == HabaneroBrewId)
                        priority.Score += 400;

                    if (s_bopperIds.Contains(unit.Entry) && StyxWoW.Me.IsDps)
                        priority.Score += 600;

                    if (s_hopperIds.Contains(unit.Entry) && StyxWoW.Me.IsDps)
                        priority.Score += 500;

                    if (unit.Entry == HoptallusId)
                    {
                        // dps adds while Hoptallus is casting Furlwind otherwise dpe him and ignore adds during carret breath.
                        if (unit.CastingSpellId == FurlwindSpellId)
                            priority.Score -= 1000;
                        else if (unit.CastingSpellId == CarretBreathSpellId)
                            priority.Score += 1000;
                    }
                    // ignore these and stay in melee of Yan-Zhu
                    if (_yeastyBrewAlementalIds.Contains(unit.Entry))
                    {
                        if (ShouldStayInYanZhusMeleeRange && unit.Location.Distance(_yanZhu.Location) > _yanZhu.MeleeRange)
                            priority.Score -= 500;
                        else
                            priority.Score = 10000 - unit.HealthPercent;
                    }

                    if (unit.Entry == BubbleShieldId)
                        priority.Score += 1000;
                }
            }
        }

        #endregion

        private const uint HozenPartyAnimalId = 56927;
        private const uint SleepyHozenBrawlerId = 56863;
        private const uint HabaneroBrewId = 56731;
        private const uint MysteriouslyShakingKegId = 211138;
        private const uint HoptallusId = 56717;
        private const int FurlwindSpellId = 112992;
        private const uint GushingBrewId = 59394;
        private const int CarbonationId = 56746;
        private const uint FizzyBrewAlemental = 56748;
        private const int CarretBreathSpellId = 112944;
        private readonly uint[] _yeastyBrewAlementalIds = new uint[] { 66413, 59494 };

        private const int FermentHealSpellId = 114451;
        private const int FermentSpellId = 106859;
        private const uint WallOfSudsVehicle = 59510;
        private const uint YanZhuTheUncasked = 56717;
        private const uint UncleGaoId = 59074;
        private const uint ChenStormstoutId = 64361;
        private const int ExplosiveBrew = 116027;
        private const uint FizzyBubbleId = 59799;
        private const int FizzyBubblesSpellId = 114459;
        private const int CarbonationSpellId = 114386;
        private const uint BubbleShieldId = 59487;

        private static readonly uint[] s_bopperIds = new uint[] { 59426, 59551 };

        private static readonly uint[] s_hoplingIds = new uint[] { 59459, 59460, 59461 };

        private static readonly uint[] s_hopperIds = new uint[] { 59464, 56718 };
        private static readonly uint[] s_partyAnimals = new[] { SleepyHozenBrawlerId, HozenPartyAnimalId, HabaneroBrewId };
        private readonly Vector3 _exitBarrelLoc = new Vector3(-697.1378f, 1259.298f, 162.7813f);

        private readonly uint[] _hoplites = s_bopperIds.Concat(s_hoplingIds.Concat(s_hopperIds)).ToArray();
        private readonly Vector3 _hoptallusLoc = new Vector3(-696.0826f, 1259.851f, 162.7818f);

        private int _hozenPartyAnimalsDistrupted;
        private DateTime _hozenPartyAnimalsDistruptedUpdatedTime;

        private WoWUnit _ookook;
        private WoWUnit _yanZhu;

        private static LocalPlayer Me
        {
            get { return StyxWoW.Me; }
        }

        #region Quest

        [EncounterHandler(64361, "Chen Stormstout", Mode = CallBehaviorMode.Proximity, BossRange = 35)]
        [EncounterHandler(59704, "Chen Stormstout", Mode = CallBehaviorMode.Proximity, BossRange = 35)]
        [EncounterHandler(59822, "Auntie Stormstout", Mode = CallBehaviorMode.Proximity, BossRange = 35)]
        [EncounterHandler(59074, "Uncle Gao", Mode = CallBehaviorMode.Proximity, BossRange = 35)]
        public Composite QuestPickupHandler()
        {
            WoWUnit unit = null;
            return new PrioritySelector(
                ctx => unit = ctx as WoWUnit,
                new Decorator(
                    ctx => !Me.Combat && !ScriptHelpers.WillPullAggroAtLocation(unit.Location) && unit.QuestGiverStatus == QuestGiverStatus.Available,
                    ScriptHelpers.CreatePickupQuest(ctx => unit)),
                new Decorator(
                    ctx => !Me.Combat && !ScriptHelpers.WillPullAggroAtLocation(unit.Location) && unit.QuestGiverStatus == QuestGiverStatus.TurnIn,
                    ScriptHelpers.CreateTurninQuest(ctx => unit)));
        }

        [ObjectHandler(213795, "Stormstout Secrets", ObjectRange = 20)]
        public Composite StormstoutSecretsHandler()
        {
            const int familySecretsQuestId = 31324;
            return
                new Decorator<WoWGameObject>(
                    book =>
                    {
                        if (!ScriptHelpers.HasQuest(familySecretsQuestId) || ScriptHelpers.IsQuestInLogComplete(familySecretsQuestId))
                            return false;

                        if (Me.Combat || !Targeting.Instance.IsEmpty() || ScriptHelpers.WillPullAggroAtLocation(book.Location))
                            return false;

                        PathInformation pathInf = Navigator.LookupPathInfo(book, book.InteractRange);
                        return pathInf.Navigability == PathNavigability.Navigable &&
                               pathInf.Distance < 20;
                    },
                    new PrioritySelector(
                        new Decorator<WoWGameObject>(book => !book.WithinInteractRange, new Helpers.Action<WoWGameObject>(book => Navigator.MoveTo(book.Location))),
                        new Decorator(ctx => LootFrame.Instance.IsVisible, new Action(ctx => LootFrame.Instance.LootAll())),
                         new Helpers.Action<WoWGameObject>(book => book.Interact())));
        }

        #endregion


        #region Ook-Ook

        private const uint MobId_OokOok = 56637;
        private const int SpellId_GroundPound = 106807;
        private const uint MobId_RollingBarrel = 56682;
        private const uint GameObjectId_BarrelDoor = 211127;

        private int HozenPartyAnimalsDistrupted
        {
            get
            {
                // Throttle the Lua call for efficiency
                if (DateTime.Now - _hozenPartyAnimalsDistruptedUpdatedTime > TimeSpan.FromMilliseconds(1000))
                {
                    _hozenPartyAnimalsDistrupted = Lua.GetReturnVal<int>("return UnitPower('player',10)", 0);
                    _hozenPartyAnimalsDistruptedUpdatedTime = DateTime.Now;
                }
                return _hozenPartyAnimalsDistrupted;
            }
        }

        private bool KillPartyAnimals
        {
            get
            {
                if (_ookook != null && _ookook.IsValid && _ookook.Attackable)
                    return false;
                return HozenPartyAnimalsDistrupted < 40;
            }
        }

        [EncounterHandler(56637, "Ook-Ook", Mode = CallBehaviorMode.Proximity)]
        public Func<WoWUnit, Task<bool>> OokOokEncounter()
        {
            // avoid Ground Pound
            AddAvoidObject(
                () => true,
                7,
                o =>
                    o.Entry == MobId_OokOok &&
                    (o.ToUnit().CastingSpellId == SpellId_GroundPound || o.ToUnit().HasAura("Ground Pound")),
                o => o.Location.RayCast(o.Rotation, 6));

            var rightDoorEdge = new Vector3(-771.9838f, 1387.028f, 146.7171f);
            var leftDoorEdge = new Vector3(-760.3922f, 1390.458f, 146.7169f);
            var pointInsideRoom = WoWMathHelper.GetRandomPointInCircle(new Vector3(-765.1668f, 1384.943f, 146.7272f), 3);

            return async boss =>
            {
                _ookook = boss;
                // We want to ignore boss if he's on balcony.
                if (boss.ZDiff > 10)
                    return false;

                var isTank = Me.IsTank();
                var insideBossRoom = Me.Location.IsPointLeftOfLine(leftDoorEdge, rightDoorEdge) && Me.Z > 140;

                // If locked out of boss room then do nothing until door opens.
                if (!insideBossRoom && boss.Combat)
                {
                    if (ObjectManager.GetObjectsOfType<WoWGameObject>().Any(g => g.Entry == GameObjectId_BarrelDoor))
                    {
                        TreeRoot.StatusText = "Locked out of boss room, waiting for encounter to complete";
                        return true;
                    }
                }

                // out of combat behavior.
                if (!boss.Combat && !Me.Combat)
                {
                    if (!isTank)
                    {
                        var leader = ScriptHelpers.Leader;
                        // Get inside room to avoid getting locked outside and keep running until we arrive at our ranomized point inside door
                        if (!insideBossRoom && leader != null
                            && leader.Location.IsPointLeftOfLine(leftDoorEdge, rightDoorEdge)
                            && BotPoi.Current.Type == PoiType.None)
                        {
                            await
                                ScriptHelpers.MoveToContinue(
                                    () => pointInsideRoom,
                                    name: "Moving inside room to avoid getting locked out");
                        }
                    }

                    // tank should wait some distance from door.
                    if (isTank && insideBossRoom && !Me.Combat
                        && Me.Location.GetNearestPointOnLine(leftDoorEdge, rightDoorEdge).DistanceSquared(Me.Location) > 7 * 7
                        && !ScriptHelpers.GroupMembers.All(
                            g => g.Guid == Me.Guid || g.Location.IsPointLeftOfLine(leftDoorEdge, rightDoorEdge)))
                    {
                        TreeRoot.StatusText = "Waiting for followers to enter room before starting encounter";
                        await CommonCoroutines.StopMoving();
                        return true;
                    }
                }
                else if (boss.Combat)
                {
                    // handle combat behavior
                    if (Me.IsDps)
                    {
                        // if I'm riding a barrel then move towards boss.

                        if (StyxWoW.Me.IsOnTransport)
                        {
                            Navigator.PlayerMover.MoveTowards(boss.Location);
                            await Coroutine.Sleep(300);
                            return true;
                        }
                        WoWUnit rollingBarrel = ObjectManager.GetObjectsOfType<WoWUnit>()
                            .Where(
                                u =>
                                    u.Entry == MobId_RollingBarrel && u.DistanceSqr <= 12 * 12 &&
                                    !u.CharmedByUnitGuid.IsValid)
                            .OrderBy(u => u.DistanceSqr)
                            .FirstOrDefault();
                        // If I'm a Dps then hop on any nearby rolling barrels
                        if (rollingBarrel != null && await ScriptHelpers.InteractWithObject(rollingBarrel, ignoreCombat: true))
                        {
                            return true;
                        }
                    }
                }
                return false;
            };
        }

        #endregion

        #region Root

        [EncounterHandler(0, "Root")]
        public Composite RootEncounter()
        {
            AddAvoidObject(
                () => !Me.HasAura("Smash!"),
                10,
                u => s_hopperIds.Contains(u.Entry) && u.ToUnit().CastingSpellId == ExplosiveBrew && u.ToUnit().CurrentCastTimeLeft <= TimeSpan.FromSeconds(3));

            //casted by Fizzy Brew Alemental
            AddAvoidObject(() => true, 6, CarbonationId, FizzyBrewAlemental);

            // brew gushing out of barrels. don't stand in it.
            AddAvoidObject(() => StyxWoW.Me.Combat && Math.Abs(StyxWoW.Me.Z - 139) <= 10, 4, GushingBrewId);

            // dodge barrels if not boarding them and nobody is riding them
            AddAvoidObject(
                () => _ookook == null || !_ookook.IsValid || !_ookook.Combat || _ookook.Combat && !Me.IsDps,
                4,
                u => u.Entry == MobId_RollingBarrel && u.ZDiff < 4 && u.Distance < 15,
                u =>
                {
                    var start = u.Location;
                    return Me.Location.GetNearestPointOnSegment(start, start.RayCast(WoWMathHelper.NormalizeRadian(u.Rotation), 20));
                });

            // run from bloated party members.
            AddAvoidUnitCone(90, 12, 20, u => u.IsPlayer && !u.IsMe && !u.IsMoving && u.HasAura("Bloat"));
            AddAvoidUnitCone(270, 12, 20, u => u.IsPlayer && !u.IsMe && !u.IsMoving && u.HasAura("Bloat"));

            return new PrioritySelector(
                new Decorator(ctx => StyxWoW.Me.HasAura("How Did I Get Here?"), new Action(ctx => Navigator.PlayerMover.MoveTowards(_exitBarrelLoc))),
                // jump to get rid of blackout brew debuf.
                new Decorator(
                    ctx =>
                    StyxWoW.Me.HasAura("Blackout Brew") && !Me.HasAura(FizzyBubblesSpellId) && !Me.HasAura(CarbonationSpellId) &&
                    (!Me.IsHealer || Me.IsHealer && Me.Auras["Blackout Brew"].StackCount < 9 && Me.PartyMembers.All(p => p.HealthPercent > 50)),
                    new Action(
                        ctx =>
                        {
                            Lua.DoString("JumpOrAscendStart()");
                            Lua.DoString("AscendStop()");
                            return RunStatus.Failure;
                        })),
                CreateHoppletBehavior());
        }

        #endregion

        #region Hoptallus

        [EncounterHandler(59539, "Big Ol' Hammer", Mode = CallBehaviorMode.Proximity, BossRange = 15)]
        public Composite BigOlHammerEncounter()
        {
            WoWUnit hammer = null;
            return new PrioritySelector(
                ctx => hammer = ctx as WoWUnit,
                new Decorator(
                    // can have a max of 10 stacks of Smash! debuf. each hammer gives 3
                    ctx => (!StyxWoW.Me.HasAura("Smash!") || StyxWoW.Me.Auras["Smash!"].StackCount <= 7) && !StyxWoW.Me.IsHealer,
                    ScriptHelpers.CreateInteractWithObject(ctx => hammer, 0, true)));
        }

        private Composite CreateHoppletBehavior()
        {
            const int explosiveBrewSpellId = 114291;


            // run away before hopper explodes.
            AddAvoidObject(
                () => true,
                10,
                u =>
                s_hopperIds.Contains(u.Entry) && ((WoWUnit)u).CastingSpellId == explosiveBrewSpellId && ((WoWUnit)u).CurrentCastTimeLeft <= TimeSpan.FromMilliseconds(2000));
            return
                new PrioritySelector(
                    new Decorator(
                        ctx => StyxWoW.Me.HasAura("Smash!") && ScriptHelpers.GetUnfriendlyNpsAtLocation(StyxWoW.Me.Location, 6, u => _hoplites.Contains(u.Entry)).Any(),
                        new Action(
                            ctx =>
                            {
                                Lua.DoString("ExtraActionButton1:Click()");
                                return RunStatus.Failure; // we can do other stuff while casting this.
                            })));
        }

        private bool _hoptallusEngaged;
        [EncounterHandler(56717, "Hoptallus", Mode = CallBehaviorMode.CurrentBoss)]
        public Composite HoptallusGauntletBehavior()
        {
            // force the tank to move to Hoptallus
            return new PrioritySelector(
                new Action(
                    ctx =>
                    {
                        _hoptallusEngaged = ctx != null && ((WoWUnit)ctx).Combat;
                        return RunStatus.Failure;
                    }),
                new Decorator(ctx => Me.IsTank() && Me.Combat && _killHoblitesTimer.IsFinished && !_hoptallusEngaged && Me.Location.DistanceSquared(_hoptallusRoomCenterLoc) > 10 * 10,
                    new Action(ctx => Navigator.MoveTo(_hoptallusRoomCenterLoc)))
                );
        }

        private readonly Vector3 _hoptallusRoomCenterLoc = new Vector3(-696.4132f, 1258.904f, 162.7954f);

        [EncounterHandler(56717, "Hoptallus")]
        public Composite HoptallusEncounter()
        {
            WoWUnit boss = null;

            var insideDoorLoc = new Vector3(-700.3579f, 1275.827f, 162.7954f);
            var roomCenterLoc = new Vector3(-696.4132f, 1258.904f, 162.7954f);
            // Run away from furlwind
            AddAvoidObject(() => !Me.IsCasting, () => roomCenterLoc, 20, 10, u => u.Entry == HoptallusId && ((WoWUnit)u).CastingSpellId == FurlwindSpellId);

            return new PrioritySelector(
                ctx => boss = ctx as WoWUnit,
                // make sure we're inside the door!
                new Decorator(ctx => StyxWoW.Me.Y > 1280, new Action(ctx => Navigator.MoveTo(insideDoorLoc))),
                // ScriptHelpers.CreateAvoidUnitAnglesBehavior(
                //   ctx => boss.CastingSpellId == carrotBreathSpellId && !Me.IsCasting && boss.Distance <= 15, ctx => boss, new ScriptHelpers.AngleSpan(40, 120)),
                new Decorator(
                    ctx => StyxWoW.Me.CurrentTarget == boss && boss.ChanneledCastingSpellId == 0 && !Targeting.Instance.IsEmpty(),
                    ScriptHelpers.CreateTankUnitAtLocation(ctx => roomCenterLoc, 5)),
                new Decorator(ctx => StyxWoW.Me.IsTank() && Targeting.Instance.IsEmpty(), new ActionAlwaysSucceed()));
        }

        #endregion

        #region Yan-Zhu the Uncasked

        // handles waiting for boss to spawn.

        private bool ShouldJumpForWallsOfSuds
        {
            get
            {
                var sudsWalls = ObjectManager.GetObjectsOfType<WoWUnit>().Where(u => u.Entry == WallOfSudsVehicle).OrderBy(u => u.DistanceSqr).ToArray();
                if (sudsWalls.Length == 0) return false;
                var myLoc = StyxWoW.Me.Location;
                return (from sudsWall in sudsWalls
                        let start = WoWMathHelper.CalculatePointAtSide(sudsWall.Location, sudsWall.Rotation, 10, true)
                        let end = WoWMathHelper.CalculatePointAtSide(sudsWall.Location, sudsWall.Rotation, 10, false)
                        where myLoc.GetNearestPointOnLine(start, end).DistanceSquared(myLoc) <= 15 * 15
                        select start).Any();
            }
        }

        private bool ShouldStayInYanZhusMeleeRange
        {
            get
            {
                var tank = ScriptHelpers.Tank;
                return _yanZhu != null && _yanZhu.IsValid && _yanZhu.Combat &&
                       (tank == null || tank.IsMe || tank.Location.Distance(_yanZhu.Location) > _yanZhu.MeleeRange && StyxWoW.Me.IsMelee());
            }
        }

        private Vector3 FermentInterceptLoc
        {
            get
            {
                if (StyxWoW.Me.HasAura(FermentHealSpellId))
                    return Vector3.Zero;

                return (from yeasty in ObjectManager.GetObjectsOfType<WoWUnit>()
                        where yeasty.HasAura(FermentSpellId)
                        let target =
                            ObjectManager.GetObjectsOfType<WoWUnit>(false, false)
                                         .FirstOrDefault(u => u.GetAllAuras().Any(a => a.SpellId == FermentHealSpellId && a.CreatorGuid == yeasty.Guid))
                        where target != null && (ShouldStayInYanZhusMeleeRange && target.Entry == YanZhuTheUncasked || !ShouldStayInYanZhusMeleeRange)
                        select StyxWoW.Me.Location.GetNearestPointOnSegment(yeasty.Location, target.Location)).FirstOrDefault();
            }
        }

        [EncounterHandler(59479, "Yan-Zhu the Uncasked", Mode = CallBehaviorMode.CurrentBoss)]
        public Composite YanZhuTheUncaskedSpawnEncounter()
        {
            var roomCenterLoc = new Vector3(-703.0988f, 1163.54f, 166.1415f);
            var waitForSpawnTimer = new WaitTimer(TimeSpan.FromSeconds(20));
            int waitCnt = 0;
            return new PrioritySelector(
                ctx => _yanZhu = ctx as WoWUnit,
                // wait for spawns.
                new Decorator(
                    ctx =>
                    _yanZhu == null && Targeting.Instance.IsEmpty() && Me.IsTank() && StyxWoW.Me.Location.DistanceSquared(roomCenterLoc) <= 20 * 20,
                    new PrioritySelector(
                        new Decorator(ctx => waitForSpawnTimer.IsFinished && waitCnt <= 3, new Action(
                            ctx =>
                            {
                                waitForSpawnTimer.Reset();
                                waitCnt++;
                                return RunStatus.Failure;
                            })),
                        new Decorator(ctx => !waitForSpawnTimer.IsFinished,
                            new PrioritySelector(
                                new ActionSetActivity("Waiting for Yan-Zhu to come out of hiding"),
                                new ActionAlwaysSucceed()))
                        )));
        }

        [ObjectHandler(211137, "Sliding Door", ObjectRange = 4)]
        public Composite SlidingDoorHandler()
        {
            return new PrioritySelector(
                new Decorator<WoWGameObject>(
                    door => door.State == WoWGameObjectState.Ready,
                    new Helpers.Action<WoWGameObject>(
                        door =>
                        {
                            door.Interact();
                            return RunStatus.Failure;
                        })));
        }

        private const uint BubblingBrewAlementalId = 59521;

        [LocationHandler(-700.8574, 1161.332, 166.1415, 50, "Yan-Zhu the Uncasked Trash")]
        public Composite CreateBehavior_YanZhuTrash()
        {
            var moveTo = new Vector3(-712.2311f, 1192.942f, 167.3986f);
            return new PrioritySelector(
                ctx => ScriptHelpers.Tank,
                // check if tank is LOSing trash at a pillar
                new Decorator<WoWPlayer>(
                    tank =>
                        !tank.IsMe && tank.Location.DistanceSquared(moveTo) < 5 * 5 &&
                        Targeting.Instance.TargetList.Any(t => t.Entry == BubblingBrewAlementalId),
                    new PrioritySelector(
                        new ActionSetActivity("LOSing trash at Yan-Zhu"),
                        new Decorator(
                            loc => Me.Location.DistanceSquared(moveTo) > 3 * 3,
                            new Action(ctx => Navigator.MoveTo(moveTo))),
                        // wait for target to get in dps range.
                        new Decorator(
                            ctx => ScriptHelpers.MovementEnabled,
                            new Helpers.Action<WoWPlayer>(
                                tank =>
                                    ScriptHelpers.DisableMovement(
                                        () =>
                                            tank.IsValid && tank.IsAlive && tank.Location.DistanceSquared(moveTo) < 5 * 5 &&
                                            Targeting.Instance.TargetList.Any(t => t.Entry == BubblingBrewAlementalId)))))));
        }

        [EncounterHandler(59479, "Yan-Zhu the Uncasked")]
        public Composite YanZhuTheUncaskedEncounter()
        {
            WoWUnit fizzyBubble = null;
            var jumpTimer = new WaitTimer(TimeSpan.FromSeconds(2));
            return new PrioritySelector(
                ctx =>
                {
                    fizzyBubble = (from obj in ObjectManager.GetObjectsOfType<WoWUnit>()
                                   where
                                       obj.Entry == FizzyBubbleId &&
                                       !Me.PartyMembers.Any(
                                           p =>
                                           p.IsSafelyFacing(obj, 45) && !p.HasAura(FizzyBubblesSpellId) &&
                                           p.Location.DistanceSquared(obj.Location) < Me.Location.DistanceSquared(obj.Location))
                                   orderby obj.DistanceSqr
                                   select obj).FirstOrDefault();
                    return _yanZhu = ctx as WoWUnit;
                },
                // Handle carbonation.
                new Decorator(
                    ctx => fizzyBubble != null && !Me.HasAura(FizzyBubblesSpellId),
                    new PrioritySelector(
                        new Decorator(ctx => fizzyBubble.Distance2D <= 4, new Action(ctx => fizzyBubble.Interact())),
                        new Decorator(ctx => fizzyBubble.Distance2D > 4, new Action(ctx => Navigator.MoveTo(fizzyBubble.Location))))),
                new Decorator(
                    ctx => Me.HasAura(FizzyBubblesSpellId) && jumpTimer.IsFinished,
                    new PrioritySelector(
                        new Decorator(
                            ctx => Me.HasAura(CarbonationSpellId) || !Me.IsFlying,
                            new Action(
                                ctx =>
                                {
                                    Lua.DoString("JumpOrAscendStart()");
                                    Lua.DoString("AscendStop()");
                                    var loc = Me.Location;
                                    loc.Z += 6;
                                    Navigator.PlayerMover.MoveTowards(loc);
                                    jumpTimer.Reset();
                                })))),
                // walls of suds.
                new Decorator(
                    ctx => ShouldJumpForWallsOfSuds,
                    new Sequence(
                        new Action(ctx => WoWMovement.Move(WoWMovement.MovementDirection.JumpAscend)),
                        new Action(ctx => Logger.Write("Jumping to avoid wall of suds")),
                        new Action(ctx => WoWMovement.MoveStop(WoWMovement.MovementDirection.JumpAscend)))),
                new Decorator(
                    ctx => ShouldStayInYanZhusMeleeRange && _yanZhu.Distance2DSqr > 4 * 4,
                    new Sequence(
                        new Action(ctx => Logger.Write("Moving into Yan-Zhu's Melee Range")),
                        new DecoratorContinue(
                            ctx => _yanZhu.Distance2DSqr < 10 * 10,
                            new Action(ctx => Navigator.PlayerMover.MoveTowards(WoWMathHelper.CalculatePointFrom(StyxWoW.Me.Location, _yanZhu.Location, 3)))),
                        new DecoratorContinue(
                            ctx => _yanZhu.Distance2DSqr >= 10 * 10,
                            ScriptHelpers.CreateMoveToContinue(ctx => WoWMathHelper.CalculatePointFrom(StyxWoW.Me.Location, _yanZhu.Location, 3))))),
                new PrioritySelector(
                    ctx => FermentInterceptLoc,
                    new Decorator(
                        ctx => (Vector3)ctx != Vector3.Zero,
                        new Sequence(new Action(ctx => Logger.Write("Intercepting Ferment")), new Action(ctx => Navigator.PlayerMover.MoveTowards((Vector3)ctx))))));
        }

        #endregion
    }

    #endregion

    #region Heroic Difficulty

    public class Stormstout_BreweryHeroic : Stormstout_Brewery
    {
        #region Overrides of Dungeon

        public override uint DungeonId
        {
            get { return 469; }
        }

        #endregion
    }

    #endregion
}