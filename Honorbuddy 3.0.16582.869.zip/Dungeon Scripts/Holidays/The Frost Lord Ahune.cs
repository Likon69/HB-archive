﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Threading.Tasks;
using Bots.DungeonBuddy.Enums;
using Buddy.Coroutines;
using Styx;
using Styx.Common;
using Styx.CommonBot;
using Styx.CommonBot.Coroutines;
using Styx.CommonBot.Frames;
using Styx.Pathing;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using Bots.DungeonBuddy.Attributes;
using Bots.DungeonBuddy.Helpers;

namespace Bots.DungeonBuddy.Dungeon_Scripts.Mists_of_Pandaria
{
    internal class The_Frost_Lord_Ahune : Dungeon
    {
        #region Overrides of Dungeon

        public override uint DungeonId
        {
            get { return 286; }
        }

        private readonly Vector3 _entrance = new Vector3(740.8317f, 7013.667f, -72.97391f);
        public override Vector3 Entrance
        {
            get { return _entrance; }
        }


        public override void RemoveTargetsFilter(List<WoWObject> units)
        {
            units.RemoveAll(
                ret =>
                {
                    var unit = ret.ToUnit();
                    if (unit != null) { }
                    return false;
                });
        }

        public override void IncludeTargetsFilter(List<WoWObject> incomingunits, HashSet<WoWObject> outgoingunits)
        {
            foreach (var obj in incomingunits)
            {
                var unit = obj as WoWUnit;
                if (unit != null)
                {
                    if (unit.Entry == FrozenCoreId && unit.Attackable)
                        outgoingunits.Add(unit);
                }
            }
        }

        public override void WeighTargetsFilter(List<Targeting.TargetPriority> units)
        {
            foreach (var priority in units)
            {
                var unit = priority.Object as WoWUnit;
                if (unit != null)
                {
                    if (unit.Entry == AhuneId)
                    {
                        priority.Score -= 10000;
                    }
                    else if (unit.Entry == FrozenCoreId)
                    {
                        priority.Score += 10000;
                    }
                }
            }
        }

        public override void IncludeLootTargetsFilter(List<WoWObject> incomingunits, HashSet<WoWObject> outgoingunits)
        {
            foreach (var obj in incomingunits)
            {
                var gObj = obj as WoWGameObject;
                if (gObj != null)
                {
                    // chest that spawns after killing ahune
                    if (gObj.Entry == IceChestId
                        && DungeonBuddySettings.Instance.LootMode != LootMode.Off
                        && gObj.CanUse())
                    {
                        outgoingunits.Add(gObj);
                    }
                }
            }
        }

        #endregion

        #region corpse run behavior

        private readonly CircularQueue<Vector3> _tunnelPath = new CircularQueue<Vector3>()
                                                    {
                                                        new Vector3(563.1432f, 6943.247f, -1.951628f),
                                                        new Vector3(568.424f, 6941.722f, -24.89723f),
                                                        new Vector3(582.709f, 6936.663f, -38.11215f),
                                                        new Vector3(602.8282f, 6915.195f, -45.36474f),
                                                        new Vector3(611.301f, 6895.487f, -51.30582f),
                                                        new Vector3(637.5763f, 6869.115f, -79.11536f),
                                                        new Vector3(667.0811f, 6865.27f, -81.14445f),
                                                        new Vector3(667.0811f, 6865.27f, -70.73276f),
                                                    };

        private readonly Vector3 _corpseRunSubmergeStart = new Vector3(561.1754f, 6944.772f, 16.60149f);

        public override async Task<bool> HandleMovement(MoveToParameters moveToParameters)
        {
            var location = moveToParameters.Location;
            // Coilfang corpse run. 
            if (Me.IsGhost)
            {
                var myLoc = Me.Location;
                // Outside and above water logic
                if (Me.Z > 12)
                {
                    // move to a point on the outside water surface just above underwater tunnel 
                    if (myLoc.DistanceSquared(_corpseRunSubmergeStart) > 10 * 10)
                        return (await CommonCoroutines.MoveTo(_corpseRunSubmergeStart)).IsSuccessful();

                    if (_tunnelPath.Peek() != _tunnelPath.First)
                        _tunnelPath.CycleTo(_tunnelPath.First);

                    // submerge. We can only break through the water's surface if player's vertical pitch is facing down. 
                    if (!Me.IsSwimming)
                        Lua.DoString("VehicleAimIncrement(-1)");
                    else
                        Navigator.PlayerMover.MoveTowards(_tunnelPath.First);
                    return true;
                }
                // tunnel navigation.
                if (Me.IsSwimming)
                {
                    var moveTo = _tunnelPath.Peek();
                    if (myLoc.DistanceSquared((Vector3)moveTo) < 5 * 5)
                    {
                        _tunnelPath.Dequeue();
                        moveTo = _tunnelPath.Peek();
                        // Tunnel path ends at the water surface of the underwater pool. Jump to walk on the surface.
                        if (moveTo == _tunnelPath.First)
                        {
                            WoWMovement.Move(WoWMovement.MovementDirection.JumpAscend);
                            WoWMovement.MoveStop(WoWMovement.MovementDirection.JumpAscend);
                            return true;
                        }
                    }
                    Navigator.PlayerMover.MoveTowards(moveTo);
                    return true;
                }
            }
            return false;
        }

        public override void OnEnter()
        {
            // if coming back from a DC and a ghost then make sure current point in _tunnelPath is closest one.
            if (Me.IsGhost && Me.IsSwimming)
            {
                var myLoc = Me.Location;
                _tunnelPath.CycleTo(_tunnelPath.OrderBy(loc => loc.DistanceSquared(myLoc)).FirstOrDefault());
            }
            base.OnEnter();
        }

        #endregion

        private const uint SlipperyFloorBunnyId = 25952;
        private const uint SpankTargetBunnyId = 26190;
        private const uint IceSpearBunnyId = 25985;
        private const uint IceStoneId = 187882;
        private const uint FrozenCoreId = 25865;
        private const uint AhuneId = 25740;
        private const uint PocketOfSnowId = 35512;
        private const uint IceChestId = 187892;
        private const uint SatchelId = 54536;

        private LocalPlayer Me { get { return StyxWoW.Me; } }

        [EncounterHandler(0)]
        public Func<WoWUnit, Task<bool>> RootBehavior()
        {
            const uint bigIceBlockId = 188142;
            const uint iceBlockId = 188067;
            const uint iseStoneMountId = 188072;
            const uint extraBigIceBlockId = 195000;

            AddAvoidObject(() => true, 6, bigIceBlockId, extraBigIceBlockId);
            AddAvoidObject(() => true, 3, iceBlockId, iseStoneMountId);
            AddAvoidObject(() => true, 4, IceSpearBunnyId);

            return async npc =>
                        {
                            if (!Me.Combat)
                            {
                                var pocketOfSnow = Me.BagItems.FirstOrDefault(i => i.Entry == PocketOfSnowId || i.Entry == SatchelId);
                                if (pocketOfSnow != null)
                                {
                                    pocketOfSnow.UseContainerItem();
                                    if (!await Coroutine.Wait(2000, () => LootFrame.Instance.IsVisible))
                                        return false;
                                    LootFrame.Instance.LootAll();
                                    return true;
                                }
                            }
                            return false;
                        };
        }

        [ObjectHandler(187882, "Ice Stone", 100)]
        public async Task<bool> IceStoneBehavior(WoWGameObject iceStone)
        {
            if (!Me.IsLeader() || !Targeting.Instance.IsEmpty() || !iceStone.CanUse())
                return false;

            if (!ScriptHelpers.GroupMembers.All(g => g.Player != null && g.IsAlive && g.Location.DistanceSquared((Vector3)Me.Location) < 45 * 45))
                return false;

            if (!iceStone.CanUseNow())
                return (await CommonCoroutines.MoveTo(iceStone.Location)).IsSuccessful();

            if (!GossipFrame.Instance.IsVisible)
            {
                await ScriptHelpers.StopMovingIfMoving();
                iceStone.Interact();
                return true;
            }
            GossipFrame.Instance.SelectGossipOption(0);
            return true;
        }
    }
}
