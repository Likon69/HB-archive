﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Threading.Tasks;
using Bots.DungeonBuddy.Attributes;
using Bots.DungeonBuddy.Enums;
using Bots.DungeonBuddy.Helpers;
using Bots.DungeonBuddy.Profiles;
using Buddy.Coroutines;
using CommonBehaviors.Actions;
using Styx;
using Styx.Common;
using Styx.Common.Helpers;
using Styx.CommonBot;
using Styx.CommonBot.Bars;
using Styx.CommonBot.Coroutines;
using Styx.CommonBot.Routines;
using Styx.Helpers;
using Styx.Pathing;
using Styx.Pathing.Avoidance;
using Styx.TreeSharp;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;

// ReSharper disable CheckNamespace

namespace Bots.DungeonBuddy.DungeonScripts.Legion
// ReSharper restore CheckNamespace
{

    #region Normal Difficulty

    public class AssaultOnVioletHold : Dungeon
    {
        #region Overrides of Dungeon

        public override uint DungeonId => 1208;

        public override Vector3 Entrance { get; } = new Vector3(-972.907f, 4308.964f, 739.7485f);

        public override Vector3 ExitLocation { get; } = new Vector3(4543.491f, 4014.875f, 83.6719f);

        public override void RemoveTargetsFilter(List<WoWObject> units)
        {
            units.RemoveAll(
                ret =>
                {
                    var unit = ret as WoWUnit;
                    if (unit == null)
                        return false;

                    return false;
                });
        }

        public override void IncludeTargetsFilter(List<WoWObject> incomingunits, HashSet<WoWObject> outgoingunits)
        {
            var isTank = Me.IsTank;
            var inDungeon = Me.MapId == LfgDungeon.MapId;

            foreach (var obj in incomingunits)
            {
                var unit = obj as WoWUnit;
                if (unit != null)
                {
                    if ((unit.Entry == MobId_ThoriumRocketChicken || unit.Entry == MobId_IceBlock ) && Me.IsDps)
                        outgoingunits.Add(unit);

                    // ensure tank picks up all mobs, regardless of range.
                    if (isTank && inDungeon && unit.IsHostile)
                        outgoingunits.Add(unit);

                    if (unit.Entry == MobId_TreasureGoblin)
                        outgoingunits.Add(unit);

                    if ((unit.Entry == MobId_FacelessTendril || unit.Entry == MobId_CongealedGoo) && !isTank && unit.Z < 80)
                    {
                        var maxRange = Me.IsRanged ? 35 : 20;
                        var pathInfo = Navigator.LookupPathInfo(unit);
                        if (pathInfo.Navigability == PathNavigability.Navigable &&
                            pathInfo.Distance <= maxRange)
                        {
                            outgoingunits.Add(unit);
                        }
                    }
                }
            }
        }

        public override void WeighTargetsFilter(List<Targeting.TargetPriority> units)
        {
            var isDps = Me.IsDps;

            foreach (var priority in units)
            {
                var unit = priority.Object as WoWUnit;
                if (unit != null)
                {
                    switch (unit.Entry)
                    {
                        case MobId_ThoriumRocketChicken:
                        case MobId_IceBlock:
                        case MobId_SpittingScarab:
                        case MobId_CongealedGoo:
                            priority.Score += isDps ? 5000: -5000;
                            break;

                        case MobId_ReinforcedThoriumRocketChicken:
                            priority.Score -= 5000;
                            break;

                        case MobId_WrathguardDecimator:
                        case MobId_ShadowBeast:
                            if (isDps)
                                priority.Score += 5000;
                            break;

                        case MobId_FacelessTendril:
                            PathInformation pathInfo;
                            var maxRange = Me.IsRanged ? 35 : 20;
                            if (isDps && unit.Z < 80 && (pathInfo = Navigator.LookupPathInfo(unit)).Navigability == PathNavigability.Navigable && pathInfo.Distance <= maxRange)
                            {
                                priority.Score += 5000;
                            }
                            else
                            {
                                priority.Score -= 500;
                            }
                            break;
                    }
                }
            }
        }

        public override void IncludeLootTargetsFilter(List<WoWObject> incomingunits, HashSet<WoWObject> outgoingunits)
        {
            foreach (var lootTarget in incomingunits)
            {
                var gObj = lootTarget as WoWGameObject;
                if (gObj != null && gObj.Entry == GameObjectId_MillificentsDiscardedLockbox &&  gObj.CanLoot &&
                    DungeonBuddySettings.Instance.LootMode != LootMode.Off)
                {
                    outgoingunits.Add(gObj);
                }
            }
        }

        private Composite _deathHook;
        public override void OnEnter()
        {            
            _deathHook = new ActionRunCoroutine(ctx => DeathHandler());
            TreeHooks.Instance.InsertHook("Dungeonbot_Main", 0, _deathHook);

            var displayPugGroupWarning = DungeonBuddySettings.Instance.PartyMode == PartyMode.Off ||
                                         (DungeonBuddySettings.Instance.PartyMode == PartyMode.Leader &&
                                          DungeonBuddySettings.Instance.PartyMembers.Count(
                                              s => !string.IsNullOrWhiteSpace(s)) < 4);

            if (displayPugGroupWarning)
            {
                Alert.Show(
                    "Dungeon not tested in PUGs",
                    $"{Name} dungeon has not been tested in PUGs so it's very important to not leave toon unattended",
                    15);
            }

        }

        public override void OnExit()
        {
            TreeHooks.Instance.RemoveHook("Dungeonbot_Main", _deathHook);
            _deathHook = null;
            _isBugged = false;
        }

        public override bool IsComplete
        {
            get
            {
                if (_isBugged)
                    return true;

                // extend the time when dungeon is complete to allow for killing the treasure goblin
                if (base.IsComplete)
                    return _treasureGoblinTimer.IsFinished;
                _treasureGoblinTimer.Reset();
                return false;
            }
            
        }

        #endregion

        #region Root

        private readonly WaitTimer _treasureGoblinTimer = new WaitTimer(TimeSpan.FromSeconds(30));

        private const uint MobId_TreasureGoblin = 116652;

        private readonly Vector3 _prisonCenter = new Vector3(4635.03f, 4013.459f, 77.96378f);

        private static LocalPlayer Me => StyxWoW.Me;

        private const uint MobId_LieutenantSinclari = 102278;
        private const uint MobId_TeleportationPortal = 102281;
        private const uint MobId_TeleportationPortal_Guarded = 102279;

        private readonly Vector3 _entranceArea = new Vector3(4589.105f, 4015.223f, 83.36134f);
        private WoWGameObject _prisonSeal;

        // <GameObject Name = "Prison Seal" Entry="247002" X="4566.874" Y="4015.322" Z="83.67188" />
        [ObjectHandler(247002, "Prison Seal", 150)]
        public Func<WoWGameObject, Task<bool>> PrisonSealBehavior()
        {
            var sinclariOriginalLocation = new Vector3(4577.135f, 4009.958f, 83.60803f);
            var doorLeftSide = new Vector3(4566.873f, 4019.966f, 83.67189f);
            var doorRightSide = new Vector3(4566.938f, 4010.313f, 83.96714f);
            var randomPointInsideRoom =
                WoWMathHelper.GetRandomPointInCircle(new Vector3(4575.295f, 4015.321f, 83.63346f), 2);

            return async seal =>
            {
                _prisonSeal = seal;
                if (Me.Location.IsPointLeftOfLine(doorRightSide, doorLeftSide))
                    return (await CommonCoroutines.MoveTo(randomPointInsideRoom, "Inside Room")).IsSuccessful();

                if (!Me.IsTank)
                    return false;

                var door = (WoWDoor)seal.SubObj;
                if (!door.IsClosed)
                {
                    // repair before we start..
                    if (Me.LowestDurabilityPercent <= 0.01)
                        return false;

                    var sinclari =
                        ObjectManager.GetObjectsOfType<WoWUnit>().FirstOrDefault(u => u.Entry == MobId_LieutenantSinclari && u.Location.DistanceSquared(sinclariOriginalLocation) < 1*1);

                    if (sinclari == null)
                        return false;

                    if (Me.GroupInfo.IsInParty &&
                        !GroupMember.GroupMembers.All(
                            g =>
                                g.MapId == LfgDungeon.MapId &&
                                !g.Location.IsPointLeftOfLine(doorRightSide, doorLeftSide)))
                    {
                        TreeRoot.StatusText = "Waiting for party members to zone in dungeon and move inside room";
                        return true;
                    }
                    return await ScriptHelpers.TalkToNpc(sinclari, 1, 1);
                }

                if (!Targeting.Instance.IsEmpty())
                    return false;
                var portal =
                    ObjectManager
                        .GetObjectsOfType<WoWUnit>()
                        .FirstOrDefault(u => (u.Entry == MobId_TeleportationPortal && u.HasAura("Portal Periodic Elite")) 
                            || (u.Entry == MobId_TeleportationPortal_Guarded && u.HasAura("Portal Periodic")));

                if (portal != null)
                {
                    if (portal.DistanceSqr > 5*5)
                    {
                        ScriptHelpers.SetLeaderMoveToPoi(portal.Location, portal.SafeName);
                        return false;
                    }
                    TreeRoot.StatusText = "Waiting for mobs to come through portal";
                    return true;
                }

                if (!LootTargeting.Instance.IsEmpty() || !Me.IsAlive)
                    return false;

                if (Me.Location.DistanceSquared(_prisonCenter) > 10 * 10)
                    return (await CommonCoroutines.MoveTo(_prisonCenter, "Room Center")).IsSuccessful();

                TreeRoot.StatusText = "Waiting for portal to spawn";
                return true;
            };
        }

        private bool _isBugged;

        [EncounterHandler(0, "Root Handler")]
        public Func<WoWUnit, Task<bool>> RootBehavior()
        {
            CapabilityManagerHandle handle = CapabilityManager.Instance.CreateNewHandle();

            return async npc =>
            {
                // If bosses are out and step 2 is not complete then leave because it's hard to complete dungeon.
                if (!_isBugged && Me.IsTank && ScenarioInfo.Current.CurrentStageNumber >= 1
                    && ScenarioInfo.Current.CurrentStageNumber <= 3
                    && !ScenarioInfo.Current.CurrentStage.GetCriteria(2).IsComplete
                    && Targeting.Instance.TargetList.Any(t => IsBoss(t.Entry))
                    && ObjectManager.GetObjectsOfType<WoWUnit>().Any(u => IsBoss(u.Entry) && u.CanSelect))
                {
                    _isBugged = true;
                    Logger.Write("Dungeon is considered complete because we can't continue due to boss and protals being up at same time");
                    if (Me.GroupInfo.IsInParty)
                        Lua.DoString("LeaveParty()");
                    return true;
                }
                return false;
            };
        }

        private async Task<bool> DeathHandler()
        {
            // never wait for a rez
            if (Me.IsDead && !Me.HasAura("Death Penalty"))
            {
                if (ScriptHelpers.IsViable(_prisonSeal) && ((WoWDoor)_prisonSeal.SubObj).IsClosed)
                {
                    var hostileMobs = ScriptHelpers.GetUnfriendlyNpsAtLocation(_entranceArea, 20, u => u.IsHostile);
                    if (hostileMobs.Count >= 8)
                    {
                        TreeRoot.StatusText = "Waiting for encounter to end. Overrun by adds";
                        return true;
                    }
                }

                Lua.DoString("RepopMe()");
                return true;
            }

            return false;
        }

        private HashSet<uint> _bossIds;

        private HashSet<uint> BossIds
            =>
                _bossIds ??
                (_bossIds = new HashSet<uint>(ProfileManager.CurrentProfile.BossEncounters.Select(b => b.Entry)));

        private bool IsBoss(uint mobId)
        {
            return BossIds.Contains(mobId);
        }

        #endregion

        #region Elite Legion Squad 

        private const uint MobId_BlazingInfernal = 102398;
        private const int SpellId_FelSlam = 205090;

        [EncounterHandler(MobId_BlazingInfernal, "Blazing Infernal")]
        public Func<WoWUnit, Task<bool>> BlazingInfernalHandler()
        {
            AddAvoidLine<WoWUnit>(() => !Me.IsTank, u => u.Location, u => u.RenderFacing, u => 30, u => 8, u => u.Entry == MobId_BlazingInfernal && u.CastingSpellId == SpellId_FelSlam);

            return async boss => false;
        }

        private const uint MobId_EredarShadowMender = 102400;
        private const uint MobId_InfiltratorAssassin = 102395;
        private const uint MobId_WrathlordBulwark = 102397;
        private const int SpellId_FelShieldBlast = 205081;

        [EncounterHandler(MobId_WrathlordBulwark, "Wrathlord Bulwark")]
        public Func<WoWUnit, Task<bool>> WrathlordBulwarkHandler()
        {
            AddAvoidLine<WoWUnit>(() => !Me.IsTank, u => u.Location, u => u.RenderFacing, u => 15, u => 8, u => u.Entry == MobId_WrathlordBulwark && u.CastingSpellId == SpellId_FelShieldBlast);

            return async boss => false;
        }

        private const uint MobId_WrathguardDecimator = 112741;
        [EncounterHandler(MobId_WrathguardDecimator, "Wrathguard Decimator")]
        public Func<WoWUnit, Task<bool>> WrathguardDecimatorHandler()
        {

            return async npc =>
            {
                var dispellTarget =
                    Me.RaidMembers.FirstOrDefault(
                        p =>
                            p.HasAura("Burning Wound", a => a.StackCount >= 5));


                if (dispellTarget != null &&
                    await  ScriptHelpers.DispelFriendlyUnit("Burning Wound", ScriptHelpers.PartyDispelType.Magic, dispellTarget))
                {
                    return true;
                }

                if (await ScriptHelpers.DispelGroup("Fel Dash", ScriptHelpers.PartyDispelType.Magic))
                    return true;

                if (await ScriptHelpers.DispelEnemy("Enrage", ScriptHelpers.EnemyDispelType.Enrage, npc))
                    return true;

                return false;
            };
        }

        private const uint MobId_ShadowyOverfiend = 112739;
        private const int MissileSpellId_CrushingShadows = 224613;
        private const int SpellId_ShadowSlash = 224607;

        [EncounterHandler(MobId_ShadowyOverfiend, "Shadowy Overfiend")]
        public Func<WoWUnit, Task<bool>> ShadowyOverfiendHandler()
        {
            AddAvoidLocation(() => true, 6, m => m.ImpactPosition, () => WoWMissile.InFlightMissiles.Where(m => m.SpellId == MissileSpellId_CrushingShadows));

            AddAvoidUnitCone(() => !Me.IsTank, 0, 6, 80, unit => unit.Entry == MobId_ShadowyOverfiend && unit.CastingSpellId == SpellId_ShadowSlash);

            return async npc => await ScriptHelpers.DispelGroup("Crushing Shadows", ScriptHelpers.PartyDispelType.Magic);
        }

        #endregion


        #region Portal Keepers

        private const uint MobId_PortalKeeperDreadlord = 102336;
        private const int SpellId_CarrionSwarm = 204901;
        private const int SpellId_VampiricCleave = 204947;

        [EncounterHandler(MobId_PortalKeeperDreadlord, "Portal Keeper-Dreadlord")]
        public Func<WoWUnit, Task<bool>> PortalGuardianJailorHandler()
        {
            AddAvoidUnitCone(() => !Me.IsTank, 0, 9, 90, unit => unit.Entry == MobId_PortalKeeperDreadlord && unit.CastingSpellId == SpellId_VampiricCleave);

            return async unit => await ScriptHelpers.InterruptCast(unit, SpellId_CarrionSwarm, SpellId_VampiricCleave);
        }

        private const uint AreaTriggerId_ViolentFelEnergy = 10745;
        private const uint MobId_PortalKeeperFelguard = 102302;
        private const int SpellId_FelDestruction = 204876;
        private const int SpellId_SoulSlash = 204895;
        private const int MissileSpellId_ThrowAxe = 204722;

        [EncounterHandler(MobId_PortalKeeperFelguard, "Portal Keeper-Felguard")]
        public Func<WoWUnit, Task<bool>> PortalKeeperFelguardHandler()
        {
            AddAvoidUnitCone(() => !Me.IsTank, 0, 11, 90, unit => unit.Entry == MobId_PortalKeeperFelguard && unit.CastingSpellId == SpellId_SoulSlash);
            AddAvoidLocation(() => true, 10, m => m.ImpactPosition, () => WoWMissile.InFlightMissiles.Where(m => m.SpellId == MissileSpellId_ThrowAxe));
            AddAvoidObject<WoWAreaTrigger>(10, AreaTriggerId_ViolentFelEnergy);

            return async unit => await ScriptHelpers.InterruptCast(unit, SpellId_FelDestruction);
        }

        #endregion


        #region Portal Guardians

        private const uint MobId_PortalGuardianInquisitor = 102337;
        private const int SpellId_ShieldofEyes = 204140;
        private const uint MobId_Eyebomb = 103146;

        [EncounterHandler(MobId_PortalGuardianInquisitor, "Portal Guardian-Inquisitor")]
        public Func<WoWUnit, Task<bool>> PortalGuardianInquisitorHandler()
        {
            AddAvoidObject<WoWAreaTrigger>(4, MobId_Eyebomb);

            return async unit => await ScriptHelpers.InterruptCast(unit, SpellId_ShieldofEyes);
        }

        private const uint AreaTriggerId_SoulVortex = 10712;
        private const int MissileSpellId_SoulVortex = 204462;
        private const uint MobId_PortalGuardianJailor = 102335;

        [EncounterHandler(MobId_PortalGuardianJailor, "Portal Guardian-Jailor")]
        public Func<WoWUnit, Task<bool>> PortalGuardianHandler()
        {
            AddAvoidObject<WoWAreaTrigger>(10, AreaTriggerId_SoulVortex);
            AddAvoidLocation(() => true, 10, m => m.ImpactPosition, () => WoWMissile.InFlightMissiles.Where(m => m.SpellId == MissileSpellId_SoulVortex));

            return async unit => await ScriptHelpers.DispelGroup("Soul Exhaustion", ScriptHelpers.PartyDispelType.Magic);
        }

        #endregion


        #region Prisoners

        #region Festerface

        private const uint MobId_Festerface = 101995;
        private const uint MobId_CongealedGoo = 102158;
        private const int SpellId_CongealingVomit = 201598;
        private const uint AreaTriggerId_Recongealing = 10476;

        [EncounterHandler(MobId_Festerface, "Festerface")]
        public Func<WoWUnit, Task<bool>> FesterfaceHandler()
        {
            AddAvoidObject<WoWAreaTrigger>(6, AreaTriggerId_Recongealing);
            AddAvoidUnitCone(() => true, 0, 40, 50,
                u => u.Entry == MobId_Festerface && u.CastingSpellId == SpellId_CongealingVomit);

            return async boss =>
            {
                if (Me.IsTank)
                {
                    var ickyGoo =
                        ObjectManager.GetObjectsOfType<WoWAreaTrigger>()
                            .Where(a => a.Entry == AreaTriggerId_Recongealing )
                            .OrderBy(a => a.DistanceSqr)
                            .FirstOrDefault();

                    if (ickyGoo != null)
                    {
                        return
                            await
                                ScriptHelpers.MoveOutOfLos(() => ScriptHelpers.IsViable(ickyGoo) && ScriptHelpers.IsViable(boss), boss.Location,
                                    ickyGoo.Location, 7);
                    }

                    return boss.CurrentTargetGuid == Me.Guid &&
                           await ScriptHelpers.TankUnitAtLocation(_prisonCenter, 10);
                }
                return false;
            };
        }

        #endregion

        #region Mindflayer Kaahrj

        private const uint MobId_MindflayerKaahrj = 101950;
        private const int SpellId_Hysteria = 201146;
        private const int MissileSpellId_ShadowCrash = 197783;
        private const uint AreaTriggerId_ShadowCrash = 10039;
        private const uint MobId_FacelessTendril = 101994;

        [EncounterHandler(MobId_MindflayerKaahrj, "Mindflayer Kaahrj")]
        public Func<WoWUnit, Task<bool>> MindflayerKaahrjHandler()
        {
            AddAvoidLocation(() => true, 5, m => m.ImpactPosition, () => WoWMissile.InFlightMissiles.Where(m => m.SpellId == MissileSpellId_ShadowCrash));
            AddAvoidObject<WoWAreaTrigger>(5, AreaTriggerId_ShadowCrash);
            return async boss =>
            {
                if (await ScriptHelpers.InterruptCast(boss, SpellId_Hysteria))
                    return true;

                return boss == Me.CurrentTarget && await ScriptHelpers.TankUnitAtLocation(_prisonCenter, 15);
            };
        }
        #endregion

        #region Millificent Manastorm

        private const uint MobId_MillificentManastorm = 101976;
        private const uint MobId_ElementiumSquirrelBomb = 102043;
        private const uint MobId_ThoriumRocketChicken = 102103;
        private const uint MobId_ReinforcedThoriumRocketChicken = 102139;
        private const uint GameObjectId_MillificentsDiscardedLockbox = 246430;
        private const int SpellId_RocketChickenRocket = 201369;

        [EncounterHandler(MobId_MillificentManastorm, "Millificent Manastorm")]
        public Func<WoWUnit, Task<bool>> MillificentManastormHandler()
        {
            WoWUnit millificentManastorm = null;

            // force range to spread out to reduce group damage from Mechanical Bomb Squirrels
            AddAvoidObject<WoWPlayer>(() => ScriptHelpers.IsViable(millificentManastorm) && millificentManastorm.Combat && Me.IsRanged, 15, player => player != Me );

            AddAvoidLine<WoWUnit>(() => ScriptHelpers.IsViable(millificentManastorm) && millificentManastorm.Combat,
                unit => unit.Location, unit => unit.RenderFacing, unit => 50, unit => 5,
                unit => (unit.Entry == SpellId_RocketChickenRocket || unit.Entry == MobId_ReinforcedThoriumRocketChicken) && unit.CastingSpellId == SpellId_RocketChickenRocket);

            return async boss =>
            {
                millificentManastorm = null;

                if (Me.IsDps || !Me.GroupInfo.IsInParty)
                {
                    WoWUnit squirrelBomb = null;
                    var squirrelBombs =
                        (from unit in ObjectManager.GetObjectsOfType<WoWUnit>()
                            where unit.Entry == MobId_ElementiumSquirrelBomb
                            let pathInfo = Navigator.LookupPathInfo(unit)
                            where pathInfo.Navigability == PathNavigability.Navigable
                            orderby pathInfo.Distance
                            select unit).ToList();
      

                    if (squirrelBombs.Any())
                    {
                        var dpsGroupMembers = GroupMember.GroupMembers.Where(g => g.IsDps).ToList();
                        squirrelBomb =
                            squirrelBombs.FirstOrDefault(
                                s =>
                                    !Me.GroupInfo.IsInParty ||
                                    dpsGroupMembers.OrderBy(p => p.Location.DistanceSquared(s.Location)).First().Guid ==
                                    Me.Guid);
                    }

                    if (squirrelBomb != null)
                        return await ScriptHelpers.InteractWithObject(squirrelBomb, 3500, true);
                }

                return false;
            };
        }

        [EncounterHandler(MobId_ThoriumRocketChicken, "Thorium Rocket Chicken")]
        public Func<WoWUnit, Task<bool>> ThoriumRocketChickenHandler()
        {
            return async boss => Me.IsDps && await ScriptHelpers.InterruptCast(boss, SpellId_RocketChickenRocket);
        }

        #endregion

        #region Shivermaw

        private const uint MobId_IceBlock = 102301;
        private const uint MobId_Shivermaw = 101951;
        private const int MissileSpellId_RelentlessStorm = 201848;
        private const int SpellId_FrostBreath = 201379;

        [EncounterHandler(MobId_Shivermaw, "Shivermaw", Mode= CallBehaviorMode.Proximity)]
        public Func<WoWUnit, Task<bool>> ShivermawHandler()
        {
            AddAvoidUnitCone(() => true, () => _prisonCenter, 30, 180, 30, 82, unit => unit.Entry == MobId_Shivermaw && unit.Combat && unit.Z < 84);
            AddAvoidUnitCone(() => !Me.IsTank, () => _prisonCenter, 30, 0, 30, 82, unit => unit.Entry == MobId_Shivermaw && unit.Combat && unit.Z < 84 && unit.CurrentTargetGuid != Me.Guid);
            AddAvoidLocation(() => !Me.IsTank, () => _prisonCenter, 30, 4, m => m.ImpactPosition, () => WoWMissile.InFlightMissiles.Where(m => m.SpellId == MissileSpellId_RelentlessStorm));

            var tankLoc = new Vector3(4604.799f, 4005.055f, 80.41222f);

            var airPhaseSafeLoc = new Vector3(4598.657f, 4016.511f, 83.3046f);

            return async boss =>
            {
                // return if boss is still in prison 
                if (!boss.Attackable || !boss.CanSelect)
                    return false;

                if (!boss.Combat)
                    return Me.IsTank &&  await ScriptHelpers.PullNpcToLocation(() => true, boss, tankLoc, 5000);

                var airPhase = boss.Z >= 84;
                // move off top part of prison to avoid taking damage from Frostbite during ground phase
                if (!airPhase && Me.Z > 82)
                {
                    if ((await CommonCoroutines.MoveTo(_prisonCenter)).IsSuccessful())
                        return true;

                    // Sometimes player gets stuck on wall after being knocked back
                    Navigator.PlayerMover.MoveTowards(_prisonCenter);
                    await Coroutine.Sleep(1000);
                    return true;
                }

                if (airPhase)
                {
                    return await ScriptHelpers.StayAtLocationWhile(() => ScriptHelpers.IsViable(boss) && boss.Z >= 84, airPhaseSafeLoc, "Safe Location", 5);
                }

                if (Me.RaidMembers.Any(p => p.HasAura("Frost Breath", a => a.StackCount >= 6) && boss.CastingSpellId != SpellId_FrostBreath))
                    return await ScriptHelpers.DispelGroup("Frost Breath", ScriptHelpers.PartyDispelType.Magic);



                return Me.HealthPercent > 60 && await ScriptHelpers.TankUnitAtLocation(tankLoc, 1);
            };
        }

        #endregion

        #region Anub'esset

        private const uint MobId_Anubesset = 102246;
        private const uint MobId_SpittingScarab = 102271;
        private const int SpellId_Impale = 202341;

        [EncounterHandler(MobId_Anubesset, "Anub'esset")]
        public Func<WoWUnit, Task<bool>> AnubessetHandler()
        {
            AddAvoidUnitCone(0, 60, 30,
                u => u.Entry == MobId_Anubesset && u.CastingSpellId == SpellId_Impale);
            return async boss => false;
        }

        #endregion

        #region Blood-Princess Thal'ena

        private const uint MobId_BloodPrincessThalena = 102431;
        private const uint AreaTriggerId_BloodSwarm = 10580;

        [EncounterHandler(MobId_BloodPrincessThalena, "Blood-Princess Thal'ena")]
        public Func<WoWUnit, Task<bool>> BloodPrincessThalenaHandler()
        {
            AddAvoidObject<WoWAreaTrigger>(4, AreaTriggerId_BloodSwarm);

            return async boss =>
            {
                if (Me.HasAura("Frenzied Bloodthirst"))
                {
                    var target =
                        Me.PartyMembers.Where(
                            p => !p.HasAura("Essence of the Blood Princess") && !p.HasAura("Frenzied Bloodthirst") && p.InLineOfSpellSight)
                            .OrderBy(p => p.DistanceSqr)
                            .FirstOrDefault();

                    if (target != null)
                    {
                        target.Target();
                        ActionBar.Active.Buttons[0].Use();
                        await Coroutine.Wait(1000, () => !Me.HasAura("Frenzied Bloodthirst"));
                        return true;
                    }

                }
                return false;
            };
        }

        #endregion

        #endregion


        #region Lord Malgath

        private const uint MobId_LordMalgath = 102282;
        private const uint MobId_ShadowBeast = 103561;
        private const uint AreaTriggerId_SeepingShadows = 10768;
        private const int SpellId_ShadowBoltVolley = 204963;

        [EncounterHandler(MobId_LordMalgath, "Lord Malgath")]
        public Func<WoWUnit, Task<bool>> LordMalgathHandler()
        {
            AddAvoidObject<WoWAreaTrigger>(3, AreaTriggerId_SeepingShadows);
            AddAvoidUnitCone(() => true, 0, 100, 30, u => u.Entry == MobId_LordMalgath && u.CastingSpellId == SpellId_FelSlash && u.CurrentTargetGuid != Me.Guid);

            return async boss =>
            {
                return await ScriptHelpers.InterruptCast(boss, SpellId_ShadowBoltVolley);
            };
        }

        #endregion

        #region Fel Lord Betrug

        private const uint MobId_FelLordBetrug = 102446;
        private const int SpellId_MightySmash = 202328;
        private const int SpellId_FelSlash = 203641;
        private const uint MobId_StasisCrystal = 103672;
        private const uint AreaTriggerId_Execution = 10787;

        [EncounterHandler(MobId_FelLordBetrug, "Fel Lord Betrug")]
        public Func<WoWUnit, Task<bool>> FelLordBetrugHandler()
        {
            WoWUnit felLordBetrug = null;

            // range should spread to avoid chaining the Chaotic Energy ability
            AddAvoidObject<WoWPlayer>(() => ScriptHelpers.IsViable(felLordBetrug) && Me.IsRanged && felLordBetrug.Combat && !felLordBetrug.HasAura("Execution"), 5, p => !p.IsMe);

            AddAvoidUnitCone(() => true, 0, 100, 30, u => u.Entry == MobId_FelLordBetrug && u.CastingSpellId == SpellId_FelSlash && u.CurrentTargetGuid != Me.Guid);

            AddAvoidObject<WoWAreaTrigger>(3, AreaTriggerId_Execution);
            var executionLoc = new Vector3(4673.193f, 4015.203f, 91.79407f);
            return async boss =>
            {
                felLordBetrug = boss;

                var crystal =
                    (from unit in ObjectManager.GetObjectsOfType<WoWUnit>()
                    where unit.Entry == MobId_StasisCrystal && !Blacklist.Contains(unit, BlacklistFlags.Interact)
                    let pathInfo = Navigator.LookupPathInfo(unit)
                    where pathInfo.Navigability == PathNavigability.Navigable
                    orderby pathInfo.Distance
                    select unit).FirstOrDefault();

                // We need to handle moving out of execution spot because Avoidance can't navigate out due to including the gameobject that enclose prisoner (I believe).
                if (boss.HasAura("Execution") && Me.Location.DistanceSquared(executionLoc) <= 3*3)
                {
                    Logger.Write("Moving away from execution location");
                    Navigator.PlayerMover.MoveTowards(boss.Location);
                    await Coroutine.Wait(3000, () => Me.Location.DistanceSquared(executionLoc) > 3 * 3);
                    return true;
                }

                if (crystal != null && !Me.HasAura("Execution "))
                {
                    if (!crystal.WithinInteractRange || !crystal.InLineOfSpellSight)
                    {
                        return (await CommonCoroutines.MoveTo(crystal.Location, crystal.SafeName)).IsSuccessful();
                    }

                    await CommonCoroutines.StopMoving();
                    Logger.Write($"Interacting with {crystal.SafeName}");
                    crystal.Interact();
                    Blacklist.Add(crystal, BlacklistFlags.Interact, TimeSpan.FromSeconds(3));
                    return true;
                }

                return false;
            };
        }
        #endregion

        #region Sael'orn

        private const uint MobId_Saelorn = 102387;
        private const uint MobId_PhaseSpider = 102434;

        [EncounterHandler(MobId_Saelorn, "Sael'orn", Mode = CallBehaviorMode.Proximity)]
        public Func<WoWUnit, Task<bool>> SaelornHandler()
        {
            AddAvoidUnitCone(() => !Me.IsTank, 0, 30, 60, u => u.Entry == MobId_Saelorn && u.Combat);
            var tankLoc = new Vector3(4625.53f, 4036.459f, 77.96375f);

            return async boss =>
            {
                // return if boss is still in prison 
                if (!boss.Attackable || !boss.CanSelect)
                    return false;

                var creepingSlaughter = Me.GetAuraByName("Creeping Slaughter");
                WoWUnit phaseSpider = creepingSlaughter != null ? ObjectManager.GetObjectByGuid<WoWUnit>(creepingSlaughter.CreatorGuid) : null;

                if (phaseSpider != null && !Me.IsSafelyFacing(phaseSpider, WoWMathHelper.DegreesToRadians(10)))
                {
                    if (!Me.IsTank && (Me.HealthPercent < 50 || Me.IsHealer))
                    {
                        phaseSpider.Face();
                        if (!Me.IsHealer)
                        {
                            Logger.Write("Facing towards spider until I get some heals");
                            await Coroutine.Wait(10000, () => Me.HealthPercent > 75);
                        }
                        return true;
                    }
                }
                if (!boss.Combat && Me.IsTank && await ScriptHelpers.PullNpcToLocation(() => true, boss, tankLoc, 5000))
                    return true;

                return await ScriptHelpers.TankUnitAtLocation(tankLoc, 5);
            };
        }

        #endregion

    }




    #endregion

    #region Heroic Difficulty

    public class AssaultOnVioletHoldHeroic : AssaultOnVioletHold
    {
        public override uint DungeonId => 1208;
    }

    #endregion
}