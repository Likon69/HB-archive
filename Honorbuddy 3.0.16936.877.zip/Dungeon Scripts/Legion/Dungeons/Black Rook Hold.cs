﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Threading.Tasks;
using Bots.DungeonBuddy.Attributes;
using Bots.DungeonBuddy.Enums;
using Bots.DungeonBuddy.Helpers;
using Bots.DungeonBuddy.Profiles;
using Buddy.Coroutines;
using CommonBehaviors.Actions;
using Styx;
using Styx.Common;
using Styx.Common.Helpers;
using Styx.CommonBot;
using Styx.CommonBot.Bars;
using Styx.CommonBot.Coroutines;
using Styx.CommonBot.Routines;
using Styx.Helpers;
using Styx.Patchables;
using Styx.Pathing;
using Styx.Pathing.Avoidance;
using Styx.TreeSharp;
using Styx.WoWInternals;
using Styx.WoWInternals.World;
using Styx.WoWInternals.WoWObjects;
using Styx.WoWInternals.WoWObjects.AreaTriggerShapes;

// ReSharper disable CheckNamespace

namespace Bots.DungeonBuddy.DungeonScripts.Legion
// ReSharper restore CheckNamespace
{

    #region Normal Difficulty
    public class BlackRookHold : Dungeon
    {
        #region Overrides of Dungeon

        public override uint DungeonId => 1204;

        public override Vector3 Entrance { get; } = new Vector3(3123.45f, 7562.829f, 31.61473f);

        public override Vector3 ExitLocation { get; } = new Vector3(3508.087f, 7650.085f, -7.543344f);

        public override void RemoveTargetsFilter(List<WoWObject> units)
        {
            var isMelee = Me.IsMelee;
            units.RemoveAll(
                ret =>
                {
                    var unit = ret as WoWUnit;
                    if (unit == null)
                        return false;

                    if (unit.Entry == MobId_IllysannaRavencrest && isMelee && unit.Z > 104)
                        return true;

                    if (unit.Entry == MobId_FelBatPup && !unit.Combat)
                        return true;

                    return false;
                });
        }

        public override void IncludeTargetsFilter(List<WoWObject> incomingunits, HashSet<WoWObject> outgoingunits)
        {
            var isTank = Me.IsTank;

            foreach (var obj in incomingunits)
            {
                var unit = obj as WoWUnit;
                if (unit != null)
                {

                }
            }
        }

        public override void WeighTargetsFilter(List<Targeting.TargetPriority> units)
        {
            var isDps = Me.IsDps;

            foreach (var priority in units)
            {
                var unit = priority.Object as WoWUnit;
                if (unit != null)
                {
                    switch (unit.Entry)
                    {
                        case MobId_ArcaneMinion:
                        case MobId_SoultornVanguard:
                            if (isDps)
                                priority.Score += 5000;
                            break;

                        case MobId_RisenArcanist:
                            if (isDps)
                                priority.Score += 4500;
                            break;

                        case MobId_RisenArcher:
                            if (isDps)
                                priority.Score += 4000;
                            break;

                        case MobId_GhostlyProtector:
                            if (isDps && unit.HasAura("Sacrifice Soul"))
                                priority.Score += 5000;
                            break;

                        case MobId_WyrmtongueScavenger:
                            if (isDps && unit.HasAura("Frenzy Potion"))
                                priority.Score += 5000;
                            break;
                    }
                }
            }
        }

        public override void IncludeLootTargetsFilter(List<WoWObject> incomingunits, HashSet<WoWObject> outgoingunits)
        {
            foreach (var lootTarget in incomingunits)
            {
                //var gObj = lootTarget as WoWGameObject;
                //if (gObj != null && gObj.Entry == GameObjectId_MillificentsDiscardedLockbox &&  gObj.CanLoot &&
                //    DungeonBuddySettings.Instance.LootMode != LootMode.Off)
                //{
                //    outgoingunits.Add(gObj);
                //}

            }
        }

        public override void OnEnter()
        {

            var displayPugGroupWarning = DungeonBuddySettings.Instance.PartyMode == PartyMode.Off ||
                                         (DungeonBuddySettings.Instance.PartyMode == PartyMode.Leader &&
                                          DungeonBuddySettings.Instance.PartyMembers.Count(
                                              s => !string.IsNullOrWhiteSpace(s)) < 4);

            if (displayPugGroupWarning)
            {
                Alert.Show(
                    "Dungeon not tested in PUGs",
                    $"{Name} dungeon has not been tested in PUGs so it's very important to not leave toon unattended",
                    15);
            }

        }
        
        public override async Task<bool> HandleMovement(MoveToParameters moveToParameters)
        {

            return false;
        }

        public override DungeonPathForkInfo[] PathForks { get; } = {
            new DungeonPathForkInfo(
                rightSideDivider: new Vector3(3359.504f, 7720.063f, -6.262749f),
                rightSideFromEntranceMoveTo: new Vector3(3337.708f, 7699.401f, -7.435966f),
                rightSideTowardsEntranceMoveTo: new Vector3(3382.493f, 7708.129f, -7.473053f),
                leftSideDivider: new Vector3(3368.672f, 7513.441f, 15.01807f),
                leftSideFromEntranceMoveTo:  new Vector3(3342.258f, 7515.013f, 14.83877f),
                leftSideTowardsEntranceMoveTo: new Vector3(3387.701f, 7522.753f, 14.74867f),
                shouldTakeRightSide: () => IsRightEntranceGateOpen)
        };

        public override DungeonStuckHandler[] StuckHandlers { get; } = {
            new BasicCtmStuckHandler(new Vector3(3195.8f, 7380.191f, 132.4526f), 6, 130, 135,
                new Vector3(3198.899f, 7376.898f, 129.7495f), "Top of some furniture before 3rd boss"),
            new JumpCtmStuckHandler(new Vector3(3193.267f, 7375.741f, 129.7495f), 2, 129, 130,
                new Vector3(3195.955f, 7372.166f, 131.4946f), "Corner behind of some furniture before 3rd boss"),
        };



        private class BasicCtmStuckHandler : DungeonStuckHandler
        {
            private readonly Vector3 _stuckLocation;
            private readonly float _stuckRadius, _stuckMinZ, _stuckMaxZ;

            public BasicCtmStuckHandler(Vector3 stuckLoc, float stuckRadius, float stuckMinZ, float stuckMaxZ,
                Vector3 unstickMoveTo, string name)
            {
                _stuckLocation = stuckLoc;
                _stuckRadius = stuckRadius;
                _stuckMinZ = stuckMinZ;
                _stuckMaxZ = stuckMaxZ;
                UnstickMoveTo = unstickMoveTo;
                StuckAreaName = name;
            }

            protected override bool IsStuck
                => StyxWoW.Me.Location.DistanceSquared(_stuckLocation) < _stuckRadius * _stuckRadius && StyxWoW.Me.Z >= _stuckMinZ && Me.Z < _stuckMaxZ;

            protected override Vector3 UnstickMoveTo { get; }
            protected override string StuckAreaName { get; }
        }

        private class JumpCtmStuckHandler : BasicCtmStuckHandler
        {
            public JumpCtmStuckHandler(Vector3 stuckLoc, float stuckRadius, float stuckMinZ, float stuckMaxZ,
                Vector3 unstickMoveTo, string name)
                : base(stuckLoc, stuckRadius, stuckMinZ, stuckMaxZ, unstickMoveTo, name)
            {
            }


            protected override async Task Unstick()
            {
                Navigator.PlayerMover.MoveTowards(UnstickMoveTo);
                WoWMovement.Move(WoWMovement.MovementDirection.Forward, 1000);
                WoWMovement.Move(WoWMovement.MovementDirection.JumpAscend, 1000);
                await Coroutine.Wait(1000, () => !IsStuck);
            }
        }

        #endregion

        #region Root

        private static bool IsRightEntranceGateOpen => ObjectManager.GetObjectsOfType<WoWGameObject>()
            .Any(g => g.Entry == GameObjectId_BlackrookHoldDungeonEntranceRightDoor && !((WoWDoor)g.SubObj).IsClosed);

        private static LocalPlayer Me => StyxWoW.Me;

        private const uint GameObjectId_BlackrookHoldDungeonEntranceRightDoor = 252328;

        [EncounterHandler(0, "Root Handler")]
        public Func<WoWUnit, Task<bool>> RootBehavior()
        {
            return async npc =>
            {
                return false;
            };
        }


        #endregion

        #region Amalgam of Souls

        #region Trash

        #region Ghostly Councilor

        private const uint MobId_GhostlyCouncilor = 98370;
        private const int SpellId_DarkMending = 225573;

        [EncounterHandler(MobId_GhostlyCouncilor, "Ghostly Councilor")]
        public Func<WoWUnit, Task<bool>> GhostlyCouncilorHandler()
        {
            return async boss => await ScriptHelpers.InterruptCast(boss, SpellId_DarkMending);
        }

        #endregion

        #region Ghostly Retainer

        private const uint MobId_GhostlyRetainer = 98366;

        [EncounterHandler(MobId_GhostlyRetainer, "Ghostly Retainer")]
        public Func<WoWUnit, Task<bool>> GhostlyRetainerHandler()
        {
            return async boss =>
            {
                var soulBladeTarget = Me.RaidMembers.FirstOrDefault(r => r.HasAura("Soul Blade", a => a.StackCount > 1));
                if (soulBladeTarget != null 
                    && await ScriptHelpers.DispelFriendlyUnit("Soul Blade", ScriptHelpers.PartyDispelType.Magic, soulBladeTarget))
                {
                    return true;
                }
                return false;
            };
        }


        #endregion

        private const uint MobId_GhostlyProtector = 98368;

        #region Lady Velandras Ravencrest

        private const uint MobId_LadyVelandrasRavencrest = 98538;
        private const int SpellId_StrikeDown = 225732;

        [EncounterHandler(MobId_LadyVelandrasRavencrest, "Lady Velandras Ravencrest")]
        public Func<WoWUnit, Task<bool>> LadyVelandrasRavencrestHandler()
        {
            return async boss => boss.CastingSpellId == SpellId_StrikeDown && await ScriptHelpers.CastActiveMitigationSpell(boss);
        }

        #endregion

        #region Lord Etheldrin Ravencrest

        private const int SpellId_SpiritBlast = 196883;
        private const uint MobId_LordEtheldrinRavencrest = 98521;

        [EncounterHandler(MobId_LordEtheldrinRavencrest, "Lord Etheldrin Ravencrest")]
        public Func<WoWUnit, Task<bool>> LordEtheldrinRavencrestHandler()
        {
            // Soul Echo is handled in the "Amalgam of Souls" handler because that boss uses same ability.
            return async boss =>
            {
                if (await ScriptHelpers.InterruptCast(boss, SpellId_SpiritBlast))
                    return true;

                return false;
            };
        }

        #endregion

        #endregion



        private const uint MobId_AmalgamofSouls = 98542;
        private const uint MobId_SoulEchoesStalker = 99090;
        private const uint AreaTriggerId_SwirlingScythe = 9899;
        private const int SpellId_ReapSoul = 194956;
        private const int SpellId_SwirlingScythe = 195254;

        [EncounterHandler(MobId_AmalgamofSouls, "Amalgam of Souls", Mode = CallBehaviorMode.Proximity)]
        public Func<WoWUnit, Task<bool>> AmalgamofSoulsHandler()
        {
            WoWUnit amalgamOfSouls = null;

            var roomCenter = new Vector3(3251.346f, 7582.793f, 12.70161f);

            AddAvoidUnitCone(() => ScriptHelpers.IsViable(amalgamOfSouls) && amalgamOfSouls.Combat, 0, 20, 180,
                u =>
                    u.Entry == MobId_AmalgamofSouls &&
                    ((!Me.IsTank && !u.IsCasting && u.Combat) || u.CastingSpellId == SpellId_ReapSoul));

            AddAvoidObject<WoWAreaTrigger>(() => true, 4f, a => a.Entry == AreaTriggerId_SwirlingScythe);

            AddAvoidObject<WoWPlayer>(() => true, 4,
                p => !p.IsMe && (p.HasAura("Soul Echoes") || Me.HasAura("Soul Echoes")));

            AddAvoidObject<WoWUnit>(() => true,
                4,
                u => u.Entry == MobId_SoulEchoesStalker);

            WaitTimer swirlingScytheAvoidTimer = new WaitTimer(TimeSpan.FromSeconds(5));
            Vector3 swirlingScytheAvoidLoc = Vector3.Zero;

            AddAvoidObject<WoWUnit>(() => ScriptHelpers.IsViable(amalgamOfSouls) && amalgamOfSouls.Combat,
                4, u => u.Entry == MobId_AmalgamofSouls && u.CastingSpellId == SpellId_SwirlingScythe && u.CurrentTargetGuid == Me.Guid,
                u =>
                {
                    if (swirlingScytheAvoidTimer.IsFinished)
                    {
                        swirlingScytheAvoidTimer.Reset();
                        swirlingScytheAvoidLoc = Me.Location;
                    }
                    return swirlingScytheAvoidLoc;
                });

            var insideEntranceLeftLoc = WoWMathHelper.GetRandomPointInCircle(new Vector3(3272.427f, 7567.525f, 13.47805f), 2);
            var insideEntranceRightLoc = WoWMathHelper.GetRandomPointInCircle(new Vector3(3267.243f, 7601.732f, 13.55067f), 2);
            
            return async boss =>
            {
                amalgamOfSouls = boss;

                var pointInRoom = IsRightEntranceGateOpen ? insideEntranceRightLoc : insideEntranceLeftLoc;
                if (await ScriptHelpers.GetInsideCircularBossRoom(boss, roomCenter, 30, pointInRoom))
                    return true;

                if (!boss.Combat)
                    return false;

                if (await ScriptHelpers.TankFaceUnitAwayFromGroup(boss, 20))
                    return true;

                return false;
            };
        }

        #endregion

        #region Illysanna Ravencrest

        #region Trash

        #region Rook Spiderling

        private const uint MobId_RookSpiderling = 98677;

        [EncounterHandler(MobId_RookSpiderling, "Rook Spiderling")]
        public Func<WoWUnit, Task<bool>> RookSpiderlingHandler()
        {
            return async boss =>
            {
                var soulVenomTarget = Me.RaidMembers.FirstOrDefault(p => p.HasAura("Soul Venom", a => a.StackCount >= 3));
                if (soulVenomTarget != null &&
                    await ScriptHelpers.DispelFriendlyUnit("Soul Venom", ScriptHelpers.PartyDispelType.Magic, soulVenomTarget))
                    return true;

                return false;
            };
        }

        #endregion


        #region Risen Arcanist

        private const int SpellId_ArcaneBlitz = 200248;

        private const uint MobId_RisenArcanist = 98280;
        private const uint MobId_ArcaneMinion = 101549;

        [EncounterHandler(MobId_RisenArcanist, "Risen Arcanist")]
        public Func<WoWUnit, Task<bool>> RisenArcanistHandler()
        {
            return async boss => await ScriptHelpers.InterruptCast(boss, SpellId_ArcaneBlitz);
        }

        #endregion

        #region Risen Archer

        private const uint MobId_RisenArcher = 98275;
        private const int SpellId_ArrowBarrage = 200345;

        [EncounterHandler(MobId_RisenArcher, "Risen Archer")]
        public Func<WoWUnit, Task<bool>> RisenArcherHandler()
        {
            AddAvoidUnitCone(0, 40, 25, u => u.Entry == MobId_RisenArcher && u.CastingSpellId == SpellId_ArrowBarrage);
            return async boss => false;
        }

        #endregion

        #region Risen Companion
        private const uint MobId_RisenCompanion = 101839;

        [EncounterHandler(MobId_RisenCompanion, "Risen Companion")]
        public Func<WoWUnit, Task<bool>> RisenCompanionHandler()
        {
            AddAvoidObject<WoWPlayer>(() => true, 10,  p => !p.IsMe && (p.HasAura("Bloodthirsty Leap") || Me.HasAura("Bloodthirsty Leap")));
            return async boss => false;
        }
        #endregion

        #region Soul-Torn Champion

        private const uint MobId_SoulTornChampion = 98243;
        private const int SpellId_BonebreakingStrike = 200261;

        [EncounterHandler(MobId_SoulTornChampion, "Soul-Torn Champion")]
        public Func<WoWUnit, Task<bool>> SoulTornChampionHandler()
        {
            AddAvoidUnitCone(() => true, 0, 10, 40, u => u.Entry == MobId_SoulTornChampion && u.CastingSpellId == SpellId_BonebreakingStrike);

            return async boss => false; // await ScriptHelpers.TankFaceUnitAwayFromGroup(boss, 40);
        }

        #endregion

        #region Commander Shemdah'sohn

        private const uint MobId_CommanderShemdahsohn = 98706;

        [EncounterHandler(MobId_CommanderShemdahsohn, "Commander Shemdah'sohn", Mode = CallBehaviorMode.Proximity)]
        public Func<WoWUnit, Task<bool>> CommanderShemdahsohnHandler()
        {
            AddAvoidUnitCone(() => true, 0, 10, 40,
                u =>
                    (u.Entry == MobId_SoulTornChampion || u.Entry == MobId_CommanderShemdahsohn) &&
                    u.CastingSpellId == SpellId_BonebreakingStrike);
            
            var waitLoc = new Vector3(3114.332f, 7333.401f, 86.33187f);

            return async boss =>
            {
                if (Me.IsTank && Targeting.Instance.IsEmpty())
                {
                    if (!Navigator.AtLocation(waitLoc))
                        return (await CommonCoroutines.MoveTo(waitLoc)).IsSuccessful();

                    return true;
                }
                  
                if (!boss.Combat)
                    return false;

                return await ScriptHelpers.TankFaceUnitAwayFromGroup(boss, 40);
            };
        }

        #endregion

        //[LocationHandler(3137.916f, 7407.689f, 89.19984f, 20, "Illysanna Ravencrest Trash pull handler 1")]
        //public Func<Vector3, Task<bool>> RavencrestTrashHandler1()
        //{
        //    return async loc =>
        //    {
        //        if (!ScriptHelpers.IsBossAlive("Illysanna Ravencrest"))
        //            return false;
        //        if (!ScriptHelpers.GetUnfriendlyNpsAtLocation(loc, 30).Any())
        //            return false;
        //        Alert.Show("Add me", "Add trash pull handler", 20);
        //        await Coroutine.Sleep(20000);
        //        return true;
        //    };
        //}

        #endregion

        private const uint MobId_IllysannaRavencrest = 98696;
        private const uint MobId_IllysannaRavencrest_EyeBeam = 100436;

        private const int SpellId_VengefulShear = 197418;
        private const uint AreaTriggerId_DarkRush = 10067;
        private const uint AreaTriggerId_EyeBeams = 10093;

        readonly Vector3 _ravencrestRoomCenter = new Vector3(3086.324f, 7295.168f, 103.527f);



        [EncounterHandler(MobId_IllysannaRavencrest, "Illysanna Ravencrest", Mode = CallBehaviorMode.Proximity)]
        public Func<WoWUnit, Task<bool>> IllysannaRavencrestHandler()
        {
            WoWUnit ravencrest = null;

            AddAvoidPolygon(() => ScriptHelpers.IsViable(ravencrest) && ravencrest.Combat,null, 16,
                a => a.Rotation, a => 1, a => 30, a => ((AreaTriggerPolygon)a.Shape).Vertices,
                a => a.Location,
                () => ObjectManager.GetObjectsOfType<WoWAreaTrigger>().Where(a => a.Entry == AreaTriggerId_DarkRush));

            AddAvoidObject<WoWAreaTrigger>(() => true, null, 16, 1.5f, a => a.Entry == AreaTriggerId_EyeBeams);
            AddAvoidObject<WoWUnit>(() => true, null, 16, 4, a => a.Entry == MobId_IllysannaRavencrest_EyeBeam);
            
            // Avoid other players when targeted by the lazer beam so they don't need to move.
            AddAvoidObject<WoWPlayer>(() => Me.HasAura("Eye Beams"), 5, p => !p.IsMe);

            var entranceLeftEdge = new Vector3(3069.39f, 7286.261f, 103.3462f);
            var entranceRightEdge = new Vector3(3082.753f, 7276.526f, 103.2722f);
            var insideEntranceLoc = WoWMathHelper.GetRandomPointInCircle(new Vector3(3078.298f, 7284.911f, 103.527f), 3);

            return async boss =>
            {
                ravencrest = boss;
                if (await ScriptHelpers.MoveInsideBossRoom(boss, entranceLeftEdge, entranceRightEdge, insideEntranceLoc, u => Me.Z > 102))
                    return true;

                if (!boss.Combat || Me.Z < 100)
                    return false;

                if (boss.CastingSpellId == SpellId_VengefulShear && await ScriptHelpers.CastActiveMitigationSpell(boss))
                    return true;

                if (Me.HasAura("Dark Rush"))
                {
                    var darkRushPartyMembers =
                        Me.RaidMembers.Where(r => r.HasAura("Dark Rush"))
                            .OrderByDescending(r => r.MaxHealth)
                            .ToList();

                    // Stack up during Dark Rush to cause less Blazing Trail patches to be left on the ground.
                    if (darkRushPartyMembers.Count >= 2)
                    {
                        var myTargetLoc = darkRushPartyMembers[0] != Me
                            ? darkRushPartyMembers[0].Location
                            : darkRushPartyMembers[1].Location;

                        return
                            await
                                ScriptHelpers.StayAtLocationWhile(() => Me.HasAura("Dark Rush"), myTargetLoc,
                                    "Dark Rush Meetup", 1);
                    }
                }
                return false;
            };
        }

        private const uint MobId_SoultornVanguard = 100485;
        private const int SpellId_BonecrushingStrike = 197974;

        [EncounterHandler(MobId_SoultornVanguard, "Soul-torn Vanguard")]
        public Func<WoWUnit, Task<bool>> SoultornVanguardHandler()
        {
            AddAvoidUnitCone(() => true, () => _ravencrestRoomCenter, 16, 0, 20, 40,
                u => u.Entry == MobId_SoultornVanguard && (!Me.IsTank || u.CastingSpellId == SpellId_BonecrushingStrike));

            return async boss =>
            {
                return false;
            };
        }

        #endregion

        #region Smashspite the Hateful


        #region Trash

        private const uint MobId_Boulder = 111706;

        [EncounterHandler(0, "Boudler")]
        public Func<WoWUnit, Task<bool>> RockHandlerHandler()
        {
            var spirilStaircase1Center = new Vector3(3164.233f, 7313.524f, 106.1708f);
            var spirilStaircase2Center = new Vector3(3177.755f, 7386.8695f, 175.6295f);

            Vector2[] spirilStaircase1InnerAvoidPoly =
            {
                new Vector2(-7.724121f, -0.9389648f),
                new Vector2(-7.487061f, 2.864746f),
                new Vector2(-5.021973f, 6.170898f),
                new Vector2(-1.151123f, 7.983887f),
                new Vector2(2.953857f, 7.442871f),
                new Vector2(6.218018f, 5.102051f),
                new Vector2(7.887939f, 1.275879f),
                new Vector2(7.437988f, -2.904297f),
                new Vector2(4.970947f, -6.140137f),
                new Vector2(-2.756104f, -7.373047f),
                new Vector2(-4.693115f, -6.018066f),
                new Vector2(-9.466064f, -8.936035f),
                new Vector2(-5.540039f, -11.39014f),
                new Vector2(1.328857f, -12.56201f),
                new Vector2(8.226807f, -10.12012f),
                new Vector2(12.38086f, -5.006836f),
                new Vector2(13.48999f, 1.370117f),
                new Vector2(10.29199f, 7.605957f),
                new Vector2(5.366943f, 11.93701f),
                new Vector2(-1.35498f, 12.60498f),
                new Vector2(-7.064209f, 9.612793f),
                new Vector2(-11.38013f, 5.351074f),
                new Vector2(-12.28711f, -1.472168f),
                new Vector2(-10.11011f, -7.570313f),
                new Vector2(-6.280029f, -10.66504f),
            };

            Vector2[] spirilStaircase1OuterAvoidPoly =
            {
                new Vector2(-10.24609f, -14.43799f),
                new Vector2(-14.30811f, -11.53906f),
                new Vector2(-17.37598f, 1.995117f),
                new Vector2(-17.19019f, 6.641113f),
                new Vector2(-11.56714f, 14.354f),
                new Vector2(-2.85498f, 18.25391f),
                new Vector2(6.547852f, 17.28271f),
                new Vector2(14.2688f, 11.72705f),
                new Vector2(18.2168f, 2.991699f),
                new Vector2(17.2439f, -6.522949f),
                new Vector2(11.53589f, -13.10107f),
                new Vector2(2.366943f, -17.79004f),
                new Vector2(-1.241211f, -17.68896f),
                new Vector2(-8.330078f, -15.8623f),
                new Vector2(-5.406006f, -9.614258f),
                new Vector2(2.799805f, -11.92188f),
                new Vector2(7.652832f, -9.355957f),
                new Vector2(11.66382f, -4.579102f),
                new Vector2(11.98901f, 1.795898f),
                new Vector2(9.187012f, 6.963867f),
                new Vector2(4.574951f, 11.20801f),
                new Vector2(-1.36499f, 11.9751f),
                new Vector2(-7.040039f, 9.731934f),
                new Vector2(-11.15308f, 4.64502f),
                new Vector2(-11.62207f, -1.233887f),
                new Vector2(-9.969971f, -7.103027f),
                new Vector2(-6.294189f, -10.34521f),
            };

            Vector3[] staircase2RightSideRightPoints =  
            {
                new Vector3(3174.875f, 7397.498f, 194.9451f),
                new Vector3(3178.997f, 7397.991f, 193.968f),
                new Vector3(3184.332f, 7396.601f, 190.845f),
                new Vector3(3188.299f, 7392.689f, 187.718f),
                new Vector3(3189.76f, 7389.775f, 185.8544f),
                new Vector3(3189.615f, 7384.075f, 182.2784f),
                new Vector3(3186.313f, 7378.122f, 177.3021f),
                new Vector3(3181.092f, 7375.548f, 173.3369f),
                new Vector3(3176.527f, 7375.158f, 170.7047f),
                new Vector3(3170.397f, 7377.832f, 167.6799f),
                new Vector3(3167.474f, 7381.43f, 165.7504f),
                new Vector3(3166.019f, 7385.649f, 163.5206f),
                new Vector3(3166.281f, 7389.201f, 161.9643f),
                new Vector3(3167.945f, 7393.306f, 161.0799f),
                new Vector3(3173.169f, 7397.694f, 161.0528f),
                new Vector3(3178.268f, 7397.512f, 159.4683f),
                new Vector3(3185.744f, 7394.846f, 153.9596f),
                new Vector3(3187.414f, 7391.306f, 151.9064f),
                new Vector3(3187.941f, 7388.878f, 150.8948f),
                new Vector3(3188.138f, 7385.365f, 148.0357f),
                new Vector3(3187.149f, 7380.338f, 144.8004f),
                new Vector3(3181.865f, 7374.095f, 139.765f),
                new Vector3(3174.572f, 7374.911f, 137.794f),
                new Vector3(3167.763f, 7375.917f, 137.3014f),
            };

            Vector3[] staircase2RightSideLeftPoints =
            {
                new Vector3(3174.11f, 7403.449f, 194.9451f),
                new Vector3(3180.284f, 7403.858f, 194.0959f),
                new Vector3(3188.295f, 7401.115f, 190.9867f),
                new Vector3(3193.578f, 7395.557f, 187.8303f),
                new Vector3(3195.766f, 7389.866f, 185.9901f),
                new Vector3(3194.978f, 7381.37f, 182.4396f),
                new Vector3(3189.236f, 7372.874f, 177.4889f),
                new Vector3(3181.92f, 7369.598f, 173.5479f),
                new Vector3(3174.441f, 7369.523f, 170.8562f),
                new Vector3(3165.977f, 7373.763f, 167.8036f),
                new Vector3(3161.928f, 7379.12f, 165.8351f),
                new Vector3(3160.011f, 7385.703f, 163.6161f),
                new Vector3(3160.61f, 7391.187f, 162.0885f),
                new Vector3(3163.922f, 7397.769f, 161.0781f),
                new Vector3(3173.034f, 7403.701f, 161.0559f),
                new Vector3(3180.155f, 7403.214f, 159.6361f),
                new Vector3(3190.958f, 7397.828f, 154.0715f),
                new Vector3(3193.179f, 7392.996f, 152.0312f),
                new Vector3(3193.898f, 7389.646f, 150.9794f),
                new Vector3(3194.07f, 7384.419f, 148.2123f),
                new Vector3(3191.632f, 7376.339f, 144.9431f),
                new Vector3(3181.488f, 7368.099f, 139.9226f),
                new Vector3(3174.277f, 7368.91f, 137.892f),
                new Vector3(3167.154f, 7369.948f, 137.3014f),
            };

            Vector3[] staircase2LeftSideRightPoints =
            {
                new Vector3(3172.628f, 7393.509f, 195.5353f),
                new Vector3(3177.289f, 7393.198f, 194.8534f),
                new Vector3(3181.144f, 7392.357f, 190.9486f),
                new Vector3(3183.847f, 7390.077f, 186.7751f),
                new Vector3(3185.018f, 7386.804f, 183.6712f),
                new Vector3(3183.868f, 7383.112f, 178.7939f),
                new Vector3(3179.653f, 7381.112f, 173.2035f),
                new Vector3(3175.92f, 7380.773f, 169.4452f),
                new Vector3(3172.551f, 7382.361f, 166.9403f),
                new Vector3(3170.36f, 7384.084f, 164.6269f),
                new Vector3(3170.508f, 7387.05f, 162.9607f),
                new Vector3(3171.149f, 7390.754f, 161.1591f),
                new Vector3(3173.136f, 7393.857f, 161.1053f),
                new Vector3(3174.048f, 7395.258f, 161.0508f),
                new Vector3(3178.578f, 7393.374f, 159.2666f),
                new Vector3(3179.79f, 7392.985f, 157.121f),
                new Vector3(3181.956f, 7391.267f, 154.7414f),
                new Vector3(3183.58f, 7390.64f, 152.2309f),
                new Vector3(3184.588f, 7386.096f, 148.3226f),
                new Vector3(3183.346f, 7382.295f, 143.1183f),
                new Vector3(3180.012f, 7380.479f, 139.4395f),
                new Vector3(3175.836f, 7380.468f, 136.8356f),
                new Vector3(3173.388f, 7382.156f, 135.4323f),
                new Vector3(3169.62f, 7387.456f, 132.3166f),
                new Vector3(3165.443f, 7392.938f, 130.3435f),
            };

            Vector3[] staircase2LeftSideLeftPoints =
            {
                new Vector3(3172.962f, 7399.499f, 195.5353f),
                new Vector3(3178.545f, 7399.069f, 194.9945f),
                new Vector3(3185.113f, 7396.859f, 191.0991f),
                new Vector3(3189.634f, 7391.676f, 186.8941f),
                new Vector3(3190.566f, 7384.514f, 183.8162f),
                new Vector3(3186.535f, 7377.734f, 178.9639f),
                new Vector3(3180.263f, 7375.14f, 173.418f),
                new Vector3(3173.551f, 7375.257f, 169.613f),
                new Vector3(3168.253f, 7378.168f, 167.0799f),
                new Vector3(3164.357f, 7384.055f, 164.7691f),
                new Vector3(3164.564f, 7387.894f, 163.048f),
                new Vector3(3165.975f, 7393.8f, 161.1606f),
                new Vector3(3169.787f, 7398.841f, 161.1104f),
                new Vector3(3176.177f, 7400.872f, 161.0508f),
                new Vector3(3180.402f, 7399.092f, 159.4365f),
                new Vector3(3183.385f, 7397.792f, 157.2853f),
                new Vector3(3185.483f, 7396.124f, 154.8564f),
                new Vector3(3189.459f, 7391.854f, 152.3602f),
                new Vector3(3190.172f, 7383.895f, 148.5105f),
                new Vector3(3186.177f, 7377.001f, 143.319f),
                new Vector3(3179.999f, 7374.475f, 139.6171f),
                new Vector3(3172.597f, 7375.412f, 136.8987f),
                new Vector3(3168.608f, 7378.524f, 135.5288f),
                new Vector3(3164.995f, 7383.626f, 132.4095f),
                new Vector3(3160.67f, 7389.301f, 130.3435f),
            };

            Func<Vector3, Vector2[]> getSpiralStairCase1BoulderPoly = boulderLoc =>
            {
                var dist2DSqr = boulderLoc.Distance2DSquared(spirilStaircase1Center);

                if (dist2DSqr < 20 * 20)
                {
                    return dist2DSqr < 12 * 12
                        ? spirilStaircase1InnerAvoidPoly
                        : spirilStaircase1OuterAvoidPoly;
                }

                return null;
            };

            Func<Vector3, Vector3[], Vector3[], Vector2[]> generateStaircase2Poly = (loc, leftPoints, rightPoints) =>
            {
                int startI = 0, endI = leftPoints.Length -1;
                for (; startI < leftPoints.Length - 1 && leftPoints[startI + 1].Z > loc.Z; startI++) ;
                for (; endI > startI && leftPoints[endI - 1].Z < loc.Z - 8; endI--) ;

                // boulder is at end of path. 
                if (endI == startI)
                    startI --;

                var num = (endI - startI) + 1;
                Vector2[] ret = new Vector2[num * 2];

                int retI = 0;
                for (int i = startI; i <= endI; i++, retI++)
                {
                    ret[retI] = (leftPoints[i] - spirilStaircase2Center).ToVector2();

                    ret[ret.Length - 1 - retI] = (rightPoints[i] - spirilStaircase2Center).ToVector2();
                }
                return ret;
            };

            Func<Vector3, Vector2[]> getSpiralStairCase2BoulderPoly = boulderLoc =>
            {
                var dist2DSqr = boulderLoc.Distance2DSquared(spirilStaircase2Center);

                return dist2DSqr < 12 * 12
                    ? generateStaircase2Poly(boulderLoc, staircase2LeftSideLeftPoints, staircase2LeftSideRightPoints)
                    : generateStaircase2Poly(boulderLoc, staircase2RightSideLeftPoints, staircase2RightSideRightPoints);
            };

            // Handle Staircase 1
            AddAvoidPolygon(() => true,
                null, 40, u => 0, u => 1, u => 100, u => getSpiralStairCase1BoulderPoly(u.Location),
                u => spirilStaircase1Center,
                () => ObjectManager.GetObjectsOfType<WoWUnit>().Where(u =>
                {
                    if (u.Entry != MobId_Boulder)
                        return false;

                    var zDiff = u.Z - Me.Z;
                    return zDiff < 8 && zDiff > -1 && getSpiralStairCase1BoulderPoly(u.Location) != null;
                }));

            // Handle Staircase 2
            AddAvoidPolygon(() => true,
                null, 40, u => 0, u => 1, u => 30, u => getSpiralStairCase2BoulderPoly(u.Location),
                u =>
                {
                    var loc = spirilStaircase2Center;
                    // adjust Z coord in steps of 10. This is an optimization that lowers the number of times the avoidance is updated/reappled 
                    loc.Z = (int)u.Z / 10 * 10;
                    return loc;
                },
                () => ObjectManager.GetObjectsOfType<WoWUnit>().Where(u =>
                {
                    if (u.Entry != MobId_Boulder)
                        return false;

                    var zDiff = u.Z - Me.Z;
                    if (zDiff > 8 || zDiff < -1)
                        return false;

                    return u.Location.Distance2DSquared(spirilStaircase2Center) < 20*20;
                }));



            return async boss =>
            {
                return false;
            };
        }

        #region Wrathguard Bladelord

        private const uint MobId_WrathguardBladelord = 98810;
        private const int SpellId_BrutalAssault = 201139;

        [EncounterHandler(MobId_WrathguardBladelord, "Wrathguard Bladelord")]
        public Func<WoWUnit, Task<bool>> WrathguardBladelordHandler()
        {
            return async boss =>
            {
                if (boss.CastingSpellId == SpellId_BrutalAssault && await ScriptHelpers.CastActiveMitigationSpell(boss))
                    return true;

                if (await ScriptHelpers.DispelEnemy("Enrage", ScriptHelpers.EnemyDispelType.Enrage, boss))
                    return true;

                return false;
            };
        }

        #endregion

        #region Wyrmtongue Scavenger

        private const uint MobId_WyrmtongueScavenger = 98792;
        private const int SpellId_Indigestion = 200913;
        private const int SpellId_Hyperactive = 201063;
        private const int MissileSpellId_ThrowPricelessArtifact = 201176;

        [EncounterHandler(MobId_WyrmtongueScavenger, "Wyrmtongue Scavenger")]
        public Func<WoWUnit, Task<bool>> WyrmtongueScavengerHandler()
        {
            AddAvoidUnitCone(() => true, 0, 15, 25, u => u.Entry == MobId_WyrmtongueScavenger && u.CastingSpellId == SpellId_Indigestion);
            AddAvoidObject<WoWUnit>(() => true, 5, u => u.Entry == MobId_WyrmtongueScavenger && u.HasAura(SpellId_Hyperactive));

            AddAvoidLocation(() => true, 2, m => m.ImpactPosition,
                () => WoWMissile.InFlightMissiles.Where(m => m.SpellId == MissileSpellId_ThrowPricelessArtifact));

            return async boss => { return false; };
        }

        #endregion

        private const uint MobId_FelBatPup = 102781;
        private const uint MobId_FelspiteDominator = 102788;

        [LocationHandler(3175.934f, 7418.221f, 129.578f, 30, "Staircase 2 trash pull")]
        public Func<Vector3, Task<bool>> Staircase2TrashPull()
        {
            var trashLoc = new Vector3(3157.148f, 7397.811f, 129.7495f);

            return async loc =>
            {
                if (Me.Combat)
                    return false;

                var trash =
                    ScriptHelpers.GetUnfriendlyNpsAtLocation(trashLoc, 15, u => u.Entry == MobId_WrathguardBladelord)
                        .FirstOrDefault();

                if (trash != null 
                    && await ScriptHelpers.PullNpcToLocation(() => ScriptHelpers.IsViable(trash), trash, Me.IsTank? (Vector3?) loc : null, 5000, 2 ))
                {
                    return true;
                }
                return false;
            };
        }

        #endregion

        private const uint MobId_SmashspitetheHateful = 98949;
        private const int SpellId_FelBatFixate = 203164;
        private const uint AreaTriggerId_FelVomit = 10163;

        [EncounterHandler(MobId_SmashspitetheHateful, "Smashspite the Hateful")]
        public Func<WoWUnit, Task<bool>> SmashspitetheHatefulHandler()
        {
            var tankLoc = new Vector3(3294.445f, 7263.16f, 231.6067f);
            var vomitDropStart = new Vector3(3300.684f, 7266.904f, 231.5192f);
            var vomitDropEnd = new Vector3(3301.447f, 7293.337f, 231.5133f);

            AddAvoidObject<WoWAreaTrigger>(3, AreaTriggerId_FelVomit);

            return async boss =>
            {
                if (Me.HasAura(SpellId_FelBatFixate))
                {
                    var loc = Me.Location.GetNearestPointOnSegment(vomitDropStart, vomitDropEnd);
                    return await ScriptHelpers.StayAtLocationWhile(
                        () => Me.HasAura(SpellId_FelBatFixate), loc, "Fel Bat Vomit Drop");
                }

                // keep active mitigation active to slow down the boss's energy regeneration. 
                if (await ScriptHelpers.CastActiveMitigationSpell(boss))
                    return true;

                return await ScriptHelpers.TankUnitAtLocation(tankLoc, 10);
            };
        }


        #endregion

        #region Kur'talos Ravencrest

        #region Trash

        #region Risen Lancer

        private const uint MobId_RisenLancer = 102095;
        private const int SpellId_RavensDive = 214001;


        [EncounterHandler(MobId_RisenLancer, "Risen Lancer")]
        public Func<WoWUnit, Task<bool>> RisenLancerHandler()
        {
            // ToDO, find the target of the effect.
            return async boss =>
            {
                return false;
            };
        }

        #endregion

        #endregion


        private const uint MobId_KurtalosRavencrest = 98965;
        private const uint AreaTriggerId_WhirlingBlade = 10185;
        private const uint MobId_WhirlingBlade = 100861;

        [EncounterHandler(MobId_KurtalosRavencrest, "Kur'talos Ravencrest")]
        public Func<WoWUnit, Task<bool>> KurtalosRavencrestHandler()
        {
            AddAvoidLine<WoWUnit>(() => true, u => WoWMathHelper.CalculatePointBehind(u.Location, u.Rotation, 2),
                u => u.Rotation, u => 6, u => 4, u => u.Entry == MobId_WhirlingBlade);

            return async boss =>
            {
                return false;
            };
        }

        private const uint MobId_Latosius = 98970;
        private const uint MobId_ImageofLatosius = 101028;
        private const uint AreaTriggerId_CloudofHypnosis = 10200;
        private const int SpellId_DarkBlast = 198820;
        const int SpellId_DarkObliteration = 199567;

        private const int SpellId_CloudofHypnosis = 199143;

        [EncounterHandler(MobId_Latosius, "Latosius")]
        public Func<WoWUnit, Task<bool>> LatosiusHandler()
        {
            var cloudofHypnosisTimer = new WaitTimer(TimeSpan.FromSeconds(5));
            var cloudofHypnosisLoc = Vector3.Zero;

            AddAvoidObject<WoWAreaTrigger>(() => true, a => AvoidanceManager.IsRunningOutOfAvoid ? 6 : 4, u => u.Entry == AreaTriggerId_CloudofHypnosis);
            AddAvoidLine<WoWUnit>(() => true, u => u.Location, u => u.Rotation, u => 60, u => 17, 
                u => (u.Entry == MobId_Latosius && u.CastingSpellId == SpellId_DarkBlast ) || (u.Entry == MobId_ImageofLatosius && u.CastingSpellId == SpellId_DarkObliteration));

            AddAvoidObject<WoWUnit>(() => true, u => 5,
                u =>
                    u.Entry == MobId_Latosius && u.CastingSpellId == SpellId_CloudofHypnosis &&
                    u.CurrentTargetGuid == Me.Guid,
                u =>
                {
                    if (cloudofHypnosisTimer.IsFinished)
                    {
                        cloudofHypnosisLoc = Me.Location;
                        cloudofHypnosisTimer.Reset();
                    }
                    return cloudofHypnosisLoc;
                });

            return async boss =>
            {
                // ToDo find the target of this spell.
                if (boss.CastingSpellId == SpellId_CloudofHypnosis  && Me.IsTank)
                {
        
                }
                return false;
            };
        }
        #endregion

    }

    #endregion

    #region Heroic Difficulty

    public class BlackRookHoldHeroic : BlackRookHold
    {
        public override uint DungeonId => 1205;
    }

    #endregion

}