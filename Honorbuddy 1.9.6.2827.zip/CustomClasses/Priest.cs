using Styx;
using Styx.Combat.CombatRoutine;
using Styx.Helpers;
using Styx.Logic.Combat;
using Styx.Logic.Pathing;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;

#pragma warning disable
namespace Priest
{
    using Styx.Logic;
    using System;
    using System.Threading;
    using System.Diagnostics;
    using System.Collections.Generic;

    public class Priest : CombatRoutine
    {

        /*     ePriest      */
        /*Created by Erenion*/

        /*                  */
        /*Config Starts Here*/
        /*                  */

        //Combat Config
        int healHP = 40; //HP to heal self at (breaks shadowform)
        int hpDifferenceHeal = 30; //HP must be this much greater than mobs to ignore heal
        int renewHP = 60; //HP to use renew at (breaks shadowform)
        int minManaCombatBuffs = 30; //Min mana to use combat buffs at
        int shieldAddsNumber = 2; //Number of adds to use combat buffs at
        int shieldHP = 40; //Percent HP to force use shield at
        int manaPotionMP = 15; //MP to use MP pot at
        int hpPotionHP = 30; //HP to use HP pot at
        int psychicScreamNumAdds = 3; //Number of adds to use psychic scream at
        int shadowformCombatCast = 30; //Mana must be above this to use shadow form in combat
        int dispersionMP = 40; //Mana to use dispersion at
        bool useShadowWordPain = false; //If you want to use shadow word pain or not
        bool useSWPuntilLevel10 = true; //If you want to use shadow word pain until level 10 (overrides above setting)
        bool useSilence = true; //If you want to use silence or not
        bool useDevouringPlague = true; //If you want to use devouring plague or not
        int minShadowWordDeathHP = 50; //Min HP to use SWD at
        bool onlyUseSWDifShielded = false; //If you only want to use SWD when shielded
        bool shieldBeforeSWD = false; //If you want to cast shield before using SWD
        int shadowFiendEnemyHP = 65; //Enemy HP must be above this to use shadowfiend
        int shadowFiendMana = 50; // Use shadowfiend if mana is below this
        int shadowFiendAdds = 2; //Use shadow fiend if this many adds are on you (ignore current target's hp)
        int shadowFiendMyHP = 10; //Only use shadow fiend if your hp is above this
        int VTtargetHP = 50; //HP must be above this to use vamp touch again

        //Combat adds config (CURRENTLY DISABLED)
        bool useSWPonAdds = false; //If you would like to cast SWP on adds
        bool useDevoPlagueonAdds = false; //If you would like to cast devo plague on adds

        //Rest Config
        int restHP = 50; //HP to rest at
        int restMP = 35; //MP to rest at
        int healRestMPmore = 30; //How more your MP must be to heal before rest
        bool autoDetectDrink = true; //If you want ePriest to detect what drink to drink
        bool lookHostileMobs = true; //If you want to find and kill hostile mobs first
        int lookHostileMobDistance = 40; //Distance away they can be for you to choose them first



        //Misc config
        //bool autoUpdate = false; //If you want to autoupdate (will connect to www.gliderapps.com)

        public override string Name { get { return "ePriest v1.19"; } }

        public override WoWClass Class { get { return WoWClass.Priest; } }

        // Small wrappers for Logging.Write(...)
        #region Logging

        public void Log(string format)
        {
            if (format != "")
                Log(format, true);
        }

        public void Log(string format, bool name)
        {
            Logging.Write(format);
        }

        public void Log(string format, params object[] args)
        {
            Logging.Write(format, args);
        }

        #endregion

        /// Some variables used thruout the cc including settings
        #region Global variables

        private readonly LocalPlayer _me = ObjectManager.Me;
        private bool? _useDispersion;
        bool iAmPVPing;

        #endregion

        /// Some functions like:
        /// - spell cooldown tracking
        /// - check for wand
        #region misc functions

        private static bool IsPvPing()
        {
            return Battlegrounds.IsInsideBattleground;
        }

        private static Dictionary<string, DateTime> cooldownRecorder = new Dictionary<string, DateTime>();
        private static Dictionary<string, int> cooldownLengthRecorder = new Dictionary<string, int>();

        public static void addCooldown(string spellName, int cooldownLength)
        {
            if (cooldownRecorder.ContainsKey(spellName))
            {
                cooldownRecorder.Remove(spellName);
                cooldownLengthRecorder.Remove(spellName);
            }
            cooldownRecorder.Add(spellName, DateTime.Now);
            cooldownLengthRecorder.Add(spellName, cooldownLength);
        }
        public static bool isOnCooldown(string spellName)
        {
            if (cooldownLengthRecorder.ContainsKey(spellName))
            {
                TimeSpan timeCoolingDown = DateTime.Now - cooldownRecorder[spellName];
                if (cooldownLengthRecorder[spellName] > timeCoolingDown.Seconds)
                {
                    return true;
                }
                return false;
            }
            return false;
        }

        bool haveWandEquipped;
        private void HaveWandCheck()
        {
            Lua.DoString("textureWand = GetInventoryItemTexture(\"player\", 18)");
            string textureWand = Lua.GetLocalizedText("textureWand", _me.BaseAddress);
            if (textureWand == "nil")
            {
                haveWandEquipped = false;
            }
            else
            {
                haveWandEquipped = true;
            }
        }

        private List<WoWUnit> getAdds()
        {
            return Targeting.Instance.TargetList;

        }
        private int getAddsInt()
        {
            return Targeting.Instance.TargetList.Count;
        }

        #endregion

        /// Functions and properties associated with resting
        #region Rest

        public override bool NeedRest
        {
            get
            {
                iAmPVPing = IsPvPing();
                return _me.ManaPercent <= restMP || _me.HealthPercent <= restHP;
            }
        }

        public override void Rest()
        {
            WoWMovement.MoveStop();
            if (_me.CurrentMana > _me.CurrentHealth + healRestMPmore)
            {
                CastHeal();
            }
            if (_useDispersion.HasValue)
                SpellManager.CastSpell("Dispersion");
            if (autoDetectDrink)
            {
                string drinkName = detectDrink();
                if (drinkName != "")
                {
                    LevelbotSettings.Instance.DrinkName = drinkName;
                }
            }
            Styx.Logic.Common.Rest.Feed();


        }
        public string detectDrink()//Created by erenion
        {
            List<string> drinks = new List<string>();
            string drink;
            if (_me.Level >= 80)
            {
                drinks.Add("Conjured Mana Strudel");
                if ((drink = findItem(drinks)) != "")
                {
                    return drink;
                }
                drinks.Clear();
            }

            if (_me.Level >= 75)
            {
                drinks.Add("Black Jelly");
                drinks.Add("Crusader's Waterskin");
                drinks.Add("Honeymint Tea");
                drinks.Add("Kungaloosh");
                drinks.Add("Star's Sorrow");
                drinks.Add("Yeti Milk");
                if ((drink = findItem(drinks)) != "")
                {
                    return drink;
                }
                drinks.Clear();
            }

            if (_me.Level >= 74)
            {
                drinks.Add("Conjured Mana Pie");
                if ((drink = findItem(drinks)) != "")
                {
                    return drink;
                }
                drinks.Clear();
            }

            if (_me.Level >= 70)
            {
                drinks.Add("Bitter Plasma");
                drinks.Add("Fresh Apple Juice");
                drinks.Add("Fresh-Squeezed Limeade");
                drinks.Add("Grilled Bonescale");
                drinks.Add("Pungent Seal Whey");
                drinks.Add("Smoked Rockfin");
                if ((drink = findItem(drinks)) != "")
                {
                    return drink;
                }
                drinks.Clear();
            }
            if (_me.Level >= 65)
            {
                drinks.Add("Black Coffee");
                drinks.Add("Blackrock Fortified Water");
                drinks.Add("Conjured Glacier Water");
                drinks.Add("Conjured Mana Biscuit");
                drinks.Add("Dos Ogris");
                drinks.Add("Enriched Terocone Juice");
                drinks.Add("Ethermead");
                drinks.Add("Frostberry Juice");
                drinks.Add("Gilneas Sparkling Water");
                drinks.Add("Grizzleberry Juice");
                drinks.Add("Hot buttered Trout");
                drinks.Add("Mountain Water");
                drinks.Add("Naaru Ration");
                drinks.Add("Purified Draenic Water");
                drinks.Add("Sparkling Southshore Cider");
                drinks.Add("Star's Tears");
                drinks.Add("Sweetened Goat's Milk");
                if ((drink = findItem(drinks)) != "")
                {
                    return drink;
                }
                drinks.Clear();
            }
            if (_me.Level >= 60)
            {
                drinks.Add("Blackrock Mineral Water");
                drinks.Add("Conjured Mountain Spring Water");
                drinks.Add("Filtered Draenic Water");
                drinks.Add("Silverwine");
                if ((drink = findItem(drinks)) != "")
                {
                    return drink;
                }
                drinks.Clear();
            }
            if (_me.Level >= 55)
            {
                drinks.Add("Conjured Crystal Water");
                drinks.Add("Hyjal Nectar");
                drinks.Add("Star's Lament");
                if ((drink = findItem(drinks)) != "")
                {
                    return drink;
                }
                drinks.Clear();
            }
            if (_me.Level >= 51)
            {
                drinks.Add("Alterac Manna Biscuit");
                if ((drink = findItem(drinks)) != "")
                {
                    return drink;
                }
                drinks.Clear();
            }
            if (_me.Level >= 45)
            {
                drinks.Add("Blackrock Spring Water");
                drinks.Add("Conjured Sparkling Water");
                drinks.Add("Morning Glory Dew");
                if ((drink = findItem(drinks)) != "")
                {
                    return drink;
                }
                drinks.Clear();
            }
            if (_me.Level >= 35)
            {
                drinks.Add("Bottled Winterspring Water");
                drinks.Add("Conjured Mineral Water");
                drinks.Add("Moonberry Juice");
                if ((drink = findItem(drinks)) != "")
                {
                    return drink;
                }
                drinks.Clear();
            }
            if (_me.Level >= 25)
            {
                drinks.Add("Conjured Spring Water");
                drinks.Add("Enchanted Water");
                drinks.Add("Goldthorn Tea");
                drinks.Add("Sweet Nectar");
                if ((drink = findItem(drinks)) != "")
                {
                    return drink;
                }
                drinks.Clear();
            }
            if (_me.Level >= 15)
            {
                drinks.Add("Melon Juice");
                drinks.Add("Bubbling Water");
                drinks.Add("Conjured Purified Water");
                drinks.Add("Fizzy Faire Drink");
                if ((drink = findItem(drinks)) != "")
                {
                    return drink;
                }
                drinks.Clear();
            }
            if (_me.Level >= 5)
            {
                drinks.Add("Blended Bean Brew");
                drinks.Add("Conjured Fresh Water");
                drinks.Add("Ice Cold Milk");
                if ((drink = findItem(drinks)) != "")
                {
                    return drink;
                }
                drinks.Clear();
            }
            if (_me.Level >= 4)
            {
                drinks.Add("Green Tea Leaf");
                if ((drink = findItem(drinks)) != "")
                {
                    return drink;
                }
                drinks.Clear();
            }
            if (_me.Level >= 0)
            {
                drinks.Add("Conjured Water");
                drinks.Add("Refreshing Spring Water");
                drinks.Add("Snggin Root");
                if ((drink = findItem(drinks)) != "")
                {
                    return drink;
                }
                drinks.Clear();
            }
            return "";
        }
        private string findItem(List<string> drinks)//Created by erenion
        {
            foreach (WoWItem item in ObjectManager.GetObjectsOfType<WoWItem>())
            {
                foreach (string drink in drinks)
                {
                    if (drink == item.Name)
                    {
                        return drink;
                    }
                }
            }
            return "";
        }

        #endregion

        /// Functions and properties associated with buffs prior to combat
        /// This is regular buffs like Mark of the Wild, PW: Fortitude, Thorns etc..
        #region Pre Combat Buffs

        public override bool NeedPreCombatBuffs
        {

            get
            {
                if(_me.Mounted)
                    return false;

                bool needBuff = false;
                if (!_me.Buffs.ContainsKey("Power Word: Fortitude") && !_me.Buffs.ContainsKey("Prayer of Fortitude") && SpellManager.CanCastSpell("Power Word: Fortitude"))
                {
                    needBuff = true;
                }
                if (!_me.Buffs.ContainsKey("Inner Fire") && SpellManager.CanCastSpell("Inner Fire"))
                {
                    needBuff = true;
                }
                if (!_me.Buffs.ContainsKey("Divine Spirit") && !_me.Buffs.ContainsKey("Prayer of Spirit") && !_me.Buffs.ContainsKey("Fel Intelligence") && SpellManager.CanCastSpell("Divine Spirit"))
                {
                    needBuff = true;
                }
                if (!_me.Buffs.ContainsKey("Vampiric Embrace") && SpellManager.CanCastSpell("Vampiric Embrace"))
                {
                    needBuff = true;
                }
                return needBuff;
            }
        }


        public override void PreCombatBuff()
        {
            if (SpellManager.CanCastSpell("Power Word: Fortitude") && !_me.Buffs.ContainsKey("Power Word: Fortitude") && !_me.Buffs.ContainsKey("Prayer of Fortitude"))
            {
                PowerWordFortitude();
                Log("Casting Power Word: Fortitude");
            }

            if (SpellManager.CanCastSpell("Inner Fire") && !_me.Buffs.ContainsKey("Inner Fire"))
            {
                InnerFire();
                Log("Casting Inner Fire");
            }

            if (SpellManager.CanCastSpell("Divine Spirit") && !_me.Buffs.ContainsKey("Prayer of Spirit") && !_me.Buffs.ContainsKey("Divine Spirit") && !_me.Buffs.ContainsKey("Fel Intelligence"))
            {
                DivineSpirit();
                Log("Casting Divine Spirit");
            }

            if (SpellManager.CanCastSpell("Vampiric Embrace") && !_me.Buffs.ContainsKey("Vampiric Embrace"))
            {
                VampiricEmbrace();
                Log("Casting Vampiric Embrace");
            }
        }

        #endregion

        /// Functions and properties associated with combat buffs
        /// this logic will be ran once you enter combat. Put any defensive type buffs here ie.
        /// Power Word: Shield
        #region Combat Buffs

        public override bool NeedCombatBuffs { get { return false; } }

        public override void CombatBuff()
        {
            if (!_me.Buffs.ContainsKey("Power Word: Shield") && !_me.Buffs.ContainsKey("Prayer of Fortitude") && (getAddsInt() >= shieldAddsNumber || shieldHP > _me.HealthPercent))
            {
                if (PowerWordShield())
                {
                    Log("Casting Power Word: Shield");
                }
            }

            if (_me.Shapeshift != ShapeshiftForm.Shadow && SpellManager.CanCastSpell("Shadowform"))
            {
                if (_me.Shapeshift != ShapeshiftForm.Shadow)
                    SpellManager.CastSpell("Shadowform");
            }


        }

        #endregion

        /// Put any healing code here. this state isnt implemented yet but soon to come :)
        #region Heal

        public override bool NeedHeal
        {
            get
            {
                if (_me.HealthPercent < healHP)
                {
                    if (_me.HealthPercent - hpDifferenceHeal > _me.CurrentTarget.HealthPercent)
                    {
                        if (getAddsInt() > 1)
                        {
                            return true;
                        }
                    }
                    else
                    {
                        return true;
                    }
                }
                return false;
            }
        }

        public override void Heal()
        {
            if (SpellManager.CastSpell("Power Word: Shield"))
            {
                PowerWordShield();
            }
        }

        public void CastHeal()
        {
            var level = _me.Level;

            if (level >= 40 && SpellManager.CanCastSpell("Greater Heal") && _me.HealthPercent > 30)
            {
                GreaterHeal();
            }
            else if (level >= 16 && SpellManager.CanCastSpell("Heal") && _me.HealthPercent > 30)
            {
                _Heal();
            }
            else if (SpellManager.CanCastSpell("Flash Heal"))
            {
                flashHeal();
            }
            else if (SpellManager.CanCastSpell("Lesser Heal"))
            {
                LesserHeal();
            }

            checkShadowFormCombat();
        }

        #endregion

        /// Determination of mana pot usage is done here:
        #region Potions

        public bool needManaPotion { get { return manaPotionMP > _me.ManaPercent && !isOnCooldown("Potion") && !isOnCooldown("MP Potion"); } }

        public void manaPot()
        {
            List<string> manaPotNames = new List<string>()
            {
                "Endless Mana Potion",
                "Argent Mana Potion",
                "Auchenai Mana Potion",
                "Crystal Mana Potion",
                "Greater Mana Potion",
                "Icy Mana Potion",
                "Lesser Mana Potion",
                "Major Mana Potion",
                "Mana Potion",
                "Mana Potion Injector",
                "Minor Mana Potion",
                "Runic Mana Potion",
                "Super Mana Potion",
                "Superior Mana Potion",
                "Unstable Mana Potion"
            };

            foreach (WoWItem item in ObjectManager.GetObjectsOfType<WoWItem>())
            {
                foreach (string potion in manaPotNames)
                {
                    if (potion == item.Name)
                    {
                        Lua.DoString("UseItemByName(\"" + potion + "\")");
                        Log("Using " + potion + "!", true);
                        addCooldown("Potion", 120);
                        return;
                    }
                }
            }

            addCooldown("MP Potion", 120);
        }

        public bool needHPPotion { get { return hpPotionHP > _me.HealthPercent && !isOnCooldown("Potion") && !isOnCooldown("HP Potion"); } }

        public void hpPot()
        {
            List<string> hpPotNames = new List<string>()
            {
                "Endless Healing Potion",
                "Argent Healing Potion",
                "Auchenai Healing Potion",
                "Crystal Healing Potion",
                "Discolored Healing Potion",
                "Greater Healing Potion",
                "Healing Potion",
                "Healing Potion Injector",
                "Lesser Healing Potion",
                "Major Combat Healing Potion",
                "Major Healing Potion",
                "Minor Healing Potion",
                "Resurgent Healing Potion",
                "Runic Healing Potion",
                "Super Healing Potion",
                "Superior Healing Potion",
                "Volatile Healing Potion"
            };

            foreach (WoWItem item in ObjectManager.GetObjectsOfType<WoWItem>())
            {
                foreach (string potion in hpPotNames)
                {
                    if (potion == item.Name)
                    {
                        Lua.DoString("UseItemByName(\"" + potion + "\")");
                        Log("Using " + potion + "!", true);
                        addCooldown("Potion", 120);
                        return;
                    }
                }
            }
            addCooldown("HP Potion", 120);
        }
        #endregion

        /// Pet any buffs here that prior to pulling ie. Horn of Winter for deathknights
        #region Pull Buffs

        public override bool NeedPullBuffs
        {
            get
            {
                if (SpellManager.CanCastSpell("Shadowform") && _me.Shapeshift != ShapeshiftForm.Shadow)
                {
                    return true;
                }
                return false;
            }
        }

        public override void PullBuff()
        {
            if (SpellManager.CanCastSpell("Shadowform") && _me.Shapeshift != ShapeshiftForm.Shadow)
            {
                SpellManager.CastSpell("Shadowform");
            }
        }

        #endregion

        /// Pull logic here for approaching and engaging target's in combat
        #region Pull

        private readonly Stopwatch _pullTimer = new Stopwatch();

        public override void Pull()
        {

            if (!_pullTimer.IsRunning)
                _pullTimer.Start();

            if (_me.CurrentTarget != null)
            {
                if (_me.CurrentTarget.Distance > 100)
                {
                    return;
                }
                WoWUnit closestHostile = _me.CurrentTarget; ;
                if (lookHostileMobs)
                {
                    List<WoWUnit> mobList = ObjectManager.GetObjectsOfType<WoWUnit>(false);
                    if (mobList.Count > 0)
                        foreach (WoWUnit thing in mobList)
                        {
                            try
                            {
                                if (!thing.PvpFlagged && thing.InLineOfSight && !thing.Tagged && thing.Guid != _me.Guid && thing.IsHostile && thing.IsAlive && thing.Distance < lookHostileMobDistance && (thing.Distance + 5 < closestHostile.Distance || !closestHostile.IsHostile))
                                {
                                    closestHostile = thing;
                                }
                            }
                            catch (Exception ex)
                            {
                                Logging.WriteException(ex);
                            }
                        }
                    if (_me.CurrentTarget != closestHostile)
                    {
                        closestHostile.Target();
                        Log("Switching current target {0} to closest hostile target {1}", _me.CurrentTarget.Name, closestHostile.Name);
                    }
                }

                Log("Killing {0} at distance {1}",
                    closestHostile.Name,
                    Math.Floor(closestHostile.Distance)
                    );

                if (closestHostile.Distance >= 30 && !_me.Combat && _pullTimer.Elapsed.Seconds <= 25)
                {
                    Navigator.MoveTo(closestHostile.Location);
                    Thread.Sleep(100);
                    return;
                }

                if (_pullTimer.Elapsed.Seconds > 25)
                {
                    Log("Blacklisting {0}", closestHostile.Name);
                    Blacklist.Add(closestHostile != null ? closestHostile.CurrentTargetGuid : 0, TimeSpan.FromMinutes(15));

                    _me.ClearTarget();
                    _pullTimer.Reset();
                    return;
                }

                _pullTimer.Reset();
                WoWMovement.MoveStop();
                Thread.Sleep(100);
                closestHostile.Face();
                Thread.Sleep(100);


                if (SpellManager.KnownSpells.ContainsKey("Vampiric Touch") && _me.CurrentTarget.HealthPercent > VTtargetHP)
                {
                    if (!_me.CurrentTarget.Buffs.ContainsKey("Vampiric Touch") && !iAmPVPing)
                    {
                        SpellManager.CastSpell("Vampiric Touch");
                        Log("Casting Vampiric Touch");
                        return;
                    }
                    else if (!_me.CurrentTarget.Buffs.ContainsKey("Devouring Plague") && useDevouringPlague && SpellManager.CanCastSpell("Devouring Plague"))
                    {
                        SpellManager.CastSpell("Devouring Plague");
                        Log("Casting Devouring Plague");
                        return;
                    }
                }
                if (_me.Shapeshift != ShapeshiftForm.Shadow && SpellManager.CanCastSpell("Holy Fire"))
                {
                    SpellManager.CastSpell("Holy Fire");
                    Log("Casting Holy Fire");
                }
                else if (SpellManager.KnownSpells.ContainsKey("Mind Blast"))
                {
                    if (MindBlast())
                        Log("Casting Mind Blast");
                }
                else
                {
                    if (Smite())
                        Log("Casting Smite");
                }
            }
        }

        #endregion

        /// For handling falling, not implemented yet tho :(
        #region Falling

        public void HandleFalling()
        {
            if (SpellManager.CanCastSpell("Levitate"))
            {
                SpellManager.CastSpell("Levitate");
            }
        }

        #endregion

        /// Oh yummy, here's the actual code that get's run in combat when you have a target.
        #region Combat

        public override void Combat()
        {
            if (!Targeting.Instance.TargetList.Contains(_me.CurrentTarget) && Targeting.Instance.TargetList.Count > 0)
            {
                Targeting.Instance.TargetList[0].Target();
            }
            if (_me.CurrentTarget.Distance > 30 && iAmPVPing)
            {
                Navigator.MoveTo(_me.CurrentTarget.Location);
                Thread.Sleep(100);
                return;
            }
            else
            {
                WoWMovement.MoveStop();
            }

            if (_me.GotAlivePet)
            {
                if (_me.Pet.CurrentTarget != _me.CurrentTarget)
                {
                    Lua.DoString("PetAttack()");
                }
            }

            if (!_me.GotTarget && Targeting.Instance.TargetList.Count > 0)
            {
                Targeting.Instance.TargetList[0].Target();
            }

            if (_useDispersion == null)
            {
                _useDispersion = SpellManager.KnownSpells.ContainsKey("Dispersion");
            }

            if (needHPPotion)
            {
                hpPot();
            }

            if (needManaPotion)
            {
                manaPot();
            }

            if (renewHP > _me.HealthPercent && SpellManager.CanCastSpell("Renew") && !_me.Buffs.ContainsKey("Renew"))
            {
                SpellManager.CastSpell("Renew");
            }

            if (NeedHeal)
            {
                Heal();
            }

            if (iAmPVPing)
            {
                if (!_me.CurrentTarget.IsPlayer)
                {
                    List<WoWUnit> mobList = ObjectManager.GetObjectsOfType<WoWUnit>(false);
                    foreach (WoWUnit wu in mobList)
                    {
                        if (wu.Distance < 20 && wu.IsPlayer && wu.IsHostile)
                        {
                            wu.Target();
                            break;
                        }
                    }
                }
                WoWMovement.MoveStop();
                WoWMovement.Face();
            }

            if (_me.CurrentTarget != null)
            {

                var spell = DecideSpell();

                WoWMovement.Face();

                if (spell != "" && (!_me.Stunned && !_me.Possessed && !_me.Pacified && !_me.Aggro))
                {
                    if ((spell == "Shoot" || spell == "Attack") && _me.IsAutoAttacking)
                        return;

                    Log("Casting {0}", spell);
                    SpellManager.CastSpell(spell);
                    if (spell == "Shadowfiend")
                    {
                        Thread.Sleep(100);
                        Lua.DoString("PetAttack()");
                    }

                }
                else if (_me.Stunned || _me.Possessed || _me.Pacified || _me.Dazed)
                {
                    if (SpellManager.CanCastSpell("Every Man for Himself"))
                    {
                        Log("Casting {0}", "Every Man for Himself");
                        SpellManager.CastSpell("Every Man for Himself");
                    }
                }

            }
        }
        private string DecideSpell()
        {
            if (_me.ManaPercent <= dispersionMP && SpellManager.CanCastSpell("Dispersion"))
            { return "Dispersion"; }

            checkShadowFormCombat();

            if (_me.CurrentTarget != null)
            {

                //if (_me.CurrentTarget != Targeting.TargetList[0] && !iAmPVPing)
                //{

                //    if (Targeting.TargetList[0].Distance < 30 && (!checkNeedAddCast("Devouring Plague", false) && useDevoPlagueonAdds) && (!checkNeedAddCast("Shadow Word: Pain", false) && useSWPonAdds) && !iAmPVPing)
                //    {
                //        Targeting.TargetList[0].Target();
                //    }

                //}

                if (!GotDebuff("Psychic Scream") && SpellManager.CanCastSpell("Psychic Scream") && _me.CurrentTarget.Distance <= 5f && (getAddsInt() >= psychicScreamNumAdds || IsPvPing()))
                {
                    return "Psychic Scream";
                }

                if (_me.CurrentTarget.IsCasting && SpellManager.CanCastSpell("Silence") && useSilence)
                {
                    return "Silence";
                }

                if (SpellManager.CanCastSpell("Shadowfiend") && (_me.CurrentTarget.HealthPercent > shadowFiendEnemyHP || getAddsInt() >= shadowFiendAdds) && _me.ManaPercent < shadowFiendMana && _me.HealthPercent > shadowFiendMyHP)
                {
                    return "Shadowfiend";
                }

                if (!GotDebuff("Vampiric Touch") && SpellManager.CanCastSpell("Vampiric Touch") && _me.CurrentTarget.HealthPercent > VTtargetHP && !iAmPVPing)
                {
                    return "Vampiric Touch";
                }

                if (_me.CurrentTarget.CreatureType != WoWCreatureType.Mechanical && !GotDebuff("Devouring Plague") && SpellManager.CanCastSpell("Devouring Plague") && useDevouringPlague)
                {
                    return "Devouring Plague";
                }

                if ((!GotDebuff("Shadow Word: Pain") && SpellManager.CanCastSpell("Shadow Word: Pain")) && (useShadowWordPain || (useSWPuntilLevel10 && _me.Level < 10)))
                {
                    return "Shadow Word: Pain";
                }

                if (checkNeedAddCast("Devouring Plague", true) && useDevoPlagueonAdds)
                {
                    return "Devouring Plague";
                }

                if (checkNeedAddCast("Shadow Word: Pain", true) && useSWPonAdds)
                {
                    return "Shadow Word: Pain";
                }

                if (!GotDebuff("Psychic Horror") && SpellManager.CanCastSpell("Psychic Horror"))
                {
                    return "Psychic Horror";
                }

                if (SpellManager.CanCastSpell("Mind Blast"))
                {
                    return "Mind Blast";
                }

                if (SpellManager.CanCastSpell("Shadow Word: Death") && minShadowWordDeathHP < _me.HealthPercent)
                {
                    if (shieldBeforeSWD)
                    {
                        SpellManager.CastSpell("Power Word: Shield");
                    }
                    if (onlyUseSWDifShielded && _me.Buffs.ContainsKey("Power Word: Shield") || !onlyUseSWDifShielded)
                    {
                        return "Shadow Word: Death";
                    }
                }

                if (_me.Shapeshift != ShapeshiftForm.Shadow)
                {
                    if (SpellManager.CanCastSpell("Holy Fire"))
                        return "Holy Fire";

                    if (SpellManager.CanCastSpell("Smite"))
                        return "Smite";
                }

                if (SpellManager.CanCastSpell("Mind Flay"))
                    return "Mind Flay";

                if (!_me.IsAutoAttacking)
                    if (_me.ManaPercent <= 50 || _me.CurrentTarget.HealthPercent <= 10 && _me.HealthPercent >= 50)
                    {
                        HaveWandCheck();
                        if (haveWandEquipped)
                        {
                            return "Shoot";
                        }
                        else
                        {
                            return "Attack";
                        }
                    }
            }

            return "";
        }

        private bool checkNeedAddCast(string spell, bool target)
        {
            if (Targeting.Instance.TargetList.Count > 0)
            {
                if (Targeting.Instance.TargetList.Count > 1 && !iAmPVPing)
                {
                    foreach (WoWUnit thing in Targeting.Instance.TargetList)
                    {
                        if (!thing.Buffs.ContainsKey(spell) && SpellManager.CanCastSpell(spell) && thing.Distance < 30)
                        {
                            if (target)
                            {
                                //thing.Target();
                            }
                            return true;
                        }
                    }
                }
            }
            return false;
        }

        private bool GotDebuff(string name)
        {
            if (_me.CurrentTarget == null)
                return false;

            return !(!_me.CurrentTarget.Buffs.ContainsKey(name) && SpellManager.KnownSpells.ContainsKey(name));
        }

        #region Spells

        private static bool MindBlast()
        {
            return SpellManager.CastSpell("Mind Blast");
        }

        private static void _Heal()
        {
            SpellManager.CastSpell("Heal");
        }

        private static void LesserHeal()
        {
            SpellManager.CastSpell("Lesser Heal");
        }

        private static void GreaterHeal()
        {
            SpellManager.CastSpell("Greater Heal");
        }

        private static void flashHeal()
        {
            SpellManager.CastSpell("Flash Heal");
        }

        private static bool Smite()
        {
            return SpellManager.CastSpell("Smite");
        }

        private static bool InnerFire()
        {
            return SpellManager.CastSpell("Inner Fire");
        }

        private static bool PowerWordFortitude()
        {
            return SpellManager.CastSpell("Power Word: Fortitude");
        }

        private static bool PowerWordShield()
        {
            return SpellManager.CastSpell("Power Word: Shield");
        }

        private static bool DivineSpirit()
        {
            return SpellManager.CastSpell("Divine Spirit");
        }

        private static bool VampiricEmbrace()
        {
            return SpellManager.CastSpell("Vampiric Embrace");
        }

        private void checkShadowFormCombat()
        {
            if (SpellManager.CanCastSpell("Shadowform") && _me.ManaPercent > shadowformCombatCast && _me.Shapeshift != ShapeshiftForm.Shadow)
            {
                SpellManager.CastSpell("Shadowform");
            }
        }

        #endregion

        #endregion

        //Code to do with loading settings
    }
}