﻿/*
 * Themyscira - a Warrior CC
 * Arms, Fury, Protection
 * By Fpsware AKA Fleecy
 *  
 * Working with HB Release
 * 
 * Suitable for levels 1 - 80
 *
 * CREDITS:
 * 
 * - Bobby for his Talent code
 * 
 */

#pragma warning disable
namespace Themyscira
{
    using Styx.Logic;
    using System;
    using Styx.Helpers;
    using Styx.Logic.Pathing;
    using System.Threading;
    using System.Diagnostics;
    using System.Collections.Generic;
    using Styx;
    using Styx.Combat.CombatRoutine;
    using Styx.Logic.Combat;
    using Styx.WoWInternals;
    using Styx.WoWInternals.WoWObjects;

    public class Warrior : CombatRoutine
    {

        /* •—————————————————————————————————————————————————————————————————————————————————————————————————————————————————————•
           | MODIFY YOUR SETTINGS HERE                                                                                           |
           •—————————————————————————————————————————————————————————————————————————————————————————————————————————————————————• */


        private double restHealth = 55;                        // Eat at X% health
        private int needHealHealth = 40;                       // Health % to use Healing Potion or racial
        private bool useHamstring = true;
        private int healthToUseHamstring = 40;
        private bool useRend = true;
        private bool useCommandingShout = false;             // Use Commanding Shout instead of Battle Shout
        private bool useThunderClap = true;
        private bool useExecute = false;
        private bool useImtimidatingShout = true;
        private int minRageToUseDump = 25;                   // You must have X rage before it will use the rage dump. Default spell is Heroic Strike
        private bool useDevastateRageDump = false;          // If true will use instead of Heroic Strike
        private bool useDeathWish = true;
        private bool useBerserkerRage = true;

        private bool useCCTargeting = true;                   // Use own targeting function. Will choose the best closest target.

        //private bool useRangedPull = false;                 // Pull with ranged weapon instead of Charge



        /* Unless you know what you're doing I strongly suggest you DO NOT change these 3 settings.
        * If all 3 settings are 'false' it will automatically choose the best stance dependant on your spec and talent points
        * If your spec if Fury it is assumed you are dual wielding and will use Berserker Stance
        * If your spec is Arms it is assumed you have 2Hander and will use Battle Stance
        * If your spec if Prot it is assumed you are a tank and will use Defensive Stance. 
        * 
        * If you want to override the automatically chosen stance then set ONE of the below options to 'true'
        */
        private bool useBattleStance = false;               // Force the use of Battle Stance
        private bool useBerserkerStance = false;            // Force the use of Berserker Stance
        private bool useDefensiveStance = false;            // Force the Warrior to act as Tank - OVERRIDES above settings
        /* --------------------------------------------------------------------------------------------- */



        /*
         * The below multi-mob pickup code is still in testing. 
         * Unless you want to see some wild unexpected results best you leave it off.
         * 
         */
        private bool useMultiMobPulling = false;                  // Turn this on if you want to use multi-mob pulling
        private int maxNumberOfMobs = 3;                        // Round up X number of mobs



        /* •—————————————————————————————————————————————————————————————————————————————————————————————————————————————————————•
           | DO NOT MODIFY ANYTHING PAST THIS POINT                                                                              |
           •—————————————————————————————————————————————————————————————————————————————————————————————————————————————————————• */

        public override WoWClass Class { get { return WoWClass.Warrior; } }

        public override string Name { get { return "Themyscira 0.9"; } }

        #region Private Members

        private void slog(string msg)
        {
            if (msg == _logspam)
            {
                return;
            }

            Logging.Write(msg);
            _logspam = msg;
        }

        private void slog(string msg, bool debugOnly)
        {
            if (debug == false)
            {
                return;
            }

            if (msg == _logspam)
            {
                return;
            }

            Logging.Write("DBG: " + msg);
            //Logging.Write("DEBUG: " + msg);
            _logspam = msg;
        }

        #endregion

        #region Global Variables

        List<WoWUnit> addsList = new List<WoWUnit>();
        private static LocalPlayer Me { get { return ObjectManager.Me; } }
        private static LocalPlayer _me { get { return ObjectManager.Me; } }
        private string _logspam;
        private static ulong pullGuid;
        private static Stopwatch fightTimer = new Stopwatch();
        private static Stopwatch pullTimer = new Stopwatch();
        private static Stopwatch potionTimer = new Stopwatch();
        private static Stopwatch combatTimer = new Stopwatch();
        private static Stopwatch shieldTimer = new Stopwatch();
        CC_TalentGroup primaryTalents = new CC_TalentGroup();
        CC_TalentGroup secondaryTalents = new CC_TalentGroup();
        private bool _CCLoaded = false;
        float DistanceForRangedPull = 25.0f;
        float DistanceForMeleePull = 4.5f;
        private WoWUnit aggroUnitDuringPull;
        bool debug = false;
        int addCount = 0;
        bool noFoodLeft = false;
        bool useLowestHPTarget = true;
        bool OutOfAmmoDoMeleeOnly = false;
        private bool hasShield = false; // Varialbe for a very crude way to check if a shield is equipped
        private bool tmpBattleStanceCharge = false;


        private List<string> rendImmuneMobs = new List<string>()
        {
            "name of mob here","other mob name"
        };


        private List<uint> bandageEID = new List<uint>()
        {
            34722,34721,21991,21990,14530,14529,8545,8544,
            6451,6450,3531,3530,2581,1251,
        };

        private List<uint> potionEID = new List<uint>()
        {
            33447,43569,43531,32947,18839,33934,4596,1710,
            929,23822,33092,858,31852,31853,31839,
            31838,13446,118,39671,22829,3928,
            28100,33447,
        };


        enum WarriorType
        {
            None,
            Arms,
            Fury,
            Protection
        };

        WarriorType eType = WarriorType.None;

        enum WarriorStance
        {
            None,
            Battle,
            Defensive,
            Berserker
        };

        WarriorStance StanceDance = WarriorStance.None;



        private double TargetDistance
        {
            get
            {
                return Me.GotTarget ? Me.CurrentTarget.Distance : uint.MaxValue - 1;

            }
        }

        private WoWPoint behindTarget
        {
            get
            {
                if (Me.GotTarget)
                {
                    return WoWMathHelper.CalculatePointBehind(Me.CurrentTarget.Location, Me.CurrentTarget.Rotation, 4);
                }
                else
                {
                    WoWPoint noSpot = new WoWPoint();
                    return noSpot;
                }
            }
        }

        private WoWPoint TargetLocation
        {
            get
            {
                if (Me.GotTarget)
                {
                    return Me.CurrentTarget.Location;
                }
                else
                {
                    WoWPoint noSpot = new WoWPoint();
                    return noSpot;
                }
            }
        }

        private ulong targettingGuid
        {
            get
            {
                //    try
                //    {
                if (!Equals(null, Targeting.Instance.TargetList) && Targeting.Instance.TargetList.Count > 0)
                {
                    return Targeting.Instance.TargetList[0].Guid;
                }
                else
                {
                    return 0;
                }
                //}
                //catch
                //{
                //    slog("No valid target.");
                //    return 0;
                //}
            }
        }


        public Warrior()
        {
            if (Me.Class != WoWClass.Warrior)
                return;

            if (_CCLoaded)
                return;

            BotEvents.Player.OnMobKilled += Player_OnMobKilled;

            primaryTalents.Load(1);
            secondaryTalents.Load(2);

            CC_TalentGroup activeGrp;
            CC_TalentGroup inactiveGrp;

            if (primaryTalents.IsActiveGroup())
            {
                activeGrp = primaryTalents;
                inactiveGrp = secondaryTalents;
            }
            else
            {
                inactiveGrp = primaryTalents;
                activeGrp = secondaryTalents;
            }

            string sSpecType = activeGrp._tabName[activeGrp.Spec()];
            if (activeGrp.Spec() == 1)
                eType = WarriorType.Arms;
            else if (activeGrp.Spec() == 2)
                eType = WarriorType.Fury;
            else if (activeGrp.Spec() == 3)
                eType = WarriorType.Protection;
            else
            {
                eType = WarriorType.None;
                sSpecType = "Undefined";
            }

            if (Me.Level < 10)
            {
                slog("You are < level 10. You don't have any talent points");
            }
            else
            {
                switch (eType)
                {
                    case Warrior.WarriorType.Arms:
                        slog("You are Arms spec");
                        StanceCheck();
                        //slog("Your pull range has been adjusted to: " + DistanceForRangedPull);
                        break;

                    case Warrior.WarriorType.Fury:
                        slog("You are Fury spec");
                        StanceCheck();
                        //slog("Your pull range has been adjusted to: " + DistanceForRangedPull);
                        break;

                    case Warrior.WarriorType.Protection:
                        slog("You are Protection spec");
                        StanceCheck();
                        //slog("Your pull range has been adjusted to: " + DistanceForRangedPull);
                        break;
                }
            }

            shieldTimer.Start();
            _CCLoaded = true;
        }

        void Player_OnMobKilled(BotEvents.Player.MobKilledEventArgs args)
        {
            if (_me.CurrentTargetGuid == args.KilledMob.Guid)
            {
                _me.ClearTarget();
                Lua.DoString("StopAttack()");
            }
        }

        #endregion

        #region Rest

        public override bool NeedRest
        {
            get
            {
                bool result = false;

                StanceDance = WarriorStance.None;

                if (Me.Combat || Battlegrounds.IsInsideBattleground)
                {
                    return false;
                }

                // Wait for everyone in the party to eat / drink
                foreach (WoWPlayer player in Me.PartyMembers)
                {
                    if (player.Buffs.ContainsKey("Food") || player.Buffs.ContainsKey("Drink") || player.HealthPercent < 35 || player.ManaPercent < 35 || player.Dead || player.IsGhost)
                    {
                        result = true;
                    }
                }


                if (Me.GetPowerPercent(WoWPowerType.Health) <= restHealth)
                {
                    result = true;
                }


                return result;
            }
        }

        public override void Rest()
        {
            Styx.Logic.Common.Rest.Feed();
        }

        #endregion

        #region Pull

        public override void Pull()
        {
            try
            {
                slog("START Pull()", true);

                if (IsTargetBlackListed || !IsValidPullTarget(Me.CurrentTarget) && !InBattleGround())
                {
                    slog("Clearing target. Invalid target for some reason. ");
                    Me.ClearTarget();
                    StopMoving();
                    return;
                }

                if (InBattleGround())
                {
                    StanceDance = WarriorStance.Berserker;
                }

                StanceCheck();

                if (Me.Combat && Me.CurrentTarget.Distance > 10 && !Me.CurrentTarget.Combat)
                {
                    // Looks like we picked up aggro during pull. 
                    slog("Pull target in question.....");

                    Me.ClearTarget();
                    StopMoving();
                    pullTimer.Reset();
                }

                // Looks like we picked up aggro trying to pull a mob
                if (Me.GotTarget && Me.CurrentTargetGuid != pullGuid)
                {
                    pullTimer.Reset();
                    pullTimer.Start();
                    slog("Attacking " + Me.CurrentTarget.Name + " at " + (int)Me.CurrentTarget.Distance + " yards");
                }

                // Blacklist this mob, something is buggy
                if (!Me.CurrentTarget.IsPlayer && pullTimer.ElapsedMilliseconds > 30 * 1000)
                {
                    slog("" + Me.CurrentTarget.Name + " is a bugged mob. Blacklisting for 1 hour.");

                    BlacklistTarget(Me.CurrentTargetGuid, 3600);

                    Me.ClearTarget();
                    pullGuid = 0;
                }

                PullMelee();
            }
            finally
            {
                slog("END Pull()", true);
            }
        }

        private void PullMelee()
        {
            try
            {
                slog("START PullMelee()", true);
                AutoAttack(true);

                while (IsDistanceMoreThan(5))
                {

                    if (!IsValidPullTarget(Me.CurrentTarget) && !InBattleGround())
                    {
                        Me.ClearTarget();
                        StopMoving();
                        return;
                    }

                    if (Me.Combat && Me.CurrentTarget.Distance > 10 && !Me.CurrentTarget.Combat)
                    {
                        // Looks like we picked up aggro during pull. 
                        slog("Pull target in question.....");

                        Me.ClearTarget();
                        StopMoving();
                        pullTimer.Reset();
                    }


                    if (pullTimer.ElapsedMilliseconds > 25 * 1000)
                    {
                        slog("" + Me.CurrentTarget.Name + " is a bugged mob. Blacklisting for 1 hour.");

                        BlacklistTarget(Me.CurrentTargetGuid, 3600);
                        StopMoving();
                        Me.ClearTarget();
                        pullGuid = 0;
                        return;
                    }

                    Navigator.MoveTo(WoWMathHelper.CalculatePointFrom(Me.Location, Me.CurrentTarget.Location, 3f));

                    if (TargetDistance > 25 && IsMyRageBelow(15) && !Me.Combat && !IsBuffOnMe("Warbringer") && (IsBerserkerStance || IsDefensiveStance))
                    {
                        tmpBattleStanceCharge = true;
                        StanceDance = WarriorStance.Battle;
                        StanceCheck();
                        Thread.Sleep(500);
                    }


                    if ((IsBattleStance || IsDefensiveStance || IsBerserkerStance) && (IsBattleStance || IsBuffOnMe("Warbringer")))
                    {
                        if (Charge())
                        {
                            int a = 0;
                            while ((!Me.Dead || !Me.IsGhost) && Me.IsMoving && a < 7)
                            {
                                Thread.Sleep(500);
                                ++a;
                            }
                            //slog("DISTANCE AFTER CHARGE:" + Me.CurrentTarget.Distance);
                            StanceDanceBack();
                            StopMoving();
                            return;
                        }
                    }
                    else if (IsBerserkerStance)
                    {
                        if (Intercept())
                        {
                            int a = 0;
                            while ((!Me.Dead || !Me.IsGhost) && Me.IsMoving && a < 7)
                            {
                                Thread.Sleep(500);
                                ++a;
                            }
                            //slog("DISTANCE AFTER CHARGE:" + Me.CurrentTarget.Distance);
                            StopMoving();
                            return;
                        }
                    }




                }
            }
            finally
            {
                slog("END PullMelee()", true);
            }
        }

        #endregion

        #region Pull Buffs

        public override bool NeedPullBuffs { get { return false; } }

        public override void PullBuff()
        {
        }

        #endregion

        #region Pre Combat Buffs

        public override bool NeedPreCombatBuffs { get { return false; } }

        public override void PreCombatBuff()
        {
        }

        #endregion

        #region Combat Buffs

        public override bool NeedCombatBuffs { get { return false; } }

        public override void CombatBuff()
        {
        }

        #endregion

        #region Heal

        private Stopwatch healtimer = new Stopwatch();
        public bool NeedAHeal
        {
            get
            {
                return IsMyHealthBelow(needHealHealth);
            }
        }

        public override void Heal()
        {
            if (IsMyHealthBelow(needHealHealth))
            {
                int tmpHealth = Me.CurrentHealth;
                UsePotion();
                Thread.Sleep(100);
                int tmpHealth2 = Me.CurrentHealth;
                Thread.Sleep(250);
                tmpHealth2 = Me.CurrentHealth;

                if (tmpHealth2 > tmpHealth)
                {
                    // Check if we actually used a potion. If not lets use a Racial
                    return;
                }
            }

            switch (Me.Race)
            {
                case WoWRace.Draenei:
                    GiftOfTheNaaru();
                    break;

                case WoWRace.Dwarf:
                    Stoneform();
                    break;

            }

            if (IsBuffOnMe("Gift of the Naaru"))
            {
                return;
            }

            Lifeblood();


        }

        #endregion

        #region Combat

        public override void Combat()
        {
            try
            {
                slog("START Combat()", true);
                //combatTimer.Start();

                // If you're in a BG change to Berserker stance
                if (InBattleGround() && IsKnownSpell("Berserker Stance"))
                {
                    StanceDance = WarriorStance.Berserker;
                }
                else
                {
                    ChooseLowestHPTarget();
                }

                // If the mob is dead no need to be here
                if (!CombatChecks()) { return; }

                AutoAttack(true);
                EvadeCheck();
                FaceTarget();
                BuffCheck();
                DistanceCheck();
                //CheckShield();

                // If we're stance dancing to charge lets swap back
                StanceDanceBack();


                if (NeedAHeal) { Heal(); }

                CheckProcAbilities();

                if (ShouldExecute) { Execute(); return; }
                if (ShouldHamstring) { Hamstring(); return; }
                if (IsTargetCasting) { SilenceBiatch(); return; }
                //if (AddCheck) { AddManagement(); }
                if (ShouldRageDump) { RageDump(); }

                VictoryRush();
                Overpower();

                if (ShouldMortalStrike) { MortalStrike(); }
                if (ShouldRend) { Rend(); }
                if (ShouldThunderClap) { ThunderClap(); }
                //if (AddCheck) { AddManagement(); }

                FaceTarget();
                //if (AddCheck) { AddManagement(); }
                SpecCombat();
                if (!CombatChecks()) { return; }


                FaceTarget();

                // try to stay in range of the mob - its better this way.
                DistanceCheck();


                if (NeedAHeal) { Heal(); return; }
                //if (AddCheck) { AddManagement(); }
                if (ShouldRageDump) { RageDump(); }

                EvadeCheck();
                FaceTarget();
                SpecCombat();
            }
            catch (Exception ex)
            {
                //slog(" ");
                //slog("Exception in Combat void:");
                //slog(" - " + ex.Message);
            }
            finally
            {
                slog("END Combat()", true);
                //slog("Combat Sequence Took: " + combatTimer.ElapsedMilliseconds + "ms");
                //combatTimer.Reset();
            }
        }

        public void AddManagement()
        {
            try
            {
                slog("START AddManagement()", true);

                ChooseLowestHPTarget();

                FaceTarget();

                // Lets give ourself a little bit more rage
                if (IsMyRageBelow(30)) { Bloodrage(); }

                if (ShouldIntimidatingShout) { IntimidatingShout(); }

                Retaliation();
                Whirlwind();
                Bladestorm();
                SweepingStrikes();
                Cleave();
                if (ShouldDemoShout) { DemoralizingShout(); }

                //ChooseLowestHPTarget();
                DistanceCheck();
            }
            finally
            {
                slog("END AddManagement()", true);
            }
        }

        public void CombatTank()
        {
            try
            {
                slog("START CombatTank()", true);
                Revenge();
                ShieldBlock();
                if (NeedAHeal) { Heal(); }

                //DemoralizingShout();
            }
            finally
            {
                slog("END CombatTank()", true);
            }
        }

        public void CombatFury()
        {
            try
            {
                slog("START CombatFury()", true);
                DistanceCheck();
                CheckProcAbilities();

                Recklessness();
                if (useDeathWish) { DeathWish(); }
                if (useBerserkerRage) { BerserkerRage(); }
                HeroicThrow();

                Bloodthirst();
                CheckProcAbilities();

                Whirlwind();
            }
            finally
            {
                slog("END CombatFury()", true);
            }

        }

        public void CombatArms()
        {
            try
            {
                slog("START CombatArms()", true);
                DistanceCheck();
                CheckProcAbilities();

                if (ShouldMortalStrike) { MortalStrike(); }

                if (useDeathWish) { DeathWish(); }
                if (useBerserkerRage) { BerserkerRage(); }
                HeroicThrow();

            }
            finally
            {
                slog("END CombatArms()", true);
            }

        }

        public void CombatProtection()
        {
            try
            {
                slog("START CombatProtection()", true);

                DistanceCheck();
                CheckProcAbilities();

                if (ShouldShieldWall) { ShieldWall(); }
                if (ShouldSpellReflection) { SpellReflection(); }

                ShieldBlock();
                ShieldSlam();
                Revenge();
                Shockwave();

                HeroicThrow();
                if (useDeathWish) { DeathWish(); }
                if (useBerserkerRage) { BerserkerRage(); }


                //if (NeedHeal) { Heal(); }
                //DemoralizingShout();
            }
            finally
            {
                slog("END CombatProtection()", true);
            }

        }

        public void CombatPVP()
        {

        }


        #endregion

        #region Spells


        bool Charge()
        {
            slog("...Charge()", true);
            if (!Me.GotTarget) return false;
            string SpellName = "Charge";
            bool result = false;

            if (CanCastSpell(SpellName, 9, 24))
            {
                result = CastSpell(SpellName);
                if (result)
                {
                    slog(SpellName);
                }
            }

            return result;
        }


        bool Rend()
        {
            slog("...Rend()", true);
            if (!Me.GotTarget) return false;
            string SpellName = "Rend";
            bool result = false;

            if (CanCastSpell(SpellName, 0, 5) && (IsBattleStance || IsDefensiveStance))
            {
                result = CastSpell(SpellName);
                if (result)
                {
                    slog(SpellName);
                }
            }

            return result;
        }

        bool ThunderClap()
        {
            slog("...ThunderClap()", true);
            string SpellName = "Thunder Clap";
            bool result = false;

            if (CanCastSpell(SpellName) && (IsBattleStance || IsDefensiveStance))
            {
                result = CastSpell(SpellName, true);
                if (result)
                {
                    slog(SpellName);
                }
            }

            return result;
        }

        bool HeroicThrow()
        {
            slog("...HeroicThrow()", true);
            if (!Me.GotTarget) return false;
            string SpellName = "Heroic Throw";
            bool result = false;

            if (CanCastSpell(SpellName))
            {
                result = CastSpell(SpellName);
                if (result)
                {
                    slog(SpellName);
                }
            }

            return result;
        }

        bool VictoryRush()
        {
            slog("...VictoryRush()", true);
            if (!Me.GotTarget) return false;
            string SpellName = "Victory Rush";
            bool result = false;
            if (!IsKnownSpell(SpellName)) return false;
            WoWSpell VR = SpellManager.KnownSpells[SpellName];
            var isUsable = Lua.LuaGetReturnValue("return IsUsableSpell('" + SpellName + "')", "hax.lua");

            if (isUsable != null)
            {
                //if (isUsable[0] == "1" && (IsBattleStance || IsBerserkerStance))
                if (isUsable[0] == "1")
                {
                    result = CastSpell(SpellName);
                    if (result)
                    {
                        slog(SpellName);
                    }
                }
            }

            return result;
        }

        bool Overpower()
        {
            slog("...Overpower()", true);
            if (!Me.GotTarget || !IsBattleStance) return false;
            string SpellName = "Overpower";
            bool result = false;
            if (!IsKnownSpell(SpellName)) return false;
            WoWSpell VR = SpellManager.KnownSpells[SpellName];
            var isUsable = Lua.LuaGetReturnValue("return IsUsableSpell('" + SpellName + "')", "hax.lua");

            if (isUsable != null)
            {
                //if (isUsable[0] == "1" && (IsBattleStance || IsBerserkerStance))
                if (isUsable[0] == "1")
                {
                    result = CastSpell(SpellName);
                    if (result)
                    {
                        slog(SpellName);
                    }
                }
            }

            return result;
        }

        bool Devastate()
        {
            slog("...Devastate()", true);
            if (!Me.GotTarget) return false;
            string SpellName = "Devastate";
            bool result = false;
            if (!IsKnownSpell(SpellName)) return false;
            WoWSpell VR = SpellManager.KnownSpells[SpellName];
            var isUsable = Lua.LuaGetReturnValue("return IsUsableSpell('" + SpellName + "')", "hax.lua");

            if (isUsable != null)
            {
                //if (isUsable[0] == "1" && (IsBattleStance || IsBerserkerStance))
                if (isUsable[0] == "1")
                {
                    result = CastSpell(SpellName);
                    if (result)
                    {
                        slog(SpellName);
                    }
                }
            }

            return result;
        }


        bool ShieldBash()
        {
            slog("...ShieldBash()", true);
            if (!Me.GotTarget) return false;
            string SpellName = "Shield Bash";
            bool result = false;
            if (!IsKnownSpell(SpellName)) return false;
            WoWSpell VR = SpellManager.KnownSpells[SpellName];
            var isUsable = Lua.LuaGetReturnValue("return IsUsableSpell('" + SpellName + "')", "hax.lua");

            if (isUsable != null)
            {
                //if (isUsable[0] == "1" && (IsBattleStance || IsBerserkerStance))
                if (isUsable[0] == "1")
                {
                    result = CastSpell(SpellName);
                    if (result)
                    {
                        slog(SpellName);
                    }
                }
            }

            return result;
        }

        bool ShieldBlock()
        {
            slog("...ShieldBlock()", true);
            string SpellName = "Shield Block";
            bool result = false;
            if (!IsKnownSpell(SpellName)) return false;
            WoWSpell VR = SpellManager.KnownSpells[SpellName];
            var isUsable = Lua.LuaGetReturnValue("return IsUsableSpell('" + SpellName + "')", "hax.lua");

            if (isUsable != null)
            {
                //if (isUsable[0] == "1" && (IsBattleStance || IsBerserkerStance))
                if (isUsable[0] == "1")
                {
                    result = CastSpell(SpellName);
                    if (result)
                    {
                        slog(SpellName);
                    }
                }
            }

            return result;
        }

        bool ShieldSlam()
        {
            slog("...ShieldSlam()", true);
            if (!Me.GotTarget) return false;
            string SpellName = "Shield Slam";
            bool result = false;
            if (!IsKnownSpell(SpellName)) return false;
            WoWSpell VR = SpellManager.KnownSpells[SpellName];
            var isUsable = Lua.LuaGetReturnValue("return IsUsableSpell('" + SpellName + "')", "hax.lua");

            if (isUsable != null)
            {
                //if (isUsable[0] == "1" && (IsBattleStance || IsBerserkerStance))
                if (isUsable[0] == "1")
                {
                    result = CastSpell(SpellName);
                    if (result)
                    {
                        slog(SpellName);
                    }
                }
            }

            return result;
        }

        bool ShieldWall()
        {
            slog("...ShieldWall()", true);
            string SpellName = "Shield Wall";
            bool result = false;
            if (!IsKnownSpell(SpellName)) return false;
            WoWSpell VR = SpellManager.KnownSpells[SpellName];
            var isUsable = Lua.LuaGetReturnValue("return IsUsableSpell('" + SpellName + "')", "hax.lua");

            if (isUsable != null)
            {
                //if (isUsable[0] == "1" && (IsBattleStance || IsBerserkerStance))
                if (isUsable[0] == "1")
                {
                    result = CastSpell(SpellName);
                    if (result)
                    {
                        slog(SpellName);
                    }
                }
            }

            return result;
        }

        bool SpellReflection()
        {
            slog("...SpellReflection()", true);
            string SpellName = "Spell Reflection";
            bool result = false;
            if (!IsKnownSpell(SpellName)) return false;
            WoWSpell VR = SpellManager.KnownSpells[SpellName];
            var isUsable = Lua.LuaGetReturnValue("return IsUsableSpell('" + SpellName + "')", "hax.lua");

            if (isUsable != null)
            {
                //if (isUsable[0] == "1" && (IsBattleStance || IsBerserkerStance))
                if (isUsable[0] == "1")
                {
                    result = CastSpell(SpellName);
                    if (result)
                    {
                        slog(SpellName);
                    }
                }
            }

            return result;
        }

        bool Revenge()
        {
            slog("...Revenge()", true);
            if (!Me.GotTarget) return false;
            string SpellName = "Revenge";
            bool result = false;
            if (!IsKnownSpell(SpellName)) return false;
            WoWSpell VR = SpellManager.KnownSpells[SpellName];
            var isUsable = Lua.LuaGetReturnValue("return IsUsableSpell('" + SpellName + "')", "hax.lua");

            if (isUsable != null)
            {
                //if (isUsable[0] == "1" && (IsBattleStance || IsBerserkerStance))
                if (isUsable[0] == "1")
                {
                    result = CastSpell(SpellName);
                    if (result)
                    {
                        slog(SpellName);
                    }
                }
            }

            return result;
        }

        bool BattleStance()
        {
            slog("...BattleStance()", true);
            if (IsBattleStance) return false;
            string SpellName = "Battle Stance";
            bool result = false;

            if (CanCastSpell(SpellName) && !IsBattleStance)
            {
                result = CastSpell(SpellName);
                if (result)
                {
                    slog(SpellName);
                }
            }

            return result;
        }

        bool Taunt()
        {
            slog("...Taunt()", true);
            if (!Me.GotTarget) return false;
            string SpellName = "Taunt";
            bool result = false;

            if (CanCastSpell(SpellName) && IsDefensiveStance)
            {
                result = CastSpell(SpellName);
                if (result)
                {
                    slog(SpellName);
                }
            }

            return result;
        }


        bool Intercept()
        {
            slog("...Intercept()", true);
            if (!Me.GotTarget) return false;
            string SpellName = "Intercept";
            bool result = false;

            if (CanCastSpell(SpellName, 8, 24) && IsBerserkerStance)
            {
                result = CastSpell(SpellName);
                if (result)
                {
                    slog(SpellName);
                }
            }

            return result;
        }


        bool IntimidatingShout()
        {
            slog("...IntimidatingShout()", true);
            string SpellName = "Intimidating Shout";
            bool result = false;

            if (CanCastSpell(SpellName))
            {
                result = CastSpell(SpellName);
                if (result)
                {
                    slog(SpellName);
                }
            }

            return result;
        }

        bool Pummel()
        {
            slog("...Pummel()", true);
            if (!Me.GotTarget) return false;
            string SpellName = "Pummel";
            bool result = false;

            if (CanCastSpell(SpellName, 0, 5) && IsBerserkerStance)
            {
                result = CastSpell(SpellName);
                if (result)
                {
                    slog(SpellName);
                }
            }

            return result;
        }


        bool Recklessness()
        {
            slog("...Recklessness()", true);
            string SpellName = "Recklessness";
            bool result = false;

            if (CanCastSpell(SpellName) && IsBerserkerStance)
            {
                result = CastSpell(SpellName);
                if (result)
                {
                    slog(SpellName);
                }
            }

            return result;
        }


        bool Slam()
        {
            slog("...Slam()", true);
            if (!Me.GotTarget) return false;
            string SpellName = "Slam";
            bool result = false;

            if (CanCastSpell(SpellName, 0, 5))
            {
                result = CastSpell(SpellName);
                if (result)
                {
                    slog(SpellName);
                }
            }

            return result;
        }


        bool ShatteringThrow()
        {
            slog("...ShatteringThrow()", true);
            if (!Me.GotTarget || !IsBattleStance) return false;
            string SpellName = "Shattering Throw";
            bool result = false;

            if (CanCastSpell(SpellName))
            {
                result = CastSpell(SpellName);
                if (result)
                {
                    slog(SpellName);
                }
            }

            return result;
        }

        bool DeathWish()
        {
            slog("...DeathWish()", true);
            string SpellName = "Death Wish";
            bool result = false;

            if (CanCastSpell(SpellName))
            {
                result = CastSpell(SpellName);
                if (result)
                {
                    slog(SpellName);
                }
            }

            return result;
        }

        bool BerserkerRage()
        {
            slog("...BerserkerRage()", true);
            string SpellName = "Berserker Rage";
            bool result = false;

            if (CanCastSpell(SpellName))
            {
                result = CastSpell(SpellName);
                if (result)
                {
                    slog(SpellName);
                }
            }

            return result;
        }

        bool Whirlwind()
        {
            slog("...Whirlwind()", true);
            if (!Me.GotTarget) return false;
            string SpellName = "Whirlwind";
            bool result = false;

            if (CanCastSpell(SpellName) && IsBerserkerStance)
            {
                result = CastSpell(SpellName);
                if (result)
                {
                    slog(SpellName);
                }
            }

            return result;
        }


        bool SweepingStrikes()
        {
            slog("...SweepingStrikes()", true);
            string SpellName = "Sweeping Strikes";
            bool result = false;

            if (CanCastSpell(SpellName) && IsBerserkerStance && IsBattleStance)
            {
                result = CastSpell(SpellName);
                if (result)
                {
                    slog(SpellName);
                }
            }

            return result;
        }

        bool Bladestorm()
        {
            slog("...Bladestorm()", true);
            string SpellName = "Bladestorm";
            bool result = false;

            if (CanCastSpell(SpellName))
            {
                result = CastSpell(SpellName);
                if (result)
                {
                    slog(SpellName);
                }
            }

            return result;
        }


        bool ConcussionBlow()
        {
            slog("...ConcussionBlow()", true);
            if (!Me.GotTarget) return false;
            string SpellName = "Concussion Blow";
            bool result = false;

            if (CanCastSpell(SpellName, 0, 5))
            {
                result = CastSpell(SpellName);
                if (result)
                {
                    slog(SpellName);
                }
            }

            return result;
        }



        bool SunderArmor()
        {
            slog("...SunderArmor()", true);
            if (!Me.GotTarget) return false;
            string SpellName = "Sunder Armo";
            bool result = false;

            if (CanCastSpell(SpellName, 0, 5))
            {
                result = CastSpell(SpellName);
                if (result)
                {
                    slog(SpellName);
                }
            }

            return result;
        }

        bool ChallengingShout()
        {
            slog("...ChallengingShout()", true);
            string SpellName = "Challenging Shout";
            bool result = false;

            if (CanCastSpell(SpellName))
            {
                result = CastSpell(SpellName);
                if (result)
                {
                    slog(SpellName);
                }
            }

            return result;
        }

        bool Cleave()
        {
            slog("...Cleave()", true);
            if (!Me.GotTarget) return false;
            string SpellName = "Cleave";
            bool result = false;

            if (CanCastSpell(SpellName, 0, 5))
            {
                result = CastSpell(SpellName);
                if (result)
                {
                    slog(SpellName);
                }
            }

            return result;
        }

        bool Retaliation()
        {
            slog("...Retaliation()", true);
            string SpellName = "Retaliation";
            bool result = false;

            if (CanCastSpell(SpellName) && IsBattleStance)
            {
                result = CastSpell(SpellName);
                if (result)
                {
                    slog(SpellName);
                }
            }

            return result;
        }

        bool DemoralizingShout()
        {
            slog("...DemoralizingShout()", true);
            string SpellName = "Demoralizing Shout";
            bool result = false;

            if (CanCastSpell(SpellName))
            {
                result = CastSpell(SpellName);
                if (result)
                {
                    slog(SpellName);
                }
            }

            return result;
        }

        bool Execute()
        {
            slog("...Execute()", true);
            if (!Me.GotTarget) return false;
            string SpellName = "Execute";
            bool result = false;

            if (CanCastSpell(SpellName, 0, 5) && (IsBattleStance || IsBerserkerStance))
            {
                result = CastSpell(SpellName);
                if (result)
                {
                    slog(SpellName);
                }
            }

            return result;
        }

        bool MortalStrike()
        {
            slog("...MortalStrike()", true);
            if (!Me.GotTarget) return false;
            string SpellName = "Mortal Strike";
            bool result = false;

            if (CanCastSpell(SpellName, 0, 5))
            {
                result = CastSpell(SpellName);
                if (result)
                {
                    slog(SpellName);
                }
            }

            return result;
        }

        bool DefensiveStance()
        {
            slog("...DefensiveStance()", true);
            if (IsDefensiveStance) return false;
            string SpellName = "Defensive Stance";
            bool result = false;

            if (CanCastSpell(SpellName) && !IsDefensiveStance)
            {
                result = CastSpell(SpellName);
                if (result)
                {
                    slog(SpellName);
                }
            }

            return result;
        }

        bool BerserkerStance()
        {
            slog("...BerserkerStance()", true);
            if (IsBerserkerStance) return false;
            string SpellName = "Berserker Stance";
            bool result = false;

            if (CanCastSpell(SpellName) && !IsBerserkerStance)
            {
                result = CastSpell(SpellName);
                if (result)
                {
                    slog(SpellName);
                }
            }

            return result;
        }

        bool Hamstring()
        {
            slog("...Hamstring()", true);
            if (!Me.GotTarget) return false;
            string SpellName = "Hamstring";
            bool result = false;

            if (CanCastSpell(SpellName, 0, 5) && (IsBattleStance || IsBerserkerStance))
            {
                result = CastSpell(SpellName);
                if (result)
                {
                    slog(SpellName);
                }
            }

            return result;
        }


        bool Disarm()
        {
            slog("...Disarm()", true);
            if (!Me.GotTarget) return false;
            string SpellName = "Disarm";
            bool result = false;

            if (CanCastSpell(SpellName, 0, 5) && IsDefensiveStance)
            {
                result = CastSpell(SpellName);
                if (result)
                {
                    slog(SpellName);
                }
            }

            return result;
        }


        bool Shockwave()
        {
            slog("...Shockwave()", true);
            if (!Me.GotTarget) return false;
            string SpellName = "Shockwave";
            bool result = false;

            if (CanCastSpell(SpellName))
            {
                result = CastSpell(SpellName);
                if (result)
                {
                    slog(SpellName);
                }
            }

            return result;
        }



        bool HeroicStrike()
        {
            slog("...HeroicStrike()", true);
            if (!Me.GotTarget) return false;
            string SpellName = "Heroic Strike";
            bool result = false;

            if (CanCastSpell(SpellName, 0, 5))
            {
                result = CastSpell(SpellName);
                if (result)
                {
                    slog(SpellName);
                }
            }

            return result;
        }


        bool Bloodthirst()
        {
            slog("...Bloodthirst()", true);
            if (!Me.GotTarget) return false;
            string SpellName = "Bloodthirst";
            bool result = false;

            if (CanCastSpell(SpellName))
            {
                result = CastSpell(SpellName);
                if (result)
                {
                    slog(SpellName);
                }
            }

            return result;
        }


        bool Bloodrage()
        {
            slog("...Bloodrage()", true);
            string SpellName = "Bloodrage";
            bool result = false;

            if (CanCastSpell(SpellName))
            {
                result = CastSpell(SpellName);
                if (result)
                {
                    slog(SpellName);
                }
            }

            return result;
        }





        #endregion

        #region horde racials

        // Berserking
        void Berserking()
        {
            if (IsKnownSpell("Berserking") && !IsSpellOnCooldown("Berserking"))
            {
                CastSpell("Berserking");
                slog("Berserking.");
            }
        }

        // Bloodrage
        void BloodrageRacial()
        {
            if (SpellManager.CastSpell("Bloodrage"))
            {
                Styx.Helpers.Logging.Write("Bloodrage.");
            }
        }

        // War Stomp
        void WarStomp()
        {
            if (SpellManager.CastSpell("War Stomp"))
            {
                Styx.Helpers.Logging.Write("War Stomp.");
            }
        }

        // Arcane Torrent
        void ArcaneTorrent()
        {
            if (SpellManager.CastSpell("Arcane Torrent"))
            {
                Styx.Helpers.Logging.Write("Arcane Torrent.");
            }
        }

        // Will of the Forsaken 
        void WillOfTheForsaken()
        {
            if (SpellManager.CastSpell("Will of the Forsaken"))
            {
                Styx.Helpers.Logging.Write("Will of the Forsaken.");
            }
        }
        #endregion

        #region alliance racials

        // Stoneform
        void Stoneform()
        {
            if (SpellManager.CastSpell("Stoneform"))
            {
                Styx.Helpers.Logging.Write("Stoneform.");
            }
        }

        // Gift of the Naaru
        void GiftOfTheNaaru()
        {
            if (SpellManager.CastSpell("Gift of the Naaru"))
            {
                Styx.Helpers.Logging.Write("Gift of the Naaru.");
            }
        }

        // Every Man for Himself
        void EveryManForHimself()
        {
            if (SpellManager.CastSpell("Every Man for Himself"))
            {
                Styx.Helpers.Logging.Write("Every Man for Himself.");
            }
        }

        // Shadowmeld
        void Shadowmeld()
        {
            if (SpellManager.CastSpell("Shadowmeld"))
            {
                Styx.Helpers.Logging.Write("Shadowmeld.");
            }
        }

        // Escape Artist
        void EscapeArtist()
        {
            if (SpellManager.CastSpell("Escape Artist"))
            {
                Styx.Helpers.Logging.Write("Escape Artist.");
            }
        }


        #endregion

        #region combat checks


        private bool CombatChecks()
        {

            if (!Me.GotTarget)
            {
                //slog("No target.");
                return false;
            }

            if (Me.Dead)
            {
                slog("I died.");
                return false;
            }

            if (Me.GotTarget && !Me.IsAutoAttacking)
            {
                Lua.DoString("StartAttack()");
            }

            if (TargetDistance > 200)
            {
                slog("Out of range: " + Me.CurrentTarget.Name + " is " + System.Math.Round(TargetDistance).ToString() + " yards away.");
                return false;
            }

            WoWMovement.Face();

            return true;
        }

        #endregion

        #region utility procedures



        private bool InventoryItemCheck(string itemToCheckFor)
        {
            foreach (WoWItem item in ObjectManager.GetObjectsOfType<WoWItem>(false))
            //foreach (WoWItem item in ObjectManager.ItemObjectList.Values)
            {
                if (item.Name == itemToCheckFor)
                {
                    slog(itemToCheckFor + " found, we have " + item.StackCount);

                    return true;
                }
            }
            return false;
        }

        private bool FoodCheck()
        {
            slog("FoodCheck()");

            string FoodName = Styx.Helpers.LevelbotSettings.Instance.FoodName;
            List<WoWItem> list = new List<WoWItem>(ObjectManager.GetObjectsOfType<WoWItem>(false));
            foreach (WoWItem item in list)
            {
                slog("... = " + item.Name);
                if (item.Name.Equals(FoodName))
                {
                    slog("FOUND ITEM");
                    return true;
                }
            }
            slog("NOT FOUND ITEM");
            return false;
        }

        private bool IsTargetOfTargetNothing
        {
            get
            {
                return (Me.CurrentTarget.CurrentTarget == null);
            }
        }

        private bool IsTargetOfTargetMe
        {
            get
            {
                if (!Me.GotAlivePet)
                {
                    return false;
                }

                return (Me.CurrentTarget.CurrentTargetGuid == Me.Guid);
            }
        }


        private bool TargetIsCaster
        {
            get
            {
                return (Me.CurrentTarget.GetCurrentPower(WoWPowerType.Mana) > 1);
            }
        }


        private void BuffCheck()
        {
            if (IsKnownSpell("Commanding Shout") && useCommandingShout)
            {
                if (CanCastSpell("Commanding Shout") && !IsBuffOnMe("Commanding Shout"))
                {
                    CastSpell("Commanding Shout");
                    return;
                }
            }
            else if (IsKnownSpell("Battle Shout"))
            {
                if (CanCastSpell("Battle Shout") && !IsBuffOnMe("Battle Shout"))
                {
                    CastSpell("Battle Shout");
                    return;
                }
            }
        }


        private WoWItem HaveItemCheck(List<uint> listId)
        {
            foreach (WoWItem item in ObjectManager.GetObjectsOfType<WoWItem>(false))
            {
                if (listId.Contains(item.Entry))
                {
                    return item;
                }
            }
            return null;
        }


        private List<WoWUnit> getAdds()
        {
            List<WoWUnit> mobList = ObjectManager.GetObjectsOfType<WoWUnit>(false);
            List<WoWUnit> enemyMobList = new List<WoWUnit>();

            //slog("--------------------");
            foreach (WoWUnit thing in mobList)
            {
                try
                {
                    if (thing.Guid != Me.Guid && thing.Guid != Me.Pet.Guid && (thing.IsTargetingMe || thing.IsTargetingPet))
                    {
                        //string whoisittargeting = "";
                        //if (thing.CurrentTargetGuid == Me.Guid)
                        //{
                        //    whoisittargeting = " --> Me";
                        //}
                        //else if (thing.CurrentTargetGuid == Me.Pet.Guid)
                        //{
                        //    whoisittargeting = " --> Pet";
                        //}

                        //slog("Add: " + thing.Name + whoisittargeting);
                        enemyMobList.Add(thing);
                    }
                    else
                    {
                        //slog("add ELSE: "+ thing.Name);
                    }
                }
                catch (Exception ex)
                {
                    //slog("Add error.");
                }
            }

            //slog("--------------------");
            if (enemyMobList.Count > 1)
            {
                slog("Warning: there are " + enemyMobList.Count.ToString() + " attackers.");
            }
            return enemyMobList;

        }


        private bool HaveBandages()
        {
            WoWItem bandage = HaveItemCheck(bandageEID);
            if (bandage != null)
            {
                return true;
            }

            return false;
        }

        public void UsePotion()
        {
            try
            {
                WoWItem potion = HaveItemCheck(potionEID);
                if (potion != null && (potionTimer.ElapsedMilliseconds > 60 * 1000 || !potionTimer.IsRunning))
                {
                    slog("** HEALTH LOW ** - " + potion.Name);
                    Lua.DoString("UseItemByName(\"" + potion.Name + "\")");
                    potionTimer.Reset();
                    potionTimer.Start();
                    Thread.Sleep(500);
                }
                /*else
                    slog("** HEALTH LOW ** - No potions!");
                 */
            }
            finally
            {

            }
        }


        public void UseBandage()
        {
            WoWItem bandage = HaveItemCheck(bandageEID);
            if (bandage != null)
            {
                slog("** BANDAGE NOW **");
                Lua.DoString("UseItemByName(\"" + bandage.Name + "\")");

                Stopwatch castTimeout = new Stopwatch();
                castTimeout.Reset();
                castTimeout.Start();

                while (castTimeout.ElapsedMilliseconds < 6000 || Me.ChanneledCasting != 0)
                {
                    slog("... bandaging...");
                    Thread.Sleep(50);
                }
            }
            else
                slog("** NO BANDAGES **");
        }

        private void StopMoving()
        {
            WoWMovement.MoveStop();
        }

        private void FaceTarget()
        {
            WoWMovement.Face();
        }


        private bool IsEnoughPower(string SpellName)
        {
            WoWSpell checkSpell = SpellManager.KnownSpells[SpellName];

            if (IsMyRageBelow(checkSpell.PowerCost))
            {
                return false;
            }
            return true;
        }



        private bool IsSpellOnCooldown(string SpellName)
        {
            WoWSpell checkSpell = SpellManager.KnownSpells[SpellName];

            if (!checkSpell.Cooldown)
            {
                return false;
            }
            return true;
        }



        private bool IsKnownSpell(string SpellName)
        {
            if (SpellManager.KnownSpells.ContainsKey(SpellName))
            {
                return true;
            }
            return false;
        }

        private bool CanCastSpell(string SpellName)
        {
            slog("CanCastSpell()" + SpellName, true);
            bool result = false;

            if (IsKnownSpell(SpellName) && !IsSpellOnCooldown(SpellName) && IsEnoughPower(SpellName))
            {
                result = true;
            }

            slog("CanCastSpell() = false", true);
            return result;
        }


        private bool CanCastSpell(string SpellName, int MinimumDistance, int MaximumDistance)
        {
            slog("CanCastSpell()" + SpellName, true);
            bool result = false;

            if (IsKnownSpell(SpellName) && !IsSpellOnCooldown(SpellName) && IsEnoughPower(SpellName) && TargetDistance >= MinimumDistance && TargetDistance <= MaximumDistance)
            {
                result = true;
            }

            slog("CanCastSpell() = false", true);
            return result;
        }

        private bool CanCastSpell(string SpellName, bool CheckCanCast)
        {
            slog("CanCastSpell()" + SpellName, true);
            bool result = false;

            if (IsKnownSpell(SpellName) && !IsSpellOnCooldown(SpellName) && IsEnoughPower(SpellName) && CanCastSpell(SpellName))
            {
                result = true;
            }

            slog("CanCastSpell() = false", true);
            return result;
        }



        private bool CastSpell(string SpellName)
        {
            bool result = false;

            result = SpellManager.CastSpell(SpellName);

            if (result)
            {
                slog(SpellName);
            }

            return result;

        }

        private bool CastSpell(string SpellName, bool ReturnImmediately)
        {
            bool result = false;

            result = SpellManager.CastSpell(SpellName, ReturnImmediately);

            if (result)
            {
                slog(SpellName);
            }

            return result;

        }

        private bool IsMyHealthBelow(int HealthLevel)
        {
            if (Me.HealthPercent < HealthLevel)
                if (Me.GetPowerPercent(WoWPowerType.Health) < HealthLevel)
                {
                    return true;
                }

            return false;
        }

        private bool IsMyHealthAbove(int HealthLevel)
        {
            if (Me.GetPowerPercent(WoWPowerType.Health) > HealthLevel)
            {
                return true;
            }

            return false;
        }

        private bool IsMyRageBelow(double RageLevel)
        {
            return (Me.CurrentRage < RageLevel);
        }

        private bool IsMyRageAbove(double RageLevel)
        {
            return (Me.CurrentRage > RageLevel);
        }

        private void AutoAttack(bool TurnOnAutoAttack)
        {
            if (TurnOnAutoAttack)
            {
                if (!Me.IsAutoAttacking)
                {
                    Lua.DoString("StartAttack()");
                }
            }
            else
            {
                Lua.DoString("StopAttack()");
            }

        }

        // testing something
        private double TargetHealth
        {
            get
            {
                if (!Me.GotTarget) return 0;
                return (Me.CurrentTarget.HealthPercent);
            }
        }


        private bool IsTargetHealthBelow(int HealthLevel)
        {
            double tempvalue = TargetHealth;
            if (tempvalue < HealthLevel)
            {
                return true;
            }

            return false;
        }

        private bool IsTargetHealthAbove(int HealthLevel)
        {
            double tempvalue = TargetHealth;
            if (tempvalue > HealthLevel)
            {
                return true;
            }

            return false;
        }


        private bool IsDebuffOnTarget(string DebuffName)
        {
            if (Me.CurrentTarget.Buffs.ContainsKey(DebuffName))
            {
                return true;
            }

            return false;
        }

        // uses LUA to detect buffs. This is required for some talents that put an 'invisible' buff on you. 
        // Eg... Hot Streak. Using the other method it always returns true. 
        public bool IsBuffOnMeLUA(string BuffName)
        {
            Lua.DoString("buffName,_,_,stackCount,_,_,_,_,_=UnitBuff(\"player\",\"" + BuffName + "\")");
            string buffName = Lua.GetLocalizedText("buffName", Me.BaseAddress);


            if (buffName == BuffName)
            {
                return true;
            }

            return false;
        }

        private bool IsBuffOnMe(string DebuffName)
        {
            if (Me.Buffs.ContainsKey(DebuffName))
            {
                return true;
            }

            return false;
        }

        private void BlacklistTarget(ulong TargetGUID, System.Int32 BlackListForSeconds)
        {
            Blacklist.Add(TargetGUID, System.TimeSpan.FromSeconds(BlackListForSeconds));
            Me.ClearTarget();
            return;
        }

        public bool InBattleGround()
        {

            return Battlegrounds.IsInsideBattleground;
        }

        private bool IsDistanceLessThan(double DistanceToTarget)
        {
            return Me.CurrentTarget.Distance < DistanceToTarget;
        }

        private bool IsDistanceMoreThan(double DistanceToTarget)
        {
            return Me.CurrentTarget.Distance > DistanceToTarget;
        }

        private void MoveToDistance(float distanceFromTarget)
        {
            if (IsDistanceMoreThan(distanceFromTarget))
            {
                Navigator.MoveTo(Me.CurrentTarget.Location.RayCast(WoWMathHelper.CalculateNeededFacing(Me.Location, Me.CurrentTarget.Location), distanceFromTarget));
            }
        }

        public void WaitWhileCasting()
        {
            Thread.Sleep(250);
            int a = 0;
            while ((Me.Casting != 0 || Me.ChanneledCasting != 0) && a < 50)
            {
                Thread.Sleep(100);
                ++a;
                slog("Waiting while casting ....", true);
            }
        }

        private bool LastRedMessage(string Message)
        {
            string _lastMessage = Me.LastRedErrorMessage.ToUpper();
            string _message = Message.ToUpper();
            bool result = false;

            if (_lastMessage.Contains(_message))
            {
                result = true;
            }

            return result;


        }

        private void EvadeCheck()
        {
            if (InBattleGround()) return;

            for (int i = -1; i > -5; i--)
            {
                List<string> clog = Lua.LuaGetReturnValue(string.Format("CombatLogSetCurrentEntry({0}) return CombatLogGetCurrentEntry(\"true\")", i), "_main.lua");
                if (clog == null || clog.Count < 12)
                    return;

                string sourceName = clog[3];
                string destName = clog[6];
                string missType = clog[11];
                if (missType.ToUpper() == "EVADE" && sourceName == _me.Name && destName == _me.CurrentTarget.Name)
                {
                    slog(_me.CurrentTarget.Name + " is evading.");
                    //BlacklistTarget(Me.CurrentTargetGuid, 5 * 60);
                    Blacklist.Add(Me.CurrentTargetGuid, TimeSpan.FromHours(2));
                    Me.ClearTarget();
                    break;
                }
            }
        }

        private bool IsTargetBlackListed
        {
            get
            {
                return (Blacklist.Contains(Me.CurrentTargetGuid));
            }
        }

        private void SpecCombat()
        {
            if (!CombatChecks()) { return; }

            DistanceCheck();

            if (IsMyRageBelow(30)) { Bloodrage(); }

            //if (IsDefensiveStance)
            //{
            //    CombatTank();
            //}

            switch (eType)
            {
                case WarriorType.Arms:
                    //CombatFury();
                    CombatArms();
                    break;

                case WarriorType.Fury:
                    CombatFury();
                    break;

                case WarriorType.Protection:
                    //CombatFury();
                    CombatProtection();
                    break;
            }
        }


        private void ChooseLowestHPTarget()
        {
            try
            {
                return;
                //if (!AddCheck) { return; }
                combatTimer.Reset();
                combatTimer.Start();
                //slog("START ChooseLowestHPTarget()");

                double LowestHP = 1000;
                WoWUnit LowestHPUnit = null;

                foreach (WoWUnit thing in Targeting.Instance.TargetList)
                {
                    try
                    {
                        if (thing.CurrentHealth < LowestHP && !thing.Dead && thing.Combat)
                        {
                            LowestHP = thing.CurrentHealth;
                            LowestHPUnit = thing;
                        }
                    }
                    catch (Exception ex)
                    {
                        slog("Add error: " + ex.Message);
                    }
                }

                //if (LowestHPUnit != null || LowestHPUnit.Guid != Me.CurrentTargetGuid)
                if (LowestHPUnit != null && LowestHPUnit.Guid != Me.CurrentTargetGuid)
                {

                    slog(LowestHPUnit.Name + " has lower health than " + Me.CurrentTarget.Name);
                    LowestHPUnit.Target();
                    FaceTarget();
                    //slog("Attacking " + LowestHPUnit.Name + " it has the lowest HP");
                }
            }
            finally
            {
                if (combatTimer.ElapsedMilliseconds > 1)
                {
                    //slog("END ChooseLowestHPTarget() " + combatTimer.ElapsedMilliseconds + "ms");
                    combatTimer.Reset();
                    combatTimer.Stop();
                }
            }

        }

        private bool IsValidPullTarget(WoWUnit unit)
        {
            //bool factionOK = Styx.Logic.Profiles.ProfileManager.CurrentProfile.Factions.Contains(unit.Faction);
            //bool factionOK = Global.CurrentProfile.Factions.Contains(unit.Faction);
            //bool distanceOK = unit.Distance < Logic.Targeting.PullDistance + 25;

            return (!Blacklist.Contains(unit.Guid) && !unit.Dead && !unit.IsMe && !unit.Tagged && !unit.Elite);
            //return (!Logic.Blacklist.Contains(unit.Guid) && !unit.Dead && !unit.IsMe && !unit.IsPet && !unit.Tagged && factionOK && distanceOK && !unit.Elite);
            //return (!Logic.Blacklist.Contains(unit.Guid) && !unit.Dead && !unit.IsMe && !unit.IsPet && !unit.Tagged && faction || unit.TaggedByMe);
        }

        private bool ShouldPickupMoreMobs
        {
            get
            {
                WaitWhileCasting();  // If we're casting or channeling then we're doing it with Volly. So just wait a minute ok.
                return (IsMyHealthAbove(65) && IsMyRageAbove(10) && useMultiMobPulling && addCount < maxNumberOfMobs);
            }
        }

        private void PickupMoreMobs()
        {
            double unitDistance = 100000;
            WoWUnit unit = null;
            WoWUnit unitTemp = null;

            List<WoWUnit> mobList = ObjectManager.GetObjectsOfType<WoWUnit>(false);


            foreach (WoWUnit thing in mobList)
            {
                try
                {
                    if (IsValidPullTarget(thing))
                    {
                        if (thing.Distance < unitDistance)
                        {
                            unitDistance = thing.Distance;
                            unit = thing;
                        }
                    }
                }
                catch (Exception ex)
                {
                }
            }

            if (unit != null)
            {
                slog("Multi-mob Pickup: " + unit.Name + " - " + (int)unit.Distance + " yards");
                unitTemp = Me.CurrentTarget;
                //AutoAttack(false);
                unit.Target();
                //PetAttackTarget();
                unitTemp.Target();
                //AutoAttack(true);
            }

        }

        private bool IsArmsSpec
        {
            get
            {
                return (eType == WarriorType.Arms);
            }
        }

        private bool IsFurySpec
        {
            get
            {
                return (eType == WarriorType.Fury);
            }
        }

        private bool IsProtectionSpec
        {
            get
            {
                return (eType == WarriorType.Protection);
            }
        }

        private bool IsBattleStance
        {
            get
            {
                //return (Me.Shapeshift == WoWUnit.ShapeshiftForm.BattleStance);
                return (Me.Shapeshift == ShapeshiftForm.BattleStance);
            }
        }

        private bool IsBerserkerStance
        {
            get
            {
                return (Me.Shapeshift == ShapeshiftForm.BerserkerStance);
            }
        }

        private bool IsDefensiveStance
        {
            get
            {
                return (Me.Shapeshift == ShapeshiftForm.DefensiveStance);
            }
        }

        private void UseRacials()
        {
            switch (Me.Race)
            {
                case WoWRace.Troll:
                    Berserking();
                    break;
            }

        }

        private void Lifeblood()
        {
            if (IsKnownSpell("Lifeblood") && !IsSpellOnCooldown("Lifeblood"))
            {
                CastSpell("Lifeblood");
            }
        }


        private void DistanceCheck()
        {
            //if (TargetDistance > 4 || !IsApproaching && TargetDistance > 4)

            if (Me.CurrentTarget.Fleeing && !InBattleGround())
            {
                if (TargetDistance > 1)
                {
                    MoveToDistance(0f);
                    return;
                }
            }


            if (TargetDistance > 4.75 && !InBattleGround())
            {
                MoveToDistance(3f);
            }

            if (TargetDistance > 4.5 && InBattleGround())
            {
                MoveToDistance(2f);
            }


            // Lets try to Charge or Intercept
            if (TargetDistance > 8 && TargetDistance < 24)
            {
                if (IsBerserkerStance && IsMyRageAbove(10) && CanCastSpell("Intercept"))
                {
                    if (Intercept())
                    {
                        return;
                    }
                }
                else if (IsBattleStance && CanCastSpell("Charge"))
                {
                    if (Charge())
                    {
                        return;
                    }
                }
            }

            if (TargetDistance <= 4 && !Me.CurrentTarget.Fleeing && Me.IsMoving)
            {
                StopMoving();
            }

        }

        private bool ShouldRend
        {
            get
            {
                if (!IsKnownSpell("Rend") || IsBerserkerStance) return false;
                return (!IsDebuffOnTarget("Rend") && (IsTargetHealthAbove(40) || Me.CurrentTarget.Level > Me.Level) && useRend || rendImmuneMobs.Contains(Me.CurrentTarget.Name) || LastRedMessage("immune"));
            }
        }

        private bool ShouldThunderClap
        {
            get
            {
                //return (!IsDebuffOnTarget("Thunder Clap") && IsTargetHealthAbove(50));
                if (!IsKnownSpell("Thunder Clap") || IsSpellOnCooldown("Thunder Clap") || IsBerserkerStance) return false;
                return (!IsDebuffOnTarget("Thunder Clap") && useThunderClap && TargetDistance < 10);
            }
        }


        private bool ShouldHamstring
        {
            get
            {
                if (!InBattleGround())
                {
                    return (useHamstring && !IsDebuffOnTarget("Hamstring") && IsTargetHealthBelow(healthToUseHamstring) && Me.CurrentTarget.CreatureType == WoWCreatureType.Humanoid && (IsBattleStance || IsBerserkerStance));
                }
                
                return (useHamstring && !IsDebuffOnTarget("Hamstring") && (IsBattleStance || IsBerserkerStance));
            }
        }

        private bool ShouldRageDump
        {
            get
            {
                if (Me.Level < 10) return true;
                return (Me.CurrentRage > minRageToUseDump || Me.CurrentRage >= 55);
            }
        }

        private bool IsTargetCasting
        {
            get
            {
                return (Me.CurrentTarget.IsCasting);
            }
        }

        private void CheckShield()
        {
            bool timerCheck = shieldTimer.ElapsedMilliseconds > 60 * 1000;

            if (!timerCheck)
            {
                return;
            }

            if (!IsKnownSpell("Shield Bash"))
            {
                return;
            }

            WoWSpell checkSpell = SpellManager.KnownSpells["Shield Bash"];
            if (checkSpell.Cooldown)
            {
                hasShield = true;
                return;
            }


            if (timerCheck && Me.CurrentRage > 10)
            {

                string SpellName = "Shield Bash";
                WoWSpell VR = SpellManager.KnownSpells[SpellName];
                var isUsable = Lua.LuaGetReturnValue("return IsUsableSpell('" + SpellName + "')", "hax.lua");

                if (isUsable != null)
                {
                    if (isUsable[0] == "1")
                    {
                        //slog("...Shield Equipped");
                        hasShield = true;
                    }
                }

                shieldTimer.Reset();
            }
            return;
        }

        private bool ShouldExecute
        {
            get
            {
                return (useExecute && IsTargetHealthBelow(21) && IsKnownSpell("Execute") && !IsSpellOnCooldown("Execute"));
            }
        }

        private bool ShouldDemoShout
        {
            get
            {
                return (IsKnownSpell("Demoralizing Shout") && !IsDebuffOnTarget("Demoralizing Shout") && !InBattleGround());
            }
        }

        private void CheckProcAbilities()
        {
            if (!CombatChecks()) { return; }
            FaceTarget();

            if (IsBuffOnMe("Slam!")) { slog("Slam! PROC!"); Slam(); return; }
            if (IsBuffOnMeLUA("Taste for Blood") && !IsSpellOnCooldown("Overpower")) { slog("Taste for Blood PROC!"); Overpower(); return; }
            if (IsBuffOnMeLUA("Sudden Death") && useExecute) { slog("Sudden Death PROC!"); Execute(); return; }
            if (IsBuffOnMeLUA("Sword and Board")) { slog("Sword and Board PROC!"); ShieldSlam(); return; }
        }

        private void SilenceBiatch()
        {
            if (IsDefensiveStance || IsBattleStance) { ShieldBash(); }
            if (IsBerserkerStance) { Pummel(); }

        }

        private bool ShouldMortalStrike
        {

            get
            {
                return (IsKnownSpell("Mortal Strike") && !IsDebuffOnTarget("Mortal Strike") && !IsSpellOnCooldown("Mortal Strike"));
            }
        }

        private bool ShouldIntimidatingShout
        {
            get
            {
                return (IsKnownSpell("Intimidating Shout") && !IsDebuffOnTarget("Intimidating Shout") && IsMyHealthAbove(50) && !IsSpellOnCooldown("Intimidating Shout") && useImtimidatingShout);
            }
        }

        private void StanceCheck()
        {
            try
            {
                slog("START StanceCheck()", true);
                if (useDefensiveStance || StanceDance == WarriorStance.Defensive)
                {
                    DefensiveStance();
                    return;
                }

                if (useBerserkerStance && !tmpBattleStanceCharge || StanceDance == WarriorStance.Berserker)
                {
                    BerserkerStance();
                    return;
                }

                if (useBattleStance || StanceDance == WarriorStance.Battle)
                {
                    BattleStance();
                    return;
                }

                if (Me.Level < 30 || !IsKnownSpell("Berserker Stance"))
                {
                    BattleStance();
                    return;
                }

                switch (eType)
                {
                    case WarriorType.Arms:
                        BattleStance();
                        break;

                    case WarriorType.Fury:
                        BerserkerStance();
                        break;

                    case WarriorType.Protection:
                        DefensiveStance();
                        break;
                }
            }
            finally
            {
                slog("END StanceCheck()", true);
            }
        }

        private void ChooseTarget()
        {
            try
            {
                // HB does not alwasy select the closest target. Sometimes it will target a mob further away than a more suitable mob
                // This routine just selects the closest appropriate mob. 

                slog("START ChooseTarget()", true);

                if (!useCCTargeting) return;
                combatTimer.Reset();
                combatTimer.Start();
                slog("Finding closest target...");

                double unitDistance = 100000;
                WoWUnit unit = null;
                WoWUnit unitInCombat = null;
                List<WoWUnit> mobList = ObjectManager.GetObjectsOfType<WoWUnit>(false);


                foreach (WoWUnit thing in mobList)
                {
                    try
                    {
                        if (thing.Combat && thing.CurrentTargetGuid == Me.Guid)
                        {
                            unitInCombat = thing;
                        }

                        if (IsValidPullTarget(thing))
                        {
                            if (thing.Distance < unitDistance || thing.Combat && thing.CurrentTargetGuid == Me.Guid)
                            {
                                unitDistance = thing.Distance;
                                unit = thing;
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                    }
                }

                if (unit != null)
                {
                    if (Me.CurrentTargetGuid != unit.Guid)
                    {
                        if (unitInCombat != null && unit != unitInCombat)
                        {
                            unit = unitInCombat;
                        }
                        string newTarget = unit.Name + " " + (int)unit.Distance;
                        string oldTarget = Me.CurrentTarget.Name + " " + (int)Me.CurrentTarget.Distance;
                        //pullGuid = Me.CurrentTarget.Guid;
                        slog(newTarget + " yards, its closer than " + oldTarget + " yards.");



                        //slog("Multi-mob Pickup: " + unit.Name + " - " + (int)unit.Distance + " yards");
                        //unitTemp = Me.CurrentTarget;
                        //AutoAttack(false);
                        unit.Target();
                        Thread.Sleep(250);
                        FaceTarget();
                        Thread.Sleep(250);
                        //unitTemp.Target();
                        //AutoAttack(true);
                    }
                }
            }
            finally
            {
                //slog("END ChooseTarget()", true);
                //slog("END ChooseTarget() " + combatTimer.ElapsedMilliseconds + "ms");
                combatTimer.Reset();
                combatTimer.Stop();

            }

        }

        private void RageDump()
        {
            if (useDevastateRageDump && IsKnownSpell("Devastate"))
            {

                if (Devastate())
                {
                    //slog("Rage Dump");
                }
            }
            else
            {
                if (HeroicStrike())
                {
                    //slog("Rage Dump");
                }
            }
        }

        private bool ShouldShieldWall
        {
            get
            {
                return (IsKnownSpell("Shield Wall") && !IsSpellOnCooldown("Shield Wall") && IsMyHealthBelow(40));
            }
        }

        private bool ShouldSpellReflection
        {
            get
            {
                return (IsKnownSpell("Spell Reflection") && !IsSpellOnCooldown("Spell Reflection") && IsTargetCasting);
            }
        }

        private void StanceDanceBack()
        {
            if (IsBattleStance && tmpBattleStanceCharge)
            {
                // before we swap back to Berserker stance lets apply a Rend
                if (ShouldRend) { Rend(); }
                if (ShouldThunderClap) { ThunderClap(); }

                tmpBattleStanceCharge = false;
                StanceDance = WarriorStance.None;
                StanceCheck();
            }
        }




        #endregion
    }

    public class CC_TalentGroup
    {
        private volatile LocalPlayer Me = ObjectManager.Me;

        public string[] _tabName = new string[4];
        public int[] _tabPoints = new int[4];
        public int _idxGroup;

        public int totalPoints
        {
            get
            {
                int nPoints = 0;
                for (int iTab = 1; iTab <= 3; iTab++)
                {
                    nPoints += _tabPoints[iTab];
                }

                return nPoints;
            }
        }

        public int Spec()
        {
            int nSpec = 0;
            if (_tabPoints[1] >= (_tabPoints[2] + _tabPoints[3]))
                nSpec = 1;
            else if (_tabPoints[2] >= (_tabPoints[1] + _tabPoints[3]))
                nSpec = 2;
            else if (_tabPoints[3] >= (_tabPoints[1] + _tabPoints[2]))
                nSpec = 3;

            return nSpec;
        }

        public bool Load(int nGroup)
        {
            int nTab;

            _idxGroup = nGroup;

            for (nTab = 1; nTab <= 3; nTab++)
            {
                Lua.DoString("readTabName, __, readTabPointsSpent, __, __ = GetTalentTabInfo(" + nTab + ",false,false," + _idxGroup + ")");
                _tabName[nTab] = Lua.GetLocalizedText("readTabName", Me.BaseAddress);
                _tabPoints[nTab] = Lua.GetLocalizedInt32("readTabPointsSpent", Me.BaseAddress);
            }

            return false;
        }

        public bool IsActiveGroup()
        {
            return GetActiveGroup() == _idxGroup;
        }

        public int GetActiveGroup()
        {
            Lua.DoString("activeTalentGroup = GetActiveTalentGroup(false,false)");
            int nActiveGroup = Lua.GetLocalizedInt32("activeTalentGroup", Me.BaseAddress);
            return nActiveGroup;
        }

        public void ActivateGroup()
        {
            Lua.DoString("SetActiveTalentGroup(" + _idxGroup + ")");
        }

        public int GetNumGroups()
        {
            Lua.DoString("numTalentGroups = GetNumTalentGroups(false,false)");
            int cntGroup = Lua.GetLocalizedInt32("numTalentGroups", Me.BaseAddress);
            return cntGroup;
        }
    }
}