using Styx;
using Styx.Combat.CombatRoutine;
using Styx.Helpers;
using Styx.Logic.Combat;
using Styx.Logic.Pathing;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;

#pragma warning disable
/**************************/
/* Cimmerian 0.40 by Mord updated for HB2 by Hawker/*
/**************************/


namespace Cimmeran
{
    using System;
    using System.Threading;
    using System.Media;
    using System.Diagnostics;
    using System.Collections.Generic;
    using Styx.Logic;

    public class Deathknight : CombatRoutine
    {

        public override string Name { get { return "Cimmerian for HB2 by Mord"; } }
        public override WoWClass Class { get { return WoWClass.DeathKnight; } }
        public override bool NeedCombatBuffs { get { return false; } }
        public override bool NeedPullBuffs { get { return false; } }
        public override void CombatBuff() { }
        public override void PullBuff() { }
        public override bool NeedPreCombatBuffs { get { return false; } }
        public override void PreCombatBuff() { }
        public override bool NeedHeal { get { return false; } }
        public override bool NeedRest { get { return _me.HealthPercent < EatHealth; } }
        public override void Heal() { }

        #region Class Specific Variables

        /// /////////////////////////////////////////////////////////////////////
        /// //////////////////////////////**[Bools]**/
        ///////////////////////////
        /// /////////////////////////////////////////////////////////////////////
        /// In this box is a list of spells or abilities you can turn on or off//
        /// CHOOSE ONLY ONE ROTATION!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!//

        //
        /****************************Blood Rotations****************************/
        //        
        bool UseMordBloodRotation = false; //Moderate to High DPS. High Regeneration. Low Defense. Requires level 58
        //Mord Blood requires: IT, PS, HS, DC, MoB, VB, RT, (OB & DRW at Level 61)
        //If dealing with adds you will need Pestilence and Blood Boil        
        //Presence : Blood till 65. Then Unholy
        //Fill your Blood Tree First!!
        //This rotation will cast Death Strike till you train for Obliterate at level 61
        //Dancing Rune Weapon will cast at level 61
        //http://talent.mmo-champion.com/?deathknight#B6_nlOyp9_ksX4,aQO3eO,10192

        //
        /****************************Frost Rotations****************************/
        //

        bool UseMordFrostRotation = false; //Moderate to Very High DPS, low to moderate regeneration, High Defense. Requires level 58
        //Frost One requires: IT, PS, BS, FS, Hungering Cold, Unbreakable Armor (Howling Blast at 61)      
        //If dealing with adds you will need Pestilence
        //Presence : Blood till 65. Then Unholy
        //Fill your Frost Tree First!!
        //http://talent.mmo-champion.com/?deathknight#B6_nlOT93KK8yYm,FQp,10482
        /****************************************************************/

        //
        /****************************Unholy Rotations****************************/
        //

        bool UseMordUnholyRotation = true; //Very High DPS, low regeneration. Moderate Defense. Requires level 58
        //Mord Unholy requires: IT, PS, BS, SS, BoneShield, Summon Gargoyle at 61
        //If dealing with adds you will need Pestilence and Blood Boil
        //Fill your unholy tree first!
        //Perma Pet recommended. Turn leap off to help prevent targeting issues
        //Presence : Blood till 65. Then Unholy
        //http://talent.mmo-champion.com/?deathknight#_CJTpDsu3dpyiy,FQp,10482
        /****************************************************************/

        //
        /****************************Starting Rotation****************************/
        //

        bool UseStandardRotation = false; //Standard Level 55 Rotation
        //Standard Rotation will work at any level and uses no talents
        /****************************************************************/

        //Adds
        bool IgnoreAdds = false; //Will cast certain AoE abilities is this is set to false               

        //Interupt Spells       
        bool UseStrangulate = true; //Strangulate to interupt casting
        bool UseMindFreeze = true; //Mind Freeze       

        //Defense Spells                
        bool UseIceboundFortitude = true; //Icebound Fortitude

        //Other
        bool UseRaiseDead = false; //Raise Dead     
        bool UseHorn = true; //Horn of Winter

        //Openers
        bool OpenWithDeathGrip = true;
        bool OpenWithDarkCommand = false; // If Deathgrip is on Cooldown
        bool OpenWithDeathCoil = true; // If DeathGrip is on Cooldown & not open with DarkCommand
        bool OpenWithIcyTouch = true; // If other openers are on Cooldown

        /////////////////////////////////////////////////////////////////////////

        /// /////////////////////////////////////////////////////////////////////
        /// //////////////////////////////**[Ints]**////////////////////////////
        /// /////////////////////////////////////////////////////////////////////
        /// Set the points or percentages for things to be activated/////////////        

        //Out of Combat Resting Abilities

        int EatHealth = 55; //Eat when at this %

        //In Combat Abilites

        int MinDeathGripRange = 15; //Death Grip will not be cast if you are within this range (Unless interupting a caster)
        int MinDarkCommandRange = 15; //Dark Command will not be cast if you are within this range
        int IceboundFortitudeHealth = 50; //Cast Icebound Fortitude when you reach this %
        int RuneTapHealth = 75; //Cast Rune Tap when you reach this %
        int MarkOfBloodHealth = 25; //Cast Mark of Blood when you reach this %
        int VampiricBloodHealth = 15; //Cast Vampiric Blood when you reach this %
        int UnbreakableArmorHealth = 50; //Cast Unbreakable Armor when you reach this %        
        int DRWThreshold = 40; //Dancing Rune Weapon will not be cast if you target is below this %
        int HysteriaThreshold = 31; //Hysteria will not be cast if you are at or below this %


        /// ////////////////////////////////////////////////////////////////////////////////
        /// 
        /// ////////////////////////////////////////////////////////////////////////
        /// //////////////////////////////**System**////////////////////////////
        /// /////////////////////////////////////////////////////////////////////
        /// Other Various things to set/////////////////////////////////////////

        bool UseSlog = true; //Basic Commands will display for user
        bool UseUltraSlog = false; //Debug Commands will display for user
        bool PlayerAlert = false; //Be alert of players around?
        bool WaitForApproach = true; // After pull wait for target to approach. (If DeathGrip isnt used)

        ////////////////////////////////////////////////////////////////////////    
        /// 
        /// ////////////////////////////////////////        
        /// ///Do not change anything in this box///
        /// ////////////////////////////////////////
        /// 
        //bool UseBloodTap = false;
        bool DRWToggle = false;
        bool SGToggle = false;
        bool HCToggle = false;
        bool GotPlayers = false;
        public static int StuckCount;
        bool GotAdds = false;
        bool PullSpam = false;
        bool DRWSpam = false;
        bool AddSpam = false;

        /// ////////////////////////////////////////////////////////////////////////////////           



        #endregion

        #region Rest

        public override void Rest()
        {
            if (_me.HealthPercent <= EatHealth)
            {
                Slog("Health is at " + _me.HealthPercent + "%, Eat.");
                Styx.Logic.Common.Rest.Feed();

            }
        }

        #endregion

        #region Enchanting

        private static readonly List<WoWItem> AlreadyDisenchanted = new List<WoWItem>();

        /// <summary>
        /// List from wowhead
        /// http://www.wowhead.com/?items=7.12#0+2-1
        /// </summary>
        private readonly List<uint> _doNotDisenchant = new List<uint>()
        {
            // mats
            10940, 10938, 10939, 10998, 10978, 11082, 11083, 11084, 11134, 11139, 11174, 11175,
            11176, 11177, 11178, 14343, 14344, 16202, 16203, 16204, 20725, 22445, 22446, 22447,
            22448, 22449, 22450, 34052, 34053, 34054, 34055, 34056, 34057, 46849, 49649,
            // rods
            44452,
            // lockbox
            43622,
            // healthstones
            5509, 5510, 5511, 5512, 9421, 19004, 19005, 19006,  
            19007, 19008, 19009, 19010, 19011, 19012, 19013, 
            22103, 22104, 22105, 36889, 36890, 36891, 36892,
            36893, 36894,
            // soulstones

            // firestones
            3615, 3616, 3617, 3618, 3619, 3620,

            // spellstones
            41191, 41192, 41193, 41194, 41195, 41196,
        };

        private List<WoWItem> GetItemsToDisenchant()
        {
            try
            {
                if (!SpellManager.KnownSpells.ContainsKey("Disenchant") || _me.ZoneId == 3277 || _me.ZoneId == 3358 || _me.ZoneId == 2597) // wsg, ab and av
                    return null;

                List<WoWItem> targetItems = ObjectManager.GetObjectsOfType<WoWItem>(false);

                for (int a = targetItems.Count - 1; a >= 0; --a)
                {
                    if (_doNotDisenchant.Contains(targetItems[a].Entry) ||
                        AlreadyDisenchanted.Contains(targetItems[a]))
                    {
                        targetItems.RemoveAt(a);
                    }
                    else if (targetItems[a].IsSoulbound ||
                        targetItems[a].IsAccountBound ||
                        targetItems[a].Quality != WoWItemQuality.Uncommon)
                    {
                        AlreadyDisenchanted.Add(targetItems[a]);
                        targetItems.RemoveAt(a);
                    }
                }

                if (targetItems.Count > 0)
                {
                    foreach (WoWItem deItem in targetItems)
                    {
                        Slog("Disenchant: " + deItem.Name);
                    }
                    return targetItems;
                }
            }
            catch
            {
                Slog("Getting Disenchant list failed");
            }

            // Log("Nothing to Disenchant.");
            return null;
        }

        private static void DisenchantItems(IEnumerable<WoWItem> itemList)
        {
            try
            {
                if (itemList == null)
                    return;

                foreach (WoWItem item in itemList)
                {
                    Slog("Disenchanting: " + item.Name);
                    SpellManager.CastSpell("Disenchant", false);
                    Thread.Sleep(500);
                    Lua.DoString("UseItemByName(\"" + item.Name + "\")");

                    Thread.Sleep(500);

                    int tickCount = Environment.TickCount;
                    while (_me.Casting > 0 && !_me.Combat && Environment.TickCount - tickCount <= 5000)
                        Thread.Sleep(250);

                    Thread.Sleep(2500);

                    // wait for lootframe to close
                    var timer = new Stopwatch();
                    timer.Start();

                    tickCount = Environment.TickCount;
                    while (LootTargeting.LootFrameIsOpen && !_me.Combat && Environment.TickCount - tickCount <= 7000)
                    {
                        Thread.Sleep(1000);

                        if (timer.ElapsedMilliseconds >= 6000)
                        {
                            break;
                        }
                    }

                    if (!_me.Combat)
                    {
                        Thread.Sleep(1500);
                        AlreadyDisenchanted.Add(item);
                    }
                    else
                    {
                        return;
                    }
                }
            }
            catch
            {
                Slog("DE failed");
                return;
            }
            return;
        }

        #endregion

        #region Private Members

        private static void Slog(string msg)
        {
            if (msg == _logspam)
            {
                return;
            }

            Logging.Write(msg);
            _logspam = msg;
        }

        #endregion

        #region Global Variables

        Dictionary<WoWPlayer, DateTime> followers = new Dictionary<WoWPlayer, DateTime>();

        private static readonly LocalPlayer _me = ObjectManager.Me;
        private static string _logspam;

        #endregion

        #region Pull

        private readonly Stopwatch _pullTimer = new Stopwatch(); //A Pull Timer

        public override void Pull()
        {

            if (_me.CurrentTarget != null)
            {

                /////////////Checks//////////////////
                BuffsCheck(); //Make sure buffs are good before pulling                             
                /////////////////////////////////////

                if (!_pullTimer.IsRunning)
                    _pullTimer.Start(); //Make sure timer is running

                if (_me.CurrentTarget.Distance > 100) //Also make sure we are sorta close
                    return;

                if (!PullSpam)
                    Slog("Killing " + _me.CurrentTarget.Name + " at distance " + System.Math.Floor(_me.CurrentTarget.Distance));

                if (_me.CurrentTarget.Distance >= 29 && !_me.Combat && _pullTimer.Elapsed.Seconds < 10 && (OpenWithDeathGrip || OpenWithDarkCommand)) //Move in for the kill
                {
                    Navigator.MoveTo(WoWMovement.CalculatePointFrom(_me.CurrentTarget.Location, 4.0f));
                    Thread.Sleep(500);
                    PullSpam = true;
                    StuckDetector();
                    return;

                }

                if (AvoidAdds())
                    Slog("Possible extra pull");

                if (_pullTimer.Elapsed.Seconds > 10) //Took too long to pull
                {

                    Slog("Pull lasted too long, Moving onto somthing else for now");
                    Blacklist.Add(_me.CurrentTarget != null ? _me.CurrentTarget.CurrentTargetGuid : 0, TimeSpan.FromMinutes(15));

                    _me.ClearTarget();
                    _pullTimer.Reset();
                    return;

                }

                ///////////Pull////////////
                _pullTimer.Reset();
                if (opener()) //Do Opener
                {
                    Slog("Opener was successfull!");
                    PullSpam = false;
                }

                else
                    Slog("Opener failed! Defaulting to Meele");
                ///////////////////////////               

            }

        }

        #endregion

        #region Combat

        public override void Combat()
        {

            if (_me.GotTarget && _me.CurrentTarget != null)
            {

                if ((!_me.CurrentTarget.IsTargetingMe) && (_me.CurrentTarget.CurrentHealth > 99))
                {

                    Slog("Targeting Error! Clear target and attempt again.");

                    WoWMovement.MoveStop();

                    _me.ClearTarget();
                }


                RedMessageReactor(); //At the start of combat make sure we are facing the target

                if (AutoAttack()) //Start Auto Attack
                    return;

                if (CastReactor())//Deal with Casters
                    return;

                if (MoveToMelee())
                    return;

                //Combat Spells

                if (UseStandardRotation) //Level 55 Rotation
                    StartingRotation();

                if (UseMordBloodRotation) //Level 58 Blood Rotation
                    MordBlood();

                if (UseMordUnholyRotation) //Level 58 Unholy Rotation
                    MordUnholy();

                if (UseMordFrostRotation) //Level 58 Frost Rotation
                    MordFrost();

                //End Combat Spells                        

            }

        }

        #endregion

        #region Heal Reactor

        /////////////////////////////////
        //This will decide if we need a heal
        /////////////////////////////////

        public void HealReactor()
        {
            if (SpellManager.KnownSpells.ContainsKey("Rune Tap") && ((_me.GetPowerPercent(WoWPowerType.Health)) <= RuneTapHealth))
            {

                RuneTap();

            }

            if ((SpellManager.KnownSpells.ContainsKey("Mark of Blood") && (_me.GetPowerPercent(WoWPowerType.Health)) <= MarkOfBloodHealth) && (_me.CurrentTarget.CurrentHealth > 75))
            {

                MarkOfBlood();

            }

            if ((SpellManager.KnownSpells.ContainsKey("Vampiric Blood")) && ((_me.GetPowerPercent(WoWPowerType.Health)) <= VampiricBloodHealth) && (_me.CurrentTarget.CurrentHealth > 75))
            {

                VampiricBlood();

            }

            if (((SpellManager.KnownSpells.ContainsKey("Unbreakable Armor")) && (_me.GetPowerPercent(WoWPowerType.Health)) <= UnbreakableArmorHealth) && (_me.CurrentTarget.CurrentHealth > 75))
            {

                UnbreakableArmor();

            }

            if (((UseIceboundFortitude) && (_me.GetPowerPercent(WoWPowerType.Health)) <= IceboundFortitudeHealth) && (_me.CurrentTarget.CurrentHealth > 75))
            {

                IceboundFortitude();

            }

        }

        #endregion

        #region Instant Reactor

        /////////////////////////////////
        //This will detect cooldown abilities and use them
        /////////////////////////////////

        public void InstantReactor() //Change to buff reactor when casting works
        {
            if ((SpellManager.KnownSpells.ContainsKey("Hysteria")) && (_me.GetPowerPercent(WoWPowerType.Health) > HysteriaThreshold))
                Hysteria();
        }

        #endregion

        #region Cast Detector

        /////////////////////////////////
        //This will detect casters and deal with them
        /////////////////////////////////

        public bool CastReactor()
        {

            if (_me.CurrentTarget.IsCasting) //If target starts to cast, move in.
            {
                Slog("Target is casting");

                if ((UseStrangulate) && (SpellManager.CanCastSpell("Strangulate")) && (_me.CurrentTarget.Distance <= 29) && (_me.CurrentTarget.Distance > 4)) //Strangulate to Interupt Caster
                {
                    Slog("Too far away! Interupt using Strangulate");
                    Strangulate();
                    return true;
                }

                if ((UseStrangulate) && (!SpellManager.CanCastSpell("Strangulate")) && (SpellManager.CanCastSpell("Death Grip")) && (_me.CurrentTarget.Distance <= 29) && (_me.CurrentTarget.Distance > 4)) //If St on CD cast DeathGrip
                {
                    Slog("Too far away! Strangulate not ready! Use Deathgrip.");
                    DeathGrip();
                    return true;

                }

                if ((_me.CurrentTarget.Distance <= 4) && (_me.CurrentRunicPower > 20))
                {

                    if (UseMindFreeze) //Interupt the cast if MindFreeze is available
                    {
                        MindFreeze();
                        return true;

                    }

                    return false;

                }

            }

            return false;
        }

        #endregion

        #region Runic Power Reactor

        /////////////////////////////////
        //This will keep track of runic power and use it
        /////////////////////////////////

        public void RunicPowerReactor()
        {
            if ((SpellManager.KnownSpells.ContainsKey("Hungering Cold") && (GotAdds)))
            {
                HCToggle = true;

            }
            //Dancing Rune Weapon workaround provided by TIA

            if (SpellManager.KnownSpells.ContainsKey("Dancing Rune Weapon") && (_me.CurrentTarget.CurrentHealth > DRWThreshold))
            {

                WoWSpell spell = SpellManager.KnownSpells["Dancing Rune Weapon"];

                if (!spell.Cooldown) //We may not have enoph RP to cast. So check if its on CD
                {
                    if (!DRWSpam)
                        Slog("Dancing Rune Weapon Ready.... Disable RP Dump");

                    DRWToggle = true;

                    DRWSpam = true;

                }

            }

            if (SpellManager.KnownSpells.ContainsKey("Summon Gargoyle"))
            {

                WoWSpell spell = SpellManager.KnownSpells["Summon Gargoyle"];

                if (!spell.Cooldown) //We may not have enoph RP to cast. So check if its on CD
                {
                    Slog("Summon Gargoyle Ready.... Disable RP Dump");

                    SGToggle = true;
                }

            }

            if ((!SGToggle) && (!DRWToggle) && (!UseMordFrostRotation) && (!HCToggle) && (_me.CurrentRunicPower > 40)) //Need 40 RP to cast           

                DeathCoil();

            if ((!SGToggle) && (!DRWToggle) && (UseMordFrostRotation) && (!HCToggle) && (_me.CurrentRunicPower > 40)) //Need 40 RP to cast           

                FrostStrike();

            if ((DRWToggle) && (_me.CurrentRunicPower > 60)) //Need 60 RP to cast           

                DRW();

            if ((SGToggle) && (_me.CurrentRunicPower > 60)) //Need 60 RP to cast           

                SummonGargoyle();

        }

        #endregion

        #region Red Messages

        /////////////////////////////////
        //This will detect red messages and react to them
        /////////////////////////////////

        public bool RedMessageReactor()
        {
            if (_me.LastRedErrorMessage.Contains("facing")) //Turn around dummy
            {
                WoWMovement.Face();
                Thread.Sleep(250);
                return true;
            }

            if (_me.LastRedErrorMessage.Contains("front")) //Turn around dummy
            {
                WoWMovement.Face();
                Thread.Sleep(250);
                return true;
            }

            return false;

        }

        #endregion

        #region Opener

        /////////////////////////////////
        //Decide an opener
        /////////////////////////////////

        public bool opener()
        {

            if ((OpenWithDeathGrip) && (_me.CurrentTarget.Distance <= 29) && (_me.CurrentTarget.Distance > MinDeathGripRange)) //DeathGrip
            {

                if (SpellManager.CanCastSpell("Death Grip")) //Spell Ready?
                {

                    WoWMovement.MoveStop();
                    Thread.Sleep(100);
                    WoWMovement.Face();
                    Thread.Sleep(100);

                    DeathGrip();//Do Opener

                    Thread.Sleep(100);

                    if (PlayerAlert)
                        ScanForPlayers(); //Find players near

                    return true;

                }

            }

            if ((OpenWithDarkCommand) && (_me.CurrentTarget.Distance <= 29) && (_me.CurrentTarget.Distance > MinDarkCommandRange)) //DarkCommand 
            {

                if (SpellManager.CanCastSpell("Dark Command")) //Spell Ready?
                {

                    WoWMovement.MoveStop();
                    Thread.Sleep(100);
                    WoWMovement.Face();
                    Thread.Sleep(100);

                    DarkCommand();//Do Opener 

                    Thread.Sleep(100);

                    if (PlayerAlert)
                        ScanForPlayers(); //Find players near 

                    return true;

                }

            }

            if ((OpenWithDeathCoil) && (_me.CurrentTarget.Distance <= 29) && (_me.CurrentRunicPower > 40)) //Death Coil 
            {

                if (SpellManager.CanCastSpell("Death Coil")) //Spell Ready?
                {

                    WoWMovement.MoveStop();
                    Thread.Sleep(100);
                    WoWMovement.Face();
                    Thread.Sleep(100);

                    DeathCoil();//Do Opener               

                    if (PlayerAlert)
                        ScanForPlayers(); //Find players near 

                    return true;

                }

            }

            if ((OpenWithIcyTouch) && (_me.CurrentTarget.Distance <= 19)) //Icy Touch 
            {

                if (SpellManager.CanCastSpell("Icy Touch")) //Spell Ready?
                {

                    WoWMovement.MoveStop();
                    Thread.Sleep(100);
                    WoWMovement.Face();
                    Thread.Sleep(100);

                    IcyTouch();//Do Opener

                    Thread.Sleep(100);

                    if (PlayerAlert)
                        ScanForPlayers(); //Find players near 

                    return true;

                }

            }

            return false;

        }

        #endregion

        #region AvoidAdds

        /////////////////////////////////
        //Try to avoid adds on pull. (Credit to Ninko for an outline)
        /////////////////////////////////

        public bool AvoidAdds()
        {

            var units = new List<WoWUnit>(ObjectManager.GetObjectsOfType<WoWUnit>());

            foreach (WoWUnit unit in units)
            {

                if (unit.Location.Distance(_me.CurrentTarget.Location) > 30)
                    return false;

                if ((unit.Location.Distance(_me.CurrentTarget.Location) <= 30) && (unit.Guid != _me.CurrentTargetGuid) && (unit.Guid != _me.Guid))
                {
                    return true;
                }
            }

            return false;

        }


        #endregion

        #region Buffs

        /////////////////////////////////
        //Check for Buffs
        /////////////////////////////////

        void BuffsCheck()
        {

            if (SpellManager.KnownSpells.ContainsKey("Bone Shield"))
            {
                WoWMovement.MoveStop();
                Thread.Sleep(100);
                BoneShield();

            }

            if (UseHorn)
            {

                if ((!_me.Buffs.ContainsKey("Horn of Winter")))
                {

                    WoWMovement.MoveStop();
                    Thread.Sleep(100);
                    HornOfWinter();

                }

            }

            if ((UseRaiseDead) && (SpellManager.KnownSpells.ContainsKey("Raise Dead")))

                RaiseDead();

        }

        #endregion

        #region PlayerDetector

        //Credit to Hawker for ScanForPlayers()

        private List<WoWUnit> ScanForPlayers()
        {
            double d;
            List<WoWUnit> PlayerList = new List<WoWUnit>();
            foreach (WoWObject Player in ObjectManager.ObjectList)
            {
                if (Player.Type == WoWObjectType.Player && Player.Guid != _me.Guid)
                {
                    WoWPlayer newPlayer = Player.ToPlayer();

                    if (newPlayer.Distance < 100)
                    {
                        d = Math.Round(newPlayer.Distance, 1);
                        Slog("Player Named: " + newPlayer.Name + " Is " + d + " yards away.");
                        SystemSounds.Exclamation.Play();
                    }

                    if (followers.ContainsKey(newPlayer))
                    {
                        foreach (KeyValuePair<WoWPlayer, DateTime> guy in followers)
                        {

                            if (guy.Key == newPlayer)
                            {

                                TimeSpan duration = DateTime.Now - guy.Value;

                            }
                        }
                    }
                    else
                    {
                        followers.Add(newPlayer, DateTime.Now);
                    }
                }
            }
            return PlayerList;
        }

        #endregion

        #region ApproachDetector

        /////////////////////////////////
        //This will detect if a mob is approaching
        /////////////////////////////////

        public bool ApproachDetector()
        {

            double ADone;
            double ADtwo;

            ADone = _me.CurrentTarget.Distance; //Initial Distance
            Thread.Sleep(100);
            ADtwo = _me.CurrentTarget.Distance; //Secondary Distance

            if (ADone > ADtwo) //Difference between the two
            {
                return true;
            }

            return false;

        }



        #endregion

        #region GetAdds

        //Credit to Hawker for getAdds()

        private List<WoWUnit> getAdds()
        {
            List<WoWUnit> mobList = new List<WoWUnit>();
            List<WoWUnit> enemyMobList = new List<WoWUnit>();
            List<WoWObject> longList = new List<WoWObject>();
            longList = ObjectManager.ObjectList;

            foreach (WoWObject thing in longList)
            {
                if (thing.Type == WoWObjectType.Unit)
                {
                    mobList.Add(thing.ToUnit());
                }
            }

            foreach (WoWUnit thing in mobList)
            {
                if ((thing.Guid != _me.Guid) &&
                    (thing.IsTargetingMe))
                {

                    enemyMobList.Add(thing);

                }

            }

            if (enemyMobList.Count > 1)
            {
                if (!AddSpam)
                    Slog("Warning: We have " + enemyMobList.Count.ToString() + " attackers.");

                GotAdds = true;

                AddSpam = true;

            }

            else
            {
                GotAdds = false;

                AddSpam = false;
            }

            return enemyMobList;

        }

        #endregion

        #region AddsReactor

        /////////////////////////////////
        //What to do when we have adds
        /////////////////////////////////

        public void AddsReactor()
        {


        }


        #endregion

        #region StuckDetector

        /////////////////////////////////
        //This will detect if we are stuck. Credit to Ninko for the outline
        /////////////////////////////////

        public bool StuckDetector()
        {

            double Stuckone;
            double Stucktwo;
            double So;
            double St;

            Stuckone = _me.CurrentTarget.Distance; //Initial Distance
            So = Math.Round(Stuckone, 2);
            Thread.Sleep(100);
            Stucktwo = _me.CurrentTarget.Distance; //Secondary Distance
            St = Math.Round(Stucktwo, 2);

            if (So == St) //Difference between the two
            {
                StuckCount++;

                switch (StuckCount)
                {

                    case 1:

                        Slog("We might be stuck, Jump!");
                        KeyboardManager.PressKey((char)32); //Jump Key
                        Thread.Sleep(500);
                        break;

                    case 2:

                        WoWMovement.MoveStop();
                        Slog("Still Stuck! Strafe Left");
                        SafeMove(WoWMovement.MovementDirection.Backwards, 1500);
                        SafeMove(WoWMovement.MovementDirection.StrafeLeft, 1500);
                        break;

                    case 3:

                        WoWMovement.MoveStop();
                        Slog("Still Stuck! Strafe Right");
                        SafeMove(WoWMovement.MovementDirection.Backwards, 1500);
                        SafeMove(WoWMovement.MovementDirection.StrafeRight, 1500);
                        break;

                }

                return true;

            }

            else
            {
                StuckCount = 0;
                return false;
            }

        }

        #endregion

        #region Auto Attack

        /////////////////////////////////
        //Simply makes sure we are attacking
        /////////////////////////////////

        public bool AutoAttack()
        {
            if (!_me.IsAutoAttacking && ObjectManager.Me.GotTarget)
            {
                if (!ObjectManager.Me.CurrentTarget.Dead)
                {
                    if (_me.Mounted)
                        Mount.Dismount();

                    Logging.Write("AutoAttack:{0}", _me.IsAutoAttacking);
                    Lua.DoString("StartAttack()");
                    return true;
                }

                return false;

            }

            return false;

        }


        #endregion

        #region Move to Melee

        /////////////////////////////////
        //Checks range to target and moves accordingly
        /////////////////////////////////

        public bool MoveToMelee()
        {
            if (_me.CurrentTarget.Distance > 5) //We need to get in meele range first
            {

                if ((ApproachDetector()) && (WaitForApproach))
                {

                    return true;

                }

                Navigator.MoveTo(WoWMovement.CalculatePointFrom(_me.CurrentTarget.Location, 4.0f));
                Thread.Sleep(500);
                Thread.Sleep(100);
                if (_me.CurrentTarget.Distance > 4.5)
                {

                    if (StuckDetector())
                        return true;

                }

                return true;

            }

            else
            {
                RedMessageReactor(); //We might be in melee but not facing the right direction
                StuckCount = 0; //No need for stuck detector in meele
                return false;

            }



        }

        #endregion

        #region Rotation : Level 55

        /////////////////////////////////
        //Starting Rotation.
        //Assumes no talents
        //Only Checks are Death Coil, Range and facing
        /////////////////////////////////

        public void StartingRotation()
        {

            SRChecks();
            IcyTouch();

            SRChecks();
            PlagueStrike();

            SRChecks();
            BloodStrike();

            Thread.Sleep(1000);

        }

        public void SRChecks()
        {

            RunicPowerReactor(); //Dump RP if we have it
            MoveToMelee(); //Range Checks, and faces

        }

        #endregion

        #region Rotation : Mord Unholy

        /////////////////////////////////
        //General Unholy Spec based Rotation. Requires level 58
        //http://talent.mmo-champion.com/?deathknight#_CJTpDsu3dpyiy,FQp,10482
        //Will not cast Gargoyle till 61
        //
        /////////////////////////////////


        public void MordUnholy()
        {
        MUIcyTouch:
            if (!GotAdds)
            {
                MUChecks();
                IcyTouch();
            }

        MUPlagueStrike:
            if (!GotAdds)
            {
                MUChecks();
                PlagueStrike();
            }

        MUBloodStrikeOne:
            if (!GotAdds)
            {
                MUChecks();
                BloodStrike();
            }

        MUScourgeStrike:
            if (!GotAdds)
            {
                MUChecks();
                ScourgeStrike();
            }

        MUBloodStrikeTwo:
            if (!GotAdds)
            {
                MUChecks();
                BloodStrike();
            }

            Thread.Sleep(1000);


            if (GotAdds)
            {

                if (!_me.CurrentTarget.Buffs.ContainsKey("Frost Fever"))
                {
                    if (!GotAdds)
                        goto MUIcyTouch;

                    MUChecks();
                    IcyTouch();

                }

                if (!_me.CurrentTarget.Buffs.ContainsKey("Blood Plague"))
                {

                    if (!GotAdds)
                        goto MUPlagueStrike;

                    MUChecks();
                    PlagueStrike();

                }

                if (!GotAdds)
                    goto MUBloodStrikeOne;

                MUChecks();
                Pestilence();

                if (!GotAdds)
                    goto MUScourgeStrike;

                MUChecks();
                ScourgeStrike();

                if (!GotAdds)
                    goto MUBloodStrikeTwo;

                MUChecks();
                BloodBoil();

                Thread.Sleep(1000);

            }

        }

        public void MUChecks()
        {

            HealReactor(); //Before doing anything. Do we need a heal?
            MoveToMelee(); //Range Checks, and faces
            CastReactor(); //If target is casting

            if (!IgnoreAdds)
                getAdds(); //Check for adds while in combat

            InstantReactor(); //Check instant abilities and use if needed
            RunicPowerReactor(); //Dump RP if we have it

        }

        #endregion

        #region Rotation : Mord Blood

        /////////////////////////////////
        //Mord Blood Spec based Rotation. Requires level 58 (Will use Obliterate at 61)
        //http://talent.mmo-champion.com/?deathknight#B6_nlQtnrjLKLc,aQO3eO,10192
        //
        //Dealing with adds, this will cast Blood Boil instead of the first Heart Strike
        /////////////////////////////////


        public void MordBlood()
        {
        MBIcyTouch:
            if (!GotAdds)
            {
                MBChecks();
                IcyTouch();
            }

        MBPlagueStrike:
            if (!GotAdds)
            {
                MBChecks();
                PlagueStrike();
            }

        MBHeartStrikeOne:
            if (!GotAdds)
            {
                MBChecks();
                HeartStrike();
            }

        MBHeartStrikeTwo:
            if (!GotAdds)
            {
                MBChecks();
                HeartStrike();
            }

        MBObliterate:
            if (!GotAdds)
            {
                MBChecks();
                if (OBCheck())
                    Obliterate();

                else
                    DeathStrike();
            }

            Thread.Sleep(1000);


            if (GotAdds)
            {

                if (!_me.CurrentTarget.Buffs.ContainsKey("Frost Fever"))
                {
                    if (!GotAdds)
                        goto MBIcyTouch;

                    MBChecks();
                    IcyTouch();

                }

                if (!_me.CurrentTarget.Buffs.ContainsKey("Blood Plague"))
                {

                    if (!GotAdds)
                        goto MBPlagueStrike;

                    MBChecks();
                    PlagueStrike();

                }

                if (!GotAdds)
                    goto MBHeartStrikeOne;

                MBChecks();
                Pestilence();

                if (!GotAdds)
                    goto MBHeartStrikeTwo;

                MBChecks();
                BloodBoil();

                if (!GotAdds)
                    goto MBObliterate;

                MBChecks();
                if (OBCheck())
                    Obliterate();

                else
                    DeathStrike();

                Thread.Sleep(1000);

            }

        }

        public void MBChecks()
        {

            HealReactor(); //Before doing anything. Do we need a heal?            
            CastReactor(); //If target is casting
            MoveToMelee(); //Range Checks, and faces

            if (!IgnoreAdds)
                getAdds(); //Check for adds while in combat

            InstantReactor(); //Check instant abilities and use if needed
            RunicPowerReactor(); //Dump RP if we have it
            EvadeCheck();

        }

        public bool OBCheck() //Check if we can use Obliterate
        {
            if (SpellManager.KnownSpells.ContainsKey("Obliterate"))
                return true;

            else
                return false;

        }



        #endregion

        #region Rotation : Mord Frost

        /////////////////////////////////
        //General Frost Spec based Rotation. Requires level 58
        //http://talent.mmo-champion.com/?deathknight#B6_nlOT93KK8yYm,FQp,10482
        //        
        /////////////////////////////////


        public void MordFrost()
        {
        MFIcyTouch:
            if (!GotAdds)
            {
                MFChecks();
                DeathChill();
                IcyTouch();
            }

        MFPlagueStrike:
            if (!GotAdds)
            {
                MFChecks();
                PlagueStrike();
            }

        MFBloodStrikeOne:
            if (!GotAdds)
            {
                MFChecks();
                BloodStrike();
            }

        MFBloodStrikeTwo:
            if (!GotAdds)
            {
                MFChecks();
                BloodStrike();
            }

        MFIcyTouchTwo:
            if (!GotAdds)
            {
                MFChecks();
                DeathChill();
                IcyTouch();
            }

        MFPlagueStrikeTwo:
            if (!GotAdds)
            {
                MFChecks();
                PlagueStrike();
            }


            if (GotAdds)
            {

                if (!_me.CurrentTarget.Buffs.ContainsKey("Frost Fever"))
                {
                    if (!GotAdds)
                        goto MFIcyTouch;

                    MFChecks();
                    DeathChill();
                    IcyTouch();

                }

                if (!_me.CurrentTarget.Buffs.ContainsKey("Blood Plague"))
                {

                    if (!GotAdds)
                        goto MFPlagueStrike;

                    MFChecks();
                    PlagueStrike();

                }

                if (!GotAdds)
                    goto MFBloodStrikeOne;

                MFChecks();
                Pestilence();

                if (!GotAdds)
                    goto MFBloodStrikeTwo;

                MFChecks();
                HungeringCold();

                if (!GotAdds)
                    goto MFIcyTouchTwo;

                MFChecks();
                IcyTouch();

                if (!GotAdds)
                    goto MFPlagueStrikeTwo;

                MFChecks();
                PlagueStrike();

            }

        }

        public void MFChecks()
        {

            HealReactor(); //Before doing anything. Do we need a heal?
            MoveToMelee(); //Range Checks, and faces
            CastReactor(); //If target is casting

            if (!IgnoreAdds)
                getAdds(); //Check for adds while in combat

            InstantReactor(); //Check instant abilities and use if needed
            RunicPowerReactor(); //Dump RP if we have it

        }

        #endregion

        #region Frost Spells

        /////////////////////////////////
        //Icy Touch (Req Level 55) Frost
        /////////////////////////////////

        void IcyTouch()
        {

            if (_me.CurrentTarget.Distance <= 19) //Range Check
            {

                if (SpellManager.CanCastSpell("Icy Touch"))
                {

                    SpellManager.CastSpell("Icy Touch"); //Do It!                                                

                    if (UseSlog)
                        Slog("**Icy Touch**");

                }

                else
                {
                    if (UseUltraSlog)
                        Slog("**Icy Touch** not ready");
                }
            }

            else
            {
                if (UseUltraSlog)
                    Slog("Range error on **Icy Touch**");
            }


        }

        /////////////////////////////////////
        //Icebound Fortitude (Req Level 62) Frost
        /////////////////////////////////////

        void IceboundFortitude()
        {
            if (SpellManager.KnownSpells.ContainsKey("Icebound Fortitude")) //IF
            {

                if (SpellManager.CanCastSpell("Icebound Fortitude"))
                {

                    SpellManager.CastSpell("Icebound Fortitude"); //Do It!

                    if (UseSlog)
                        Slog("Icebound Fortitude");

                }

            }

            else
                Slog("Can not find Icebound Fortitude... Check Bars"); //PS not found

            UseIceboundFortitude = false; //Disable Spell

        }

        /////////////////////////////////////
        //Unbreakable Armor (Req 30 Frost Talent) Frost
        /////////////////////////////////////

        void UnbreakableArmor()
        {


            if (SpellManager.CanCastSpell("Unbreakable Armor"))
            {

                SpellManager.CastSpell("Unbreakable Armor"); //Do It!

                if (UseSlog)
                    Slog("Heath is low... **Unbreakable Armor**");


            }

            else
            {
                if (UseUltraSlog)
                    Slog("**Unbreakable** not ready");
            }

        }

        /////////////////////////////////////
        //Hungering Cold (Req 30 Frost Talent) Frost
        /////////////////////////////////////

        void HungeringCold()
        {


            if (SpellManager.CanCastSpell("Hungering Cold"))
            {

                SpellManager.CastSpell("Hungering Cold"); //Do It!

                if (UseSlog)
                    Slog("**Hungering Cold**");

                HCToggle = false;

            }

            else
            {
                if (UseUltraSlog)
                    Slog("**Hungering Cold** not ready");
            }

        }

        /////////////////////////////////////
        //Howling Blast (Req 50 Frost Talent) Frost
        /////////////////////////////////////

        void HowlingBlast()
        {



            if (SpellManager.CanCastSpell("Howling Blast")) //Ready?
            {
                SpellManager.CastSpell("Howling Blast"); //Do It!                         

                if (UseSlog)
                    Slog("Rime Detected! **Howling Blast**");

            }

            else
            {
                if (UseUltraSlog)
                    Slog("**Howling Blast** not ready");
            }


        }

        /////////////////////////////////////
        //Frost Strike (Req 40 Frost Talent) Frost
        /////////////////////////////////////

        void FrostStrike()
        {

            if (_me.CurrentTarget.Distance <= 5) //Range Check
            {

                if (SpellManager.CanCastSpell("Frost Strike")) //Ready?
                {
                    SpellManager.CastSpell("Frost Strike"); //Do It!                       

                    if (UseSlog)
                        Slog("**Frost Strike**");


                }

                else
                {
                    if (UseUltraSlog)
                        Slog("**Frost Strike** not ready");
                }
            }

            else
            {

                if (UseUltraSlog)
                    Slog("Range error on **Frost Strike**");
            }

        }

        /////////////////////////////////////
        //Deathchill (Req 20 Frost Talent) Frost
        /////////////////////////////////////

        void DeathChill()
        {

            if (SpellManager.CanCastSpell("Deathchill"))
            {

                SpellManager.CastSpell("Deathchill"); //Do It!

                if (UseSlog)
                    Slog("**Deathchill**");


            }

            else
            {
                if (UseUltraSlog)
                    Slog("**Deathchill** not ready");
            }

        }

        #endregion

        #region Unholy Spells

        /////////////////////////////////////
        //Plague Strike (Req Level 55) Unholy
        /////////////////////////////////////

        void PlagueStrike()
        {

            if (_me.CurrentTarget.Distance <= 5) //Range Check
            {

                if (SpellManager.CanCastSpell("Plague Strike")) //Ready?
                {
                    SpellManager.CastSpell("Plague Strike"); //Do It!                        

                    if (UseSlog)
                        Slog("**Plague Strike**");

                }

                else
                {
                    if (UseUltraSlog)
                        Slog("**Plague Strike** not ready");
                }
            }

            else
            {

                if (UseUltraSlog)
                    Slog("Range error on **Plague Strike**");
            }

        }

        /////////////////////////////////////
        //Bone Shield (Requires 35 Unholy Talent)
        /////////////////////////////////////

        public void BoneShield()
        {

            if (SpellManager.CanCastSpell("Bone Shield")) //Ready?
            {
                SpellManager.CastSpell("Bone Shield"); //Do It!                        

                if (UseSlog)
                    Slog("**Bone Shield**");

                Thread.Sleep(2750); //Try to save refresh time

            }

            else
            {
                if (UseUltraSlog)
                    Slog("**Bone Shield** not ready");
            }
        }

        /////////////////////////////////////
        //Summon Gargoyle (Req 51 Unholy Talent) Unholy
        /////////////////////////////////////

        void SummonGargoyle()
        {
            if (SpellManager.CanCastSpell("Summon Gargoyle")) //Ready?
            {

                SpellManager.CastSpell("Summon Gargoyle"); //Do It!

                if (UseSlog)
                    Slog("**Summon Gargoyle**");

                SGToggle = false; //Go back to RP Dump

            }

            else
            {
                if (UseUltraSlog)
                    Slog("**Summon Gargoyle** not ready");

            }


        }

        #endregion

        #region Blood Spells

        /////////////////////////////////////
        //Blood Strike (Req Level 55) Blood
        /////////////////////////////////////

        void BloodStrike()
        {
            if (_me.CurrentTarget.Distance <= 5) //Range Check
            {

                if (SpellManager.CanCastSpell("Blood Strike")) //Ready?
                {
                    SpellManager.CastSpell("Blood Strike"); //Do It!                       

                    if (UseSlog)
                        Slog("**Blood Strike**");


                }

                else
                {
                    if (UseUltraSlog)
                        Slog("**Blood Strike** not ready");
                }
            }

            else
            {

                if (UseUltraSlog)
                    Slog("Range error on **Blood Strike**");
            }

        }

        /////////////////////////////////////
        //Rune Tap (Req 10 Point Blood Talent)
        /////////////////////////////////////

        void RuneTap()
        {

            if (SpellManager.CanCastSpell("Rune Tap")) //Ready?
            {

                SpellManager.CastSpell("Rune Tap"); //Do It!

                if (UseSlog)
                    Slog("Health is at " + _me.HealthPercent + "%. **Rune Tap**");


            }

            else
            {

                if (UseUltraSlog)
                    Slog("**Rune Tap** not ready");

            }

        }

        /////////////////////////////////////
        //Pestilence (Req Level 56) Blood
        /////////////////////////////////////

        void Pestilence()
        {

            if (_me.CurrentTarget.Distance <= 10) //Range Check
            {

                if (SpellManager.CanCastSpell("Pestilence")) //Ready?
                {
                    SpellManager.CastSpell("Pestilence"); //Do It!                        

                    if (UseSlog)
                        Slog("**Pestilence**");


                }

                else
                {
                    if (UseUltraSlog)
                        Slog("**Pestilence** not ready");
                }
            }

            else
            {

                if (UseUltraSlog)
                    Slog("Range error on **Pestilence**");
            }

        }

        /////////////////////////////////////
        //Heart Strike (Req 40 Blood Talen) Blood
        /////////////////////////////////////

        void HeartStrike()
        {

            if (_me.CurrentTarget.Distance <= 5) //Range Check
            {

                if (SpellManager.CanCastSpell("Heart Strike")) //Ready?
                {
                    SpellManager.CastSpell("Heart Strike"); //Do It!                         

                    if (UseSlog)
                        Slog("**Heart Strike**");


                }

                else
                {
                    if (UseUltraSlog)
                        Slog("**Heart Strike** not ready");
                }
            }

            else
            {

                if (UseUltraSlog)
                    Slog("Range error on **Heart Strike**");
            }

        }

        /////////////////////////////////////
        //Blood Boil (Req Level 58) Blood
        /////////////////////////////////////

        void BloodBoil()
        {

            if (_me.CurrentTarget.Distance <= 10) //Range Check
            {

                if (SpellManager.CanCastSpell("Blood Boil")) //Ready?
                {
                    SpellManager.CastSpell("Blood Boil"); //Do It!                       

                    if (UseSlog)
                        Slog("**Blood Boil**");


                }

                else
                {
                    if (UseUltraSlog)
                        Slog("**Blood Boil** not ready");
                }
            }

            else
            {

                if (UseUltraSlog)
                    Slog("Range error on **Blood Boil**");
            }

        }

        /////////////////////////////////////
        //Strangulate (Req Level 59) Blood
        /////////////////////////////////////

        void Strangulate()
        {
            if (SpellManager.KnownSpells.ContainsKey("Strangulate")) //Found Str
            {

                if (_me.CurrentTarget.Distance <= 29) //Range Check
                {

                    if (SpellManager.CanCastSpell("Strangulate"))
                    {
                        SpellManager.CastSpell("Strangulate"); //Do It!

                        if (UseSlog)
                            Slog("Strangulate");

                    }
                }

            }

            else
            {

                Slog("Can not find Strangulate... Check Bars"); //BS not found

                UseStrangulate = false; //Disable Spell
            }
        }

        /////////////////////////////////////
        //Mark of Blood (Req 20 Blood Talent) Blood
        /////////////////////////////////////

        void MarkOfBlood()
        {

            if (_me.CurrentTarget.Distance <= 29) //Range Check
            {

                if (SpellManager.CanCastSpell("Mark of Blood")) //Ready?
                {
                    SpellManager.CastSpell("Mark of Blood"); //Do It!

                    if (UseSlog)
                        Slog("Health is low... **Mark of Blood**");


                }

                else
                {
                    if (UseUltraSlog)
                        Slog("**Mark of Blood** not ready");
                }
            }

            else
            {

                if (UseUltraSlog)
                    Slog("Range error on **Mark of Blood**");
            }

        }

        /////////////////////////////////////
        //Vampiric Blood (Req 35 Blood Talent) Blood
        /////////////////////////////////////

        void VampiricBlood()
        {

            if (SpellManager.CanCastSpell("Vampiric Blood"))
            {

                SpellManager.CastSpell("Vampiric Blood"); //Do It!

                if (UseSlog)
                    Slog("Heath is low... **Vampiric Blood**");


            }

        }

        /////////////////////////////////////
        //Hysteria (Req 30 Blood Talents) Blood
        /////////////////////////////////////

        void Hysteria()
        {
            if (SpellManager.CanCastSpell("Hysteria"))
            {
                _me.Target(); //Target Self

                SpellManager.CastSpell("Hysteria"); //Do It!

                if (UseSlog)
                    Slog("Hysteria");

                _me.TargetLastTarget(); //Target our last target


            }

        }

        #endregion

        #region Hybrid Spells

        /////////////////////////////////////
        //Obliterate (Req Level 61) Frost/Unholy
        /////////////////////////////////////

        void Obliterate()
        {

            if (_me.CurrentTarget.Distance <= 5) //Range Check
            {

                if (SpellManager.CanCastSpell("Obliterate"))
                {
                    SpellManager.CastSpell("Obliterate"); //Do It!

                    if (UseSlog)
                        Slog("**Obliterate**");


                }

                else
                {
                    if (UseUltraSlog)
                        Slog("**Obliterate** not ready");
                }
            }

            else
            {

                if (UseUltraSlog)
                    Slog("Range error on **Obliterate**");
            }

        }

        /////////////////////////////////////
        //Scourge Strike (Req 40 Unholy Talents) Unholy/Frost
        /////////////////////////////////////

        void ScourgeStrike()
        {

            if (_me.CurrentTarget.Distance <= 5) //Range Check
            {

                if (SpellManager.CanCastSpell("Scourge Strike")) //Ready?
                {
                    SpellManager.CastSpell("Scourge Strike"); //Do It!                       

                    if (UseSlog)
                        Slog("**Scourge Strike**");


                }

                else
                {
                    if (UseUltraSlog)
                        Slog("**Scourge Strike** not ready");
                }
            }

            else
            {

                if (UseUltraSlog)
                    Slog("Range error on **Scourge Strike**");
            }

        }

        /////////////////////////////////////
        //Death Strike Level 56 Unholy/Frost
        /////////////////////////////////////

        void DeathStrike()
        {

            if (_me.CurrentTarget.Distance <= 5) //Range Check
            {

                if (SpellManager.CanCastSpell("Death Strike")) //Ready?
                {
                    SpellManager.CastSpell("Death Strike"); //Do It!                       

                    if (UseSlog)
                        Slog("**Death Strike**");


                }

                else
                {
                    if (UseUltraSlog)
                        Slog("**Death Strike** not ready");
                }
            }

            else
            {

                if (UseUltraSlog)
                    Slog("Range error on **Death Strike**");
            }

        }

        #endregion

        #region Runic Power Spells

        /////////////////////////////////////
        //Death Coil (Req Level 55) Runic Power
        /////////////////////////////////////

        void DeathCoil()
        {

            if (_me.CurrentTarget.Distance <= 29) //Range Check
            {

                if (SpellManager.CanCastSpell("Death Coil")) //Ready?
                {
                    SpellManager.CastSpell("Death Coil"); //Do It!                       

                    if (UseSlog)
                        Slog("^^Death Coil^^");

                }

                else
                {

                    if (UseUltraSlog)
                        Slog("**Death Coil** not ready");

                }
            }

            else
            {

                if (UseUltraSlog)
                    Slog("Range error on **Death Coil**");

            }


        }

        /////////////////////////////////////
        //Mind Freeze (Req Level 57) Runic Power
        /////////////////////////////////////

        void MindFreeze()
        {
            if (SpellManager.KnownSpells.ContainsKey("Mind Freeze")) //Found MF
            {
                if (_me.CurrentRunicPower > 20) //Need 20 RP to cast
                {

                    if (SpellManager.CanCastSpell("Mind Freeze"))
                    {
                        if (_me.CurrentTarget.Distance <= 5) //Range Check
                        {

                            SpellManager.CastSpell("Mind Freeze"); //Do It!

                            if (UseSlog)
                                Slog("^^Mind Freeze^^");

                        }

                        else
                            Slog("Can not cast Mind Freeze...Out of Range"); //MF not found                        

                    }
                }
                else
                    Slog("Not enoph Runic Power to cast **Mind Freeze**"); //20 RP not available

            }

            else
                Slog("Can not find Mind Freeze... Check Bars"); //MF not found
        }

        /////////////////////////////////////
        //Dancing Rune Weapon (Req 51 Blood Talent)
        /////////////////////////////////////

        void DRW()
        {
            if (SpellManager.CanCastSpell("Dancing Rune Weapon")) //Ready?
            {
                if ((_me.CurrentTarget.CurrentHealth > DRWThreshold))
                {

                    SpellManager.CastSpell("Dancing Rune Weapon"); //Do It!

                    if (UseSlog)
                        Slog("^^Dancing Rune Weapon^^");


                    DRWToggle = false; //Go back to RP Dump

                    DRWSpam = false; //Reset Spam

                }
                else
                {

                    Slog("Target near death... Save DRW");

                    DRWToggle = false; //Go back to RP Dump                    

                }
            }

            else
            {
                if (UseUltraSlog)
                    Slog("**Dancing Rune Weapon** not ready");

            }


        }

        #endregion

        #region Other Spells

        /////////////////////////////////////
        //Death Grip (Req Level 55)
        /////////////////////////////////////

        void DeathGrip()
        {

            if (SpellManager.CanCastSpell("Death Grip")) //Spell Ready?
            {

                WoWMovement.MoveStop();
                SpellManager.CastSpell("Death Grip"); //Do It!
                WoWMovement.MoveStop();

                if (UseSlog)
                    Slog("Pull with ##Death Grip##");

                Thread.Sleep(500);

            }

            else
            {

                if (UseUltraSlog)
                    Slog("**Death Grip** not ready");

            }

        }

        /////////////////////////////////////
        //Horn of Winter (Level 65)
        /////////////////////////////////////

        public void HornOfWinter()
        {
            if (SpellManager.KnownSpells.ContainsKey("Horn of Winter")) //Found Horn
            {

                if (SpellManager.CanCastSpell("Horn of Winter")) //Ready?
                {

                    SpellManager.CastSpell("Horn of Winter"); //Do It!                        

                    if (UseSlog)
                        Slog("**Horn of Winter**");

                    Thread.Sleep(1500);

                }

                else
                {

                    if (UseUltraSlog)
                        Slog("**Horn of Winter** not ready");

                }

            }

            else
            {

                Slog("Can not find Horn of Winter... Check Bars"); //HoW not found

                UseHorn = false; //Disable Spell

            }

        }

        /////////////////////////////////////
        //Dark Command (Req Level 65)
        /////////////////////////////////////

        void DarkCommand()
        {

            if (SpellManager.KnownSpells.ContainsKey("Dark Command")) //Found DC
            {

                if (SpellManager.CanCastSpell("Dark Command")) //Spell Ready?
                {

                    SpellManager.CastSpell("Dark Command"); //Do It!                   

                    if (UseSlog)
                        Slog("Pull with ##Dark Command##");


                }

                else
                {

                    if (UseUltraSlog)
                        Slog("**Dark Command** not ready");

                }

            }

            else
            {
                Slog("Can not find Dark Command... Check Bars"); //DC not found 

                OpenWithDarkCommand = false; //Disable Spell

            }

        }

        /////////////////////////////////////
        //Raise Dead (Req Level 56)
        /////////////////////////////////////

        void RaiseDead()
        {
            if (SpellManager.KnownSpells.ContainsKey("Raise Dead")) //Found RD
            {

                if (SpellManager.CanCastSpell("Raise Dead")) //Ready?
                {
                    WoWMovement.MoveStop();
                    Thread.Sleep(100);
                    SpellManager.CastSpell("Raise Dead"); //Do It!
                    Thread.Sleep(500);

                    if (UseSlog)
                        Slog("**Raise Dead**");

                }

                else
                {
                    if (UseUltraSlog)
                        Slog("**Raise Dead** not ready");
                }

            }

            else
            {

                Slog("Can not find Raise Dead... Check Bars"); //RD not found

                UseRaiseDead = false; //Disable Spell

            }
        }

        #endregion

        #region EvadeCheck

        /////////////////////////////////////
        //Check for evades and blacklist those evades. Credit?
        /////////////////////////////////////

        private void EvadeCheck()
        {
            for (int i = -1; i > -5; i--)
            {
                List<string> clog = Lua.LuaGetReturnValue(string.Format("CombatLogSetCurrentEntry({0}) return CombatLogGetCurrentEntry(\"true\")", i), "_main.lua");

                if (clog == null || clog.Count < 12)
                    return;

                string sourceName = clog[3];
                string destName = clog[6];
                string missType = clog[11];

                if (missType.ToUpper() == "EVADE" && sourceName == _me.Name && destName == _me.CurrentTarget.Name)
                {
                    Slog(_me.CurrentTarget.Name + " is evading.");
                    Styx.Logic.Blacklist.Add(_me.CurrentTarget.Guid, System.TimeSpan.FromMinutes(120));
                    _me.ClearTarget();

                    break;
                }

                Logging.WriteDebug(clog[0]);

            }

        }

        #endregion

        /////////////////////////////////////
        //Chains of Ice (Req Level 58) Frost
        /////////////////////////////////////

        void ChainsOfIce()
        {
            if (SpellManager.KnownSpells.ContainsKey("Chains of Ice")) //Found CoI
            {

                if (_me.CurrentTarget.Distance <= 19) //Range Check
                {

                    if (SpellManager.CanCastSpell("Chains of Ice"))
                    {
                        SpellManager.CastSpell("Chains of Ice"); //Do It!

                        if (UseSlog)
                            Slog("Chains of Ice");


                    }
                }

            }

            else
                Logging.Write("Can not find Chains of Ice... Check Bars"); //CoI not found
        }

        /// <summary>
        /// Move while alive and in game
        /// </summary>
        /// <param name="direction">The way to go</param>
        /// <param name="duration">Time to go in milliseconds</param>
        private void SafeMove(WoWMovement.MovementDirection direction, int duration)
        {
            DateTime start = DateTime.Now;

            WoWMovement.Move(direction);

            while (ObjectManager.IsInGame && ObjectManager.Me.HealthPercent > 1)
            {
                Thread.Sleep(335);

                if (DateTime.Now.Subtract(start).Milliseconds < 300 || DateTime.Now.Subtract(start).Milliseconds >= duration)
                {
                    break;
                }

            }

            WoWMovement.MoveStop(direction);
        }
    }
}
#pragma warning restore