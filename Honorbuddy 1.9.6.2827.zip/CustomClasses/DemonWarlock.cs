﻿#pragma warning disable
namespace Warlock
{
    using Styx;
    using Styx.Logic;
    using System;
    using System.Diagnostics;
    using System.Collections.Generic;
    using Styx.Helpers;
    using System.Linq;
    using Styx.Logic.Pathing;
    using System.Threading;
    using Styx.Combat.CombatRoutine;
    using Styx.Helpers;
    using Styx.Logic.Combat;
    using Styx.WoWInternals;
    using Styx.WoWInternals.World;
    using Styx.WoWInternals.WoWObjects;

    class DemonWarlock : CombatRoutine
    {
        #region variables
        public override WoWClass Class { get { return WoWClass.Warlock; } }
        public override string Name { get { return "Hawker's Fel Warlock 2.4"; } }

        bool disenchantGreens = false;
        private string _logspam;
        private readonly LocalPlayer Me = ObjectManager.Me;

        private double drainSoulPercentage = 20;
        private static Stopwatch feedPetTimer = new Stopwatch();
        private static Stopwatch aspectTimer = new Stopwatch();
        private static Stopwatch petPresenceTimer = new Stopwatch();
        private static Stopwatch fightTimer = new Stopwatch();
        private static ulong lastGuid;
        private bool noDrink;
        private bool noFood;
        private uint deathCount = 0;
        private static Stopwatch castTimer;

        private readonly Dictionary<string, uint> petEntryIds = new Dictionary<string, uint>
        {
            {"Imp", 416},
            {"Voidwalker", 1860},
            {"Succubus", 1863},
            {"Felhunter", 417},
            {"Felguard", 17252},
        };

        private bool combatChecks
        {
            get
            {
                if (!ObjectManager.Me.GotTarget || ObjectManager.Me.Dead)
                {
                    return false;
                }

                if (ObjectManager.Me.GotTarget && !ObjectManager.Me.IsAutoAttacking)
                {
                    Lua.DoString("StartAttack()");
                }

                if (ObjectManager.Me.CurrentTarget.Distance > 50)
                {
                    if (ObjectManager.Me.CurrentTarget.IsPlayer)
                    {
                        Logging.Write("Out of range: Level " + ObjectManager.Me.CurrentTarget.Level.ToString() + " " + ObjectManager.Me.CurrentTarget.Race.ToString() + " " + System.Math.Round(ObjectManager.Me.CurrentTarget.Distance).ToString() + " yards away.");
                    }
                    else
                    {

                        Logging.Write("Out of range: Level " + ObjectManager.Me.CurrentTarget.Name + " is " + System.Math.Round(ObjectManager.Me.CurrentTarget.Distance).ToString() + " yards away.");
                    }


                    if (ObjectManager.Me.Combat)
                    {
                        Blacklist.Add(ObjectManager.Me.CurrentTarget.Guid, TimeSpan.FromSeconds(10));
                        Targeting.Instance.Clear();
                    }
                    ObjectManager.Me.ClearTarget();
                    return false;
                }

                double spellRange = SpellManagerEx.Spells["Shadow Bolt"].MaxRange;

                if (ObjectManager.Me.CurrentTarget.Distance > spellRange)
                {
                    int a = 0;
                    while (a < 50 && ObjectManager.Me.IsAlive && ObjectManager.Me.GotTarget && ObjectManager.Me.CurrentTarget.Distance > spellRange)
                    {

                        Navigator.MoveTo(WoWMovement.CalculatePointFrom(ObjectManager.Me.CurrentTarget.Location, 25f));
                        Thread.Sleep(250);
                        ++a;
                    }

                    if (Me.IsMoving)
                        WoWMovement.MoveStop();
                }

                WoWMovement.Face();

                return true;
            }
        }

        private int maxShards = 4;

        private int soulShardCount
        {
            get
            {
                int tmpSoulShardCount = 0;
                uint SoulShardEntryId = 6265;

                tmpSoulShardCount = Convert.ToInt32(Lua.LuaGetReturnValue("return GetItemCount(\"Soul Shard\")", "hawker.lua")[0]);

                if (Equals(null, tmpSoulShardCount))
                    return 9999;

                if (tmpSoulShardCount > maxShards + 1)
                {
                    slog("Soul Shard count: " + tmpSoulShardCount.ToString() + ".");
                }

                return tmpSoulShardCount;
            }
        }

        private WoWItem myHealthstone
        {
            get
            {
                return HaveItemCheck(_healthstoneEntryId);
            }
        }

        private bool enemyClose = false;

        WoWPoint pointNow;

        private double targetDistance
        {
            get
            {
                return Me.GotTarget ? Me.CurrentTarget.Distance : uint.MaxValue - 1;
            }
        }

        private static Stopwatch pullTimer = new Stopwatch();
        private static Stopwatch moveTimer = new Stopwatch();

        /// <summary>
        /// THANKS NINKO
        /// </summary>
        private readonly List<uint> _healthstoneEntryId = new List<uint>
        {
            5509, 5510, 5511, 5512, 9421, 19004, 19005, 19006,  
            19007, 19008, 19009, 19010, 19011, 19012, 19013, 
            22103, 22104, 22105, 36889, 36890, 36891, 36892,
            36893, 36894,
        };

        #endregion

        #region startup
        public void Initialize()
        {
        }
        #endregion

        #region rest and buffs
        public override bool NeedRest
        {
            get
            {
                if (SpellManagerEx.Spells.ContainsKey("Life Tap") && Me.HealthPercent > 75 && Me.ManaPercent < 55)
                {
                    slog("Need Life Tap.");
                    return true;
                }

                if (soulShardCount > maxShards)
                {
                    if (soulShardCount - maxShards > 1)
                        slog("Too many shards.");

                    return true;
                }

                if (!petPresenceTimer.IsRunning || Me.Mounted)
                {
                    petPresenceTimer.Reset();
                    petPresenceTimer.Start();
                }

                if (NeedWeaponEnchant)
                {
                    slog("Need to apply a spellstone.");
                    return true;
                }

                if (!Me.Mounted)
                {
                    if (petPresenceTimer.ElapsedMilliseconds > 1500 && SpellManagerEx.Spells.ContainsKey("Summon Imp") && !Me.GotAlivePet)
                    {
                        slog("No demon.");
                        return true;
                    }

                    if (Me.GotAlivePet && soulShardCount > 0)
                    {
                        if (SpellManagerEx.Spells.ContainsKey("Dark Pact") && Me.Pet.Entry != petEntryIds["Felhunter"])
                        {
                            slog("Need a felhunter");
                            return true;
                        }
                        else if (SpellManagerEx.Spells.ContainsKey("Summon Felguard") && Me.Pet.Entry != petEntryIds["Felguard"] && !SpellManagerEx.Spells.ContainsKey("Dark Pact"))
                            return true;
                        else if (SpellManagerEx.Spells.ContainsKey("Summon Voidwalker") && Me.Pet.Entry != petEntryIds["Voidwalker"] && !SpellManagerEx.Spells.ContainsKey("Dark Pact"))
                            return true;
                    }

                    if (SpellManagerEx.Spells.ContainsKey("Soul Link") && !Me.Buffs.ContainsKey("Soul Link"))
                    {
                        slog("Need Soul Link.");
                        return true;
                    }

                    if (SpellManagerEx.Spells.ContainsKey("Fel Armor"))
                    {
                        if (!Me.Buffs.ContainsKey("Fel Armor"))
                        {
                            slog("Need Fel Armor.");
                            return true;
                        }
                    }
                    else if (SpellManagerEx.Spells.ContainsKey("Demon Armor"))
                    {
                        if (!Me.Buffs.ContainsKey("Demon Armor"))
                        {
                            slog("Need Demon Armor.");
                            return true;
                        }
                    }
                    else if (SpellManagerEx.Spells.ContainsKey("Demon Skin"))
                    {
                        if (!Me.Buffs.ContainsKey("Demon Skin"))
                        {
                            slog("Need Demon Skin.");
                            return true;
                        }
                    }
                }

                if (soulShardCount > 0 && SpellManagerEx.Spells.ContainsKey("Create Healthstone"))
                {
                    WoWItem myHealthstone = HaveItemCheck(_healthstoneEntryId);
                    if (Equals(null, myHealthstone))
                    {
                        slog("Need a health stone.");
                        return true;
                    }
                }

                if (SpellManagerEx.Spells.ContainsKey("Health Funnel") && Me.GotAlivePet && Me.Pet.HealthPercent < 50 && !Me.Pet.Buffs.ContainsKey("Health Funnel"))
                {
                    slog("Heal {0}.", Me.Pet.Name);
                    return true;
                }

                if (Battlegrounds.IsInsideBattleground)
                {
                    return false;
                }

                if (!Me.Buffs.ContainsKey("Food") &&
                    Me.HealthPercent < 50)
                {
                    slog("Low health.");
                    return true;
                }

                if (!Me.Buffs.ContainsKey("Drink") &&
                    Me.ManaPercent < 45)
                {
                    slog("Low mana");
                    return true;
                }
                return false;
            }

        }


        private DateTime restTimer = new DateTime();
        public override void Rest()
        {
            try
            {
                restTimer = DateTime.Now;
                if (Me.ManaPercent < 80)
                {
                    if (Me.HealthPercent < 100 && Me.GotAlivePet && SpellManagerEx.Spells.ContainsKey("Dark Pact") && Me.Pet.ManaPercent > 5)
                    {
                        while (Me.IsAlive && Me.ManaPercent < 100 && Me.Pet.ManaPercent > 5)
                        {
                            DarkPact();
                            Thread.Sleep(1000);
                        }
                    }
                    else
                        if (Me.HealthPercent > 85)
                        {
                            while (Me.IsAlive && Me.ManaPercent < 100 && Me.HealthPercent > 55)
                            {
                                LifeTap();
                                Thread.Sleep(1000);
                            }
                        }
                }

                // give OM time to spawn pets after dismout
                Thread.Sleep(500);

                if (petPresenceTimer.ElapsedMilliseconds > 1500 && !Me.GotAlivePet && SpellManagerEx.Spells.ContainsKey("Summon Imp"))
                {
                    WoWMovement.MoveStop();

                    if (SpellManagerEx.Spells.ContainsKey("Dark Pact") || !SpellManagerEx.Spells.ContainsKey("Summon Voidwalker") || soulShardCount == 0)
                    {
                        if (SpellManagerEx.Spells.ContainsKey("Summon Felhunter") && soulShardCount > 0)
                        {
                            slog("Call the fel puppy now.");
                            SummonFelhunter();
                        }
                        else
                        {
                            slog("Get my irratatingly chatty imp out.");
                            SummonImp();
                        }
                    }
                    else if (SpellManagerEx.Spells.ContainsKey("Summon Felguard"))
                    {
                        slog("Call out the bad one...");
                        SummonFelguard();
                    }
                    else
                    {
                        slog("Call the beast in the blue blanket.");
                        SummonVoidwalker();
                    }
                }

                if (Me.GotAlivePet && soulShardCount > 0 && Me.Pet.Entry == petEntryIds["Imp"] )
                {
                    if (SpellManagerEx.Spells.ContainsKey("Summon Felhunter") && Me.Pet.Entry != petEntryIds["Felhunter"] && SpellManagerEx.Spells.ContainsKey("Dark Pact"))
                        SummonFelhunter();
                    else if (SpellManagerEx.Spells.ContainsKey("Summon Felguard") && Me.Pet.Entry != petEntryIds["Felguard"] && !SpellManagerEx.Spells.ContainsKey("Dark Pact"))
                        SummonFelguard();
                    else if (SpellManagerEx.Spells.ContainsKey("Summon Voidwalker") && Me.Pet.Entry != petEntryIds["Voidwalker"] && !SpellManagerEx.Spells.ContainsKey("Dark Pact"))
                        SummonVoidwalker();
                }



                if (Me.GotAlivePet && SpellManagerEx.Spells.ContainsKey("Soul Link") && !Me.Buffs.ContainsKey("Soul Link"))
                {
                    SoulLink();
                }

                if (SpellManagerEx.Spells.ContainsKey("Fel Armor"))
                {
                    if (!Me.Buffs.ContainsKey("Fel Armor"))
                    {
                        slog("Apply Fel Armor.");
                        FelArmor();
                    }
                    else
                    {
                        // slog("No need to apply Fel Armor.");
                    }
                }
                else if (SpellManagerEx.Spells.ContainsKey("Demon Armor"))
                {
                    if (!Me.Buffs.ContainsKey("Demon Armor"))
                    {
                        DemonArmor();
                    }
                    else
                    {
                        // slog("No need to apply Demon Armor.");
                    }
                }
                else if (SpellManagerEx.Spells.ContainsKey("Demon Skin"))
                {
                    if (!Me.Buffs.ContainsKey("Demon Skin"))
                    {
                        DemonSkin();
                    }
                    else
                    {
                        // slog("No need to apply Demon Skin.");
                    }
                }
                else
                {
                    slog("No Warlock armor buff needed.");
                }

                if (SpellManagerEx.Spells.ContainsKey("Health Funnel") &&
                        Me.GotAlivePet &&
                        Me.Pet.HealthPercent < 50 &&
                        !Me.Pet.Buffs.ContainsKey("Health Funnel"))
                {
                    slog("Heal the pet.");
                    HealthFunnel();
                }
                else
                {
                    // slog("No need to Health Funnel.");
                }

                if (NeedWeaponEnchant)
                {
                    slog("Applying spellstone.");
                    ApplyWeaponEnchants();
                }
                else
                {
                    // slog("No need to apply Weapon Enchant.");
                }

                if (soulShardCount > 0 && SpellManagerEx.Spells.ContainsKey("Create Healthstone"))
                {
                    WoWItem myHealthstone = HaveItemCheck(_healthstoneEntryId);

                    if (Equals(null, myHealthstone))
                    {
                        slog("Make a health stone.");
                        CreateHealthstone();
                    }
                    else
                    {
                        // slog("No need to create Healthstone.");
                    }
                }

                if (!NeedWeaponEnchant && soulShardCount > maxShards)
                {
                    DeleteShard();
                }

                if (LevelbotSettings.Instance.FoodName.Length > 3)
                {
                    int foodCount = Convert.ToInt32(Lua.LuaGetReturnValue("return GetItemCount(\"" + LevelbotSettings.Instance.FoodName + "\")", "hawker.lua")[0]);

                    if (!Equals(null, foodCount) && foodCount < 1)
                    {
                        noFood = true;
                        slog("No {0} in bags.", LevelbotSettings.Instance.FoodName);
                    }
                    else
                    {
                        noFood = false;
                    }

                    if (!noFood &&
                        Me.HealthPercent < 50)
                    {
                        Styx.Logic.Common.Rest.Feed();
                    }
                }

                if (LevelbotSettings.Instance.DrinkName.Length > 3)
                {
                    int DrinkCount = Convert.ToInt32(Lua.LuaGetReturnValue("return GetItemCount(\"" + LevelbotSettings.Instance.DrinkName + "\")", "hawker.lua")[0]);

                    if (!Equals(null, DrinkCount) && DrinkCount < 1)
                    {
                        noDrink = true;
                        noFood = true;
                        slog("No {0} in bags.", LevelbotSettings.Instance.DrinkName);
                    }
                    else
                    {
                        noDrink = false;
                    }

                    if (!noDrink && Me.ManaPercent < 40)
                    {
                        Styx.Logic.Common.Rest.Feed();
                    }
                }
                Stacker();
            }
            finally
            {
                if (DateTime.Now.Subtract(restTimer).Seconds > 10)
                {
                    // slog("Rest complete. it took {0}.", DateTime.Now.Subtract(restTimer).Hours + ":" + DateTime.Now.Subtract(restTimer).Minutes + ":" + DateTime.Now.Subtract(restTimer).Seconds);
                }
            }
        }

        public override bool NeedPreCombatBuffs { get { return false; } }
        public override void PreCombatBuff() { }
        public override bool NeedCombatBuffs { get { return false; } }
        public override void CombatBuff() { }
        public override bool NeedHeal { get { return false; } }
        public override void Heal() { }
        public override bool NeedPullBuffs { get { return false; } }
        public override void PullBuff() { }
        #endregion

        #region pull
        public override void Pull()
        {
            #region checks

            if (Me.CurrentTarget.Guid != lastGuid)
            {

                if (Me.CurrentTarget.IsPlayer)
                {
                    slog("Killing Level " + Me.CurrentTarget.Level.ToString() + " " + Me.CurrentTarget.Race.ToString() + " who is " + System.Math.Round(targetDistance).ToString() + "yards away.");
                }
                else
                {

                    slog("Killing " + Me.CurrentTarget.Name + " at distance " + System.Math.Round(targetDistance).ToString() + ".");
                }

                fightTimer.Reset();
                lastGuid = Me.CurrentTarget.Guid;
                pullTimer.Reset();
                pullTimer.Start();

            }
            else
            {
                if (pullTimer.ElapsedMilliseconds > 30 * 1000)
                {
                    if (Me.CurrentTarget.IsPlayer)
                    {
                        slog("Cannot pull level " + Me.CurrentTarget.Level.ToString() + " " + Me.CurrentTarget.Class.ToString() + " now.  Blacklist for 15 seconds.");
                        Styx.Logic.Blacklist.Add(Me.CurrentTarget.Guid, System.TimeSpan.FromSeconds(15));
                    }
                    else
                    {
                        slog("Cannot pull " + Me.CurrentTarget.Name + " now.  Blacklist for 3 minutes.");
                        Styx.Logic.Blacklist.Add(Me.CurrentTarget.Guid, System.TimeSpan.FromMinutes(3));
                    }
                }
            }

            #endregion

            if (Me.CurrentTarget.Distance > SpellManagerEx.Spells["Shadow Bolt"].MaxRange - 1)
            {
                int a = 0;
                while (a < 50 && Me.IsAlive && Me.GotTarget && Me.CurrentTarget.Distance > SpellManagerEx.Spells["Shadow Bolt"].MaxRange - 1 && !Me.Combat)
                {
                    if (ObjectManager.Me.Combat)
                    {
                        Logging.Write("Combat has started.  Abandon pull.");
                        break;
                    }

                    WoWMovement.Face();
                    Navigator.MoveTo(WoWMovement.CalculatePointFrom(Me.CurrentTarget.Location, (float)SpellManagerEx.Spells["Shadow Bolt"].MaxRange - 5));
                    Thread.Sleep(250);
                    ++a;
                }
            }

            WoWMovement.MoveStop();

            if (combatChecks && Me.GotAlivePet && !SpellManagerEx.Spells.ContainsKey("Dark Pact"))
            {
                if (!Me.Pet.IsAutoAttacking)
                {
                    Lua.DoString("PetAttack()");
                }

                if (!Me.CurrentTarget.IsPlayer)
                {
                    if (Me.CurrentTarget.Level - Me.Level == 1)
                    {
                        slog("Let " + Me.Pet.Name + " gain aggro.");
                        Thread.Sleep(1000);
                    }
                    else if (Me.CurrentTarget.Level - Me.Level > 1)
                    {
                        slog("Let " + Me.Pet.Name + " face this mob alone for a bit.");
                        Thread.Sleep(2000);
                    }
                }
            }

            WoWMovement.Face();

            if (SpellManagerEx.Spells.ContainsKey("Haunt"))
            {
                Haunt();
                UnstableAffliction();
                CurseOfAgony();
                Corruption();
            }
            else if (SpellManagerEx.Spells.ContainsKey("Unstable Affliction"))
            {
                UnstableAffliction();
                CurseOfAgony();
                Corruption();
            }
            else if (SpellManagerEx.Spells.ContainsKey("Curse of Agony"))
            {
                CurseOfAgony();
                Corruption();

                if (!Me.Combat)
                    ShadowBolt();
            }
            else if (SpellManagerEx.Spells.ContainsKey("Immolate"))
            {
                Immolate();

                if (!Me.Combat)
                    ShadowBolt();
            }
            else
            {
                slog("Pull with Shadowbolt.");
                ShadowBolt();
            }

        }
        #endregion

        #region combat
        public override void Combat()
        {
            try
            {
                //   slog(" Enter Combat() at {0}:{1}:{2}:{3}", DateTime.Now.Hour, DateTime.Now.Minute, DateTime.Now.Second, DateTime.Now.Millisecond);

                #region stop and check the target
                if (!Me.GotTarget && Me.Pet.GotTarget)
                {
                    Me.Pet.CurrentTarget.Target();
                    Thread.Sleep(250);
                    slog("Take pet's target.");
                }

                if (!ObjectManager.Me.GotTarget)
                    return;

                if (ObjectManager.Me.GotTarget && !ObjectManager.Me.CurrentTarget.IsPlayer && ObjectManager.Me.CurrentTarget.Attackable)
                {
                    if (ObjectManager.Me.CurrentTarget.CurrentTargetGuid == ObjectManager.Me.Guid || (ObjectManager.Me.GotAlivePet && ObjectManager.Me.CurrentTarget.CurrentTargetGuid == ObjectManager.Me.Pet.Guid))
                    {
                        WoWMovement.MoveStop();
                        WoWMovement.Face();
                    }
                }
                #endregion

                #region mob checks
                if (!fightTimer.IsRunning || Me.CurrentTarget.Guid != lastGuid || deathCount < Styx.Helpers.InfoPanel.Deaths)
                {
                    fightTimer.Reset();
                    fightTimer.Start();
                    deathCount = Styx.Helpers.InfoPanel.Deaths;
                    lastGuid = Me.CurrentTarget.Guid;
                }

                if (!Me.CurrentTarget.IsPlayer && fightTimer.ElapsedMilliseconds > 40 * 1000 && Me.CurrentTarget.HealthPercent > 95)
                {
                    slog(" This " + Me.CurrentTarget.Name + " is a bugged mob.  Blacklisting for 1 hour.");

                    Blacklist.Add(Me.CurrentTarget.Guid, TimeSpan.FromHours(1.00));

                    Styx.Helpers.KeyboardManager.PressKey('S');
                    Thread.Sleep(5 * 1000);
                    Styx.Helpers.KeyboardManager.ReleaseKey('S');
                    Me.ClearTarget();
                    lastGuid = 0;
                    return;
                }

                if (Battlegrounds.IsInsideBattleground)
                {
                    if (Me.GotTarget && Me.CurrentTarget.IsPet)
                    {
                        Blacklist.Add(Me.CurrentTarget, TimeSpan.FromDays(1));
                        Me.ClearTarget();
                        return;
                    }
                }

                #endregion

                #region health checks
                if (Me.HealthPercent < 50)
                {
                    if (!Equals(null, myHealthstone))
                    {
                        slog("Take a health stone.");
                        Lua.DoString("UseItemByName(\"" + myHealthstone.Name + "\")");
                    }
                    else
                    {
                        Healing.UseHealthPotion();
                    }
                }

                if (Me.ManaPercent < 50)
                {
                    Healing.UseManaPotion();
                }

                // Use Metamorphosis and the Demon spells to survive
                if (Equals(null, myHealthstone) && Me.HealthPercent < 40 && SpellManagerEx.Spells.ContainsKey("Metamorphosis") && !SpellManagerEx.Spells["Metamorphosis"].Cooldown)
                {
                    Metamorphosis();

                    double meleeRange = 5;

                    if (ObjectManager.Me.CurrentTarget.Distance > meleeRange)
                    {
                        int a = 0;
                        while (a < 50 && ObjectManager.Me.IsAlive && ObjectManager.Me.GotTarget && ObjectManager.Me.CurrentTarget.Distance > meleeRange)
                        {
                            Navigator.MoveTo(WoWMovement.CalculatePointFrom(ObjectManager.Me.CurrentTarget.Location, 2.5f));
                            Thread.Sleep(250);
                            ++a;
                        }

                        WoWMovement.MoveStop();
                        WoWMovement.Face();
                    }

                    ImmolationAura();
                    ShadowCleave();
                }
                #endregion

                #region range checks
                double shadowRange = SpellManagerEx.Spells["Shadow Bolt"].MaxRange - 1;

                if (Me.CurrentTarget.Distance > shadowRange)
                {
                    if (Me.CurrentTarget.IsPlayer)
                    {
                        slog("{0} yards from level {1} {2} {3}.", System.Math.Round(Me.CurrentTarget.Distance).ToString(), Me.CurrentTarget.Level, Me.CurrentTarget.Race, Me.CurrentTarget.Class);
                    }
                    else
                    {
                        slog("{0} yards from {1}.", System.Math.Round(Me.CurrentTarget.Distance).ToString(), Me.CurrentTarget.Name);
                    }

                    int a = 0;
                    while (a < 50 && ObjectManager.Me.IsAlive && ObjectManager.Me.GotTarget && ObjectManager.Me.CurrentTarget.Distance > shadowRange)
                    {
                        Navigator.MoveTo(WoWMovement.CalculatePointFrom(ObjectManager.Me.CurrentTarget.Location, 2.5f));
                        Thread.Sleep(250);
                        ++a;
                    }

                    WoWMovement.MoveStop();
                    WoWMovement.Face();
                }

                #endregion

                WoWUnit myMob = null;

                #region dots
                if (combatChecks)
                {
                    CurseOfAgony();
                    Corruption();

                    if (SpellManagerEx.Spells.ContainsKey("Haunt") && Me.CurrentTarget.HealthPercent > 20)
                    {
                        Haunt();
                    }

                    if (SpellManagerEx.Spells.ContainsKey("Unstable Affliction") && Me.CurrentTarget.HealthPercent > 40)
                    {
                        UnstableAffliction();
                    }
                }
                else
                {
                    return;
                }
                #endregion

                #region adds
                if (combatChecks && addsList.Count > 2 && SpellManagerEx.Spells.ContainsKey("Lifebloom") && SpellManager.CanCastSpell("Lifebloom"))
                {
                    slog("Use Lifebloom as there are {0} attackers.", addsList.Count);
                    SpellManagerEx.Cast("Lifebloom");
                }


                if (combatChecks && addsList.Count > 1 && Me.GotAlivePet && SpellManagerEx.Spells.ContainsKey("Corruption") && Me.GotTarget && Me.CurrentTarget.HealthPercent < 50)
                {
                    DemonicEmpowerment();

                    slog("D.O.T. adds");

                    foreach (WoWUnit mob in addsList)
                    {
                        if (Me.CurrentTarget.Guid != mob.Guid)
                        {
                            myMob = Me.CurrentTarget;
                            CurseOfAgony();
                            Corruption();

                            if (SpellManagerEx.Spells.ContainsKey("Corruption") && !mob.Buffs.ContainsKey("Corruption"))
                            {
                                mob.Target();
                                Thread.Sleep(500);

                                Lua.DoString("PetAttack()");

                                if (SpellManagerEx.Spells.ContainsKey("Haunt"))
                                {
                                    Haunt();
                                }

                                CurseOfAgony();
                                Corruption();

                                if (myMob.IsAlive)
                                {
                                    myMob.Target();
                                    Thread.Sleep(500);
                                    if (!SpellManagerEx.Spells.ContainsKey("Dark Pact"))
                                        Lua.DoString("PetAttack()");
                                }
                                break;
                            }
                        }
                    }
                }
                #endregion

                #region dps

                if (combatChecks)
                {
                    if (Me.CurrentTarget.IsPlayer)
                        DeathCoil();

                    if (Me.CurrentTarget.HealthPercent > 50)
                    {
                        if (SpellManagerEx.Spells.ContainsKey("Haunt") && !Me.CurrentTarget.Buffs.ContainsKey("Haunt"))
                            Haunt();

                        if (SpellManagerEx.Spells.ContainsKey("Corruption") && !Me.CurrentTarget.Buffs.ContainsKey("Corruption"))
                            Corruption();

                        if (Me.CurrentTarget.HealthPercent > 20 && SpellManagerEx.Spells.ContainsKey("Curse of Agony") && !Me.CurrentTarget.Buffs.ContainsKey("Curse of Agony"))
                            CurseOfAgony();

                        if (Me.HealthPercent > 60 && Me.CurrentTarget.HealthPercent > 20 && SpellManagerEx.Spells.ContainsKey("Unstable Affliction") && !Me.CurrentTarget.Buffs.ContainsKey("Unstable Affliction"))
                            UnstableAffliction();
                    }
                }
                else
                {
                    return;
                }


                //shadow bolt
                if (HasBuffProcced("Shadow Trance", 0))
                {
                    slog("Shadow Trance.");
                    ShadowBolt();
                }
                // for adds only drain life
                else if (addsList.Count > 1 && SpellManagerEx.Spells.ContainsKey("Drain Life"))
                {
                    DrainLife();
                    Thread.Sleep(1000);
                    int a = 0;
                    while (a < 25 && Me.ChanneledCasting > 0)
                    {
                        Thread.Sleep(250);
                        if (HasBuffProcced("Shadow Trance", 0))
                        {
                            slog("Shadow Trance.");
                            ShadowBolt();
                            break;
                        }
                        ++a;
                    }
                }
                // shadow bolt for dps
                else if (Me.HealthPercent > 55 && Me.CurrentTarget.Distance > 10 && Me.CurrentTarget.HealthPercent > 70)
                {
                    ShadowBolt();
                }
                // drain life is it has 25% health or more.
                else if (Me.CurrentTarget.HealthPercent > drainSoulPercentage && SpellManagerEx.Spells.ContainsKey("Drain Life"))
                {
                    DrainLife();
                    Thread.Sleep(500);
                    int a = 0;
                    while (a < 25 && Me.ChanneledCasting > 0 && Me.CurrentTarget.HealthPercent > drainSoulPercentage)
                    {
                        Thread.Sleep(250);
                        if (HasBuffProcced("Shadow Trance", 0))
                        {
                            slog("Shadow Trance.");
                            ShadowBolt();
                            break;
                        }
                        ++a;
                    }


                    if (Me.CurrentTarget.HealthPercent <= drainSoulPercentage && Me.HealthPercent > 25)
                    {
                        if (Me.HealthPercent > 90 && Me.ManaPercent < 75)
                        {
                            LifeTap();
                        }
                        DrainSoul();
                    }
                }
                // get soul shards
                else if (Me.HealthPercent > 30 && Me.CurrentTarget.HealthPercent <= drainSoulPercentage && SpellManagerEx.Spells.ContainsKey("Drain Soul"))
                {
                    DrainSoul();
                }
                // if all else fails
                else
                {
                    ShadowBolt();
                }

                #endregion

                #region oom

                if (Me.ManaPercent < 60)
                {
                    if (Me.HealthPercent < 90 && Me.GotAlivePet && SpellManagerEx.Spells.ContainsKey("Dark Pact") && Me.Pet.ManaPercent > 25)
                    {
                        DarkPact();
                    }
                    else if (Me.HealthPercent > 60)
                    {
                        LifeTap();
                    }
                }

                #endregion

                #region pet management
                if (Me.GotTarget && !Me.CurrentTarget.IsPlayer && !Me.CurrentTarget.IsPet && Me.GotAlivePet && Me.Pet.Entry != 416 &&
                    Me.CurrentTarget.Distance > 15 && Me.CurrentTarget.Distance < Targeting.PullDistance)
                {
                    slog("Bring " + Me.CurrentTarget.Name + " closer.");

                    int a = 6;

                    Lua.DoString("PetFollow()");

                    while (a < 10 && Me.GotTarget && Me.CurrentTarget.IsAlive && Me.CurrentTarget.Distance > 15)
                    {
                        Thread.Sleep(1000);
                        a++;
                    }
                }

                if (SpellManagerEx.Spells.ContainsKey("Corruption") && SpellManagerEx.Spells.ContainsKey("Curse of Agony") &&
                    Me.CurrentTarget.Buffs.ContainsKey("Corruption") && Me.CurrentTarget.Buffs.ContainsKey("Curse of Agony") &&
                    Me.HealthPercent > 35 && Me.GotAlivePet && Me.Pet.HealthPercent < 50 && !Me.Pet.Buffs.ContainsKey("Health Funnel"))
                {
                    HealthFunnel();
                }

                #endregion

            }
            finally
            {
                //slog(" Left Combat() at {0}:{1}:{2}:{3}", DateTime.Now.Hour, DateTime.Now.Minute, DateTime.Now.Second, DateTime.Now.Millisecond);

            }
        }


        #endregion

        #region warlock spells
        /// <summary>
        /// Protects the caster, increasing armor by 90, and increasing the amount of 
        /// health generated through spells and effects by 20%. 
        /// Only one type of Armor spell can be active on the Warlock at any time.  Lasts 30 min.
        /// </summary>        
        private bool DemonSkin()
        {
            if (SpellManagerEx.Cast("Demon Skin"))
            {
                slog("Demon Skin.");
                return true;
            }
            else
            {
                // slog("Can't use Demon Skin now.");
                return false;
            }
        }

        /// <summary>
        /// Burns the enemy for 8 Fire damage and then an additional Fire damage over 15 sec.
        /// </summary>        
        private bool Immolate()
        {
            if (castTimer == null)
                castTimer = new Stopwatch();

            if (castTimer.IsRunning && castTimer.ElapsedMilliseconds < 300)
                return false;

            if (Me.CurrentTarget.Buffs.ContainsKey("Immolate") || !SpellManager.CanCastSpell("Immolate"))
            {
                return false;
            }
            else
            {
                castTimer.Reset();
                castTimer.Start();
                if (SpellManagerEx.Cast("Immolate"))
                {
                    slog("Immolate.");
                    return true;
                }
            }

            return false;
        }

        /// <summary>
        /// Sends a shadowy bolt at the enemy, causing Shadow damage.
        /// </summary>        
        private bool ShadowBolt()
        {
            if (Me.CurrentTarget.Distance > SpellManagerEx.Spells["Shadow Bolt"].MaxRange)
            {
                return false;
            }

            if (SpellManagerEx.Cast("Shadow Bolt"))
            {
                slog("Shadow Bolt.");
                return true;
            }
            else
            {
                // slog("Can't use Shadow Bolt now.");
                return false;
            }
        }

        /// <summary>
        /// Summons an Imp under the command of the Warlock.
        /// </summary>

        private bool SummonImp()
        {
            Thread.Sleep(500);
            if (Me.GotAlivePet && Me.Pet.Entry == 416)
                return true;

            if (SpellManagerEx.Cast("Summon Imp"))
            {
                return true;
            }
            else
            {
                // slog("Can't use Summon Imp now."); 
                return false;
            }
        }

        /// <summary>
        /// Summons an Felhunter under the command of the Warlock.
        /// </summary>

        private bool SummonFelhunter()
        {
            if (SpellManagerEx.Cast("Summon Felhunter"))
            {
                Thread.Sleep(1000);
                slog("Summoning Felhunter.");
                while (Me.IsCasting)
                {
                    Thread.Sleep(100);
                    if (Me.GotAlivePet && Me.Pet.Entry == 417)
                    {
                        break;
                    }
                }
                return true;
            }
            else
            {
                // slog("Can't use Summon Felhunter now."); 
                return false;
            }
        }

        /// <summary>
        /// Corrupts the target, causing 40 Shadow damage over 12 sec.
        /// </summary>     
        private static Stopwatch _corruptionCastTimer;
        private bool Corruption()
        {
            if (_corruptionCastTimer == null)
                _corruptionCastTimer = new Stopwatch();

            if (_corruptionCastTimer.IsRunning && _corruptionCastTimer.ElapsedMilliseconds < 300)
                return false;

            if (Me.CurrentTarget.Buffs.ContainsKey("Corruption") || !SpellManager.CanCastSpell("Corruption"))
            {
                return false;
            }
            else
            {
                if (SpellManagerEx.Cast("Corruption"))
                {
                    slog("Corruption.");
                    _corruptionCastTimer.Reset();
                    _corruptionCastTimer.Start();
                    return true;
                }
            }

            return false;
        }

        /// <summary>
        /// Converts health into [0 + SPI * 1] mana.  Spirit increases quantity of health converted.
        /// </summary>  
        private static Stopwatch _lifeTapCastTimer;
        private bool LifeTap()
        {
            if (_lifeTapCastTimer == null)
                _lifeTapCastTimer = new Stopwatch();

            if (_lifeTapCastTimer.IsRunning && _lifeTapCastTimer.ElapsedMilliseconds < 300 || !SpellManager.CanCastSpell("Life Tap"))
                return false;

            if (SpellManagerEx.Cast("Life Tap"))
            {
                _lifeTapCastTimer.Reset();
                _lifeTapCastTimer.Start();
                slog("Life Tap.");
                return true;
            }
            else
            {
                // slog("Can't use Life Tap now.");
                return false;
            }
        }

        /// <summary>
        /// Curses the target for 5 min, reducing Arcane, Fire, Frost, Nature, 
        /// and Shadow resistances by 45 and increasing magic damage taken by 6%.  Only one Curse per Warlock can be active on any one target.
        /// </summary>
        private static Stopwatch _curseOfTheElementsCastTimer;
        private bool CurseOfTheElements()
        {
            if (_curseOfTheElementsCastTimer == null)
                _curseOfTheElementsCastTimer = new Stopwatch();

            if (_curseOfTheElementsCastTimer.IsRunning && _curseOfTheElementsCastTimer.ElapsedMilliseconds < 300)
                return false;

            if (Me.CurrentTarget.Buffs.ContainsKey("Curse of the Elements") || !SpellManager.CanCastSpell("Curse of the Elements"))
            {
                return false;
            }
            else
            {
                if (SpellManagerEx.Cast("Curse of the Elements"))
                {
                    _curseOfTheElementsCastTimer.Reset();
                    _curseOfTheElementsCastTimer.Start();
                    slog("Curse of the Elements.");
                    return true;
                }
            }

            return false;
        }

        /// <summary>
        /// Curses the target with agony, causing Shadow damage over 24 sec.  This damage is dealt 
        /// slowly at first, and builds up as the Curse reaches its full duration. 
        /// </summary>        
        private static Stopwatch _curseOfAgonyCastTimer;
        private bool CurseOfAgony()
        {
            if (_curseOfAgonyCastTimer == null)
                _curseOfAgonyCastTimer = new Stopwatch();

            if (_curseOfAgonyCastTimer.IsRunning && _curseOfAgonyCastTimer.ElapsedMilliseconds < 300)
                return false;

            if (Me.CurrentTarget.Buffs.ContainsKey("Curse of Agony") || !SpellManager.CanCastSpell("Curse of Agony"))
            {
                return false;
            }
            else
            {
                if (SpellManagerEx.Cast("Curse of Agony"))
                {
                    slog("Curse of Agony.");
                    _curseOfAgonyCastTimer.Reset();
                    _curseOfAgonyCastTimer.Start();
                    return true;
                }
            }

            return false;
        }

        /// <summary>
        /// Creates a Healthstone that can be used to instantly restore health.
        /// </summary>        
        private bool CreateHealthstone()
        {
            if (SpellManagerEx.Cast("Create Healthstone"))
            {
                slog("Create Healthstone.");
                return true;
            }
            else
            {
                // slog("Can't use Create Healthstone now.");
                return false;
            }
        }

        /// <summary>
        /// Drains the soul of the target, causing 55 Shadow damage over 15 sec.  If the target is at or 
        /// below 25% health, Drain Soul causes four times the normal damage
        /// If the target dies while being drained, and yields experience or honor, 
        /// the caster gains a Soul Shard.  Each time the Drain Soul damages the target, 
        /// it also has a chance to generate a Soul Shard. 
        /// </summary>        
        private bool DrainSoul()
        {
            if (Me.CurrentTarget.Distance > SpellManagerEx.Spells["Shadow Bolt"].MaxRange)
            {
                return false;
            }

            if (SpellManagerEx.Cast("Drain Soul"))
            {
                slog("Drain Soul.");
                Thread.Sleep(1000);
                int a = 0;
                while (a < 25 && Me.ChanneledCasting > 0 && Me.GotTarget && Me.CurrentTarget.IsAlive)
                {
                    Thread.Sleep(250);
                    ++a;
                }
                return true;
            }
            else
            {
                // slog("Can't use Drain Soul now.");
                return false;
            }
        }

        /// <summary>
        /// Summons a Voidwalker under the command of the Warlock.
        /// </summary>        
        private bool SummonVoidwalker()
        {
            if (SpellManagerEx.Cast("Summon Voidwalker"))
            {
                slog("Summon Voidwalker.");
                Thread.Sleep(1000);
                while (Me.IsCasting)
                {
                    Thread.Sleep(100);
                    if (Me.GotAlivePet && Me.Pet.Entry == 1860)
                    {
                        break;
                    }
                }
                return true;
            }
            else
            {
                // slog("Can't use Summon Voidwalker now.");
                return false;
            }
        }

        /// <summary>
        /// Summons a Felguard under the command of the Warlock.
        /// </summary>        
        private bool SummonFelguard()
        {
            SpellManagerEx.Cast("Fel Domination");

            Thread.Sleep(1000);

            if (SpellManagerEx.Cast("Summon Felguard"))
            {
                Thread.Sleep(1000);
                while (Me.IsCasting)
                {
                    Thread.Sleep(100);
                    if (Me.GotAlivePet && Me.Pet.Entry == 17252)
                    {
                        break;
                    }
                }
                return true;
            }
            else
            {
                // slog("Can't use Summon Felguard now.");
                return false;
            }
        }

        /// <summary>
        /// Gives health to the caster's pet every second for 10 sec as long as the caster channels.
        /// </summary>        
        private bool HealthFunnel()
        {
            double myHealth = 60;

            if (Me.Combat)
            {
                myHealth = 35;
            }
            if (Me.HealthPercent > myHealth && SpellManagerEx.Cast("Health Funnel"))
            {
                slog("Health Funnel.");
                Thread.Sleep(1000);
                while (Me.Pet.HealthPercent < 95 && Me.IsCasting && Me.HealthPercent > myHealth)
                {
                    Thread.Sleep(100);
                }

                return true;
            }
            else
            {
                // slog("Don't use Health Funnel now.");
                return false;
            }
        }

        /// <summary>
        /// Transfers health every 1 sec from the target to the caster.  Lasts 5 sec.
        /// </summary>        
        private bool DrainLife()
        {
            if (Me.CurrentTarget.Distance > SpellManagerEx.Spells["Shadow Bolt"].MaxRange)
            {
                return false;
            }

            if (Me.CurrentTarget.CreatureType == WoWCreatureType.Mechanical || Me.CurrentTarget.CreatureType == WoWCreatureType.Elemental)
            {
                ShadowBolt();
                return true;
            }

            if (SpellManagerEx.Cast("Drain Life"))
            {
                slog("Drain Life.");
                return true;
            }
            else
            {
                // slog("Can't use Drain Life now.");
                return false;
            }
        }

        /// <summary>
        /// The Soulstone can be used to store one target's soul.  If the target dies while his soul is stored, 
        /// he will be able to resurrect.
        /// </summary>        
        private bool CreateSoulstone()
        {
            if (SpellManagerEx.Cast("Create Soulstone"))
            {
                slog("Create Soulstone.");
                return true;
            }
            else
            {
                // slog("Can't use Create Soulstone now.");
                return false;
            }
        }

        /// <summary>
        /// Protects the caster, increasing armor, and increasing the amount of health 
        /// generated through spells and effects by 20%
        /// </summary>        
        private bool DemonArmor()
        {
            if (SpellManagerEx.Cast("Demon Armor"))
            {
                slog("Demon Armor.");
                return true;
            }
            else
            {
                // slog("Can't use Demon Armor now.");
                return false;
            }
        }

        /// <summary>
        /// While applied to target weapon it increases damage dealt by direct spells by 1% 
        /// and spell critical strike rating. 
        /// </summary>        
        private bool CreateFirestone()
        {
            if (SpellManagerEx.Cast("Create Firestone"))
            {
                slog("Create Firestone.");
                return true;
            }
            else
            {
                // slog("Can't use Create Firestone now.");
                return false;
            }
        }

        /// <summary>
        /// While applied to target weapon it increases damage dealt by periodic spells by 1% and spell haste rating.
        /// </summary>        
        private bool CreateSpellstone()
        {
            if (SpellManagerEx.Cast("Create Spellstone"))
            {
                slog("Create Spellstone.");
                return true;
            }
            else
            {
                // slog("Can't use Create Spellstone now.");
                return false;
            }
        }

        /// <summary>
        /// Causes the enemy target to run in horror for 3 sec and causes Shadow damage.  
        /// The caster gains 300% of the damage caused in health.
        /// </summary>        
        private bool DeathCoil()
        {
            if (Me.CurrentTarget.Distance > SpellManagerEx.Spells["Shadow Bolt"].MaxRange)
            {
                return false;
            }

            if (combatChecks && !Me.CurrentTarget.Buffs.ContainsKey("Death Coil") && SpellManagerEx.Cast("Death Coil"))
            {
                slog("Death Coil.");
                return true;
            }
            else
            {
                // slog("Can't use Death Coil now.");
                return false;
            }
        }

        /// <summary>
        /// Voidwalker - Increases the Voidwalker's health by 20%, and its threat 
        /// generated from spells and attacks by 20% for 20 sec.
        /// 
        /// Increases the Felguard's attack speed by 20% and breaks all stun, 
        /// snare and movement impairing effects and makes your Felguard immune to them for 15 sec.
        /// </summary>
        /// <returns></returns>
        private bool DemonicEmpowerment()
        {

            if (SpellManagerEx.Cast("Demonic Empowerment"))
            {
                slog("Demonic Empowerment.");
                return true;
            }
            else
            {
                // slog("Can't use Demonic Empowerment now.");
                return false;
            }
        }

        /// <summary>
        /// Drains your summoned demon's Mana, returning 100% to you.
        /// </summary>        
        private bool DarkPact()
        {
            if (castTimer == null)
                castTimer = new Stopwatch();

            if (castTimer.IsRunning && castTimer.ElapsedMilliseconds < 300 || !SpellManager.CanCastSpell("Dark Pact"))
                return false;

            castTimer.Reset();
            castTimer.Start();

            if (SpellManagerEx.Cast("Dark Pact"))
            {
                slog("Dark Pact.");
                return true;
            }
            else
            {
                // slog("Can't use Dark Pact now.");
                return false;
            }
        }

        /// <summary>
        /// Shadow energy slowly destroys the target, causing damage over 15 sec.  
        /// In addition, if the Unstable Affliction is dispelled it will cause serious damage to the dispeller 
        /// and silence them for 5 sec.
        /// </summary>   
        private static Stopwatch _unstableAfflictionCastTimer;
        private bool UnstableAffliction()
        {
            if (_unstableAfflictionCastTimer == null)
                _unstableAfflictionCastTimer = new Stopwatch();

            if (_unstableAfflictionCastTimer.IsRunning && _unstableAfflictionCastTimer.ElapsedMilliseconds < 300)
                return false;

            if (Me.CurrentTarget.Buffs.ContainsKey("Unstable Affliction") || !SpellManager.CanCastSpell("Unstable Affliction"))
            {
                return false;
            }
            else
            {
                if (SpellManagerEx.Cast("Unstable Affliction"))
                {
                    slog("Unstable Affliction.");
                    _unstableAfflictionCastTimer.Reset();
                    _unstableAfflictionCastTimer.Start();
                    return true;
                }
            }

            return false;
        }

        /// <summary>
        /// Surrounds the caster with fel energy, increasing spell power plus additional spell 
        /// power equal to 30% of your Spirit. 
        /// In addition, you regain 2% of your maximum health every 5 sec.
        /// </summary>        
        private bool FelArmor()
        {
            if (SpellManagerEx.Cast("Fel Armor"))
            {
                slog("Fel Armor.");
                return true;
            }
            else
            {
                // slog("Can't use Fel Armor now.");
                return false;
            }
        }

        /// <summary>
        /// When active, 20% of all damage taken by the caster is taken by your Imp, Voidwalker, 
        /// Succubus, Felhunter, Felguard, or enslaved demon instead.  
        /// That damage cannot be prevented. Lasts as long as the demon is active and controlled.
        /// </summary>        
        private bool SoulLink()
        {
            if (SpellManagerEx.Cast("Soul Link"))
            {
                slog("Soul Link.");
                return true;
            }
            else
            {
                // slog("Can't use Soul Link now.");
                return false;
            }
        }

        /// <summary>
        /// You send a ghostly soul into the target, dealing Shadow damage and increasing all damage done 
        /// by your Shadow damage-over-time effects on the target by 20% for 12 sec. 
        /// When the Haunt spell ends or is dispelled, the soul returns to you, healing you for 100% of the 
        /// damage it did to the target.
        /// </summary>      
        private static Stopwatch _hauntCastTimer;
        private bool Haunt()
        {
            if (_hauntCastTimer == null)
                _hauntCastTimer = new Stopwatch();

            if (_hauntCastTimer.IsRunning && _hauntCastTimer.ElapsedMilliseconds < 300)
                return false;

            if (Me.CurrentTarget.Buffs.ContainsKey("Haunt") || !SpellManager.CanCastSpell("Haunt"))
            {
                return false;
            }
            else
            {
                _hauntCastTimer.Reset();
                _hauntCastTimer.Start();
                if (SpellManagerEx.Cast("Haunt"))
                {
                    slog("Haunt.");
                    return true;
                }
            }

            return false;
        }

        /// <summary>
        /// You transform into a Demon for 30 sec.  This form increases your armor by 600%, damage by 20%, 
        /// reduces the chance you'll be critically hit by melee attacks by 6% and reduces the duration of 
        /// stun and snare effects by 50%.
        ///  You gain some unique demon abilities in addition to your normal abilities.
        /// </summary>        
        private bool Metamorphosis()
        {
            if (combatChecks && SpellManagerEx.Cast("Metamorphosis"))
            {
                slog("Metamorphosis.");
                return true;
            }
            else
            {
                // slog("Can't use Metamorphosis now.");
                return false;
            }
        }

        /// <summary>
        /// Inflicts 110 Shadow damage to an enemy target and nearby allies, affecting up to 3 targets.
        /// </summary>        
        private bool ShadowCleave()
        {
            if (Me.CurrentTarget.Distance > 5)
            {
                return false;
            }

            if (combatChecks && SpellManagerEx.Cast("Shadow Cleave"))
            {
                slog("Shadow Cleave.");
                return true;
            }
            else
            {
                // slog("Can't use Shadow Cleave now.");
                return false;
            }
        }

        /// <summary>
        /// Ignites the area surrounds you, causing 251 Fire damage to all nearby enemies every 1 sec.  
        /// Lasts 15 sec.
        /// </summary>
        private bool ImmolationAura()
        {
            if (Me.CurrentTarget.Distance > 5)
            {
                return false;
            }

            if (combatChecks && SpellManagerEx.Cast("Immolation Aura"))
            {
                slog("Immolation Aura.");
                return true;
            }
            else
            {
                // slog("Can't use Immolation Aura now.");
                return false;
            }
        }


        /// <summary>
        /// Targets in a cone in front of the 
        /// caster take Shadow damage and an additional Fire damage over 8 sec.
        /// </summary>        
        private bool Shadowflame()
        {
            if (Me.CurrentTarget.Distance > SpellManagerEx.Spells["Shadow Bolt"].MaxRange)
            {
                return false;
            }

            if (combatChecks && !Me.CurrentTarget.Buffs.ContainsKey("ShadowFlame") && SpellManagerEx.Cast("Shadowflame"))
            {
                slog("Shadowflame.");
                return true;
            }
            else
            {
                // slog("Can't use Shadowflame now.");
                return false;
            }
        }

        #endregion

        #region spellstones

        private readonly List<uint> _firestoneEnchantEntryId = new List<uint>
        {
            3597, 3609, 3610, 3611, 3612, 3613, 3614,
        };

        private readonly List<uint> _firestoneEntryId = new List<uint>
        {
            40773, 41169, 41170, 41171, 41172, 41173, 41174,
        };

        private readonly List<uint> _spellstoneEnchantEntryId = new List<uint>
        {
            3615, 3616, 3617, 3618, 3619, 3620,
        };

        private readonly List<uint> _spellstoneEntryId = new List<uint>
        {
            41191, 41192, 41193, 41194, 41195, 41196,
        };

        private void ApplyWeaponEnchants()
        {
            if (!SpellManagerEx.Spells.ContainsKey("Create Firestone") ||
               _spellstoneEnchantEntryId.Contains(Me.Mainhand.TemporaryEnchantment.Id) ||
               _firestoneEnchantEntryId.Contains(Me.Mainhand.TemporaryEnchantment.Id))
            {
                return;
            }

            if (SpellManagerEx.Spells.ContainsKey("Create Spellstone"))
            {
                WoWItem mySpellstone = HaveItemCheck(_spellstoneEntryId);

                if (Equals(null, mySpellstone))
                {
                    if (soulShardCount == 0)
                    {
                        slog("Get soul shards.");
                        return;
                    }
                    else
                    {
                        slog("Make a spellstone.");
                        CreateSpellstone();
                        return;
                    }
                }
                else
                    slog("Apply Spellstone.");

                Lua.DoString("UseItemByName(\"" + mySpellstone.Entry + "\")");
                Thread.Sleep(100);
                Lua.DoString("UseInventoryItem(16)");
                Thread.Sleep(250);

                while (Me.IsCasting &&
                    !Me.Combat)
                {
                    Thread.Sleep(250);
                }


            }
            else if (SpellManagerEx.Spells.ContainsKey("Create Firestone"))
            {
                WoWItem mySpellstone = HaveItemCheck(_firestoneEntryId);

                if (Equals(null, mySpellstone))
                {
                    if (soulShardCount == 0)
                    {
                        slog("Make soul shards.");
                        return;
                    }
                    else
                    {
                        slog("Make a Firestone.");
                        CreateFirestone();
                        return;
                    }
                }
                else
                    slog("Apply Firestone.");

                Lua.DoString("UseItemByName(\"" + mySpellstone.Entry + "\")");
                Thread.Sleep(100);
                Lua.DoString("UseInventoryItem(16)");
                Thread.Sleep(3100);
            }
        }

        private bool NeedWeaponEnchant
        {
            get
            {
                if (Me.Mounted)
                    return false;

                if (soulShardCount == 0)
                {
                    return false;
                }

                if (SpellManagerEx.Spells.ContainsKey("Create Firestone") && !Equals(null, Me.Mainhand) && Me.Mainhand.IsSoulbound &&                                      // for people who use Skinning Knifes as warlocks ?
                    !_spellstoneEnchantEntryId.Contains(Me.Mainhand.TemporaryEnchantment.Id) && !_firestoneEnchantEntryId.Contains(Me.Mainhand.TemporaryEnchantment.Id))
                {
                    return true;
                }

                return false;
            }
        }
        #endregion

        #region utilities


        /// <summary>
        /// Has this buff procced?
        /// </summary>
        /// <param name="cSearchBuffName"></param>
        /// <returns>True if the buff is present</returns>
        private bool HasBuffProcced(string cSearchBuffName, int minStackCount)
        {
            int stackCount = 0;

            List<string> myBuffs = Lua.LuaGetReturnValue("return UnitBuff(\"player\",\"" + cSearchBuffName + "\")", "hawker.lua");

            if (Equals(null, myBuffs))
                return false;

            string buffName = myBuffs[0];

            if (minStackCount > 0)
            {
                stackCount = Convert.ToInt32(myBuffs[3]);
            }

            if (buffName == cSearchBuffName || stackCount >= minStackCount)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        private WoWItem HaveItemCheck(List<uint> listId)
        {
            foreach (WoWItem item in ObjectManager.GetObjectsOfType<WoWItem>(false))
            {
                if (listId.Contains(item.Entry))
                {
                    return item;
                }
            }
            return null;
        }

        private static Stopwatch shardTimer = new Stopwatch();
        private void DeleteShard()
        {
            int _startShards = soulShardCount;
            int _endShard = 0;

            if (shardTimer.IsRunning &&
                shardTimer.ElapsedMilliseconds < 1000)
            {
                return;
            }
            if (soulShardCount > maxShards)
            {
                shardTimer.Reset();
                shardTimer.Start();

                string shardDelete = "i=\"Soul Shard\"d=1 for x=0,4 do for y=1,GetContainerNumSlots(x) do  if (d>0) then l=GetContainerItemLink(x,y)  if l and GetItemInfo(l)==i then PickupContainerItem(x,y) DeleteCursorItem() d=d-1 end end end end";

                Lua.DoString(shardDelete);
            }

            _endShard = soulShardCount;

            if (_endShard - _startShards > 1)
            {
                slog("Deleted {0} shards.", _endShard - _startShards);
            }
            else if (_endShard - _startShards == 0)
            {
                slog("Deleted a shard.");
            }
            else
            {
                slog("Shard delete has failed!");
            }
        }

        private List<WoWUnit> addsList
        {
            get
            {
                List<WoWUnit> mobList = ObjectManager.GetObjectsOfType<WoWUnit>(false);
                List<WoWUnit> enemyMobList = new List<WoWUnit>();

                foreach (WoWUnit thing in mobList)
                {
                    try
                    {
                        if ((thing.Guid != Me.Guid) &&
                        thing.IsTargetingMe)
                        {
                            enemyMobList.Add(thing);
                        }
                    }
                    catch (Exception ex)
                    {
                        Logging.WriteException(ex);
                        slog("Add error.");
                    }
                }

                if (enemyMobList.Count > 1)
                {
                    slog("Warning: there are " + enemyMobList.Count.ToString() + " attackers.");
                }
                return enemyMobList;
            }
        }

        private void slog(string msg, params object[] args)
        {
            if (msg != _logspam)
            {
                Logging.Write(msg, args);
                _logspam = msg;
            }
        }


        private void slog(string msg)
        {
            if (msg != _logspam)
            {
                Logging.Write(msg);
                _logspam = msg;
            }
        }

        public void HandleFalling() { }

        #endregion

        #region movement logic
        WoWPoint attackPoint
        {
            get
            {
                if (Me.GotTarget)
                {
                    if (!movementTimer.IsRunning ||
                        movementTimer.ElapsedMilliseconds > 2500)
                    {
                        movementTimer.Reset();
                        movementTimer.Start();
                        attackPointBuffer = WoWMovement.CalculatePointFrom(Me.CurrentTarget.Location, 25.0f);
                        return attackPointBuffer;
                    }
                    else
                    {
                        return attackPointBuffer;
                    }
                }
                else
                {
                    WoWPoint noSpot = new WoWPoint();
                    return noSpot;
                }
            }
        }

        WoWPoint attackPointBuffer;

        private static Stopwatch movementTimer = new Stopwatch();


        #endregion

        #region horde racials

        // Berserking
        void Berserking()
        {
            if (ObjectManager.Me.Race == WoWRace.Troll &&
                SpellManagerEx.Cast("Berserking"))
            {
                Styx.Helpers.Logging.Write("Berserking.");
            }
        }

        // Bloodrage
        void Bloodrage()
        {
            if (ObjectManager.Me.Race == WoWRace.Orc &&
                SpellManagerEx.Cast("Bloodrage"))
            {
                Styx.Helpers.Logging.Write("Bloodrage.");
            }
        }

        // War Stomp
        void WarStomp()
        {
            if (ObjectManager.Me.Race == WoWRace.Tauren &&
                SpellManagerEx.Cast("War Stomp"))
            {
                Styx.Helpers.Logging.Write("War Stomp.");
            }
        }

        // Arcane Torrent
        void ArcaneTorrent()
        {
            if (ObjectManager.Me.Race == WoWRace.BloodElf &&
                SpellManagerEx.Cast("Arcane Torrent"))
            {
                Styx.Helpers.Logging.Write("Arcane Torrent.");
            }
        }

        // Will of the Forsaken 
        void WillOfTheForsaken()
        {
            if (ObjectManager.Me.Race == WoWRace.Undead &&
                SpellManagerEx.Cast("Will of the Forsaken"))
            {
                Styx.Helpers.Logging.Write("Will of the Forsaken.");
            }
        }
        #endregion

        #region alliance racials

        // Stoneform
        void Stoneform()
        {
            if (ObjectManager.Me.Race == WoWRace.Dwarf &&
                SpellManagerEx.Cast("Stoneform"))
            {
                Styx.Helpers.Logging.Write("Stoneform.");
            }
        }

        // Gift of the Naaru
        void GiftOfTheNaaru()
        {
            if (ObjectManager.Me.Race == WoWRace.Draenei &&
                SpellManagerEx.Cast("Gift of the Naaru"))
            {
                Styx.Helpers.Logging.Write("Gift of the Naaru.");
            }
        }

        // Every Man for Himself
        void EveryManForHimself()
        {
            if (ObjectManager.Me.Race == WoWRace.Human &&
                SpellManagerEx.Cast("Every Man for Himself"))
            {
                Styx.Helpers.Logging.Write("Every Man for Himself.");
            }
        }

        // Shadowmeld
        void Shadowmeld()
        {
            if (ObjectManager.Me.Race == WoWRace.NightElf &&
                SpellManagerEx.Cast("Shadowmeld"))
            {
                Styx.Helpers.Logging.Write("Shadowmeld.");
            }
        }

        // Escape Artist
        void EscapeArtist()
        {
            if (ObjectManager.Me.Race == WoWRace.Gnome &&
                SpellManagerEx.Cast("Escape Artist"))
            {
                Styx.Helpers.Logging.Write("Escape Artist.");
            }
        }


        #endregion


        private bool Stacker()
        {
            // 33567

            try
            {
                List<WoWItem> allItems = ObjectManager.GetObjectsOfType<WoWItem>(false);

                int count = 0;

                foreach (WoWItem one in allItems)
                {
                    if (one.Entry == 33567)
                    {
                        ++count;
                        if (count > 1)
                        {
                            break;
                        }
                    }
                }

                if (count > 1)
                {
                    Lua.DoString("UseItemByName(\"" + 33567 + "\")");
                    slog("Borean Leather created.");
                    return true;
                }
            }
            catch (Exception ex)
            {
                slog(ex.Message);
            }
            return false;
        }
    }
}
#pragma warning restore