

#pragma warning disable
namespace Rogue
{
    using Styx.Combat.CombatRoutine;
    using Styx.Helpers;
    using Styx.Logic.Combat;
    using Styx.WoWInternals;
    using Styx.WoWInternals.WoWObjects;
    using System;
    using Styx.Logic;
    using Styx.Logic.Pathing;
    using System.Threading;
    using System.Diagnostics;
    using System.Collections.Generic;
    using Styx;

    public class Rogue : CombatRoutine
    {
        public override WoWClass Class { get { return WoWClass.Rogue; } }

        public override string Name { get { return "Hawker's Rogue 2.0"; } }

        #region Private Members

        private void slog(string msg)
        {
            if (msg == _logspam)
            {
                return;
            }

            Logging.Write(msg);
            _logspam = msg;
        }

        #endregion

        #region Global Variables

        bool IsInGame = ObjectManager.IsInGame;
        bool SliceAndDiceUsed = false;
        List<WoWUnit> addsList = new List<WoWUnit>();
        private readonly LocalPlayer Me = ObjectManager.Me;
        private string _logspam;
        WoWPoint pointNow = new WoWPoint();
        private uint killComboCount = 4;
        private uint deathCount = 0;


        private double targetDistance
        {
            get
            {
                return Me.GotTarget ? Me.CurrentTarget.Distance : uint.MaxValue - 1;

            }
        }

        private WoWPoint behindTarget
        {
            get
            {
                if (Me.GotTarget)
                {
                    return WoWMathHelper.CalculatePointBehind(Me.CurrentTarget.Location, Me.CurrentTarget.Rotation, 4);
                }
                else
                {
                    WoWPoint noSpot = new WoWPoint();
                    return noSpot;
                }
            }
        }

        private WoWPoint targetLocation
        {
            get
            {
                if (Me.GotTarget)
                {
                    return Me.CurrentTarget.Location;
                }
                else
                {
                    WoWPoint noSpot = new WoWPoint();
                    return noSpot;
                }
            }
        }

        private ulong targettingGuid
        {
            get
            {
                //    try
                //    {
                if (!Equals(null, Targeting.Instance.TargetList) &&
                    Targeting.Instance.TargetList.Count > 0)
                {
                    return Targeting.Instance.FirstUnit.Guid;
                }
                else
                {
                    return 0;
                }
            }
        }

        private static ulong lastGuid;
        private static Stopwatch fightTimer = new Stopwatch();

        private static ulong pullGuid;
        private static Stopwatch pullTimer = new Stopwatch();
        #endregion

        #region Rest

        public override bool NeedRest
        {
            get
            {
                if (NeedPoisons())
                {
                    return true;
                }

                if (Battlegrounds.IsInsideBattleground)
                {
                    return false;
                }

                return Me.GetPowerPercent(WoWPowerType.Health) <= 55;
            }
        }

        public override void Rest()
        {
            if (NeedPoisons())
            {
                ApplyPoisons();
                Thread.Sleep(3000);
            }
            Styx.Logic.Common.Rest.Feed();

        }

        #endregion

        #region Pull

        private WoWUnit FindPlayers()
        {
            var playerList = ObjectManager.GetObjectsOfType<WoWUnit>();

            foreach (WoWUnit players in playerList)
            {

                if (players.IsPlayer)
                {
                    slog("Got Players! Run for the hills!");
                    return players;
                }
            }

            return null;
        }


        bool IsFacingAway
        {
            get
            {
                bool face = false;
                double bearing = Me.CurrentTarget.Rotation;
                //double Angle = bearing * 180 / Math.PI; 
                if (bearing > Math.PI / 2 || bearing < -Math.PI / 2)

                    face = true;
                return face;
            }
        }

        //degrees = radians * 180 / Math.PI
        public override void Pull()
        {
            try
            {
                if (Blacklist.Contains(Me.CurrentTarget.Guid))
                    slog("Pull Blacklisted");

                if (Battlegrounds.IsInsideBattleground &&
                    Me.GotTarget &&
                    Me.CurrentTarget.Mounted)
                {
                    Styx.Logic.Blacklist.Add(Me.CurrentTarget.Guid, System.TimeSpan.FromSeconds(30));
                    Me.ClearTarget();
                    return;
                }

                if (Me.GotTarget && Me.CurrentTarget.Guid != pullGuid)
                {
                    pullTimer.Reset();
                    pullTimer.Start();
                    pullGuid = Me.CurrentTarget.Guid;

                    if (Me.CurrentTarget.IsPlayer)
                    {
                        slog("Killing " + Me.CurrentTarget.Level.ToString() + " " + Me.CurrentTarget.Race.ToString() + " who is " + System.Math.Round(Me.CurrentTarget.Distance).ToString() + " yards away.");
                    }
                    else
                    {

                        slog("Killing " + Me.CurrentTarget.Name + " is " + System.Math.Round(Me.CurrentTarget.Distance).ToString() + " yards away.");
                    }
                }

                if (!Me.CurrentTarget.IsPlayer && pullTimer.ElapsedMilliseconds > 30 * 1000)
                {
                    slog(" This " + Me.CurrentTarget.Name + " is a bugged mob.  Blacklisting for 1 hour.");

                    Blacklist.Add(Me.CurrentTarget.Guid, TimeSpan.FromHours(1.00));

                    Me.ClearTarget();
                    pullGuid = 0;
                }

                if (!Me.Buffs.ContainsKey("Stealth"))
                {
                    SpellManager.CastSpell("Stealth");
                }

                if (!Me.Combat && targetDistance > 5 && targetDistance < Styx.Logic.Targeting.PullDistance + 10)
                {
                    int a = 0;
                    while (a < 50 && ObjectManager.Me.IsAlive && ObjectManager.Me.GotTarget && ObjectManager.Me.CurrentTarget.Distance > 5)
                    {
                        if (ObjectManager.Me.Combat)
                        {
                            Logging.Write("Combat has started.  Abandon pull.");
                            break;
                        }
                        WoWMovement.Face();
                        Navigator.MoveTo(WoWMovement.CalculatePointFrom(ObjectManager.Me.CurrentTarget.Location, 2f));
                        Thread.Sleep(250);
                        ++a;
                    }
                }
                else
                {
                    WoWMovement.MoveStop();
                    WoWMovement.Face();
                }


                if (Me.GotTarget &&
                    targetDistance <= 5 &&
                    !Me.IsAutoAttacking)
                {
                    CheapShot();
                    Navigator.MoveTo(attackPoint);
                    Lua.DoString("StartAttack()");
                    SliceAndDice();
                }
            }
            finally
            {
                slog("Pull done.");
            }

        }

        #endregion



        #region Pull Buffs

        public override bool NeedPullBuffs { get { return false; } }

        public override void PullBuff()
        {
            //slog("Got Here");
            //Stealth();
        }

        #endregion

        #region Pre Combat Buffs

        public override bool NeedPreCombatBuffs { get { return false; } }

        public override void PreCombatBuff()
        {
            //slog("Got Here");
            //Stealth();
            //if (!Me.Buffs.ContainsKey("Stealth"))
            //{
            //SpellManager.CastSpell("Stealth", false);
            //}
        }

        #endregion

        #region Combat Buffs

        public override bool NeedCombatBuffs { get { return false; } }

        public override void CombatBuff() { }

        #endregion

        #region Heal

        public override bool NeedHeal { get { return false; } }// Me.GetPowerPercent(WoWPowerType.Health) <= 30; } }

        public override void Heal()
        {
            Gouge();
        }

        #endregion

        #region Falling

        public void HandleFalling() { }

        #endregion

        #region Combat

        public override void Combat()
        {
            if (Blacklist.Contains(Me.CurrentTarget.Guid))
                slog("Pull Blacklisted");

            if (Me.GotTarget && (Me.CurrentTarget.Guid != lastGuid || InfoPanel.Deaths > deathCount))
            {
                if (InfoPanel.Deaths > deathCount)
                {
                    deathCount = InfoPanel.Deaths;
                }

                if (Me.CurrentTarget.IsPlayer)
                {
                    slog("Killing level " + Me.CurrentTarget.Level.ToString() + " " + Me.CurrentTarget.Race.ToString() + " " + Me.CurrentTarget.Class.ToString() + " at range of " + System.Math.Round(Me.CurrentTarget.Distance).ToString() + " yards.");
                }
                else
                {
                    slog("Killing " + Me.CurrentTarget.Name + " at range of " + System.Math.Round(Me.CurrentTarget.Distance).ToString() + " yards.");
                }
                fightTimer.Reset();
                fightTimer.Start();
                lastGuid = Me.CurrentTarget.Guid;
                SliceAndDiceUsed = false;
            }

            if (combatChecks)
            {
                addsList = getAdds();

                if (addsList.Count > 1)
                {
                    KillingSpree();
                    BladeFlurry();
                    AdrenalineRush();
                }

                if (Me.ComboPoints > 5)
                {
                    slog(Me.ComboPoints.ToString() + " combo points.  Need to restart WoW.");
                }

                if (Me.ComboPoints < 3 &&
                    !SliceAndDiceUsed)
                {
                    SliceAndDice();
                    SliceAndDiceUsed = true;
                }

            }
            else
            {
                return;
            }

            if (combatChecks)
            {
                Berserking();
                Bloodrage();

                if (Me.CurrentTarget.IsCasting)
                {
                    Kick();
                    ArcaneTorrent();
                }

                if (Me.ComboPoints < killComboCount ||
                    Me.ComboPoints >= 5)    // allows for buggy combo count
                {
                    SinisterStrike();
                }
                else
                {
                    Eviscerate();
                }
            }
            else
            {
                return;
            }


            if (Me.HealthPercent < 50)
            {
                if (!combatChecks)
                    return;

                KillingSpree();
                Evasion();
                AdrenalineRush();
                Stoneform();
            }

            if ((Me.HealthPercent < 30 &&
                Me.CurrentTarget.HealthPercent > Me.CurrentTarget.HealthPercent))
            {
                Healing.UseHealthPotion();
            }

            if (Me.GotTarget && !Me.CurrentTarget.IsPlayer && fightTimer.ElapsedMilliseconds > 40 * 1000 && Me.CurrentTarget.HealthPercent < 95)
            {
                slog(" This " + Me.CurrentTarget.Name + " is a bugged mob.  Combat blacklisting for 1 hour.");

                Blacklist.Add(Me.CurrentTarget.Guid, TimeSpan.FromHours(1.00));

                SafeMove(WoWMovement.MovementDirection.Backwards, 5000);
                Me.ClearTarget();
                lastGuid = 0;

            }

        }

        #endregion

        #region Spells

        void SinisterStrike()
        {
            if (Me.GotTarget &&
                targetDistance <= 5 &&
                SpellManager.CastSpell("Sinister Strike"))
            {
                slog("Sinister Strike.");
            }
        }

        bool Throw()
        {
            if (Me.GotTarget &&
                !Me.Combat)
            {
                if (Me.CurrentTarget.Distance >= 6 && Me.CurrentTarget.Distance <= 28)
                {
                    if (SpellManager.CastSpell("Throw")) //Found Throw
                    {
                        slog("Throw.");
                        return true;
                    }
                }
            }
            return false;

        }

        //Eviscerate (Req Level 1)

        void Eviscerate()
        {
            if (Me.GotTarget &&
                targetDistance <= 5 &&
                SpellManager.CastSpell("Eviscerate"))
            {
                slog("Eviscerate.");
            }
        }

        /// Stealth (Req Level 2)

        void Stealth()
        {
            if (!Me.Combat) //Cant stealth in combat!
            {
                if (!Me.Buffs.ContainsKey("Stealth") &&
                    SpellManager.CastSpell("Stealth"))
                {
                    slog("Stealth.");
                }
            }
        }

        // Evasion
        void Evasion()
        {
            if (Me.GotTarget &&
                targetDistance <= 5 &&
                SpellManager.CastSpell("Evasion"))
            {
                slog("Evasion.");
            }
        }

        // Sprint
        void Sprint()
        {
            if (SpellManager.CastSpell("Sprint"))
            {
                slog("Sprint.");
            }
        }

        // Backstab
        void Backstab()
        {
            if (Me.GotTarget &&
                targetDistance <= 5 &&
                SpellManager.CastSpell("Backstab"))
            {
                slog("Try to Backstab.");
            }
        }

        // Gouge
        void Gouge()
        {
            if (Me.GotTarget &&
                targetDistance <= 5 &&
                SpellManager.CastSpell("Gouge"))
            {
                slog("Gouge.");
            }
        }

        // Cheap Shot or Backstab?
        void CheapShot()
        {
            if (Me.GotTarget && targetDistance <= 5)
            {
                if (Me.CurrentTarget.IsPlayer && SpellManager.KnownSpells.ContainsKey("Garrote"))
                {
                    WoWSpell Garrote = SpellManager.KnownSpells["Garrote"];
                    var isUsable = Lua.LuaGetReturnValue("return IsUsableSpell('Garrote')", "hax.lua");
                    if (isUsable != null)
                    {
                        if (isUsable[0] == "1")
                        {
                            SpellManager.CastSpell("Garrote");
                            slog("Garrote");
                        }
                    }
                }

                if (SpellManager.CastSpell("Cheap Shot"))
                {
                    slog("Cheap Shot.");
                }
            }
        }

        // Kick
        void Kick()
        {
            if (Me.GotTarget &&
                targetDistance <= 5 &&
                SpellManager.CastSpell("Kick"))
            {
                slog("Kick.");
            }
        }

        // Garrote
        void Garrote()
        {
            if (Me.GotTarget &&
                targetDistance <= 5 &&
                SpellManager.CastSpell("Garrote"))
            {
                slog("Try to Garrote.");
            }
        }

        // Ambush
        void Ambush()
        {
            if (Me.GotTarget &&
                targetDistance <= 5 &&
                SpellManager.CastSpell("Ambush"))
            {
                slog("Try to Ambush.");
            }
            else
            {
                Backstab();
            }
        }

        void SliceAndDice()
        {
            if (SpellManager.KnownSpells.ContainsKey("Slice and Dice") && !Me.Buffs.ContainsKey("Slice and Dice") && Me.GotTarget && targetDistance <= 5 && SpellManager.CastSpell("Slice and Dice"))
            {
                slog("Slice and Dice.");
            }
        }

        void BladeFlurry()
        {
            if (Me.GotTarget &&
                targetDistance <= 5 &&
                SpellManager.CastSpell("Blade Flurry"))
            {
                slog("Blade Flurry.");
            }
        }

        void AdrenalineRush()
        {
            if (Me.GotTarget &&
                targetDistance <= 5 &&
                SpellManager.CastSpell("Adrenaline Rush"))
            {
                slog("Adrenaline Rush.");
            }
        }

        void KillingSpree()
        {
            if (Me.GotTarget &&
                targetDistance <= 5 &&
                SpellManager.CastSpell("Killing Spree"))
            {
                slog("Killing Spree.");
            }
        }

        #endregion

        #region horde racials

        // Berserking
        void Berserking()
        {
            if (SpellManager.CastSpell("Berserking"))
            {
                Styx.Helpers.Logging.Write("Berserking.");
            }
        }

        // Bloodrage
        void Bloodrage()
        {
            if (SpellManager.CastSpell("Bloodrage"))
            {
                Styx.Helpers.Logging.Write("Bloodrage.");
            }
        }

        // War Stomp
        void WarStomp()
        {
            if (SpellManager.CastSpell("War Stomp"))
            {
                Styx.Helpers.Logging.Write("War Stomp.");
            }
        }

        // Arcane Torrent
        void ArcaneTorrent()
        {
            if (SpellManager.CastSpell("Arcane Torrent"))
            {
                Styx.Helpers.Logging.Write("Arcane Torrent.");
            }
        }

        // Will of the Forsaken 
        void WillOfTheForsaken()
        {
            if (SpellManager.CastSpell("Will of the Forsaken"))
            {
                Styx.Helpers.Logging.Write("Will of the Forsaken.");
            }
        }
        #endregion

        #region alliance racials

        // Stoneform
        void Stoneform()
        {
            if (SpellManager.CastSpell("Stoneform"))
            {
                Styx.Helpers.Logging.Write("Stoneform.");
            }
        }

        // Gift of the Naaru
        void GiftOfTheNaaru()
        {
            if (SpellManager.CastSpell("Gift of the Naaru"))
            {
                Styx.Helpers.Logging.Write("Gift of the Naaru.");
            }
        }

        // Every Man for Himself
        void EveryManForHimself()
        {
            if (SpellManager.CastSpell("Every Man for Himself"))
            {
                Styx.Helpers.Logging.Write("Every Man for Himself.");
            }
        }

        // Shadowmeld
        void Shadowmeld()
        {
            if (SpellManager.CastSpell("Shadowmeld"))
            {
                Styx.Helpers.Logging.Write("Shadowmeld.");
            }
        }

        // Escape Artist
        void EscapeArtist()
        {
            if (SpellManager.CastSpell("Escape Artist"))
            {
                Styx.Helpers.Logging.Write("Escape Artist.");
            }
        }


        #endregion

        #region combat checks
        // lua for when both hand shave the same weapon
        private bool IsWeaponEnhanceNeeded(out bool needMainhand, out bool needOffhand)
        {
            needMainhand = false;
            needOffhand = false;

            if (!IsInGame)
                return false;


            List<string> weaponEnchants = Lua.LuaGetReturnValue("return GetWeaponEnchantInfo()", "hawker.lua");

            if (Equals(null, weaponEnchants))
                return false;

            needMainhand = weaponEnchants[0] == "" || weaponEnchants[0] == "nil";
            if (Me.Offhand.Entry > 0)
                needOffhand = weaponEnchants[3] == "" || weaponEnchants[3] == "nil";


            if (needMainhand)
                Logging.Write("Mainhand weapon {0} needs enchancement", Me.Mainhand.Name);

            if (needOffhand)
                Logging.Write("Offhand weapon {0} needs enhancement", Me.Offhand == null ? "(none)" : Me.Offhand.Name);

            return needMainhand || needOffhand;
        }


        // Instant Poison Entry Ids
        private List<uint> PoisonEntryIds = new List<uint>()
        {
            6947, 6949, 6950, 8926, 8927, 8928,21927,43230,43231
        };

        private Stopwatch poisonTimer = new Stopwatch();

        // Instant Poison Enchant Ids
        private List<uint> PoisonEnchantIds = new List<uint>()
        {
            323, 324, 325, 623, 624, 625, 2641, 3768, 3769
        };

        private bool NeedPoisons()
        {
            // over level 10
            if (Me.Level < 10)
            {
                return false;
            }
            // timer to ease burden on cpu
            if (!poisonTimer.IsRunning)
            {
                poisonTimer.Reset();
                poisonTimer.Start();
            }

            if (poisonTimer.ElapsedMilliseconds < 20 * 1000)
            {
                return false;
            }

            // look at all items in inventory and check we have poisons to apply
            WoWItem instantPoison = HaveItemCheck(PoisonEntryIds);

            if (Equals(null, instantPoison))
            {
                return false;
            }

            // look at weapons and see if they have poisons applied

            if (Me.Mainhand.Entry == Me.Offhand.Entry)
            {
                bool needPoisonMainhand, needPoisonOffhand;

                return IsWeaponEnhanceNeeded(out needPoisonMainhand, out needPoisonOffhand);
            }

            if (PoisonEnchantIds.Contains(Me.Mainhand.TemporaryEnchantment.Id) && PoisonEnchantIds.Contains(Me.Offhand.TemporaryEnchantment.Id))
            {
                return false;
            }

            return true;
        }

        private void ApplyPoisons()
        {
            poisonTimer.Reset();
            poisonTimer.Start();

            WoWItem instantPoison = HaveItemCheck(PoisonEntryIds);

            if (!Equals(null, instantPoison))
            {
                if (Me.Mounted)
                    Mount.Dismount();
            }

            WoWMovement.MoveStop();

            bool needPoisonMainhand, needPoisonOffhand;

            if (IsWeaponEnhanceNeeded(out needPoisonMainhand, out needPoisonOffhand))
            {
                if (needPoisonOffhand)
                {
                    slog("Applying poison to offhand weapon: " + Me.Offhand.Name);
                    Lua.DoString("UseItemByName(\"" + instantPoison.Entry + "\")");
                    Thread.Sleep(100);
                    Lua.DoString("UseInventoryItem(17)");
                    Thread.Sleep(3100);
                }

                if (needPoisonMainhand)
                {
                    slog("Applying poison to main hand weapon: " + Me.Mainhand.Name);
                    Lua.DoString("UseItemByName(\"" + instantPoison.Entry + "\")");
                    Thread.Sleep(100);
                    Lua.DoString("UseInventoryItem(16)");
                    Thread.Sleep(3100);
                }
            }

        }

        private WoWItem HaveItemCheck(List<uint> listId)
        {
            foreach (WoWItem item in ObjectManager.GetObjectsOfType<WoWItem>(false))
            {
                if (listId.Contains(item.Entry))
                {
                    return item;
                }
            }
            return null;
        }

        private bool combatChecks
        {
            get
            {
                if (!ObjectManager.Me.GotTarget)
                {
                    Logging.Write("No target.");
                    return false;
                }

                if (ObjectManager.Me.Dead)
                {
                    Logging.Write("I died.");
                    return false;
                }

                if (ObjectManager.Me.GotTarget && !ObjectManager.Me.IsAutoAttacking)
                {
                    Lua.DoString("StartAttack()");
                }

                if (ObjectManager.Me.CurrentTarget.Distance > 50)
                {
                    if (ObjectManager.Me.CurrentTarget.IsPlayer)
                    {
                        Logging.Write("Out of range: Level " + ObjectManager.Me.CurrentTarget.Level.ToString() + " " + ObjectManager.Me.CurrentTarget.Race.ToString() + " " + System.Math.Round(ObjectManager.Me.CurrentTarget.Distance).ToString() + " yards away.");
                    }
                    else
                    {

                        Logging.Write("Out of range: Level " + ObjectManager.Me.CurrentTarget.Name + " is " + System.Math.Round(ObjectManager.Me.CurrentTarget.Distance).ToString() + " yards away.");
                    }

                    Me.ClearTarget();
                    return false;
                }

                double meleeRange = 5;

                if (ObjectManager.Me.CurrentTarget.Distance > meleeRange)
                {
                    int a = 0;
                    while (a < 50 && ObjectManager.Me.IsAlive && ObjectManager.Me.GotTarget && ObjectManager.Me.CurrentTarget.Distance > meleeRange)
                    {
                        WoWMovement.Face();
                        Navigator.MoveTo(WoWMovement.CalculatePointFrom(ObjectManager.Me.CurrentTarget.Location, 2.5f));
                        Thread.Sleep(250);
                        ++a;
                    }
                }

                WoWMovement.Face();

                return true;
            }
        }

        private List<WoWUnit> getAdds()
        {
            List<WoWUnit> mobList = ObjectManager.GetObjectsOfType<WoWUnit>(false);
            List<WoWUnit> enemyMobList = new List<WoWUnit>();

            foreach (WoWUnit thing in mobList)
            {
                try
                {
                    if ((thing.Guid != Me.Guid) &&
                    thing.IsTargetingMe)
                    {
                        enemyMobList.Add(thing);
                    }
                }
                catch (Exception ex)
                {
                    slog("Add error.");
                }
            }

            if (enemyMobList.Count > 1)
            {
                slog("Warning: there are " + enemyMobList.Count.ToString() + " attackers.");
            }
            return enemyMobList;

        }
        #endregion

        #region movement logic

        private void SafeMove(WoWMovement.MovementDirection direction, int duration)
        {
            DateTime start = DateTime.Now;

            WoWMovement.Move(direction);

            while (ObjectManager.Me.HealthPercent > 1)
            {
                Thread.Sleep(100);
                if (DateTime.Now.Subtract(start).Milliseconds >= duration)
                {
                    break;
                }
            }

            WoWMovement.MoveStop();
        }

        WoWPoint attackPointBuffer;
        WoWPoint attackPoint
        {
            get
            {
                if (Me.GotTarget)
                {
                    attackPointBuffer = WoWMovement.CalculatePointFrom(Me.CurrentTarget.Location, 1.0f);
                    return attackPointBuffer;
                }
                else
                {
                    WoWPoint noSpot = new WoWPoint();
                    return noSpot;
                }
            }
        }

        private static bool UseNavigator;
        private WoWUnit _lastTarget;
        private WoWPoint _dest = WoWPoint.Zero;
        private WoWPoint GetTraceLinePos()
        {
            return new WoWPoint(Me.X, Me.Y, Me.Z + 2.132f);
        }

        private static Stopwatch movementTimer = new Stopwatch();

        #endregion
    }
}
#pragma warning restore