using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading;
using Styx;
using Styx.Combat.CombatRoutine;
using Styx.Helpers;
using Styx.Logic;
using Styx.Logic.Combat;
using Styx.Logic.Pathing;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;

#pragma warning disable

namespace Paladin
{
    public class Paladin : CombatRoutine
    {
        public override string Name { get { return "Hawker's Paladin 2.3"; } }
        public override WoWClass Class { get { return WoWClass.Paladin; } }

        private static void Player_OnMobKilled(BotEvents.Player.MobKilledEventArgs args)
        {
            StyxWoW.Me.ClearTarget();

            if (StyxWoW.Me.IsAutoAttacking)
            {
                StyxWoW.Me.ToggleAttack();
            }
        }

        private static ulong _lastGuid;

        TimeSpan _needBuffTimespan = new TimeSpan(0, 3, 0);

        private readonly Stopwatch _fightTimer = new Stopwatch();
        private readonly LocalPlayer _me = ObjectManager.Me;

        private List<WoWUnit> _addsList = new List<WoWUnit>();
        private string _logspam; // prevent logs filling with dupe entries
        private List<uint> _runnerList = new List<uint>();

        private double _restHealPercent = 55;
        private double _combatHealPercent = 65;



        #region Buffs and Heals

        private bool HasBuffProcced(string cSearchBuffName, int minStackCount)
        {
            int stackCount = 0;

            List<string> myBuffs = Lua.LuaGetReturnValue("return UnitBuff(\"player\",\"" + cSearchBuffName + "\")", "hawker.lua");

            if (Equals(null, myBuffs))
                return false;

            string buffName = myBuffs[0];

            if (minStackCount > 0)
            {
                stackCount = Convert.ToInt32(myBuffs[3]);
            }

            if (buffName == cSearchBuffName || stackCount >= minStackCount)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public override bool NeedRest
        {
            get
            {
                if (!_me.Mounted)
                {
                    if (ObjectManager.Me.Combat)
                    {
                        return false;
                    }

                    if (ObjectManager.Me.Auras.ContainsKey("Resurrection Sickness"))
                    {
                        return true;
                    }

                    if (ObjectManager.Me.IsSwimming)
                    {
                        return false;
                    }

                    if (SpellManager.KnownSpells.ContainsKey("Seal of Command"))
                    {
                        if (!_me.Buffs.ContainsKey("Seal of Command"))
                        {
                            return true;
                        }
                    }
                    else if (!_me.Buffs.ContainsKey("Seal of Righteousness") && SpellManager.KnownSpells.ContainsKey("Seal of Righteousness"))
                    {
                        return true;
                    }

                    if (SpellManager.KnownSpells.ContainsKey("Blessing of Might") &&
                        !_me.Buffs.ContainsKey("Blessing of Might") &&
                        !_me.Buffs.ContainsKey("Greater Blessing of Might") &&
                        !_me.Buffs.ContainsKey("Battle Shout"))
                    {
                        return true;
                    }

                    if (Battlegrounds.IsInsideBattleground)
                    {
                        return false;
                    }

                    if (SpellManager.KnownSpells.ContainsKey("Blessing of Kings"))
                    {
                        foreach (WoWPlayer player in _me.PartyMembers)
                        {
                            if (player.IsAlive && player.InLineOfSight &&
                                player.Distance < SpellManager.KnownSpells["Blessing of Kings"].MaxRange - 2
                                && (player.Class == WoWClass.Warrior || player.Class == WoWClass.Paladin))
                                if (!player.Buffs.ContainsKey("Blessing of Kings"))
                                    return true;
                        }
                    }
                }

                if (ObjectManager.Me.HealthPercent <= _restHealPercent || ObjectManager.Me.ManaPercent <= 50)
                    return true;

                return false;
            }
        }

        public override bool NeedPreCombatBuffs
        {
            get { return NeedRest; }
        }

        public override bool NeedCombatBuffs
        {
            get { return false; }
        }

        public bool NeedHeal
        {
            get
            {
                if (HealTarget.Dead)
                    return false;

                if (HealTarget.Combat && HealTarget.HealthPercent < _combatHealPercent)
                {
                    return true;
                }

                if (HealTarget.HealthPercent < _restHealPercent)
                {
                    return true;
                }

                return false;
            }
        }

        public override bool NeedPullBuffs
        {
            get
            {
                if (SpellManager.KnownSpells.ContainsKey("Avenging Wrath") && !SpellManager.KnownSpells["Avenging Wrath"].Cooldown)
                    return true;
                return false;
            }
        }

        public override void Rest()
        {
            PaladinBuffs();

            if (Battlegrounds.IsInsideBattleground)
                return;

            if (_me.HealthPercent < _restHealPercent)
            {
                HolyLight();
            }

            if (SpellManager.CanCastSpell("Flash of Light") && _me.HealthPercent < 90)
            {
                FlashOfLight();
            }

            if (_me.ManaPercent < 60)
            {
                Styx.Logic.Common.Rest.Feed();
                if (_me.HealthPercent < _restHealPercent)
                    Styx.Logic.Common.Rest.Feed();
            }
        }

        public override void CombatBuff()
        {
        }

        public override void PullBuff()
        {
            AvengingWrath();
        }

        #endregion

        public override void Pull()
        {
            if (SpellManager.KnownSpells.ContainsKey("Seal of Command"))
            {
                if (!_me.Buffs.ContainsKey("Seal of Command"))
                {
                    SealOfCommand("Seal of Command.");
                }
            }
            else if (!_me.Buffs.ContainsKey("Seal of Righteousness") && SpellManager.KnownSpells.ContainsKey("Seal of Righteousness"))
            {
                SealOfRighteousness("Seal of Righteousness.");
            }

            if (!_me.GotTarget)
                return;

            if (!Battlegrounds.IsInsideBattleground && _me.PartyMembers.Count > 0 && !Equals(null, _me.PartyMember1.CurrentTarget))
            {
                Log("Will on pull the party leader's target.");
                return;
            }

            if (ObjectManager.Me.GotTarget && !_me.IsAutoAttacking)
                Lua.DoString("StartAttack()");

            Log("Pull {0} at {1}.", _me.CurrentTarget.Name, Math.Round(_me.CurrentTarget.Distance));

            #region mobs
            if (!_me.CurrentTarget.IsPlayer && SpellManager.KnownSpells.ContainsKey("Hand of Reckoning"))
            {
                if (ObjectManager.Me.CurrentTarget.Distance > SpellManager.KnownSpells["Hand of Reckoning"].MaxRange - 2)
                {
                    Logging.Write("Get to {0} yards.", SpellManager.KnownSpells["Hand of Reckoning"].MaxRange);
                    int a = 0;
                    while (a < 50 && ObjectManager.Me.IsAlive && ObjectManager.Me.GotTarget && ObjectManager.Me.CurrentTarget.Distance > SpellManager.KnownSpells["Hand of Reckoning"].MaxRange)
                    {
                        if (ObjectManager.Me.Combat)
                        {
                            Logging.Write("Combat has started.  Abandon pull.");
                            break;
                        }
                        WoWMovement.Face();
                        Navigator.MoveTo(WoWMovement.CalculatePointFrom(ObjectManager.Me.CurrentTarget.Location, 25f));
                        Thread.Sleep(250);
                        ++a;
                    }
                }

                Logging.Write("Within HoR range.");
                WoWMovement.MoveStop();
                WoWMovement.Face();
                HandOfReckoning();
                if (_me.PartyMembers.Count == 0)
                {
                    Exorcism();
                }



                Stopwatch pTimer = new Stopwatch();
                pTimer.Start();

                while (pTimer.ElapsedMilliseconds < 1500 && _me.GotTarget && _me.CurrentTarget.IsTargetingMe && _me.CurrentTarget.Distance > 5)
                {
                    Log("Waiting for " + _me.CurrentTarget.Name + " come into melee range.");
                    Thread.Sleep(250);
                }
            }
            #endregion
            else
            {
                float attackRange = 5;

                int a = 0;
                while (a < 6 && _me.GotTarget && _me.CurrentTarget.Distance > attackRange)
                {
                    Navigator.MoveTo(_me.CurrentTarget.Location);
                    ++a;
                }

                WoWMovement.Face();
                if (!_me.Combat)
                {
                    Thread.Sleep(500);
                }

                _me.CurrentTarget.Interact();
                PaladinJudgements();


            }
        }

        private void Log(string msg)
        {
            if (msg == _logspam)
            {
                return;
            }

            Logging.Write(msg);
            _logspam = msg;
        }

        private void Log(string msg, params object[] args)
        {
            if (msg != _logspam)
            {
                try
                {
                    Logging.Write(msg, args);
                    _logspam = msg;
                }
                catch (Exception ex)
                {
                    Logging.WriteDebug("Error in Log: ");
                    Logging.WriteDebug(ex.Source);
                }
            }
        }

        public override void PreCombatBuff()
        {
            // check buffs 
            if (NeedCombatBuffs)
            {
                PaladinBuffs();
            }
        }

        public override void Heal()
        {
            if (_me.Combat)
            {
                if (_me.CurrentTarget.CreatureType != WoWCreatureType.Beast && _me.CurrentTarget.CreatureType != WoWCreatureType.Mechanical && SpellManager.KnownSpells.ContainsKey("Repentance") && !SpellManager.KnownSpells["Repentance"].Cooldown)
                    Repentance();
                else
                    HammerOfJustice();

                if (HealTarget.Guid != _me.Guid)
                    HealTarget.Target();

                if (Equals(HealTarget, _me))
                {
                    DivineShield();
                }
                else if (HealTarget.Class != WoWClass.Warrior)
                {
                    HandOfProtection();
                }

                if (HealTarget.HealthPercent < 25)
                {
                    LayOnHands();
                }

                if (HealTarget.HealthPercent > _combatHealPercent && SpellManager.KnownSpells.ContainsKey("Flash of Light"))
                {
                    FlashOfLight();
                }
                else
                {
                    HolyLight();
                }
            }
            else if (HealTarget.HealthPercent < _combatHealPercent)
            {
                HolyLight();
            }
            else if (HealTarget.HealthPercent < 90)
            {
                FlashOfLight();
            }
        }

        private bool combatChecks
        {
            get
            {
                if (!ObjectManager.Me.GotTarget || ObjectManager.Me.Dead || !ObjectManager.Me.Combat)
                {
                    return false;
                }
                else if (!ObjectManager.Me.IsAutoAttacking)
                {
                    Lua.DoString("StartAttack()");
                }

                if (ObjectManager.Me.CurrentTarget.Distance > 50)
                {
                    if (ObjectManager.Me.CurrentTarget.IsPlayer)
                    {
                        Logging.Write("Out of range: Level " + ObjectManager.Me.CurrentTarget.Level.ToString() + " " + ObjectManager.Me.CurrentTarget.Race.ToString() + " " + System.Math.Round(ObjectManager.Me.CurrentTarget.Distance).ToString() + " yards away.");
                    }
                    else
                    {

                        Logging.Write("Out of range: Level " + ObjectManager.Me.CurrentTarget.Name + " is " + System.Math.Round(ObjectManager.Me.CurrentTarget.Distance).ToString() + " yards away.");
                    }



                    if (ObjectManager.Me.Combat)
                    {
                        Blacklist.Add(ObjectManager.Me.CurrentTarget.Guid, TimeSpan.FromSeconds(10));
                        Targeting.Instance.Clear();
                    }
                    ObjectManager.Me.ClearTarget();
                    return false;
                }

                double meleeRange = 5;

                if (_me.Level < 5)
                    meleeRange = 1;

                if (ObjectManager.Me.CurrentTarget.Distance > meleeRange)
                {
                    int a = 0;
                    while (a < 50 && ObjectManager.Me.IsAlive && ObjectManager.Me.GotTarget && ObjectManager.Me.CurrentTarget.Distance > meleeRange)
                    {
                        WoWMovement.Face();
                        Navigator.MoveTo(WoWMovement.CalculatePointFrom(ObjectManager.Me.CurrentTarget.Location, 2.5f));
                        Thread.Sleep(250);
                        ++a;
                    }

                }

                WoWMovement.MoveStop();
                WoWMovement.Face();

                return true;
            }
        }

        public override void Combat()
        {
            try
            {
                // Log(" Entered Combat() at {0}:{1}:{2}:{3}", DateTime.Now.Hour, DateTime.Now.Minute, DateTime.Now.Second, DateTime.Now.Millisecond);
                if (!Equals(null, _me.PartyMember1) && !Equals(_me.CurrentTarget, _me.PartyMember1.CurrentTarget) &&
                    _me.PartyMember1.Distance < 45)
                {
                    _me.PartyMember1.CurrentTarget.Target();
                    _me.CurrentTarget.Face();
                }

                if (!ObjectManager.Me.GotTarget)
                    return;

                if (ObjectManager.Me.GotTarget && !ObjectManager.Me.CurrentTarget.IsPlayer && ObjectManager.Me.CurrentTarget.Attackable)
                {
                    if (ObjectManager.Me.CurrentTarget.CurrentTargetGuid == ObjectManager.Me.Guid || (ObjectManager.Me.GotAlivePet && ObjectManager.Me.CurrentTarget.CurrentTargetGuid == ObjectManager.Me.Pet.Guid))
                    {
                        WoWMovement.MoveStop();
                        WoWMovement.Face();
                    }
                }

                if (_me.GotTarget && _me.CurrentTarget.Guid != _lastGuid)
                {
                    _fightTimer.Reset();
                    _fightTimer.Start();
                    _lastGuid = _me.CurrentTarget.Guid;
                }

                if (_me.GotTarget && !_me.CurrentTarget.IsPlayer && _fightTimer.ElapsedMilliseconds > 20 * 1000 && _me.CurrentTarget.HealthPercent > 95)
                {
                    Log(" This " + _me.CurrentTarget.Name + " is a bugged mob.  blacklisting for 1 hour.");

                    Blacklist.Add(_me.CurrentTarget.Guid, TimeSpan.FromHours(1.00));

                    KeyboardManager.PressKey('S');
                    Thread.Sleep(5 * 1000);
                    KeyboardManager.ReleaseKey('S');
                    _me.ClearTarget();
                    _lastGuid = 0;
                }

                #region buffs
                if (!combatChecks)
                    return;
                else if (SpellManager.KnownSpells.ContainsKey("Seal of Command"))
                {
                    if (!_me.Buffs.ContainsKey("Seal of Command"))
                    {
                        SealOfCommand("Seal of Command.");
                    }
                }
                else if (!_me.Buffs.ContainsKey("Seal of Righteousness") && SpellManager.KnownSpells.ContainsKey("Seal of Righteousness"))
                {
                    SealOfRighteousness("Seal of Righteousness.");
                }

                #endregion

                #region heals
                if (combatChecks)
                {
                    if (_me.HealthPercent < 35)
                    {
                        if (_me.HealthPercent < 25)
                        {
                            LayOnHands();
                        }
                        else
                        {
                            DivineShield();
                        }
                    }
                }
                else
                {
                    return;
                }

                if (combatChecks)
                {
                    if ((_me.HealthPercent < 30 && _me.CurrentTarget.HealthPercent > _me.HealthPercent))
                    {
                        Healing.UseHealthPotion();
                        GiftOfTheNaaru();
                        DivineShield();
                    }

                    if (_me.ManaPercent < 30 && _me.CurrentTarget.HealthPercent > _me.HealthPercent)
                    {
                        Healing.UseManaPotion();
                    }

                    if (_me.HealthPercent < _combatHealPercent || NeedHeal)
                    {
                        Log("Heal.");
                        Heal();
                    }
                }
                else
                {
                    return;
                }
                #endregion

                #region open combat
                if (combatChecks)
                {
                    if (_me.CurrentTarget.IsCasting)
                    {
                        WarStomp();
                        ArcaneTorrent();
                    }

                    Berserking();
                    Bloodrage();

                    PaladinJudgements();
                    if (SpellManager.KnownSpells.ContainsKey("Divine Plea") && _me.ManaPercent < 50)
                    {
                        Log("Mana below 50%.");
                        DivinePlea();
                    }
                }
                else
                {
                    return;
                }
                #endregion

                #region handle adds
                if (combatChecks)
                {
                    _addsList = GetAdds();
                }
                else
                {
                    return;
                }

                if (_addsList.Count > 1)
                {
                    Consecration();
                    if (_me.HealthPercent < 80 && SpellManager.KnownSpells.ContainsKey("Lifeblood") && SpellManager.KnownSpells["Lifeblood"].Cooldown)
                    {
                        SpellManager.CastSpell("Lifeblood");
                        Log("Lifeblood.");
                    }

                    Stoneform();
                    GiftOfTheNaaru();
                }
                #endregion

                #region dps
                if (_me.Level > 40 && _me.PartyMembers.Count == 0 && HasBuffProcced("The Art of War", 0) && combatChecks)
                {
                    Exorcism();
                }

                if (combatChecks)
                {
                    PaladinJudgements();
                    CrusaderStrike();
                }
                else
                {
                    return;
                }

                if (combatChecks)
                {
                    DivineStorm();
                }
                else
                {
                    return;
                }

                if (combatChecks)
                {
                    HammmerOfWrath();
                }
                else
                {
                    return;
                }
                #endregion

            }
            finally
            {
                if (SpellManager.KnownSpells.ContainsKey("Judgement of Justice") && _me.CurrentTarget != null
                    && !_runnerList.Contains(_me.CurrentTarget.Entry) && _me.CurrentTarget.Fleeing)
                {
                    Log("{0}s are runners.  Use Judgement of Justice from now on.");
                    _runnerList.Add(_me.CurrentTarget.Entry);
                }
            }

        }

        /// <summary>
        /// Finds a list of all units in vicinity that are targetting you
        /// </summary>
        private List<WoWUnit> GetAdds()
        {
            List<WoWUnit> mobList = ObjectManager.GetObjectsOfType<WoWUnit>(false);
            var enemyMobList = new List<WoWUnit>();

            foreach (WoWUnit thing in mobList)
            {
                if ((thing.Guid != _me.Guid) &&
                    thing.IsTargetingMe)
                {
                    enemyMobList.Add(thing);
                }
            }

            if (enemyMobList.Count > 1)
            {
                Log("Warning: there are " + enemyMobList.Count + " attackers.");
            }
            return enemyMobList;
        }

        #region paladin logic

        private void PaladinJudgements()
        {
            if (combatChecks)
            {
                // stun before seal of command
                if (SpellManager.KnownSpells.ContainsKey("Hammer of Justice") && _me.Buffs.ContainsKey("Seal of Command"))
                {
                    if (_me.CurrentTarget.CreatureType != WoWCreatureType.Mechanical && SpellManager.KnownSpells.ContainsKey("Repentance") && !SpellManager.KnownSpells["Repentance"].Cooldown)
                        Repentance();
                    else
                        HammerOfJustice();
                }

                if (SpellManager.KnownSpells.ContainsKey("Judgement of Justice") && (_me.CurrentTarget.IsPlayer || _runnerList.Contains(_me.CurrentTarget.Entry)))
                {
                    JudgementOfJustice();
                    return;
                }

                if (SpellManager.KnownSpells.ContainsKey("Judgement of Wisdom") && _me.ManaPercent < 75)
                {
                    JudgementOfWisdom();
                    return;
                }

                if (SpellManager.KnownSpells.ContainsKey("Judgement of Light") && !SpellManager.KnownSpells["Judgement of Light"].Cooldown)
                {
                    JudgementOfLight();
                }
            }

        }

        /// <summary>
        /// Check buffs every 15 seconds between combat
        /// </summary>
        private void PaladinBuffs()
        {
            {
                if (SpellManager.KnownSpells.ContainsKey("Seal of Command"))
                {
                    if (!_me.Buffs.ContainsKey("Seal of Command"))
                    {
                        SealOfCommand("Seal of Command.");
                    }
                }
                else if (_me.Level == 4 && !_me.Buffs.ContainsKey("Seal of Righteousness") && SpellManager.KnownSpells.ContainsKey("Seal of Righteousness"))
                {
                    SpellManager.CastSpellById(21084);
                }
                else if (!_me.Buffs.ContainsKey("Seal of Righteousness") &&
                            SpellManager.KnownSpells.ContainsKey("Seal of Righteousness"))
                {
                    SealOfRighteousness("Seal of Righteousness.");
                }

                // aura
                if (SpellManager.KnownSpells.ContainsKey("Retribution Aura"))
                {
                    if (!_me.Buffs.ContainsKey("Retribution Aura"))
                    {
                        RetributionAura();
                    }
                }
                else if (!_me.Buffs.ContainsKey("Devotion Aura") &&
                         SpellManager.KnownSpells.ContainsKey("Devotion Aura"))
                {
                    DevotionAura();
                }

                if (_me.Level > 3 &&
                !_me.Buffs.ContainsKey("Blessing of Might") &&
                !_me.Buffs.ContainsKey("Greater Blessing of Might") &&
                !_me.Buffs.ContainsKey("Battle Shout") &&
                SpellManager.KnownSpells.ContainsKey("Blessing of Might"))
                {
                    if (_me.GotTarget &&
                        _me.CurrentTarget.Guid == _me.Guid)
                    {
                        _me.ClearTarget();
                    }

                    BlessingOfMight("Blessing of Might.");
                }
            }


            if (SpellManager.KnownSpells.ContainsKey("Seal of Command") && _me.Buffs.ContainsKey("Seal of Command") && _me.Buffs["Seal of Command"].TimeLeft < _needBuffTimespan)
                SealOfCommand("Refresh Seal of Command.");
            else if (_me.Buffs.ContainsKey("Seal of Righteousness") && _me.Buffs["Seal of Righteousness"].TimeLeft < _needBuffTimespan)
                SealOfRighteousness("Refresh Seal of Righteousness.");

            if (SpellManager.KnownSpells.ContainsKey("Blessing of Might") && _me.Buffs.ContainsKey("Blessing of Might") && _me.Buffs["Blessing of Might"].TimeLeft < _needBuffTimespan)
            {
                if (_me.GotTarget &&
                    _me.CurrentTarget.Guid != _me.Guid)
                {
                    _me.ClearTarget();
                }

                BlessingOfMight("Refresh Blessing of Might.");
            }

        }

        #endregion

        #region paladin spells

        /// <summary>
        /// Increases all damage and healing caused by 20% for 20 sec.  Cannot be used within 30 sec 
        /// of being the target of Divine Shield, Divine Protection, or Hand of Protection, or of using Lay on Hands on oneself.
        /// </summary>
        private void AvengingWrath()
        {
            //http://www.wowhead.com/spell=31884
            if (SpellManager.KnownSpells.ContainsKey("Avenging Wrath") && !SpellManager.KnownSpells["Avenging Wrath"].Cooldown && SpellManager.CastSpell("Avenging Wrath"))
            {
                Log("Avenging Wrath.");
            }
        }

        /// <summary>
        /// Gives additional armor to party and raid members within 40 yards. 
        /// </summary>
        private void DevotionAura()
        {
            // http://www.wowhead.com/?spell=465
            if (SpellManager.CastSpell("Devotion Aura"))
            {
                Log("Devotion Aura.");
            }
        }

        /// <summary>
        /// Heals a friendly target.
        /// </summary>
        private static Stopwatch _holyLightTimer;
        private void HolyLight()
        {
            if (_holyLightTimer == null)
                _holyLightTimer = new Stopwatch();

            if (_holyLightTimer.IsRunning && _holyLightTimer.ElapsedMilliseconds < 300)
                return;


            if (!IsPartyMode)
                HealTarget = _me;

            if (HealTarget.HealthPercent > 95)
                return;

            if (HealTarget.HealthPercent < 95 && HealTarget.HealthPercent > 75)
            {
                FlashOfLight();
                return;
            }

            // http://www.wowhead.com/?spell=635
            if (SpellManager.CastSpell("Holy Light", true))
            {
                Log("Holy Light.");

                Thread.Sleep(500);

                while (_me.IsCasting)
                {
                    if (HealTarget.HealthPercent > 85)
                    {
                        KeyboardManager.KeyUpDown(' ');
                        break;
                    }
                    Thread.Sleep(100);
                }

                _holyLightTimer.Reset();
                _holyLightTimer.Start();
            }
        }

        /// <summary>
        /// Fills the Paladin with holy spirit for 30 min, granting each melee attack additional Holy damage. 
        /// Unleashing this Seal's energy will cause extra Holy damage to an enemy.
        /// </summary>
        private void SealOfRighteousness(string msg)
        {
            // http://www.wowhead.com/?spell=21084
            bool castDone = SpellManager.CastSpell("Seal of Righteousness");
            if (castDone)
            {
                Log(msg);
            }
        }

        /// <summary>
        /// Places a Blessing on the friendly target, increasing attack power for 10 min. 
        /// </summary>
        private void BlessingOfMight(string msg)
        {
            // http://www.wowhead.com/?spell=19740
            if (SpellManager.CastSpell("Blessing of Might"))
            {
                Log(msg);
            }
        }

        /// <summary>
        /// Unleashes the energy of a Seal spell to judge an enemy for 20 sec, granting attacks made against the judged enemy a chance of healing the attacker for 2% of their maximum health. 
        /// </summary>
        private void JudgementOfLight()
        {
            // http://www.wowhead.com/?spell=20271
            if (_me.GotTarget && _me.CurrentTarget.Distance < SpellManager.KnownSpells["Judgement of Light"].MaxRange && SpellManager.CastSpell("Judgement of Light"))
            {
                Log("Judgement of Light.");
            }
        }



        /// <summary>
        /// Stuns the target
        /// </summary>
        private void HammerOfJustice()
        {
            if (!SpellManager.KnownSpells.ContainsKey("Hammer of Justice") || SpellManager.KnownSpells["Hammer of Justice"].Cooldown)
                return;

            // http://www.wowhead.com/?spell=853
            if (_me.GotTarget && _me.CurrentTarget.Distance < SpellManager.KnownSpells["Hammer of Justice"].MaxRange && SpellManager.CastSpell("Hammer of Justice"))
            {
                Log("Hammer of Justice.");
            }
        }

        /// <summary>
        /// A targeted party or raid member is protected from all physical attacks for 6 sec, but during that time they cannot attack or use physical abilities.
        /// </summary>
        private void HandOfProtection()
        {
            // http://www.wowhead.com/?spell=1022
            if (SpellManager.CastSpell("Hand of Protection"))
            {
                Log("Hand of Protection.");
            }
        }

        /// <summary>
        /// Protects the paladin from all damage and spells for 12 sec
        /// </summary>
        private void DivineShield()
        {
            if (_me.Buffs.ContainsKey("Forbearance"))
                return;

            if (SpellManager.CastSpell("Divine Shield"))
            {
                Log("Divine Shield.");
            }
            if (SpellManager.CastSpell("Divine Protection"))
            {
                Log("Divine Protection.");
            }
        }

        /// <summary>
        /// Heals a friendly target for an amount equal to the Paladin's maximum health.
        /// </summary>
        private void LayOnHands()
        {
            // http://www.wowhead.com/?spell=633
            if (SpellManager.CastSpell("Lay on Hands"))
            {
                Log("Lay on Hands for " + _me.CurrentTarget.Class + ".");
            }
        }

        /// <summary>
        /// Unleashes the energy of a Seal spell to judge an enemy, giving each attack a chance to restore 2% of the attacker's base mana.
        /// </summary>
        private void JudgementOfWisdom()
        {
            // http://www.wowhead.com/?spell=53408
            if (_me.GotTarget && _me.CurrentTarget.Distance < SpellManager.KnownSpells["Judgement of Wisdom"].MaxRange && SpellManager.CastSpell("Judgement of Wisdom"))
            {
                if (_me.ManaPercent < 75)
                {
                    Log("Mana is " + Math.Floor(_me.ManaPercent) + "% so casting Judgement of Wisdom.");
                }
                else
                {
                    Log("Judgement of Wisdom.");
                }
            }
        }

        /// <summary>
        /// Places a Blessing on the friendly target, restoring mana every 5 seconds for 10 min.
        /// </summary>
        private void BlessingOfWisdom(string msg)
        {
            // http://www.wowhead.com/?spell=19742
            if (SpellManager.CastSpell("Blessing of Wisdom"))
            {
                Log(msg);
            }
        }

        /// <summary>
        /// Taunts the target to attack you.  If the target is not currently targeting you, causes Holy damage.
        /// </summary>
        private void HandOfReckoning()
        {
            // http://www.wowhead.com/?spell=62124
            if (!SpellManager.KnownSpells.ContainsKey("Hand of Reckoning"))
            {
                Log("Hand of Reckoning not known.");
            }

            if (_me.CurrentTarget.IsPlayer)
                return;

            bool castDone = SpellManager.CastSpell("Hand of Reckoning");

            if (castDone)
            {
                Log("Pulling with Hand of Reckoning.");
            }
            else
            {
                Log("Hand of Reckoning failed.");
            }
        }

        /// <summary>
        /// All melee attacks deal additional Holy damage.  When used with attacks or abilities that strike a single target, this additional Holy damage will strike up to 2 additional targets.  Lasts 30 min.
        /// Unleashing this Seal's energy will judge an enemy, instantly causing Holy damage.
        /// </summary>
        private void SealOfCommand(string msg)
        {
            // http://www.wowhead.com/?spell=20375
            if (SpellManager.CastSpell("Seal of Command"))
            {
                Log(msg);
            }
        }

        /// <summary>
        /// Causes Holy damage to any enemy that strikes a party or raid member within 40 yards. 
        /// </summary>
        private void RetributionAura()
        {
            // http://www.wowhead.com/?spell=7294
            if (SpellManager.CastSpell("Retribution Aura"))
            {
                Log("Retribution Aura.");
            }
        }

        /// <summary>
        /// Consecrates the land beneath the Paladin, doing Holy damage over 8 sec to enemies who enter the area.
        /// </summary>
        private void Consecration()
        {
            // http://www.wowhead.com/?spell=26573
            if (SpellManager.CastSpell("Consecration"))
            {
                Log("Consecration.");
            }
        }

        /// <summary>
        /// Causes Holy damage to an enemy target.  If the target is Undead or Demon, it will always critically hit.
        /// </summary>
        private void Exorcism()
        {
            // http://www.wowhead.com/?spell=879
            if (_me.GotTarget && _me.CurrentTarget.Distance < SpellManager.KnownSpells["Exorcism"].MaxRange && SpellManager.CastSpell("Exorcism"))
            {
                Log("Exorcism.");
            }
        }

        /// <summary>
        /// Heals a friendly target.  If the target has the Sacred Shield effect, they heal an additional 100% over 12 sec.
        /// </summary>
        private void FlashOfLight()
        {
            if (_holyLightTimer.IsRunning && _holyLightTimer.ElapsedMilliseconds < 300)
                return;

            if (HealTarget.HealthPercent > 95)
                return;

            // http://www.wowhead.com/?spell=19750
            if (_me.GotTarget && _me.CurrentTarget.Distance < SpellManager.KnownSpells["Flash of Light"].MaxRange && SpellManager.CastSpell("Flash of Light"))
            {
                Log("Flash of Light.");
            }
        }

        /// <summary>
        /// Unleashes the energy of a Seal spell to judge an enemy for 20 sec, preventing them from fleeing and limiting their movement speed. 
        /// </summary>
        private void JudgementOfJustice()
        {
            // http://www.wowhead.com/?spell=53407
            if (_me.GotTarget && _me.CurrentTarget.Distance < SpellManager.KnownSpells["Judgement of Justice"].MaxRange && SpellManager.CastSpell("Judgement of Justice"))
            {
                Log("Judgement of Justice.");
            }
        }

        /// <summary>
        /// Puts the enemy target in a state of meditation, incapacitating them for up to 1 min, and removing the effect of Righteous Vengeance.  
        /// Any damage caused will awaken the target.  Usable against Demons, Dragonkin, Giants, Humanoids and Undead.
        /// </summary>
        private void Repentance()
        {
            // http://www.wowhead.com/spell=20066
            if (_me.CurrentTarget.CreatureType == WoWCreatureType.Mechanical || !SpellManager.KnownSpells.ContainsKey("Repentance") || SpellManager.KnownSpells["Repentance"].Cooldown)
                return;

            // http://www.wowhead.com/?spell=20066
            if (_me.GotTarget && _me.CurrentTarget.Distance < SpellManager.KnownSpells["Repentance"].MaxRange && SpellManager.CastSpell("Repentance"))
            {
                Log("Repentance.");
            }

        }

        /// <summary>
        /// Cleanses a friendly target, removing 1 poison effect, 1 disease effect, and 1 magic effect.
        /// </summary>
        private void Cleanse()
        {
            // http://www.wowhead.com/?spell=4987
            if (SpellManager.CastSpell("Cleanse"))
            {
                Log("Cleanse.");
            }
            else if (SpellManager.CastSpell("Purify"))
            {
                Log("Purify.");
            }
        }

        /// <summary>
        /// Hurls a hammer that strikes an enemy for Holy damage.  Only usable on enemies that have 20% or less health.
        /// </summary>
        private void HammmerOfWrath()
        {
            if (_me.Level < 44) return;

            // http://www.wowhead.com/?spell=24275
            if (_me.CurrentTarget.HealthPercent < 21)
            {
                SpellManager.CastSpell("Hammer of Wrath");
                Log("Hammer of Wrath.");
            }
        }

        /// <summary>
        /// Sends bolts of holy power in all directions, causing AOE Holy damage and stunning all Undead and Demon targets within 10 yds for 3 sec.
        /// </summary>
        private void HolyWrath()
        {
            // http://www.wowhead.com/?spell=2812
        }

        /// <summary>
        /// An instant strike that causes 75% weapon damage. 
        /// </summary>
        private void CrusaderStrike()
        {
            // http://www.wowhead.com/?spell=35395
            if (_me.Level < 50) return;

            if (_me.GotTarget && _me.CurrentTarget.Distance < 6 && SpellManager.CastSpell("Crusader Strike"))
            {
                Log("Crusader Strike.");
            }
        }

        /// <summary>
        /// An instant weapon attack that causes 110% of weapon damage to up to 4 enemies within 8 yards.  The Divine Storm heals up to 3 party or raid members totaling 25% of the damage caused.
        /// </summary>
        private void DivineStorm()
        {
            // http://www.wowhead.com/?spell=53385
            if (_me.Level < 60) return;

            if (_me.GotTarget && SpellManager.CastSpell("Divine Storm"))
            {
                Log("Divine Storm.");
            }
        }

        /// <summary>
        /// Increases the mounted speed by 20% for all party and raid members within 40 yards. 
        /// </summary>
        private void CrusaderAura()
        {
            // http://www.wowhead.com/?spell=32223
        }

        /// <summary>
        /// Fills the Paladin with holy power, causing attacks to apply Holy Vengeance, which deals additional Holy damage over 15 sec.  Holy Vengeance can stack up to 5 times.  Once stacked to 5 times, each of the Paladin's attacks also deals 33% weapon damage as additional Holy damage. 
        /// </summary>
        private void SealOfVengeance()
        {
            // http://www.wowhead.com/?spell=31801
        }

        /// <summary>
        /// Fills the Paladin with holy power, causing attacks to apply Holy Vengeance, which deals additional Holy damage over 15 sec.  Holy Vengeance can stack up to 5 times.  Once stacked to 5 times, each of the Paladin's attacks also deals 33% weapon damage as additional Holy damage. 
        /// </summary>
        private void SealOfCorruption()
        {
            // http://www.wowhead.com/?spell=53736
        }

        /// <summary>
        /// Each time the target takes damage they gain a Sacred Shield, 
        /// absorbing 500 damage and increasing the paladin's chance to 
        /// critically hit with Flash of Light by 50% for up to 6 sec.  
        /// They cannot gain this effect more than once every 6 sec.  Lasts 30 sec.
        /// </summary>
        private void SacredShield()
        {
            // http://www.wowhead.com/?spell=53601
        }

        /// <summary>
        /// You gain 25% of your total mana over 15 sec, but the amount healed by your Flash of Light, Holy Light, and Holy Shock spells is reduced by 50%.
        /// </summary>
        private void DivinePlea()
        {
            // http://www.wowhead.com/?spell=54428
            if (SpellManager.CastSpell("Divine Plea"))
            {
                Log("Divine Plea.");
            }
        }

        #endregion

        #region movement logic

        private static readonly Stopwatch MovementTimer = new Stopwatch();
        private static int _movementDuration;

        #endregion

        #region party logic

        private bool IsPartyMode
        {
            get
            {
                if (_me.PartyMembers.Count > 0 || _me.RaidMembers.Count > 0)
                {
                    return true;
                }
                return false;
            }
        }

        private WoWPlayer HealTarget
        {
            get
            {
                if (Battlegrounds.IsInsideBattleground && _me.HealthPercent < 90)
                {
                    return _me;
                }

                if (IsPartyMode)
                {
                    WoWPlayer healTarget = _me;

                    foreach (WoWPlayer pal in _me.PartyMembers)
                    {
                        if (pal.HealthPercent < _combatHealPercent && pal.InLineOfSight && pal.Distance <= 35)
                        {
                            if (healTarget == null || pal.HealthPercent < healTarget.HealthPercent)
                            {
                                healTarget = pal;
                            }
                        }
                    }

                    return healTarget;
                }

                return _me;
            }

            set
            {

            }
        }

        #endregion

        #region Horde racials

        private static void Berserking()
        {
            if (ObjectManager.Me.Race == WoWRace.Troll &&
                SpellManager.CastSpell("Berserking"))
            {
                Logging.Write("Berserking.");
            }
        }

        // Bloodrage
        private void Bloodrage()
        {
            if (ObjectManager.Me.Race == WoWRace.Orc &&
                SpellManager.CastSpell("Bloodrage"))
            {
                Logging.Write("Bloodrage.");
            }
        }

        // War Stomp
        private void WarStomp()
        {
            if (ObjectManager.Me.Race == WoWRace.Tauren &&
                SpellManager.CastSpell("War Stomp"))
            {
                Logging.Write("War Stomp.");
            }
        }

        // Arcane Torrent
        private void ArcaneTorrent()
        {
            if (ObjectManager.Me.Race == WoWRace.BloodElf &&
                SpellManager.CastSpell("Arcane Torrent"))
            {
                Logging.Write("Arcane Torrent.");
            }
        }

        // Will of the Forsaken 
        private void WillOfTheForsaken()
        {
            if (ObjectManager.Me.Race == WoWRace.Undead &&
                SpellManager.CastSpell("Will of the Forsaken"))
            {
                Logging.Write("Will of the Forsaken.");
            }
        }

        #endregion

        #region Alliance racials

        // Stoneform
        private void Stoneform()
        {
            if (ObjectManager.Me.Race == WoWRace.Dwarf &&
                SpellManager.CastSpell("Stoneform"))
            {
                Logging.Write("Stoneform.");
            }
        }

        // Gift of the Naaru
        private static void GiftOfTheNaaru()
        {
            if (ObjectManager.Me.Race == WoWRace.Draenei && SpellManager.CastSpell("Gift of the Naaru"))
            {
                Logging.Write("Gift of the Naaru.");
            }
        }

        // Every Man for Himself
        private void EveryManForHimself()
        {
            if (ObjectManager.Me.Race == WoWRace.Human &&
                SpellManager.CastSpell("Every Man for Himself"))
            {
                Logging.Write("Every Man for Himself.");
            }
        }

        // Shadowmeld
        private void Shadowmeld()
        {
            if (ObjectManager.Me.Race == WoWRace.NightElf &&
                SpellManager.CastSpell("Shadowmeld"))
            {
                Logging.Write("Shadowmeld.");
            }
        }

        // Escape Artist
        private void EscapeArtist()
        {
            if (ObjectManager.Me.Race == WoWRace.Gnome &&
                SpellManager.CastSpell("Escape Artist"))
            {
                Logging.Write("Escape Artist.");
            }
        }

        #endregion
    }
}

#pragma warning restore