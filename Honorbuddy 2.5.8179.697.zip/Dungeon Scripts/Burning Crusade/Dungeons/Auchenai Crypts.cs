//#define USE_DUNGEONBUDDY_DLL

using System.Collections.Generic;
using Styx;
using Styx.CommonBot;
using Styx.Pathing;
using Styx.WoWInternals.WoWObjects;
using Styx.TreeSharp;
#if USE_DUNGEONBUDDY_DLL
using Bots.DungeonBuddyDll;
using Bots.DungeonBuddyDll.Attributes;
using Bots.DungeonBuddyDll.Helpers;
namespace Bots.DungeonBuddyDll.Dungeon_Scripts.Burning_Crusade
#else
    using Bots.DungeonBuddy.Attributes;
    using Bots.DungeonBuddy.Helpers;
namespace Bots.DungeonBuddy.Dungeon_Scripts.Burning_Crusade
#endif
{
    public class AuchenaiCrypts : Dungeon
    {
        #region Overrides of Dungeon

        public override uint DungeonId { get { return 149; } }

        public override WoWPoint Entrance { get { return new WoWPoint(-3362.34, 5230.694, -101.0485); } }

        public override void WeighTargetsFilter(List<Targeting.TargetPriority> units)
        {
            foreach (var p in units)
            {
                var unit = p.Object.ToUnit();
                if (unit == null) continue;
                if (unit.Entry == StolenSoulId)
                    p.Score += 200;
            }
        }

        #endregion

        private const uint StolenSoulId = 18441;
        private LocalPlayer Me
        {
            get { return StyxWoW.Me; }
        }

        [EncounterHandler(54725, "Draenei Spirit", Mode = CallBehaviorMode.Proximity, BossRange = 30)]
        [EncounterHandler(54698, "Tormented Soulpriest", Mode = CallBehaviorMode.Proximity, BossRange = 30)]
        public Composite QuestPickupHandler()
        {
            WoWUnit unit = null;
            return new PrioritySelector(
                ctx => unit = ctx as WoWUnit,
                new Decorator(
                    ctx => !Me.Combat && !ScriptHelpers.WillPullAggroAtLocation(unit.Location) && unit.QuestGiverStatus == QuestGiverStatus.Available,
                    ScriptHelpers.CreatePickupQuest(() => unit)),
                new Decorator(
                    ctx => !Me.Combat && !ScriptHelpers.WillPullAggroAtLocation(unit.Location) && unit.QuestGiverStatus == QuestGiverStatus.TurnIn,
                    ScriptHelpers.CreateTurninQuest(() => unit)));
        }


        [EncounterHandler(18371, "Shirrak the Dead Watcher")]
        public Composite ShirrakEncounter()
        {
            WoWUnit shirrak = null;
            const uint focusFireId = 18374;
            AddAvoidObject(ctx => true, 12, focusFireId);
            return new PrioritySelector(
                ctx => shirrak = ctx as WoWUnit);
        }

        [EncounterHandler(18373, "Exarch Maladaar")]
        public Composite ExarchMaladaarEncounter()
        {
            const uint exarchMaladaarId = 18373;
            // avoid Soul Scream
            AddAvoidObject(ctx => Me.IsRange() && !Me.IsCasting, 10, o => o.Entry == exarchMaladaarId && o.ToUnit().CurrentTargetGuid != Me.Guid && !o.ToUnit().IsMoving);
            //WoWUnit boss = null;
            return new PrioritySelector(
                //   ctx => boss = ctx as WoWUnit,
                );
        }
    }
}