﻿#region Revision Info

// This file is part of Singular - A community driven Honorbuddy CC
// $Author: raphus $
// $Date: 2011-02-18 13:28:58 +0100 (fr, 18 feb 2011) $
// $HeadURL: http://svn.apocdev.com/singular/trunk/Singular/Settings/MageSettings.cs $
// $LastChangedBy: raphus $
// $LastChangedDate: 2011-02-18 13:28:58 +0100 (fr, 18 feb 2011) $
// $LastChangedRevision: 74 $
// $Revision: 74 $

#endregion

using System.ComponentModel;

using Styx;
using Styx.Helpers;

using DefaultValue = Styx.Helpers.DefaultValueAttribute;

namespace Singular.Settings
{
    internal class MageSettings : Styx.Helpers.Settings
    {
        public MageSettings()
            : base(SingularSettings.SettingsPath + "_Mage.xml")
        {
        }
    }
}