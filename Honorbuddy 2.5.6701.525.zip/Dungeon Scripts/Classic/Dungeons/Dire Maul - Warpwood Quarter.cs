﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Styx;
using Styx.Pathing;
using Styx.WoWInternals;

#if USE_DUNGEONBUDDY_DLL
using Bots.DungeonBuddyDll;
using Bots.DungeonBuddyDll.Attributes;
using Bots.DungeonBuddyDll.Helpers;
namespace Bots.DungeonBuddyDll.Dungeon_Scripts.Classic
#else
    using Bots.DungeonBuddy.Attributes;
    using Bots.DungeonBuddy.Helpers;
    namespace Bots.DungeonBuddy.Dungeon_Scripts.Classic
#endif
{
    public class DireMaulWarpwoodQuarter : Dungeon
    {
        #region Overrides of Dungeon
        public override uint DungeonId
        {
            get { return 34; }
        }

        public override WoWPoint Entrance { get { return new WoWPoint(-3817.948, 1250.378, 160.2729); } }

        readonly WoWPoint[] _poolExitLocs = new[]
                                       {
                                           new WoWPoint (-9.936749, -445.6717, -58.62322),
                                           new WoWPoint (-33.14164, -447.9058, -58.61671),
                                           new WoWPoint (-37.1635, -409.2715, -58.61413),
                                           new WoWPoint (-9.161582, -408.6013, -58.61409)
                                       };

        WoWPoint _poolLoc = new WoWPoint(-14.4789, -427.714, -59.95045);
        public override MoveResult MoveTo(WoWPoint location)
        {
            // jump out of the pool.
            if (StyxWoW.Me.Location.DistanceSqr(_poolLoc) < 40 * 40)
            {
                if (StyxWoW.Me.Z < -59f && location.Z > -59 && !StyxWoW.Me.MovementInfo.IsAscending)
                {
                    var bestExit = _poolExitLocs.OrderBy(l => l.DistanceSqr(location)).FirstOrDefault();
                    Navigator.MoveTo(bestExit);
                    if (bestExit.DistanceSqr(StyxWoW.Me.Location) < 8 * 8)

                        WoWMovement.Move(WoWMovement.MovementDirection.JumpAscend);
                    return MoveResult.Moved;
                }
                else if (StyxWoW.Me.MovementInfo.IsAscending)
                    WoWMovement.MoveStop(WoWMovement.MovementDirection.JumpAscend);
            }
            return base.MoveTo(location);
        }
        #endregion
    }
}
