﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CommonBehaviors.Actions;
using Styx;
using Styx.CommonBot;
using Styx.Pathing;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using Styx.TreeSharp;
using Action = Styx.TreeSharp.Action;

#if USE_DUNGEONBUDDY_DLL
using Bots.DungeonBuddyDll;
using Bots.DungeonBuddyDll.Profiles;
using Bots.DungeonBuddyDll.Attributes;
using Bots.DungeonBuddyDll.Helpers;
namespace Bots.DungeonBuddyDll.Dungeon_Scripts.Classic
#else
    using Bots.DungeonBuddy.Profiles;
    using Bots.DungeonBuddy.Attributes;
    using Bots.DungeonBuddy.Helpers;
namespace Bots.DungeonBuddy.Dungeon_Scripts.Classic
#endif
{
    public class Uldaman : Dungeon
    {
        #region Overrides of Dungeon
        public override uint DungeonId
        {
            get { return 22; }
        }

        public override WoWPoint Entrance { get { return new WoWPoint(-6061.87, -2956.325, 209.7706); } }

        public override void IncludeTargetsFilter(List<WoWObject> incomingunits, HashSet<WoWObject> outgoingunits)
        {
            foreach (var unit in incomingunits.Select(obj => obj.ToUnit()))
            {
                switch (unit.Entry)
                {
                    case 3560: // healing totem
                    case 6017: // Lava sprout totem
                        outgoingunits.Add(unit);
                        break;
                }
            }
        }

        public override void WeighTargetsFilter(List<Targeting.TargetPriority> units)
        {
            foreach (var p in units)
            {
                WoWUnit unit = p.Object.ToUnit();
                switch (unit.Entry)
                {
                    case 3560: // healing totem
                    case 6017: // Lava sprout totem
                        p.Score += 100;
                        break;
                }

            }
        }

        public override bool IsComplete
        {
            get
            {
                if (BossManager.CurrentBoss == null)
                {
                    if (_lootedAncientTeasure) return true;
                    var chest = AncientTreasure;
                    if (chest == null || !chest.CanLoot)
                        return true;
                }
                return false;
            }
        }

        // reset _lootedAncientTreasure to default value (false)
        public override void OnEnter() { _lootedAncientTeasure = false; }
        #endregion

        [ObjectHandler(124371, "Keystone")]
        public Composite KeystoneObject()
        {
            return new Decorator(ctx => !StyxWoW.Me.Combat && ((WoWGameObject)ctx).Locked == false,
                ScriptHelpers.CreateInteractWithObject(124371));
        }

        [ObjectHandler(130511, "Altar of The Keepers")]
        public Composite AltarofTheKeepers()
        {
            WoWGameObject door = null;
            return new PrioritySelector(ctx =>
                {
                    door = HallOfCraftersDoor; // cache the door object.
                    return ctx;
                },
                 new Decorator(ctx => !StyxWoW.Me.Combat && door != null && door.State != WoWGameObjectState.Active,
                    ScriptHelpers.CreateInteractWithObject(130511, 12, false)));
        }

        [EncounterHandler(2748, "Archaeda", Mode = CallBehaviorMode.CurrentBoss)]
        public Composite ArchaedaHandler()
        {
            const uint altarofTheArchaedas = 133234;
            return new PrioritySelector(
                new Decorator<WoWUnit>(boss => boss.HasAura("Freeze Anim") && boss.DistanceSqr <= 20 * 20,
                    ScriptHelpers.CreateInteractWithObject(altarofTheArchaedas, 12))
                );
        }

        private bool _lootedAncientTeasure;

        [ObjectHandler(141979, "Ancient Treasure")]
        public Composite AncientTreasureHandler()
        {
            return new Decorator<WoWGameObject>(chest => BossManager.CurrentBoss == null && chest.CanLoot && !_lootedAncientTeasure,
                new Sequence(
                    ScriptHelpers.CreateInteractWithObjectContinue(141979, 4),
                    new Action(ctx => _lootedAncientTeasure = true)));
        }


        WoWGameObject HallOfCraftersDoor
        {
            get { return ObjectManager.GetObjectsOfType<WoWGameObject>().FirstOrDefault(o => o.Entry == 124367); }
        }

        WoWGameObject AncientTreasure
        {
            get { return ObjectManager.GetObjectsOfType<WoWGameObject>().FirstOrDefault(o => o.Entry == 141979); }
        }

    }
}
