﻿//#define USE_DUNGEONBUDDY_DLL

using System;
using System.Collections.Generic;
using System.Linq;
using CommonBehaviors.Actions;
using MainDev.RemoteASM.Handlers;
using Styx;
using Styx.Common.Helpers;
using Styx.CommonBot;
using Styx.CommonBot.Frames;
using Styx.Helpers;
using Styx.Patchables;
using Styx.Pathing;
using Styx.TreeSharp;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using Styx.WoWInternals.World;
using Action = Styx.TreeSharp.Action;

#if USE_DUNGEONBUDDY_DLL
using Bots.DungeonBuddyDll;
using Bots.DungeonBuddyDll.Profiles;
using Bots.DungeonBuddyDll.Attributes;
using Bots.DungeonBuddyDll.Helpers;

namespace Bots.DungeonBuddyDll.Dungeon_Scripts.Mists_of_Pandaria
#else
    using Bots.DungeonBuddy.Profiles;
    using Bots.DungeonBuddy.Attributes;
    using Bots.DungeonBuddy.Helpers;
namespace Bots.DungeonBuddy.Dungeon_Scripts.Mists_of_Pandaria
#endif
{
    internal class TheVaultOfMysteries : Dungeon
    {
        #region Overrides of Dungeon

        public override uint DungeonId
        {
            get { return 528; }  

        }

        public override WoWPoint Entrance
        {
            get { return new WoWPoint(3978.82, 1115.574, 497.136); }
        }

        public override void RemoveTargetsFilter(List<WoWObject> units)
        {
            units.RemoveAll(
                ret =>
                {
                    var unit = ret.ToUnit();
                    if (unit != null)
                    {
                    }
                    return false;
                });
        }

        public override void IncludeTargetsFilter(List<WoWObject> incomingunits, HashSet<WoWObject> outgoingunits)
        {
            foreach (var obj in incomingunits)
            {
                var unit = obj as WoWUnit;
                if (unit != null)
                {
                }
            }
        }

        public override void WeighTargetsFilter(List<Targeting.TargetPriority> units)
        {
            foreach (var priority in units)
            {
                var unit = priority.Object as WoWUnit;
                if (unit != null)
                {
                }
            }
        }

        #endregion

        private static LocalPlayer Me
        {
            get { return StyxWoW.Me; }
        }

        [EncounterHandler(0)]
        public Composite RootEncounter()
        {
            return new PrioritySelector();
        }

        // 1st boss
        // var roomCenterLoc = new WoWPoint(4227.072, 1595.776, 438.8339); // radius 31..

        // 2nd boss
        const int EnergyCascadeId = 122199; // Avoid this missile, does 5 yard aoe damge at impact location.
        const uint EnergyPlatformId = 213526; // if this state is 'Active' you will fall down and die..
        private const uint EnergyChargeId = 60913; // kill these before they leave the Energy Vortext.
        const uint EmpyrealFocusId = 60776; // kill these in stage 3.
        private const int PhaseShiftedId = 118921; // Elegon is immune to damage.
        // var roomCenterLoc = new WoWPoint(4023.042, 1907.786, 358.7884); // inner radius 46. outer radius 63
        
        [EncounterHandler(60410, "Elegon")]
        public Composite ElegonEncounter()
        {
            return new PrioritySelector();
        }


        // 3rd boss 
        //new WoWPoint (3874.398, 1549.394, 362.1991); // radius 50.

    }
}