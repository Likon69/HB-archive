﻿//#define USE_DUNGEONBUDDY_DLL

using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Media;
using CommonBehaviors.Actions;
using MainDev.RemoteASM.Handlers;
using Styx;
using Styx.Common.Helpers;
using Styx.CommonBot;
using Styx.CommonBot.Frames;
using Styx.Helpers;
using Styx.Patchables;
using Styx.Pathing;
using Styx.TreeSharp;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using Styx.WoWInternals.World;
using Action = Styx.TreeSharp.Action;

#if USE_DUNGEONBUDDY_DLL
using Bots.DungeonBuddyDll;
using Bots.DungeonBuddyDll.Profiles;
using Bots.DungeonBuddyDll.Attributes;
using Bots.DungeonBuddyDll.Helpers;

namespace Bots.DungeonBuddyDll.Dungeon_Scripts.Mists_of_Pandaria
#else
    using Bots.DungeonBuddy.Profiles;
    using Bots.DungeonBuddy.Attributes;
    using Bots.DungeonBuddy.Helpers;
namespace Bots.DungeonBuddy.Dungeon_Scripts.Mists_of_Pandaria
#endif
{
    internal class GuardiansOfMogushan : Dungeon
    {
        #region Overrides of Dungeon

        public override uint DungeonId
        {
            get { return 527; }  

        }

        public override WoWPoint Entrance
        {
            get { return new WoWPoint(3978.82, 1115.574, 497.136); }
        }

        public override void RemoveTargetsFilter(List<WoWObject> units)
        {
            units.RemoveAll(
                ret =>
                {
                    var unit = ret.ToUnit();
                    if (unit != null)
                    {
                    }
                    return false;
                });
        }

        public override void IncludeTargetsFilter(List<WoWObject> incomingunits, HashSet<WoWObject> outgoingunits)
        {
            foreach (var obj in incomingunits)
            {
                var unit = obj as WoWUnit;
                if (unit != null)
                {
                }
            }
        }

        public override void WeighTargetsFilter(List<Targeting.TargetPriority> units)
        {
            foreach (var priority in units)
            {
                var unit = priority.Object as WoWUnit;
                if (unit != null)
                {
                }
            }
        }

        public override void OnEnter()
        {
            if(Me.IsTank())
            {
                Logger.Write(Colors.Red, "{0} does support tanking", Name);
                Lua.DoString("LeaveParty()");
            }
        }

        #endregion

        private static LocalPlayer Me
        {
            get { return StyxWoW.Me; }
        }

        [EncounterHandler(0)]
        public Composite RootEncounter()
        {
            return new PrioritySelector(
                
                );
        }

        private const int AmethystPetrificationId = 116060;
        private const int JadePetrificationId = 116008;
        private const int CobaltPetrificationId = 115861;
        private const int JaderPetrificationId = 116038;
        private const uint JasperGuardianId = 59915;
        private const uint JadeGuardianId = 60043;
        private const uint AmethystGuardianId = 60047;
        private const uint CoboltGuardianId = 60051;

        [EncounterHandler(59915, "Jasper Guardian")]
        [EncounterHandler(60043, "Jade Guardian")]
        [EncounterHandler(60047, "Amethyst Guardian")]
        [EncounterHandler(60051, "Cobalt Guardian")]
        public Composite TheStoneGuardEncounter()
        {
            WoWUnit boss = null;
            return new PrioritySelector(ctx => boss = ctx as WoWUnit);
        }

        // Wild fire. drop it out of group debuf is on you. avoid it on ground.
        // Lightning Charge. moves in a straight line, avoid it.
        // Run from group if you have the Arcane explosion debuf.
        [EncounterHandler(60009, "Feng the Accursed")]
        public Composite FengTheAccursedEncounter()
        {
            var roomCenterLoc = new WoWPoint(4041.803, 1341.639, 466.3051);
            WoWUnit boss = null;
            return new PrioritySelector(ctx => boss = ctx as WoWUnit);
        }
        // Test explosives, moves in staight line and and should be avoided 
        // run from NPC that fixates on you

        [EncounterHandler(60143, "Gara'jal the Spiritbinder")]
        public Composite GarajaltheSpiritbinderEncounter()
        {
            
            WoWUnit boss = null;
            return new PrioritySelector(ctx => boss = ctx as WoWUnit);
        }
    }
}