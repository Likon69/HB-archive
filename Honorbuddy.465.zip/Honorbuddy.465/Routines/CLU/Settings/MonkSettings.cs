﻿#region Revision info
/*
 * $Author: clutwopointzero@gmail.com $
 * $Date: 2012-09-14 07:56:17 +0200 (vr, 14 sep 2012) $
 * $ID$
 * $Revision: 271 $
 * $URL: http://clu-for-honorbuddy.googlecode.com/svn/trunk/CLU/CLU/Settings/MonkSettings.cs $
 * $LastChangedBy: clutwopointzero@gmail.com $
 * $ChangesMade$
 */
#endregion

// This file was part of Singular - A community driven Honorbuddy CC

using System.ComponentModel;
using Styx.Helpers;
using CLU.Base;
using DefaultValue = Styx.Helpers.DefaultValueAttribute;


namespace CLU.Settings
{

    internal class MonkSettings : Styx.Helpers.Settings
    {
        public MonkSettings()
        : base(CLUSettings.SettingsPath + "_Monk.xml")
        {
        }

        #region Common

        [Setting]
        [DefaultValue(MonkLegacy.Emperor)]
        [Category("Common")]
        [DisplayName("Monk Legacy Selector")]
        [Description("Choose a Monk Legacy. This is on applicable to solo play (ie: not in party or raid.)")]
        public MonkLegacy LegacySelection
        {
            get;
            set;
        }

        #endregion
    }
}