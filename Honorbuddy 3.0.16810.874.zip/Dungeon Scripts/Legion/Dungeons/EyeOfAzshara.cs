﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Numerics;
using System.Threading.Tasks;
using Bots.DungeonBuddy.Attributes;
using Bots.DungeonBuddy.Enums;
using Bots.DungeonBuddy.Helpers;
using Buddy.Coroutines;
using Styx;
using Styx.Common;
using Styx.CommonBot;
using Styx.CommonBot.Coroutines;
using Styx.CommonBot.POI;
using Styx.CommonBot.Routines;
using Styx.Helpers;
using Styx.Pathing;
using Styx.Pathing.Avoidance;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;

// ReSharper disable CheckNamespace

namespace Bots.DungeonBuddy.DungeonScripts.Legion
// ReSharper restore CheckNamespace
{
    #region Normal Difficulty

    public class EyeOfAzshara : Dungeon
    {
        #region Overrides of Dungeon

        public override uint DungeonId => 1174;

        public override Vector3 Entrance
        {
            get
            {
                throw new NotImplementedException();
            }
        }

        public override Vector3 ExitLocation => new Vector3(-3928.471f, 4549.58f, 88.92654f);

        public override void RemoveTargetsFilter(List<WoWObject> units)
        {
            units.RemoveAll(
                ret =>
                {
                    var unit = ret as WoWUnit;
                    if (unit == null)
                        return false;

                    if (unit.Entry == MobId_RestlessTides && !unit.Combat)
                        return true;

                    return false;
                });
        }

        public override void IncludeTargetsFilter(List<WoWObject> incomingunits, HashSet<WoWObject> outgoingunits)
        {
            foreach (var obj in incomingunits)
            {
                var unit = obj as WoWUnit;
                if (unit != null)
                {
                }
            }
        }


        public override void WeighTargetsFilter(List<Targeting.TargetPriority> units)
        {
            var isDps = Me.IsDps;
            foreach (var priority in units)
            {
                var unit = priority.Object as WoWUnit;
                if (unit != null)
                {
                    switch (unit.Entry)
                    {
                        case MobId_BlazingHydraSpawn:
                        case MobId_HatecoilWrangler:
                            if (isDps)
                                priority.Score += 5500;
                            break;

                        case MobId_WanderingShellback:
                            if (isDps)
                                priority.Score += unit.HasAura("Spiked Carapace") ? -6000 : 6000;
                            break;

                        case MobId_HatecoilStormweaver:
                            if (unit.HasAura("Storm"))
                                priority.Score -= 4000;
                            break;

                        case MobId_SaltseaGlobule:
                            // We only AOE these down..
                            if (Me.IsDps || (Me.IsTank && unit.Aggro))
                                priority.Score -= 4000;
                            break;

                    }
                }
            }
        }

        public override void OnEnter()
        {
            var displayPugGroupWarning = DungeonBuddySettings.Instance.PartyMode == PartyMode.Off ||
                (DungeonBuddySettings.Instance.PartyMode == PartyMode.Leader &&
                DungeonBuddySettings.Instance.PartyMembers.Count(s => !string.IsNullOrWhiteSpace(s)) < 4);

            if (displayPugGroupWarning)
            {
                Alert.Show(
                    "Dungeon not tested in PUGs",
                    $"{Name} dungeon has not been tested in PUGs so it's very important to not leave toon unattended",
                    15);
            }
        }

        public override async Task<bool> HandleMovement(MoveToParameters moveToParameters)
        {
            var destination = moveToParameters.Location;
            if (ScriptHelpers.IsViable(_wrathOfAzshara) && _wrathOfAzshara.IsAlive && destination.DistanceSquared(_wrathOfAzshara.Location) < 3 * 3)
            {
                var moveTo = WoWMathHelper.CalculatePointFrom(Me.Location, _wrathOfAzshara.Location, 20);
                return (await CommonCoroutines.MoveTo(new MoveToParameters(moveTo) {DistanceTolerance = 6}, _wrathOfAzshara.SafeName)).IsSuccessful();
            }
            return false;
        }

        #endregion

        #region Root

        private static LocalPlayer Me => StyxWoW.Me;
        private const int SpellMissileId_LightningStrikes = 192796;
        private const int SpellMissileId_LightningStrikes2 = 192741;

        public override DungeonPathForkInfo[] PathForks { get; } = {
            // Alt path to Lady Hatecoil if killed 3rd.
            new DungeonPathForkInfo(
                rightSideDivider: new Vector3(-3315.898f, 3968.477f, 1.698608f),
                rightSideFromEntranceMoveTo:  new Vector3(-3268.874f, 4003.54f, 6.949371f),
                rightSideTowardsEntranceMoveTo: new Vector3(-3360.089f, 3947.332f, 3.380463f),
                leftSideDivider:  new Vector3(-3578.035f, 4687.903f, 4.306763f),
                leftSideFromEntranceMoveTo: new Vector3(-3546.989f, 4715.622f, 3.084686f),
                leftSideTowardsEntranceMoveTo: new Vector3(-3622.467f, 4662.232f, 9.072479f),
                shouldTakeRightSide: () => !ScriptHelpers.IsBossAlive("King Deepbeard"),
                shouldTakeForkAdditionalCondition: moveto => ScriptHelpers.IsBossAlive("Lady Hatecoil") 
                    && !ScriptHelpers.IsBossAlive("Serpentrix") 
                    && !ScriptHelpers.IsBossAlive("King Deepbeard") 
                    && moveto.Y > 4631
                    && Me.Location.DistanceSquared(moveto) > 200 * 200),

            // path to Serpentrix if only one of Lady Hatecoil or King Deepbeard are dead
            new DungeonPathForkInfo(
                rightSideDivider: new Vector3(-3315.898f, 3968.477f, 1.698608f),
                rightSideFromEntranceMoveTo: new Vector3(-3312.039f, 3963.418f, 1.487915f),
                rightSideTowardsEntranceMoveTo: new Vector3(-3476.725f, 4010.11f, 4.319092f),
                leftSideDivider:  new Vector3(-3427.855f, 4713.483f, 5.391418f),
                leftSideFromEntranceMoveTo: new Vector3(-3377.185f, 4684.423f, 1.543091f),
                leftSideTowardsEntranceMoveTo: new Vector3(-3476.659f, 4736.866f, 2.763794f),
                shouldTakeRightSide: () => !ScriptHelpers.IsBossAlive("King Deepbeard"),
                shouldTakeForkAdditionalCondition: moveto => ScriptHelpers.IsBossAlive("Serpentrix")
                    && ScriptHelpers.IsBossAlive("Lady Hatecoil") != ScriptHelpers.IsBossAlive("King Deepbeard")
                    && moveto.X > -3340.256
                    && Me.Location.DistanceSquared(moveto) > 200 * 200),

            // path to King Deepbeard if killed 3rd
            new DungeonPathForkInfo(
                rightSideDivider: new Vector3(-3762.828f, 4274.876f, 19.80719f),
                rightSideFromEntranceMoveTo:  new Vector3(-3745.103f, 4221.287f, 24.2348f),
                rightSideTowardsEntranceMoveTo: new Vector3(-3776.015f, 4317.544f, 29.21558f),
                leftSideDivider:  new Vector3(-3351.749f, 4558.417f, 0f),
                leftSideFromEntranceMoveTo:  new Vector3(-3326.624f, 4522.796f, 1.272705f),
                leftSideTowardsEntranceMoveTo: new Vector3(-3373.815f, 4616.666f, 1.577393f),
                shouldTakeRightSide: () => ScriptHelpers.IsBossAlive("Serpentrix"),
                shouldTakeForkAdditionalCondition: moveto => ScriptHelpers.IsBossAlive("King Deepbeard")
                    && !ScriptHelpers.IsBossAlive("Lady Hatecoil") && !ScriptHelpers.IsBossAlive("Serpentrix")
                    && moveto.X < -3459.652
                    && Me.Location.DistanceSquared(moveto) > 200 * 200),
        };

        [EncounterHandler(0, "Root Handler")]
        public Func<WoWUnit, Task<bool>> RootBehavior()
        {
            //AddAvoidLocation(() => true, 2, missile => missile.ImpactPosition,
            //    () =>
            //        WoWMissile.InFlightMissiles.Where(
            //            m =>
            //                m.SpellId == SpellMissileId_LightningStrikes));


            //AddAvoidLocation(() => true, 4, missile => missile.ImpactPosition,
            //    () =>
            //        WoWMissile.InFlightMissiles.Where(
            //            m =>
            //                m.SpellId == SpellMissileId_LightningStrikes2));

            return async npc =>
            {
                return false;
            };
        }

        #endregion


        #region Warlord Parjesh

        #region Trash

        private const int SpellId_ThunderingStomp = 195129;
        private const int SpellId_LightningBlast = 195108;
        private const int SpellId_Storm = 196870;
        private const int SpellId_RejuvenatingWaters = 195046;
        private const int SpellId_Restoration = 197502;
        private const int SpellId_BellowingRoar = 192135;
        private const int SpellId_ImpalingSpear = 191946;

        private const uint MobId_HatecoilWrangler = 100216;
        private const uint MobId_WanderingShellback = 91785;
        private const uint MobId_HatecoilCrusher = 91782;
        private const uint MobId_HatecoilStormweaver = 91783;
        private const uint MobId_HatecoilOracle = 95861;
        private const uint MobId_HatecoilShellbreaker = 97264;
        private const uint MobId_HatecoilCrestrider = 97269;
        private const uint MobId_WarlordParjesh = 91784;

        private const uint AreaTriggerId_RejuvenatingWaters = 9878;
        private const uint AreaTriggerId_CrashingWave = 9580;

        [EncounterHandler((int)MobId_HatecoilOracle, "Hatecoil Oracle")]
        public Func<WoWUnit, Task<bool>> HatecoilOracleBehavior()
        {
            AddAvoidObject<WoWAreaTrigger>(() => Me.IsTank, a => 12,
                a =>
                    a.Entry == AreaTriggerId_RejuvenatingWaters &&
                    Targeting.Instance.TargetList.Any(t => t.Location.DistanceSquared(a.Location) < 5 * 5));

            return async npc => await ScriptHelpers.InterruptCast(npc, SpellId_RejuvenatingWaters);
        }


        [EncounterHandler((int)MobId_HatecoilCrusher, "Hatecoil Crusher")]
        public Func<WoWUnit, Task<bool>> HatecoilCrusherBehavior()
        {
            return async npc => await ScriptHelpers.InterruptCast(npc, SpellId_ThunderingStomp);
        }

        [EncounterHandler((int)MobId_HatecoilStormweaver, "Hatecoil Stormweaver")]
        public Func<WoWUnit, Task<bool>> HatecoilStormweaverBehavior()
        {
            AddAvoidObject<WoWUnit>(() => true, 10, u => u.Entry == MobId_HatecoilStormweaver && u.HasAura("Storm"));

            return async npc => await ScriptHelpers.InterruptCast(npc, SpellId_LightningBlast, SpellId_Storm);
        }

        [EncounterHandler((int)MobId_HatecoilShellbreaker, "Hatecoil Shellbreaker")]
        public Func<WoWUnit, Task<bool>> HatecoilShellbreakerBehavior()
        {
            return async npc => await ScriptHelpers.InterruptCast(npc, SpellId_BellowingRoar);
        }

        [EncounterHandler((int)MobId_HatecoilCrestrider, "Hatecoil Crestrider")]
        public Func<WoWUnit, Task<bool>> HatecoilCrestriderBehavior()
        {
            return async npc => await ScriptHelpers.InterruptCast(npc, SpellId_Restoration);
        }


        [LocationHandler(-3825.905f, 4486.231f, 57.50399f, 30, "Trash Pull Before Warlord Parjesh")]
        public Func<Vector3, Task<bool>> TrashPullBeforeWarlordParjesh()
        {
            var trashLoc = new Vector3(-3804.395f, 4472.23f, 54.96346f);

            return async loc =>
            {
                var trash = ScriptHelpers.GetUnfriendlyNpsAtLocation(trashLoc, 10).FirstOrDefault();
                return await ScriptHelpers.PullNpcToLocation(() => trash != null, trash, loc, 5000);
            };
        }


        [LocationHandler(-3770.406f, 4459.95f, 44.89996f, 30, "2nd Dangerous Trash Pull Before Warlord Parjesh")]
        public Func<Vector3, Task<bool>> SecondTrashPullBeforeWarlordParjesh()
        {
            var trashLoc = new Vector3(-3756.955f, 4431.997f, 42.31681f);

            return async loc =>
            {
                var trash = ScriptHelpers.GetUnfriendlyNpsAtLocation(trashLoc, 10).FirstOrDefault();
                return await ScriptHelpers.PullNpcToLocation(() => trash != null, trash, loc, 5000);
            };
        }


        #endregion



        [EncounterHandler((int)MobId_WarlordParjesh, "Warlord Parjesh")]
        public Func<WoWUnit, Task<bool>> WarlordParjeshBehavior()
        {
            WoWUnit warlordParjesh = null;
            WoWUnit impaleTarget = null;

            AddAvoidObject<WoWAreaTrigger>(() => true, a => 5, a => a.Entry == AreaTriggerId_CrashingWave, a => a.Location.RayCast(a.Rotation, 4));

            // avoid the path that impaling spear will travel to its target
            AddAvoidLine(() => warlordParjesh != null && warlordParjesh.IsValid &&
                               warlordParjesh.CastingSpellId == SpellId_ImpalingSpear &&
                               warlordParjesh.CurrentTargetGuid != Me.Guid, () => 6, () => warlordParjesh.Location,
                () => warlordParjesh.CurrentTarget.Location);

            Func<bool> findImpaleTarget =
                () =>
                    warlordParjesh != null && warlordParjesh.IsValid &&
                    warlordParjesh.CastingSpellId == SpellId_ImpalingSpear &&
                    warlordParjesh.CurrentTargetGuid == Me.Guid;

            return async boss =>
            {
                warlordParjesh = boss;
                
                if (findImpaleTarget())
                {
                    impaleTarget =
                        Targeting.Instance.TargetList.FirstOrDefault(u => u.Entry == MobId_HatecoilCrestrider) ??
                        Targeting.Instance.TargetList.FirstOrDefault(u => u.Entry == MobId_HatecoilShellbreaker);
                    if (impaleTarget != null)
                    {
                        var moveTo = WoWMathHelper.CalculatePointFrom(boss.Location, impaleTarget.Location, -4);
                        return
                            await
                                ScriptHelpers.StayAtLocationWhile(findImpaleTarget, moveTo, "Impaling Spear MoveTo", 1);
                    }

                }
                return false;
            };
        }

        #endregion

        #region Lady Hatecoil

        #region Trash

        private const uint MobId_HatecoilArcanist = 97171;

        private Vector3[] _arcanisLocations = 
        {
            new Vector3(-3641.099f, 4631.725f, 11.54732f),
            new Vector3(-3641.099f, 4631.725f, 11.54732f), 
        };

        private const uint MobId_RestlessTides = 97173;

        // Arcanist

        #endregion

        private const uint MobId_LadyHatecoil = 91789;

        [EncounterHandler(MobId_LadyHatecoil, "Lady Hatecoil", Mode = CallBehaviorMode.CurrentBoss )]
        public Func<WoWUnit, Task<bool>> LadyHatecoilStartHandler()
        {
            return async boss =>
            {
                if (!Me.IsTank || boss == null || !Targeting.Instance.IsEmpty() || BotPoi.Current.Type != PoiType.None)
                    return false;

                if (!boss.HasAura("Arcane Fortification"))
                    return false;

                var arcanist =
                    ObjectManager.GetObjectsOfType<WoWUnit>()
                        .Where(u => u.Entry == MobId_HatecoilArcanist && u.IsAlive)
                        .OrderBy(u => u.DistanceSqr)
                        .FirstOrDefault();

                if (arcanist == null)
                    return false;

                BotPoi.Current = new BotPoi(arcanist.Location, PoiType.Hotspot);
                return true;
            };
        }

        private const int SpellId_FocusedLightning = 193611;
        private const int SpellId_StaticNova = 193597;
        private const uint GameObjectId_SandDune = 244690;
        private const uint MobId_SaltseaGlobule = 98293;

        [EncounterHandler(MobId_LadyHatecoil, "Lady Hatecoil")]
        public Func<WoWUnit, Task<bool>> LadyHatecoilHandler()
        {
            WoWUnit ladyHatecoil = null;
            var encounterCenter = new Vector3(-3444.524f, 4591.971f, 0.2291832f);

            AddAvoidObject<WoWObject>(
                () => ScriptHelpers.IsViable(ladyHatecoil) && ladyHatecoil.CastingSpellId == SpellId_FocusedLightning, 
                () => encounterCenter,
                30,
                6,
                obj => (obj is WoWGameObject && obj.Entry == GameObjectId_SandDune) || (obj is WoWPlayer && !obj.IsMe));

            float curseRange = 30;
            float curseArc = 30;

            Func<Vector3, float, bool> willGetHitByCurse =
                (loc, rotation) =>
                    loc.DistanceSquared(Me.Location) < curseRange * curseRange &&
                    WoWMathHelper.IsFacing(Me.Location, rotation, loc, WoWMathHelper.DegreesToRadians(curseArc));

            // Commented out because it just ends up players to run around too much.. We just need to rely on players to face away from us (handled below)
            // AddAvoidUnitCone(() => true, 0, curseRange, curseArc, unit => unit.IsPlayer && !unit.IsMe && unit.HasAura("Curse of the Witch"));

            Func<float?> findSafeCurseExpireDirection = () =>
            {
                var globuleRotation =
                    (from globule in
                        ObjectManager.GetObjectsOfType<WoWUnit>()
                            .Where(u => u.Entry == MobId_SaltseaGlobule)
                            .OrderBy(u => u.DistanceSqr)
                        let rotationVector = Me.Location.GetDirectionTo(globule.Location)
                        let rotation = (float?)Math.Atan2(rotationVector.Y, rotationVector.X)
                        where
                            globule.Location.DistanceSquared(Me.Location) < curseRange * curseRange &&
                            !Me.PartyMembers.Any(p => willGetHitByCurse(p.Location, rotation.Value))
                        select rotation).FirstOrDefault();


                if (globuleRotation.HasValue)
                    return globuleRotation;

                var pix2 = Math.PI * 2;
                for (int step = 0; step < 20; step++)
                {
                    var rotation = (float)(step * pix2 / 20f);
                    if (!Me.PartyMembers.Any(p => willGetHitByCurse(p.Location, rotation)))
                        return rotation;
                }
                return null;
            };

            return async boss =>
            {
                ladyHatecoil = boss;

                if (boss.CastingSpellId == SpellId_StaticNova)
                {
                    var nearbySandDune =
                        ObjectManager.GetObjectsOfType<WoWGameObject>()
                            .Where(u => u.Entry == GameObjectId_SandDune)
                            .OrderBy(u => u.DistanceSqr)
                            .FirstOrDefault();

                    if (await ScriptHelpers.StayAtLocationWhile(
                        () => ScriptHelpers.IsViable(nearbySandDune) && ScriptHelpers.IsViable(boss) && boss.CastingSpellId == SpellId_StaticNova,
                            nearbySandDune.Location, "Sand Dune", 1))
                    {
                        return true;
                    }
                }

                var curse = Me.GetAuraByName("Curse of the Witch");
                if (curse != null && curse.TimeLeft < TimeSpan.FromSeconds(1) && Me.PartyMembers.Any(p => willGetHitByCurse(p.Location, Me.Rotation)))
                {
                    var rotation = findSafeCurseExpireDirection();
                    if (rotation.HasValue)
                    {
                        Me.SetFacing(rotation.Value);
                        await Coroutine.Wait(2000, () => !Me.HasAura("Curse of the Witch"));
                        return true;
                    }
                }

                if (await ScriptHelpers.DispelGroup("Static Nova", ScriptHelpers.PartyDispelType.Magic))
                    return true;

                return await ScriptHelpers.StayAtLocationWhile(() => ScriptHelpers.IsViable(boss) && boss.Combat, encounterCenter, boss.SafeName, 40);
            };
        }

        #endregion

        #region Serpentrix

        #region Trash

        private const uint MobId_StormwakeHydra = 91792;
        private const int MissileSpellId_ChaoticTempest = 196292;
        private const int MissileSpellId_RoilingStorm = 196298;

        [EncounterHandler((int)MobId_StormwakeHydra, "Stormwake Hydra")]
        public Func<WoWUnit, Task<bool>> StormwakeHydraLogic()
        {
            AddAvoidLocation(() => true, 2, missile => missile.ImpactPosition,
                () => WoWMissile.InFlightMissiles.Where(m => m.SpellId == MissileSpellId_ChaoticTempest));

            AddAvoidLocation(() => true, 10, missile => missile.Position,
              () => WoWMissile.InFlightMissiles.Where(m => m.SpellId == MissileSpellId_RoilingStorm));

            return async boss =>
            {
                if (await ScriptHelpers.InterruptCast(boss, SpellId_BlazingNova))
                    return true;

                return false;
            };
        }

        #endregion


        private const uint MobId_Serpentrix = 91808;
        private const uint MobId_BlazingHydraSpawn = 97259;

        private const int SpellId_Rampage = 191848;
        private const int SpellId_BlazingNova = 192003;
        private const uint AreaTriggerId_ToxicPuddle = 9574;


        [EncounterHandler((int)MobId_Serpentrix, "Serpentrix", 115, CallBehaviorMode.CurrentBoss)]
        public Func<WoWUnit, Task<bool>> SerpentrixStartHandler()
        {
            var bossLoc = new Vector3(-3250.663f, 4429.41f, -2.768002f);

            var trash =
                new PerFrameCachedValue<WoWUnit>(
                    () =>
                        ScriptHelpers.GetUnfriendlyNpsAtLocation(bossLoc, 120, unit => unit.Entry != MobId_Serpentrix && unit.IsHostile)
                            .FirstOrDefault());


            // Avoid boss while there's trash to kill
            AddAvoidObject<WoWUnit>(() => ScriptHelpers.IsViable(trash.Value), 30, u => u.Entry == MobId_Serpentrix && u.IsAlive && !u.Combat);

            return async boss =>
            {
                if (boss == null || boss.Combat)
                    return false;

                // clear trash around the boss.
                if (ScriptHelpers.IsViable(trash.Value) && trash.Value.Location.DistanceSquared(boss.Location) < 30 * 30 &&
                    await ScriptHelpers.PullNpcToLocation(() => ScriptHelpers.IsViable(trash.Value), trash.Value, Me.Location, 6000))
                {
                    return true;
                }

                return await ScriptHelpers.ClearArea(bossLoc, 120, unit => unit != boss && unit.IsHostile, false);
            };
        }

        [EncounterHandler((int)MobId_Serpentrix, "Serpentrix")]
        public Func<WoWUnit, Task<bool>> SerpentrixHandler()
        {
            HashSet<int> poisonSpitSpellIds = new HashSet<int> { 191841, 191843, 191845 };

            AddAvoidLocation(() => !Me.IsTank(), 6, missile => missile.ImpactPosition,
                () => WoWMissile.InFlightMissiles.Where(m => poisonSpitSpellIds.Contains(m.SpellId)));
            
            AddAvoidObject<WoWAreaTrigger>(() => true, trigger => 5, AreaTriggerId_ToxicPuddle);

            return async boss =>
            {
                if (await ScriptHelpers.InterruptCast(boss, SpellId_Rampage))
                    return true;

                return false;
            };
        }

        [EncounterHandler((int)MobId_BlazingHydraSpawn, "Blazing Hydra Spawn")]
        public Func<WoWUnit, Task<bool>> BlazingHydraSpawnLogic()
        {
            return async boss =>
            {
                if (await ScriptHelpers.InterruptCast(boss, SpellId_BlazingNova))
                    return true;

                return false;
            };
        }

        #endregion

        #region King Deepbeard

        #region Trash

        private const uint MobId_SkrogWavecrasher = 91796;

        #endregion


        private const uint MobId_KingDeepbeard = 91797;
        private const int MissileSpellId_GroundSlam = 193056;
        private const uint MobId_Quake = 97916;
        private const int SpellId_Quake = 193152;

        [EncounterHandler((int)MobId_KingDeepbeard, "King Deepbeard", 115, CallBehaviorMode.Proximity)]
        public Func<WoWUnit, Task<bool>> KingDeepbeardHandler()
        {
            WoWUnit kingDeepbeard = null;

            AddAvoidLocation(() => true, 14, missile => missile.ImpactPosition, () => WoWMissile.InFlightMissiles.Where(m => m.SpellId == MissileSpellId_GroundSlam));

            AddAvoidObject<WoWUnit>(() => !Me.HasAura("Gaseous Bubbles"), 5, u => u.Entry == MobId_Quake);
            AddAvoidObject<WoWPlayer>(() => ScriptHelpers.IsViable(kingDeepbeard) && kingDeepbeard.CastingSpellId == SpellId_Quake, 5, p => !p.IsMe && p.IsAlive);
            // dps and healers shouldn't not stand in front of boss because of Ground Slam
            AddAvoidObject<WoWUnit>(() => !Me.IsTank, 15, u => u.Entry == MobId_KingDeepbeard && u.Combat, unit => unit.Location.RayCast(unit.Rotation, 14), true);

            return async boss =>
            {
                kingDeepbeard = boss;

                if (Me.HasAura("Gaseous Bubbles"))
                {
                    var aftershock =
                        ObjectManager.GetObjectsOfType<WoWUnit>()
                            .Where(u => u.Entry == MobId_Quake && u.HasAura("Aftershock"))
                            .OrderBy(u => u.DistanceSqr)
                            .FirstOrDefault();

                    if (await ScriptHelpers.StayAtLocationWhile(() => ScriptHelpers.IsViable(aftershock) && Me.HasAura("Gaseous Bubbles"), aftershock.Location, aftershock.SafeName, 1))
                    {
                        return true;
                    }
                }

                return false;
            };
        }


        #endregion

        #region Wrath of Azshara

        private const uint MobId_MysticSsaveh = 98173;
        private const uint MobId_BinderAshioi = 100250;
        private const uint MobId_ChannelerVarisz = 100249;
        private const uint MobId_RitualistLesha = 100248;

        private readonly HashSet<uint> MobIds_WrathOfAzsharaChanneler = new HashSet<uint>()
        {
            MobId_MysticSsaveh,
            MobId_BinderAshioi,
            MobId_ChannelerVarisz,
            MobId_RitualistLesha
        };

        private const int MissileSpellId_AquaSpout = 195212;
        private const uint MobId_ArcaneBomb = 97691;
        private const int MissileSpellId_ArcaneBomb = 192711;

        [EncounterHandler((int)MobId_MysticSsaveh, "Mystic Ssaveh")]
        [EncounterHandler((int)MobId_BinderAshioi, "Binder Ashioi")]
        [EncounterHandler((int)MobId_ChannelerVarisz, "Channeler Varisz")]
        [EncounterHandler((int)MobId_RitualistLesha, "Ritualist Lesha")]
        public Func<WoWUnit, Task<bool>> MysticSsavehBehavior()
        {
            AddAvoidLocation(() => true, 4, missile => missile.ImpactPosition, () => WoWMissile.InFlightMissiles.Where(m => m.SpellId == MissileSpellId_AquaSpout));
            //AddAvoidLocation(() => true, 10, missile => missile.ImpactPosition, () => WoWMissile.InFlightMissiles.Where(m => m.SpellId == MissileSpellId_ArcaneBomb));

            AddAvoidObject<WoWPlayer>(() => Me.HasAura("Arcane Bomb"), 10, player => !player.IsMe && player.IsAlive);
            AddAvoidObject<WoWUnit>(() => !Me.HasAura("Arcane Bomb"), 10, unit => unit.Entry == MobId_ArcaneBomb);

            return async boss =>
            {
                if (await ScriptHelpers.DispelGroup("Magic Binding", ScriptHelpers.PartyDispelType.Magic))
                    return true;

                // ToDo: Run out of Storm effect

                var arcaneBombDispelTarget =
                    Me.RaidMembers.FirstOrDefault(
                        r =>
                            r.HasAura("Arcane Bomb") &&
                            !Me.RaidMembers.Any(s => s != r && s.Location.DistanceSquared(r.Location) < 10 * 10));

                // Dispell Arcane Bomb when person is not near other players
                if (arcaneBombDispelTarget !=null && await ScriptHelpers.DispelFriendlyUnit("Arcane Bomb", ScriptHelpers.PartyDispelType.Magic, arcaneBombDispelTarget))
                    return true;

                return false;
            };
        }
        WoWUnit _wrathOfAzshara;

        private const uint MobId_WrathOfAzshara = 96028;
        private const int SpellId_MassiveDeluge = 192617;

        [EncounterHandler((int)MobId_WrathOfAzshara, "Wrath of Azshara", Mode=CallBehaviorMode.CurrentBoss)]
        public Func<WoWUnit, Task<bool>> WrathOfAzsharaStartBehavior()
        {
            return async boss =>
            {
                if (!Me.IsTank || boss == null || !Targeting.Instance.IsEmpty() || BotPoi.Current.Type != PoiType.None)
                    return false;

                if (!boss.HasAura("Storm Conduit"))
                    return false;

                var channeler =
                    ObjectManager.GetObjectsOfType<WoWUnit>()
                        .Where(u => MobIds_WrathOfAzsharaChanneler.Contains(u.Entry) && u.IsAlive)
                        .OrderBy(u => u.DistanceSqr)
                        .FirstOrDefault();

                if (channeler == null)
                    return false;

                BotPoi.Current = new BotPoi(channeler.Location, PoiType.Hotspot);
                return true;
            };
        }

        private const uint AreaTriggerId_SurgingWaters = 9640;
        private const uint AreaTriggerId_TidalWave = 9671;
        private const uint AreaTriggerId_MysticTornado = 9647;
        private const int MissileSpellId_MysticTornado = 192681;

        [EncounterHandler((int)MobId_WrathOfAzshara, "Wrath of Azshara", 150, CallBehaviorMode.Proximity)]
        public Func<WoWUnit, Task<bool>> WrathOfAzsharaBehavior()
        {
            var bossLoc = new Vector3(-3501.03f, 4464.382f, -0.4354081f);

            AddAvoidObject<WoWAreaTrigger>(() => ScriptHelpers.IsViable(_wrathOfAzshara),
                () => (Me.IsTank ? _wrathOfAzshara : ScriptHelpers.Tank ?? _wrathOfAzshara).Location,
                35,
                a => AvoidanceManager.IsRunningOutOfAvoid ? 20 + 3: 20, AreaTriggerId_SurgingWaters);

            Vector2[] tidalWaveAvoidPoly =
            {
                new Vector2(1.5f, -1.1f),
                new Vector2(-1.1f, -1.1f),
                new Vector2(-1.1f, 1.1f),
                new Vector2(1.5f, 1.1f),
                new Vector2(3, 0),
                new Vector2(1.5f, -1.1f)
            };

            Func<WoWAreaTrigger, float> getTidalwaveScale = a =>
            {
                // Not sure how the game dermines scale but it's based on distance from boss.
                var dist = _wrathOfAzshara.Location.Distance2D(a.Location);
                if (dist < 60)
                    return 4;
                if (dist < 85)
                    return 6;
                if (dist < 115)
                    return 8;
                return 10;
            };

            AddAvoidPolygon(() => ScriptHelpers.IsViable(_wrathOfAzshara) && Me.IsDps,
                () => (ScriptHelpers.Tank ?? _wrathOfAzshara).Location, 
                35,
                unit => unit.Rotation, a => AvoidanceManager.IsRunningOutOfAvoid ? getTidalwaveScale(a) + 3 : getTidalwaveScale(a), unit => 30, unit => tidalWaveAvoidPoly,
                unit => unit.Location,
                () => ObjectManager.GetObjectsOfType<WoWAreaTrigger>().Where(u => (u.Entry == AreaTriggerId_TidalWave) && u.DistanceSqr < 30 * 30));

            //AddAvoidObject<WoWAreaTrigger>(() => true,
            //    a => AvoidanceManager.IsRunningOutOfAvoid ? getTidalwaveScale(a) + 5 : getTidalwaveScale(a),
            //    a => a.Entry == AreaTriggerId_MysticTornado && a.DistanceSqr < 25 * 25);

            AddAvoidObject<WoWAreaTrigger>(() => ScriptHelpers.IsViable(_wrathOfAzshara),
                () => (Me.IsTank ? _wrathOfAzshara : ScriptHelpers.Tank ?? _wrathOfAzshara).Location, 
                35, a => AvoidanceManager.IsRunningOutOfAvoid ? 10 : 6,
                a => a.Entry == AreaTriggerId_MysticTornado && a.DistanceSqr < 25 * 25);

            AddAvoidLocation(() => true, () => bossLoc, Me.IsTank ? 30 : 60,
                a => AvoidanceManager.IsRunningOutOfAvoid ? 8 : 6, missile => missile.ImpactPosition,
                () => WoWMissile.InFlightMissiles.Where(m => m.SpellId == MissileSpellId_MysticTornado));

            //Vector3 massiveDeludgeLoc = Vector3.Zero;
            //Stopwatch massiveDeludgeSw = new Stopwatch();

            //// Massive Deludge 
            //AddAvoidObject<WoWUnit>(() => ScriptHelpers.IsViable(_wrathOfAzshara) && _wrathOfAzshara.GotTarget, 16,
            //    u => u.Entry == MobId_WrathOfAzshara && (!Me.IsTank || u.CastingSpellId == SpellId_MassiveDeluge),
            //    unit =>
            //    {
            //        if (massiveDeludgeSw == null || massiveDeludgeSw.ElapsedMilliseconds > 10000)
            //        {
            //            massiveDeludgeLoc = _wrathOfAzshara.CurrentTarget.Location;
            //            massiveDeludgeSw = Stopwatch.StartNew();
            //        }

            //        return massiveDeludgeLoc;
            //    });

            Vector2[] wrathOfAzsharaPoly =
            {
                new Vector2(4,1),
                new Vector2(4,-1),
                new Vector2(0, -1),
                new Vector2(0, 1)
            };

            AddAvoidPolygon(() => ScriptHelpers.IsViable(_wrathOfAzshara) && (!Me.IsTank || _wrathOfAzshara.CastingSpellId == SpellId_MassiveDeluge), 
                () => (Me.IsTank ? _wrathOfAzshara : ScriptHelpers.Tank??_wrathOfAzshara).Location,
                35,
                unit => unit.Rotation, a => 16, unit => 30, unit => wrathOfAzsharaPoly,
                unit => unit.Location,
                () => new [] {_wrathOfAzshara });

            var capablitiyHandle = CapabilityManager.Instance.CreateNewHandle();

            return async boss =>
            {
                _wrathOfAzshara = boss;

                CapabilityManager.Instance.Update(capablitiyHandle, CapabilityFlags.GapCloser,
                    () => ScriptHelpers.IsViable(boss) && boss.Combat);


                CapabilityManager.Instance.Update(capablitiyHandle, CapabilityFlags.MoveBehind,
                    () => ScriptHelpers.IsViable(boss) && boss.Combat);

                if (await ScriptHelpers.CastHeroism())
                    return true;

                var arcaneBombDispelTarget =
                    Me.RaidMembers.FirstOrDefault(
                        r =>
                            r.HasAura("Arcane Bomb") &&
                            !Me.RaidMembers.Any(s => s != r && s.Location.DistanceSquared(r.Location) < 10 * 10));

                // Dispell Arcane Bomb when person is not near other players
                if (arcaneBombDispelTarget != null && await ScriptHelpers.DispelFriendlyUnit("Arcane Bomb", ScriptHelpers.PartyDispelType.Magic, arcaneBombDispelTarget))
                    return true;

                return false;
            };


        }

        #endregion
    }

    #endregion

    #region Heroic Difficulty

    public class EyeOfAzsharaHeroic : EyeOfAzshara
    {
        #region Overrides of Dungeon

        public override uint DungeonId => 1175;

        #endregion
    }

    #endregion
}
