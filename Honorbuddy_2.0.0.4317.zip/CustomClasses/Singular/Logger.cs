﻿#region Revision Info

// This file is part of Singular - A community driven Honorbuddy CC
// $Author: apoc $
// $Date: 2011-03-04 14:49:55 +0200 (Cum, 04 Mar 2011) $
// $HeadURL: http://svn.apocdev.com/singular/trunk/Singular/Logger.cs $
// $LastChangedBy: apoc $
// $LastChangedDate: 2011-03-04 14:49:55 +0200 (Cum, 04 Mar 2011) $
// $LastChangedRevision: 140 $
// $Revision: 140 $

#endregion

using System.Drawing;

using Singular.Settings;

using Styx.Helpers;

namespace Singular
{
    internal class Logger
    {
        public static void Write(string message)
        {
            Logging.Write(Color.Green, "[Singular] " + message);
        }

        public static void WriteDebug(string message)
        {
            if (!SingularSettings.Instance.EnableDebugLogging)
            {
                return;
            }

            Logging.WriteDebug(Color.Green, "[Singular-DEBUG] " + message);
        }
    }
}