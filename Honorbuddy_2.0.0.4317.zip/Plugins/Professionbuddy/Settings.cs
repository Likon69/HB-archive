﻿/* ========================================================================
 *
 * Copyright (c) 2011 Highvoltz of www.buddyforum.de  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are Not permitted without direct consent of the copyright 
 * holder
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL HIGHVOLTZ OF www.buddyforum.de 
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,                     
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Styx.Helpers;
namespace HighVoltz
{
    public class ProfessionBuddySettings : Settings
    {
        public ProfessionBuddySettings(string settingsPath)
            : base(settingsPath)
        {
            Load();
        }
        [Setting, DefaultValue("")]
        public string LastProfile { get; set; }
    }
}
