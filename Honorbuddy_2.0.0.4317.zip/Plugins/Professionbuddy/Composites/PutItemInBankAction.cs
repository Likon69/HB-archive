﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing.Design;
using System.Linq;
using System.Xml;
using Styx;
using Styx.Helpers;
using Styx.Logic.Pathing;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using TreeSharp;
using ObjectManager = Styx.WoWInternals.ObjectManager;


namespace HighVoltz.Composites
{
    #region PutItemInBankAction
    public class PutItemInBankAction : PBAction
    {
        public enum BankType
        {
            Personal,
            Guild
        }
        public BankType Bank
        {
            get { return (BankType)Properties["Bank"].Value; }
            set { Properties["Bank"].Value = value; }
        }

        public uint Entry
        {
            get { return (uint)Properties["Entry"].Value; }
            set { Properties["Entry"].Value = value; }
        }
        public uint GuildTab
        {
            get { return (uint)Properties["GuildTab"].Value; }
            set { Properties["GuildTab"].Value = value; }
        }
        public uint NpcEntry
        {
            get { return (uint)Properties["NpcEntry"].Value; }
            set { Properties["NpcEntry"].Value = value; }
        }
        public int Amount
        {
            get { return (int)Properties["Amount"].Value; }
            set { Properties["Amount"].Value = value; }
        }
        public bool AutoFindBank
        {
            get { return (bool)Properties["AutoFindBank"].Value; }
            set { Properties["AutoFindBank"].Value = value; }
        }
        WoWPoint loc;
        public string Location
        {
            get { return (string)Properties["Location"].Value; }
            set { Properties["Location"].Value = value; }
        }
        public PutItemInBankAction()
        {
            Properties["Amount"] = new MetaProp("Amount", typeof(int));
            Properties["Entry"] = new MetaProp("Entry", typeof(uint));
            Properties["Bank"] = new MetaProp("Bank", typeof(BankType));
            Properties["AutoFindBank"] = new MetaProp("AutoFindBank", typeof(bool), new DisplayNameAttribute("Auto find Bank"));
            Properties["Location"] = new MetaProp("Location", typeof(string), new EditorAttribute(typeof(PropertyBag.LocationEditor), typeof(UITypeEditor)));
            Properties["NpcEntry"] = new MetaProp("NpcEntry", typeof(uint));
            Properties["GuildTab"] = new MetaProp("GuildTab", typeof(uint));

            Properties["Amount"].Value = 0;
            Properties["Entry"].Value = 0u;
            Properties["Bank"].Value = BankType.Personal;
            Properties["AutoFindBank"].Value = true;
            loc = WoWPoint.Zero;
            Properties["Location"].Value = loc.ToString();
            Properties["NpcEntry"].Value = 0u;
            Properties["GuildTab"].Value = 0u;

            Properties["Location"].Show = false;
            Properties["NpcEntry"].Show = false;
            Properties["GuildTab"].Show = false;

            Properties["AutoFindBank"].PropertyChanged += new EventHandler(AutoFindBankChanged);
            Properties["Bank"].PropertyChanged += new EventHandler(PutItemInBankAction_PropertyChanged);
            Properties["Location"].PropertyChanged += new EventHandler(LocationChanged);
        }
        void LocationChanged(object sender, EventArgs e)
        {
            MetaProp mp = (MetaProp)sender;
            loc = Util.StringToWoWPoint((string)((MetaProp)sender).Value);
            Properties["Location"].PropertyChanged -= new EventHandler(LocationChanged);
            Properties["Location"].Value = string.Format("<{0}, {1}, {2}>", loc.X, loc.Y, loc.Z);
            Properties["Location"].PropertyChanged += new EventHandler(LocationChanged);
            RefreshPropertyGrid();
        }

        void PutItemInBankAction_PropertyChanged(object sender, EventArgs e)
        {
            if (Bank == BankType.Personal)
            {
                Properties["GuildTab"].Show = false;
            }
            else
            {
                Properties["GuildTab"].Show = true;
            }
            RefreshPropertyGrid();
        }

        void AutoFindBankChanged(object sender, EventArgs e)
        {
            if (AutoFindBank)
            {
                Properties["Location"].Show = false;
                Properties["NpcEntry"].Show = false;
            }
            else
            {
                Properties["Location"].Show = true;
                Properties["NpcEntry"].Show = true;
            }
            RefreshPropertyGrid();
        }

        WoWObject bank;
        Stopwatch interactTimer = new Stopwatch();
        protected override RunStatus Run(object context)
        {
            if (!IsDone)
            {
                WoWPoint movetoPoint = loc;
                bank = GetLocalBanker();
                if (bank != null)
                    movetoPoint = bank.Location;
                // search the database
                else if (movetoPoint == WoWPoint.Zero)
                {
                    if (Bank == BankType.Personal)
                        movetoPoint = MoveToAction.GetLocationFromDB(MoveToAction.MoveToType.NearestBanker, NpcEntry);
                    else
                        movetoPoint = MoveToAction.GetLocationFromDB(MoveToAction.MoveToType.NearestGB, NpcEntry);
                }
                if (movetoPoint == WoWPoint.Zero)
                    return RunStatus.Failure;
                if (movetoPoint.Distance(ObjectManager.Me.Location) > 4.5)
                {
                    Util.MoveTo(movetoPoint);
                    return RunStatus.Running;
                }
                else if (bank == null)
                {
                    Logging.Write(System.Drawing.Color.Red, "Unable to find a banker at location. aborting");
                    return RunStatus.Failure;
                }
                else
                {  // can't use frame:IsVisible and be compatible with some bag addons. 
                    //I might have to use events if this doesn't work well
                    if (!interactTimer.IsRunning)
                    {
                        interactTimer.Reset();
                        interactTimer.Start();
                        bank.Interact();
                        return RunStatus.Running;
                    }
                    else if (interactTimer.ElapsedMilliseconds < 4000)
                    {
                        bank.Interact();// spam the interact() since we have no check to see if frame is open..
                        return RunStatus.Running;
                    }
                    if (Bank == BankType.Personal)
                        IsDone = PutItemInBank(Entry, Amount);
                    else
                        IsDone = PutItemInGBank(Entry, Amount, GuildTab);
                }
                if (IsDone)
                {
                    interactTimer.Stop();
                    Professionbuddy.Log("Deposited Item with ID: {0} into {1} Bank", Entry, Bank);
                }
                else
                    return RunStatus.Running;
            }
            return RunStatus.Failure;
        }

        WoWObject GetLocalBanker()
        {
            WoWObject bank = null;
            List<WoWObject> bankers;
            if (Bank == BankType.Guild)
                bankers = ObjectManager.ObjectList.Where(o => ((o.TypeFlags & WoWObjectTypeFlag.GameObject) > 0 && o.ToGameObject().SubType == WoWGameObjectType.GuildBank)
                    || ((o.TypeFlags & WoWObjectTypeFlag.Unit) > 0 && o.ToUnit().IsGuildBanker && o.ToUnit().IsAlive)).ToList();
            else
                bankers = ObjectManager.ObjectList.Where(o => (o.TypeFlags & WoWObjectTypeFlag.Unit) > 0 && o.ToUnit().IsBanker && o.ToUnit().IsAlive).ToList();

            if (bankers != null)
            {
                if (NpcEntry != 0)
                    bank = bankers.Where(b => b.Entry == NpcEntry).OrderBy(o => o.Distance).FirstOrDefault();
                else if (AutoFindBank || loc == WoWPoint.Zero)
                    bank = bankers.OrderBy(o => o.Distance).FirstOrDefault();
                else if (ObjectManager.Me.Location.Distance(loc) <= 90)
                {
                    bank = bankers.Where(o => o.Location.Distance(loc) < 10).
                        OrderBy(o => o.Distance).FirstOrDefault();
                }
            }
            return bank;
        }
        Stopwatch queueServerSW;
        public bool PutItemInGBank(uint id, int amount, uint tab)
        {
            if (queueServerSW == null)
            {
                queueServerSW = new Stopwatch();
                queueServerSW.Start();
                Lua.DoString("for i=GetNumGuildBankTabs(), 1, -1 do QueryGuildBankTab(i) end ");
                Professionbuddy.Log("Queuing server for gbank info");
                return false;
            }
            if (queueServerSW.ElapsedMilliseconds < 2000)
            {
                return false;
            }
            string lua = string.Format(
                "local tabnum = GetNumGuildBankTabs() " +
                "local bagged = 0 " +
                "local currentTab = 1 " +
                "local currentSlot = 1 " +
                "local storeInGbank= function () " +
                   "if {2} > 0 then currentTab = {2} end " +
                   "while currentTab <= tabnum do " +
                      "_,_,v,d =GetGuildBankTabInfo(currentTab) " +
                      "if v == 1 and d == 1 then " +
                         "SetCurrentGuildBankTab(currentTab) " +
                         "for i=currentSlot, 98 do " +
                            "local _,c,l=GetGuildBankItemInfo(currentTab, i) " +
                            "if c == 0 then " +
                               "PickupGuildBankItem(currentTab ,i) " +
                               "currentSlot = i +1 " +
                               "return " +
                            "end " +
                         "end " +
                         "currentSlot = 1 " +
                      "end " +
                      "currentTab = currentTab + 1 " +
                   "end " +
                "end " +
                "if GuildBankFrame and GuildBankFrame:IsVisible() then " +
                   "for bag = 0,4 do " +
                      "for slot=GetContainerNumSlots(bag),1,-1 do " +
                         "local id = GetContainerItemID(bag,slot) " +
                         "local _,c,l = GetContainerItemInfo(bag, slot) " +
                         "if id == {0} and l == nil then  " +
                            "if c + bagged <= {1} then " +
                               "PickupContainerItem(bag,slot) " +
                               "storeInGbank() " +
                               "bagged = bagged + c " +
                            "else " +
                               "SplitContainerItem(bag,slot, {1}-bagged) " +
                               "storeInGbank() " +
                               "return 1 " +
                            "end " +
                         "end " +
                      "end " +
                   "end " +
                "else " +
                   "return -1 " +
                "end " +
                "return 0 ", id, amount <= 0 ? int.MaxValue : amount, tab);
            int retVal = Lua.GetReturnVal<int>(lua, 0);
            // -1 means frame was not visible.
            if (retVal == -1)
            {
                interactTimer.Stop();
            }
            queueServerSW = null;
            return true;
        }

        public bool PutItemInBank(uint id, int amount)
        {
            string lua = string.Format(
                "local bagged = 0 " +
                "local amount = 23 " +
                "local currentBag = -1 " +
                "local currentSlot = 1 " +
                "local storeInBank= function () " +
                   "while currentBag <= 11 do " +
                      "local itemf  = GetItemFamily({0}) " +
                      "local fs,bfamily = GetContainerNumFreeSlots(currentBag) " +
                      "if fs > 0 and (bfamily == 0 or bit.band(itemf, bfamily) > 0) then " +
                         "for i=currentSlot, GetContainerNumSlots(currentBag) do " +
                            "local _,c,l = GetContainerItemInfo(currentBag, i) " +
                            "if c == nil then " +
                               "PickupContainerItem(currentBag,i) " +
                               "currentSlot = i +1 " +
                               "return " +
                            "end " +
                            "currentSlot = 1 " +
                         "end " +
                      "end " +
                      "currentBag = currentBag + 1 " +
                      "if currentBag == 0 then currentBag = 5 " +
                      "end " +
                   "end " +
                "end " +
                "for bag = 0,4 do " +
                   "for slot=GetContainerNumSlots(bag),1,-1 do " +
                      "local id = GetContainerItemID(bag,slot) " +
                      "local _,c,l = GetContainerItemInfo(bag, slot) " +
                      "if id == {0} and l == nil then " +
                         "if c + bagged <= {1} then " +
                            "PickupContainerItem(bag, slot) " +
                            "storeInBank() " +
                            "bagged = bagged + c " +
                         "else " +
                            "SplitContainerItem(bag,slot, {1}-bagged) " +
                            "storeInBank() " +
                            "return 1 " +
                         "end " +
                      "end " +
                   "end " +
                "end "
                , id, amount <= 0 ? int.MaxValue : amount);
            int retVal = Lua.GetReturnVal<int>(lua, 0);
            return true;
        }
        public override string Name { get { return "Deposit Item in Bank"; } }
        public override string Title
        {
            get
            {
                return string.Format("{0}: {1} {2}", Name, Entry, Amount);
            }
        }
        public override string Help
        {
            get
            {
                return "This action will deposit the specified item from your personal or guild bank. Set Amount to 0 if you want to deposit all items that match Entry. Set GuildTab to 0 to deposit in whichever tab has room";
            }
        }
        public override object Clone()
        {
            return new PutItemInBankAction()
            {
                Entry = this.Entry,
                Amount = this.Amount,
                Bank = this.Bank,
                NpcEntry = this.NpcEntry,
                loc = this.loc,
                GuildTab = this.GuildTab,
                AutoFindBank = this.AutoFindBank,
                Parent = this.Parent,
                Location = this.Location
            };
        }
        #region XmlSerializer
        public override void ReadXml(XmlReader reader)
        {
            uint id;
            uint.TryParse(reader["Amount"], out id);
            Amount = (int)id;
            uint.TryParse(reader["Entry"], out id);
            Entry = id;
            uint.TryParse(reader["NpcEntry"], out id);
            NpcEntry = id;
            uint.TryParse(reader["GuildTab"], out id);
            GuildTab = id;
            bool autoFind;
            bool.TryParse(reader["AutoFindBank"], out autoFind);
            AutoFindBank = autoFind;
            Bank = (BankType)Enum.Parse(typeof(BankType), reader["Bank"]);
            float x, y, z;
            float.TryParse(reader["X"], out x);
            float.TryParse(reader["Y"], out y);
            float.TryParse(reader["Z"], out z);
            loc = new WoWPoint(x, y, z);
            Properties["Location"].Value = loc.ToString();
            reader.ReadStartElement();
        }
        public override void WriteXml(XmlWriter writer)
        {
            writer.WriteAttributeString("Amount", Amount.ToString());
            writer.WriteAttributeString("Entry", Entry.ToString());
            writer.WriteAttributeString("NpcEntry", NpcEntry.ToString());
            writer.WriteAttributeString("GuildTab", GuildTab.ToString());
            writer.WriteAttributeString("AutoFindBank", AutoFindBank.ToString());
            writer.WriteAttributeString("Bank", Bank.ToString());
            writer.WriteAttributeString("X", loc.X.ToString());
            writer.WriteAttributeString("Y", loc.Y.ToString());
            writer.WriteAttributeString("Z", loc.Z.ToString());
        }
        #endregion
    }
    #endregion
}
