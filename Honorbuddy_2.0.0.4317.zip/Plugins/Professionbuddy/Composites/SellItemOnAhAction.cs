﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.ComponentModel;
using System.Globalization;
using Styx;
using TreeSharp;
using Styx.Helpers;
using Styx.WoWInternals;
using System.Diagnostics;
using Styx.Logic.Pathing;
using Styx.WoWInternals.WoWObjects;
using System.Xml;
using System.Drawing.Design;

using ObjectManager = Styx.WoWInternals.ObjectManager;

namespace HighVoltz.Composites
{
    struct AuctionEntry
    {
        public AuctionEntry(string name, uint id, uint buyout, uint bid)
        {
            Name = name;
            Id = id;
            Buyout = buyout;
            Bid = bid;
            LowestBo = 0;
        }
        public string Name;
        public uint Id;
        public uint Buyout;
        public uint Bid;
        public uint LowestBo;
        public override string ToString()
        {
            return string.Format("Name:{0} Buyout:{1} Competitor:{2}",
                Name,goldString(Buyout),goldString(LowestBo));
        }
        string goldString(uint copper)
        {
            uint gold = copper / 10000;
            copper %= 10000;
            uint silver = copper / 100;
            copper %= 100;
            return string.Format("{0}g{1}s{2}c", gold, silver, copper);
        }
    }

    #region SellItemOnAhAction
    class SellItemOnAhAction : PBAction
    {
        public enum RunTimeType { _12_Hours = 1, _24_Hours, _48_Hours, }
        public enum AmountBasedType { Amount, Everything }
        public bool UseCategory
        {
            get { return (bool)Properties["UseCategory"].Value; }
            set { Properties["UseCategory"].Value = value; }
        }
        public WoWItemClass Category
        {
            get { return (WoWItemClass)Properties["Category"].Value; }
            set { Properties["Category"].Value = value; }
        }
        public object SubCategory
        {
            get { return (object)Properties["SubCategory"].Value; }
            set { Properties["SubCategory"].Value = value; }
        }
        public RunTimeType RunTime
        {
            get { return (RunTimeType)Properties["RunTime"].Value; }
            set { Properties["RunTime"].Value = value; }
        }
        public AmountBasedType AmountType
        {
            get { return (AmountBasedType)Properties["AmountType"].Value; }
            set { Properties["AmountType"].Value = value; }
        }
        public string ItemName
        {
            get { return (string)Properties["ItemName"].Value; }
            set { Properties["ItemName"].Value = value; }
        }
        public PropertyBag.GoldEditor MinBuyout
        {
            get { return (PropertyBag.GoldEditor)Properties["MinBuyout"].Value; }
            set { Properties["MinBuyout"].Value = value; }
        }
        public PropertyBag.GoldEditor MaxBuyout
        {
            get { return (PropertyBag.GoldEditor)Properties["MaxBuyout"].Value; }
            set { Properties["MaxBuyout"].Value = value; }
        }
        public uint StackSize
        {
            get { return (uint)Properties["StackSize"].Value; }
            set { Properties["StackSize"].Value = value; }
        }
        public uint Amount
        {
            get { return (uint)Properties["Amount"].Value; }
            set { Properties["Amount"].Value = value; }
        }
        public float BidPrecent
        {
            get { return (float)Properties["BidPrecent"].Value; }
            set { Properties["BidPrecent"].Value = value; }
        }
        public float UndercutPrecent
        {
            get { return (float)Properties["UndercutPrecent"].Value; }
            set { Properties["UndercutPrecent"].Value = value; }
        }
        public bool AutoFindAh
        {
            get { return (bool)Properties["AutoFindAh"].Value; }
            set { Properties["AutoFindAh"].Value = value; }
        }
        WoWPoint loc;
        public string Location
        {
            get { return (string)Properties["Location"].Value; }
            set { Properties["Location"].Value = value; }
        }

        public SellItemOnAhAction()
        {
            Properties["ItemName"] = new MetaProp("ItemName", typeof(string), new DisplayNameAttribute("Item Name"));
            Properties["RunTime"] = new MetaProp("RunTime", typeof(RunTimeType), new DisplayNameAttribute("Auction Duration"));
            Properties["MinBuyout"] = new MetaProp("MinBuyout", typeof(PropertyBag.GoldEditor),
                new DisplayNameAttribute("Min Buyout"), new TypeConverterAttribute(typeof(PropertyBag.GoldEditorConverter)));
            Properties["MaxBuyout"] = new MetaProp("MaxBuyout", typeof(PropertyBag.GoldEditor),
                new DisplayNameAttribute("Max Buyout"), new TypeConverterAttribute(typeof(PropertyBag.GoldEditorConverter)));
            Properties["Amount"] = new MetaProp("Amount", typeof(uint));
            Properties["StackSize"] = new MetaProp("StackSize", typeof(uint));
            Properties["AmountType"] = new MetaProp("AmountType", typeof(AmountBasedType), new DisplayNameAttribute("Sell"));
            Properties["AutoFindAh"] = new MetaProp("AutoFindAh", typeof(bool), new DisplayNameAttribute("Auto find AH"));
            Properties["Location"] = new MetaProp("Location", typeof(string), new EditorAttribute(typeof(PropertyBag.LocationEditor), typeof(UITypeEditor)));
            Properties["BidPrecent"] = new MetaProp("BidPrecent", typeof(float));
            Properties["UndercutPrecent"] = new MetaProp("UndercutPrecent", typeof(float));
            Properties["UseCategory"] = new MetaProp("UseCategory", typeof(bool), new DisplayNameAttribute("Use Category"));
            Properties["Category"] = new MetaProp("Category", typeof(WoWItemClass), new DisplayNameAttribute("Item Category"));
            Properties["SubCategory"] = new MetaProp("SubCategory", typeof(WoWItemTradeGoodsClass), new DisplayNameAttribute("Item SubCategory"));


            Properties["ItemName"].Value = "";
            Properties["MinBuyout"].Value = new PropertyBag.GoldEditor("0g10s0c");
            Properties["MaxBuyout"].Value = new PropertyBag.GoldEditor("100g0s0c");
            Properties["RunTime"].Value = RunTimeType._24_Hours;
            Properties["Amount"].Value = 10u;
            Properties["StackSize"].Value = 20u;
            Properties["AmountType"].Value = AmountBasedType.Everything;
            Properties["AutoFindAh"].Value = true;
            Properties["BidPrecent"].Value = 95f;
            Properties["UndercutPrecent"].Value = 0.1f;
            loc = WoWPoint.Zero;
            Properties["Location"].Value = loc.ToString();
            Properties["UseCategory"].Value = true;
            Properties["Category"].Value = WoWItemClass.TradeGoods;
            Properties["SubCategory"].Value = WoWItemTradeGoodsClass.Herb;

            Properties["AutoFindAh"].PropertyChanged += new EventHandler(AutoFindAHChanged);
            Properties["AmountType"].PropertyChanged += new EventHandler(SellItemToAhAction_PropertyChanged);
            Properties["Location"].PropertyChanged += new EventHandler(LocationChanged);
            Properties["UseCategory"].PropertyChanged += UseCategoryChanged;
            Properties["Category"].PropertyChanged += CategoryChanged;

            Properties["ItemName"].Show = false;
            Properties["Amount"].Show = false;
            Properties["Location"].Show = false;
        }

        #region Callbacks
        void LocationChanged(object sender, EventArgs e)
        {
            MetaProp mp = (MetaProp)sender;
            loc = Util.StringToWoWPoint((string)((MetaProp)sender).Value);
            Properties["Location"].PropertyChanged -= new EventHandler(LocationChanged);
            Properties["Location"].Value = string.Format("<{0}, {1}, {2}>", loc.X, loc.Y, loc.Z);
            Properties["Location"].PropertyChanged += new EventHandler(LocationChanged);
            RefreshPropertyGrid();
        }

        void AutoFindAHChanged(object sender, EventArgs e)
        {
            if (AutoFindAh)
                Properties["Location"].Show = false;
            else
                Properties["Location"].Show = true;
            RefreshPropertyGrid();
        }

        void SellItemToAhAction_PropertyChanged(object sender, EventArgs e)
        {
            if (AmountType == AmountBasedType.Everything)
                Properties["Amount"].Show = false;
            else
                Properties["Amount"].Show = true;
            RefreshPropertyGrid();
        }

        void UseCategoryChanged(object sender, EventArgs e)
        {
            if (UseCategory)
            {
                Properties["ItemName"].Show = false;
                Properties["Category"].Show = true;
                Properties["SubCategory"].Show = true;
            }
            else
            {
                Properties["ItemName"].Show = true;
                Properties["Category"].Show = false;
                Properties["SubCategory"].Show = false;
            }
            RefreshPropertyGrid();
        }
        void CategoryChanged(object sender, EventArgs e)
        {
            switch (Category)
            {
                case WoWItemClass.Armor:
                    Properties["SubCategory"] = new MetaProp("SubCategory", typeof(WoWItemArmorClass), new DisplayNameAttribute("Item SubCategory"));
                    SubCategory = WoWItemArmorClass.None;
                    break;
                case WoWItemClass.Consumable:
                case WoWItemClass.Money:
                case WoWItemClass.Projectile:
                case WoWItemClass.Quest:
                case WoWItemClass.Quiver:
                case WoWItemClass.Reagent:
                    Properties["SubCategory"] = new MetaProp("SubCategory", typeof(Enum), new DisplayNameAttribute("Item SubCategory"));
                    //Properties["SubCategory"].Value = Enum.;
                    break;
                case WoWItemClass.Container:
                    Properties["SubCategory"] = new MetaProp("SubCategory", typeof(WoWItemContainerClass), new DisplayNameAttribute("Item SubCategory"));
                    SubCategory = WoWItemContainerClass.None;
                    break;
                case WoWItemClass.Gem:
                    Properties["SubCategory"] = new MetaProp("SubCategory", typeof(WoWItemGemClass), new DisplayNameAttribute("Item SubCategory"));
                    SubCategory = WoWItemGemClass.None;
                    break;
                case WoWItemClass.Glyph:
                    Properties["SubCategory"] = new MetaProp("SubCategory", typeof(WoWItemGlyphClass), new DisplayNameAttribute("Item SubCategory"));
                    SubCategory = WoWItemGlyphClass.None;
                    break;
                case WoWItemClass.Key:
                    Properties["SubCategory"] = new MetaProp("SubCategory", typeof(WoWItemKeyClass), new DisplayNameAttribute("Item SubCategory"));
                    SubCategory = WoWItemKeyClass.None;
                    break;
                case WoWItemClass.Miscellaneous:
                    Properties["SubCategory"] = new MetaProp("SubCategory", typeof(WoWItemMiscClass), new DisplayNameAttribute("Item SubCategory"));
                    SubCategory = WoWItemMiscClass.None;
                    break;
                case WoWItemClass.Recipe:
                    Properties["SubCategory"] = new MetaProp("SubCategory", typeof(WoWItemRecipeClass), new DisplayNameAttribute("Item SubCategory"));
                    SubCategory = WoWItemRecipeClass.None;
                    break;
                case WoWItemClass.TradeGoods:
                    Properties["SubCategory"] = new MetaProp("SubCategory", typeof(WoWItemTradeGoodsClass), new DisplayNameAttribute("Item SubCategory"));
                    SubCategory = WoWItemTradeGoodsClass.None;
                    break;
                case WoWItemClass.Weapon:
                    Properties["SubCategory"] = new MetaProp("SubCategory", typeof(WoWItemWeaponClass), new DisplayNameAttribute("Item SubCategory"));
                    SubCategory = WoWItemWeaponClass.None;
                    break;
            }
            RefreshPropertyGrid();
        }
        #endregion

        //uint bo = 0, bid = 0, lowestBuyout = 0;  // buyout/bid
        List<AuctionEntry> ToScanItemList;
        List<AuctionEntry> ToSellItemList;
        protected override RunStatus Run(object context)
        {
            if (!IsDone)
            {
                if (ToScanItemList == null)
                {
                    ToScanItemList = buildScanItemList();
                    ToSellItemList = new List<AuctionEntry>();
                }
                if (ToScanItemList.Count == 0 && ToSellItemList.Count == 0)
                {
                    ToScanItemList = null;
                    IsDone = true;
                    return RunStatus.Failure;
                }
                if (Lua.GetReturnVal<int>("if AuctionFrame and AuctionFrame:IsVisible() then return 1 else return 0 end ", 0) == 0)
                {
                    //if (queueTimer.IsRunning)
                    //{
                    //    queueTimer.Stop();
                    //    queueTimer.Reset();
                    //}
                    moveToAh();
                }
                else
                {
                    if (ToScanItemList.Count > 0)
                    {
                        uint lowestBo;
                        if (ScanAh(ToScanItemList[0].Name, out lowestBo))
                        {
                            AuctionEntry ae = ToScanItemList[0];
                            if (lowestBo > MaxBuyout.TotalCopper)
                                ae.Buyout = MaxBuyout.TotalCopper;
                            else if (lowestBo < MinBuyout.TotalCopper)
                                ae.Buyout = MinBuyout.TotalCopper;
                            else
                                ae.Buyout = lowestBo - (uint)Math.Ceiling(((double)(lowestBo * UndercutPrecent) / 100d));
                            ae.Bid = (uint)((double)(ae.Buyout * BidPrecent) / 100d);
                            ae.LowestBo = lowestBo;
                            ToSellItemList.Add(ae);
                            ToScanItemList.RemoveAt(0);
                        }
                        if (ToScanItemList.Count == 0)
                            Professionbuddy.Log("Finished scanning for items");
                    }
                    if (ToSellItemList.Count > 0)
                    {
                        if (SellOnAh(ToSellItemList[0]))
                        {
                            Professionbuddy.Log("Selling {0}" ,ToSellItemList[0]);
                            ToSellItemList.RemoveAt(0);
                        }
                    }
                }
                if (!IsDone)
                    return RunStatus.Running;
            }
            return RunStatus.Failure;
        }

        #region Auction House

        Stopwatch queueTimer = new Stopwatch();
        int totalAuctions = 0;
        int page = 0;
        uint lowestBo = uint.MaxValue; // buyout in copper

        bool ScanAh(string name, out uint lowestBuyout)
        {
            bool scanned = false;
            if (!queueTimer.IsRunning)
            {
                string lua = string.Format("QueryAuctionItems(\"{0}\" ,nil,nil,nil,nil,nil,{1}) return 1",
                    name, page);
                Lua.GetReturnVal<int>(lua, 0);
                Professionbuddy.Log("Searching AH for {0}", name);
                queueTimer.Start();
            }
            else if (queueTimer.ElapsedMilliseconds <= 10000)
            {
                using (new FrameLock())
                {
                    if (Lua.GetReturnVal<int>("if CanSendAuctionQuery('list') == 1 then return 1 else return 0 end ", 0) == 1)
                    {
                        queueTimer.Stop();
                        queueTimer.Reset();
                        totalAuctions = Lua.GetReturnVal<int>("return GetNumAuctionItems('list')", 1);
                        string lua = string.Format("local A,totalA= GetNumAuctionItems('list') local me = GetUnitName('player') local lowest = {0} for index=1, A do local name, _, count,_,_,_,minBid,_, buyoutPrice,_,_,owner,_ = GetAuctionItemInfo('list', index) if string.upper(name) == string.upper(\"{1}\") and owner ~= me and buyoutPrice > 0 and buyoutPrice/count <  lowest then lowest = floor(buyoutPrice/count) end end  return lowest",
                            lowestBo, name);
                        lowestBo = Lua.GetReturnVal<uint>(lua, 0);
                        if (++page >= (int)Math.Ceiling((double)totalAuctions / 50))
                            scanned = true;
                    }
                }
            }
            else
            {
                scanned = true;
            }
            lowestBuyout = lowestBo;
            // reset to default values in preparations for next scan
            if (scanned)
            {
                queueTimer.Stop();
                queueTimer.Reset();
                totalAuctions = 0;
                page = 0;
                lowestBo = uint.MaxValue;
            }
            return scanned;
        }

        bool posted = false;
        bool SellOnAh(AuctionEntry ae)
        {
            if (!posted)
            {
                string lua = string.Format(
                    "local itemID = {0} " +
                    "local amount = {1} " +
                    "local bid = {3} " +
                    "local bo = {4} " +
                    "local runtime = {5} " +
                    "local stack = {2} " +
                    "local sold = 0 " +
                    "local leftovers = 0 " +
                    "local numItems = GetItemCount(itemID) " +
                    "if numItems == 0 then return 1 end " +
                    "if AuctionProgressFrame:IsVisible() == nil then " +
                       "if amount * stack > numItems then " +
                          "amount = floor(numItems/stack) " +
                          "if amount <= 0 then " +
                             "amount = 1 " +
                             "stack = numItems " +
                          "else " +
                             "leftovers = 1 " +
                          "end " +
                       "end " +
                       "for bag = 0,4 do " +
                          "for slot=GetContainerNumSlots(bag),1,-1 do " +
                             "local id = GetContainerItemID(bag,slot) " +
                             "local _,c,l = GetContainerItemInfo(bag, slot) " +
                             "if id == itemID and l == nil then " +
                                "PickupContainerItem(bag, slot) " +
                                "ClickAuctionSellItemButton() " +
                                "StartAuction(bid*stack, bo*stack, runtime,stack,amount) " +
                                "if leftovers == 1 then " +
                                   "return -2 " +
                                "else " +
                                   "return 1 " +
                                "end " +
                             "end " +
                          "end " +
                       "end " +
                    "else " +
                       "return -1 " +
                    "end", ae.Id, AmountType == AmountBasedType.Everything ? uint.MaxValue : Amount,
                            StackSize, ae.Bid, ae.Buyout, (int)RunTime);
                int ret = Lua.GetReturnVal<int>(lua, 0);
                if (ret == 1)
                    posted = true;
            }
            //wait for auctions to finish listing before moving on
            if (posted)
            {
                bool ret = Lua.GetReturnVal<int>("if AuctionProgressFrame:IsVisible() == nil then return 1 else return 0 end ", 0) == 1;
                if (ret)
                    posted = false;
                return ret;
            }
            else
                return false;
        }

        #endregion

        void moveToAh()
        {
            WoWPoint movetoPoint = loc;
            WoWUnit auctioneer;
            if (AutoFindAh || movetoPoint == WoWPoint.Zero)
            {
                auctioneer = ObjectManager.GetObjectsOfType<WoWUnit>().Where(o => o.IsAuctioneer && o.IsAlive)
                    .OrderBy(o => o.Distance).FirstOrDefault();
            }
            else
            {
                auctioneer = ObjectManager.GetObjectsOfType<WoWUnit>().Where(o => o.IsAuctioneer
                    && o.Location.Distance(loc) < 5)
                    .OrderBy(o => o.Distance).FirstOrDefault();
            }
            if (auctioneer != null)
                movetoPoint = auctioneer.Location;
            else if (movetoPoint == WoWPoint.Zero)
                movetoPoint = MoveToAction.GetLocationFromDB(MoveToAction.MoveToType.NearestAH, 0);
            if (movetoPoint == WoWPoint.Zero)
            {
                Logging.Write("Unable to location Auctioneer, Maybe he's dead?");
            }
            if (movetoPoint.Distance(ObjectManager.Me.Location) > 4.5)
            {
                Util.MoveTo(movetoPoint);
            }
            else if (auctioneer != null)
            {
                auctioneer.Interact();
            }
        }

        List<AuctionEntry> buildScanItemList()
        {
            var tmpItemlist = new List<AuctionEntry>();
            List<WoWItem> itemList;
            if (UseCategory)
            {
                itemList = ObjectManager.Me.BagItems.
                    Where(i => i.ItemInfo.ItemClass == Category && subCategoryCheck(i)).ToList();
                foreach (var item in itemList)
                {
                    if (!containsItem(item, tmpItemlist))
                        tmpItemlist.Add(new AuctionEntry(item.Name, item.Entry, 0, 0));
                }
            }
            else
            {
                uint itemId;
                if (!uint.TryParse(ItemName, out itemId))
                {
                    itemList = ObjectManager.Me.BagItems.
                        Where(i => i.Name.Equals(ItemName, StringComparison.OrdinalIgnoreCase)).ToList();
                }
                else
                {
                    itemList = ObjectManager.Me.BagItems.Where(i => i.Entry == itemId).ToList();
                }
                if (itemList != null && itemList.Count > 0)
                {
                    tmpItemlist.Add(new AuctionEntry(itemList[0].Name, itemList[0].Entry, 0, 0));
                }
            }
            return tmpItemlist;
        }

        Func<WoWItem, IEnumerable<AuctionEntry>, bool> containsItem = (i, en) =>
            { return en.Count(ae => ae.Id == i.Entry) > 0; };

        bool subCategoryCheck(WoWItem item)
        {
            int sub = (int)SubCategory;
            if (sub == -1 || sub == 0)
                return true;
            object val = item.ItemInfo.GetType().GetProperties().FirstOrDefault(t => t.PropertyType == SubCategory.GetType()).GetValue(item.ItemInfo, null);
            if (val != null && (int)val == sub)
                return true;
            else
                return false;
        }

        public override void Reset()
        {
            base.Reset();
        }
        public override string Name
        {
            get { return "Sell Item To AH"; }
        }
        public override string Title
        {
            get
            {
                return string.Format("{0}: {1}{2}", Name, UseCategory ?
                    string.Format("{0} {1}", Category, ((int)SubCategory != -1 && (int)SubCategory != 0) ?
                    "(" + SubCategory + ")" : "") : ItemName,
                    AmountType == AmountBasedType.Amount ? " x" + Amount.ToString() : "");
            }
        }
        public override string Help
        {
            get
            {
                return "This action will sell a specific item that matches Name/ID to the Auction house. If Cheapest item on AH is below minimum buyout then the item is listed at min buyout, else if the cheapest item is higher then the max buyout then the item is liested at max buyout, otherwise it's listed at lowest buyout minus undercut precent";
            }
        }
        public override object Clone()
        {
            return new SellItemOnAhAction()
            {
                ItemName = this.ItemName,
                MinBuyout = new PropertyBag.GoldEditor(this.MinBuyout.ToString()),
                MaxBuyout = new PropertyBag.GoldEditor(this.MaxBuyout.ToString()),
                Amount = this.Amount,
                StackSize = this.StackSize,
                AmountType = this.AmountType,
                AutoFindAh = this.AutoFindAh,
                Location = this.Location,
                UndercutPrecent = this.UndercutPrecent,
                BidPrecent = this.BidPrecent,
                RunTime = this.RunTime,
                UseCategory = this.UseCategory,
                Category = this.Category,
                SubCategory = this.SubCategory,
            };
        }
        #region XmlSerializer
        public override void ReadXml(XmlReader reader)
        {
            ItemName = reader["ItemName"];
            uint val;
            MinBuyout = new PropertyBag.GoldEditor(reader["MinBuyout"]);
            MaxBuyout = new PropertyBag.GoldEditor(reader["MaxBuyout"]);
            RunTime = (RunTimeType)Enum.Parse(typeof(RunTimeType), reader["RunTime"]);
            uint.TryParse(reader["Amount"], out val);
            Amount = val;
            uint.TryParse(reader["StackSize"], out val);
            StackSize = val;
            AmountType = (AmountBasedType)Enum.Parse(typeof(AmountBasedType), reader["AmountType"]);
            bool boolVal;
            bool.TryParse(reader["AutoFindAh"], out boolVal);
            AutoFindAh = boolVal;
            float precent;
            float.TryParse(reader["BidPrecent"], NumberStyles.AllowDecimalPoint, CultureInfo.InvariantCulture, out precent);
            BidPrecent = precent;
            float.TryParse(reader["UndercutPrecent"], NumberStyles.AllowDecimalPoint, CultureInfo.InvariantCulture, out precent);
            UndercutPrecent = precent;
            if (reader.MoveToAttribute("UseCategory"))
            {
                bool.TryParse(reader["UseCategory"], out boolVal);
                UseCategory = boolVal;
            }
            if (reader.MoveToAttribute("Category"))
            {
                Category = (WoWItemClass)Enum.Parse(typeof(WoWItemClass), reader["Category"]);
            }
            string subCatType = "";
            if (reader.MoveToAttribute("SubCategoryType"))
            {
                subCatType = reader["SubCategoryType"];
            }
            if (reader.MoveToAttribute("SubCategory") && !string.IsNullOrEmpty(subCatType))
            {
                string typeName = string.Format("Styx.{0}", subCatType);
                Type t = Assembly.GetEntryAssembly().GetType(typeName);
                object subVal = Activator.CreateInstance(t);
                subVal = Enum.Parse(t, reader["SubCategory"]);
                SubCategory = subVal;
            }

            float x, y, z;
            float.TryParse(reader["X"], out x);
            float.TryParse(reader["Y"], out y);
            float.TryParse(reader["Z"], out z);
            loc = new WoWPoint(x, y, z);
            Location = loc.ToString();
            reader.ReadStartElement();
        }
        public override void WriteXml(XmlWriter writer)
        {
            writer.WriteAttributeString("ItemName", ItemName.ToString());
            writer.WriteAttributeString("MinBuyout", MinBuyout.ToString());
            writer.WriteAttributeString("MaxBuyout", MaxBuyout.ToString());
            writer.WriteAttributeString("RunTime", RunTime.ToString());
            writer.WriteAttributeString("Amount", Amount.ToString());
            writer.WriteAttributeString("StackSize", StackSize.ToString());
            writer.WriteAttributeString("AmountType", AmountType.ToString());
            writer.WriteAttributeString("AutoFindAh", AutoFindAh.ToString());
            writer.WriteAttributeString("BidPrecent", BidPrecent.ToString(CultureInfo.InvariantCulture));
            writer.WriteAttributeString("UndercutPrecent", UndercutPrecent.ToString(CultureInfo.InvariantCulture));
            writer.WriteAttributeString("UseCategory", UseCategory.ToString());
            writer.WriteAttributeString("Category", Category.ToString());
            writer.WriteAttributeString("SubCategoryType", SubCategory.GetType().Name);
            writer.WriteAttributeString("SubCategory", SubCategory.ToString());
            writer.WriteAttributeString("X", loc.X.ToString());
            writer.WriteAttributeString("Y", loc.Y.ToString());
            writer.WriteAttributeString("Z", loc.Z.ToString());
        }
        #endregion
    }
    #endregion
}
