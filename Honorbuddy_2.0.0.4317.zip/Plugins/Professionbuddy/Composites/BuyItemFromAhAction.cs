﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing.Design;
using System.Linq;
using System.Xml;
using Styx;
using Styx.Helpers;
using Styx.Logic.Pathing;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWCache;
using Styx.WoWInternals.WoWObjects;
using TreeSharp;
using ObjectManager = Styx.WoWInternals.ObjectManager;

namespace HighVoltz.Composites
{
    #region BuyItemFromAhAction
    class BuyItemFromAhAction : PBAction
    {
        public enum AmountBasedType
        {
            SpecificAmount,
            Materials
        }
        public AmountBasedType AmountType
        {
            get { return (AmountBasedType)Properties["AmountType"].Value; }
            set { Properties["AmountType"].Value = value; }
        }
        public string ItemName
        {
            get { return (string)Properties["ItemName"].Value; }
            set { Properties["ItemName"].Value = value; }
        }
        public uint CalculatedAmount
        {
            get
            {
                if (AmountType == AmountBasedType.Materials)
                {
                    foreach (TradeSkill ts in Pb.TradeSkillList)
                    {
                        foreach (var kv in ts.Ingredients)
                        {
                            if (kv.Value.Name.ToUpper() == Name.ToUpper())
                            {
                                uint id = kv.Value.parent.ID;
                                if (Pb.MaterialList.ContainsKey(id))
                                    return (uint)Pb.MaterialList[id];
                            }
                        }
                    }
                }
                return Amount;
            }
        }

        public PropertyBag.GoldEditor MaxBuyout
        {
            get { return (PropertyBag.GoldEditor)Properties["MaxBuyout"].Value; }
            set { Properties["MaxBuyout"].Value = value; }
        }

        public uint Amount
        {
            get { return (uint)Properties["Amount"].Value; }
            set { Properties["Amount"].Value = value; }
        }
        public bool AutoFindAh
        {
            get { return (bool)Properties["AutoFindAh"].Value; }
            set { Properties["AutoFindAh"].Value = value; }
        }
        WoWPoint loc;
        public string Location
        {
            get { return (string)Properties["Location"].Value; }
            set { Properties["Location"].Value = value; }
        }

        public BuyItemFromAhAction()
        {
            Properties["ItemName"] = new MetaProp("ItemName", typeof(string), new DisplayNameAttribute("Item Name"));
            Properties["MaxBuyout"] = new MetaProp("MaxBuyout", typeof(PropertyBag.GoldEditor),
                new DisplayNameAttribute("Max Buyout"), new TypeConverterAttribute(typeof(PropertyBag.GoldEditorConverter)));
            Properties["Amount"] = new MetaProp("Amount", typeof(uint));
            Properties["AmountType"] = new MetaProp("AmountType", typeof(AmountBasedType), new DisplayNameAttribute("Buy based on..."));
            Properties["AutoFindAh"] = new MetaProp("AutoFindAh", typeof(bool), new DisplayNameAttribute("Auto find AH"));
            Properties["Location"] = new MetaProp("Location", typeof(string), new EditorAttribute(typeof(PropertyBag.LocationEditor), typeof(UITypeEditor)));

            Properties["ItemName"].Value = "";
            Properties["Amount"].Value = 0u;
            Properties["AmountType"].Value = AmountBasedType.SpecificAmount;
            Properties["AutoFindAh"].Value = true;
            loc = WoWPoint.Zero;
            Properties["Location"].Value = loc.ToString();
            Properties["MaxBuyout"].Value = new PropertyBag.GoldEditor("100g0s0c");

            Properties["AutoFindAh"].PropertyChanged += new EventHandler(AutoFindAHChanged);
            Properties["AmountType"].PropertyChanged += new EventHandler(BuyItemFromAhAction_PropertyChanged);
            Properties["Location"].PropertyChanged += new EventHandler(LocationChanged);
            Properties["Amount"].Show = true;
            Properties["Location"].Show = false;
        }
        void LocationChanged(object sender, EventArgs e)
        {
            MetaProp mp = (MetaProp)sender;
            loc = Util.StringToWoWPoint((string)((MetaProp)sender).Value);
            Properties["Location"].PropertyChanged -= new EventHandler(LocationChanged);
            Properties["Location"].Value = string.Format("<{0}, {1}, {2}>", loc.X, loc.Y, loc.Z);
            Properties["Location"].PropertyChanged += new EventHandler(LocationChanged);
            RefreshPropertyGrid();
        }

        void AutoFindAHChanged(object sender, EventArgs e)
        {
            if (AutoFindAh)
            {
                Properties["Location"].Show = false;
            }
            else
            {
                Properties["Location"].Show = true;
            }
            RefreshPropertyGrid();
        }
        void BuyItemFromAhAction_PropertyChanged(object sender, EventArgs e)
        {
            if (AmountType == AmountBasedType.Materials)
                Properties["Amount"].Show = false;
            else
                Properties["Amount"].Show = true;
            RefreshPropertyGrid();
        }
        Stopwatch queueTimer = new Stopwatch();
        int totalAuctions = 0;
        int counter = 0;
        int page = 0;
        uint itemID = 0;
        Stopwatch queueServerForItemSW;
        string localizedName;
        WoWUnit auctioneer;
        protected override RunStatus Run(object context)
        {
            if (!IsDone)
            {
                #region ItemID to localized name conversion
                // check if the Name is a number, if so lets look up the localized name.
                if (queueServerForItemSW == null)
                {
                    queueServerForItemSW = new Stopwatch();
                    uint.TryParse(ItemName, out itemID);
                    if (itemID > 0)
                    {
                        localizedName = TradeSkillFrame.GetItemCacheName(itemID);
                        if (string.IsNullOrEmpty(localizedName))// ok looks like name is not in the cache, lets queue the server for it
                        {
                            Styx.StyxWoW.Cache[CacheDb.Item].GetInfoBlockById(itemID);
                            queueServerForItemSW.Start();
                            Professionbuddy.Log("Queueing server for Item: {0}", itemID);
                            return RunStatus.Running;
                        }
                    }
                    else
                    {
                        localizedName = Name;
                    }
                }
                else if (queueServerForItemSW.IsRunning)
                {
                    if (queueServerForItemSW.ElapsedMilliseconds < 5000)
                        return RunStatus.Running;
                    else
                    {
                        string localizedName = TradeSkillFrame.GetItemCacheName(itemID);
                        queueServerForItemSW.Stop();
                        queueServerForItemSW.Reset();
                        if (string.IsNullOrEmpty(localizedName))
                        {
                            Logging.Write(System.Drawing.Color.Red, "Failed to convert item ID {0} to its localized item name", itemID);
                            return RunStatus.Failure;
                        }
                    }
                }
                #endregion

                using (new FrameLock())
                {
                    if (Lua.GetReturnVal<int>("if AuctionFrame and AuctionFrame:IsVisible() then return 1 else return 0 end ", 0) == 0)
                    {
                        if (queueTimer.IsRunning)
                        {
                            queueTimer.Stop();
                            queueTimer.Reset();
                        }
                        WoWPoint movetoPoint = loc;
                        if (AutoFindAh || movetoPoint == WoWPoint.Zero)
                        {
                            auctioneer = ObjectManager.GetObjectsOfType<WoWUnit>().Where(o => o.IsAuctioneer && o.IsAlive)
                                .OrderBy(o => o.Distance).FirstOrDefault();
                        }
                        else
                        {
                            auctioneer = ObjectManager.GetObjectsOfType<WoWUnit>().Where(o => o.IsAuctioneer
                                && o.Location.Distance(loc) < 5)
                                .OrderBy(o => o.Distance).FirstOrDefault();
                        }
                        if (auctioneer != null)
                            movetoPoint = auctioneer.Location;
                        else if (movetoPoint == WoWPoint.Zero)
                            movetoPoint = MoveToAction.GetLocationFromDB(MoveToAction.MoveToType.NearestAH, 0);
                        if (movetoPoint == WoWPoint.Zero)
                        {
                            Logging.Write("Unable to location Auctioneer, Maybe he's dead?");

                        }
                        if (movetoPoint.Distance(ObjectManager.Me.Location) > 4.5)
                        {
                            Util.MoveTo(movetoPoint);
                        }
                        else if (auctioneer != null)
                        {
                            auctioneer.Interact();
                        }
                    }
                    else
                    {
                        if (!queueTimer.IsRunning)
                        {
                            string lua = string.Format("if AuctionFrame and AuctionFrame:IsVisible() then QueryAuctionItems(\"{0}\" ,nil,nil,nil,nil,nil,{1}) return 1 else return 0 end", localizedName, page);
                            bool queuedAH = Lua.GetReturnVal<bool>(lua, 0);
                            if (queuedAH)
                            {
                                queueTimer.Start();
                            }
                            Professionbuddy.Log("Searching AH for {0}", localizedName);
                        }
                        else if (queueTimer.ElapsedMilliseconds > 1000)
                        {
                            totalAuctions = Lua.GetReturnVal<int>("return GetNumAuctionItems('list')", 1);
                            if (totalAuctions > 0)
                            {
                                queueTimer.Stop();
                                queueTimer.Reset();
                                string lua = string.Format("local A,totalA= GetNumAuctionItems('list') local amountBought={0} local want={1} local each={3} for index=1, A do local name, _, count,_,_,_,minBid,_, buyoutPrice,_,_,_,_ = GetAuctionItemInfo('list', index) if string.upper(name) == string.upper(\"{2}\") and buyoutPrice > 0 and buyoutPrice <= each*count and amountBought < want then amountBought = amountBought + count PlaceAuctionBid('list', index, buyoutPrice) end if amountBought >=  want then return -1 end end return amountBought",
                                    counter, CalculatedAmount, localizedName, MaxBuyout.TotalCopper);
                                counter = Lua.GetReturnVal<int>(lua, 0);
                                if (counter == -1 || ++page >= (int)Math.Ceiling((double)totalAuctions / 50))
                                    IsDone = true;
                            }
                        }
                        else if (queueTimer.ElapsedMilliseconds > 10000)
                        {
                            IsDone = true;
                        }
                    }
                }
                if (!IsDone)
                    return RunStatus.Running;
            }
            return RunStatus.Failure;
        }
        public override void Reset()
        {
            base.Reset();
            queueServerForItemSW = null;
            counter = 0;
            totalAuctions = 0;
            queueTimer.Stop();
            queueTimer.Reset();
            page = 0;
        }
        public override string Name
        {
            get { return "Buy Item From AH"; }
        }
        public override string Title
        {
            get { return string.Format("{0}: {1} x{2}", Name, ItemName, CalculatedAmount); }
        }
        public override string Help
        {
            get
            {
                return "This action will buy a specific item that matches Name from the Auction house if item is below specified maximum price. It can be set to buy the amount needed by Recipes, or a specified amount.";
            }
        }
        public override object Clone()
        {
            return new BuyItemFromAhAction()
            {
                ItemName = this.ItemName,
                MaxBuyout = new PropertyBag.GoldEditor(this.MaxBuyout.ToString()),
                Amount = this.Amount,
                AmountType = this.AmountType,
                AutoFindAh = this.AutoFindAh
                ,
                Location = this.Location
            };
        }
        #region XmlSerializer
        public override void ReadXml(XmlReader reader)
        {
            ItemName = reader["ItemName"];
            uint val;
            MaxBuyout = new PropertyBag.GoldEditor(reader["MaxBuyout"]);
            uint.TryParse(reader["Amount"], out val);
            Amount = val;
            AmountType = (AmountBasedType)Enum.Parse(typeof(AmountBasedType), reader["AmountType"]);
            bool autofind;
            bool.TryParse(reader["AutoFindAh"], out autofind);
            AutoFindAh = autofind;
            float x, y, z;
            float.TryParse(reader["X"], out x);
            float.TryParse(reader["Y"], out y);
            float.TryParse(reader["Z"], out z);
            loc = new WoWPoint(x, y, z);
            Location = loc.ToString();
            reader.ReadStartElement();
        }
        public override void WriteXml(XmlWriter writer)
        {
            writer.WriteAttributeString("ItemName", ItemName.ToString());
            writer.WriteAttributeString("MaxBuyout", MaxBuyout.ToString());
            writer.WriteAttributeString("Amount", Amount.ToString());
            writer.WriteAttributeString("AmountType", AmountType.ToString());
            writer.WriteAttributeString("AutoFindAh", AutoFindAh.ToString());
            writer.WriteAttributeString("X", loc.X.ToString());
            writer.WriteAttributeString("Y", loc.Y.ToString());
            writer.WriteAttributeString("Z", loc.Z.ToString());
        }
        #endregion
    }
    #endregion
}
