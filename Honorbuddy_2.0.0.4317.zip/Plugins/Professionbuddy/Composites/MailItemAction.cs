﻿using System;
using System.ComponentModel;
using System.Drawing.Design;
using System.Linq;
using System.Xml;
using Styx;
using Styx.Logic.Inventory.Frames.MailBox;
using Styx.Logic.Pathing;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using TreeSharp;
using ObjectManager = Styx.WoWInternals.ObjectManager;

namespace HighVoltz.Composites
{
    #region MailItemAction
    class MailItemAction : PBAction
    {
        public enum MailItemActionType
        {
            AllItems,
            Specific,
        }
        public MailItemActionType MailItemType
        {
            get { return (MailItemActionType)Properties["MailItemType"].Value; }
            set { Properties["MailItemType"].Value = value; }
        }
        public uint Entry
        {
            get { return (uint)Properties["Entry"].Value; }
            set { Properties["Entry"].Value = value; }
        }
        public uint Count
        {
            get { return (uint)Properties["Count"].Value; }
            set { Properties["Count"].Value = value; }
        }
        public string Recipient
        {
            get { return (string)Properties["Recipient"].Value; }
            set { Properties["Recipient"].Value = value; }
        }
        public bool AutoFindMailBox
        {
            get { return (bool)Properties["AutoFindMailBox"].Value; }
            set { Properties["AutoFindMailBox"].Value = value; }
        }

        WoWPoint loc;
        public string Location
        {
            get { return (string)Properties["Location"].Value; }
            set { Properties["Location"].Value = value; }
        }
        public MailItemAction()
        {
            Properties["Entry"] = new MetaProp("Entry", typeof(uint));
            Properties["Count"] = new MetaProp("Count", typeof(uint));
            Properties["MailItemType"] = new MetaProp("MailItemType", typeof(MailItemActionType), new DisplayNameAttribute("Mail Items"));
            Properties["Recipient"] = new MetaProp("Recipient", typeof(string));
            Properties["AutoFindMailBox"] = new MetaProp("AutoFindMailBox", typeof(bool), new DisplayNameAttribute("Automatically find Mailbox"));
            Properties["Location"] = new MetaProp("Location", typeof(string), new EditorAttribute(typeof(PropertyBag.LocationEditor), typeof(UITypeEditor)));

            Properties["Entry"].Value = 0u;
            Properties["Count"].Value = 0u;
            Properties["MailItemType"].Value = (MailItemActionType)MailItemActionType.AllItems;
            Properties["Recipient"].Value = "";
            Properties["AutoFindMailBox"].Value = true;
            loc = WoWPoint.Zero;
            Properties["Location"].Value = loc.ToString();

            Properties["Count"].Show = false;
            Properties["Location"].Show = false;
            Properties["MailItemType"].PropertyChanged += new EventHandler(MailItemAction_PropertyChanged);
            Properties["AutoFindMailBox"].PropertyChanged += new EventHandler(AutoFindMailBoxChanged);
            Properties["Location"].PropertyChanged += new EventHandler(LocationChanged);
        }
        void LocationChanged(object sender, EventArgs e)
        {
            MetaProp mp = (MetaProp)sender;
            loc = Util.StringToWoWPoint((string)((MetaProp)sender).Value);
            Properties["Location"].PropertyChanged -= new EventHandler(LocationChanged);
            Properties["Location"].Value = string.Format("<{0}, {1}, {2}>", loc.X, loc.Y, loc.Z);
            Properties["Location"].PropertyChanged += new EventHandler(LocationChanged);
            RefreshPropertyGrid();
        }

        void AutoFindMailBoxChanged(object sender, EventArgs e)
        {
            if (AutoFindMailBox)
                Properties["Location"].Show = false;
            else
                Properties["Location"].Show = true;
            RefreshPropertyGrid();
        }
        void MailItemAction_PropertyChanged(object sender, EventArgs e)
        {
            switch (MailItemType)
            {
                case MailItemActionType.AllItems:
                    Properties["Count"].Show = false;
                    break;
                default:
                    Properties["Count"].Show = true;
                    break;
            }
            RefreshPropertyGrid();
        }

        uint itemsSend = 0;
        bool usedSplit = false;
        WoWGameObject mailbox;
        protected override RunStatus Run(object context)
        {
            if (!IsDone)
            {
                WoWPoint movetoPoint = loc;
                if (MailFrame.Instance == null || !MailFrame.Instance.IsVisible)
                {
                    if (AutoFindMailBox || movetoPoint == WoWPoint.Zero)
                    {
                        mailbox = ObjectManager.GetObjectsOfType<WoWGameObject>().Where(o => o.SubType == WoWGameObjectType.Mailbox)
                            .OrderBy(o => o.Distance).FirstOrDefault();
                    }
                    else
                    {
                        mailbox = ObjectManager.GetObjectsOfType<WoWGameObject>().Where(o => o.SubType == WoWGameObjectType.Mailbox
                            && o.Location.Distance(loc) < 10)
                            .OrderBy(o => o.Distance).FirstOrDefault();
                    }
                    if (mailbox != null)
                        movetoPoint = mailbox.Location;
                    if (movetoPoint == WoWPoint.Zero)
                        return RunStatus.Failure;
                    if (movetoPoint.Distance(ObjectManager.Me.Location) > 4.5)
                        Util.MoveTo(movetoPoint);
                    else if (mailbox != null)
                        mailbox.Interact();
                    return RunStatus.Running;
                }
                else
                {
                    if (MailItemType == MailItemActionType.AllItems)
                    {
                        WoWItem[] items = ObjectManager.Me.BagItems.Where(i => i.IsValid && i.Entry == Entry).Take(12).ToArray();
                        if (items == null || items.Length == 0)
                        {
                            IsDone = true;
                            return RunStatus.Failure;
                        }
                        using (new FrameLock())
                        {
                            MailFrame.Instance.SwitchToSendMailTab();
                            foreach (WoWItem item in items)
                            {
                                item.UseContainerItem();
                            }
                            Lua.DoString(string.Format("SendMail ('{0}','','');SendMailMailButton:Click();", Recipient));
                        }
                    }
                    else
                    {
                        using (new FrameLock())
                        {
                            WoWItem[] items = ObjectManager.Me.BagItems.Where(i => i.IsValid && i.Entry == Entry).Take(12).ToArray();
                            if (items == null || items.Length == 0)
                            {
                                IsDone = true;
                                return RunStatus.Failure;
                            }
                            MailFrame.Instance.SwitchToSendMailTab();
                            foreach (WoWItem item in items)
                            {
                                if (((item.StackCount <= Count - itemsSend) && !usedSplit) ||
                                    (item.StackCount == Count - itemsSend) && usedSplit)
                                {
                                    item.UseContainerItem();
                                    itemsSend += item.StackCount;
                                }
                                else
                                {
                                    if (!usedSplit)
                                    {
                                        string lua = string.Format("SplitContainerItem({0},{1},{2}) for bag = 0, 4 do local f,t =GetContainerNumFreeSlots(bag) if f > 0 and t == 0 then for slot = 1, GetContainerNumSlots(bag) do local _,c,l=GetContainerItemInfo(bag, slot) print (c,l) if c==nil and l~=1 then PickupContainerItem(bag, slot) break end end end end ",
                                            item.BagIndex + 1, item.BagSlot + 1, Count - itemsSend);
                                        Lua.DoString(lua);
                                        usedSplit = true;
                                    }
                                }
                            }
                            if (itemsSend >= Count)
                            {
                                itemsSend = 0;
                                usedSplit = false;
                                Lua.DoString(string.Format("SendMail ('{0}','','');SendMailMailButton:Click();", Recipient));
                                IsDone = true;
                            }
                        }
                    }
                    if (!IsDone)
                        return RunStatus.Running;
                }
            }
            return RunStatus.Failure;
        }
        public override void Reset()
        {
            base.Reset();
            usedSplit = false;
            itemsSend = 0;
        }
        public override string Name
        {
            get
            {
                return "Mail Item";
            }
        }
        public override string Title
        {
            get
            {
                return string.Format("{0}: to:{1} " +
                    (MailItemType == MailItemActionType.AllItems ? "All Items" : "{2} x{3}"), Name, Recipient, Entry, Count);
            }
        }
        public override string Help
        {
            get
            {
                return "This action will mail either all items that match the specific ID or a specific amount. Note: Count = axact number, not stacks";
            }
        }
        public override object Clone()
        {
            return new MailItemAction()
            {
                Count = this.Count,
                Entry = this.Entry,
                MailItemType = this.MailItemType,
                Recipient = this.Recipient,
                loc = this.loc,
                AutoFindMailBox = this.AutoFindMailBox,
                Location = this.Location
            };
        }
        #region XmlSerializer
        public override void ReadXml(XmlReader reader)
        {
            uint num;
            uint.TryParse(reader["Entry"], out num);
            Entry = num;
            uint.TryParse(reader["Count"], out num);
            Count = num;
            MailItemType = (MailItemActionType)Enum.Parse(typeof(MailItemActionType), reader["MailItemType"]);
            Recipient = reader["Recipient"];
            bool autofind;
            bool.TryParse(reader["AutoFindMailBox"], out autofind);
            AutoFindMailBox = autofind;
            float x, y, z;
            float.TryParse(reader["X"], out x);
            float.TryParse(reader["Y"], out y);
            float.TryParse(reader["Z"], out z);
            loc = new WoWPoint(x, y, z);
            Location = loc.ToString();
            reader.ReadStartElement();
        }
        public override void WriteXml(XmlWriter writer)
        {
            writer.WriteAttributeString("Entry", Entry.ToString());
            writer.WriteAttributeString("Count", Count.ToString());
            writer.WriteAttributeString("MailItemType", MailItemType.ToString());
            writer.WriteAttributeString("Recipient", Recipient);
            writer.WriteAttributeString("AutoFindMailBox", AutoFindMailBox.ToString());
            writer.WriteAttributeString("X", loc.X.ToString());
            writer.WriteAttributeString("Y", loc.Y.ToString());
            writer.WriteAttributeString("Z", loc.Z.ToString());
        }
        #endregion
    }
    #endregion

}
