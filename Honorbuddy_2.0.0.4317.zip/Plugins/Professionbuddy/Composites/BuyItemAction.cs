﻿using System;
using System.ComponentModel;
using System.Xml;
using Styx.Logic.Inventory.Frames.Gossip;
using Styx.Logic.Inventory.Frames.Merchant;
using TreeSharp;

namespace HighVoltz.Composites
{
    #region BuyItemAction
    class BuyItemAction : PBAction
    {
        public enum BuyItemActionType
        {
            SpecificItem,
            Material,
        }
        public uint Entry
        {
            get { return (uint)Properties["Entry"].Value; }
            set { Properties["Entry"].Value = value; }
        }
        public BuyItemActionType BuyItemType
        {
            get { return (BuyItemActionType)Properties["BuyItemType"].Value; }
            set { Properties["BuyItemType"].Value = value; }
        }
        public uint Count
        {
            get { return (uint)Properties["Count"].Value; }
            set { Properties["Count"].Value = value; }
        }
        public BuyItemAction()
        {
            Properties["Entry"] = new MetaProp("Entry", typeof(uint));
            Properties["Count"] = new MetaProp("Count", typeof(uint));
            Properties["BuyItemType"] = new MetaProp("BuyItemType", typeof(BuyItemActionType), new DisplayNameAttribute("Buy"));
            Properties["Entry"].Value = 0u;
            Properties["Count"].Value = 0u;
            Properties["BuyItemType"].Value = BuyItemActionType.Material;
            Properties["Entry"].Show = false;
            Properties["Count"].Show = false;
            Properties["BuyItemType"].PropertyChanged += new EventHandler(BuyItemAction_PropertyChanged);
        }

        void BuyItemAction_PropertyChanged(object sender, EventArgs e)
        {
            switch (BuyItemType)
            {
                case BuyItemActionType.Material:
                    Properties["Entry"].Show = false;
                    Properties["Count"].Show = false;
                    break;
                case BuyItemActionType.SpecificItem:
                    Properties["Entry"].Show = true;
                    Properties["Count"].Show = true;
                    break;
            }
            RefreshPropertyGrid();
        }
        
        protected override RunStatus Run(object context)
        {
            if (!IsDone)
            {
                if (GossipFrame.Instance != null && GossipFrame.Instance.IsVisible)
                {
                    foreach (GossipEntry ge in GossipFrame.Instance.GossipOptionEntries)
                    {
                        if (ge.Type == GossipEntry.GossipEntryType.Vendor)
                        {
                            GossipFrame.Instance.SelectGossipOption(ge.Index);
                            break;
                        }
                    }
                }
                if (MerchantFrame.Instance != null && MerchantFrame.Instance.IsVisible)
                {
                    if (BuyItemType == BuyItemActionType.SpecificItem)
                    {
                        buyItem(Entry, Count);
                    }
                    else if (BuyItemType == BuyItemActionType.Material)
                    {
                        foreach (var kv in Pb.MaterialList)
                            buyItem(kv.Key, (uint)kv.Value);
                    }
                    Professionbuddy.Log("BuyItemAction Completed ");
                    IsDone = true;
                }
                if (!IsDone)
                    return RunStatus.Running;
            }
            return RunStatus.Failure;
        }
        static public void buyItem(uint id, uint count)
        {
            bool found = false;
            foreach (MerchantItem mi in MerchantFrame.Instance.GetAllMerchantItems())
            {
                if (mi.ItemId == id)
                {
                    MerchantFrame.Instance.BuyItem(mi.Index, (int)Math.Ceiling((double)count / mi.Quantity));
                    found = true;
                    break;
                }
            }
            Professionbuddy.Log("item {0} {1}", id, found? "bought ":"not found");
        }
        public override string Name
        {
            get { return "Buy Item"; }
        }
        public override string Title
        {
            get { return string.Format("{0}: " + (BuyItemType == BuyItemActionType.SpecificItem ? "{1} x{2}" : "{3}"), Name, Entry, Count, BuyItemType); }
        }
        public override string Help
        {
            get
            {
                return "This action will buy items from a merchant frame, either a specific item or any materials the NPC has that are needed for recipes in the action tree";
            }
        }
        public override object Clone()
        {
            return new BuyItemAction() { Count = this.Count, Entry = this.Entry, BuyItemType = this.BuyItemType };
        }
        #region XmlSerializer
        public override void ReadXml(XmlReader reader)
        {
            uint num;
            uint.TryParse(reader["Entry"], out num);
            Entry = num;
            uint.TryParse(reader["Count"], out num);
            Count = num;
            BuyItemType = (BuyItemActionType)Enum.Parse(typeof(BuyItemActionType), reader["BuyItemType"]);
            reader.ReadStartElement();
        }
        public override void WriteXml(XmlWriter writer)
        {
            writer.WriteAttributeString("Entry", Entry.ToString());
            writer.WriteAttributeString("Count", Count.ToString());
            writer.WriteAttributeString("BuyItemType", BuyItemType.ToString());
        }
        #endregion
    }
    #endregion
}
