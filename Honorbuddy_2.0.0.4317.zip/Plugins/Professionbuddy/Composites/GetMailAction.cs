﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing.Design;
using System.Linq;
using System.Xml;
using Styx;
using Styx.Logic.Inventory.Frames.MailBox;
using Styx.Logic.Pathing;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using TreeSharp;
using ObjectManager = Styx.WoWInternals.ObjectManager;


namespace HighVoltz.Composites
{
    #region GetMailAction
    class GetMailAction : PBAction
    {
        public enum GetMailActionType
        {
            AllItems,
            Specific,
        }
        public GetMailActionType GetMailType
        {
            get { return (GetMailActionType)Properties["GetMailType"].Value; }
            set { Properties["GetMailType"].Value = value; }
        }
        public uint Entry
        {
            get { return (uint)Properties["Entry"].Value; }
            set { Properties["Entry"].Value = value; }
        }
        public bool AutoFindMailBox
        {
            get { return (bool)Properties["AutoFindMailBox"].Value; }
            set { Properties["AutoFindMailBox"].Value = value; }
        }
        WoWPoint loc;
        public string Location
        {
            get { return (string)Properties["Location"].Value; }
            set { Properties["Location"].Value = value; }
        }
        public GetMailAction()
        {
            Properties["Entry"] = new MetaProp("Entry", typeof(uint));
            Properties["GetMailType"] = new MetaProp("GetMailType", typeof(GetMailActionType), new DisplayNameAttribute("Get Mail"));
            Properties["AutoFindMailBox"] = new MetaProp("AutoFindMailBox", typeof(bool), new DisplayNameAttribute("Auto find Mailbox"));
            Properties["Location"] = new MetaProp("Location", typeof(string), new EditorAttribute(typeof(PropertyBag.LocationEditor), typeof(UITypeEditor)));

            Properties["Entry"].Value = 0u;
            Properties["GetMailType"].Value = (GetMailActionType)GetMailActionType.AllItems;
            Properties["AutoFindMailBox"].Value = true;
            loc = WoWPoint.Zero;
            Properties["Location"].Value = loc.ToString();

            Properties["GetMailType"].PropertyChanged += new EventHandler(GetMailAction_PropertyChanged);
            Properties["AutoFindMailBox"].PropertyChanged += new EventHandler(AutoFindMailBoxChanged);
            Properties["Entry"].Show = false;
            Properties["Location"].Show = false;
            Properties["Location"].PropertyChanged += new EventHandler(LocationChanged);
        }
        void LocationChanged(object sender, EventArgs e)
        {
            MetaProp mp = (MetaProp)sender;
            loc = Util.StringToWoWPoint((string)((MetaProp)sender).Value);
            Properties["Location"].PropertyChanged -= new EventHandler(LocationChanged);
            Properties["Location"].Value = string.Format("<{0}, {1}, {2}>", loc.X, loc.Y, loc.Z);
            Properties["Location"].PropertyChanged += new EventHandler(LocationChanged);
            RefreshPropertyGrid();
        }

        void AutoFindMailBoxChanged(object sender, EventArgs e)
        {
            if (AutoFindMailBox)
                Properties["Location"].Show = false;
            else
                Properties["Location"].Show = true;
            RefreshPropertyGrid();
        }
        void GetMailAction_PropertyChanged(object sender, EventArgs e)
        {
            if (GetMailType == GetMailActionType.AllItems)
                Properties["Entry"].Show = false;
            else
                Properties["Entry"].Show = true;
            RefreshPropertyGrid();
        }
        WoWGameObject mailbox;
        Stopwatch WaitForContentToShowSW = new Stopwatch();
        protected override RunStatus Run(object context)
        {
            if (!IsDone)
            {
                WoWPoint movetoPoint = loc;
                if (MailFrame.Instance == null || !MailFrame.Instance.IsVisible)
                {
                    if (AutoFindMailBox || movetoPoint == WoWPoint.Zero)
                    {
                        mailbox = ObjectManager.GetObjectsOfType<WoWGameObject>().Where(o => o.SubType == WoWGameObjectType.Mailbox)
                            .OrderBy(o => o.Distance).FirstOrDefault();
                    }
                    else
                    {
                        mailbox = ObjectManager.GetObjectsOfType<WoWGameObject>().Where(o => o.SubType == WoWGameObjectType.Mailbox
                            && o.Location.Distance(loc) < 10)
                            .OrderBy(o => o.Distance).FirstOrDefault();
                    }
                    if (mailbox != null)
                        movetoPoint = mailbox.Location;
                    if (movetoPoint == WoWPoint.Zero)
                        return RunStatus.Failure;
                    if (movetoPoint.Distance(ObjectManager.Me.Location) > 4.5)
                        Util.MoveTo(movetoPoint);
                    else if (mailbox != null)
                        mailbox.Interact();
                    return RunStatus.Running;
                }
                else
                {
                    if (!WaitForContentToShowSW.IsRunning)
                        WaitForContentToShowSW.Start();
                    if (WaitForContentToShowSW.ElapsedMilliseconds < 3000)
                        return RunStatus.Running;
                    if (GetMailType == GetMailActionType.AllItems)
                    {
                        string lua = "local totalItems,numItems = GetInboxNumItems() local foundMail=0 for index=1,numItems do local _,_,sender,subj,gold,cod,_,itemCnt=GetInboxHeaderInfo(index) if cod == 0 and ((itemCnt and itemCnt >0) or (gold and gold > 0)) then AutoLootMailItem(index) foundMail = 1 break end end local beans = BeanCounterMail and BeanCounterMail:IsVisible() if foundMail == 0 and totalItems == numItems and beans ~= 1 then return 1 else return 0 end ";
                        if (Lua.GetReturnValues(lua)[0] == "1" || ObjectManager.Me.FreeNormalBagSlots <= 2)
                            IsDone = true;
                    }
                    else
                    {
                        string lua = string.Format("local totalItems,numItems = GetInboxNumItems() local foundMail = 0 for index=1, numItems do local _,_,sender,subj,gold,cod,_,itemCnt=GetInboxHeaderInfo(index) if cod == 0 and itemCnt and itemCnt >0  then for i2=1,itemCnt do local itemlink = GetInboxItemLink(index, i2) if string.find(itemlink,'{0}') then foundMail =1 TakeInboxItem(index, i2) break end end end end if foundMail == 0 and (numItems == totalItems) or (numItems == 50 and totalItems > 50)then return 1; else return 0 end ", Entry);
                        if (Lua.GetReturnValues(lua)[0] == "1" || ObjectManager.Me.FreeNormalBagSlots <= 2)
                            IsDone = true;
                    }
                    if (!IsDone)
                        return RunStatus.Running;
                }
            }
            return RunStatus.Failure;
        }
        public override void Reset()
        {
            base.Reset();
            WaitForContentToShowSW.Stop();
            WaitForContentToShowSW.Reset();
        }
        public override string Name
        {
            get
            {
                return "Get Mail";
            }
        }
        public override string Title
        {
            get
            {
                return string.Format("{0}: {1} " + (GetMailType == GetMailActionType.Specific ? " - " +
                    Entry.ToString() : ""), Name, GetMailType);
            }
        }
        public override string Help
        {
            get
            {
                return "This action retrieve all mail in the mailbox, or only items that match the ID. Use the MoveTo and Interact actions to go to and open the mail frame";
            }
        }
        public override object Clone()
        {
            return new GetMailAction()
            {
                Entry = this.Entry,
                GetMailType = this.GetMailType,
                loc = this.loc,
                AutoFindMailBox = this.AutoFindMailBox,
                Location = this.Location
            };
        }
        #region XmlSerializer
        public override void ReadXml(XmlReader reader)
        {
            uint num;
            uint.TryParse(reader["Entry"], out num);
            Entry = num;
            GetMailType = (GetMailActionType)Enum.Parse(typeof(GetMailActionType), reader["GetMailType"]);
            bool autofind;
            bool.TryParse(reader["AutoFindMailBox"], out autofind);
            AutoFindMailBox = autofind;
            float x, y, z;
            float.TryParse(reader["X"], out x);
            float.TryParse(reader["Y"], out y);
            float.TryParse(reader["Z"], out z);
            loc = new WoWPoint(x, y, z);
            Location = loc.ToString();
            reader.ReadStartElement();
        }
        public override void WriteXml(XmlWriter writer)
        {
            writer.WriteAttributeString("Entry", Entry.ToString());
            writer.WriteAttributeString("GetMailType", GetMailType.ToString());
            writer.WriteAttributeString("AutoFindMailBox", AutoFindMailBox.ToString());
            writer.WriteAttributeString("X", loc.X.ToString());
            writer.WriteAttributeString("Y", loc.Y.ToString());
            writer.WriteAttributeString("Z", loc.Z.ToString());
        }
        #endregion
    }
    #endregion
}
