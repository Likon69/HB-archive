﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing.Design;
using System.Linq;
using System.Text.RegularExpressions;
using System.Xml;
using System.IO;
using System.Globalization;
using Styx;
using Styx.Logic;
using Styx.Database;
using Styx.Helpers;
using Styx.Logic.Pathing;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using TreeSharp;
using Styx.Logic.Profiles;
using Styx.Logic.BehaviorTree;
using System.Reflection;
using ObjectManager = Styx.WoWInternals.ObjectManager;

//using Flightor = Styx.Logic.Pathing.Flightor;

namespace HighVoltz.Composites
{
    #region FlyToAction
    public class FlyToAction : PBAction
    {
        delegate void FlightorFlyTo(WoWPoint point);
        static FlightorFlyTo flyTo = null;
        void FlyTo(WoWPoint point)
        {
            if (flyTo == null)
            {
                Assembly asm = AppDomain.CurrentDomain.GetAssemblies().
                    FirstOrDefault(a => a.GetName().Name == "Gatherbuddy2");
                Type flightor = asm.GetType("Styx.Logic.Pathing.Flightor");
                flyTo = (FlightorFlyTo)Delegate.CreateDelegate(typeof(FlightorFlyTo), 
                    flightor.GetMethod("MoveTo", new Type[] { typeof(WoWPoint) }));
            }
            flyTo(point);
        }
        public bool Dismount
        {
            get { return (bool)Properties["Dismount"].Value; }
            set { Properties["Dismount"].Value = value; }
        }
        WoWPoint loc;
        public string Location
        {
            get { return (string)Properties["Location"].Value; }
            set { Properties["Location"].Value = value; }
        }
        public FlyToAction()
        {
            Properties["Dismount"] = new MetaProp("Dismount", typeof(bool), new DisplayNameAttribute("Dismount on Arrival"));
            Properties["Location"] = new MetaProp("Location", typeof(string), new EditorAttribute(typeof(PropertyBag.LocationEditor), typeof(UITypeEditor)));

            Properties["Location"].Value = loc.ToString();
            Properties["Dismount"].Value = true;

            Properties["Location"].PropertyChanged += new EventHandler(LocationChanged);
        }

        void LocationChanged(object sender, EventArgs e)
        {
            MetaProp mp = (MetaProp)sender;
            loc = Util.StringToWoWPoint((string)((MetaProp)sender).Value);
            Properties["Location"].PropertyChanged -= new EventHandler(LocationChanged);
            Properties["Location"].Value = string.Format("<{0}, {1}, {2}>", loc.X, loc.Y, loc.Z);
            Properties["Location"].PropertyChanged += new EventHandler(LocationChanged);
            RefreshPropertyGrid();
        }

        protected override RunStatus Run(object context)
        {
            if (!IsDone)
            {
                if (ObjectManager.Me.Location.Distance(loc) > 6)
                {
                    FlyTo(loc);
                    TreeRoot.StatusText = string.Format("Flying to location {0}", loc);
                }
                else
                {
                    if (Dismount)
                        Mount.Dismount();
                    IsDone = true;
                    TreeRoot.StatusText = string.Format("Arrived at location {0}", loc);
                    return RunStatus.Success;
                }
                return RunStatus.Running;
            }
            return RunStatus.Failure;
        }

        void WriteProfile(WoWPoint point,string file)
        {
            System.Text.UTF8Encoding encoding = new System.Text.UTF8Encoding();
            FileStream fs = File.Open(file, FileMode.Create);
            string buf = string.Format("<HBProfile>\n<Hotspots>\n{0}\n</Hotspots>\n</HBProfile>\n", 
                string.Format(CultureInfo.InvariantCulture, "<Hotspot X=\"{0}\" Y=\"{1}\" Z=\"{2}\" />", point.X, point.Y, point.Z));
            fs.Write(encoding.GetBytes(buf), 0, buf.Length);
            fs.Close();
        }

        public override string Name { get { return "Fly To"; } }
        public override string Title
        {
            get
            {
                return string.Format("{0}: {1} ",Name,Location);
            }
        }
        public override string Help
        {
            get
            {
                return "(Needs to be in GB2 installed) This action will fly your character to the selected location and dismount on arrival if Dismount is set to true.";
            }
        }
        public override object Clone()
        {
            return new FlyToAction() {Location = this.Location, Dismount = this.Dismount};
        }

        public override void Reset()
        {
            base.Reset();
        }

        #region XmlSerializer
        public override void ReadXml(XmlReader reader)
        {
            bool dismount;
            bool.TryParse(reader["Dismount"], out dismount);
            Dismount = dismount;
            float x, y, z;
            float.TryParse(reader["X"], out x);
            float.TryParse(reader["Y"], out y);
            float.TryParse(reader["Z"], out z);
            loc = new WoWPoint(x, y, z);
            Location = loc.ToString();
            reader.ReadStartElement();
        }
        public override void WriteXml(XmlWriter writer)
        {
            writer.WriteAttributeString("Dismount", Dismount.ToString());
            writer.WriteAttributeString("X", loc.X.ToString());
            writer.WriteAttributeString("Y", loc.Y.ToString());
            writer.WriteAttributeString("Z", loc.Z.ToString());
        }
        #endregion
    }
    #endregion
}
