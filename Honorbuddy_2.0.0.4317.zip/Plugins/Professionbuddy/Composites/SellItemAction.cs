﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Xml;
using Styx;
using Styx.Logic.Inventory.Frames.Gossip;
using Styx.Logic.Inventory.Frames.Merchant;
using Styx.WoWInternals.WoWObjects;
using TreeSharp;
using ObjectManager = Styx.WoWInternals.ObjectManager;

namespace HighVoltz.Composites
{
    #region SellItemAction
    class SellItemAction : PBAction
    {
        public enum SellItemActionType
        {
            Specific,
            Greys,
            Whites,
            Greens,
        }
        public SellItemActionType SellItemType
        {
            get { return (SellItemActionType)Properties["SellItemType"].Value; }
            set { Properties["SellItemType"].Value = value; }
        }
        public uint Entry
        {
            get { return (uint)Properties["Entry"].Value; }
            set { Properties["Entry"].Value = value; }
        }
        public uint Count
        {
            get { return (uint)Properties["Count"].Value; }
            set { Properties["Count"].Value = value; }
        }
        public SellItemAction()
        {
            Properties["Entry"] = new MetaProp("Entry", typeof(uint));
            Properties["Count"] = new MetaProp("Count", typeof(uint));
            Properties["SellItemType"] = new MetaProp("SellItemType", typeof(SellItemActionType), new DisplayNameAttribute("Sell Item Type"));
            Properties["Entry"].Value = 0u;
            Properties["Count"].Value = 0u;
            Properties["SellItemType"].Value = SellItemActionType.Specific;
            Properties["SellItemType"].PropertyChanged += new EventHandler(SellItemAction_PropertyChanged);
        }
        void SellItemAction_PropertyChanged(object sender, EventArgs e)
        {
            switch (SellItemType)
            {
                case SellItemActionType.Specific:
                    Properties["Count"].Show = true;
                    Properties["Entry"].Show = true;
                    break;
                default:
                    Properties["Count"].Show = false;
                    Properties["Entry"].Show = false;
                    break;
            }
            RefreshPropertyGrid();
        }
        protected override RunStatus Run(object context)
        {
            if (!IsDone)
            {
                if (GossipFrame.Instance != null && GossipFrame.Instance.IsVisible)
                {
                    foreach (GossipEntry ge in GossipFrame.Instance.GossipOptionEntries)
                    {
                        if (ge.Type == GossipEntry.GossipEntryType.Vendor)
                        {
                            GossipFrame.Instance.SelectGossipOption(ge.Index);
                            return RunStatus.Running;
                        }
                    }
                }
                if (MerchantFrame.Instance != null && MerchantFrame.Instance.IsVisible)
                {
                    if (SellItemType == SellItemActionType.Specific)
                    {
                        WoWItem item = ObjectManager.Me.BagItems.FirstOrDefault(u => u.Entry == Entry);
                        if (item != null)
                        {
                            using (new FrameLock())
                            {
                                for (int i = 0; i < Count; i++)
                                    item.UseContainerItem();
                            }
                        }
                    }
                    else
                    {
                        List<WoWItem> itemList = null;
                        switch (SellItemType)
                        {
                            case SellItemActionType.Greys:
                                itemList = ObjectManager.Me.BagItems.Where(i => i.Quality == WoWItemQuality.Poor).ToList();
                                break;
                            case SellItemActionType.Whites:
                                itemList = ObjectManager.Me.BagItems.Where(i => i.Quality == WoWItemQuality.Common).ToList();
                                break;
                            case SellItemActionType.Greens:
                                itemList = ObjectManager.Me.BagItems.Where(i => i.Quality == WoWItemQuality.Uncommon).ToList();
                                break;
                        }
                        if (itemList != null)
                        {
                            using (new FrameLock())
                            {
                                foreach (WoWItem item in itemList)
                                {
                                    item.UseContainerItem();
                                }
                            }
                        }
                    }
                    Professionbuddy.Log("SellItemAction Completed ");
                    IsDone = true;
                }
            }
            return RunStatus.Failure;
        }
        public override string Name
        {
            get { return "Sell Item"; }
        }
        public override string Title
        {
            get
            {
                return string.Format("({0}) " +
                  (SellItemType == SellItemActionType.Specific ? Entry.ToString() + " x{1} " : SellItemType.ToString()), Name, Count);
            }
        }
        public override string Help
        {
            get
            {
                return "This action will sell items to a merchant. It will either sell a specified item x Count stacks, or sell all grey/white/green quality items";
            }
        }
        public override object Clone()
        {
            return new SellItemAction() { Count = this.Count, Entry = this.Entry, SellItemType = this.SellItemType };
        }
        #region XmlSerializer
        public override void ReadXml(XmlReader reader)
        {
            uint num;
            uint.TryParse(reader["Entry"], out num);
            Entry = num;
            uint.TryParse(reader["Count"], out num);
            Count = num;
            SellItemType = (SellItemActionType)Enum.Parse(typeof(SellItemActionType), reader["SellItemType"]);
            reader.ReadStartElement();
        }
        public override void WriteXml(XmlWriter writer)
        {
            writer.WriteAttributeString("Entry", Entry.ToString());
            writer.WriteAttributeString("Count", Count.ToString());
            writer.WriteAttributeString("SellItemType", SellItemType.ToString());
        }
        #endregion

    }
    #endregion
}
