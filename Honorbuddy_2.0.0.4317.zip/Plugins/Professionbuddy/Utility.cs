﻿using System;
using System.Text;
using System.Text.RegularExpressions;
using Styx.Helpers;
using Styx.Logic;
using Styx.Logic.Pathing;
using Styx.Logic.POI;
using System.Linq;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using ObjectManager = Styx.WoWInternals.ObjectManager;

namespace HighVoltz
{
    /// <summary>
    /// Utility functions
    /// </summary>
    public static class Util
    {
        /// <summary>
        ///  Random Number Genorator
        /// </summary>
        public static System.Random Rng = new Random(Environment.TickCount);
        /// <summary>
        /// Creates a random upper/lowercase string
        /// </summary>
        /// <returns>Random String</returns>
        public static string RandomString
        {
            get
            {
                int size = Rng.Next(6, 15);
                StringBuilder sb = new StringBuilder(size);
                for (int i = 0; i < size; i++)
                {
                    // random upper/lowercase character using ascii code
                    sb.Append((char)(Rng.Next(2) == 1 ? Rng.Next(65, 91) + 32 : Rng.Next(65, 91)));
                }
                return sb.ToString();
            }
        }

        public static void MoveTo(WoWPoint point)
        {// tempFix
            if (BotPoi.Current.Type != PoiType.None)
                BotPoi.Clear();
            //if (!ObjectManager.Me.Mounted && MountHelper.GroundMounts.Count > 0 && Mount.CanMount() && 
            //    Styx.Helpers.LevelbotSettings.Instance.UseMount && ObjectManager.Me.Location.Distance(point) > 35)
            if (!ObjectManager.Me.Mounted)
                Mount.MountUp();
            Navigator.MoveTo(point);
        }

        static public WoWPoint StringToWoWPoint(string location)
        {
            WoWPoint loc = WoWPoint.Zero;
            Regex pattern = new Regex(@"-?\d+\.?(\d+)?");
            MatchCollection matches = pattern.Matches(location);
            if (matches != null)
            {
                loc.X = matches.Count > 0 ? (matches[0].ToString()).ToFloat() : 0;
                loc.Y = matches.Count > 1 ? (matches[1].ToString()).ToFloat() : 0;
                loc.Z = matches.Count > 2 ? (matches[2].ToString()).ToFloat() : 0;
            }
            return loc;
        }

        public static uint GetBankItemCount(uint itemID, uint inbagsCount)
        {
            uint count = 0;
            ObjectManager.GetObjectsOfType<WoWItem>().Where(o =>
            {
                if (o != null && o.IsValid && o.Entry == itemID)
                {
                    count += o.StackCount;
                    return true;
                }
                return false;
            }).ToList();
            return count - inbagsCount;
        }
    }
}
