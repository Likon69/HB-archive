﻿//#define USE_DUNGEONBUDDY_DLL
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Styx;
using Styx.CommonBot;
using Styx.TreeSharp;
using Styx.Pathing;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using Action = Styx.TreeSharp.Action;

#if USE_DUNGEONBUDDY_DLL
using Bots.DungeonBuddyDll;
using Bots.DungeonBuddyDll.Profiles;
using Bots.DungeonBuddyDll.Attributes;
using Bots.DungeonBuddyDll.Helpers;


namespace Bots.DungeonBuddyDll.Dungeon_Scripts.Classic
#else
using Bots.DungeonBuddy.Profiles;
using Bots.DungeonBuddy.Attributes;
using Bots.DungeonBuddy.Helpers;
namespace Bots.DungeonBuddy.Dungeon_Scripts.Classic
#endif
{
    public class ScarletMonastery : Dungeon
    {
        #region Overrides of Dungeon

        public override uint DungeonId { get { return 164; } }

        public override WoWPoint Entrance { get { return new WoWPoint(2920.317, -799.8921, 160.3323); } }
        public override WoWPoint ExitLocation
        {
            get { return new WoWPoint(1124.471, 504.2796, 0.9892024); }
        }

        public override void RemoveTargetsFilter(List<WoWObject> units)
        {
            units.RemoveAll(
                ret =>
                {
                    var unit = ret as WoWUnit;
                    if (unit != null)
                    {
                        if (unit.Entry == TrainingDummyId || unit.Entry == TrainingDummyId2)
                            return true;
                        // ignore npcs that are fighting other npcs
                        if ((unit.Entry == ScarletCenturionId || unit.Entry == ZombifiedCorpseId || unit.Entry == PileOfCorpsesId) && !unit.TaggedByMe && unit.Combat && Me.Combat)
                            return true;
                        // ignore brother korloff if he's near other unfriendlies
                        if (unit.Entry == BrotherKorloff && !unit.Combat && ScriptHelpers.GetUnfriendlyNpsAtLocation(() => unit.Location, 25, u => u.Entry != BrotherKorloff).Any())
                            return true;
                        // ignore brother korloff if I'm melee and he's casting firestorm kick
                        if (unit.Entry == BrotherKorloff && unit.CastingSpellId == FirestormKickId && Me.IsMelee())
                            return true;
                        // kill this zealot before engaging CommanderDurand
                        if (unit.Entry == CommanderDurand && !unit.Combat && ScriptHelpers.GetUnfriendlyNpsAtLocation(() => _scarletZealotLoc, 4, u => u.Entry == ScarletZealot).Any())
                            return true;
                    }
                    return false;
                });
        }

        public override void IncludeTargetsFilter(List<WoWObject> incomingunits, HashSet<WoWObject> outgoingunits)
        {
            foreach (var obj in incomingunits)
            {
                var unit = obj as WoWUnit;
                if (unit != null)
                {
                    if (unit.Entry == ScarletZealot && Targeting.Instance.IsEmpty() && Me.IsTank() && unit.Location.DistanceSqr(_scarletZealotLoc) <= 4 * 4)
                        outgoingunits.Add(unit);

                }
            }
        }

        public override void WeighTargetsFilter(List<Targeting.TargetPriority> units)
        {
            foreach (var priority in units)
            {
                var unit = priority.Object as WoWUnit;
                if (unit != null)
                {
                    if (unit.Entry == PileOfCorpsesId)
                        priority.Score += 300;

                    // if (unit.Entry == EmpoweredZombie && StyxWoW.Me.IsDps())
                    //     priority.Score += 500;

                    if (unit.Entry == EvictedSoul && StyxWoW.Me.IsDps())
                        priority.Score += 400;
                }
            }
        }

        #endregion

        private const uint PileOfCorpsesId = 59722;
        private const uint EmpoweredZombie = 59930;
        private const uint EvictedSoul = 59974;
        private const uint ScarletCenturionId = 59746;
        private const uint ZombifiedCorpseId = 59771;
        private const uint TrainingDummyId = 60197;
        private const uint TrainingDummyId2 = 64446;
        private const uint BrotherKorloff = 59223;
        private const uint ScorchedEarth = 59507;
        private const uint ScarletZealot = 58590;
        private const uint CommanderDurand = 60040;
        const int FirestormKickId = 113764;

        private static LocalPlayer Me
        {
            get { return StyxWoW.Me; }
        }

        readonly WoWPoint _scarletZealotLoc = new WoWPoint(760.7621, 551.4827, 12.80546);

        [EncounterHandler(59706, "Fuel Tank", Mode = CallBehaviorMode.Proximity, BossRange = 10)]
        public Composite FuelTankEncounter()
        {
            return new Decorator<WoWUnit>(
                fuelTank => fuelTank.TransportGuid == 0 && Me.Combat,
                new PrioritySelector(
                    new Decorator<WoWUnit>(fuelTank => fuelTank.WithinInteractRange, new Helpers.Action<WoWUnit>(fuelTank => fuelTank.Interact())),
                    new Decorator<WoWUnit>(fuelTank => !fuelTank.WithinInteractRange, new Helpers.Action<WoWUnit>(fuelTank => Navigator.MoveTo(fuelTank.Location)))));
        }

        [EncounterHandler(59789, "Thalnos the Soulrender")]
        public Composite ThalnostheSoulrenderEncounter()
        {
            const int spiritGaleSpellId = 115289;
            const uint spiritGaleObjectId = 2857;
            WoWUnit boss = null;
            return new PrioritySelector(
                ctx => boss = ctx as WoWUnit,
                ScriptHelpers.CreateDispellParty("Evict Soul", ScriptHelpers.PartyDispellType.Magic),
                ScriptHelpers.CreateInterruptCast(() => boss, spiritGaleSpellId),
                ScriptHelpers.CreateRunAwayFromBad(ctx => true, 4, spiritGaleObjectId),
                ScriptHelpers.CreateRunAwayFromLocation(
                    ctx => true,
                    2,
                    m => ((WoWMissile)m).ImpactPosition,
                    () => WoWMissile.InFlightMissiles.Where(m => boss != null && boss.IsValid && m.CasterGuid == boss.Guid && m.SpellId == spiritGaleSpellId)));
        }

        [EncounterHandler(64838, "Hooded Crusader", Mode = CallBehaviorMode.Proximity)]
        public Composite HoodedCrusaderEncounter()
        {
            return new PrioritySelector(new Decorator<WoWUnit>(unit => unit.QuestGiverStatus == QuestGiverStatus.Available, ScriptHelpers.CreatePickupQuest(64838)));
        }

        [EncounterHandler(59223, "Brother Korloff", Mode = CallBehaviorMode.Proximity, BossRange = 100)]
        public Composite BrotherKorloffEncounter()
        {
            WoWUnit boss = null;
            const int blazingFists = 114807;

            return new PrioritySelector(
                ctx => boss = ctx as WoWUnit,
                ScriptHelpers.CreateRunAwayFromBad(
                    ctx => boss != null && boss.IsValid && !boss.Combat && boss.IsAlive && ScriptHelpers.GetUnfriendlyNpsAtLocation(() => boss.Location, 25, u => u.Entry != BrotherKorloff).Any(), 30, BrotherKorloff),

                new Decorator(ctx => !boss.Combat && ScriptHelpers.GetUnfriendlyNpsAtLocation(() => boss.Location, 25, u => u.Entry != BrotherKorloff).Any(),
                    ScriptHelpers.CreateClearArea(() => boss.Location, 40, u => u != boss)),
                ScriptHelpers.CreateRunAwayFromBad(ctx => true, 10, u => u.Entry == BrotherKorloff && u.ToUnit().CastingSpellId == FirestormKickId),
                ScriptHelpers.CreateRunAwayFromBad(ctx => true, 6, u => u.Entry == BrotherKorloff && u.ToUnit().CastingSpellId == blazingFists, u => u.Location.RayCast(u.Rotation, 3)),
                ScriptHelpers.CreateRunAwayFromBad(ctx => true, 3, ScorchedEarth));
        }

        [ObjectHandler(214296, "Blade of the Anointed")]
        public Composite BladeoftheAnointedHandler()
        {
            WoWGameObject blade = null;

            return new PrioritySelector(ctx => blade = ctx as WoWGameObject,
                new Decorator(ctx => blade.CanLoot,
                    ScriptHelpers.CreateInteractWithObject(() => blade, 2)));
        }

        [EncounterHandler(60040, "Commander Durand")]
        public Composite CommanderDurandEncounter()
        {
            return new PrioritySelector();
        }

        [EncounterHandler(3977, "High Inquisitor Whitemane")]
        public Composite HighInquisitorWhitemaneEncounter()
        {
            WoWUnit boss = null;
            const int massResurrection = 113134;
            const int heal = 12039;
            return new PrioritySelector(ctx => boss = ctx as WoWUnit,
                ScriptHelpers.CreateInterruptCast(() => boss, massResurrection, heal),
                ScriptHelpers.CreateDispellParty("Power Word: Shield", ScriptHelpers.PartyDispellType.Magic));
        }
    }
}