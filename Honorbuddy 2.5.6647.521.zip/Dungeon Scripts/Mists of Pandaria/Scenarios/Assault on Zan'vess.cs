﻿//#define USE_DUNGEONBUDDY_DLL

using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using CommonBehaviors.Actions;
using Styx;
using Styx.Common.Helpers;
using Styx.CommonBot;
using Styx.CommonBot.Frames;
using Styx.Helpers;
using Styx.Patchables;
using Styx.Pathing;
using Styx.TreeSharp;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using Action = Styx.TreeSharp.Action;
#if USE_DUNGEONBUDDY_DLL
using Bots.DungeonBuddyDll;
using Bots.DungeonBuddyDll.Profiles;
using Bots.DungeonBuddyDll.Attributes;
using Bots.DungeonBuddyDll.Helpers;

namespace Bots.DungeonBuddyDll.Dungeon_Scripts.Mists_of_Pandaria
#else
    using Bots.DungeonBuddy.Profiles;
    using Bots.DungeonBuddy.Attributes;
    using Bots.DungeonBuddy.Helpers;
namespace Bots.DungeonBuddy.Dungeon_Scripts.Mists_of_Pandaria
#endif
{
    internal class AssaultOnZanvess : Dungeon
    {
        #region Overrides of Dungeon

        public override uint DungeonId
        {
            get { return 593; }
        }

        public override WoWPoint Entrance
        {
            get { return new WoWPoint(1400.152, 428.4431, 479.0349); }
        }

        public override void RemoveTargetsFilter(List<WoWObject> units)
        {
            units.RemoveAll(
                ret =>
                {
                    var unit = ret.ToUnit();
                    if (unit != null)
                    {
                        if (unit.Combat && Me.Combat && !unit.IsTargetingMeOrPet && !unit.IsTargetingMyPartyMember && !unit.TaggedByMe)
                            return true;
                    }
                    return false;
                });
        }

        public override void IncludeTargetsFilter(List<WoWObject> incomingunits, HashSet<WoWObject> outgoingunits)
        {
            foreach (var obj in incomingunits)
            {
                var unit = obj as WoWUnit;
                if (unit != null) { }
            }
        }

        public override void WeighTargetsFilter(List<Targeting.TargetPriority> units)
        {
            foreach (var priority in units)
            {
                var unit = priority.Object as WoWUnit;
                if (unit != null) { }
            }
        }

        #endregion

        private const uint SkyfireGyrocopterId = 68115;
        private const uint SonicControlTowerId = 67788;
        private const uint ZanthikGuardianId = 67710;
        const uint ScorpidRelocatorId = 67784;
        private const uint SquadLeaderBoshId = 68143;

        private static LocalPlayer Me
        {
            get { return StyxWoW.Me; }
        }

        [EncounterHandler(0)]
        public Composite RootEncounter()
        {
            return new PrioritySelector(
                new Decorator(ctx => ScriptHelpers.CurrentScenarioInfo.CurrentStageIndex == 0, CreateStageOneBehavior()),
                new Decorator(ctx => ScriptHelpers.CurrentScenarioInfo.CurrentStageIndex == 1, CreateStageTwoBehavior()),
                new Decorator(ctx => ScriptHelpers.CurrentScenarioInfo.CurrentStageIndex == 2 || ScriptHelpers.CurrentScenarioInfo.CurrentStageIndex == 3, CreateAirstrikeBehavior()),
                new Decorator(ctx => ScriptHelpers.CurrentScenarioInfo.CurrentStageIndex == 3 && ScriptHelpers.IsBossAlive("Squad Leader Bosh"),
                    new Action(ctx => ScriptHelpers.MarkBossAsDead("Squad Leader Bosh"))));
        }

        private void FireBombard(WoWPoint target)
        {
            Lua.DoString("if GetSpellCooldown(133556) == 0 then CastSpellByID(133556) end");
            SpellManager.ClickRemoteLocation(target);
        }

        private Composite CreateGetInCopterBehavior()
        {
            return new PrioritySelector(
                ctx => // set the context to nearest empty copter
                ObjectManager.GetObjectsOfType<WoWUnit>().Where(u => u.Entry == SkyfireGyrocopterId && Me.PartyMembers.All(p => p.TransportGuid != u.Guid)).OrderBy(
                    u => u.DistanceSqr).FirstOrDefault(),
                new Decorator<WoWUnit>(copter => copter.WithinInteractRange, new Helpers.Action<WoWUnit>(copter => copter.Interact())),
                new Decorator<WoWUnit>(copter => !copter.WithinInteractRange, new Helpers.Action<WoWUnit>(copter => Navigator.PlayerMover.MoveTowards(copter.Location))));
        }

        private Composite CreateStageOneBehavior()
        {
            return new PrioritySelector(new Decorator(ctx => Me.TransportGuid == 0, CreateGetInCopterBehavior()), new ActionAlwaysSucceed());
        }

        private Composite CreateStageTwoBehavior()
        {
            return new PrioritySelector(
                ctx => ScriptHelpers.CurrentScenarioInfo.CurrentStage,
                new Decorator(ctx => Me.TransportGuid == 0, CreateGetInCopterBehavior()),
                new Decorator(
                    ctx => Me.TransportGuid != 0,
                    new PrioritySelector(
                // Criteria 1 ToDo finsh this.. and add support for incoming missiles.
                        new Decorator<ScenarioStage>(stage => !stage.Criterias[0].IsComplete, new PrioritySelector()),
                // Criteria 2
                        new Decorator<ScenarioStage>(
                            stage => stage.Criterias[0].IsComplete && !stage.Criterias[1].IsComplete,
                            new PrioritySelector(
                                ctx =>
                                ObjectManager.GetObjectsOfType<WoWUnit>().Where(
                                    u => (u.Entry == ZanthikGuardianId && u.IsAlive) || (u.Entry == SonicControlTowerId && !u.HasAura("Protective Shell")) && u.Distance < 200)
                                    .OrderBy(u => u.DistanceSqr).FirstOrDefault(),
                                new Helpers.Action<WoWUnit>(tower => FireBombard(tower.Location)))),
                // Criteria 3
                        new Decorator<ScenarioStage>(
                            stage => stage.Criterias[1].IsComplete && !stage.Criterias[2].IsComplete,
                            new PrioritySelector(
                                ctx =>
                                ObjectManager.GetObjectsOfType<WoWUnit>().Where(
                                    u => u.Entry == ScorpidRelocatorId && u.IsAlive && u.Distance < 200)
                                    .OrderBy(u => u.DistanceSqr).FirstOrDefault(),
                // fire in front of target since it's moving and we're shooting a projectile.
                                new Helpers.Action<WoWUnit>(scorpid => FireBombard(scorpid.Location.RayCast(WoWMathHelper.NormalizeRadian(scorpid.Rotation), 20))))))),
                new ActionAlwaysSucceed());
        }

        private Composite CreateAirstrikeBehavior()
        {
            WoWUnit airStrikeTarget = null;

            return new PrioritySelector(
                ctx =>
                {
                    var targets = ObjectManager.GetObjectsOfType<WoWUnit>().Where(u => u.Combat && u.IsTargetingMeOrPet || u.IsTargetingMyPartyMember).ToList();

                    airStrikeTarget = Me.Combat && targets.Count > 3 || targets.Any(t => t.Elite)
                                          ? targets.OrderByDescending(u => targets.Count(t => u.Location.DistanceSqr(t.Location) <= 10 * 10)).FirstOrDefault()
                                          : null;
                    return ScriptHelpers.CurrentScenarioInfo.CurrentStage;
                },
                new Decorator(ctx => airStrikeTarget != null && !Lua.GetReturnVal<bool>("return ExtraActionButton1.cooldown:IsVisible()", 0),
                    new Action(ctx =>
                                   {
                                       Lua.DoString("ExtraActionButton1:Click()");
                                       SpellManager.ClickRemoteLocation(airStrikeTarget.Location);
                                   }))
                );
        }

        [EncounterHandler(68143, "Squad Leader Bosh")]
        public Composite SquadLeaderBoshEncounter()
        {
            AddAvoidObject(ctx => true, 10, 68143);

            WoWUnit boss = null;
            return new PrioritySelector(ctx => boss = ctx as WoWUnit);
        }

        [EncounterHandler(67879, "Commander Tel'vrak")]
        public Composite CommanderTelvrakEncounter()
        {
            WoWUnit boss = null;
            return new PrioritySelector(ctx => boss = ctx as WoWUnit);
        }
    }
}