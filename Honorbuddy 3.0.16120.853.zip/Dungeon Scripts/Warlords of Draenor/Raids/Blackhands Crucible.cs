﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Numerics;
using System.Threading.Tasks;
using System.Windows.Documents;
using System.Windows.Forms.VisualStyles;
using Bots.DungeonBuddy.Attributes;
using Bots.DungeonBuddy.Helpers;
using Buddy.Coroutines;
using Styx;
using Styx.Common;
using Styx.Common.Helpers;
using Styx.CommonBot;
using Styx.CommonBot.Coroutines;
using Styx.Helpers;
using Styx.Pathing;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;

// ReSharper disable CheckNamespace

namespace Bots.DungeonBuddy.Raids.WarlordsOfDraenor
// ReSharper restore CheckNamespace
{
    public class BlackhandsCrucible : BlackrockFoundry
    {
        #region Overrides of Dungeon
        public override uint DungeonId
        {
            get { return 823; }
        }

        public override Vector3 Entrance
        {
            get { return new Vector3(1491.402f, 3071.209f, 110.1424f); }
        }

        public override Vector3 ExitLocation
        {
            get { return new Vector3(1491.654f, 2952.643f, 35.23913f); }
        }

        public override void RemoveTargetsFilter(List<WoWObject> units)
        {
            units.RemoveAll(
                ret =>
                {
                    var unit = ret as WoWUnit;
                    if (unit == null)
                        return false;

                    // Player can't navigate to these NPCs unless he/she is thrown up on the platform that NPC is on.
                    if (unit.Entry == MobId_IronSoldier && unit.ZDiff > 12)
                        return true;

                    return false;
                });
        }

        public override void IncludeTargetsFilter(List<WoWObject> incomingunits, HashSet<WoWObject> outgoingunits)
        {
            foreach (var obj in incomingunits)
            {
                var unit = obj as WoWUnit;
                if (unit != null)
                {
                }
            }
        }

        public override void WeighTargetsFilter(List<Targeting.TargetPriority> units)
        {
            var isMelee = Me.IsMelee();
            var israngedDps = !isMelee && Me.IsDps;
            foreach (var priority in units)
            {
                var unit = priority.Object as WoWUnit;
                if (unit != null)
                {
                    switch (unit.Entry)
                    {
                        case MobId_IronSoldier:
                            priority.Score += 5000;
                            break;

                        case MobId_Siegemaker:
                            priority.Score += 4000;
                            break;
                    }
                }
            }
        }

        public override void RemoveHealTargetsFilter(List<WoWObject> objects)
        {
            var blackHandStageTwo = ScriptHelpers.IsViable(_blackHand) && _blackHand.Combat && _blackHandStage == 2;

            objects.RemoveAll(
                ret =>
                {
                    var unit = ret as WoWUnit;
                    if (unit == null)
                        return false;

                    // Remove targets that are on platform while player is not on platform, or vice versa 
                    if (blackHandStageTwo && unit.ZDiff > 12)
                        return true;

                    return false;
                });
        }

        public override async Task<bool> HandleMovement(MoveToParameters moveToParameters)
        {
            return await CrucibleDoorHandler(moveToParameters.Location) || await ElevatorLogic(moveToParameters.Location);
        }

        #endregion


        #region Elevator Logic

        protected const uint GameObjectId_Elevator = 231014;

        private readonly Vector3 _elevatorBottomBoardLoc =
            WoWMathHelper.GetRandomPointInCircle(new Vector3(443.0896f, 3493.924f, 306.6379f), 2);

        private readonly Vector3 _elevatorBottomExitLoc =
            WoWMathHelper.GetRandomPointInCircle(new Vector3(431.2929f, 3494.608f, 306.929f), 1);

        private readonly float _elevatorBottomZ = 305.4167f;

        private readonly Vector3 _elevatorTopBoardLoc =
            WoWMathHelper.GetRandomPointInCircle(new Vector3(443.0896f, 3493.924f, 741.5526f), 2);

        // randomize points in order to avoid stacking of bots.
        private readonly Vector3 _elevatorTopExitLoc =
            WoWMathHelper.GetRandomPointInCircle(new Vector3(457.5137f, 3494.16f, 742.5745f), 1);

        private readonly float _elevatorTopZ = 740.3314f;

        private BoundingBox3 _elevatorShaftBounds = new BoundingBox3(new Vector3(435.5273f, 3485.564f, 300),
            new Vector3(453.0355f, 3502.836f, 741.9951f));

        public async Task<bool> ElevatorLogic(Vector3 destination)
        {
            var myloc = StyxWoW.Me.Location;

            var myFloorLevel = GetFloorLevel(myloc);
            var destinationFloorLevel = GetFloorLevel(destination);

            Vector3 elevatorBoardLoc, elevatorExitLoc;
            float elevatorRestingZ;
            WoWGameObject elevator;

            var handleElevator =
                GetElevatorMoveInfo(myloc, destination, out elevatorBoardLoc, out elevatorExitLoc, out elevatorRestingZ,
                    out elevator);

            if (!handleElevator)
                return false;

            var elevatorIsResting = elevator != null && Math.Abs(elevator.Z - elevatorRestingZ) <= 0.5f;

            if (elevator != null && Me.Transport == elevator)
            {
                if (elevatorIsResting && myFloorLevel == destinationFloorLevel && !_elevatorShaftBounds.Contains(destination))
                {
                    Logger.Write("[Elevator Manager] Exiting Elevator");
                    Navigator.PlayerMover.MoveTowards(elevatorExitLoc);
                }
            }
            else
            {
                // move to the elevator exit location
                if ((elevator == null || myloc.DistanceSquared(elevatorBoardLoc) > 20 * 20
                     || (!elevatorIsResting && myloc.DistanceSquared(elevatorExitLoc) > 4 * 4)
                     && !Navigator.AtLocation(elevatorBoardLoc)))
                {
                    Logger.Write("[Elevator Manager] Moving To Elevator");
                    var moveResult = Navigator.MoveTo(elevatorExitLoc);
                    return moveResult != MoveResult.Failed && moveResult != MoveResult.PathGenerationFailed;
                }

                // Get onboard of the elevator.
                if (elevatorIsResting && myloc.DistanceSquared(elevatorBoardLoc) > 1.5 * 1.5)
                {
                    Logger.Write("[Elevator Manager] Boarding Elevator");
                    // avoid getting stuck on lever
                    Navigator.PlayerMover.MoveTowards(elevatorBoardLoc);
                }
                else if (elevatorIsResting && myloc.DistanceSquared(elevatorBoardLoc) <= 1.5 * 1.5 && !Me.TransportGuid.IsValid)
                {
                    Logger.Write("[Elevator Manager] Jumping");
                    try
                    {
                        WoWMovement.Move(WoWMovement.MovementDirection.JumpAscend);
                        await Coroutine.Sleep(110);
                    }
                    finally
                    {
                        WoWMovement.MoveStop(WoWMovement.MovementDirection.JumpAscend);
                    }
                }
            }
            return true;
        }



        private bool GetElevatorMoveInfo(Vector3 myLoc, Vector3 destination,
            out Vector3 elevatorBoardLoc, out Vector3 elevatorExitLoc, out float elevatorRestingZ,
            out WoWGameObject elevator)
        {
            var myFloorLevel = GetFloorLevel(myLoc);
            var destinationFloorLevel = GetFloorLevel(destination);

            if (myFloorLevel == destinationFloorLevel && !_elevatorShaftBounds.Contains(destination))
            {
                var transport = Me.Transport;
                if (transport == null || transport.Entry != GameObjectId_Elevator)
                {
                    elevatorBoardLoc = elevatorExitLoc = Vector3.Zero;
                    elevatorRestingZ = 0;
                    elevator = null;
                    return false;
                }

                elevator = (WoWGameObject)transport;
                if (Math.Abs(myLoc.Z - _elevatorTopZ) > Math.Abs(myLoc.Z - _elevatorBottomZ))
                {
                    elevatorExitLoc = _elevatorBottomExitLoc;
                    elevatorRestingZ = _elevatorBottomZ;
                }
                else
                {
                    elevatorExitLoc = _elevatorTopExitLoc;
                    elevatorRestingZ = _elevatorTopZ;
                }
                // We don't care about elevatorBoardLoc while riding on the elevator. 
                elevatorBoardLoc = Vector3.Zero;
                return true;
            }

            elevator = ObjectManager.GetObjectsOfType<WoWGameObject>().FirstOrDefault(g => g.Entry == GameObjectId_Elevator);
            switch (myFloorLevel)
            {
                case FloorLevel.Upper:
                    elevatorBoardLoc = _elevatorTopBoardLoc;
                    elevatorExitLoc = _elevatorTopExitLoc;
                    elevatorRestingZ = _elevatorTopZ;
                    break;
                case FloorLevel.Main:
                    elevatorBoardLoc = _elevatorBottomBoardLoc;
                    elevatorExitLoc = _elevatorBottomExitLoc;
                    elevatorRestingZ = _elevatorBottomZ;
                    break;
                default:
                    throw new ArgumentException(string.Format("Unknown floor level: {0}", myFloorLevel));
            }
            return true;
        }

        private readonly Vector3 _blackhandAreaCenterLoc = new Vector3(567.9324f, 3494.572f, 741.7349f);
        private FloorLevel GetFloorLevel(Vector3 loc)
        {
            if (loc.Distance2DSquared(_blackhandAreaCenterLoc) < 67 * 67 && loc.Z > 500 || loc.Z > 700)
                return FloorLevel.Upper;

            return FloorLevel.Main;
        }

        private enum FloorLevel
        {
            Main,
            Upper,
        }


        #endregion Elevator Logic

        #region Crucible Door

        private const uint GameObjectId_CrucibleDoor = 233006;
        private readonly Vector3 _crucibleDoorRightEdge = new Vector3(326.6111f, 3424.123f, 306.7117f);
        private readonly Vector3 _crucibleDoorLeftEdge = new Vector3(326.7765f, 3435.413f, 306.7117f);

        private async Task<bool> CrucibleDoorHandler(Vector3 location)
        {
            var myLoc = Me.Location;
            if (myLoc.DistanceSquared(_crucibleDoorLeftEdge) > 15 * 15)
                return false;

            var door = ObjectManager.GetObjectsOfType<WoWGameObject>().FirstOrDefault(g => g.Entry == GameObjectId_CrucibleDoor);
            if (door == null || ((WoWDoor)door.SubObj).IsOpen)
                return false;

            return false;
#warning FIXME: Blackhands Crucible: CrucibleDoorHandler
            // TODO: Blackhands Crucible door handler
            // Cleanest would be to add this to meshes.

            //			var movePath = ((MeshNavigator) Navigator.NavigationProvider).CurrentMovePath;
            //			if (movePath == null || movePath.Index >= movePath.Path.Points.Length || movePath.Index < 0)
            //				return false;
            //
            //			var waypoint = (Vector3)movePath.Path.Points[movePath.Index];
            //			var isPlayerLeftOfDoor = myLoc.IsPointLeftOfLine(_crucibleDoorLeftEdge, _crucibleDoorRightEdge);
            //			var isWaypointLeftOfDoor = waypoint.IsPointLeftOfLine(_crucibleDoorLeftEdge, _crucibleDoorRightEdge);
            //
            //			// player and waypoint are on same side then return.
            //            if (isPlayerLeftOfDoor == isWaypointLeftOfDoor)
            //			return false;

            //			TreeRoot.StatusText = "Waiting on Crucible door to open";
            //			await CommonCoroutines.StopMoving();
            //			return true;
        }

        #endregion Crucible Door


        #region Root

        #endregion


        #region Blackhand

        private WoWUnit _blackHand;
        private int _blackHandStage;

        private const uint MobId_SlagBomb = 77343;
        private const uint MobId_Blackhand = 77325;
        private const uint MobId_RubblePile = 77405;
        private const uint MobId_Siegemaker = 77342;
        private const uint MobId_IronSoldier = 77665;
        private const uint MobId_MoltenSlag = 77558;
        private const uint MobId_SlagHole = 77357;

        private const int MissileSpellId_Demolition = 156496;
        private const uint AreaTriggerId_FallingAsh = 7022;
        private const uint AreaTriggerId_Blaze = 6380;
        private const uint AreaTriggerId_SlagCrater = 6330;

        [EncounterHandler((int)MobId_Blackhand, "Blackhand")]
        public Func<WoWUnit, Task<bool>> BlackhandEncounter()
        {
            AddAvoidObject(2, MobId_SlagBomb, AreaTriggerId_FallingAsh);
            AddAvoidObject(5, AreaTriggerId_Blaze);
            AddAvoidObject(() => true, o => o.ToUnit().CurrentTargetGuid == Me.Guid ? (Me.IsMoving ? 20 : 15) : 10,
                o => o.Entry == MobId_Siegemaker && o.ToUnit().CanSelect,
                o => o.Location.RayCast(o.Rotation, 5));
            AddAvoidObject(10, AreaTriggerId_SlagCrater);

            AddAvoidObject(() => true, 5, o => o.Entry == MobId_RubblePile && o.ToUnit().HasAura("Ore Visual"));
            AddAvoidLocation(() => true, 6, o => ((WoWMissile)o).ImpactPosition,
                () => WoWMissile.InFlightMissiles.Where(m => m.SpellId == MissileSpellId_Demolition));

            AddAvoidObject(() => ScriptHelpers.IsViable(_blackHand), 6, o => o is WoWPlayer && !o.IsMe && o.ToPlayer().HasAura("Marked for Death"),
                o => Me.Location.GetNearestPointOnSegment(o.Location, _blackHand.Location));

            AddAvoidObject(5, MobId_MoltenSlag, MobId_SlagHole);
            AddAvoidObject(5, MobId_SlagHole);

            Vector3 markedForDeathLosLoc = Vector3.Zero;
            WaitTimer markedForDeathTimer = new WaitTimer(TimeSpan.FromMilliseconds(10000));
            return async npc =>
            {
                _blackHand = npc;
                _blackHandStage = _blackHand.Z > 620 ? 1 : (_blackHand.Z > 580 ? 2 : 3);

                if (Me.HasAura("Marked for Death") && _blackHandStage != 3)
                {
                    if (markedForDeathTimer.IsFinished || markedForDeathLosLoc == Vector3.Zero)
                    {
                        var radius = _blackHandStage == 1 ? 7 : 12;
                        markedForDeathLosLoc =
                            ObjectManager
                                .GetObjectsOfType<WoWUnit>()
                                .Where(u => _blackHandStage == 1 ? (u.Entry == MobId_RubblePile && u.HasAura("Ore Visual")) : u.Entry == MobId_Siegemaker)
                                .Select(u => WoWMathHelper.CalculatePointFrom(_blackHand.Location, u.Location, -radius))
                                .OrderBy(l => Me.Location.DistanceSquared(l))
#warning FIXME: Dungeonbuddy - Blackhands Crucible: CanNavigateFully to marked-for-death mobs
                                // TODO: Dungeonbuddy - Blackhands Crucible: CanNavigateFully to marked-for-death mobs
                                // Probably use mesh sampling
                                .FirstOrDefault(/*l => Navigator.CanNavigateFully(Me.Location, l)*/);

                        markedForDeathTimer.Reset();
                    }
                    if (await ScriptHelpers.StayAtLocationWhile(
                        () => Me.HasAura("Marked for Death") && markedForDeathLosLoc != Vector3.Zero && _blackHandStage != 3,
                        markedForDeathLosLoc, "Marked for Death LOS", 1))
                    {
                        return true;
                    }
                }
                return false;
            };
        }
        #endregion
    }
}